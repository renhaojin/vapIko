package jp.co.nii.bma.business.rto;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import jp.co.nii.sew.presentation.AbstractRequestTransferObject;
import jp.co.nii.sew.presentation.DownloadRTO;
import jp.co.nii.sew.presentation.Messages;
import jp.co.nii.sew.presentation.Option;

/**
 *�^�C�g��: �����A�܂��͍u�K��̑I�� ����: �����A�܂��͍u�K��̑I�����RTO ���쌠: Copyright (c) 2020 ��Ж�: ���{���Y�Ɗ������
 * @author Luo-Yang
 */

public class MskSknJoho extends DownloadRTO {
    
   private Messages errors;
    
    /**     t01�����I�����     **/
    /** �\���҂h�c */
    private String moshikomishaId;
    /** ����敪 */
    private String kaiinKbn;
    /** �����u�K��R�[�h */
    private String sknKsuCode;
    /** ��ʃR�[�h */
    private String shubetsuCode;
    /** �񐔃R�[�h */
    private String kaisuCode;
    /** �����u�K��敪 */
    private String sknKsuKbn;
    /** �����u�K� */
    private String sknKsuName;
    /** �����u�K��i���j */
    private String sknKsuNameRyaku;
    /** �����u�K��Q��ʂȂ� */
    private String sknKsuNameNosbt;
     /** �����u�K��Q��ʂȂ��i���j */
    private String sknKsuNameNosbtRyaku;
    /** ��ʖ� */
    private String shubetsuName;
    /** �񐔖� */
    private String kaisuName;
    /** �N�x */
    private String nendo;
    /** �X�P�W���[���R�[�h */
    private String scheduleCode;
    /** �\�����Ԃe�q�n�l */
    private String mskKikanStart;
    /** �\�����Ԃs�n */
    private String mskKikanEnd;
    private String mosikomi;
    private String close;
    private String sknMsk;
    // �\���{�^���@�����E�񊈐�����@"1"�F�����@"0":�񊈐�
    private String active;
    
    /** �c�́E�����u�K��I��*/
    /** �\���I���{�^�� */
    private String moshikomiChoice;
    /** �e���v���[�g�_�E�����[�h�{�^�� */
    private String templateDownload;
    /** 2�d�\���`�F�b�N�p���� */
    private String moshikomiCountFlg;
    private String moshikomiCount;
    
    //���� ���X�g
    private List<MskSknJoho> mskSknList;
    private List<Option> sknKsuCodeList;
    private List<Option> shubetsuCodeList;
    private List<Option> kaisuCodeList;
    private List<Option> sknNaiyoList;
    private List<Option> sknKsuKbnList;
    
    /** �{�^�� */
    private String backDoi;
    private String mskKbnSentakuBack;
    private String checkMosikomi;
    
    private MskSikakuJoho mskSikakuJoho;
    
    public MskSknJoho() {
        clearInfo();
    }

    private void clearInfo() {
        setErrors(new Messages());
        
        /**�����I�����**/
        setMoshikomishaId("");
        setKaiinKbn("");
        setSknKsuCode("");
        setShubetsuCode("");
        setKaisuCode("");
        setSknKsuKbn("");
        setSknKsuName("");
        setSknKsuNameRyaku("");
        setSknKsuNameNosbt("");
        setSknKsuNameNosbtRyaku("");
        setShubetsuName("");
        setKaisuName("");
        setNendo("");
        setScheduleCode("");
        setMskKikanStart("");
        setMskKikanEnd("");
        setMoshikomiChoice("");
        setTemplateDownload("");
        setMosikomi("");
        setClose("");
        setSknMsk("");
//        setSknNaiyoKbn("01");
        setKaisuCode("");
        
        setMskSknList(new ArrayList<MskSknJoho>());
        
        setSknKsuCodeList(new ArrayList<Option>());
        setShubetsuCodeList(new ArrayList<Option>());
        setKaisuCodeList(new ArrayList<Option>());
        setSknNaiyoList(new ArrayList<Option>());
        setSknKsuKbnList(new ArrayList<Option>());
        
        /** �{�^�� */
        setBackDoi("");
        setMskKbnSentakuBack("");
        setCheckMosikomi("");
    }
    
    @Override
    public void copyFromRequest(HttpServletRequest request) {
        
        /**�����I�����**/
        setMoshikomishaId((String) request.getAttribute("moshikomishaId"));
        setKaiinKbn((String) request.getAttribute("kaiinKbn"));
        setSknKsuCode((String) request.getAttribute("sknKsuCode"));
        setShubetsuCode((String) request.getAttribute("shubetsuCode"));
        setKaisuCode((String) request.getAttribute("kaisuCode"));
        setSknKsuKbn((String) request.getAttribute("sknKsuKbn"));
        setSknKsuName((String) request.getAttribute("sknKsuName"));
        setSknKsuNameRyaku((String) request.getAttribute("sknKsuNameRyaku"));
        setSknKsuNameNosbt((String) request.getAttribute("sknKsuNameNosbt"));
        setSknKsuNameNosbtRyaku((String) request.getAttribute("sknKsuNameNosbtRyaku"));
        setShubetsuName((String) request.getAttribute("shubetsuName"));
        setKaisuName((String) request.getAttribute("kaisuName"));
        setNendo((String) request.getAttribute("nendo"));
        setScheduleCode((String) request.getAttribute("scheduleCode"));
        setMskKikanStart((String) request.getAttribute("mskKikanStart"));
        setMskKikanEnd((String) request.getAttribute("mskKikanEnd"));
        setMoshikomiChoice((String) request.getAttribute("moshikomiChoice"));
        setTemplateDownload((String) request.getAttribute("templateDownload"));
        setMosikomi((String) request.getAttribute("mosikomi"));
        setClose((String) request.getAttribute("close"));
        setSknMsk((String) request.getAttribute("sknMsk"));
//        setSknNaiyoKbn((String) request.getAttribute("sknNaiyoKbn"));
        setKaisuCode((String) request.getAttribute("kaisuCode"));
        
        /** �{�^�� */
        setBackDoi((String) request.getAttribute("backDoi"));
        setMskKbnSentakuBack((String) request.getAttribute("mskKbnSentakuBack"));
        setCheckMosikomi((String) request.getAttribute("checkMosikomi"));
        
        HttpSession session = request.getSession(false);
        if (session.getAttribute("MskJoho") != null) {
            MskJoho tmp = (MskJoho) session.getAttribute("MskJoho");
            setMoshikomishaId(tmp.getMoshikomishaId());
            setSknKsuCode(tmp.getSknKsuCode());
            setShubetsuCode(tmp.getShubetsuCode());
            setKaisuCode(tmp.getKaisuCode());
            setSknKsuKbn(tmp.getSknKsuKbn());
            setSknKsuNameNosbt(tmp.getSknKsuNameNosbt());
            setShubetsuName(tmp.getShubetsuName());
        }
        
        if(session.getAttribute("TopJoho") != null){
            TopJoho temp = (TopJoho) session.getAttribute("TopJoho");
            setMoshikomishaId(temp.getMoshikomishaId());
            setKaiinKbn(temp.getKaiinKbn());
        }
        
        // �N�x�擾
        if (session.getAttribute("MskSknJoho") != null) {
            MskSknJoho mskSknJoho = (MskSknJoho) session.getAttribute("MskSknJoho");
            setNendo(mskSknJoho.getNendo());
        }
        
        if(session.getAttribute("MskSikakuJoho") != null){
            MskSikakuJoho temp = (MskSikakuJoho) session.getAttribute("MskSikakuJoho");
            setMskSikakuJoho(temp);
        }
    }

    /**setter and getter**/
    public Messages getErrors() {
        return errors;
    }

    public void setErrors(Messages errors) {
        this.errors = errors;
    }

    public String getMosikomi() {
        return mosikomi;
    }

    public void setMosikomi(String mosikomi) {
        this.mosikomi = mosikomi;
    }

    public String getClose() {
        return close;
    }

    public void setClose(String close) {
        this.close = close;
    }

    public String getSknMsk() {
        return sknMsk;
    }

    public void setSknMsk(String sknMsk) {
        this.sknMsk = sknMsk;
    }
    
    /**
     * @return the active
     */
    public String getActive() {
        return active;
    }

    /**
     * @param active the active to set
     */
    public void setActive(String active) {
        this.active = active;
    }
    
    public List<MskSknJoho> getMskSknList() {
        return mskSknList;
    }

    public void setMskSknList(List<MskSknJoho> mskSknList) {
        this.mskSknList = mskSknList;
    }

    public List<Option> getSknKsuCodeList() {
        return sknKsuCodeList;
    }

    public void setSknKsuCodeList(List<Option> sknKsuCodeList) {
        this.sknKsuCodeList = sknKsuCodeList;
    }

    public List<Option> getShubetsuCodeList() {
        return shubetsuCodeList;
    }

    public void setShubetsuCodeList(List<Option> shubetsuCodeList) {
        this.shubetsuCodeList = shubetsuCodeList;
    }

    public List<Option> getKaisuCodeList() {
        return kaisuCodeList;
    }

    public void setKaisuCodeList(List<Option> kaisuCodeList) {
        this.kaisuCodeList = kaisuCodeList;
    }

    public List<Option> getSknKsuKbnList() {
        return sknKsuKbnList;
    }

    public void setSknKsuKbnList(List<Option> sknKsuKbnList) {
        this.sknKsuKbnList = sknKsuKbnList;
    }
    
    public List<Option> getSknNaiyoList() {
        return sknNaiyoList;
    }

    public void setSknNaiyoList(List<Option> sknNaiyoList) {
        this.sknNaiyoList = sknNaiyoList;
    }
    
    public String getMskKikanStart() {
        return mskKikanStart;
    }

    public void setMskKikanStart(String mskKikanStart) {
        this.mskKikanStart = mskKikanStart;
    }

    public String getMskKikanEnd() {
        return mskKikanEnd;
    }

    public void setMskKikanEnd(String mskKikanEnd) {
        this.mskKikanEnd = mskKikanEnd;
    }

//    public String getSknNaiyoKbn() {
//        return sknNaiyoKbn;
//    }
//
//    public void setSknNaiyoKbn(String sknNaiyoKbn) {
//        this.sknNaiyoKbn = sknNaiyoKbn;
//    }

    public String getKaisuCode() {
        return kaisuCode;
    }

    public void setKaisuCode(String kaisuCode) {
        this.kaisuCode = kaisuCode;
    }

    public String getSknKsuCode() {
        return sknKsuCode;
    }

    public void setSknKsuCode(String sknKsuCode) {
        this.sknKsuCode = sknKsuCode;
    }

    public String getShubetsuCode() {
        return shubetsuCode;
    }

    public void setShubetsuCode(String shubetsuCode) {
        this.shubetsuCode = shubetsuCode;
    }

    public String getSknKsuKbn() {
        return sknKsuKbn;
    }

    public void setSknKsuKbn(String sknKsuKbn) {
        this.sknKsuKbn = sknKsuKbn;
    }

    public String getSknKsuName() {
        return sknKsuName;
    }

    public void setSknKsuName(String sknKsuName) {
        this.sknKsuName = sknKsuName;
    }

    public String getSknKsuNameNosbt() {
        return sknKsuNameNosbt;
    }

    public void setSknKsuNameNosbt(String sknKsuNameNosbt) {
        this.sknKsuNameNosbt = sknKsuNameNosbt;
    }

    /**
     * �����u�K��Q��ʂȂ��i���j ���擾����B
     * @return �����u�K��Q��ʂȂ��i���j
     */
    public String getSknKsuNameNosbtRyaku() {
        return sknKsuNameNosbtRyaku;
    }

    /**
     * �����u�K��Q��ʂȂ��i���j ���Z�b�g����B
     * @param sknKsuNameNosbtRyaku �����u�K��Q��ʂȂ��i���j
     */
    public void setSknKsuNameNosbtRyaku(String sknKsuNameNosbtRyaku) {
        this.sknKsuNameNosbtRyaku = sknKsuNameNosbtRyaku;
    }
    
    public String getSknKsuNameRyaku() {
        return sknKsuNameRyaku;
    }

    public void setSknKsuNameRyaku(String sknKsuNameRyaku) {
        this.sknKsuNameRyaku = sknKsuNameRyaku;
    }
    
    public String getShubetsuName() {
        return shubetsuName;
    }

    public void setShubetsuName(String shubetsuName) {
        this.shubetsuName = shubetsuName;
    }

    public String getKaisuName() {
        return kaisuName;
    }

    public void setKaisuName(String kaisuName) {
        this.kaisuName = kaisuName;
    }

    public String getNendo() {
        return nendo;
    }

    public void setNendo(String nendo) {
        this.nendo = nendo;
    }

    public String getScheduleCode() {
        return scheduleCode;
    }

    public void setScheduleCode(String scheduleCode) {
        this.scheduleCode = scheduleCode;
    }
    
    public String getMskKikanStartDsp() {
        if(mskKikanStart.length() == 8){
            return mskKikanStart.substring(0,4)+"�N"+mskKikanStart.substring(4,6)+"��"+mskKikanStart.substring(6)+"��"+"("+dateToWeek(mskKikanStart)+")";
        }
        return "";
    }

    public String getMskKikanEndDsp() {
        if(mskKikanEnd.length() == 8){
            return mskKikanEnd.substring(0,4)+"�N"+mskKikanEnd.substring(4,6)+"��"+mskKikanEnd.substring(6)+"��"+"("+dateToWeek(mskKikanEnd)+")";
        }
        return "";
    }

    public String getMoshikomiChoice() {
        return moshikomiChoice;
    }

    public void setMoshikomiChoice(String moshikomiChoice) {
        this.moshikomiChoice = moshikomiChoice;
    }

    public String getTemplateDownload() {
        return templateDownload;
    }

    public void setTemplateDownload(String templateDownload) {
        this.templateDownload = templateDownload;
    }

    public String getMoshikomiCount() {
        return moshikomiCount;
    }

    public void setMoshikomiCount(String moshikomiCount) {
        this.moshikomiCount = moshikomiCount;
    }

    public String getMoshikomiCountFlg() {
        return moshikomiCountFlg;
    }

    public void setMoshikomiCountFlg(String moshikomiCountFlg) {
        this.moshikomiCountFlg = moshikomiCountFlg;
    }

    public String getMoshikomishaId() {
        return moshikomishaId;
    }

    public void setMoshikomishaId(String moshikomishaId) {
        this.moshikomishaId = moshikomishaId;
    }

    public String getKaiinKbn() {
        return kaiinKbn;
    }

    public void setKaiinKbn(String kaiinKbn) {
        this.kaiinKbn = kaiinKbn;
    }

    public String getBackDoi() {
        return backDoi;
    }

    public void setBackDoi(String backDoi) {
        this.backDoi = backDoi;
    }

    public String getMskKbnSentakuBack() {
        return mskKbnSentakuBack;
    }

    public void setMskKbnSentakuBack(String mskKbnSentakuBack) {
        this.mskKbnSentakuBack = mskKbnSentakuBack;
    }

    public String getCheckMosikomi() {
        return checkMosikomi;
    }

    public void setCheckMosikomi(String checkMosikomi) {
        this.checkMosikomi = checkMosikomi;
    }

    public MskSikakuJoho getMskSikakuJoho() {
        return mskSikakuJoho;
    }
    
    public void setMskSikakuJoho(MskSikakuJoho mskSikakuJoho) {
        this.mskSikakuJoho = mskSikakuJoho;
    }
    
    /**
     * ���t�ɂ���ėj�����擾����
     * @param datetime�@���t
     * @return  �j��
     */
    public static String dateToWeek(String datetime) {

        SimpleDateFormat f = new SimpleDateFormat("yyyyMMdd");
        String[] weekDays = {"��", "��", "��", "��", "��", "��", "�y"};
        Calendar cal = Calendar.getInstance();
        Date date;
        try {
            date = f.parse(datetime);
            cal.setTime(date);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        //the day number of a week
        int w = cal.get(Calendar.DAY_OF_WEEK) - 1;
        if (w < 0)
            w = 0;
        return weekDays[w];
    }
}
