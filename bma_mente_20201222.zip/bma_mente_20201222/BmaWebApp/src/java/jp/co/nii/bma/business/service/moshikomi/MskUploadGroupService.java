package jp.co.nii.bma.business.service.moshikomi;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;
import jp.co.nii.bma.business.domain.Gazo;
import jp.co.nii.bma.business.domain.HoyuShikakuMst;
import jp.co.nii.bma.business.domain.MSkkMnjKanri;
import jp.co.nii.bma.business.domain.MeishoKanri;
import jp.co.nii.bma.business.domain.Moshikomi;
import jp.co.nii.bma.business.domain.MoshikomiHenkoRireki;
import jp.co.nii.bma.business.domain.Saiban;
import jp.co.nii.bma.business.domain.ShiyoKaijo;
import jp.co.nii.bma.business.domain.SknksuMst;
import jp.co.nii.bma.business.domain.Torokusha;
import jp.co.nii.bma.business.service.common.BmaConstants;
import jp.co.nii.bma.business.service.common.BmaLogger;
import jp.co.nii.bma.business.service.common.SaibanService;
import jp.co.nii.bma.business.service.common.BmaValidator;
import jp.co.nii.bma.presentation.common.BmaText;
import jp.co.nii.bma.utility.BmaFileUtility;
import jp.co.nii.bma.utility.BmaUtility;
import jp.co.nii.sew.business.service.AbstractService;
import jp.co.nii.sew.presentation.Messages;
import jp.co.nii.sew.presentation.Option;
import jp.co.nii.sew.presentation.RequestTransferObject;
import jp.co.nii.sew.utility.PropertyUtility;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.fileupload.FileItem;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import java.net.URLEncoder;
import java.text.ParseException;
import java.util.Locale;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;
import jp.co.nii.bma.business.domain.Shokureki;
import jp.co.nii.bma.business.rto.MskKsuJoho;
import jp.co.nii.bma.business.rto.MskUploadJoho;
import jp.co.nii.bma.business.service.common.MoshikomiCommonService;
import jp.co.nii.bma.utility.BmaDateTimeUtility;
import jp.co.nii.bma.utility.BmaStringUtility;
import jp.co.nii.sew.business.Validator;
import static jp.co.nii.sew.business.service.ApplicationService.DOWNLOAD;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_BACK;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_CONFIRM;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_RELOAD;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_SUCCESS;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_UPLOAD;
import jp.co.nii.sew.presentation.Message;
import jp.co.nii.sew.utility.CheckUtility;
import org.apache.poi.ss.util.CellReference;

/**
 * �^�C�g��: �\���f�[�^�A�b�v���[�h�T�[�r�X ����: �\���f�[�^�A�b�v���[�hRTO ���쌠: Copyright (c) 2020 ��Ж�:
 * ���{���Y�Ɗ������
 *
 */
public class MskUploadGroupService extends AbstractService {

    /**
     * DB�ڑ��̃f�[�^�\�[�X
     */
    private static String DATA_SOURCE_NAME;
    /**
     * ���O
     */
    BmaLogger log = (BmaLogger) BmaLogger.getLogger(this.getClass().getName());
    /**
     * �Ɩ��R�[�h
     */
    private static final String BUSINESS_CODE = PropertyUtility.getProperty("business_code");
    /**
     * ���׃e�X�g���[�h
     */
    private static final String STRESS_MODE = PropertyUtility.getProperty(BUSINESS_CODE + "stress_mode");
    /**
     * �t�F�C���T�C�Y
     */
    private static final String CSV_SIZE = PropertyUtility.getProperty(BUSINESS_CODE + "max_csv_size");
    //���i��� ���i��̐E���v�Z�p��N
    private static final String GOKAKU_SHOKUREKI_NEN = PropertyUtility.getProperty(BUSINESS_CODE + "gokaku_shokureki_nen");
    //���i��� ���i��̐E���v�Z�p�����
    private static final String GOKAKU_SHOKUREKI_TSUKIHI = PropertyUtility.getProperty(BUSINESS_CODE + "gokaku_shokureki_tsukihi");

    /**
     * �R���X�g���N�^
     */
    public MskUploadGroupService() {
        super();
        /* DB�ڑ����̃��[�U�[������ */
        DATA_SOURCE_NAME = BmaConstants.DS_REGISTRANT;
    }

    /**
     * �T�[�r�X�N���X�̎��s���\�b�h
     *
     * @param rto ���N�G�X�g��񂩂�擾����rto
     * @param rtoInSession �Z�b�V�������rto
     * @return foward��
     * @throws Exception ��O
     */
    @Override
    public String doService(RequestTransferObject rto, RequestTransferObject rtoInSession)
            throws Exception {

        MskUploadJoho inRequest = (MskUploadJoho) rto;
        MskUploadJoho inSession = (MskUploadJoho) rtoInSession;
        String processName = "";

        /*�G���[���b�Z�[�W������*/
        inSession.setErrors(new Messages());
        inSession.setMoshikomishaId(inRequest.getMoshikomishaId());
        inSession.setNendo(inRequest.getNendo());
        try {
            if (!BmaUtility.isNullOrEmpty(inRequest.getNextDoi())
                    || !BmaUtility.isNullOrEmpty(inRequest.getMskKakuninBack())
                    || !BmaUtility.isNullOrEmpty(inRequest.getKaijoSentakuNext())) {
                /*�u���ʐ\���v�{�^��������*/
                processName = "SmnMskDataUpload";
                log.Start(processName);
                inSession.clearInfo();
                inSession.setSknKsuNameNosbt(inRequest.getSknKsuNameNosbt());
                /* �\���f�[�^�A�b�v���[�h ��ʕ\�� */
                return FWD_NM_SUCCESS;
            } else if (!BmaUtility.isNullOrEmpty(inRequest.getMskUl())) {
                /*�u�A�b�v���[�h�v�{�^��������*/
                processName = "SmnMskDataUpload";
                log.Start(processName);
                /*���͒l���Z�b�V�����ɕۑ�*/
                setValueRequestToSession(inRequest, inSession);
                inSession.setFuriganaOnlyErrFlg(BmaConstants.FLG_OFF);
                inSession.setErrorLogFlg(BmaConstants.FLG_OFF);
                // �t�@�C���擾
                String fileName = inRequest.getMskFileChoice().getName();
                File file = new File(fileName);
                // PATH���t���Ă���̃t�@�C���̂ݔ��f����
                int index = fileName.indexOf("\\");
                // IE��������
                if (index > 0 && !file.exists()) {
                    /* �e�h�k�d���݂��Ă��܂���̎��G���[*/
                    Messages errors = new Messages();
                    BmaValidator.addMessage(errors, "info",
                            "�t�@�C�������݂��܂���B", "�t�@�C��");
                    inSession.setErrors(errors);
                    return FWD_NM_RELOAD;
                }

                /*�g���q�`�F�b�N*/
                if (!validateSearchInput(inRequest, inSession)) {
                    /*�G���[���������ꍇ�͌���������ʍĕ\��*/
                    return FWD_NM_RELOAD;
                }
                boolean result = false;
                // �G���[���X�g
                List<ErrorMsg> errorLog = new ArrayList<>();
                //�t�@�C���`���`�F�b�N
                if (validateImportFile(inRequest, inSession)) {
                    //�C���|�[�g
                    SimpleDateFormat dt = new SimpleDateFormat("yyyyMMdd");
                    SimpleDateFormat tm = new SimpleDateFormat("HHmmss");
                    Date date = new Date();
                    String koshinDate = dt.format(date);
                    String koshinTime = tm.format(date);
                    inSession.setTorokuUserId(inSession.getMoshikomishaId());
                    inSession.setTorokuDate(koshinDate);
                    inSession.setTorokuTime(koshinTime);
                    if (importFile(inRequest, inSession, errorLog)) {
                        result = true;
                    }
                } else {
                    /*�G���[���������ꍇ�͌���������ʍĕ\��*/
                    return FWD_NM_RELOAD;
                }

                if (result) {
                    log.info("�f�[�^�C���|�[�g����I��");
                    Messages errors = new Messages();
                    BmaValidator.addMessage(errors, "info",
                            "�f�[�^�C���|�[�g����I���B");
                    inSession.setErrors(errors);
                    inSession.setUpdCheck("1");
                    inRequest.setMskUl("");
                    return FWD_NM_RELOAD;
                } else {
                    if (BmaConstants.FLG_ON.equals(inSession.getFuriganaOnlyErrFlg())) {
                        log.error("�f�[�^�C���|�[�g�ُ�I��_�t���K�i�s��v�̂�");
                    } else {
                        log.error("�f�[�^�C���|�[�g�ُ�I��_�f�[�^NG");
                    }
                    inSession.setErrorLogForDownload(errorLog);
                    if (inSession.getErrors().get("info") == null) {
                        inSession.setErrors(new Messages());
                    }
                    return FWD_NM_RELOAD;
                }
            } else if (!BmaUtility.isNullOrEmpty(inRequest.getUpdNext())) {
                /*�u���ցv�{�^��������*/
                processName = "updNext";
                log.Start(processName);
                /* �\���f�[�^�A�b�v���[�h ��ʕ\�� */
                return FWD_NM_NEXT;
            } else if (!BmaUtility.isNullOrEmpty(inRequest.getUpdBack())) {
                /*�u�߂�v�{�^��������*/
                processName = "updBack";
                log.Start(processName);
                /* �����̏ꍇ�A���Ӊ�ʕ\�� �u�K��̏ꍇ�A���m�F��ʕ\�� */
                String result = "";
                if (BmaConstants.KSU_KBN.equals(inRequest.getSknKsuKbn())) {
                    // �g�p���Ď擾
                    List<MskKsuJoho> kaijoList = new ArrayList<>();
                    List<MskKsuJoho> kaijoListNew = new ArrayList<>();
                    ShiyoKaijo shiyoKaijo = new ShiyoKaijo(BmaConstants.DS_REGISTRANT);
                    MskKsuJoho mskKsuJoho = inRequest.getMskKsuJoho();
                    /*��ꃊ�X�g�擾*/
                    kaijoList = shiyoKaijo.searchKaijoList(inSession.getNendo(), inRequest.getSknKsuCode(),
                            inRequest.getShubetsuCode(), inRequest.getKaisuCode(), "0");
                    /*�J�Òn�擾*/
                    Map<String, List<MskKsuJoho>> kaisaichi = kaijoList.stream().collect(
                            Collectors.groupingBy(MskKsuJoho::getKaisaichiCode));
                    /*��ꃊ�X�g����J�Òn���Ɣz��*/
                    for (Map.Entry<String, List<MskKsuJoho>> entry : kaisaichi.entrySet()) {
                        List<MskKsuJoho> listGroup = entry.getValue();
                        for (MskKsuJoho item : listGroup) {
                            item.setCount(listGroup.size() + "");
                            kaijoListNew.add(item);
                        }
                    }
                    mskKsuJoho.setKaiMskJohoList(kaijoListNew);
                    result = FWD_NM_BACK + "Kaijo";
                } else {
                    result = FWD_NM_BACK + "Doi";
                }
                return result;
            } else if (!BmaUtility.isNullOrEmpty(inRequest.getErrorLogCheck())) {
                /*�t���K�i�̂ݕs��v�E�G���[���O����̃|�b�v�A�b�v�I����*/
                processName = "errorLogCheck";
                log.Start(processName);
                
                if ("ok".equals(inRequest.getErrorLogCheck())) {
                    inSession.setFuriganaOnlyErrFlg(BmaConstants.FLG_OFF);
                    log.info("�f�[�^�C���|�[�g����I��");
                    Messages errors = new Messages();
                    BmaValidator.addMessage(errors, "info",
                            "�f�[�^�C���|�[�g����I���B");
                    inSession.setErrors(errors);
                    inSession.setUpdCheck("1");
                    inRequest.setMskUl("");
                    return FWD_NM_RELOAD;
                } else {
                    createCsv(inRequest, inSession, inSession.getErrorLogForDownload());
                    inSession.clearInfo();
                    return DOWNLOAD;
                }
            } else {
                /*�ُ�J��*/
                log.IllegalFWD();
//                return FWD_NM_SESSION;
                return FWD_NM_RELOAD;
            }
        } catch (Exception e) {
            throw e;
        } finally {
            log.End(processName);
        }
    }

    /**
     * �\�������X�V����
     *
     * @param bo
     * @param inSession
     */
    public void moshikomiUpd(Moshikomi bo, MskUploadJoho inSession) {
        Date date = new Date();
        SimpleDateFormat dt = new SimpleDateFormat("yyyyMMdd");
        SimpleDateFormat tm = new SimpleDateFormat("HHmmss");
        String koshinDate = dt.format(date);
        String koshinTime = tm.format(date);
        bo.setMoshikomiJokyoKbn("01");
        bo.setUnyoJokyoKbn("01");
        bo.setKoshinKbn("U");
        bo.setKoshinDate(koshinDate);
        bo.setKoshinTime(koshinTime);
        bo.setKoshinUserId(inSession.getMoshikomishaId());
    }

    /**
     * �\���ύX��o�^����
     *
     * @param bo
     * @param inSession
     */
    public void moshikomihenkoTrk(MoshikomiHenkoRireki bo, MskUploadJoho inSession) throws Exception {
        Saiban saiban = new SaibanService(DATA_SOURCE_NAME).getSaibanAndUpdate(BmaConstants.SAIBAN_MOSHIKOMIHENKORIREKI_IDX, inSession.getMoshikomishaId());
        bo.setMoshikomiHenkoRirekiIdx(saiban.getGenzaiNo());
        bo.setHenkoKbn("1");
        bo.setKoshinKbn("I");
        bo.setTorokuDate(bo.getKoshinDate());
        bo.setTorokuTime(bo.getKoshinTime());
        bo.setTorokuUserId(inSession.getMoshikomishaId());
        bo.setKoshinDate("");
        bo.setKoshinTime("");
        bo.setKoshinUserId("");
    }

    /**
     * �t�@�C����ǂݍ��݁A���f�[�^���C���T�[�g
     *
     * @param inRequest
     * @param inSession
     * @return �C���|�[�g�����̏ꍇ�Atrue
     * @throws Exception
     */
    private boolean importFile(MskUploadJoho inRequest, MskUploadJoho inSession, List<ErrorMsg> errorLog) throws IOException {
        Messages errors = new Messages();
        ShiyoKaijo shiyoKaijo = new ShiyoKaijo(BmaConstants.DS_REGISTRANT);
        List<MskKsuJoho> kiboKaijoList = new ArrayList<>();

        // �t�@�C���擾
        FileItem fItem = inRequest.getMskFileChoice();
        String line;
        int rowCount = 5;
        List<String> uketsukeNos = new ArrayList<>();

        boolean ret = false;

        if (!(fItem.isFormField())) {
            BufferedReader bufferedReader = null;
            try {
                bufferedReader = new BufferedReader(new InputStreamReader(fItem.getInputStream(), BmaConstants.ENCODE_WINDOWS_31J));
                // systemTime

                String[] lineArray;

                //�t�@�C���ŏI�s�܂ŌJ��Ԃ�
//                bufferedReader.mark(1);
                while ((line = bufferedReader.readLine()) != null) {
                    String tempStr = line;
                    //�t�@�C�����e��String�z��ɕϊ�
                    if (tempStr.endsWith("\"")) {
                        tempStr = tempStr.replaceAll("^\"|\"$", "");
                        lineArray = tempStr.split("\",\"", -1);
                        tempStr = "";
                    } else {
                        lineArray = tempStr.split(",", -1);
                        tempStr = "";
                    }
                    int length = 0;
                    String sknksuKbn = inRequest.getSknKsuKbn();
                    String sknksuCode = inRequest.getSknKsuCode();
                    String shubetsuCode = inRequest.getShubetsuCode();
                    String kaisuCode = inRequest.getKaisuCode();
                    if (sknksuKbn.equals(BmaConstants.SKN_KBN)) {
                        if (sknksuCode.equals(BmaConstants.SKN_KSU_CODE_BC) && shubetsuCode.equals(BmaConstants.SHUBETSU_CODE_ONE)) {
                            length = 97;
                        } else if (sknksuCode.equals(BmaConstants.SKN_KSU_CODE_BE) && shubetsuCode.equals(BmaConstants.SHUBETSU_CODE_ONE)) {
                            length = 101;
                        } else if (sknksuCode.equals(BmaConstants.SKN_KSU_CODE_BC) && shubetsuCode.equals(BmaConstants.SHUBETSU_CODE_TWO)) {
                            length = 98;
                        } else if ((sknksuCode.equals(BmaConstants.SKN_KSU_CODE_BC) && shubetsuCode.equals(BmaConstants.SHUBETSU_CODE_THREE))
                                || (sknksuCode.equals(BmaConstants.SKN_KSU_CODE_BE) && shubetsuCode.equals(BmaConstants.SHUBETSU_CODE_TWO))) {
                            length = 91;
                        }
                    } else {
                        if (sknksuCode.equals(BmaConstants.SKN_KSU_CODE_HC) && shubetsuCode.equals(BmaConstants.SHUBETSU_CODE_NEW)) {
                            length = 88;
                        } else if ((sknksuCode.equals(BmaConstants.SKN_KSU_CODE_HC) && shubetsuCode.equals(BmaConstants.SHUBETSU_CODE_SAIKSU))
                                || (sknksuCode.equals(BmaConstants.SKN_KSU_CODE_IP) && shubetsuCode.equals(BmaConstants.SHUBETSU_CODE_FOLLOW_UP))) {
                            length = 29;
                        } else if (sknksuCode.equals(BmaConstants.SKN_KSU_CODE_IP) && shubetsuCode.equals(BmaConstants.SHUBETSU_CODE_NEW)) {
                            length = 33;
                        }
                    }

                    if (rowCount < 6) {
                        // 1���ڂ̎��A�Z�b�V�����ɕۑ�
                        inSession.setSknKsuKbn(sknksuKbn);
                        inSession.setSknKsuCode(sknksuCode);
                        inSession.setShubetsuCode(shubetsuCode);
                        inSession.setKaisuCode(kaisuCode);
                        if (sknksuKbn.equals(BmaConstants.KSU_KBN)) {
                            // �u�K��̏ꍇ�A�g�p�����擾
                            kiboKaijoList = shiyoKaijo.searchKaijoList(inSession.getNendo(), inSession.getSknKsuCode(), inSession.getShubetsuCode(), inSession.getKaisuCode(), "0");
                            inSession.setShiyoKaijoKsuList(kiboKaijoList);
                        }
                    }
                    // ���ڐ��`�F�b�N
                    if (lineArray.length != length) {
                        BmaValidator.addMessage(errors, "info", BmaText.E00060, "info");
                        log.info("���ڐ��G���[�i" + rowCount + "�s�ځj");
                        inSession.setErrors(errors);
                        return ret;
                    }
                    // �t�@�C�����ڃ`�F�b�N
                    if (!inputCheck(lineArray, errors, inSession, inRequest, errorLog, rowCount - 4)) {
                        inSession.setErrors(errors);
                        rowCount++;
                    }else{
                        rowCount++;
                    }
                }
                // �G���[����̏ꍇ�A�I��
                if (errorLog.size() > 0 && !BmaConstants.FLG_ON.equals(inSession.getFuriganaOnlyErrFlg())) {
                    Boolean checkErr = false;
                    for (ErrorMsg errorMsg : errorLog) {
                        if (!"�t���K�i�s��v".equals(errorMsg.itemName)) {
                            inSession.setErrorLogFlg(BmaConstants.FLG_ON);
                            checkErr = true;
                            break;
                        }
                    }
                    if (!checkErr) {
                        inSession.setFuriganaOnlyErrFlg(BmaConstants.FLG_ON);
                    } else {
                        inSession.setFuriganaOnlyErrFlg(BmaConstants.FLG_OFF);
                        return false;
                    }
                }
                bufferedReader.close();
                bufferedReader = new BufferedReader(new InputStreamReader(fItem.getInputStream(), BmaConstants.ENCODE_WINDOWS_31J));

//                bufferedReader.reset();
                // CSV �o�^
                //�t�@�C���ŏI�s�܂ŌJ��Ԃ�
                while ((line = bufferedReader.readLine()) != null) {
                    String tempStr = line;

                    //�t�@�C�����e��String�z��ɕϊ�
                    if (tempStr.endsWith("\"")) {
                        tempStr = tempStr.replaceAll("^\"|\"$", "");
                        lineArray = tempStr.split("\",\"", -1);
                        tempStr = "";
                    } else {
                        lineArray = tempStr.split(",", -1);
                        tempStr = "";
                    }
                    // CSV�f�[�^��ۑ�����
                    MskUploadJoho torokuLine = new MskUploadJoho();
                    setCSVToSession(lineArray, torokuLine, inSession);
                    // �o�^�X�V��������
                    csvToroku(inRequest, inSession, torokuLine);
                    rowCount++;
                    uketsukeNos.add(torokuLine.getUketsukeNo());
                }
                if (!inSession.getErrors().isEmpty()) {
                    inSession.setErrors(errors);
                    return false;
                }
                inSession.setUketsukeNos(uketsukeNos.toArray(new String[uketsukeNos.size()]));
                ret = true;

                inSession.setErrors(errors);
                // ���O�o��
                log.info("��������" + String.valueOf(rowCount));
            } catch (IOException e) {
                log.error(CLASS_NAME + ".importFile()�ŗ�O����", e);
            } finally {
                if (bufferedReader != null) {
                    bufferedReader.close();
                }
            }
        }
        return ret;
    }

    /**
     * ���̓f�[�^���Z�b�V�����f�[�^�ɃZ�b�g����B
     *
     * @param inRequest ���N�G�X�g��̓��̓f�[�^
     * @param inSession �Z�b�V������̓��̓f�[�^
     */
    private void setValueRequestToSession(MskUploadJoho inRequest, MskUploadJoho inSession) {
        inSession.setMskFileChoice(inRequest.getMskFileChoice());
    }

    /**
     * CSV�f�[�^���Z�b�V�����f�[�^�ɃZ�b�g����B
     *
     * @param lineArray csv���̓f�[�^
     * @param torokuLine DB�o�^�p�f�[�^
     * @param inSession �Z�b�V������̓��̓f�[�^
     */
    private void setCSVToSession(String[] lineArray, MskUploadJoho torokuLine, MskUploadJoho inSession) {
        MoshikomiCommonService service = new MoshikomiCommonService(DATA_SOURCE_NAME);
        String nenrei = "";

         /*trim���s*/
        String shimei = BmaStringUtility.trimSpace2(lineArray[4]);
        String furigana = BmaStringUtility.trimSpace2(lineArray[5]);
         //�S�p�ϊ����s
        shimei = BmaStringUtility.convertHankakuToZenkakuBma(shimei);
        furigana = BmaStringUtility.convertHankakuToZenkakuBma(furigana);
        String jusho1 = BmaStringUtility.convertHankakuToZenkakuBma(lineArray[10]);
        String jusho2 = BmaStringUtility.convertHankakuToZenkakuBma(lineArray[11]);
        String tatemono = BmaStringUtility.convertHankakuToZenkakuBma(lineArray[12]);
        String kinmusakiJusho1 = BmaStringUtility.convertHankakuToZenkakuBma(lineArray[18]);
        String kinmusakiJusho2 = BmaStringUtility.convertHankakuToZenkakuBma(lineArray[19]);
        String kinmusakiTatemono = BmaStringUtility.convertHankakuToZenkakuBma(lineArray[20]);

        torokuLine.setSknKsuCode(lineArray[0]);
        torokuLine.setShubetsuCode(lineArray[1]);
        torokuLine.setKaisuCode(lineArray[2]);
        torokuLine.setNendo(lineArray[3]);
        torokuLine.setShimei(shimei);
        torokuLine.setFurigana(furigana);
        torokuLine.setBirthday(lineArray[6]);
        // �N��v�Z
        String birthday = lineArray[6];
        if (birthday.length() == 8) {
            try {
                nenrei = service.calcAge(lineArray[3], lineArray[0], lineArray[1], lineArray[2], inSession.getMoshikomishaId(), birthday);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        torokuLine.setNenrei(nenrei);
        torokuLine.setSex(lineArray[7]);
        torokuLine.setYubinNo(lineArray[8]);
        torokuLine.setTodofuken(lineArray[9]);
        torokuLine.setJusho1(jusho1);
        torokuLine.setJusho2(jusho2);
        torokuLine.setTatemono(tatemono);
        torokuLine.setTelNo(lineArray[13]);
        torokuLine.setFaxNo(lineArray[14]);
        torokuLine.setMailAddress(lineArray[15]);
        torokuLine.setKinmusakiYubinNo(lineArray[16]);
        torokuLine.setKinmusakiTodofuken(lineArray[17]);
        torokuLine.setKinmusakiJusho1(kinmusakiJusho1);
        torokuLine.setKinmusakiJusho2(kinmusakiJusho2);
        torokuLine.setKinmusakiTatemono(kinmusakiTatemono);
        torokuLine.setKinmusakiTelNo(lineArray[21]);
        torokuLine.setKinmusakiFaxNo(lineArray[22]);
        torokuLine.setSofuSakiKbn(lineArray[23]);
        if (inSession.getSknKsuKbn().equals(BmaConstants.SKN_KBN)) {
            torokuLine.setShikenNaiyoKbn(lineArray[24]);
            torokuLine.setKiboShikenchi(lineArray[25]);
            if (lineArray[0].equals(BmaConstants.SKN_KSU_CODE_BC) && lineArray[1].equals(BmaConstants.SHUBETSU_CODE_ONE)) {
                torokuLine.setGaijiFlg(lineArray[26]);
                torokuLine.setGaijiShosai(lineArray[27]);
                torokuLine.setJukenSkkCode(lineArray[28]);
                torokuLine.setJukenSkkNo(lineArray[29]);
                torokuLine.setKurenrekiName(lineArray[30]);
                torokuLine.setKurenrekiNaiyo(lineArray[31]);
                torokuLine.setKurenrekiShozaichi(lineArray[32]);
                torokuLine.setKurenrekiFrom(lineArray[33]);
                torokuLine.setKurenrekiTo(lineArray[34]);
                torokuLine.setKinmusakiKaishaName1(lineArray[35]);
                torokuLine.setBushoYakushokuName1(lineArray[36]);
                torokuLine.setShozaichi1(lineArray[37]);
                torokuLine.setShokumuNaiyo1(lineArray[38]);
                torokuLine.setZaisekikikanFrom1(lineArray[39]);
                torokuLine.setZaisekikikanTo1(lineArray[40]);
                torokuLine.setKinmusakiKaishaName2(lineArray[41]);
                torokuLine.setBushoYakushokuName2(lineArray[42]);
                torokuLine.setShozaichi2(lineArray[43]);
                torokuLine.setShokumuNaiyo2(lineArray[44]);
                torokuLine.setZaisekikikanFrom2(lineArray[45]);
                torokuLine.setZaisekikikanTo2(lineArray[46]);
                torokuLine.setKinmusakiKaishaName3(lineArray[47]);
                torokuLine.setBushoYakushokuName3(lineArray[48]);
                torokuLine.setShozaichi3(lineArray[49]);
                torokuLine.setShokumuNaiyo3(lineArray[50]);
                torokuLine.setZaisekikikanFrom3(lineArray[51]);
                torokuLine.setZaisekikikanTo3(lineArray[52]);
                torokuLine.setKinmusakiKaishaName4(lineArray[53]);
                torokuLine.setBushoYakushokuName4(lineArray[54]);
                torokuLine.setShozaichi4(lineArray[55]);
                torokuLine.setShokumuNaiyo4(lineArray[56]);
                torokuLine.setZaisekikikanFrom4(lineArray[57]);
                torokuLine.setZaisekikikanTo4(lineArray[58]);
                torokuLine.setKinmusakiKaishaName5(lineArray[59]);
                torokuLine.setBushoYakushokuName5(lineArray[60]);
                torokuLine.setShozaichi5(lineArray[61]);
                torokuLine.setShokumuNaiyo5(lineArray[62]);
                torokuLine.setZaisekikikanFrom5(lineArray[63]);
                torokuLine.setZaisekikikanTo5(lineArray[64]);
                torokuLine.setKinmusakiKaishaName6(lineArray[65]);
                torokuLine.setBushoYakushokuName6(lineArray[66]);
                torokuLine.setShozaichi6(lineArray[67]);
                torokuLine.setShokumuNaiyo6(lineArray[68]);
                torokuLine.setZaisekikikanFrom6(lineArray[69]);
                torokuLine.setZaisekikikanTo6(lineArray[70]);
                torokuLine.setKinmusakiKaishaName7(lineArray[71]);
                torokuLine.setBushoYakushokuName7(lineArray[72]);
                torokuLine.setShozaichi7(lineArray[73]);
                torokuLine.setShokumuNaiyo7(lineArray[74]);
                torokuLine.setZaisekikikanFrom7(lineArray[75]);
                torokuLine.setZaisekikikanTo7(lineArray[76]);
                torokuLine.setKinmusakiKaishaName8(lineArray[77]);
                torokuLine.setBushoYakushokuName8(lineArray[78]);
                torokuLine.setShozaichi8(lineArray[79]);
                torokuLine.setShokumuNaiyo8(lineArray[80]);
                torokuLine.setZaisekikikanFrom8(lineArray[81]);
                torokuLine.setZaisekikikanTo8(lineArray[82]);
                torokuLine.setKinmusakiKaishaName9(lineArray[83]);
                torokuLine.setBushoYakushokuName9(lineArray[84]);
                torokuLine.setShozaichi9(lineArray[85]);
                torokuLine.setShokumuNaiyo9(lineArray[86]);
                torokuLine.setZaisekikikanFrom9(lineArray[87]);
                torokuLine.setZaisekikikanTo9(lineArray[88]);
                torokuLine.setKinmusakiKaishaName10(lineArray[89]);
                torokuLine.setBushoYakushokuName10(lineArray[90]);
                torokuLine.setShozaichi10(lineArray[91]);
                torokuLine.setShokumuNaiyo10(lineArray[92]);
                torokuLine.setZaisekikikanFrom10(lineArray[93]);
                torokuLine.setZaisekikikanTo10(lineArray[94]);
                torokuLine.setMenjoSkkCode(lineArray[95]);
                torokuLine.setMenjoSkkNo(lineArray[96]);
            } else if (lineArray[0].equals(BmaConstants.SKN_KSU_CODE_BE) && lineArray[1].equals(BmaConstants.SHUBETSU_CODE_ONE)) {
                torokuLine.setGaijiFlg(lineArray[26]);
                torokuLine.setGaijiShosai(lineArray[27]);
                torokuLine.setJukenSkkCode(lineArray[28]);
                torokuLine.setJukenSkkNo(lineArray[29]);
                torokuLine.setGakurekiName(lineArray[30]);
                torokuLine.setGakurekiNaiyo(lineArray[31]);
                torokuLine.setGakurekiShozaichi(lineArray[32]);
                torokuLine.setGakurekiDate(lineArray[33]);
                torokuLine.setKurenrekiName(lineArray[34]);
                torokuLine.setKurenrekiNaiyo(lineArray[35]);
                torokuLine.setKurenrekiShozaichi(lineArray[36]);
                torokuLine.setKurenrekiFrom(lineArray[37]);
                torokuLine.setKurenrekiTo(lineArray[38]);
                torokuLine.setKinmusakiKaishaName1(lineArray[39]);
                torokuLine.setBushoYakushokuName1(lineArray[40]);
                torokuLine.setShozaichi1(lineArray[41]);
                torokuLine.setShokumuNaiyo1(lineArray[42]);
                torokuLine.setZaisekikikanFrom1(lineArray[43]);
                torokuLine.setZaisekikikanTo1(lineArray[44]);
                torokuLine.setKinmusakiKaishaName2(lineArray[45]);
                torokuLine.setBushoYakushokuName2(lineArray[46]);
                torokuLine.setShozaichi2(lineArray[47]);
                torokuLine.setShokumuNaiyo2(lineArray[48]);
                torokuLine.setZaisekikikanFrom2(lineArray[49]);
                torokuLine.setZaisekikikanTo2(lineArray[50]);
                torokuLine.setKinmusakiKaishaName3(lineArray[51]);
                torokuLine.setBushoYakushokuName3(lineArray[52]);
                torokuLine.setShozaichi3(lineArray[53]);
                torokuLine.setShokumuNaiyo3(lineArray[54]);
                torokuLine.setZaisekikikanFrom3(lineArray[55]);
                torokuLine.setZaisekikikanTo3(lineArray[56]);
                torokuLine.setKinmusakiKaishaName4(lineArray[57]);
                torokuLine.setBushoYakushokuName4(lineArray[58]);
                torokuLine.setShozaichi4(lineArray[59]);
                torokuLine.setShokumuNaiyo4(lineArray[60]);
                torokuLine.setZaisekikikanFrom4(lineArray[61]);
                torokuLine.setZaisekikikanTo4(lineArray[62]);
                torokuLine.setKinmusakiKaishaName5(lineArray[63]);
                torokuLine.setBushoYakushokuName5(lineArray[64]);
                torokuLine.setShozaichi5(lineArray[65]);
                torokuLine.setShokumuNaiyo5(lineArray[66]);
                torokuLine.setZaisekikikanFrom5(lineArray[67]);
                torokuLine.setZaisekikikanTo5(lineArray[68]);
                torokuLine.setKinmusakiKaishaName6(lineArray[69]);
                torokuLine.setBushoYakushokuName6(lineArray[70]);
                torokuLine.setShozaichi6(lineArray[71]);
                torokuLine.setShokumuNaiyo6(lineArray[72]);
                torokuLine.setZaisekikikanFrom6(lineArray[73]);
                torokuLine.setZaisekikikanTo6(lineArray[74]);
                torokuLine.setKinmusakiKaishaName7(lineArray[75]);
                torokuLine.setBushoYakushokuName7(lineArray[76]);
                torokuLine.setShozaichi7(lineArray[77]);
                torokuLine.setShokumuNaiyo7(lineArray[78]);
                torokuLine.setZaisekikikanFrom7(lineArray[79]);
                torokuLine.setZaisekikikanTo7(lineArray[80]);
                torokuLine.setKinmusakiKaishaName8(lineArray[81]);
                torokuLine.setBushoYakushokuName8(lineArray[82]);
                torokuLine.setShozaichi8(lineArray[83]);
                torokuLine.setShokumuNaiyo8(lineArray[84]);
                torokuLine.setZaisekikikanFrom8(lineArray[85]);
                torokuLine.setZaisekikikanTo8(lineArray[86]);
                torokuLine.setKinmusakiKaishaName9(lineArray[87]);
                torokuLine.setBushoYakushokuName9(lineArray[88]);
                torokuLine.setShozaichi9(lineArray[89]);
                torokuLine.setShokumuNaiyo9(lineArray[90]);
                torokuLine.setZaisekikikanFrom9(lineArray[91]);
                torokuLine.setZaisekikikanTo9(lineArray[92]);
                torokuLine.setKinmusakiKaishaName10(lineArray[93]);
                torokuLine.setBushoYakushokuName10(lineArray[94]);
                torokuLine.setShozaichi10(lineArray[95]);
                torokuLine.setShokumuNaiyo10(lineArray[96]);
                torokuLine.setZaisekikikanFrom10(lineArray[97]);
                torokuLine.setZaisekikikanTo10(lineArray[98]);
                torokuLine.setMenjoSkkCode(lineArray[99]);
                torokuLine.setMenjoSkkNo(lineArray[100]);
            } else if (lineArray[0].equals(BmaConstants.SKN_KSU_CODE_BC) && lineArray[1].equals(BmaConstants.SHUBETSU_CODE_TWO)) {
                torokuLine.setGenmenFlg(lineArray[26]);
                torokuLine.setGaijiFlg(lineArray[27]);
                torokuLine.setGaijiShosai(lineArray[28]);
                torokuLine.setJukenSkkCode(lineArray[29]);
                torokuLine.setJukenSkkNo(lineArray[30]);
                torokuLine.setKurenrekiName(lineArray[31]);
                torokuLine.setKurenrekiNaiyo(lineArray[32]);
                torokuLine.setKurenrekiShozaichi(lineArray[33]);
                torokuLine.setKurenrekiFrom(lineArray[34]);
                torokuLine.setKurenrekiTo(lineArray[35]);
                torokuLine.setKinmusakiKaishaName1(lineArray[36]);
                torokuLine.setBushoYakushokuName1(lineArray[37]);
                torokuLine.setShozaichi1(lineArray[38]);
                torokuLine.setShokumuNaiyo1(lineArray[39]);
                torokuLine.setZaisekikikanFrom1(lineArray[40]);
                torokuLine.setZaisekikikanTo1(lineArray[41]);
                torokuLine.setKinmusakiKaishaName2(lineArray[42]);
                torokuLine.setBushoYakushokuName2(lineArray[43]);
                torokuLine.setShozaichi2(lineArray[44]);
                torokuLine.setShokumuNaiyo2(lineArray[45]);
                torokuLine.setZaisekikikanFrom2(lineArray[46]);
                torokuLine.setZaisekikikanTo2(lineArray[47]);
                torokuLine.setKinmusakiKaishaName3(lineArray[48]);
                torokuLine.setBushoYakushokuName3(lineArray[49]);
                torokuLine.setShozaichi3(lineArray[50]);
                torokuLine.setShokumuNaiyo3(lineArray[51]);
                torokuLine.setZaisekikikanFrom3(lineArray[52]);
                torokuLine.setZaisekikikanTo3(lineArray[53]);
                torokuLine.setKinmusakiKaishaName4(lineArray[54]);
                torokuLine.setBushoYakushokuName4(lineArray[55]);
                torokuLine.setShozaichi4(lineArray[56]);
                torokuLine.setShokumuNaiyo4(lineArray[57]);
                torokuLine.setZaisekikikanFrom4(lineArray[58]);
                torokuLine.setZaisekikikanTo4(lineArray[59]);
                torokuLine.setKinmusakiKaishaName5(lineArray[60]);
                torokuLine.setBushoYakushokuName5(lineArray[61]);
                torokuLine.setShozaichi5(lineArray[62]);
                torokuLine.setShokumuNaiyo5(lineArray[63]);
                torokuLine.setZaisekikikanFrom5(lineArray[64]);
                torokuLine.setZaisekikikanTo5(lineArray[65]);
                torokuLine.setKinmusakiKaishaName6(lineArray[66]);
                torokuLine.setBushoYakushokuName6(lineArray[67]);
                torokuLine.setShozaichi6(lineArray[68]);
                torokuLine.setShokumuNaiyo6(lineArray[69]);
                torokuLine.setZaisekikikanFrom6(lineArray[70]);
                torokuLine.setZaisekikikanTo6(lineArray[71]);
                torokuLine.setKinmusakiKaishaName7(lineArray[72]);
                torokuLine.setBushoYakushokuName7(lineArray[73]);
                torokuLine.setShozaichi7(lineArray[74]);
                torokuLine.setShokumuNaiyo7(lineArray[75]);
                torokuLine.setZaisekikikanFrom7(lineArray[76]);
                torokuLine.setZaisekikikanTo7(lineArray[77]);
                torokuLine.setKinmusakiKaishaName8(lineArray[78]);
                torokuLine.setBushoYakushokuName8(lineArray[79]);
                torokuLine.setShozaichi8(lineArray[80]);
                torokuLine.setShokumuNaiyo8(lineArray[81]);
                torokuLine.setZaisekikikanFrom8(lineArray[82]);
                torokuLine.setZaisekikikanTo8(lineArray[83]);
                torokuLine.setKinmusakiKaishaName9(lineArray[84]);
                torokuLine.setBushoYakushokuName9(lineArray[85]);
                torokuLine.setShozaichi9(lineArray[86]);
                torokuLine.setShokumuNaiyo9(lineArray[87]);
                torokuLine.setZaisekikikanFrom9(lineArray[88]);
                torokuLine.setZaisekikikanTo9(lineArray[89]);
                torokuLine.setKinmusakiKaishaName10(lineArray[90]);
                torokuLine.setBushoYakushokuName10(lineArray[91]);
                torokuLine.setShozaichi10(lineArray[92]);
                torokuLine.setShokumuNaiyo10(lineArray[93]);
                torokuLine.setZaisekikikanFrom10(lineArray[94]);
                torokuLine.setZaisekikikanTo10(lineArray[95]);
                torokuLine.setMenjoSkkCode(lineArray[96]);
                torokuLine.setMenjoSkkNo(lineArray[97]);
            } else if ((lineArray[0].equals(BmaConstants.SKN_KSU_CODE_BC) && lineArray[1].equals(BmaConstants.SHUBETSU_CODE_THREE))
                    || (lineArray[0].equals(BmaConstants.SKN_KSU_CODE_BE) && lineArray[1].equals(BmaConstants.SHUBETSU_CODE_TWO))) {
                torokuLine.setGenmenFlg(lineArray[26]);
                torokuLine.setGaijiFlg(lineArray[27]);
                torokuLine.setGaijiShosai(lineArray[28]);
                torokuLine.setKinmusakiKaishaName1(lineArray[29]);
                torokuLine.setBushoYakushokuName1(lineArray[30]);
                torokuLine.setShozaichi1(lineArray[31]);
                torokuLine.setShokumuNaiyo1(lineArray[32]);
                torokuLine.setZaisekikikanFrom1(lineArray[33]);
                torokuLine.setZaisekikikanTo1(lineArray[34]);
                torokuLine.setKinmusakiKaishaName2(lineArray[35]);
                torokuLine.setBushoYakushokuName2(lineArray[36]);
                torokuLine.setShozaichi2(lineArray[37]);
                torokuLine.setShokumuNaiyo2(lineArray[38]);
                torokuLine.setZaisekikikanFrom2(lineArray[39]);
                torokuLine.setZaisekikikanTo2(lineArray[40]);
                torokuLine.setKinmusakiKaishaName3(lineArray[41]);
                torokuLine.setBushoYakushokuName3(lineArray[42]);
                torokuLine.setShozaichi3(lineArray[43]);
                torokuLine.setShokumuNaiyo3(lineArray[44]);
                torokuLine.setZaisekikikanFrom3(lineArray[45]);
                torokuLine.setZaisekikikanTo3(lineArray[46]);
                torokuLine.setKinmusakiKaishaName4(lineArray[47]);
                torokuLine.setBushoYakushokuName4(lineArray[48]);
                torokuLine.setShozaichi4(lineArray[49]);
                torokuLine.setShokumuNaiyo4(lineArray[50]);
                torokuLine.setZaisekikikanFrom4(lineArray[51]);
                torokuLine.setZaisekikikanTo4(lineArray[52]);
                torokuLine.setKinmusakiKaishaName5(lineArray[53]);
                torokuLine.setBushoYakushokuName5(lineArray[54]);
                torokuLine.setShozaichi5(lineArray[55]);
                torokuLine.setShokumuNaiyo5(lineArray[56]);
                torokuLine.setZaisekikikanFrom5(lineArray[57]);
                torokuLine.setZaisekikikanTo5(lineArray[58]);
                torokuLine.setKinmusakiKaishaName6(lineArray[59]);
                torokuLine.setBushoYakushokuName6(lineArray[60]);
                torokuLine.setShozaichi6(lineArray[61]);
                torokuLine.setShokumuNaiyo6(lineArray[62]);
                torokuLine.setZaisekikikanFrom6(lineArray[63]);
                torokuLine.setZaisekikikanTo6(lineArray[64]);
                torokuLine.setKinmusakiKaishaName7(lineArray[65]);
                torokuLine.setBushoYakushokuName7(lineArray[66]);
                torokuLine.setShozaichi7(lineArray[67]);
                torokuLine.setShokumuNaiyo7(lineArray[68]);
                torokuLine.setZaisekikikanFrom7(lineArray[69]);
                torokuLine.setZaisekikikanTo7(lineArray[70]);
                torokuLine.setKinmusakiKaishaName8(lineArray[71]);
                torokuLine.setBushoYakushokuName8(lineArray[72]);
                torokuLine.setShozaichi8(lineArray[73]);
                torokuLine.setShokumuNaiyo8(lineArray[74]);
                torokuLine.setZaisekikikanFrom8(lineArray[75]);
                torokuLine.setZaisekikikanTo8(lineArray[76]);
                torokuLine.setKinmusakiKaishaName9(lineArray[77]);
                torokuLine.setBushoYakushokuName9(lineArray[78]);
                torokuLine.setShozaichi9(lineArray[79]);
                torokuLine.setShokumuNaiyo9(lineArray[80]);
                torokuLine.setZaisekikikanFrom9(lineArray[81]);
                torokuLine.setZaisekikikanTo9(lineArray[82]);
                torokuLine.setKinmusakiKaishaName10(lineArray[83]);
                torokuLine.setBushoYakushokuName10(lineArray[84]);
                torokuLine.setShozaichi10(lineArray[85]);
                torokuLine.setShokumuNaiyo10(lineArray[86]);
                torokuLine.setZaisekikikanFrom10(lineArray[87]);
                torokuLine.setZaisekikikanTo10(lineArray[88]);
                torokuLine.setMenjoSkkCode(lineArray[89]);
                torokuLine.setMenjoSkkNo(lineArray[90]);
            }
        } else {
            torokuLine.setKaijoId1(lineArray[24]);
            torokuLine.setKaijoId2(lineArray[25]);
            torokuLine.setGaijiFlg(lineArray[26]);
            torokuLine.setGaijiShosai(lineArray[27]);
            if (lineArray[0].equals(BmaConstants.SKN_KSU_CODE_HC) && lineArray[1].equals(BmaConstants.SHUBETSU_CODE_NEW)) {
                torokuLine.setKinmusakiKaishaName1(lineArray[28]);
                torokuLine.setBushoYakushokuName1(lineArray[29]);
                torokuLine.setShozaichi1(lineArray[30]);
                torokuLine.setShokumuNaiyo1(lineArray[31]);
                torokuLine.setZaisekikikanFrom1(lineArray[32]);
                torokuLine.setZaisekikikanTo1(lineArray[33]);
                torokuLine.setKinmusakiKaishaName2(lineArray[34]);
                torokuLine.setBushoYakushokuName2(lineArray[35]);
                torokuLine.setShozaichi2(lineArray[36]);
                torokuLine.setShokumuNaiyo2(lineArray[37]);
                torokuLine.setZaisekikikanFrom2(lineArray[38]);
                torokuLine.setZaisekikikanTo2(lineArray[39]);
                torokuLine.setKinmusakiKaishaName3(lineArray[40]);
                torokuLine.setBushoYakushokuName3(lineArray[41]);
                torokuLine.setShozaichi3(lineArray[42]);
                torokuLine.setShokumuNaiyo3(lineArray[43]);
                torokuLine.setZaisekikikanFrom3(lineArray[44]);
                torokuLine.setZaisekikikanTo3(lineArray[45]);
                torokuLine.setKinmusakiKaishaName4(lineArray[46]);
                torokuLine.setBushoYakushokuName4(lineArray[47]);
                torokuLine.setShozaichi4(lineArray[48]);
                torokuLine.setShokumuNaiyo4(lineArray[49]);
                torokuLine.setZaisekikikanFrom4(lineArray[50]);
                torokuLine.setZaisekikikanTo4(lineArray[51]);
                torokuLine.setKinmusakiKaishaName5(lineArray[52]);
                torokuLine.setBushoYakushokuName5(lineArray[53]);
                torokuLine.setShozaichi5(lineArray[54]);
                torokuLine.setShokumuNaiyo5(lineArray[55]);
                torokuLine.setZaisekikikanFrom5(lineArray[56]);
                torokuLine.setZaisekikikanTo5(lineArray[57]);
                torokuLine.setKinmusakiKaishaName6(lineArray[58]);
                torokuLine.setBushoYakushokuName6(lineArray[59]);
                torokuLine.setShozaichi6(lineArray[60]);
                torokuLine.setShokumuNaiyo6(lineArray[61]);
                torokuLine.setZaisekikikanFrom6(lineArray[62]);
                torokuLine.setZaisekikikanTo6(lineArray[63]);
                torokuLine.setKinmusakiKaishaName7(lineArray[64]);
                torokuLine.setBushoYakushokuName7(lineArray[65]);
                torokuLine.setShozaichi7(lineArray[66]);
                torokuLine.setShokumuNaiyo7(lineArray[67]);
                torokuLine.setZaisekikikanFrom7(lineArray[68]);
                torokuLine.setZaisekikikanTo7(lineArray[69]);
                torokuLine.setKinmusakiKaishaName8(lineArray[70]);
                torokuLine.setBushoYakushokuName8(lineArray[71]);
                torokuLine.setShozaichi8(lineArray[72]);
                torokuLine.setShokumuNaiyo8(lineArray[73]);
                torokuLine.setZaisekikikanFrom8(lineArray[74]);
                torokuLine.setZaisekikikanTo8(lineArray[75]);
                torokuLine.setKinmusakiKaishaName9(lineArray[76]);
                torokuLine.setBushoYakushokuName9(lineArray[77]);
                torokuLine.setShozaichi9(lineArray[78]);
                torokuLine.setShokumuNaiyo9(lineArray[79]);
                torokuLine.setZaisekikikanFrom9(lineArray[80]);
                torokuLine.setZaisekikikanTo9(lineArray[81]);
                torokuLine.setKinmusakiKaishaName10(lineArray[82]);
                torokuLine.setBushoYakushokuName10(lineArray[83]);
                torokuLine.setShozaichi10(lineArray[84]);
                torokuLine.setShokumuNaiyo10(lineArray[85]);
                torokuLine.setZaisekikikanFrom10(lineArray[86]);
                torokuLine.setZaisekikikanTo10(lineArray[87]);
            } else if ((lineArray[0].equals(BmaConstants.SKN_KSU_CODE_HC) && lineArray[1].equals(BmaConstants.SHUBETSU_CODE_SAIKSU))
                    || (lineArray[0].equals(BmaConstants.SKN_KSU_CODE_IP) && lineArray[1].equals(BmaConstants.SHUBETSU_CODE_FOLLOW_UP))) {
                torokuLine.setShuryouSkkNo(lineArray[28]);
            } else if (lineArray[0].equals(BmaConstants.SKN_KSU_CODE_IP) && lineArray[1].equals(BmaConstants.SHUBETSU_CODE_NEW)) {
                torokuLine.setShikakuCode01(lineArray[28]);
                torokuLine.setShikakuCode02(lineArray[29]);
                torokuLine.setShikakuCode03(lineArray[30]);
                torokuLine.setShikakuCode04(lineArray[31]);
                torokuLine.setShikakuCode05(lineArray[32]);
            }
        }
        List<String> kinmusakiKaishaNameList = new ArrayList<>();
        kinmusakiKaishaNameList.add(torokuLine.getKinmusakiKaishaName1());
        kinmusakiKaishaNameList.add(torokuLine.getKinmusakiKaishaName2());
        kinmusakiKaishaNameList.add(torokuLine.getKinmusakiKaishaName3());
        kinmusakiKaishaNameList.add(torokuLine.getKinmusakiKaishaName4());
        kinmusakiKaishaNameList.add(torokuLine.getKinmusakiKaishaName5());
        kinmusakiKaishaNameList.add(torokuLine.getKinmusakiKaishaName6());
        kinmusakiKaishaNameList.add(torokuLine.getKinmusakiKaishaName7());
        kinmusakiKaishaNameList.add(torokuLine.getKinmusakiKaishaName8());
        kinmusakiKaishaNameList.add(torokuLine.getKinmusakiKaishaName9());
        kinmusakiKaishaNameList.add(torokuLine.getKinmusakiKaishaName10());
        torokuLine.setKinmusakiKaishaNameList(kinmusakiKaishaNameList);
    }

    /**
     * �����������̓`�F�b�N
     *
     * @param inSession �Z�b�V����RTO
     * @return true:�G���[��
     */
    private boolean validateSearchInput(MskUploadJoho inRequest, MskUploadJoho inSession) {
        Messages errors = new Messages();

        String itemName;
        String groupCode;

        groupCode = "info";
        itemName = "�t�@�C�� ";
        String fileName = inRequest.getMskFileChoice().getName();
        if (BmaUtility.isNullOrEmpty(fileName)) {
            BmaValidator.checkNull(errors, groupCode, itemName);
        }
        if (BmaValidator.validateMessageCheck(errors, groupCode)) {
            if (inRequest.getSknKsuKbn().equals(BmaConstants.SKN_KBN)) {
                // ���̃`�F�b�N
                if (!fileName.contains(inRequest.getSknKsuNameNosbt() + inRequest.getShubetsuName())) {
                    BmaValidator.addMessage(errors, groupCode, "�t�@�C�����̂��s���ł�");
                }
            } else {
                // ���̃`�F�b�N
                if (!fileName.contains(inRequest.getSknKsuNameNosbt().replace("�u�K", "") + "�i" + inRequest.getShubetsuName() + "�j")) {
                    BmaValidator.addMessage(errors, groupCode, "�t�@�C�����̂��s���ł�");
                }
            }
        }
        // �g���q�i�[�ϐ�
        String ext = BmaFileUtility.getExtension(fileName);
        if (!BmaUtility.isNullOrEmpty(ext) && !"csv".equals(ext)) {
            BmaValidator.addMessage(errors, groupCode, BmaText.E00070);
        }

        inSession.setErrors(errors);
        return errors.isEmpty();
    }

    /**
     * �t�@�C���̌`���`�F�b�N
     *
     * @param inSession
     * @return �`�F�b�N�n�j�̏ꍇ�Atrue
     */
    private boolean validateImportFile(MskUploadJoho inRequest, MskUploadJoho inSession) {
        Messages errors = new Messages();

        String itemName;
        String groupCode;
        Boolean result = false;

        groupCode = "info";
        itemName = "�t�@�C���T�C�Y";
        // �t�@�C���擾
        FileItem fItem = inRequest.getMskFileChoice();

        // 0���f�[�^�̏ꍇ�G���[
        if (fItem.getSize() == 0) {
            BmaValidator.checkFileSize(errors, groupCode, itemName);
            result = false;
        } else {
            result = BmaValidator.validateFileSize(fItem.getSize(), CSV_SIZE, errors, groupCode, groupCode);
        }

        if (!result) {
            log.info("�t�@�C���T�C�Y�G���[");
            inSession.setErrors(errors);
            fItem.delete();
        }
        return result;
    }

    /**
     * �t�@�C�����̐\���ԍ�������`�F�b�N����
     *
     * @param lineArray
     * @param errors
     * @return �`�F�b�N�n�j�̏ꍇ�Atrue
     */
    private boolean inputCheck(String[] lineArray, Messages errors, MskUploadJoho inSession, MskUploadJoho inRequest, List<ErrorMsg> errorLog, long lineNo) throws IOException {
        String groupCode = "fileInputCheck";

        MeishoKanri meishoKanri = new MeishoKanri(BmaConstants.DS_REGISTRANT);
        SknksuMst sknksuMst = new SknksuMst(BmaConstants.DS_REGISTRANT);
        ShiyoKaijo shiyoKaijo = new ShiyoKaijo(BmaConstants.DS_REGISTRANT);
        MoshikomiCommonService service = new MoshikomiCommonService(DATA_SOURCE_NAME);
        String nenrei = "0";

        // �E���E�P�����E�w���`�F�b�N�p
        String itemName;
        MskUploadJoho checkShokureki = new MskUploadJoho();
        List<MskUploadJoho> gokakugoShokurekiCheckList = new ArrayList<>();
        int yearCount = 0;
        int shokurekiMonths = 0;

        // �I���`�F�b�N
        List<Option> sknKsuList = new ArrayList<>();
        List<String> sknKsuCodeList = new ArrayList<>();
        List<String> shubetsuCodeList = new ArrayList<>();
        List<String> kaisuCodeList = new ArrayList<>();
        sknksuMst.findBySknKsuKbn(inRequest.getSknKsuKbn(), sknKsuList);
        for (int i = 0; i < sknKsuList.size(); i++) {
            sknKsuCodeList.add(sknKsuList.get(i).getValue().substring(0, 2));
            if (sknKsuList.get(i).getValue().substring(0, 2).equals(lineArray[0])) {
                shubetsuCodeList.add(sknKsuList.get(i).getValue().substring(2, 4));
                kaisuCodeList.add(sknKsuList.get(i).getValue().substring(4, 6));
            }
        }
        List<Option> todofukenList = new ArrayList<>();
        List<Option> shikennaiyoKbnList = new ArrayList<>();
        List<Option> kaisaichiList = new ArrayList<>();
        meishoKanri.findByGroupCode("TODOFUKEN_CODE", todofukenList);
        meishoKanri.findByGroupCode("SHIKEN_NAIYO_KBN", shikennaiyoKbnList);
        // �u�敪�Ȃ�"00"�v���Ȃ�
        shikennaiyoKbnList.remove(0);

        shiyoKaijo.setNendo(inSession.getNendo());
        shiyoKaijo.setSknKsuCode(inSession.getSknKsuCode());
        shiyoKaijo.setShubetsuCode(inSession.getShubetsuCode());
        shiyoKaijo.setKaisuCode(inSession.getKaisuCode());
        kaisaichiList = shiyoKaijo.findKiboKaisaichiList(shiyoKaijo);

        String[] sex = {"1", "2"};
        String[] sofukuFlg = {"1", "2"};
        String[] gaijiFlg = {"0", "1"};
        String[] genmenFlg = {"0", "1"};

         /*����������trim���s*/
        String shimei = BmaStringUtility.trimSpace2(lineArray[4]);
         /*�t���K�i��trim���s*/
        String furigana = BmaStringUtility.trimSpace2(lineArray[5]);
         //�S�p�ϊ����s
        shimei = BmaStringUtility.convertHankakuToZenkakuBma(shimei);
        furigana = BmaStringUtility.convertHankakuToZenkakuBma(furigana);
        String jusho1 = BmaStringUtility.convertHankakuToZenkakuBma(lineArray[10]);
        String jusho2 = BmaStringUtility.convertHankakuToZenkakuBma(lineArray[11]);
        String tatemono = BmaStringUtility.convertHankakuToZenkakuBma(lineArray[12]);
        String kinmusakiJusho1 = BmaStringUtility.convertHankakuToZenkakuBma(lineArray[18]);
        String kinmusakiJusho2 = BmaStringUtility.convertHankakuToZenkakuBma(lineArray[19]);
        String kinmusakiTatemono = BmaStringUtility.convertHankakuToZenkakuBma(lineArray[20]);
        
        // �����u�K��R�[�h
        // �K�v�`�F�b�N
        if (!BmaValidator.validateRequired(lineArray[0], errors, groupCode, "")) {
            this.createErrorLine(lineNo, 2, "�����u�K��R�[�h", errors, errorLog);
        } else {
            // �����`�F�b�N
            if (!BmaValidator.validateEqualLength(lineArray[0], 2, errors, groupCode, "")) {
                this.createErrorLine(lineNo, 2, "�����u�K��R�[�h", errors, errorLog);
            }
            // �I���`�F�b�N
            if (!sknKsuCodeList.contains(lineArray[0])) {
                BmaValidator.addMessage(errors, groupCode, BmaText.E00118, "");
                this.createErrorLine(lineNo, 2, "�����u�K��R�[�h", errors, errorLog);
            }
        }
        // ��ʃR�[�h
        // �K�v�`�F�b�N
        if (!BmaValidator.validateRequired(lineArray[1], errors, groupCode, "")) {
            this.createErrorLine(lineNo, 3, "��ʃR�[�h", errors, errorLog);
        } else {
            // �����`�F�b�N
            if (!BmaValidator.validateEqualLength(lineArray[1], 2, errors, groupCode, "")) {
                this.createErrorLine(lineNo, 3, "��ʃR�[�h", errors, errorLog);
            }
            // �����R�[�h�`�F�b�N
            if (!BmaValidator.validateNumber(lineArray[1], errors, groupCode, "")) {
                this.createErrorLine(lineNo, 3, "��ʃR�[�h", errors, errorLog);
            }
            // �I���`�F�b�N
            if (!shubetsuCodeList.contains(lineArray[1])) {
                BmaValidator.addMessage(errors, groupCode, BmaText.E00118, "");
                this.createErrorLine(lineNo, 3, "��ʃR�[�h", errors, errorLog);
            }
        }
        // �񐔃R�[�h
        // �K�v�`�F�b�N
        if (!BmaValidator.validateRequired(lineArray[2], errors, groupCode, "")) {
            this.createErrorLine(lineNo, 4, "�񐔃R�[�h", errors, errorLog);
        } else {
            // �����`�F�b�N
            if (!BmaValidator.validateEqualLength(lineArray[2], 2, errors, groupCode, "")) {
                this.createErrorLine(lineNo, 4, "�񐔃R�[�h", errors, errorLog);
            }
            // �����R�[�h�`�F�b�N
            if (!BmaValidator.validateNumber(lineArray[2], errors, groupCode, "")) {
                this.createErrorLine(lineNo, 4, "�񐔃R�[�h", errors, errorLog);
            }
            if (!kaisuCodeList.contains(lineArray[2])) {
                BmaValidator.addMessage(errors, groupCode, BmaText.E00118, "");
                this.createErrorLine(lineNo, 4, "�񐔃R�[�h", errors, errorLog);
            }
        }
        // �N�x
        // �K�v�`�F�b�N
        if (!BmaValidator.validateRequired(lineArray[3], errors, groupCode, "")) {
            this.createErrorLine(lineNo, 5, "�N�x", errors, errorLog);
        } else {
            // �����`�F�b�N
            if (!BmaValidator.validateEqualLength(lineArray[3], 4, errors, groupCode, "")) {
                this.createErrorLine(lineNo, 5, "�N�x", errors, errorLog);
            }
            // �����R�[�h�`�F�b�N
            if (!BmaValidator.validateNumber(lineArray[3], errors, groupCode, "")) {
                this.createErrorLine(lineNo, 5, "�N�x", errors, errorLog);
            }
            if (!lineArray[3].equals(inSession.getNendo())) {
                BmaValidator.addMessage(errors, groupCode, BmaText.E00119, "");
                this.createErrorLine(lineNo, 5, "�N�x", errors, errorLog);
            }
        }

        // ����
        // �K�v�`�F�b�N
        if (!BmaValidator.validateRequired(shimei, errors, groupCode, "")) {
            this.createErrorLine(lineNo, 6, "����", errors, errorLog);
        } else {
            // �����`�F�b�N
            if (!BmaValidator.validateMaxLength(shimei, BmaConstants.MAX_LENGTH_SHIMEI_KANJI, errors, groupCode, "")) {
                this.createErrorLine(lineNo, 6, "����", errors, errorLog);
            }
            // �����R�[�h�`�F�b�N
            if (!BmaValidator.validateMojiCode3(shimei, errors, groupCode, "")) {
                this.createErrorLine(lineNo, 6, "����", errors, errorLog);
            }
        }
        // �t���K�i
        // �K�v�`�F�b�N
        if (!BmaValidator.validateRequired(furigana, errors, groupCode, "")) {
            this.createErrorLine(lineNo, 7, "�t���K�i", errors, errorLog);
        } else {
            // �����`�F�b�N
            if (!BmaValidator.validateMaxLength(furigana, BmaConstants.MAX_LENGTH_SHIMEI_KANA, errors, groupCode, "")) {
                this.createErrorLine(lineNo, 7, "�t���K�i", errors, errorLog);
            }
            // �����R�[�h�`�F�b�N
            if (!BmaValidator.isKatakanaOrZenNumOrZenAlpha(furigana, errors, groupCode, "")) {
                this.createErrorLine(lineNo, 7, "�t���K�i", errors, errorLog);
            }
        }
        // ���N����
        // �K�v�`�F�b�N
        if (!BmaValidator.validateRequired(lineArray[6], errors, groupCode, "")) {
            this.createErrorLine(lineNo, 8, "���N����", errors, errorLog);
        } else {
            // �����`�F�b�N
            if (!BmaValidator.validateEqualLength(lineArray[6], 8, errors, groupCode, "")) {
                this.createErrorLine(lineNo, 8, "���N����", errors, errorLog);
            }
            // �����R�[�h�`�F�b�N
            if (!BmaValidator.validateNumber(lineArray[6], errors, groupCode, "")) {
                this.createErrorLine(lineNo, 8, "���N����", errors, errorLog);
            }
            // �N���`�F�b�N
            if (!BmaValidator.validateDate(lineArray[6], errors, groupCode, "")) {
                this.createErrorLine(lineNo, 8, "���N����", errors, errorLog);
            }
        }

        // ����
        // �K�v�`�F�b�N
        if (!BmaValidator.validateRequired(lineArray[7], errors, groupCode, "")) {
            this.createErrorLine(lineNo, 9, "����", errors, errorLog);
        } else {
            // �I���`�F�b�N
            if (!Arrays.asList(sex).contains(lineArray[7])) {
                BmaValidator.addMessage(errors, groupCode, BmaText.E00106, "");
                this.createErrorLine(lineNo, 9, "����", errors, errorLog);
            }
        }
        // ����Z���@�X�֔ԍ�
        // �K�v�`�F�b�N
        if (!BmaValidator.validateRequired(lineArray[8], errors, groupCode, "")) {
            this.createErrorLine(lineNo, 11, "����Z���@�X�֔ԍ�", errors, errorLog);
        } else {
            // �����`�F�b�N
            if (!BmaValidator.validateEqualLength(lineArray[8], BmaConstants.EQUAL_LENGTH_YUBIN_NO, errors, groupCode, "")) {
                this.createErrorLine(lineNo, 11, "����Z���@�X�֔ԍ�", errors, errorLog);
            }
            // ���l�`�F�b�N
            if (!BmaValidator.validateNumber(lineArray[8], errors, groupCode, "")) {
                this.createErrorLine(lineNo, 11, "����Z���@�X�֔ԍ�", errors, errorLog);
            }
        }
        // ����Z���@�s���{��
        // �K�v�`�F�b�N
        if (!BmaValidator.validateRequired(lineArray[9], errors, groupCode, "")) {
            this.createErrorLine(lineNo, 12, "����Z���@�s���{��", errors, errorLog);
        } else {
            // �I���`�F�b�N
            if (!BmaValidator.validatePermissionSelect(lineArray[9], todofukenList, errors, groupCode, "")) {
                this.createErrorLine(lineNo, 12, "����Z���@�s���{��", errors, errorLog);
            }
        }
        // ����Z���@�Z���P
        // �K�v�`�F�b�N
        if (!BmaValidator.validateRequired(jusho1, errors, groupCode, "")) {
            this.createErrorLine(lineNo, 14, "����Z���@�Z���P", errors, errorLog);
        } else {
            // �����`�F�b�N
            if (!BmaValidator.validateMaxLength(jusho1, BmaConstants.MAX_LENGTH_SHIKUCHOSON_NAME, errors, groupCode, "")) {
                this.createErrorLine(lineNo, 14, "����Z���@�Z���P", errors, errorLog);
            }
            // �����R�[�h�`�F�b�N
            if (!BmaValidator.validateMojiCode3(jusho1, errors, groupCode, "")) {
                this.createErrorLine(lineNo, 14, "����Z���@�Z���P", errors, errorLog);
            }
        }
        // ����Z���@�Z��2
        // �K�v�`�F�b�N
        if (!BmaValidator.validateRequired(jusho2, errors, groupCode, "")) {
            this.createErrorLine(lineNo, 15, "����Z���@�Z��2", errors, errorLog);
        } else {
            // �����`�F�b�N
            if (!BmaValidator.validateMaxLength(jusho2, BmaConstants.MAX_LENGTH_SHIKUCHOSON_NAME, errors, groupCode, "")) {
                this.createErrorLine(lineNo, 15, "����Z���@�Z��2", errors, errorLog);
            }
            // �����R�[�h�`�F�b�N
            if (!BmaValidator.validateMojiCode3(jusho2, errors, groupCode, "")) {
                this.createErrorLine(lineNo, 15, "����Z���@�Z��2", errors, errorLog);
            }
        }
        // ����Z���@�����E�r����
        // �����`�F�b�N
        if (!BmaValidator.validateMaxLength(tatemono, BmaConstants.MAX_LENGTH_SHIKUCHOSON_NAME, errors, groupCode, "")) {
            this.createErrorLine(lineNo, 16, "����Z���@�����E�r����", errors, errorLog);
        }
        // �����R�[�h�`�F�b�N
        if (!BmaValidator.validateMojiCode3(tatemono, errors, groupCode, "")) {
            this.createErrorLine(lineNo, 16, "����Z�� �����E�r����", errors, errorLog);
        }
        // �d�b�ԍ�
        // �K�v�`�F�b�N
        if (!BmaValidator.validateRequired(lineArray[13], errors, groupCode, "")) {
            this.createErrorLine(lineNo, 17, "����Z���@�d�b�ԍ�", errors, errorLog);
        } else {
            // �����`�F�b�N
            if (!BmaValidator.validateMaxLength(lineArray[13], BmaConstants.MAX_LENGTH_TEL_NO, errors, groupCode, "")) {
                this.createErrorLine(lineNo, 17, "����Z���@�d�b�ԍ�", errors, errorLog);
            }
            if (!BmaValidator.validateMinLength(lineArray[13], BmaConstants.MIN_LENGTH_TEL_NO, errors, groupCode, "")) {
                this.createErrorLine(lineNo, 17, "����Z���@�d�b�ԍ�", errors, errorLog);
            }
            // �����R�[�h�`�F�b�N
            if (!BmaValidator.validateNumber(lineArray[13], errors, groupCode, "")) {
                this.createErrorLine(lineNo, 17, "����Z���@�d�b�ԍ�", errors, errorLog);
            }
        }
        // FAX�ԍ�
        // �����`�F�b�N
        if (!BmaValidator.validateMaxLength(lineArray[14], BmaConstants.MAX_LENGTH_FAX_NO, errors, groupCode, "")) {
            this.createErrorLine(lineNo, 18, "����Z���@FAX�ԍ�", errors, errorLog);
        }
        if (!BmaValidator.validateMinLength(lineArray[14], BmaConstants.MIN_LENGTH_FAX_NO, errors, groupCode, "")) {
            this.createErrorLine(lineNo, 18, "����Z���@FAX�ԍ�", errors, errorLog);
        }
        // �����R�[�h�`�F�b�N
        if (!BmaValidator.validateNumber(lineArray[14], errors, groupCode, "")) {
            this.createErrorLine(lineNo, 18, "����Z���@FAX�ԍ�", errors, errorLog);
        }
        // ���[���A�h���X
        // �����`�F�b�N
        if (!BmaValidator.validateMaxLength(lineArray[15], BmaConstants.MAX_LENGTH_MAILADDRESS, errors, groupCode, "")) {
            this.createErrorLine(lineNo, 19, "���[���A�h���X", errors, errorLog);
        }
        // ���[���`���`�F�b�N
        if (!Validator.validateEmail(lineArray[15], errors, groupCode, "")) {
            this.createErrorLine(lineNo, 19, "���[���A�h���X", errors, errorLog);
        }
        //�Ζ����� 1�ł����͂�����ꍇ�A�G���[�`�F�b�N
        if (!BmaUtility.isNullOrEmpty(lineArray[16]) || !BmaUtility.isNullOrEmpty(lineArray[17]) || !BmaUtility.isNullOrEmpty(lineArray[18])
                || !BmaUtility.isNullOrEmpty(lineArray[19]) || !BmaUtility.isNullOrEmpty(lineArray[20])
                || !BmaUtility.isNullOrEmpty(lineArray[21]) || !BmaUtility.isNullOrEmpty(lineArray[22])) {
            // �Ζ���@�X�֔ԍ�
            // �K�v�`�F�b�N
            if (!BmaValidator.validateRequired(lineArray[16], errors, groupCode, "")) {
                this.createErrorLine(lineNo, 20, "�Ζ���@�X�֔ԍ�", errors, errorLog);
            } else {
                // �����`�F�b�N
                if (!BmaValidator.validateEqualLength(lineArray[16], BmaConstants.EQUAL_LENGTH_YUBIN_NO, errors, groupCode, "")) {
                    this.createErrorLine(lineNo, 20, "�Ζ���@�X�֔ԍ�", errors, errorLog);
                }
                // ���l�`�F�b�N
                if (!BmaValidator.validateNumber(lineArray[16], errors, groupCode, "")) {
                    this.createErrorLine(lineNo, 20, "�Ζ���@�X�֔ԍ�", errors, errorLog);
                }
            }
            // �Ζ���@�s���{��
            // �K�v�`�F�b�N
            if (!BmaValidator.validateRequired(lineArray[17], errors, groupCode, "")) {
                this.createErrorLine(lineNo, 21, "�Ζ���@�s���{��", errors, errorLog);
            } else {
                // �I���`�F�b�N
                if (!BmaValidator.validatePermissionSelect(lineArray[17], todofukenList, errors, groupCode, "")) {
                    this.createErrorLine(lineNo, 21, "�Ζ���@�s���{��", errors, errorLog);
                }
            }
            // �Ζ���@�Z���P
            // �K�v�`�F�b�N
            if (!BmaValidator.validateRequired(kinmusakiJusho1, errors, groupCode, "")) {
                this.createErrorLine(lineNo, 23, "�Ζ���@�Z���P", errors, errorLog);
            } else {
                // �����`�F�b�N
                if (!BmaValidator.validateMaxLength(kinmusakiJusho1, BmaConstants.MAX_LENGTH_SHIKUCHOSON_NAME, errors, groupCode, "")) {
                    this.createErrorLine(lineNo, 23, "�Ζ���@�Z���P", errors, errorLog);
                }
                // �����R�[�h�`�F�b�N
                if (!BmaValidator.validateMojiCode3(kinmusakiJusho1, errors, groupCode, "")) {
                    this.createErrorLine(lineNo, 23, "�Ζ���@�Z���P", errors, errorLog);
                }
            }
            // �Ζ���@�Z���Q
            // �K�v�`�F�b�N
            if (!BmaValidator.validateRequired(kinmusakiJusho2, errors, groupCode, "")) {
                this.createErrorLine(lineNo, 24, "�Ζ���@�Z���Q", errors, errorLog);
            } else {
                // �����`�F�b�N
                if (!BmaValidator.validateMaxLength(kinmusakiJusho2, BmaConstants.MAX_LENGTH_SHIKUCHOSON_NAME, errors, groupCode, "")) {
                    this.createErrorLine(lineNo, 24, "�Ζ���@�Z���Q", errors, errorLog);
                }
                // �����R�[�h�`�F�b�N
                if (!BmaValidator.validateMojiCode3(kinmusakiJusho2, errors, groupCode, "")) {
                    this.createErrorLine(lineNo, 24, "�Ζ���@�Z���Q", errors, errorLog);
                }
            }
            // �Ζ���@�����E�r����
            // �����`�F�b�N
            if (!BmaValidator.validateMaxLength(kinmusakiTatemono, BmaConstants.MAX_LENGTH_SHIKUCHOSON_NAME, errors, groupCode, "")) {
                this.createErrorLine(lineNo, 25, "�Ζ���@�����E�r����", errors, errorLog);
            }
            // �����R�[�h�`�F�b�N
            if (!BmaValidator.validateMojiCode3(kinmusakiTatemono, errors, groupCode, "")) {
                this.createErrorLine(lineNo, 25, "�Ζ���@�����E�r����", errors, errorLog);
            }
            // �d�b�ԍ�
            // �K�v�`�F�b�N
            if (!BmaValidator.validateRequired(lineArray[21], errors, groupCode, "")) {
                this.createErrorLine(lineNo, 26, "�Ζ���@�d�b�ԍ�", errors, errorLog);
            } else {
                // �����`�F�b�N
                if (!BmaValidator.validateMaxLength(lineArray[21], BmaConstants.MAX_LENGTH_TEL_NO, errors, groupCode, "")) {
                    this.createErrorLine(lineNo, 26, "�Ζ���@�d�b�ԍ�", errors, errorLog);
                }
                if (!BmaValidator.validateMinLength(lineArray[21], BmaConstants.MIN_LENGTH_TEL_NO, errors, groupCode, "")) {
                    this.createErrorLine(lineNo, 26, "�Ζ���@�d�b�ԍ�", errors, errorLog);
                }
                // �����R�[�h�`�F�b�N
                if (!BmaValidator.validateNumber(lineArray[21], errors, groupCode, "")) {
                    this.createErrorLine(lineNo, 26, "�Ζ���@�d�b�ԍ�", errors, errorLog);
                }
            }
            // FAX�ԍ�
            // �����`�F�b�N
            if (!BmaValidator.validateMaxLength(lineArray[22], BmaConstants.MAX_LENGTH_FAX_NO, errors, groupCode, "")) {
                this.createErrorLine(lineNo, 27, "�Ζ���@FAX�ԍ�", errors, errorLog);
            }
            if (!BmaValidator.validateMinLength(lineArray[22], BmaConstants.MIN_LENGTH_FAX_NO, errors, groupCode, "")) {
                this.createErrorLine(lineNo, 27, "�Ζ���@FAX�ԍ�", errors, errorLog);
            }
            // �����R�[�h�`�F�b�N
            if (!BmaValidator.validateNumber(lineArray[22], errors, groupCode, "")) {
                this.createErrorLine(lineNo, 27, "�Ζ���@FAX�ԍ�", errors, errorLog);
            }
        }
        // ���t��敪
        // �K�v�`�F�b�N
        if (!BmaValidator.validateRequired(lineArray[23], errors, groupCode, "")) {
            this.createErrorLine(lineNo, 28, "���t��敪", errors, errorLog);
        } else {
            // �I���`�F�b�N
            if (!BmaConstants.SKN_KSU_CODE_BC.equals(lineArray[0]) && !BmaConstants.SKN_KSU_CODE_BE.equals(lineArray[0])) {
                if (!Arrays.asList(sofukuFlg).contains(lineArray[23])) {
                    BmaValidator.addMessage(errors, groupCode, BmaText.E00106, "");
                    this.createErrorLine(lineNo, 28, "���t��敪", errors, errorLog);
                }
            } else {
                if (!"1".equals(lineArray[23])) {
                    BmaValidator.addMessage(errors, groupCode, BmaText.E00106, "");
                    this.createErrorLine(lineNo, 28, "���t��敪", errors, errorLog);
                }
            }
            // ���t��Ɂu�Ζ���v��I�����Ă���ꍇ�A�Ζ���X�֔ԍ��̓��͂��Ȃ���΃G���[�i�u�K��j
            if ("2".equals(lineArray[23]) && BmaUtility.isNullOrEmpty(lineArray[16])) {
                BmaValidator.addMessage(errors, groupCode, BmaText.E00080);
                this.createErrorLine(lineNo, 28, "���t��敪", errors, errorLog);
            }
        }
        if (BmaConstants.SKN_KBN.equals(inSession.getSknKsuKbn())) {
            // �������e�敪
            // �K�v�`�F�b�N
            if (!BmaValidator.validateRequired(lineArray[24], errors, groupCode, "")) {
                this.createErrorLine(lineNo, 30, "�������e�敪", errors, errorLog);
            } else {
                // �����`�F�b�N
                if (!BmaValidator.validateEqualLength(lineArray[24], 2, errors, groupCode, "")) {
                    this.createErrorLine(lineNo, 30, "�������e�敪", errors, errorLog);
                }
                // �I���`�F�b�N
                if (!BmaValidator.validatePermissionSelect(lineArray[24], shikennaiyoKbnList, errors, groupCode, "")) {
                    this.createErrorLine(lineNo, 30, "�������e�敪", errors, errorLog);
                }
            }

            // ��]�����n
            // �K�v�`�F�b�N
            if (!BmaValidator.validateRequired(lineArray[25], errors, groupCode, "")) {
                this.createErrorLine(lineNo, 32, "��]�����n", errors, errorLog);
            } else {
                // �����`�F�b�N
                if (!BmaValidator.validateEqualLength(lineArray[25], 2, errors, groupCode, "")) {
                    this.createErrorLine(lineNo, 32, "��]�����n", errors, errorLog);
                }
                // �I���`�F�b�N
                if (!BmaValidator.validatePermissionSelect(lineArray[25], kaisaichiList, errors, groupCode, "")) {
                    this.createErrorLine(lineNo, 32, "��]�����n", errors, errorLog);
                }
            }

            if (BmaConstants.SKN_KSU_CODE_BC.equals(lineArray[0]) && BmaConstants.SHUBETSU_CODE_ONE.equals(lineArray[1])) {
                // �O���t���O
                // �K�v�`�F�b�N
                if (!BmaValidator.validateRequired(lineArray[26], errors, groupCode, "")) {
                    this.createErrorLine(lineNo, 34, "�O���t���O", errors, errorLog);
                } else {
                    // �I���`�F�b�N
                    if (!Arrays.asList(gaijiFlg).contains(lineArray[26])) {
                        BmaValidator.addMessage(errors, groupCode, BmaText.E00106, "");
                        this.createErrorLine(lineNo, 34, "�O���t���O", errors, errorLog);
                    }
                }
                // �O���ڍ�
                // �����`�F�b�N
                if (!BmaValidator.validateMaxLength(lineArray[27], 200, errors, groupCode, "")) {
                    this.createErrorLine(lineNo, 36, "�O���ڍ�", errors, errorLog);
                }
                // ������`�F�b�N
                if (!BmaValidator.validateMojiCodeForBiko(lineArray[27], errors, groupCode, "")) {
                    this.createErrorLine(lineNo, 36, "�O���ڍ�", errors, errorLog);
                }

                // �󌟎��i�R�[�h
                // �K�v�`�F�b�N
                if (!BmaValidator.validateRequired(lineArray[28], errors, groupCode, "")) {
                    this.createErrorLine(lineNo, 37, "�󌟎��i�R�[�h", errors, errorLog);
                } else {
                    String[] bc1SkkCode1 = {BmaConstants.SKK_CODE_01, BmaConstants.SKK_CODE_02,
                        BmaConstants.SKK_CODE_03, BmaConstants.SKK_CODE_04, BmaConstants.SKK_CODE_05};
                    // �I���`�F�b�N
                    if (!Arrays.asList(bc1SkkCode1).contains(lineArray[28])) {
                        BmaValidator.addMessage(errors, groupCode, BmaText.E00106, "");
                        this.createErrorLine(lineNo, 37, "�󌟎��i�R�[�h", errors, errorLog);
                    }
                    if (BmaConstants.SKK_CODE_02.equals(lineArray[28]) || lineArray[28].equals(BmaConstants.SKK_CODE_03)) {
                        // �󌟎��i�ԍ�
                        // �K�v�`�F�b�N
                        if (!BmaValidator.validateRequired(lineArray[29], errors, groupCode, "")) {
                            this.createErrorLine(lineNo, 39, "�󌟎��i�ԍ�", errors, errorLog);
                        } else {
                            // �����`�F�b�N
                            if (!BmaValidator.validateMaxLength(lineArray[29], 20, errors, groupCode, "")) {
                                this.createErrorLine(lineNo, 39, "�󌟎��i�ԍ�", errors, errorLog);
                            }
                            // �ԍ��`�F�b�N
                            if (BmaConstants.SKK_CODE_02.equals(lineArray[28])) {
                                validateInputShikaku(BmaConstants.SKN_KSU_CODE_BC, BmaConstants.SHUBETSU_CODE_TWO, lineArray[29], groupCode, lineNo, 39, errorLog, errors);
                            } else if (BmaConstants.SKK_CODE_03.equals(lineArray[28])) {
                                validateInputShikaku(BmaConstants.SKN_KSU_CODE_BC, BmaConstants.SHUBETSU_CODE_THREE, lineArray[29], groupCode, lineNo, 39, errorLog, errors);
                            }

                            List<String> jukenSkkNoList = inSession.getJukenSkkNoList();
                            // �_�u��`�F�b�N
                            if (jukenSkkNoList.contains(lineArray[29])) {
                                BmaValidator.addMessage(errors, groupCode, BmaText.E00101, "");
                                this.createErrorLine(lineNo, 39, "�󌟎��i�ԍ�", errors, errorLog);
                            }
                            jukenSkkNoList.add(lineArray[29]);
                            inSession.setJukenSkkNoList(jukenSkkNoList);
                        }
                    }
                }
                if (!BmaUtility.isNullOrEmpty(lineArray[28]) && !BmaConstants.SKK_CODE_04.equals(lineArray[28])) {
                    // �P����
                    if (BmaConstants.SKK_CODE_05.equals(lineArray[28])) {
                        checkShokureki = new MskUploadJoho();
                        checkShokureki.setSknKsuCode(lineArray[0]);
                        checkShokureki.setKurenrekiName(lineArray[30]);
                        checkShokureki.setKurenrekiNaiyo(lineArray[31]);
                        checkShokureki.setKurenrekiShozaichi(lineArray[32]);
                        checkShokureki.setKurenrekiFrom(lineArray[33]);
                        checkShokureki.setKurenrekiTo(lineArray[34]);
                        validateInputKunrenreki(checkShokureki, groupCode, lineNo, 40, errorLog, errors);
                    }

                    // �E��
                    if (lineArray[35].isEmpty()
                            && lineArray[41].isEmpty()
                            && lineArray[47].isEmpty()
                            && lineArray[53].isEmpty()
                            && lineArray[59].isEmpty()
                            && lineArray[65].isEmpty()
                            && lineArray[71].isEmpty()
                            && lineArray[77].isEmpty()
                            && lineArray[83].isEmpty()
                            && lineArray[89].isEmpty()) {
                        BmaValidator.addMessage(errors, groupCode, BmaText.E00015, "");
                        this.createErrorLine(lineNo, 45, "�E���P�i�Ζ���Ћy�ю��Ə��j", errors, errorLog);
                    } else {
                        if (!lineArray[35].isEmpty()) {
                            // �E���P
                            checkShokureki = new MskUploadJoho();
                            checkShokureki.setSknKsuCode(lineArray[0]);
                            checkShokureki.setKinmusakiKaishaName1(lineArray[35]);
                            checkShokureki.setBushoYakushokuName1(lineArray[36]);
                            checkShokureki.setShozaichi1(lineArray[37]);
                            checkShokureki.setShokumuNaiyo1(lineArray[38]);
                            checkShokureki.setZaisekikikanFrom1(lineArray[39]);
                            checkShokureki.setZaisekikikanTo1(lineArray[40]);

                            itemName = "�E���P";
                            shokurekiMonths += validateInputShokureki(checkShokureki, itemName, lineNo, 45, errorLog, errors);
                            gokakugoShokurekiCheckList.add(checkShokureki);
                        }
                        if (!lineArray[41].isEmpty()) {
                            // �E���Q
                            checkShokureki = new MskUploadJoho();
                            checkShokureki.setSknKsuCode(lineArray[0]);
                            checkShokureki.setKinmusakiKaishaName1(lineArray[41]);
                            checkShokureki.setBushoYakushokuName1(lineArray[42]);
                            checkShokureki.setShozaichi1(lineArray[43]);
                            checkShokureki.setShokumuNaiyo1(lineArray[44]);
                            checkShokureki.setZaisekikikanFrom1(lineArray[45]);
                            checkShokureki.setZaisekikikanTo1(lineArray[46]);

                            itemName = "�E���Q";
                            shokurekiMonths += validateInputShokureki(checkShokureki, itemName, lineNo, 52, errorLog, errors);
                            gokakugoShokurekiCheckList.add(checkShokureki);
                        }
                        if (!lineArray[47].isEmpty()) {
                            // �E���R
                            checkShokureki = new MskUploadJoho();
                            checkShokureki.setSknKsuCode(lineArray[0]);
                            checkShokureki.setKinmusakiKaishaName1(lineArray[47]);
                            checkShokureki.setBushoYakushokuName1(lineArray[48]);
                            checkShokureki.setShozaichi1(lineArray[49]);
                            checkShokureki.setShokumuNaiyo1(lineArray[50]);
                            checkShokureki.setZaisekikikanFrom1(lineArray[51]);
                            checkShokureki.setZaisekikikanTo1(lineArray[52]);

                            itemName = "�E���R";
                            shokurekiMonths += validateInputShokureki(checkShokureki, itemName, lineNo, 59, errorLog, errors);
                            gokakugoShokurekiCheckList.add(checkShokureki);
                        }
                        if (!lineArray[53].isEmpty()) {
                            // �E���S
                            checkShokureki = new MskUploadJoho();
                            checkShokureki.setSknKsuCode(lineArray[0]);
                            checkShokureki.setKinmusakiKaishaName1(lineArray[53]);
                            checkShokureki.setBushoYakushokuName1(lineArray[54]);
                            checkShokureki.setShozaichi1(lineArray[55]);
                            checkShokureki.setShokumuNaiyo1(lineArray[56]);
                            checkShokureki.setZaisekikikanFrom1(lineArray[57]);
                            checkShokureki.setZaisekikikanTo1(lineArray[58]);

                            itemName = "�E���S";
                            shokurekiMonths += validateInputShokureki(checkShokureki, itemName, lineNo, 66, errorLog, errors);
                            gokakugoShokurekiCheckList.add(checkShokureki);
                        }
                        if (!lineArray[59].isEmpty()) {
                            // �E���T
                            checkShokureki = new MskUploadJoho();
                            checkShokureki.setSknKsuCode(lineArray[0]);
                            checkShokureki.setKinmusakiKaishaName1(lineArray[59]);
                            checkShokureki.setBushoYakushokuName1(lineArray[60]);
                            checkShokureki.setShozaichi1(lineArray[61]);
                            checkShokureki.setShokumuNaiyo1(lineArray[62]);
                            checkShokureki.setZaisekikikanFrom1(lineArray[63]);
                            checkShokureki.setZaisekikikanTo1(lineArray[64]);

                            itemName = "�E���T";
                            shokurekiMonths += validateInputShokureki(checkShokureki, itemName, lineNo, 73, errorLog, errors);
                            gokakugoShokurekiCheckList.add(checkShokureki);
                        }
                        if (!lineArray[65].isEmpty()) {
                            // �E���U
                            checkShokureki = new MskUploadJoho();
                            checkShokureki.setSknKsuCode(lineArray[0]);
                            checkShokureki.setKinmusakiKaishaName1(lineArray[65]);
                            checkShokureki.setBushoYakushokuName1(lineArray[66]);
                            checkShokureki.setShozaichi1(lineArray[67]);
                            checkShokureki.setShokumuNaiyo1(lineArray[68]);
                            checkShokureki.setZaisekikikanFrom1(lineArray[69]);
                            checkShokureki.setZaisekikikanTo1(lineArray[70]);

                            itemName = "�E���U";
                            shokurekiMonths += validateInputShokureki(checkShokureki, itemName, lineNo, 80, errorLog, errors);
                            gokakugoShokurekiCheckList.add(checkShokureki);
                        }
                        if (!lineArray[71].isEmpty()) {
                            // �E���V
                            checkShokureki = new MskUploadJoho();
                            checkShokureki.setSknKsuCode(lineArray[0]);
                            checkShokureki.setKinmusakiKaishaName1(lineArray[71]);
                            checkShokureki.setBushoYakushokuName1(lineArray[72]);
                            checkShokureki.setShozaichi1(lineArray[73]);
                            checkShokureki.setShokumuNaiyo1(lineArray[74]);
                            checkShokureki.setZaisekikikanFrom1(lineArray[75]);
                            checkShokureki.setZaisekikikanTo1(lineArray[76]);

                            itemName = "�E���V";
                            shokurekiMonths += validateInputShokureki(checkShokureki, itemName, lineNo, 87, errorLog, errors);
                            gokakugoShokurekiCheckList.add(checkShokureki);
                        }
                        if (!lineArray[77].isEmpty()) {
                            // �E���W
                            checkShokureki = new MskUploadJoho();
                            checkShokureki.setSknKsuCode(lineArray[0]);
                            checkShokureki.setKinmusakiKaishaName1(lineArray[77]);
                            checkShokureki.setBushoYakushokuName1(lineArray[78]);
                            checkShokureki.setShozaichi1(lineArray[79]);
                            checkShokureki.setShokumuNaiyo1(lineArray[80]);
                            checkShokureki.setZaisekikikanFrom1(lineArray[81]);
                            checkShokureki.setZaisekikikanTo1(lineArray[82]);

                            itemName = "�E���W";
                            shokurekiMonths += validateInputShokureki(checkShokureki, itemName, lineNo, 94, errorLog, errors);
                            gokakugoShokurekiCheckList.add(checkShokureki);
                        }
                        if (!lineArray[83].isEmpty()) {
                            // �E���X
                            checkShokureki = new MskUploadJoho();
                            checkShokureki.setSknKsuCode(lineArray[0]);
                            checkShokureki.setKinmusakiKaishaName1(lineArray[83]);
                            checkShokureki.setBushoYakushokuName1(lineArray[84]);
                            checkShokureki.setShozaichi1(lineArray[85]);
                            checkShokureki.setShokumuNaiyo1(lineArray[86]);
                            checkShokureki.setZaisekikikanFrom1(lineArray[87]);
                            checkShokureki.setZaisekikikanTo1(lineArray[88]);

                            itemName = "�E���X";
                            shokurekiMonths += validateInputShokureki(checkShokureki, itemName, lineNo, 101, errorLog, errors);
                            gokakugoShokurekiCheckList.add(checkShokureki);
                        }
                        if (!lineArray[89].isEmpty()) {
                            // �E���P�O
                            checkShokureki = new MskUploadJoho();
                            checkShokureki.setSknKsuCode(lineArray[0]);
                            checkShokureki.setKinmusakiKaishaName1(lineArray[89]);
                            checkShokureki.setBushoYakushokuName1(lineArray[90]);
                            checkShokureki.setShozaichi1(lineArray[91]);
                            checkShokureki.setShokumuNaiyo1(lineArray[92]);
                            checkShokureki.setZaisekikikanFrom1(lineArray[93]);
                            checkShokureki.setZaisekikikanTo1(lineArray[94]);

                            itemName = "�E���P�O";
                            shokurekiMonths += validateInputShokureki(checkShokureki, itemName, lineNo, 108, errorLog, errors);
                            gokakugoShokurekiCheckList.add(checkShokureki);
                        }

                        yearCount = shokurekiMonths / 12;
                        switch (lineArray[28]) {
                            case BmaConstants.SKK_CODE_01:
                                if (yearCount < 5) {
                                    BmaValidator.addMessage(errors, groupCode, BmaText.E00054, "");
                                    this.createErrorLine(lineNo, 45, "�E��", errors, errorLog);
                                }
                                break;
                            case BmaConstants.SKK_CODE_02:
                                if (yearCount < 1) {
                                    BmaValidator.addMessage(errors, groupCode, BmaText.E00054, "");
                                    this.createErrorLine(lineNo, 45, "�E��", errors, errorLog);
                                }
                                break;
                            case BmaConstants.SKK_CODE_03:
                                if (yearCount < 3) {
                                    BmaValidator.addMessage(errors, groupCode, BmaText.E00054, "");
                                    this.createErrorLine(lineNo, 45, "�E��", errors, errorLog);
                                }
                                break;
                            case BmaConstants.SKK_CODE_05:
                                if (yearCount < 4) {
                                    BmaValidator.addMessage(errors, groupCode, BmaText.E00054, "");
                                    this.createErrorLine(lineNo, 45, "�E��", errors, errorLog);
                                }
                                break;
                            default:
                        }
                    }

                    // ���i�R�[�h0002or0003�̎��A���i��̎����o���N�����`�F�b�N
                    if (BmaConstants.SKK_CODE_02.equals(lineArray[28]) || BmaConstants.SKK_CODE_03.equals(lineArray[28])) {
                        String gokakuNen = "";
                        int gokakugoHitsuyoNensu = 0;
                        // �r���N1���@���i�R�[�h0002�A0003
                        if (BmaConstants.SKK_CODE_02.equals(lineArray[28]) && !BmaUtility.isNullOrEmpty(lineArray[29]) && lineArray[29].length() > 3) {
                            // ���i�R�[�h0002 ���i��1�N
                            gokakuNen = lineArray[29].substring(1, 3);
                            gokakugoHitsuyoNensu = 1;
                        } else if (BmaConstants.SKK_CODE_03.equals(lineArray[28]) && !BmaUtility.isNullOrEmpty(lineArray[29]) && lineArray[29].length() > 3) {
                            // ���i�R�[�h0003 ���i��3�N
                            gokakuNen = lineArray[29].substring(1, 3);
                            gokakugoHitsuyoNensu = 3;
                        }

                        // for test
//                        Boolean result = checkGokakugoShokureki(gokakugoShokurekiCheckList, gokakuNen, gokakugoHitsuyoNensu);
//                        if (!result) {
//                            BmaValidator.addMessage(errors, groupCode, "���i��̎����o���N�����s�����Ă��܂��B", "");
//                            this.createErrorLine(lineNo, 45, "�E���P�i�Ζ���Ћy�ю��Ə��j", errors, errorLog);
//                        }
                    }
                }

                switch (lineArray[24]) {
                    case BmaConstants.SKN_NAIYO_KBN_GAKKA_MENJO:
                        // �K�v�`�F�b�N
                        if (!BmaValidator.validateRequired(lineArray[95], errors, groupCode, "")) {
                            this.createErrorLine(lineNo, 115, "�Ə����i�R�[�h", errors, errorLog);
                        } else {
                            // �Ə����i�R�[�h
                            String[] bc1MnjCode1 = {BmaConstants.MNJ_CODE_01, BmaConstants.MNJ_CODE_03, BmaConstants.MNJ_CODE_05};
                            // �I���`�F�b�N
                            if (!Arrays.asList(bc1MnjCode1).contains(lineArray[95])) {
                                BmaValidator.addMessage(errors, groupCode, BmaText.E00106, "");
                                this.createErrorLine(lineNo, 115, "�Ə����i�R�[�h", errors, errorLog);
                            }
                            if (lineArray[95].equals(BmaConstants.MNJ_CODE_01) || lineArray[95].equals(BmaConstants.MNJ_CODE_03)) {
                                // �K�v�`�F�b�N
                                if (!BmaValidator.validateRequired(lineArray[96], errors, groupCode, "")) {
                                    this.createErrorLine(lineNo, 117, "�Ə����i�ԍ�", errors, errorLog);
                                } else {
                                    // �Ə����i�ԍ�
                                    // �����`�F�b�N
                                    if (!BmaValidator.validateMaxLength(lineArray[96], 20, errors, groupCode, "")) {
                                        this.createErrorLine(lineNo, 117, "�Ə����i�ԍ�", errors, errorLog);
                                    }
                                    // �ԍ��`�F�b�N
                                    if (lineArray[95].equals(BmaConstants.MNJ_CODE_01)) {
                                        validateInputMenjo(BmaConstants.SKN_KSU_CODE_BC, BmaConstants.SHUBETSU_CODE_ONE, lineArray[96], BmaConstants.SKN_NAIYO_KBN_GAKKA_MENJO, groupCode, lineNo, 117, errorLog, errors);
                                    } else if (lineArray[95].equals(BmaConstants.MNJ_CODE_03)) {
                                        validateInputMenjo(BmaConstants.SKN_KSU_CODE_BC, BmaConstants.SHUBETSU_CODE_TANITI, lineArray[96], BmaConstants.SKN_NAIYO_KBN_GAKKA_MENJO, groupCode, lineNo, 117, errorLog, errors);
                                    }
                                }
                            }
                        }
                        break;
                    case BmaConstants.SKN_NAIYO_KBN_JITSUGI_MENJO:
                        // �Ə����i�R�[�h
                        // �K�v�`�F�b�N
                        if (!BmaValidator.validateRequired(lineArray[95], errors, groupCode, "")) {
                            this.createErrorLine(lineNo, 115, "�Ə����i�R�[�h", errors, errorLog);
                        } else {
                            String[] bc1MnjCode2 = {BmaConstants.MNJ_CODE_02, BmaConstants.MNJ_CODE_04};
                            // �I���`�F�b�N
                            if (!Arrays.asList(bc1MnjCode2).contains(lineArray[95])) {
                                BmaValidator.addMessage(errors, groupCode, BmaText.E00106, "");
                                this.createErrorLine(lineNo, 115, "�Ə����i�R�[�h", errors, errorLog);
                            }
                            // �Ə����i�ԍ�
                            // �K�v�`�F�b�N
                            if (!BmaValidator.validateRequired(lineArray[96], errors, groupCode, "")) {
                                this.createErrorLine(lineNo, 117, "�Ə����i�ԍ�", errors, errorLog);
                            } else {
                                // �����`�F�b�N
                                if (!BmaValidator.validateMaxLength(lineArray[96], 20, errors, groupCode, "")) {
                                    this.createErrorLine(lineNo, 117, "�Ə����i�ԍ�", errors, errorLog);
                                }
                                // �ԍ��`�F�b�N
                                if (lineArray[95].equals(BmaConstants.MNJ_CODE_02)) {
                                    validateInputMenjo(BmaConstants.SKN_KSU_CODE_BC, BmaConstants.SHUBETSU_CODE_ONE, lineArray[96], BmaConstants.SKN_NAIYO_KBN_JITSUGI_MENJO, groupCode, lineNo, 117, errorLog, errors);
                                } else if (lineArray[95].equals(BmaConstants.MNJ_CODE_04)) {
                                    validateInputMenjo(BmaConstants.SKN_KSU_CODE_BC, BmaConstants.SHUBETSU_CODE_TANITI, lineArray[96], BmaConstants.SKN_NAIYO_KBN_JITSUGI_MENJO, groupCode, lineNo, 117, errorLog, errors);
                                }
                            }
                        }
                        break;
                    default:
                        break;
                }
            } else if (BmaConstants.SKN_KSU_CODE_BE.equals(lineArray[0]) && BmaConstants.SHUBETSU_CODE_ONE.equals(lineArray[1])) {
                // �O���t���O
                // �K�v�`�F�b�N
                if (!BmaValidator.validateRequired(lineArray[26], errors, groupCode, "")) {
                    this.createErrorLine(lineNo, 34, "�O���t���O", errors, errorLog);
                } else {
                    // �I���`�F�b�N
                    if (!Arrays.asList(gaijiFlg).contains(lineArray[26])) {
                        BmaValidator.addMessage(errors, groupCode, BmaText.E00106, "");
                        this.createErrorLine(lineNo, 34, "�O���t���O", errors, errorLog);
                    }
                }
                // �O���ڍ�
                if (!BmaValidator.validateMaxLength(lineArray[27], 200, errors, groupCode, "")) {
                    this.createErrorLine(lineNo, 36, "�O���ڍ�", errors, errorLog);
                }
                // ������`�F�b�N
                if (!BmaValidator.validateMojiCodeForBiko(lineArray[27], errors, groupCode, "")) {
                    this.createErrorLine(lineNo, 36, "�O���ڍ�", errors, errorLog);
                }

                // ���i�֘A�`�F�b�N
                String[] bc1SkkCode1 = {BmaConstants.SKK_CODE_01, BmaConstants.SKK_CODE_02,
                    BmaConstants.SKK_CODE_03, BmaConstants.SKK_CODE_04, BmaConstants.SKK_CODE_05,
                    BmaConstants.SKK_CODE_06, BmaConstants.SKK_CODE_07, BmaConstants.SKK_CODE_08,
                    BmaConstants.SKK_CODE_09, BmaConstants.SKK_CODE_10};
                // �󌟎��i�R�[�h
                // �K�v�`�F�b�N
                if (!BmaValidator.validateRequired(lineArray[28], errors, groupCode, "")) {
                    this.createErrorLine(lineNo, 37, "�󌟎��i�R�[�h", errors, errorLog);
                } else {
                    // �I���`�F�b�N
                    if (!Arrays.asList(bc1SkkCode1).contains(lineArray[28])) {
                        BmaValidator.addMessage(errors, groupCode, BmaText.E00106, "");
                        this.createErrorLine(lineNo, 37, "�󌟎��i�R�[�h", errors, errorLog);
                    }
                }

                // �󌟎��i�ԍ�
                List<String> jukenSkkNoList = inSession.getJukenSkkNoList();
                // �_�u��`�F�b�N
                if (!lineArray[29].isEmpty()) {
                    if (jukenSkkNoList.contains(lineArray[29])) {
                        BmaValidator.addMessage(errors, groupCode, BmaText.E00101, "");
                        this.createErrorLine(lineNo, 39, "�󌟎��i�ԍ�", errors, errorLog);
                    }
                    jukenSkkNoList.add(lineArray[29]);
                    inSession.setJukenSkkNoList(jukenSkkNoList);
                    // �����`�F�b�N
                    if (!BmaValidator.validateMaxLength(lineArray[29], 20, errors, groupCode, "")) {
                        this.createErrorLine(lineNo, 39, "�󌟎��i�ԍ�", errors, errorLog);
                    }
                    // �ԍ��`�F�b�N
                    validateInputShikaku(BmaConstants.SKN_KSU_CODE_BE, BmaConstants.SHUBETSU_CODE_TWO, lineArray[29], groupCode, lineNo, 39, errorLog, errors);
                }

                if (BmaConstants.SKK_CODE_02.equals(lineArray[28])
                        || BmaConstants.SKK_CODE_03.equals(lineArray[28])
                        || BmaConstants.SKK_CODE_04.equals(lineArray[28])
                        || BmaConstants.SKK_CODE_05.equals(lineArray[28])
                        || BmaConstants.SKK_CODE_06.equals(lineArray[28])) {
                    // �w��
                    checkShokureki = new MskUploadJoho();
                    checkShokureki.setSknKsuCode(lineArray[0]);
                    checkShokureki.setGakurekiName(lineArray[30]);
                    checkShokureki.setGakurekiNaiyo(lineArray[31]);
                    checkShokureki.setGakurekiShozaichi(lineArray[32]);
                    checkShokureki.setGakurekiDate(lineArray[33]);
                    validateInputGakureki(checkShokureki, groupCode, lineNo, 40, errorLog, errors);
                } else if (BmaConstants.SKK_CODE_07.equals(lineArray[28])
                        || BmaConstants.SKK_CODE_08.equals(lineArray[28])
                        || BmaConstants.SKK_CODE_09.equals(lineArray[28])) {
                    // �P����
                    checkShokureki = new MskUploadJoho();
                    checkShokureki.setSknKsuCode(lineArray[0]);
                    checkShokureki.setKurenrekiName(lineArray[34]);
                    checkShokureki.setKurenrekiNaiyo(lineArray[35]);
                    checkShokureki.setKurenrekiShozaichi(lineArray[36]);
                    checkShokureki.setKurenrekiFrom(lineArray[37]);
                    checkShokureki.setKurenrekiTo(lineArray[38]);
                    validateInputKunrenreki(checkShokureki, groupCode, lineNo, 44, errorLog, errors);
                }

                // �E��
                if (lineArray[39].isEmpty()
                        && lineArray[45].isEmpty()
                        && lineArray[51].isEmpty()
                        && lineArray[57].isEmpty()
                        && lineArray[63].isEmpty()
                        && lineArray[69].isEmpty()
                        && lineArray[75].isEmpty()
                        && lineArray[81].isEmpty()
                        && lineArray[87].isEmpty()
                        && lineArray[93].isEmpty()) {
                    BmaValidator.addMessage(errors, groupCode, BmaText.E00015, "");
                    this.createErrorLine(lineNo, 49, "�E���P�i�Ζ���Ћy�ю��Ə��j", errors, errorLog);
                } else {
                    if (!lineArray[39].isEmpty()) {
                        // �E���P
                        checkShokureki = new MskUploadJoho();
                        checkShokureki.setSknKsuCode(lineArray[0]);
                        checkShokureki.setKinmusakiKaishaName1(lineArray[39]);
                        checkShokureki.setBushoYakushokuName1(lineArray[40]);
                        checkShokureki.setShozaichi1(lineArray[41]);
                        checkShokureki.setShokumuNaiyo1(lineArray[42]);
                        checkShokureki.setZaisekikikanFrom1(lineArray[43]);
                        checkShokureki.setZaisekikikanTo1(lineArray[44]);

                        itemName = "�E���P";
                        shokurekiMonths += validateInputShokureki(checkShokureki, itemName, lineNo, 49, errorLog, errors);
                        gokakugoShokurekiCheckList.add(checkShokureki);
                    }
                    if (!lineArray[45].isEmpty()) {
                        // �E���Q
                        checkShokureki = new MskUploadJoho();
                        checkShokureki.setSknKsuCode(lineArray[0]);
                        checkShokureki.setKinmusakiKaishaName1(lineArray[45]);
                        checkShokureki.setBushoYakushokuName1(lineArray[46]);
                        checkShokureki.setShozaichi1(lineArray[47]);
                        checkShokureki.setShokumuNaiyo1(lineArray[48]);
                        checkShokureki.setZaisekikikanFrom1(lineArray[49]);
                        checkShokureki.setZaisekikikanTo1(lineArray[50]);

                        itemName = "�E���Q";
                        shokurekiMonths += validateInputShokureki(checkShokureki, itemName, lineNo, 56, errorLog, errors);
                        gokakugoShokurekiCheckList.add(checkShokureki);
                    }
                    if (!lineArray[51].isEmpty()) {
                        // �E���R
                        checkShokureki = new MskUploadJoho();
                        checkShokureki.setSknKsuCode(lineArray[0]);
                        checkShokureki.setKinmusakiKaishaName1(lineArray[51]);
                        checkShokureki.setBushoYakushokuName1(lineArray[52]);
                        checkShokureki.setShozaichi1(lineArray[53]);
                        checkShokureki.setShokumuNaiyo1(lineArray[54]);
                        checkShokureki.setZaisekikikanFrom1(lineArray[55]);
                        checkShokureki.setZaisekikikanTo1(lineArray[56]);

                        itemName = "�E���R";
                        shokurekiMonths += validateInputShokureki(checkShokureki, itemName, lineNo, 63, errorLog, errors);
                        gokakugoShokurekiCheckList.add(checkShokureki);
                    }
                    if (!lineArray[57].isEmpty()) {
                        // �E���S
                        checkShokureki = new MskUploadJoho();
                        checkShokureki.setSknKsuCode(lineArray[0]);
                        checkShokureki.setKinmusakiKaishaName1(lineArray[57]);
                        checkShokureki.setBushoYakushokuName1(lineArray[58]);
                        checkShokureki.setShozaichi1(lineArray[59]);
                        checkShokureki.setShokumuNaiyo1(lineArray[60]);
                        checkShokureki.setZaisekikikanFrom1(lineArray[61]);
                        checkShokureki.setZaisekikikanTo1(lineArray[62]);

                        itemName = "�E���S";
                        shokurekiMonths += validateInputShokureki(checkShokureki, itemName, lineNo, 70, errorLog, errors);
                        gokakugoShokurekiCheckList.add(checkShokureki);
                    }
                    if (!lineArray[63].isEmpty()) {
                        // �E���T
                        checkShokureki = new MskUploadJoho();
                        checkShokureki.setSknKsuCode(lineArray[0]);
                        checkShokureki.setKinmusakiKaishaName1(lineArray[63]);
                        checkShokureki.setBushoYakushokuName1(lineArray[64]);
                        checkShokureki.setShozaichi1(lineArray[65]);
                        checkShokureki.setShokumuNaiyo1(lineArray[66]);
                        checkShokureki.setZaisekikikanFrom1(lineArray[67]);
                        checkShokureki.setZaisekikikanTo1(lineArray[68]);

                        itemName = "�E���T";
                        shokurekiMonths += validateInputShokureki(checkShokureki, itemName, lineNo, 77, errorLog, errors);
                        gokakugoShokurekiCheckList.add(checkShokureki);
                    }
                    if (!lineArray[69].isEmpty()) {
                        // �E���U
                        checkShokureki = new MskUploadJoho();
                        checkShokureki.setSknKsuCode(lineArray[0]);
                        checkShokureki.setKinmusakiKaishaName1(lineArray[69]);
                        checkShokureki.setBushoYakushokuName1(lineArray[70]);
                        checkShokureki.setShozaichi1(lineArray[71]);
                        checkShokureki.setShokumuNaiyo1(lineArray[72]);
                        checkShokureki.setZaisekikikanFrom1(lineArray[73]);
                        checkShokureki.setZaisekikikanTo1(lineArray[74]);

                        itemName = "�E���U";
                        shokurekiMonths += validateInputShokureki(checkShokureki, itemName, lineNo, 84, errorLog, errors);
                        gokakugoShokurekiCheckList.add(checkShokureki);
                    }
                    if (!lineArray[75].isEmpty()) {
                        // �E���V
                        checkShokureki = new MskUploadJoho();
                        checkShokureki.setSknKsuCode(lineArray[0]);
                        checkShokureki.setKinmusakiKaishaName1(lineArray[75]);
                        checkShokureki.setBushoYakushokuName1(lineArray[76]);
                        checkShokureki.setShozaichi1(lineArray[77]);
                        checkShokureki.setShokumuNaiyo1(lineArray[78]);
                        checkShokureki.setZaisekikikanFrom1(lineArray[79]);
                        checkShokureki.setZaisekikikanTo1(lineArray[80]);

                        itemName = "�E���V";
                        shokurekiMonths += validateInputShokureki(checkShokureki, itemName, lineNo, 91, errorLog, errors);
                        gokakugoShokurekiCheckList.add(checkShokureki);
                    }
                    if (!lineArray[81].isEmpty()) {
                        // �E���W
                        checkShokureki = new MskUploadJoho();
                        checkShokureki.setSknKsuCode(lineArray[0]);
                        checkShokureki.setKinmusakiKaishaName1(lineArray[81]);
                        checkShokureki.setBushoYakushokuName1(lineArray[82]);
                        checkShokureki.setShozaichi1(lineArray[83]);
                        checkShokureki.setShokumuNaiyo1(lineArray[84]);
                        checkShokureki.setZaisekikikanFrom1(lineArray[85]);
                        checkShokureki.setZaisekikikanTo1(lineArray[86]);

                        itemName = "�E���W";
                        shokurekiMonths += validateInputShokureki(checkShokureki, itemName, lineNo, 98, errorLog, errors);
                        gokakugoShokurekiCheckList.add(checkShokureki);
                    }
                    if (!lineArray[87].isEmpty()) {
                        // �E���X
                        checkShokureki = new MskUploadJoho();
                        checkShokureki.setSknKsuCode(lineArray[0]);
                        checkShokureki.setKinmusakiKaishaName1(lineArray[87]);
                        checkShokureki.setBushoYakushokuName1(lineArray[88]);
                        checkShokureki.setShozaichi1(lineArray[89]);
                        checkShokureki.setShokumuNaiyo1(lineArray[90]);
                        checkShokureki.setZaisekikikanFrom1(lineArray[91]);
                        checkShokureki.setZaisekikikanTo1(lineArray[92]);

                        itemName = "�E���X";
                        shokurekiMonths += validateInputShokureki(checkShokureki, itemName, lineNo, 105, errorLog, errors);
                        gokakugoShokurekiCheckList.add(checkShokureki);
                    }
                    if (!lineArray[93].isEmpty()) {
                        // �E���P�O
                        checkShokureki = new MskUploadJoho();
                        checkShokureki.setSknKsuCode(lineArray[0]);
                        checkShokureki.setKinmusakiKaishaName1(lineArray[93]);
                        checkShokureki.setBushoYakushokuName1(lineArray[94]);
                        checkShokureki.setShozaichi1(lineArray[95]);
                        checkShokureki.setShokumuNaiyo1(lineArray[96]);
                        checkShokureki.setZaisekikikanFrom1(lineArray[97]);
                        checkShokureki.setZaisekikikanTo1(lineArray[98]);

                        itemName = "�E���P�O";
                        shokurekiMonths += validateInputShokureki(checkShokureki, itemName, lineNo, 112, errorLog, errors);
                        gokakugoShokurekiCheckList.add(checkShokureki);
                    }

                    yearCount = shokurekiMonths / 12;
                    if (!lineArray[29].isEmpty()) {
                        // BE2��������ꍇ
                        String gokakuNen = "";
                        int gokakugoHitsuyoNensu = 0;
                        if (lineArray[29].length() > 3) {
                            gokakuNen = lineArray[29].substring(1, 3);
                            // ���i��̐E��N���v�Z�@���i�R�[�h0010��1�N�A����2�N
                            gokakugoHitsuyoNensu = BmaConstants.SKK_CODE_10.equals(lineArray[28]) ? 1 : 2;
                            Boolean result = checkGokakugoShokureki(gokakugoShokurekiCheckList, gokakuNen, gokakugoHitsuyoNensu);
                            if (!result) {
                                BmaValidator.addMessage(errors, groupCode, "���i��̎����o���N�����s�����Ă��܂��B", "");
                                this.createErrorLine(lineNo, 49, "�E��", errors, errorLog);
                            }
                        }
                    } else if (BmaConstants.SKK_CODE_01.equals(lineArray[28]) && lineArray[29].isEmpty()) {
                        if (yearCount < 7) {
                            BmaValidator.addMessage(errors, groupCode, BmaText.E00054, "");
                            this.createErrorLine(lineNo, 49, "�E��", errors, errorLog);
                        }
                    } else if (BmaConstants.SKK_CODE_02.equals(lineArray[28]) && lineArray[29].isEmpty()) {
                        if (yearCount < 6) {
                            BmaValidator.addMessage(errors, groupCode, BmaText.E00054, "");
                            this.createErrorLine(lineNo, 49, "�E��", errors, errorLog);
                        }
                    } else if (BmaConstants.SKK_CODE_03.equals(lineArray[28]) && lineArray[29].isEmpty()) {
                        if (yearCount < 5) {
                            BmaValidator.addMessage(errors, groupCode, BmaText.E00054, "");
                            this.createErrorLine(lineNo, 49, "�E��", errors, errorLog);
                        }
                    } else if (BmaConstants.SKK_CODE_04.equals(lineArray[28]) && lineArray[29].isEmpty()) {
                        if (yearCount < 4) {
                            BmaValidator.addMessage(errors, groupCode, BmaText.E00054, "");
                            this.createErrorLine(lineNo, 49, "�E��", errors, errorLog);
                        }
                    } else if (BmaConstants.SKK_CODE_05.equals(lineArray[28]) && lineArray[29].isEmpty()) {
                        if (yearCount < 6) {
                            BmaValidator.addMessage(errors, groupCode, BmaText.E00054, "");
                            this.createErrorLine(lineNo, 49, "�E��", errors, errorLog);
                        }
                    } else if (BmaConstants.SKK_CODE_06.equals(lineArray[28]) && lineArray[29].isEmpty()) {
                        if (yearCount < 4) {
                            BmaValidator.addMessage(errors, groupCode, BmaText.E00054, "");
                            this.createErrorLine(lineNo, 49, "�E��", errors, errorLog);
                        }
                    } else if (BmaConstants.SKK_CODE_07.equals(lineArray[28]) && lineArray[29].isEmpty()) {
                        if (yearCount < 6) {
                            BmaValidator.addMessage(errors, groupCode, BmaText.E00054, "");
                            this.createErrorLine(lineNo, 49, "�E��", errors, errorLog);
                        }
                    } else if (BmaConstants.SKK_CODE_08.equals(lineArray[28]) && lineArray[29].isEmpty()) {
                        if (yearCount < 6) {
                            BmaValidator.addMessage(errors, groupCode, BmaText.E00054, "");
                            this.createErrorLine(lineNo, 49, "�E��", errors, errorLog);
                        }
                    } else if (BmaConstants.SKK_CODE_09.equals(lineArray[28]) && lineArray[29].isEmpty()) {
                        if (yearCount < 4) {
                            BmaValidator.addMessage(errors, groupCode, BmaText.E00054, "");
                            this.createErrorLine(lineNo, 49, "�E��", errors, errorLog);
                        }
                    } else if (BmaConstants.SKK_CODE_10.equals(lineArray[28]) && lineArray[29].isEmpty()) {
                        if (yearCount < 1) {
                            BmaValidator.addMessage(errors, groupCode, BmaText.E00054, "");
                            this.createErrorLine(lineNo, 49, "�E��", errors, errorLog);
                        }
                    }
                }

                switch (lineArray[24]) {
                    case BmaConstants.SKN_NAIYO_KBN_GAKKA_MENJO:
                        // �K�v�`�F�b�N
                        if (!BmaValidator.validateRequired(lineArray[99], errors, groupCode, "")) {
                            this.createErrorLine(lineNo, 119, "�Ə����i�R�[�h", errors, errorLog);
                        } else {
                            // �Ə����i�R�[�h
                            String[] bc1MnjCode1 = {BmaConstants.MNJ_CODE_01, BmaConstants.MNJ_CODE_03, BmaConstants.MNJ_CODE_04};
                            // �I���`�F�b�N
                            if (!Arrays.asList(bc1MnjCode1).contains(lineArray[99])) {
                                BmaValidator.addMessage(errors, groupCode, BmaText.E00106, "");
                                this.createErrorLine(lineNo, 119, "�Ə����i�R�[�h", errors, errorLog);
                            }
                            if (BmaConstants.MNJ_CODE_01.equals(lineArray[99])) {
                                // �K�v�`�F�b�N
                                if (!BmaValidator.validateRequired(lineArray[100], errors, groupCode, "")) {
                                    this.createErrorLine(lineNo, 121, "�Ə����i�ԍ�", errors, errorLog);
                                } else {
                                    // �Ə����i�ԍ�
                                    // �����`�F�b�N
                                    if (!BmaValidator.validateMaxLength(lineArray[100], 20, errors, groupCode, "")) {
                                        this.createErrorLine(lineNo, 121, "�Ə����i�ԍ�", errors, errorLog);
                                    }
                                    // �ԍ��`�F�b�N
                                    validateInputMenjo(BmaConstants.SKN_KSU_CODE_BE, BmaConstants.SHUBETSU_CODE_ONE, lineArray[100], BmaConstants.SKN_NAIYO_KBN_GAKKA_MENJO, groupCode, lineNo, 121, errorLog, errors);
                                }
                            }
                        }
                        break;
                    case BmaConstants.SKN_NAIYO_KBN_JITSUGI_MENJO:
                        // �K�v�`�F�b�N
                        if (!BmaValidator.validateRequired(lineArray[99], errors, groupCode, "")) {
                            this.createErrorLine(lineNo, 119, "�Ə����i�R�[�h", errors, errorLog);
                        } else {
                            // �Ə����i�R�[�h
                            // �I���`�F�b�N
                            if (!BmaConstants.MNJ_CODE_02.equals(lineArray[99])) {
                                BmaValidator.addMessage(errors, groupCode, BmaText.E00106, "");
                                this.createErrorLine(lineNo, 119, "�Ə����i�R�[�h", errors, errorLog);
                            }
                            // �K�v�`�F�b�N
                            if (!BmaValidator.validateRequired(lineArray[100], errors, groupCode, "")) {
                                this.createErrorLine(lineNo, 121, "�Ə����i�ԍ�", errors, errorLog);
                            } else {
                                // �Ə����i�ԍ�
                                // �I���`�F�b�N
                                if (!BmaValidator.validateMaxLength(lineArray[100], 20, errors, groupCode, "")) {
                                    this.createErrorLine(lineNo, 121, "�Ə����i�ԍ�", errors, errorLog);
                                }
                                // �ԍ��`�F�b�N
                                validateInputMenjo(BmaConstants.SKN_KSU_CODE_BE, BmaConstants.SHUBETSU_CODE_ONE, lineArray[100], BmaConstants.SKN_NAIYO_KBN_JITSUGI_MENJO, groupCode, lineNo, 121, errorLog, errors);
                            }
                        }
                        break;
                    default:
                        break;
                }

            } else if (BmaConstants.SKN_KSU_CODE_BC.equals(lineArray[0]) && BmaConstants.SHUBETSU_CODE_TWO.equals(lineArray[1])) {
                // ���ƃt���O
                // �K�v�`�F�b�N
                if (!BmaValidator.validateRequired(lineArray[26], errors, groupCode, "")) {
                    this.createErrorLine(lineNo, 34, "���ƃt���O", errors, errorLog);
                } else {
                    // �I���`�F�b�N
                    if (!Arrays.asList(genmenFlg).contains(lineArray[26])) {
                        BmaValidator.addMessage(errors, groupCode, BmaText.E00106, "");
                        this.createErrorLine(lineNo, 34, "���ƃt���O", errors, errorLog);
                    }
                    // �N��`�F�b�N
                    try {
                        nenrei = service.calcAge(lineArray[3], lineArray[0], lineArray[1], lineArray[2], inSession.getMoshikomishaId(), lineArray[6]);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    if (!BmaUtility.isNullOrEmpty(nenrei) && 35 <= Integer.parseInt(nenrei) && "1".equals(lineArray[26])) {
                        BmaValidator.addMessage(errors, groupCode, "35�Έȏ�̕��͌��Ƒ[�u���󂯂��܂���B", "");
                        this.createErrorLine(lineNo, 34, "���ƃt���O", errors, errorLog);
                    }
                }
                // �O���t���O
                // �K�v�`�F�b�N
                if (!BmaValidator.validateRequired(lineArray[27], errors, groupCode, "")) {
                    this.createErrorLine(lineNo, 36, "�O���t���O", errors, errorLog);
                } else {
                    // �I���`�F�b�N
                    if (!Arrays.asList(gaijiFlg).contains(lineArray[27])) {
                        BmaValidator.addMessage(errors, groupCode, BmaText.E00106, "");
                        this.createErrorLine(lineNo, 36, "�O���t���O", errors, errorLog);
                    }
                }
                // �O���ڍ�
                if (!BmaValidator.validateMaxLength(lineArray[28], 200, errors, groupCode, "")) {
                    this.createErrorLine(lineNo, 38, "�O���ڍ�", errors, errorLog);
                }
                // ������`�F�b�N
                if (!BmaValidator.validateMojiCodeForBiko(lineArray[28], errors, groupCode, "")) {
                    this.createErrorLine(lineNo, 38, "�O���ڍ�", errors, errorLog);
                }

                // �󌟎��i�R�[�h
                // �K�v�`�F�b�N
                if (!BmaValidator.validateRequired(lineArray[29], errors, groupCode, "")) {
                    this.createErrorLine(lineNo, 39, "�󌟎��i�R�[�h", errors, errorLog);
                } else {
                    String[] bc2SkkCode1 = {BmaConstants.SKK_CODE_01, BmaConstants.SKK_CODE_02,
                        BmaConstants.SKK_CODE_03, BmaConstants.SKK_CODE_04};
                    // �I���`�F�b�N
                    if (!Arrays.asList(bc2SkkCode1).contains(lineArray[29])) {
                        BmaValidator.addMessage(errors, groupCode, BmaText.E00106, "");
                        this.createErrorLine(lineNo, 39, "�󌟎��i�R�[�h", errors, errorLog);
                    }
                }
                if (BmaConstants.SKK_CODE_02.equals(lineArray[29])) {
                    // �󌟎��i�ԍ�
                    // �K�v�`�F�b�N
                    if (!BmaValidator.validateRequired(lineArray[30], errors, groupCode, "")) {
                        this.createErrorLine(lineNo, 41, "�󌟎��i�ԍ�", errors, errorLog);
                    } else {
                        // �����`�F�b�N
                        if (!BmaValidator.validateMaxLength(lineArray[30], 20, errors, groupCode, "")) {
                            this.createErrorLine(lineNo, 41, "�󌟎��i�ԍ�", errors, errorLog);
                        }
                        // �ԍ��`�F�b�N
                        validateInputShikaku(BmaConstants.SKN_KSU_CODE_BC, BmaConstants.SHUBETSU_CODE_THREE, lineArray[30], groupCode, lineNo, 41, errorLog, errors);

                        List<String> jukenSkkNoList1 = inSession.getJukenSkkNoList();
                        // �_�u��`�F�b�N
                        if (jukenSkkNoList1.contains(lineArray[30])) {
                            BmaValidator.addMessage(errors, groupCode, BmaText.E00101, "");
                            this.createErrorLine(lineNo, 41, "�󌟎��i�ԍ�", errors, errorLog);
                        }
                        jukenSkkNoList1.add(lineArray[30]);
                        inSession.setJukenSkkNoList(jukenSkkNoList1);
                    }
                }
                if (BmaConstants.SKK_CODE_01.equals(lineArray[29]) || BmaConstants.SKK_CODE_04.equals(lineArray[29])) {
                    if (BmaConstants.SKK_CODE_04.equals(lineArray[29])) {
                        // �P����
                        checkShokureki = new MskUploadJoho();
                        checkShokureki.setSknKsuCode(lineArray[0]);
                        checkShokureki.setKurenrekiName(lineArray[31]);
                        checkShokureki.setKurenrekiNaiyo(lineArray[32]);
                        checkShokureki.setKurenrekiShozaichi(lineArray[33]);
                        checkShokureki.setKurenrekiFrom(lineArray[34]);
                        checkShokureki.setKurenrekiTo(lineArray[35]);
                        validateInputKunrenreki(checkShokureki, groupCode, lineNo, 42, errorLog, errors);
                    }

                    // �E��
                    if (lineArray[36].isEmpty()
                            && lineArray[42].isEmpty()
                            && lineArray[48].isEmpty()
                            && lineArray[54].isEmpty()
                            && lineArray[60].isEmpty()
                            && lineArray[66].isEmpty()
                            && lineArray[72].isEmpty()
                            && lineArray[78].isEmpty()
                            && lineArray[84].isEmpty()
                            && lineArray[90].isEmpty()) {
                        BmaValidator.addMessage(errors, groupCode, BmaText.E00015, "");
                        this.createErrorLine(lineNo, 47, "�E���P�i�Ζ���Ћy�ю��Ə��j", errors, errorLog);
                    } else {
                        if (!lineArray[36].isEmpty()) {
                            // �E���P
                            checkShokureki = new MskUploadJoho();
                            checkShokureki.setSknKsuCode(lineArray[0]);
                            checkShokureki.setKinmusakiKaishaName1(lineArray[36]);
                            checkShokureki.setBushoYakushokuName1(lineArray[37]);
                            checkShokureki.setShozaichi1(lineArray[38]);
                            checkShokureki.setShokumuNaiyo1(lineArray[39]);
                            checkShokureki.setZaisekikikanFrom1(lineArray[40]);
                            checkShokureki.setZaisekikikanTo1(lineArray[41]);

                            itemName = "�E���P";
                            shokurekiMonths += validateInputShokureki(checkShokureki, itemName, lineNo, 47, errorLog, errors);
                        }
                        if (!lineArray[42].isEmpty()) {
                            // �E���Q
                            checkShokureki = new MskUploadJoho();
                            checkShokureki.setSknKsuCode(lineArray[0]);
                            checkShokureki.setKinmusakiKaishaName1(lineArray[42]);
                            checkShokureki.setBushoYakushokuName1(lineArray[43]);
                            checkShokureki.setShozaichi1(lineArray[44]);
                            checkShokureki.setShokumuNaiyo1(lineArray[45]);
                            checkShokureki.setZaisekikikanFrom1(lineArray[46]);
                            checkShokureki.setZaisekikikanTo1(lineArray[47]);

                            itemName = "�E���Q";
                            shokurekiMonths += validateInputShokureki(checkShokureki, itemName, lineNo, 54, errorLog, errors);
                        }
                        if (!lineArray[48].isEmpty()) {
                            // �E���R
                            checkShokureki = new MskUploadJoho();
                            checkShokureki.setSknKsuCode(lineArray[0]);
                            checkShokureki.setKinmusakiKaishaName1(lineArray[48]);
                            checkShokureki.setBushoYakushokuName1(lineArray[49]);
                            checkShokureki.setShozaichi1(lineArray[50]);
                            checkShokureki.setShokumuNaiyo1(lineArray[51]);
                            checkShokureki.setZaisekikikanFrom1(lineArray[52]);
                            checkShokureki.setZaisekikikanTo1(lineArray[53]);

                            itemName = "�E���R";
                            shokurekiMonths += validateInputShokureki(checkShokureki, itemName, lineNo, 61, errorLog, errors);
                        }
                        if (!lineArray[54].isEmpty()) {
                            // �E���S
                            checkShokureki = new MskUploadJoho();
                            checkShokureki.setSknKsuCode(lineArray[0]);
                            checkShokureki.setKinmusakiKaishaName1(lineArray[54]);
                            checkShokureki.setBushoYakushokuName1(lineArray[55]);
                            checkShokureki.setShozaichi1(lineArray[56]);
                            checkShokureki.setShokumuNaiyo1(lineArray[57]);
                            checkShokureki.setZaisekikikanFrom1(lineArray[58]);
                            checkShokureki.setZaisekikikanTo1(lineArray[59]);

                            itemName = "�E���S";
                            shokurekiMonths += validateInputShokureki(checkShokureki, itemName, lineNo, 68, errorLog, errors);
                        }
                        if (!lineArray[60].isEmpty()) {
                            // �E���T
                            checkShokureki = new MskUploadJoho();
                            checkShokureki.setSknKsuCode(lineArray[0]);
                            checkShokureki.setKinmusakiKaishaName1(lineArray[60]);
                            checkShokureki.setBushoYakushokuName1(lineArray[61]);
                            checkShokureki.setShozaichi1(lineArray[62]);
                            checkShokureki.setShokumuNaiyo1(lineArray[63]);
                            checkShokureki.setZaisekikikanFrom1(lineArray[64]);
                            checkShokureki.setZaisekikikanTo1(lineArray[65]);

                            itemName = "�E���T";
                            shokurekiMonths += validateInputShokureki(checkShokureki, itemName, lineNo, 75, errorLog, errors);
                        }
                        if (!lineArray[66].isEmpty()) {
                            // �E���U
                            checkShokureki = new MskUploadJoho();
                            checkShokureki.setSknKsuCode(lineArray[0]);
                            checkShokureki.setKinmusakiKaishaName1(lineArray[66]);
                            checkShokureki.setBushoYakushokuName1(lineArray[67]);
                            checkShokureki.setShozaichi1(lineArray[68]);
                            checkShokureki.setShokumuNaiyo1(lineArray[69]);
                            checkShokureki.setZaisekikikanFrom1(lineArray[70]);
                            checkShokureki.setZaisekikikanTo1(lineArray[71]);

                            itemName = "�E���U";
                            shokurekiMonths += validateInputShokureki(checkShokureki, itemName, lineNo, 82, errorLog, errors);
                        }
                        if (!lineArray[72].isEmpty()) {
                            // �E���V
                            checkShokureki = new MskUploadJoho();
                            checkShokureki.setSknKsuCode(lineArray[0]);
                            checkShokureki.setKinmusakiKaishaName1(lineArray[72]);
                            checkShokureki.setBushoYakushokuName1(lineArray[73]);
                            checkShokureki.setShozaichi1(lineArray[74]);
                            checkShokureki.setShokumuNaiyo1(lineArray[75]);
                            checkShokureki.setZaisekikikanFrom1(lineArray[76]);
                            checkShokureki.setZaisekikikanTo1(lineArray[77]);

                            itemName = "�E���V";
                            shokurekiMonths += validateInputShokureki(checkShokureki, itemName, lineNo, 89, errorLog, errors);
                        }
                        if (!lineArray[78].isEmpty()) {
                            // �E���W
                            checkShokureki = new MskUploadJoho();
                            checkShokureki.setSknKsuCode(lineArray[0]);
                            checkShokureki.setKinmusakiKaishaName1(lineArray[78]);
                            checkShokureki.setBushoYakushokuName1(lineArray[79]);
                            checkShokureki.setShozaichi1(lineArray[80]);
                            checkShokureki.setShokumuNaiyo1(lineArray[81]);
                            checkShokureki.setZaisekikikanFrom1(lineArray[82]);
                            checkShokureki.setZaisekikikanTo1(lineArray[83]);

                            itemName = "�E���W";
                            shokurekiMonths += validateInputShokureki(checkShokureki, itemName, lineNo, 96, errorLog, errors);
                        }
                        if (!lineArray[84].isEmpty()) {
                            // �E���X
                            checkShokureki = new MskUploadJoho();
                            checkShokureki.setSknKsuCode(lineArray[0]);
                            checkShokureki.setKinmusakiKaishaName1(lineArray[84]);
                            checkShokureki.setBushoYakushokuName1(lineArray[85]);
                            checkShokureki.setShozaichi1(lineArray[86]);
                            checkShokureki.setShokumuNaiyo1(lineArray[87]);
                            checkShokureki.setZaisekikikanFrom1(lineArray[88]);
                            checkShokureki.setZaisekikikanTo1(lineArray[89]);

                            itemName = "�E���X";
                            shokurekiMonths += validateInputShokureki(checkShokureki, itemName, lineNo, 103, errorLog, errors);
                        }
                        if (!lineArray[90].isEmpty()) {
                            // �E���P�O
                            checkShokureki = new MskUploadJoho();
                            checkShokureki.setSknKsuCode(lineArray[0]);
                            checkShokureki.setKinmusakiKaishaName1(lineArray[90]);
                            checkShokureki.setBushoYakushokuName1(lineArray[91]);
                            checkShokureki.setShozaichi1(lineArray[92]);
                            checkShokureki.setShokumuNaiyo1(lineArray[93]);
                            checkShokureki.setZaisekikikanFrom1(lineArray[94]);
                            checkShokureki.setZaisekikikanTo1(lineArray[95]);

                            itemName = "�E���P�O";
                            shokurekiMonths += validateInputShokureki(checkShokureki, itemName, lineNo, 110, errorLog, errors);
                        }

                        yearCount = shokurekiMonths / 12;
                        switch (lineArray[29]) {
                            case BmaConstants.SKK_CODE_01:
                                if (yearCount < 2) {
                                    BmaValidator.addMessage(errors, groupCode, BmaText.E00054, "");
                                    this.createErrorLine(lineNo, 47, "�E��", errors, errorLog);
                                }
                                break;
                            case BmaConstants.SKK_CODE_04:
                                if (yearCount < 1) {
                                    BmaValidator.addMessage(errors, groupCode, BmaText.E00054, "");
                                    this.createErrorLine(lineNo, 47, "�E��", errors, errorLog);
                                }
                                break;
                            default:
                        }
                    }
                }

                switch (lineArray[24]) {
                    case BmaConstants.SKN_NAIYO_KBN_GAKKA_MENJO:
                        if (!BmaValidator.validateRequired(lineArray[96], errors, groupCode, "")) {
                            this.createErrorLine(lineNo, 117, "�Ə����i�R�[�h", errors, errorLog);
                        } else {
                            // �Ə����i�R�[�h
                            String[] bc1MnjCode1 = {BmaConstants.MNJ_CODE_01, BmaConstants.MNJ_CODE_03, BmaConstants.MNJ_CODE_05,
                                 BmaConstants.MNJ_CODE_07, BmaConstants.MNJ_CODE_08};
                            // �I���`�F�b�N
                            if (!Arrays.asList(bc1MnjCode1).contains(lineArray[96])) {
                                BmaValidator.addMessage(errors, groupCode, BmaText.E00106, "");
                                this.createErrorLine(lineNo, 117, "�Ə����i�R�[�h", errors, errorLog);
                            }
                        }
                        if (BmaConstants.MNJ_CODE_01.equals(lineArray[96]) || BmaConstants.MNJ_CODE_03.equals(lineArray[96]) || BmaConstants.MNJ_CODE_05.equals(lineArray[96])) {
                            // �Ə����i�ԍ�
                            // �K�v�`�F�b�N
                            if (!BmaValidator.validateRequired(lineArray[97], errors, groupCode, "")) {
                                this.createErrorLine(lineNo, 119, "�Ə����i�ԍ�", errors, errorLog);
                            } else {
                                // �����`�F�b�N
                                if (!BmaValidator.validateMaxLength(lineArray[97], 20, errors, groupCode, "")) {
                                    this.createErrorLine(lineNo, 119, "�Ə����i�ԍ�", errors, errorLog);
                                }
                                // �ԍ��`�F�b�N
                                if (BmaConstants.MNJ_CODE_01.equals(lineArray[96])) {
                                    validateInputMenjo(BmaConstants.SKN_KSU_CODE_BC, BmaConstants.SHUBETSU_CODE_ONE, lineArray[97], BmaConstants.SKN_NAIYO_KBN_GAKKA_MENJO, groupCode, lineNo, 119, errorLog, errors);
                                } else if (BmaConstants.MNJ_CODE_03.equals(lineArray[96])) {
                                    validateInputMenjo(BmaConstants.SKN_KSU_CODE_BC, BmaConstants.SHUBETSU_CODE_TWO, lineArray[97], BmaConstants.SKN_NAIYO_KBN_GAKKA_MENJO, groupCode, lineNo, 119, errorLog, errors);
                                } else if (BmaConstants.MNJ_CODE_05.equals(lineArray[96])) {
                                    validateInputMenjo(BmaConstants.SKN_KSU_CODE_BC, BmaConstants.SHUBETSU_CODE_TANITI, lineArray[97], BmaConstants.SKN_NAIYO_KBN_GAKKA_MENJO, groupCode, lineNo, 119, errorLog, errors);
                                }
                            }
                        }
                        break;
                    case BmaConstants.SKN_NAIYO_KBN_JITSUGI_MENJO:
                        // �Ə����i�R�[�h
                        if (!BmaValidator.validateRequired(lineArray[96], errors, groupCode, "")) {
                            this.createErrorLine(lineNo, 117, "�Ə����i�R�[�h", errors, errorLog);
                        } else {
                            String[] bc1MnjCode2 = {BmaConstants.MNJ_CODE_02, BmaConstants.MNJ_CODE_04, BmaConstants.MNJ_CODE_06};
                            // �I���`�F�b�N
                            if (!Arrays.asList(bc1MnjCode2).contains(lineArray[96])) {
                                BmaValidator.addMessage(errors, groupCode, BmaText.E00106, "");
                                this.createErrorLine(lineNo, 117, "�Ə����i�R�[�h", errors, errorLog);
                            }
                            // �Ə����i�ԍ�
                            // �K�v�`�F�b�N
                            if (!BmaValidator.validateRequired(lineArray[97], errors, groupCode, "")) {
                                this.createErrorLine(lineNo, 119, "�Ə����i�ԍ�", errors, errorLog);
                            } else {
                                // �����`�F�b�N
                                if (!BmaValidator.validateMaxLength(lineArray[97], 20, errors, groupCode, "")) {
                                    this.createErrorLine(lineNo, 119, "�Ə����i�ԍ�", errors, errorLog);
                                }
                                // �ԍ��`�F�b�N
                                if (BmaConstants.MNJ_CODE_02.equals(lineArray[96])) {
                                    validateInputMenjo(BmaConstants.SKN_KSU_CODE_BC, BmaConstants.SHUBETSU_CODE_ONE, lineArray[97], BmaConstants.SKN_NAIYO_KBN_JITSUGI_MENJO, groupCode, lineNo, 119, errorLog, errors);
                                } else if (BmaConstants.MNJ_CODE_04.equals(lineArray[96])) {
                                    validateInputMenjo(BmaConstants.SKN_KSU_CODE_BC, BmaConstants.SHUBETSU_CODE_TWO, lineArray[97], BmaConstants.SKN_NAIYO_KBN_JITSUGI_MENJO, groupCode, lineNo, 119, errorLog, errors);
                                } else if (BmaConstants.MNJ_CODE_06.equals(lineArray[96])) {
                                    validateInputMenjo(BmaConstants.SKN_KSU_CODE_BC, BmaConstants.SHUBETSU_CODE_TANITI, lineArray[97], BmaConstants.SKN_NAIYO_KBN_JITSUGI_MENJO, groupCode, lineNo, 119, errorLog, errors);
                                }
                            }
                        }
                        break;
                    default:
                        break;
                }
            } else if ((BmaConstants.SKN_KSU_CODE_BC.equals(lineArray[0]) && BmaConstants.SHUBETSU_CODE_THREE.equals(lineArray[1]))
                    || (BmaConstants.SKN_KSU_CODE_BE.equals(lineArray[0]) && BmaConstants.SHUBETSU_CODE_TWO.equals(lineArray[1]))) {
                // ���ƃt���O
                // �K�v�`�F�b�N
                if (!BmaValidator.validateRequired(lineArray[26], errors, groupCode, "")) {
                    this.createErrorLine(lineNo, 34, "���ƃt���O", errors, errorLog);
                } else {
                    // �I���`�F�b�N
                    if (!Arrays.asList(genmenFlg).contains(lineArray[26])) {
                        BmaValidator.addMessage(errors, groupCode, BmaText.E00106, "");
                        this.createErrorLine(lineNo, 34, "���ƃt���O", errors, errorLog);
                    }
                    // �N��`�F�b�N
                    try {
                        nenrei = service.calcAge(lineArray[3], lineArray[0], lineArray[1], lineArray[2], inSession.getMoshikomishaId(), lineArray[6]);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    if (35 <= Integer.parseInt(nenrei) && BmaConstants.FLG_ON.equals(lineArray[26])) {
                        BmaValidator.addMessage(errors, groupCode, "35�Έȏ�̕��͌��Ƒ[�u���󂯂��܂���B", "");
                        this.createErrorLine(lineNo, 34, "���ƃt���O", errors, errorLog);
                    }
                }

                // �O���t���O
                // �K�v�`�F�b�N
                if (!BmaValidator.validateRequired(lineArray[27], errors, groupCode, "")) {
                    this.createErrorLine(lineNo, 36, "�O���t���O", errors, errorLog);
                } else {
                    // �I���`�F�b�N
                    if (!Arrays.asList(gaijiFlg).contains(lineArray[27])) {
                        BmaValidator.addMessage(errors, groupCode, BmaText.E00106, "");
                        this.createErrorLine(lineNo, 36, "�O���t���O", errors, errorLog);
                    }
                }
                // �O���ڍ�
                if (!BmaValidator.validateMaxLength(lineArray[28], 200, errors, groupCode, "")) {
                    this.createErrorLine(lineNo, 38, "�O���ڍ�", errors, errorLog);
                }
                // ������`�F�b�N
                if (!BmaValidator.validateMojiCodeForBiko(lineArray[28], errors, groupCode, "")) {
                    this.createErrorLine(lineNo, 38, "�O���ڍ�", errors, errorLog);
                }

                // ���i�֘A�`�F�b�N
                // �r���N3���͐E���Ȃ��ł�OK
                if (BmaConstants.SKN_KSU_CODE_BE.equals(lineArray[0]) && BmaConstants.SHUBETSU_CODE_TWO.equals(lineArray[1])) {
                    if (lineArray[29].isEmpty()
                            && lineArray[35].isEmpty()
                            && lineArray[41].isEmpty()
                            && lineArray[47].isEmpty()
                            && lineArray[53].isEmpty()
                            && lineArray[59].isEmpty()
                            && lineArray[65].isEmpty()
                            && lineArray[71].isEmpty()
                            && lineArray[77].isEmpty()
                            && lineArray[83].isEmpty()) {
                        BmaValidator.addMessage(errors, groupCode, BmaText.E00015, "");
                        this.createErrorLine(lineNo, 39, "�E���P�i�Ζ���Ћy�ю��Ə��j", errors, errorLog);
                    }
                }
                if (!lineArray[29].isEmpty()) {
                    // �E���P
                    checkShokureki = new MskUploadJoho();
                    checkShokureki.setSknKsuCode(lineArray[0]);
                    checkShokureki.setKinmusakiKaishaName1(lineArray[29]);
                    checkShokureki.setBushoYakushokuName1(lineArray[30]);
                    checkShokureki.setShozaichi1(lineArray[31]);
                    checkShokureki.setShokumuNaiyo1(lineArray[32]);
                    checkShokureki.setZaisekikikanFrom1(lineArray[33]);
                    checkShokureki.setZaisekikikanTo1(lineArray[34]);

                    itemName = "�E���P";
                    shokurekiMonths += validateInputShokureki(checkShokureki, itemName, lineNo, 39, errorLog, errors);
                }
                if (!lineArray[35].isEmpty()) {
                    // �E���Q
                    checkShokureki = new MskUploadJoho();
                    checkShokureki.setSknKsuCode(lineArray[0]);
                    checkShokureki.setKinmusakiKaishaName1(lineArray[35]);
                    checkShokureki.setBushoYakushokuName1(lineArray[36]);
                    checkShokureki.setShozaichi1(lineArray[37]);
                    checkShokureki.setShokumuNaiyo1(lineArray[38]);
                    checkShokureki.setZaisekikikanFrom1(lineArray[39]);
                    checkShokureki.setZaisekikikanTo1(lineArray[40]);

                    itemName = "�E���Q";
                    shokurekiMonths += validateInputShokureki(checkShokureki, itemName, lineNo, 46, errorLog, errors);
                }
                if (!lineArray[41].isEmpty()) {
                    // �E���R
                    checkShokureki = new MskUploadJoho();
                    checkShokureki.setSknKsuCode(lineArray[0]);
                    checkShokureki.setKinmusakiKaishaName1(lineArray[41]);
                    checkShokureki.setBushoYakushokuName1(lineArray[42]);
                    checkShokureki.setShozaichi1(lineArray[43]);
                    checkShokureki.setShokumuNaiyo1(lineArray[44]);
                    checkShokureki.setZaisekikikanFrom1(lineArray[45]);
                    checkShokureki.setZaisekikikanTo1(lineArray[46]);

                    itemName = "�E���R";
                    shokurekiMonths += validateInputShokureki(checkShokureki, itemName, lineNo, 53, errorLog, errors);
                }
                if (!lineArray[47].isEmpty()) {
                    // �E���S
                    checkShokureki = new MskUploadJoho();
                    checkShokureki.setSknKsuCode(lineArray[0]);
                    checkShokureki.setKinmusakiKaishaName1(lineArray[47]);
                    checkShokureki.setBushoYakushokuName1(lineArray[48]);
                    checkShokureki.setShozaichi1(lineArray[49]);
                    checkShokureki.setShokumuNaiyo1(lineArray[50]);
                    checkShokureki.setZaisekikikanFrom1(lineArray[51]);
                    checkShokureki.setZaisekikikanTo1(lineArray[52]);

                    itemName = "�E���S";
                    shokurekiMonths += validateInputShokureki(checkShokureki, itemName, lineNo, 60, errorLog, errors);
                }
                if (!lineArray[53].isEmpty()) {
                    // �E���T
                    checkShokureki = new MskUploadJoho();
                    checkShokureki.setSknKsuCode(lineArray[0]);
                    checkShokureki.setKinmusakiKaishaName1(lineArray[53]);
                    checkShokureki.setBushoYakushokuName1(lineArray[54]);
                    checkShokureki.setShozaichi1(lineArray[55]);
                    checkShokureki.setShokumuNaiyo1(lineArray[56]);
                    checkShokureki.setZaisekikikanFrom1(lineArray[57]);
                    checkShokureki.setZaisekikikanTo1(lineArray[58]);

                    itemName = "�E���T";
                    shokurekiMonths += validateInputShokureki(checkShokureki, itemName, lineNo, 67, errorLog, errors);
                }
                if (!lineArray[59].isEmpty()) {
                    // �E���U
                    checkShokureki = new MskUploadJoho();
                    checkShokureki.setSknKsuCode(lineArray[0]);
                    checkShokureki.setKinmusakiKaishaName1(lineArray[59]);
                    checkShokureki.setBushoYakushokuName1(lineArray[60]);
                    checkShokureki.setShozaichi1(lineArray[61]);
                    checkShokureki.setShokumuNaiyo1(lineArray[62]);
                    checkShokureki.setZaisekikikanFrom1(lineArray[63]);
                    checkShokureki.setZaisekikikanTo1(lineArray[64]);

                    itemName = "�E���U";
                    shokurekiMonths += validateInputShokureki(checkShokureki, itemName, lineNo, 74, errorLog, errors);
                }
                if (!lineArray[65].isEmpty()) {
                    // �E���V
                    checkShokureki = new MskUploadJoho();
                    checkShokureki.setSknKsuCode(lineArray[0]);
                    checkShokureki.setKinmusakiKaishaName1(lineArray[65]);
                    checkShokureki.setBushoYakushokuName1(lineArray[66]);
                    checkShokureki.setShozaichi1(lineArray[67]);
                    checkShokureki.setShokumuNaiyo1(lineArray[68]);
                    checkShokureki.setZaisekikikanFrom1(lineArray[69]);
                    checkShokureki.setZaisekikikanTo1(lineArray[70]);

                    itemName = "�E���V";
                    shokurekiMonths += validateInputShokureki(checkShokureki, itemName, lineNo, 81, errorLog, errors);
                }
                if (!lineArray[71].isEmpty()) {
                    // �E���W
                    checkShokureki = new MskUploadJoho();
                    checkShokureki.setSknKsuCode(lineArray[0]);
                    checkShokureki.setKinmusakiKaishaName1(lineArray[71]);
                    checkShokureki.setBushoYakushokuName1(lineArray[72]);
                    checkShokureki.setShozaichi1(lineArray[73]);
                    checkShokureki.setShokumuNaiyo1(lineArray[74]);
                    checkShokureki.setZaisekikikanFrom1(lineArray[75]);
                    checkShokureki.setZaisekikikanTo1(lineArray[76]);

                    itemName = "�E���W";
                    shokurekiMonths += validateInputShokureki(checkShokureki, itemName, lineNo, 88, errorLog, errors);
                }
                if (!lineArray[77].isEmpty()) {
                    // �E���X
                    checkShokureki = new MskUploadJoho();
                    checkShokureki.setSknKsuCode(lineArray[0]);
                    checkShokureki.setKinmusakiKaishaName1(lineArray[77]);
                    checkShokureki.setBushoYakushokuName1(lineArray[78]);
                    checkShokureki.setShozaichi1(lineArray[79]);
                    checkShokureki.setShokumuNaiyo1(lineArray[80]);
                    checkShokureki.setZaisekikikanFrom1(lineArray[81]);
                    checkShokureki.setZaisekikikanTo1(lineArray[82]);

                    itemName = "�E���X";
                    shokurekiMonths += validateInputShokureki(checkShokureki, itemName, lineNo, 95, errorLog, errors);
                }
                if (!lineArray[83].isEmpty()) {
                    // �E���P�O
                    checkShokureki = new MskUploadJoho();
                    checkShokureki.setSknKsuCode(lineArray[0]);
                    checkShokureki.setKinmusakiKaishaName1(lineArray[83]);
                    checkShokureki.setBushoYakushokuName1(lineArray[84]);
                    checkShokureki.setShozaichi1(lineArray[85]);
                    checkShokureki.setShokumuNaiyo1(lineArray[86]);
                    checkShokureki.setZaisekikikanFrom1(lineArray[87]);
                    checkShokureki.setZaisekikikanTo1(lineArray[88]);

                    itemName = "�E���P�O";
                    shokurekiMonths += validateInputShokureki(checkShokureki, itemName, lineNo, 102, errorLog, errors);
                }
                        
                if (BmaConstants.SKN_KSU_CODE_BE.equals(lineArray[0]) && BmaConstants.SHUBETSU_CODE_TWO.equals(lineArray[1])) {
                    yearCount = shokurekiMonths / 12;
                    if (yearCount < 2) {
                        BmaValidator.addMessage(errors, groupCode, BmaText.E00054, "");
                        this.createErrorLine(lineNo, 39, "�E��", errors, errorLog);
                    }
                }

                switch (lineArray[24]) {
                    case BmaConstants.SKN_NAIYO_KBN_GAKKA_MENJO:
                        // �Ə����i�R�[�h
                        // �K�v�`�F�b�N
                        if (!BmaValidator.validateRequired(lineArray[89], errors, groupCode, "")) {
                            this.createErrorLine(lineNo, 109, "�Ə����i�R�[�h", errors, errorLog);
                        } else {
                            String[] bc1MnjCode1 = new String[5];
                            if (BmaConstants.SKN_KSU_CODE_BC.equals(lineArray[0])) {
                                bc1MnjCode1[0] = BmaConstants.MNJ_CODE_01;
                                bc1MnjCode1[1] = BmaConstants.MNJ_CODE_03;
                                bc1MnjCode1[2] = BmaConstants.MNJ_CODE_05;
                                bc1MnjCode1[3] = BmaConstants.MNJ_CODE_07;
                                bc1MnjCode1[4] = "";

                                // �I���`�F�b�N
                                if (!Arrays.asList(bc1MnjCode1).contains(lineArray[89])) {
                                    BmaValidator.addMessage(errors, groupCode, BmaText.E00106, "");
                                    this.createErrorLine(lineNo, 109, "�Ə����i�R�[�h", errors, errorLog);
                                }
                                // �Ə����i�ԍ�
                                // �K�v�`�F�b�N
                                if (!BmaValidator.validateRequired(lineArray[90], errors, groupCode, "")) {
                                    this.createErrorLine(lineNo, 111, "�Ə����i�ԍ�", errors, errorLog);
                                } else {
                                    // �����`�F�b�N
                                    if (!BmaValidator.validateMaxLength(lineArray[90], 20, errors, groupCode, "")) {
                                        this.createErrorLine(lineNo, 111, "�Ə����i�ԍ�", errors, errorLog);
                                    }
                                    // �ԍ��`�F�b�N
                                    if (BmaConstants.MNJ_CODE_01.equals(lineArray[89])) {
                                        validateInputMenjo(BmaConstants.SKN_KSU_CODE_BC, BmaConstants.SHUBETSU_CODE_ONE, lineArray[90], BmaConstants.SKN_NAIYO_KBN_GAKKA_MENJO, groupCode, lineNo, 111, errorLog, errors);
                                    } else if (BmaConstants.MNJ_CODE_03.equals(lineArray[89])) {
                                        validateInputMenjo(BmaConstants.SKN_KSU_CODE_BC, BmaConstants.SHUBETSU_CODE_TWO, lineArray[90], BmaConstants.SKN_NAIYO_KBN_GAKKA_MENJO, groupCode, lineNo, 111, errorLog, errors);
                                    } else if (BmaConstants.MNJ_CODE_05.equals(lineArray[89])) {
                                        validateInputMenjo(BmaConstants.SKN_KSU_CODE_BC, BmaConstants.SHUBETSU_CODE_THREE, lineArray[90], BmaConstants.SKN_NAIYO_KBN_GAKKA_MENJO, groupCode, lineNo, 111, errorLog, errors);
                                    } else if (BmaConstants.MNJ_CODE_07.equals(lineArray[89])) {
                                        validateInputMenjo(BmaConstants.SKN_KSU_CODE_BC, BmaConstants.SHUBETSU_CODE_TANITI, lineArray[90], BmaConstants.SKN_NAIYO_KBN_GAKKA_MENJO, groupCode, lineNo, 111, errorLog, errors);
                                    }
                                }
                            } else if (BmaConstants.SKN_KSU_CODE_BE.equals(lineArray[0])) {
                                bc1MnjCode1[0] = BmaConstants.MNJ_CODE_01;
                                bc1MnjCode1[1] = BmaConstants.MNJ_CODE_03;
                                bc1MnjCode1[2] = BmaConstants.MNJ_CODE_05;
                                bc1MnjCode1[3] = BmaConstants.MNJ_CODE_06;
                                bc1MnjCode1[4] = BmaConstants.MNJ_CODE_07;

                                // �I���`�F�b�N
                                if (!Arrays.asList(bc1MnjCode1).contains(lineArray[89])) {
                                    BmaValidator.addMessage(errors, groupCode, BmaText.E00106, "");
                                    this.createErrorLine(lineNo, 109, "�Ə����i�R�[�h", errors, errorLog);
                                }
                                if (BmaConstants.MNJ_CODE_01.equals(lineArray[89]) || BmaConstants.MNJ_CODE_03.equals(lineArray[89])) {
                                    // �Ə����i�ԍ�
                                    // �K�v�`�F�b�N
                                    if (!BmaValidator.validateRequired(lineArray[90], errors, groupCode, "")) {
                                        this.createErrorLine(lineNo, 109, "�Ə����i�ԍ�", errors, errorLog);
                                    } else {
                                        // �����`�F�b�N
                                        if (!BmaValidator.validateMaxLength(lineArray[90], 20, errors, groupCode, "")) {
                                            this.createErrorLine(lineNo, 111, "�Ə����i�ԍ�", errors, errorLog);
                                        }
                                        // �ԍ��`�F�b�N
                                        if (BmaConstants.MNJ_CODE_01.equals(lineArray[89])) {
                                            validateInputMenjo(BmaConstants.SKN_KSU_CODE_BE, BmaConstants.SHUBETSU_CODE_ONE, lineArray[90], BmaConstants.SKN_NAIYO_KBN_GAKKA_MENJO, groupCode, lineNo, 111, errorLog, errors);
                                        } else if (BmaConstants.MNJ_CODE_03.equals(lineArray[89])) {
                                            validateInputMenjo(BmaConstants.SKN_KSU_CODE_BE, BmaConstants.SHUBETSU_CODE_TWO, lineArray[90], BmaConstants.SKN_NAIYO_KBN_GAKKA_MENJO, groupCode, lineNo, 111, errorLog, errors);
                                        }
                                    }
                                }
                            }
                        }
                        break;
                    case BmaConstants.SKN_NAIYO_KBN_JITSUGI_MENJO:
                        // �K�v�`�F�b�N
                        if (!BmaValidator.validateRequired(lineArray[89], errors, groupCode, "")) {
                            this.createErrorLine(lineNo, 109, "�Ə����i�R�[�h", errors, errorLog);
                        } else {
                            String[] bc1MnjCode2 = new String[4];
                            bc1MnjCode2[0] = BmaConstants.MNJ_CODE_02;
                            bc1MnjCode2[1] = BmaConstants.MNJ_CODE_04;
                            // �Ə����i�R�[�h
                            if (BmaConstants.SKN_KSU_CODE_BC.equals(lineArray[0])) {
                                bc1MnjCode2[2] = BmaConstants.MNJ_CODE_06;
                                bc1MnjCode2[3] = BmaConstants.MNJ_CODE_08;
                            } else if (BmaConstants.SKN_KSU_CODE_BE.equals(lineArray[0])) {
                                bc1MnjCode2[2] = "";
                                bc1MnjCode2[3] = "";
                            }
                            // �I���`�F�b�N
                            if (!Arrays.asList(bc1MnjCode2).contains(lineArray[89])) {
                                BmaValidator.addMessage(errors, groupCode, BmaText.E00106, "");
                                this.createErrorLine(lineNo, 109, "�Ə����i�R�[�h", errors, errorLog);
                            }
                            // �Ə����i�ԍ�
                            // �K�v�`�F�b�N
                            if (!BmaValidator.validateRequired(lineArray[90], errors, groupCode, "")) {
                                this.createErrorLine(lineNo, 111, "�Ə����i�ԍ�", errors, errorLog);
                            } else {
                                // �����`�F�b�N
                                if (!BmaValidator.validateMaxLength(lineArray[90], 20, errors, groupCode, "")) {
                                    this.createErrorLine(lineNo, 111, "�Ə����i�ԍ�", errors, errorLog);
                                }
                                // �ԍ��`�F�b�N
                                if (BmaConstants.SKN_KSU_CODE_BC.equals(lineArray[0])) {
                                    if (BmaConstants.MNJ_CODE_02.equals(lineArray[89])) {
                                        validateInputMenjo(BmaConstants.SKN_KSU_CODE_BC, BmaConstants.SHUBETSU_CODE_ONE, lineArray[90], BmaConstants.SKN_NAIYO_KBN_JITSUGI_MENJO, groupCode, lineNo, 111, errorLog, errors);
                                    } else if (BmaConstants.MNJ_CODE_04.equals(lineArray[89])) {
                                        validateInputMenjo(BmaConstants.SKN_KSU_CODE_BC, BmaConstants.SHUBETSU_CODE_TWO, lineArray[90], BmaConstants.SKN_NAIYO_KBN_JITSUGI_MENJO, groupCode, lineNo, 111, errorLog, errors);
                                    } else if (BmaConstants.MNJ_CODE_06.equals(lineArray[89])) {
                                        validateInputMenjo(BmaConstants.SKN_KSU_CODE_BC, BmaConstants.SHUBETSU_CODE_THREE, lineArray[90], BmaConstants.SKN_NAIYO_KBN_JITSUGI_MENJO, groupCode, lineNo, 111, errorLog, errors);
                                    } else if (BmaConstants.MNJ_CODE_08.equals(lineArray[89])) {
                                        validateInputMenjo(BmaConstants.SKN_KSU_CODE_BC, BmaConstants.SHUBETSU_CODE_TANITI, lineArray[90], BmaConstants.SKN_NAIYO_KBN_JITSUGI_MENJO, groupCode, lineNo, 111, errorLog, errors);
                                    }
                                } else if (BmaConstants.SKN_KSU_CODE_BE.equals(lineArray[0])) {
                                    if (BmaConstants.MNJ_CODE_02.equals(lineArray[89])) {
                                        validateInputMenjo(BmaConstants.SKN_KSU_CODE_BE, BmaConstants.SHUBETSU_CODE_ONE, lineArray[90], BmaConstants.SKN_NAIYO_KBN_JITSUGI_MENJO, groupCode, lineNo, 111, errorLog, errors);
                                    } else if (BmaConstants.MNJ_CODE_04.equals(lineArray[89])) {
                                        validateInputMenjo(BmaConstants.SKN_KSU_CODE_BE, BmaConstants.SHUBETSU_CODE_TWO, lineArray[90], BmaConstants.SKN_NAIYO_KBN_JITSUGI_MENJO, groupCode, lineNo, 111, errorLog, errors);
                                    }
                                }
                            }
                        }
                        break;
                    default:
                        break;
                }
            }
        } else {
            List<MskKsuJoho> shiyoKaijoKsuList = inSession.getShiyoKaijoKsuList();
            int listNo1 = 0;
            int listNo2 = 0;
            int kuseiki1 = 0;
            int kuseiki2 = 0;
            String kaijocode1 = "";
            String kaijocode2 = "";
            for (int i = 0; i < shiyoKaijoKsuList.size(); i++) {
                if (shiyoKaijoKsuList.get(i).getKaijoId().equals(lineArray[24])) {
                    listNo1 = i;
                    kuseiki1 = Integer.parseInt(shiyoKaijoKsuList.get(i).getKuusekiSuu()) - 1;
                    kaijocode1 = shiyoKaijoKsuList.get(i).getKaijoCode();
                    break;
                }
            }
            for (int i = 0; i < shiyoKaijoKsuList.size(); i++) {
                if (shiyoKaijoKsuList.get(i).getKaijoId().equals(lineArray[25])) {
                    listNo2 = i;
                    kuseiki2 = Integer.parseInt(shiyoKaijoKsuList.get(i).getKuusekiSuu()) - 1;
                    kaijocode2 = shiyoKaijoKsuList.get(i).getKaijoCode();
                    break;
                }
            }
            // ���ID(����])
            // �K�v�`�F�b�N
            if (!BmaValidator.validateRequired(lineArray[24], errors, groupCode, "")) {
                this.createErrorLine(lineNo, 30, "���ID(��1��])", errors, errorLog);
            } else {
                // �����`�F�b�N
                if (!BmaValidator.validateEqualLength(lineArray[24], 2, errors, groupCode, "")) {
                    this.createErrorLine(lineNo, 30, "���ID(��1��])", errors, errorLog);
                }
                // ������`�F�b�N
                if (!BmaValidator.validateNumber(lineArray[24], errors, groupCode, "")) {
                    this.createErrorLine(lineNo, 30, "���ID(��1��])", errors, errorLog);
                } else {
                    // ���̑��݃`�F�b�N
                    if (BmaUtility.isNullOrEmpty(kaijocode1)) {
                        BmaValidator.addMessage(errors, groupCode, BmaText.E00079, "");
                        this.createErrorLine(lineNo, 30, "���ID(��1��])", errors, errorLog);
                    }
                }
            }
            // ���ID(����])
            // �K�v�`�F�b�N
            if (!BmaValidator.validateRequired(lineArray[25], errors, groupCode, "")) {
                this.createErrorLine(lineNo, 31, "���ID(��2��])", errors, errorLog);
            } else {
                // �����`�F�b�N
                if (!BmaValidator.validateEqualLength(lineArray[25], 2, errors, groupCode, "")) {
                    this.createErrorLine(lineNo, 31, "���ID(��2��])", errors, errorLog);
                }
                // ������`�F�b�N
                if (!BmaValidator.validateNumber(lineArray[25], errors, groupCode, "")) {
                    this.createErrorLine(lineNo, 31, "���ID(��2��])", errors, errorLog);
                } else {
                    // ���̑��݃`�F�b�N
                    if (BmaUtility.isNullOrEmpty(kaijocode2)) {
                        BmaValidator.addMessage(errors, groupCode, BmaText.E00079, "");
                        this.createErrorLine(lineNo, 31, "���ID(��2��])", errors, errorLog);
                    }
                }
                // ����]�Ƒ���]���قȂ��ꂩ�ǂ����`�F�b�N
                if (lineArray[25].equals(lineArray[24])) {
                    BmaValidator.addMessage(errors, groupCode, BmaText.E00078, "");
                    this.createErrorLine(lineNo, 30, "���ID", errors, errorLog);
                }
            }

            // ����]����
            if (!BmaUtility.isNullOrEmpty(kaijocode1) && !BmaUtility.isNullOrEmpty(kaijocode2) && !lineArray[25].equals(lineArray[24])) {
                if (kuseiki1 < 1 || kaijocode1.isEmpty()) {
                    // ����]����
                    if (kuseiki2 < 1 || kaijocode2.isEmpty()) {
                        BmaValidator.addMessage(errors, groupCode, BmaText.E00060, "");
                        this.createErrorLine(lineNo, 31, "���ID", errors, errorLog);
                    } else {
                        // ����]�̋�Ȑ������Z
                        shiyoKaijoKsuList.get(listNo2).setKuusekiSuu(String.valueOf(kuseiki2));
                    }
                } else {
                    // ����]�̋�Ȑ������Z
                    shiyoKaijoKsuList.get(listNo1).setKuusekiSuu(String.valueOf(kuseiki1));
                }
                inSession.setShiyoKaijoKsuList(shiyoKaijoKsuList);
            }

            // �O���t���O
            // �K�v�`�F�b�N
            if (!BmaValidator.validateRequired(lineArray[26], errors, groupCode, "")) {
                this.createErrorLine(lineNo, 32, "�O���t���O", errors, errorLog);
            } else {
                // �I���`�F�b�N
                if (!Arrays.asList(gaijiFlg).contains(lineArray[26])) {
                    BmaValidator.addMessage(errors, groupCode, BmaText.E00106, "");
                    this.createErrorLine(lineNo, 32, "�O���t���O", errors, errorLog);
                }
            }
            // �O���ڍ�
            if (!BmaValidator.validateMaxLength(lineArray[27], 200, errors, groupCode, "")) {
                this.createErrorLine(lineNo, 34, "�O���ڍ�", errors, errorLog);
            }
            // ������`�F�b�N
            if (!BmaValidator.validateMojiCodeForBiko(lineArray[27], errors, groupCode, "")) {
                this.createErrorLine(lineNo, 34, "�O���ڍ�", errors, errorLog);
            }

            if (BmaConstants.SKN_KSU_CODE_HC.equals(lineArray[0]) && BmaConstants.SHUBETSU_CODE_NEW.equals(lineArray[1])) {
                int iryoukikanDate = 0;
                if (lineArray[28].isEmpty()
                        && lineArray[34].isEmpty()
                        && lineArray[40].isEmpty()
                        && lineArray[46].isEmpty()
                        && lineArray[52].isEmpty()
                        && lineArray[58].isEmpty()
                        && lineArray[64].isEmpty()
                        && lineArray[70].isEmpty()
                        && lineArray[76].isEmpty()
                        && lineArray[82].isEmpty()) {
                    BmaValidator.addMessage(errors, groupCode, BmaText.E00015, "");
                    this.createErrorLine(lineNo, 35, "�E���P�i�Ζ���Ћy�ю��Ə��j", errors, errorLog);
                } else {
                    if (!lineArray[28].isEmpty()) {
                        // �E���P
                        checkShokureki = new MskUploadJoho();
                        checkShokureki.setSknKsuCode(lineArray[0]);
                        checkShokureki.setKinmusakiKaishaName1(lineArray[28]);
                        checkShokureki.setBushoYakushokuName1(lineArray[29]);
                        checkShokureki.setShozaichi1(lineArray[30]);
                        checkShokureki.setShokumuNaiyo1(lineArray[31]);
                        checkShokureki.setZaisekikikanFrom1(lineArray[32]);
                        checkShokureki.setZaisekikikanTo1(lineArray[33]);

                        itemName = "�E���P";
                        int months = validateInputShokureki(checkShokureki, itemName, lineNo, 35, errorLog, errors);
                        // ���o���N���ǉ�
                        shokurekiMonths += months;
                        // 05:��Ë@�ւȂ�΁A��Ìn�o�������ɒǉ�
                        if ("05".equals(checkShokureki.getShokumuNaiyo1())) {
                            iryoukikanDate += months;
                        }
                    }
                    if (!lineArray[34].isEmpty()) {
                        // �E���Q
                        checkShokureki = new MskUploadJoho();
                        checkShokureki.setSknKsuCode(lineArray[0]);
                        checkShokureki.setKinmusakiKaishaName1(lineArray[34]);
                        checkShokureki.setBushoYakushokuName1(lineArray[35]);
                        checkShokureki.setShozaichi1(lineArray[36]);
                        checkShokureki.setShokumuNaiyo1(lineArray[37]);
                        checkShokureki.setZaisekikikanFrom1(lineArray[38]);
                        checkShokureki.setZaisekikikanTo1(lineArray[39]);

                        itemName = "�E���Q";
                        int months = validateInputShokureki(checkShokureki, itemName, lineNo, 42, errorLog, errors);
                        shokurekiMonths += months;
                        if ("05".equals(checkShokureki.getShokumuNaiyo1())) {
                            iryoukikanDate += months;
                        }
                    }
                    if (!lineArray[40].isEmpty()) {
                        // �E���R
                        checkShokureki = new MskUploadJoho();
                        checkShokureki.setSknKsuCode(lineArray[0]);
                        checkShokureki.setKinmusakiKaishaName1(lineArray[40]);
                        checkShokureki.setBushoYakushokuName1(lineArray[41]);
                        checkShokureki.setShozaichi1(lineArray[42]);
                        checkShokureki.setShokumuNaiyo1(lineArray[43]);
                        checkShokureki.setZaisekikikanFrom1(lineArray[44]);
                        checkShokureki.setZaisekikikanTo1(lineArray[45]);

                        itemName = "�E���R";
                        int months = validateInputShokureki(checkShokureki, itemName, lineNo, 49, errorLog, errors);
                        shokurekiMonths += months;
                        if ("05".equals(checkShokureki.getShokumuNaiyo1())) {
                            iryoukikanDate += months;
                        }
                    }
                    if (!lineArray[46].isEmpty()) {
                        // �E���S
                        checkShokureki = new MskUploadJoho();
                        checkShokureki.setSknKsuCode(lineArray[0]);
                        checkShokureki.setKinmusakiKaishaName1(lineArray[46]);
                        checkShokureki.setBushoYakushokuName1(lineArray[47]);
                        checkShokureki.setShozaichi1(lineArray[48]);
                        checkShokureki.setShokumuNaiyo1(lineArray[49]);
                        checkShokureki.setZaisekikikanFrom1(lineArray[50]);
                        checkShokureki.setZaisekikikanTo1(lineArray[51]);

                        itemName = "�E���S";
                        int months = validateInputShokureki(checkShokureki, itemName, lineNo, 56, errorLog, errors);
                        shokurekiMonths += months;
                        if ("05".equals(checkShokureki.getShokumuNaiyo1())) {
                            iryoukikanDate += months;
                        }
                    }
                    if (!lineArray[52].isEmpty()) {
                        // �E���T
                        checkShokureki = new MskUploadJoho();
                        checkShokureki.setSknKsuCode(lineArray[0]);
                        checkShokureki.setKinmusakiKaishaName1(lineArray[52]);
                        checkShokureki.setBushoYakushokuName1(lineArray[53]);
                        checkShokureki.setShozaichi1(lineArray[54]);
                        checkShokureki.setShokumuNaiyo1(lineArray[55]);
                        checkShokureki.setZaisekikikanFrom1(lineArray[56]);
                        checkShokureki.setZaisekikikanTo1(lineArray[57]);

                        itemName = "�E���T";
                        int months = validateInputShokureki(checkShokureki, itemName, lineNo, 63, errorLog, errors);
                        shokurekiMonths += months;
                        if ("05".equals(checkShokureki.getShokumuNaiyo1())) {
                            iryoukikanDate += months;
                        }
                    }
                    if (!lineArray[58].isEmpty()) {
                        // �E���U
                        checkShokureki = new MskUploadJoho();
                        checkShokureki.setSknKsuCode(lineArray[0]);
                        checkShokureki.setKinmusakiKaishaName1(lineArray[58]);
                        checkShokureki.setBushoYakushokuName1(lineArray[59]);
                        checkShokureki.setShozaichi1(lineArray[60]);
                        checkShokureki.setShokumuNaiyo1(lineArray[61]);
                        checkShokureki.setZaisekikikanFrom1(lineArray[62]);
                        checkShokureki.setZaisekikikanTo1(lineArray[63]);

                        itemName = "�E���U";
                        int months = validateInputShokureki(checkShokureki, itemName, lineNo, 70, errorLog, errors);
                        shokurekiMonths += months;
                        if ("05".equals(checkShokureki.getShokumuNaiyo1())) {
                            iryoukikanDate += months;
                        }
                    }
                    if (!lineArray[64].isEmpty()) {
                        // �E���V
                        checkShokureki = new MskUploadJoho();
                        checkShokureki.setSknKsuCode(lineArray[0]);
                        checkShokureki.setKinmusakiKaishaName1(lineArray[64]);
                        checkShokureki.setBushoYakushokuName1(lineArray[65]);
                        checkShokureki.setShozaichi1(lineArray[66]);
                        checkShokureki.setShokumuNaiyo1(lineArray[67]);
                        checkShokureki.setZaisekikikanFrom1(lineArray[68]);
                        checkShokureki.setZaisekikikanTo1(lineArray[69]);

                        itemName = "�E���V";
                        int months = validateInputShokureki(checkShokureki, itemName, lineNo, 77, errorLog, errors);
                        shokurekiMonths += months;
                        if ("05".equals(checkShokureki.getShokumuNaiyo1())) {
                            iryoukikanDate += months;
                        }
                    }
                    if (!lineArray[70].isEmpty()) {
                        // �E���W
                        checkShokureki = new MskUploadJoho();
                        checkShokureki.setSknKsuCode(lineArray[0]);
                        checkShokureki.setKinmusakiKaishaName1(lineArray[70]);
                        checkShokureki.setBushoYakushokuName1(lineArray[71]);
                        checkShokureki.setShozaichi1(lineArray[72]);
                        checkShokureki.setShokumuNaiyo1(lineArray[73]);
                        checkShokureki.setZaisekikikanFrom1(lineArray[74]);
                        checkShokureki.setZaisekikikanTo1(lineArray[75]);

                        itemName = "�E���W";
                        int months = validateInputShokureki(checkShokureki, itemName, lineNo, 84, errorLog, errors);
                        shokurekiMonths += months;
                        if ("05".equals(checkShokureki.getShokumuNaiyo1())) {
                            iryoukikanDate += months;
                        }
                    }
                    if (!lineArray[76].isEmpty()) {
                        // �E���X
                        checkShokureki = new MskUploadJoho();
                        checkShokureki.setSknKsuCode(lineArray[0]);
                        checkShokureki.setKinmusakiKaishaName1(lineArray[76]);
                        checkShokureki.setBushoYakushokuName1(lineArray[77]);
                        checkShokureki.setShozaichi1(lineArray[78]);
                        checkShokureki.setShokumuNaiyo1(lineArray[79]);
                        checkShokureki.setZaisekikikanFrom1(lineArray[80]);
                        checkShokureki.setZaisekikikanTo1(lineArray[81]);

                        itemName = "�E���X";
                        int months = validateInputShokureki(checkShokureki, itemName, lineNo, 91, errorLog, errors);
                        shokurekiMonths += months;
                        if ("05".equals(checkShokureki.getShokumuNaiyo1())) {
                            iryoukikanDate += months;
                        }
                    }
                    if (!lineArray[82].isEmpty()) {
                        // �E���P�O
                        checkShokureki = new MskUploadJoho();
                        checkShokureki.setSknKsuCode(lineArray[0]);
                        checkShokureki.setKinmusakiKaishaName1(lineArray[82]);
                        checkShokureki.setBushoYakushokuName1(lineArray[83]);
                        checkShokureki.setShozaichi1(lineArray[84]);
                        checkShokureki.setShokumuNaiyo1(lineArray[85]);
                        checkShokureki.setZaisekikikanFrom1(lineArray[86]);
                        checkShokureki.setZaisekikikanTo1(lineArray[87]);

                        itemName = "�E���P�O";
                        int months = validateInputShokureki(checkShokureki, itemName, lineNo, 98, errorLog, errors);
                        shokurekiMonths += months;
                        if ("05".equals(checkShokureki.getShokumuNaiyo1())) {
                            iryoukikanDate += months;
                        }
                    }

                    yearCount = shokurekiMonths / 12;
                    // ���o���N��
                    if (yearCount < 3) {
                        BmaValidator.addMessage(errors, groupCode, BmaText.E00054, "");
                        this.createErrorLine(lineNo, 35, "�E��", errors, errorLog);
                    }
                    // ��Ë@�ւ̌o������
                    if (iryoukikanDate < 6) {
                        BmaValidator.addMessage(errors, groupCode, "��Ë@�ւ̐��|�Ɩ���6���������ł�", "");
                        this.createErrorLine(lineNo, 35, "�E��", errors, errorLog);
                    }
                }
            } else if ((BmaConstants.SKN_KSU_CODE_HC.equals(lineArray[0]) && BmaConstants.SHUBETSU_CODE_SAIKSU.equals(lineArray[1]))
                    || (BmaConstants.SKN_KSU_CODE_IP.equals(lineArray[0]) && BmaConstants.SHUBETSU_CODE_FOLLOW_UP.equals(lineArray[1]))) {
                // �K�v�`�F�b�N
                if (!BmaValidator.validateRequired(lineArray[28], errors, groupCode, "")) {
                    this.createErrorLine(lineNo, 35, "���i�ԍ��i�C���ԍ��j", errors, errorLog);
                } else {
                    // ���i�ԍ��i�C���ԍ��j
                    // �_�u��`�F�b�N
                    List<String> shuryouSkkNoList = inSession.getShuryouSkkNoList();
                    if (shuryouSkkNoList.contains(lineArray[28])) {
                        BmaValidator.addMessage(errors, groupCode, BmaText.E00101, "");
                        this.createErrorLine(lineNo, 35, "���i�ԍ��i�C���ԍ��j", errors, errorLog);
                    }
                    shuryouSkkNoList.add(lineArray[28]);
                    inSession.setShuryouSkkNoList(shuryouSkkNoList);
                    if (!BmaValidator.validateMaxLength(lineArray[28], 20, errors, groupCode, "")) {
                        this.createErrorLine(lineNo, 35, "���i�ԍ��i�C���ԍ��j", errors, errorLog);
                    }
                    HoyuShikakuMst hoyuShikakuMst = new HoyuShikakuMst(DATA_SOURCE_NAME);
                    hoyuShikakuMst = hoyuShikakuMst.getByGokakuNo(lineArray[0], lineArray[28]);
                    Map<String, HoyuShikakuMst> hoyuShikakuMstMapForUpdateBefore = inSession.getHoyuShikakuMstMapForUpdateBefore();
                    if (!BmaUtility.isNullOrEmpty(hoyuShikakuMst.getGokakuNo())) {
                        if (!hoyuShikakuMst.getBirthday().equals(lineArray[6])) {
                            BmaValidator.addMessage(errors, groupCode, BmaText.E00075, "���i�ԍ��i�C���ԍ��j");
                            this.createErrorLine(lineNo, 8, "���N����", errors, errorLog);
                        } else {
                            if (!hoyuShikakuMst.getFurigana().equals(lineArray[5])) {
                                // ���������擾
                                Torokusha torokusha = new Torokusha(DATA_SOURCE_NAME).find(hoyuShikakuMst.getMoshikomishaId());
                                if (torokusha != null && !BmaUtility.isNullOrEmpty(torokusha.getShimei())) {
                                    String torokuShimei = torokusha.getShimei();
                                    BmaValidator.addMessage(errors, groupCode, BmaText.E00081, torokuShimei, hoyuShikakuMst.getFurigana());
                                    this.createErrorLine(lineNo, 7, "�t���K�i�s��v", errors, errorLog);
                                    // ���i�ԍ���key�ɂ��ăZ�b�V�����ۑ�
                                    hoyuShikakuMstMapForUpdateBefore.put(lineArray[28], hoyuShikakuMst);
                                    inSession.setHoyuShikakuMstMapForUpdateBefore(hoyuShikakuMstMapForUpdateBefore);
                                } else {
                                    // �o�^�҃e�[�u���Ƀf�[�^�Ȃ�
                                    BmaValidator.addMessage(errors, groupCode, BmaText.E00082, "���i�ԍ��i�C���ԍ��j");
                                    this.createErrorLine(lineNo, 35, "���i�ԍ��i�C���ԍ��j", errors, errorLog);
                                }
                            } else {
                                // ���i�ԍ���key�ɂ��ăZ�b�V�����ۑ�
                                hoyuShikakuMstMapForUpdateBefore.put(lineArray[28], hoyuShikakuMst);
                                inSession.setHoyuShikakuMstMapForUpdateBefore(hoyuShikakuMstMapForUpdateBefore);
                            }
                        }
                    } else {
                        BmaValidator.addMessage(errors, groupCode, BmaText.E00076, "�ۗL���i");
                        this.createErrorLine(lineNo, 35, "���i�ԍ��i�C���ԍ��j", errors, errorLog);
                    }
                }

            } else if (BmaConstants.SKN_KSU_CODE_IP.equals(lineArray[0]) && BmaConstants.SHUBETSU_CODE_NEW.equals(lineArray[1])) {
                int shikakuCnt = 0;
                if (!lineArray[28].isEmpty()) {
                    shikakuCnt++;
                }
                if (!lineArray[29].isEmpty()) {
                    shikakuCnt++;
                }
                if (!lineArray[30].isEmpty()) {
                    shikakuCnt++;
                }
                if (!lineArray[31].isEmpty()) {
                    shikakuCnt++;
                }
                if (!lineArray[32].isEmpty()) {
                    shikakuCnt++;
                }
                if (shikakuCnt > 1) {
                    BmaValidator.addMessage(errors, groupCode, "�C���X�y�N�^�[������͂��Ă��������B", "");
                    this.createErrorLine(lineNo, 35, "�C���X�y�N�^�[������͂��Ă��������B", errors, errorLog);
                } else if (shikakuCnt == 0) {
                    BmaValidator.addMessage(errors, groupCode, "�C���X�y�N�^�[������͂��Ă��������B", "");
                    this.createErrorLine(lineNo, 35, "�C���X�y�N�^�[������͂��Ă��������B", errors, errorLog);
                }
                // �r���N���[�j���O�Z�\�m1��
                if (!lineArray[28].isEmpty()) {
                    // �����`�F�b�N
                    if (!BmaValidator.validateMaxLength(lineArray[28], 20, errors, groupCode, "")) {
                        this.createErrorLine(lineNo, 35, "�r���N���[�j���O�Z�\�m1��", errors, errorLog);
                    }
                    // �ԍ��`�F�b�N
                    validateInputShikaku(BmaConstants.SKN_KSU_CODE_BC, BmaConstants.SHUBETSU_CODE_ONE, lineArray[28], groupCode, lineNo, 35, errorLog, errors);
                    // �_�u��`�F�b�N
                    List<String> shikakuCode01List = inSession.getShikakuCode01List();
                    if (shikakuCode01List.contains(lineArray[28])) {
                        BmaValidator.addMessage(errors, groupCode, BmaText.E00101, "");
                        this.createErrorLine(lineNo, 35, "�r���N���[�j���O�Z�\�m1��", errors, errorLog);
                    }
                    shikakuCode01List.add(lineArray[28]);
                    inSession.setShikakuCode01List(shikakuCode01List);
                }
                if (!lineArray[29].isEmpty()) {
                    // �r���N���[�j���O�Z�\�m�P�ꓙ��
                    // �����`�F�b�N
                    if (!BmaValidator.validateMaxLength(lineArray[29], 20, errors, groupCode, "")) {
                        this.createErrorLine(lineNo, 36, "�r���N���[�j���O�Z�\�m�P�ꓙ��", errors, errorLog);
                    }
                    // �ԍ��`�F�b�N
                    validateInputShikaku(BmaConstants.SKN_KSU_CODE_BC, BmaConstants.SHUBETSU_CODE_TANITI, lineArray[29], groupCode, lineNo, 36, errorLog, errors);
                    // �_�u��`�F�b�N
                    List<String> shikakuCode02List = inSession.getShikakuCode02List();
                    if (shikakuCode02List.contains(lineArray[29])) {
                        BmaValidator.addMessage(errors, groupCode, BmaText.E00101, "");
                        this.createErrorLine(lineNo, 36, "�r���N���[�j���O�Z�\�m�P�ꓙ��", errors, errorLog);
                    }
                    shikakuCode02List.add(lineArray[29]);
                    inSession.setShikakuCode02List(shikakuCode02List);
                }
                if (!lineArray[30].isEmpty()) {
                    // ���|��Ɗē�
                    // �_�u��`�F�b�N
                    List<String> shikakuCode03List = inSession.getShikakuCode03List();
                    if (shikakuCode03List.contains(lineArray[30])) {
                        BmaValidator.addMessage(errors, groupCode, BmaText.E00101, "");
                        this.createErrorLine(lineNo, 37, "���|��Ɗē�", errors, errorLog);
                    }
                    // �����`�F�b�N
                    if (!BmaValidator.validateMaxLength1(lineArray[30], 20, errors, groupCode, "")) {
                        this.createErrorLine(lineNo, 37, "���|��Ɗē�", errors, errorLog);
                    }
                    shikakuCode03List.add(lineArray[30]);
                    inSession.setShikakuCode03List(shikakuCode03List);
                }
                if (!lineArray[31].isEmpty()) {
                    // ���z�����q���Ǘ��Z�p��
                    // �_�u��`�F�b�N
                    List<String> shikakuCode04List = inSession.getShikakuCode04List();
                    if (shikakuCode04List.contains(lineArray[31])) {
                        BmaValidator.addMessage(errors, groupCode, BmaText.E00101, "");
                        this.createErrorLine(lineNo, 38, "���z�����q���Ǘ��Z�p��", errors, errorLog);
                    }
                    // �����`�F�b�N
                    if (!BmaValidator.validateMaxLength1(lineArray[31], 20, errors, groupCode, "")) {
                        this.createErrorLine(lineNo, 38, "���z�����q���Ǘ��Z�p��", errors, errorLog);
                    }
                    shikakuCode04List.add(lineArray[31]);
                    inSession.setShikakuCode04List(shikakuCode04List);
                }
                if (!lineArray[32].isEmpty()) {
                    // �����Ǘ���
                    // �_�u��`�F�b�N
                    List<String> shikakuCode05List = inSession.getShikakuCode05List();
                    if (shikakuCode05List.contains(lineArray[32])) {
                        BmaValidator.addMessage(errors, groupCode, BmaText.E00101, "");
                        this.createErrorLine(lineNo, 39, "�����Ǘ���", errors, errorLog);
                    }
                    // �����`�F�b�N
                    if (!BmaValidator.validateMaxLength1(lineArray[32], 20, errors, groupCode, "")) {
                        this.createErrorLine(lineNo, 39, "�����Ǘ���", errors, errorLog);
                    }
                    shikakuCode05List.add(lineArray[28]);
                    inSession.setShikakuCode05List(shikakuCode05List);
                }
            }
        }

        createCsv(inRequest, inSession, errorLog);

        if (!errors.isEmpty()) {
            return false;
        } else {
            return true;
        }
    }

    /**
     * �󌟎��i���̓��̓`�F�b�N
     *
     * @param sknKsuCode ���i�ԍ��̎����u�K��R�[�h
     * @param shubetsuCode ���i�ԍ��̎�ʃR�[�h
     * @param checkGokakuNo ���̓`�F�b�N���鍇�i�ԍ�
     * @param groupCode �O���[�v�R�[�h
     * @param lineNo �s�ԍ�
     * @param stColumnNo ��ԍ�
     * @param errorLog �G���[���O
     * @param errors �G���[���b�Z�[�W
     */
    private void validateInputShikaku(String sknKsuCode, String shubetsuCode, String checkGokakuNo, String groupCode, long lineNo, long stColumnNo, List<ErrorMsg> errorLog, Messages errors) {
        Boolean checkResult = false;
        //�󌟒n�惊�X�g�F�k�C�A���k�A�����A�֓��A�����A�ߋE�A�����A�l���A��B
        List<String> jukenchikuList = new ArrayList<String>();
        jukenchikuList.add("����");
        jukenchikuList.add("�ߋE");
        if (BmaConstants.SKN_KSU_CODE_BC.equals(sknKsuCode)) {
            jukenchikuList.add("�k�C");
            jukenchikuList.add("���k");
            jukenchikuList.add("�֓�");
            jukenchikuList.add("����");
            jukenchikuList.add("����");
            jukenchikuList.add("�l��");
            jukenchikuList.add("��B");
        }
        /*�A�ԁA�����S���A0001�`9999 */
        List<String> renban4List = new ArrayList<String>();
        for (int i = 1; i <= 9999; i++) {
            renban4List.add(String.format("%04d", i));
        }

        if (checkGokakuNo.length() == 17) {
            switch (sknKsuCode + shubetsuCode) {
                // �r���N1���̍��i�ԍ�
                case BmaConstants.SKN_KSU_CODE_BC + BmaConstants.SHUBETSU_CODE_ONE:
                    if ("��".equals(checkGokakuNo.substring(0, 1))
                            && CheckUtility.isNumber(checkGokakuNo.substring(1, 3))
                            && "-1-".equals(checkGokakuNo.substring(3, 6))
                            && "120-".equals(checkGokakuNo.substring(6, 10))
                            && jukenchikuList.contains(checkGokakuNo.substring(10, 12))
                            && renban4List.contains(checkGokakuNo.substring(12, 16))
                            && "��".equals(checkGokakuNo.substring(16, 17))) {
                        checkResult = true;
                    }
                    break;
                // �r���N2���̍��i�ԍ�
                case BmaConstants.SKN_KSU_CODE_BC + BmaConstants.SHUBETSU_CODE_TWO:
                    if ("��".equals(checkGokakuNo.substring(0, 1))
                            && CheckUtility.isNumber(checkGokakuNo.substring(1, 3))
                            && "-2-".equals(checkGokakuNo.substring(3, 6))
                            && "120-".equals(checkGokakuNo.substring(6, 10))
                            && jukenchikuList.contains(checkGokakuNo.substring(10, 12))
                            && renban4List.contains(checkGokakuNo.substring(12, 16))
                            && "��".equals(checkGokakuNo.substring(16, 17))) {
                        checkResult = true;
                    }
                    break;
                // �r���N3���̍��i�ԍ�
                case BmaConstants.SKN_KSU_CODE_BC + BmaConstants.SHUBETSU_CODE_THREE:
                    if ("��".equals(checkGokakuNo.substring(0, 1))
                            && CheckUtility.isNumber(checkGokakuNo.substring(1, 3))
                            && "-3-".equals(checkGokakuNo.substring(3, 6))
                            && "120-".equals(checkGokakuNo.substring(6, 10))
                            && jukenchikuList.contains(checkGokakuNo.substring(10, 12))
                            && renban4List.contains(checkGokakuNo.substring(12, 16))
                            && "��".equals(checkGokakuNo.substring(16, 17))) {
                        checkResult = true;
                    }
                    break;
                // �P�ꓙ���̍��i�ԍ�
                case BmaConstants.SKN_KSU_CODE_BC + BmaConstants.SHUBETSU_CODE_TANITI:
                    if ("��".equals(checkGokakuNo.substring(0, 1))
                            && CheckUtility.isNumber(checkGokakuNo.substring(1, 3))
                            && "-�P-".equals(checkGokakuNo.substring(3, 6))
                            && "120-".equals(checkGokakuNo.substring(6, 10))
                            && jukenchikuList.contains(checkGokakuNo.substring(10, 12))
                            && renban4List.contains(checkGokakuNo.substring(12, 16))
                            && "��".equals(checkGokakuNo.substring(16, 17))) {
                        checkResult = true;
                    }
                    break;
                // �r����2���̍��i�ԍ�
                case BmaConstants.SKN_KSU_CODE_BE + BmaConstants.SHUBETSU_CODE_TWO:
                    if ("��".equals(checkGokakuNo.substring(0, 1))
                            && CheckUtility.isNumber(checkGokakuNo.substring(1, 3))
                            && "-2-".equals(checkGokakuNo.substring(3, 6))
                            && "165-".equals(checkGokakuNo.substring(6, 10))
                            && jukenchikuList.contains(checkGokakuNo.substring(10, 12))
                            && renban4List.contains(checkGokakuNo.substring(12, 16))
                            && "��".equals(checkGokakuNo.substring(16, 17))) {
                        checkResult = true;
                    }
                    break;
                default:
                    checkResult = false;
                    break;
            }
        }

        if (!checkResult) {
            BmaValidator.addMessage(errors, groupCode, "�󌟎��i�ԍ��̓��͂Ɍ�肪����܂��B", "");
            this.createErrorLine(lineNo, stColumnNo, "�󌟎��i�ԍ�", errors, errorLog);
        }
    }

    /**
     * �Ə����i���̓��̓`�F�b�N
     *
     * @param sknKsuCode ���i�ԍ��̎����u�K��R�[�h
     * @param shubetsuCode ���i�ԍ��̎�ʃR�[�h
     * @param checkGokakuNo ���̓`�F�b�N���鍇�i�ԍ�
     * @param shikenNaiyoKbn �������e�敪
     * @param groupCode �O���[�v�R�[�h
     * @param lineNo �s�ԍ�
     * @param stColumnNo ��ԍ�
     * @param errorLog �G���[���O
     * @param errors �G���[���b�Z�[�W
     */
    private void validateInputMenjo(String sknKsuCode, String shubetsuCode, String checkGokakuNo, String shikenNaiyoKbn, String groupCode, long lineNo, long stColumnNo, List<ErrorMsg> errorLog, Messages errors) {
        Boolean checkResult = false;
        //�󌟒n�惊�X�g�F�k�C�A���k�A�����A�֓��A�����A�ߋE�A�����A�l���A��B
        List<String> jukenchikuList = new ArrayList<String>();
        jukenchikuList.add("����");
        jukenchikuList.add("�ߋE");
        if (BmaConstants.SKN_KSU_CODE_BC.equals(sknKsuCode)) {
            jukenchikuList.add("�k�C");
            jukenchikuList.add("���k");
            jukenchikuList.add("�֓�");
            jukenchikuList.add("����");
            jukenchikuList.add("����");
            jukenchikuList.add("�l��");
            jukenchikuList.add("��B");
        }
        //���i�敪�F�ꕔ�i�w�ȁj�F�w�ȍ��i�A�ꕔ�i���Z�j�F���Z���i
        String gokakuKbn = "";
        if (BmaConstants.SKN_NAIYO_KBN_GAKKA_MENJO.equals(shikenNaiyoKbn)) {
            gokakuKbn = "�ꕔ�i�w�ȁj";
        } else {
            gokakuKbn = "�ꕔ�i���Z�j";
        }
        /*�A�ԁA�����R���A001�`999 */
        List<String> renban3List = new ArrayList<String>();
        for (int i = 1; i <= 999; i++) {
            renban3List.add(String.format("%03d", i));
        }

        if (checkGokakuNo.length() == 15) {
            switch (shubetsuCode) {
                // �r���N1���E�r����1���̈ꕔ���i�ԍ�
                case BmaConstants.SHUBETSU_CODE_ONE:
                    if (CheckUtility.isNumber(checkGokakuNo.substring(0, 2))
                            && "-1".equals(checkGokakuNo.substring(2, 4))
                            && gokakuKbn.equals(checkGokakuNo.substring(4, 10))
                            && jukenchikuList.contains(checkGokakuNo.substring(10, 12))
                            && renban3List.contains(checkGokakuNo.substring(12, 15))) {
                        checkResult = true;
                    }
                    break;
                // �r���N2���E�r����2���̈ꕔ���i�ԍ�
                case BmaConstants.SHUBETSU_CODE_TWO:
                    if (CheckUtility.isNumber(checkGokakuNo.substring(0, 2))
                            && "-2".equals(checkGokakuNo.substring(2, 4))
                            && gokakuKbn.equals(checkGokakuNo.substring(4, 10))
                            && jukenchikuList.contains(checkGokakuNo.substring(10, 12))
                            && renban3List.contains(checkGokakuNo.substring(12, 15))) {
                        checkResult = true;
                    }
                    break;
                // �r���N3���̈ꕔ���i�ԍ�
                case BmaConstants.SHUBETSU_CODE_THREE:
                    if (CheckUtility.isNumber(checkGokakuNo.substring(0, 2))
                            && "-3".equals(checkGokakuNo.substring(2, 4))
                            && gokakuKbn.equals(checkGokakuNo.substring(4, 10))
                            && jukenchikuList.contains(checkGokakuNo.substring(10, 12))
                            && renban3List.contains(checkGokakuNo.substring(12, 15))) {
                        checkResult = true;
                    }
                    break;
                // �P�ꓙ���̈ꕔ���i�ԍ�
                case BmaConstants.SHUBETSU_CODE_TANITI:
                    if (CheckUtility.isNumber(checkGokakuNo.substring(0, 2))
                            && "-�P".equals(checkGokakuNo.substring(2, 4))
                            && gokakuKbn.equals(checkGokakuNo.substring(4, 10))
                            && jukenchikuList.contains(checkGokakuNo.substring(10, 12))
                            && renban3List.contains(checkGokakuNo.substring(12, 15))) {
                        checkResult = true;
                    }
                    break;
                default:
                    checkResult = false;
                    break;
            }
        }

        if (!checkResult) {
            BmaValidator.addMessage(errors, groupCode, "�Ə����i�ԍ��̓��͂Ɍ�肪����܂��B", "");
            this.createErrorLine(lineNo, stColumnNo, "�Ə����i�ԍ�", errors, errorLog);
        }
    }

    /**
     * �E�����̓��̓`�F�b�N
     *
     * @param checkShokureki ���̓`�F�b�N����E��
     * @param itemName �`�F�b�N���ږ�
     * @param lineNo �s�ԍ�
     * @param stColumnNo �擪�̗�ԍ�
     * @param errorLog �G���[���O
     * @param errors �G���[���b�Z�[�W
     * @return �G���[�Ȃ��F�����o���̌����A�G���[����F0
     */
    private int validateInputShokureki(MskUploadJoho checkShokureki, String itemName, long lineNo, long stColumnNo, List<ErrorMsg> errorLog, Messages errors) {
        String groupCode = "fileInputCheck";
        Boolean result = true;
        int shokurekiMonths = 0;
        /*�E����e���X�g*/
        List<Option> shokumuNaiyoList = new ArrayList<Option>();
        if (BmaConstants.SKN_KSU_CODE_BC.equals(checkShokureki.getSknKsuCode())) {
            //�r���N�̏ꍇ
            shokumuNaiyoList.add(new Option("01", "���퐴�|"));
            shokumuNaiyoList.add(new Option("02", "������|"));
        } else if (BmaConstants.SKN_KSU_CODE_BE.equals(checkShokureki.getSknKsuCode())) {
            //�r���݂̏ꍇ
            shokumuNaiyoList.add(new Option("03", "�^�]"));
            shokumuNaiyoList.add(new Option("04", "�ێ�"));
        } else if (BmaConstants.SKN_KSU_CODE_HC.equals(checkShokureki.getSknKsuCode())) {
            //�r���݂̏ꍇ
            shokumuNaiyoList.add(new Option("05", "��Ë@��"));
            shokumuNaiyoList.add(new Option("06", "���̑�"));
        }
        try {
            //�S�p�ϊ����s
            checkShokureki.setKinmusakiKaishaName1(BmaStringUtility.convertHankakuToZenkakuBma(checkShokureki.getKinmusakiKaishaName1()));
            checkShokureki.setBushoYakushokuName1(BmaStringUtility.convertHankakuToZenkakuBma(checkShokureki.getBushoYakushokuName1()));
            checkShokureki.setShozaichi1(BmaStringUtility.convertHankakuToZenkakuBma(checkShokureki.getShozaichi1()));

            // �Ζ���Ћy�ю��Ə�
            if (!BmaValidator.validateRequired(checkShokureki.getKinmusakiKaishaName1(), errors, groupCode, "")) {
                this.createErrorLine(lineNo, stColumnNo, itemName + "�i�Ζ���Ћy�ю��Ə��j", errors, errorLog);
                result = false;
            } else {
                if (!BmaValidator.validateMaxLength(checkShokureki.getKinmusakiKaishaName1(), BmaConstants.MAX_LENGTH_SHIKUCHOSON_NAME, errors, groupCode, "")) {
                    this.createErrorLine(lineNo, stColumnNo, itemName + "�i�Ζ���Ћy�ю��Ə��j", errors, errorLog);
                    result = false;
                }
                if (!BmaValidator.validateMojiCode3(checkShokureki.getKinmusakiKaishaName1(), errors, groupCode, "")) {
                    this.createErrorLine(lineNo, stColumnNo, itemName + "�i�Ζ���Ћy�ю��Ə��j", errors, errorLog);
                    result = false;
                }
            }
            // ������E��
            if (!BmaValidator.validateRequired(checkShokureki.getBushoYakushokuName1(), errors, groupCode, "")) {
                this.createErrorLine(lineNo, stColumnNo + 1, itemName + "�i������E���j", errors, errorLog);
                result = false;
            } else {
                if (!BmaValidator.validateMaxLength(checkShokureki.getBushoYakushokuName1(), BmaConstants.MAX_LENGTH_SHIKUCHOSON_NAME, errors, groupCode, "")) {
                    this.createErrorLine(lineNo, stColumnNo + 1, itemName + "�i������E���j", errors, errorLog);
                    result = false;
                }
                if (!BmaValidator.validateMojiCode3(checkShokureki.getBushoYakushokuName1(), errors, groupCode, "")) {
                    this.createErrorLine(lineNo, stColumnNo + 1, itemName + "�i������E���j", errors, errorLog);
                    result = false;
                }
            }
            // ���ݒn
            if (!BmaValidator.validateRequired(checkShokureki.getShozaichi1(), errors, groupCode, "")) {
                this.createErrorLine(lineNo, stColumnNo + 2, itemName + "�i���ݒn�j", errors, errorLog);
                result = false;
            } else {
                if (!BmaValidator.validateMaxLength(checkShokureki.getShozaichi1(), BmaConstants.MAX_LENGTH_SHIKUCHOSON_NAME, errors, groupCode, "")) {
                    this.createErrorLine(lineNo, stColumnNo + 2, itemName + "�i���ݒn�j", errors, errorLog);
                    result = false;
                }
                if (!BmaValidator.validateMojiCode3(checkShokureki.getShozaichi1(), errors, groupCode, "")) {
                    this.createErrorLine(lineNo, stColumnNo + 2, itemName + "�i���ݒn�j", errors, errorLog);
                    result = false;
                }
            }
            // �E�����e
            if (!BmaValidator.validateRequired(checkShokureki.getShokumuNaiyo1(), errors, groupCode, "")) {
                this.createErrorLine(lineNo, stColumnNo + 3, itemName + "�i�E�����e�j", errors, errorLog);
                result = false;
            } else {
                if (!BmaValidator.validatePermissionSelect(checkShokureki.getShokumuNaiyo1(), shokumuNaiyoList, null, groupCode, itemName)) {
                    BmaValidator.addMessage(errors, groupCode, BmaText.E00106, "");
                    this.createErrorLine(lineNo, stColumnNo + 3, itemName + "�i�E�����e�j", errors, errorLog);
                    result = false;
                }
            }
            // �ݐЊ��ԊJ�n
            if (!BmaValidator.validateRequired(checkShokureki.getZaisekikikanFrom1(), errors, groupCode, "")) {
                this.createErrorLine(lineNo, stColumnNo + 5, itemName + "�i�ݐЊ��ԊJ�n�j", errors, errorLog);
                result = false;
            } else {
                if (!BmaValidator.validateEqualLength(checkShokureki.getZaisekikikanFrom1(), 6, errors, groupCode, "")) {
                    this.createErrorLine(lineNo, stColumnNo + 5, itemName + "�i�ݐЊ��ԊJ�n�j", errors, errorLog);
                    result = false;
                }
                if (!BmaValidator.validateDate(checkShokureki.getZaisekikikanFrom1() + "01", errors, groupCode, "")) {
                    this.createErrorLine(lineNo, stColumnNo + 5, itemName + "�i�ݐЊ��ԊJ�n�j", errors, errorLog);
                    result = false;
                }
            }
            // �ݐЊ��ԏI��
            if (!BmaValidator.validateRequired(checkShokureki.getZaisekikikanTo1(), errors, groupCode, "")) {
                this.createErrorLine(lineNo, stColumnNo + 6, itemName + "�i�ݐЊ��ԏI���j", errors, errorLog);
                result = false;
            } else {
                if (!BmaValidator.validateEqualLength(checkShokureki.getZaisekikikanTo1(), 6, errors, groupCode, "")) {
                    this.createErrorLine(lineNo, stColumnNo + 6, itemName + "�i�ݐЊ��ԏI���j", errors, errorLog);
                    result = false;
                }
                if (!BmaValidator.validateDate(checkShokureki.getZaisekikikanTo1() + "01", errors, groupCode, "")) {
                    this.createErrorLine(lineNo, stColumnNo + 6, itemName + "�i�ݐЊ��ԏI���j", errors, errorLog);
                    result = false;
                }
            }
            if (!BmaUtility.isNullOrEmpty(checkShokureki.getZaisekikikanFrom1()) && !BmaUtility.isNullOrEmpty(checkShokureki.getZaisekikikanTo1())) {
                if (checkShokureki.getZaisekikikanFrom1().compareTo(checkShokureki.getZaisekikikanTo1()) > 0) {
                    BmaValidator.addMessage(errors, groupCode, "�ݐЊ��ԊJ�n���ƍݐЊ��ԏI�������s�K�؂ł��B", "");
                    this.createErrorLine(lineNo, stColumnNo + 6, itemName + "�i�ݐЊ��ԏI���j", errors, errorLog);
                    result = false;
                }
            }
            
            // �G���[���Ȃ���΁A�����o���������v�Z
            if (result) {
                shokurekiMonths = shokurekiDate(checkShokureki.getZaisekikikanTo1(), checkShokureki.getZaisekikikanFrom1());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return shokurekiMonths;
    }

    /**
     * �w�����̓��̓`�F�b�N
     *
     * @param checkGakureki ���̓`�F�b�N����w��
     * @param groupCode �O���[�v�R�[�h
     * @param itemName �`�F�b�N���ږ�
     * @param lineNo �s�ԍ�
     * @param stColumnNo �擪�̗�ԍ�
     * @param errorLog �G���[���O
     * @param errors �G���[���b�Z�[�W
     */
    private void validateInputGakureki(MskUploadJoho checkGakureki, String groupCode, long lineNo, long stColumnNo, List<ErrorMsg> errorLog, Messages errors) {
        try {
            //�S�p�ϊ����s
            checkGakureki.setGakurekiName(BmaStringUtility.convertHankakuToZenkakuBma(checkGakureki.getGakurekiName()));
            checkGakureki.setGakurekiNaiyo(BmaStringUtility.convertHankakuToZenkakuBma(checkGakureki.getGakurekiNaiyo()));
            checkGakureki.setGakurekiShozaichi(BmaStringUtility.convertHankakuToZenkakuBma(checkGakureki.getGakurekiShozaichi()));

            // �w���i�w�Z���j
            if (!BmaValidator.validateRequired(checkGakureki.getGakurekiName(), errors, groupCode, "")) {
                this.createErrorLine(lineNo, stColumnNo, "�w���i�w�Z���j", errors, errorLog);
            } else {
                if (!BmaValidator.validateMaxLength(checkGakureki.getGakurekiName(), BmaConstants.MAX_LENGTH_SHIKUCHOSON_NAME, errors, groupCode, "")) {
                    this.createErrorLine(lineNo, stColumnNo, "�w���i�w�Z���j", errors, errorLog);
                }
                if (!BmaValidator.validateMojiCode3(checkGakureki.getGakurekiName(), errors, groupCode, "")) {
                    this.createErrorLine(lineNo, stColumnNo, "�w���i�w�Z���j", errors, errorLog);
                }
            }
            // �w���i�w�Ȗ��͉ے��j
            if (!BmaValidator.validateRequired(checkGakureki.getGakurekiNaiyo(), errors, groupCode, "")) {
                this.createErrorLine(lineNo, stColumnNo + 1, "�w���i�w�Ȗ��͉ے��j", errors, errorLog);
            } else {
                if (!BmaValidator.validateMaxLength(checkGakureki.getGakurekiNaiyo(), BmaConstants.MAX_LENGTH_SHIKUCHOSON_NAME, errors, groupCode, "")) {
                    this.createErrorLine(lineNo, stColumnNo + 1, "�w���i�w�Ȗ��͉ے��j", errors, errorLog);
                }
                if (!BmaValidator.validateMojiCode3(checkGakureki.getGakurekiNaiyo(), errors, groupCode, "")) {
                    this.createErrorLine(lineNo, stColumnNo + 1, "�w���i�w�Ȗ��͉ے��j", errors, errorLog);
                }
            }
            // �w���i���ݒn�j
            if (!BmaValidator.validateRequired(checkGakureki.getGakurekiShozaichi(), errors, groupCode, "")) {
                this.createErrorLine(lineNo, stColumnNo + 2, "�w���i���ݒn�j", errors, errorLog);
            } else {
                if (!BmaValidator.validateMaxLength(checkGakureki.getGakurekiShozaichi(), BmaConstants.MAX_LENGTH_SHIKUCHOSON_NAME, errors, groupCode, "")) {
                    this.createErrorLine(lineNo, stColumnNo + 2, "�w���i���ݒn�j", errors, errorLog);
                }
                if (!BmaValidator.validateMojiCode3(checkGakureki.getGakurekiShozaichi(), errors, groupCode, "")) {
                    this.createErrorLine(lineNo, stColumnNo + 2, "�w���i���ݒn�j", errors, errorLog);
                }
            }
            // �w���i���ƔN���j
            if (!BmaValidator.validateRequired(checkGakureki.getGakurekiDate(), errors, groupCode, "")) {
                this.createErrorLine(lineNo, stColumnNo + 3, "�w���i���ƔN���j", errors, errorLog);
            } else {
                if (!BmaValidator.validateEqualLength(checkGakureki.getGakurekiDate(), 6, errors, groupCode, "")) {
                    this.createErrorLine(lineNo, stColumnNo + 3, "�w���i���ƔN���j", errors, errorLog);
                }
                if (!BmaValidator.validateDate(checkGakureki.getGakurekiDate() + "01", errors, groupCode, "")) {
                    this.createErrorLine(lineNo, stColumnNo + 3, "�w���i���ƔN���j", errors, errorLog);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * �P�������̓��̓`�F�b�N
     *
     * @param checkKunrenreki ���̓`�F�b�N����P����
     * @param groupCode �O���[�v�R�[�h
     * @param itemName �`�F�b�N���ږ�
     * @param lineNo �s�ԍ�
     * @param stColumnNo �擪�̗�ԍ�
     * @param errorLog �G���[���O
     * @param errors �G���[���b�Z�[�W
     */
    private void validateInputKunrenreki(MskUploadJoho checkKunrenreki, String groupCode, long lineNo, long stColumnNo, List<ErrorMsg> errorLog, Messages errors) {
        try {            
            //�S�p�ϊ����s
           checkKunrenreki.setKurenrekiName(BmaStringUtility.convertHankakuToZenkakuBma(checkKunrenreki.getKurenrekiName()));
           checkKunrenreki.setKurenrekiNaiyo(BmaStringUtility.convertHankakuToZenkakuBma(checkKunrenreki.getKurenrekiNaiyo()));
           checkKunrenreki.setKurenrekiShozaichi(BmaStringUtility.convertHankakuToZenkakuBma(checkKunrenreki.getKurenrekiShozaichi()));

            // �P�����i�{�ݖ��j
            if (!BmaValidator.validateRequired(checkKunrenreki.getKurenrekiName(), errors, groupCode, "")) {
                this.createErrorLine(lineNo, stColumnNo, "�P�����i�{�ݖ��j", errors, errorLog);
            } else {
                if (!BmaValidator.validateMaxLength(checkKunrenreki.getKurenrekiName(), BmaConstants.MAX_LENGTH_SHIKUCHOSON_NAME, errors, groupCode, "")) {
                    this.createErrorLine(lineNo, stColumnNo, "�P�����i�{�ݖ��j", errors, errorLog);
                }
                if (!BmaValidator.validateMojiCode3(checkKunrenreki.getKurenrekiName(), errors, groupCode, "")) {
                    this.createErrorLine(lineNo, stColumnNo, "�P�����i�{�ݖ��j", errors, errorLog);
                }
            }
            // �P�����i�P���ȁj
            if (!BmaValidator.validateRequired(checkKunrenreki.getKurenrekiNaiyo(), errors, groupCode, "")) {
                this.createErrorLine(lineNo, stColumnNo + 1, "�P�����i�P���ȁj", errors, errorLog);
            } else {
                if (!BmaValidator.validateMaxLength(checkKunrenreki.getKurenrekiNaiyo(), BmaConstants.MAX_LENGTH_SHIKUCHOSON_NAME, errors, groupCode, "")) {
                    this.createErrorLine(lineNo, stColumnNo + 1, "�P�����i�P���ȁj", errors, errorLog);
                }
                if (!BmaValidator.validateMojiCode3(checkKunrenreki.getKurenrekiNaiyo(), errors, groupCode, "")) {
                    this.createErrorLine(lineNo, stColumnNo + 1, "�P�����i�P���ȁj", errors, errorLog);
                }
            }
            // �P�����i���ݒn�j
            if (!BmaValidator.validateRequired(checkKunrenreki.getKurenrekiShozaichi(), errors, groupCode, "")) {
                this.createErrorLine(lineNo, stColumnNo + 2, "�P�����i���ݒn�j", errors, errorLog);
            } else {
                if (!BmaValidator.validateMaxLength(checkKunrenreki.getKurenrekiShozaichi(), BmaConstants.MAX_LENGTH_SHIKUCHOSON_NAME, errors, groupCode, "")) {
                    this.createErrorLine(lineNo, stColumnNo + 2, "�P�����i���ݒn�j", errors, errorLog);
                }
                if (!BmaValidator.validateMojiCode3(checkKunrenreki.getKurenrekiShozaichi(), errors, groupCode, "")) {
                    this.createErrorLine(lineNo, stColumnNo + 2, "�P�����i���ݒn�j", errors, errorLog);
                }
            }
            // �P�����i�C���N���J�n�j
            if (!BmaValidator.validateRequired(checkKunrenreki.getKurenrekiFrom(), errors, groupCode, "")) {
                this.createErrorLine(lineNo, stColumnNo + 3, "�P�����i�C���N���J�n�j", errors, errorLog);
            } else {
                if (!BmaValidator.validateEqualLength(checkKunrenreki.getKurenrekiFrom(), 6, errors, groupCode, "")) {
                    this.createErrorLine(lineNo, stColumnNo + 3, "�P�����i�C���N���J�n�j", errors, errorLog);
                }
                if (!BmaValidator.validateDate(checkKunrenreki.getKurenrekiFrom() + "01", errors, groupCode, "")) {
                    this.createErrorLine(lineNo, stColumnNo + 3, "�P�����i�C���N���J�n�j", errors, errorLog);
                }
            }
            // �P�����i�C���N���I���j
            if (!BmaValidator.validateRequired(checkKunrenreki.getKurenrekiTo(), errors, groupCode, "")) {
                this.createErrorLine(lineNo, stColumnNo + 4, "�P�����i�C���N���I���j", errors, errorLog);
            } else {
                if (!BmaValidator.validateEqualLength(checkKunrenreki.getKurenrekiTo(), 6, errors, groupCode, "")) {
                    this.createErrorLine(lineNo, stColumnNo + 4, "�P�����i�C���N���I���j", errors, errorLog);
                }
                if (!BmaValidator.validateDate(checkKunrenreki.getKurenrekiTo() + "01", errors, groupCode, "")) {
                    this.createErrorLine(lineNo, stColumnNo + 4, "�P�����i�C���N���I���j", errors, errorLog);
                }
            }
            if (!BmaUtility.isNullOrEmpty(checkKunrenreki.getKurenrekiFrom()) && !BmaUtility.isNullOrEmpty(checkKunrenreki.getKurenrekiTo())) {
                if (checkKunrenreki.getKurenrekiFrom().compareTo(checkKunrenreki.getKurenrekiTo()) > 0) {
                    BmaValidator.addMessage(errors, groupCode, "�C���N���J�n���ƏC���N���I�������s�K�؂ł��B", "");
                    this.createErrorLine(lineNo, stColumnNo + 4, "�P�����i�C���N���I���j", errors, errorLog);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * ���i�����u���i��Z�N�̎����o���v�̔���
     *
     * @param gokakugoShokurekiCheckList �m�F����E�����X�g
     * @param gokakuNen ���i�N�i���2���j
     * @param gokakugoHitsuyoNensu ���i��ɕK�v�Ȏ����o���N��
     * @return result ���i��̔N���𖞂����Ă����true�A����ȊO��false
     */
    public Boolean checkGokakugoShokureki(List<MskUploadJoho> gokakugoShokurekiCheckList, String gokakuNen, int gokakugoHitsuyoNensu) {
        Boolean result = false;
        int gokakuNendo = 0;
        int cntMonthAll = 0;
        String gokakuDate = "";
        String dateFrom = "";
        String dateTo = "";
        String calcDateFrom = "";
        String calcDateTo = "";

        try {
            // ���i�ԍ�����A���i�N�������擾
            gokakuNendo = Integer.parseInt(GOKAKU_SHOKUREKI_NEN) + Integer.parseInt(gokakuNen);
            gokakuDate = String.valueOf(gokakuNendo) + GOKAKU_SHOKUREKI_TSUKIHI;

            //�E�����X�g��index �A�P����
            for (MskUploadJoho shokureki : gokakugoShokurekiCheckList) {
                dateFrom = shokureki.getZaisekikikanFrom1() + "01";
                dateTo = shokureki.getZaisekikikanTo1() + "01";

                if (dateTo.compareTo(gokakuDate) < 0) {
                    // ���i�ȑO�̐E����Skip
                    continue;
                }
                // �ݐЊ���From�Ɣ�r
                if (dateFrom.compareTo(gokakuDate) < 0) {
                    // ���i�N�������O�̐E���́A���i�N�������g�p
                    calcDateFrom = gokakuDate;
                } else {
                    // ���i�N�����ȍ~�̐E���́A�E��From���g�p
                    calcDateFrom = dateFrom;
                }
                // �ݐЊ���To�Ɣ�r
                if (dateTo.compareTo(gokakuDate) > 0) {
                    // ���i�N��������̐E���́A�E��To���g�p
                    calcDateTo = dateTo;
                } else {
                    // ���i�N�����ȑO�̐E���́A���i�N�������g�p
                    calcDateTo = gokakuDate;
                }
                cntMonthAll = cntMonthAll + BmaDateTimeUtility.differenceMonth(calcDateTo, calcDateFrom) + 1;
            }

            int skkYear = cntMonthAll / 12;
            // ���i��ɕK�v�Ȍo���N���𒴂��Ă����true��Ԃ�
            if (gokakugoHitsuyoNensu <= skkYear) {
                result = true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return result;
    }

    /**
     * �G���[���b�Z�[�W�s��ǉ�����B
     *
     * @param lineNo
     * @param errors
     * @param columnNo
     * @param itemName
     * @param errors
     * @param errorLog
     */
    private void createErrorLine(long lineNo, long columnNo, String itemName, Messages errors, List<ErrorMsg> errorLog) {
        ErrorMsg errorMsg = new ErrorMsg();
        Date date = new Date();
        SimpleDateFormat dt = new SimpleDateFormat("yyyyMMdd");
        SimpleDateFormat tm = new SimpleDateFormat("HHmmss");
        String koshinDate = dt.format(date);
        String koshinTime = tm.format(date);
        //�w�b�_�[�ǉ�
        //���e�ǉ�    
        errorMsg.lineNo = String.valueOf(lineNo);
        errorMsg.columnNo = CellReference.convertNumToColString((int) columnNo);
        errorMsg.itemName = itemName;
        List<Message> valueList = new ArrayList<>(errors.getMessages().values());
        List<String> messages = valueList.get(valueList.size() - 1).getMessage();
        String message = messages.get(messages.size() - 1);
        errorMsg.message = message;
        errorLog.add(errorMsg);
    }

    private int shokurekiDate(String shokurekiTo, String shokurekiFrom) throws ParseException {
        int shokurekiDate = 0;
        shokurekiDate = BmaDateTimeUtility.differenceMonth(shokurekiTo + "01", shokurekiFrom + "01")+ 1;
        return shokurekiDate;
    }

    private String createCsv(MskUploadJoho inRequest, MskUploadJoho inSession, List<ErrorMsg> errorLog) throws IOException {
        Date date = new Date();
        SimpleDateFormat dt = new SimpleDateFormat("yyyyMMdd");
        SimpleDateFormat tm = new SimpleDateFormat("HHmmss");
        String koshinDate = dt.format(date);
        String koshinTime = tm.format(date);
        SknksuMst sknksuMst = new SknksuMst(BmaConstants.DS_REGISTRANT);
        String sknKsuNameChi = sknksuMst.findSknKsuNameRyaku(inRequest.getSknKsuCode(),
                inRequest.getShubetsuCode(), inRequest.getKaisuCode()).getSknKsuNameRyaku();
        String path = BmaConstants.PHOTO_UPLOAD_PATH_TEMP;
        String fileName = sknKsuNameChi + "_" + "�c�̐\���f�[�^" + "_" + koshinDate + koshinTime + ".csv";
        // �w�b�_�[����
        inRequest.setHeader("Content-Disposition", String.format(Locale.JAPAN, "attachment; filename*=utf-8'jp'%s", URLEncoder.encode(fileName, "utf-8")));
        inRequest.setContentType("application/octet-stream;charset=" + BmaConstants.ENCODE_SHIFT_JIS);
        BufferedWriter bw = null;
        ByteArrayOutputStream outputStream = null;
        try {
            // �X�g���[������
            outputStream = new ByteArrayOutputStream();
            bw = new BufferedWriter(new OutputStreamWriter(outputStream, BmaConstants.ENCODE_SHIFT_JIS));
            for (int i = 0; i < errorLog.size(); i++) {
                if (i == 0) {
                    bw.write("�s�ԍ�");
                    bw.write(",");
                    bw.write("��ԍ�");
                    bw.write(",");
                    bw.write("���ږ�");
                    bw.write(",");
                    bw.write("�G���[���b�Z�[�W");
                    bw.write(",");
                    bw.write("\r\n");
                    bw.write(errorLog.get(i).lineNo);
                    bw.write(",");
                    bw.write(errorLog.get(i).columnNo);
                    bw.write(",");
                    bw.write(errorLog.get(i).itemName);
                    bw.write(",");
                    bw.write(errorLog.get(i).message);
                    bw.write(",");
                    bw.write("\r\n");
                } else {
                    bw.write(errorLog.get(i).lineNo);
                    bw.write(",");
                    bw.write(errorLog.get(i).columnNo);
                    bw.write(",");
                    bw.write(errorLog.get(i).itemName);
                    bw.write(",");
                    bw.write(errorLog.get(i).message);
                    bw.write(",");
                    bw.write("\r\n");
                }
            }
            bw.flush();
        } catch (Exception e) {
            log.error("CSV�o�͏����ŃG���[���������܂����B", e);
        } finally {
            if (bw != null) {
                bw.close();
            }
        }
        InputStream io = new ByteArrayInputStream(outputStream.toByteArray());
        inRequest.setInputStream(io);
        inRequest.setHeader("Content-Type", "charset=" + BmaConstants.ENCODE_SHIFT_JIS);
        inRequest.setContentType("text/csv; charset=" + BmaConstants.ENCODE_SHIFT_JIS);
        return DOWNLOAD;

    }
    // �G���[���b�Z�[�W�i�[�p

    public class ErrorMsg {

        String lineNo;
        String columnNo;
        String itemName;
        String message;
    }

    private void csvToroku(MskUploadJoho inRequest, MskUploadJoho inSession, MskUploadJoho torokuLine) {
        String sknKsuCode = torokuLine.getSknKsuCode();
        String shubetsuCode = torokuLine.getShubetsuCode();
        Moshikomi moshikomi = new Moshikomi(DATA_SOURCE_NAME);
        Torokusha torokusha = new Torokusha(DATA_SOURCE_NAME);
        MSkkMnjKanri mSkkMnjKanri = new MSkkMnjKanri();
        HoyuShikakuMst hoyuShikakuMst = new HoyuShikakuMst(DATA_SOURCE_NAME);
        Gazo gazo = new Gazo();
        List<String> inputGazoKbnList = new ArrayList<>();
        Shokureki shokureki = new Shokureki();

        List<Moshikomi> moshikomiListForInsert = inSession.getMoshikomiListForInsert();
        List<MSkkMnjKanri> mSkkMnjKanriListForInsert = inSession.getMSkkMnjKanriListForInsert();
        List<Torokusha> torokushaListForInsert = inSession.getTorokushaListForInsert();
        List<Gazo> gazoListForInsert = inSession.getGazoListForInsert();
        List<Shokureki> shokurekiListForInsert = inSession.getShokurekiListForInsert();
        Map<String, HoyuShikakuMst> hoyuShikakuMstMapForUpdate = inSession.getHoyuShikakuMstMapForUpdate();
        try {
            if ((BmaConstants.SKN_KSU_CODE_IP.equals(sknKsuCode) && BmaConstants.SHUBETSU_CODE_FOLLOW_UP.equals(shubetsuCode))
                    || (BmaConstants.SKN_KSU_CODE_HC.equals(sknKsuCode) && BmaConstants.SHUBETSU_CODE_SAIKSU.equals(shubetsuCode))) {
                // �\������o�^����
                /* �o�^���Z�b�g */
                CSVmoshikomiTrk2(moshikomi, inSession, torokuLine);
                moshikomiListForInsert.add(moshikomi);
                // ��t�ԍ��A�\����ID���擾
                torokuLine.setUketsukeNo(moshikomi.getUketsukeNo());
                torokuLine.setMoshikomishaId(moshikomi.getMoshikomishaId());
                // �\�����i�Ə��Ǘ���o�^����
                /* �o�^���Z�b�g */
                CSVskkmnjTrk2(mSkkMnjKanri, inSession, torokuLine);
                mSkkMnjKanriListForInsert.add(mSkkMnjKanri);
                // �摜��o�^����(��ʐ^�̂�)
                /* �o�^���Z�b�g */
                CSVgazoTrk2(gazo, inSession, torokuLine);
                gazoListForInsert.add(gazo);
                // �ۗL���i�}�X�^���X�V����
                CSVhoyuShiakuMstUpd(hoyuShikakuMst, inSession, torokuLine);
                /* �V�����\����ID��key��Map�փZ�b�g */
                hoyuShikakuMstMapForUpdate.put(torokuLine.getMoshikomishaId(), hoyuShikakuMst);
                // �o�^�҂�o�^����
                /* �o�^���Z�b�g */
                CSVtorokushaTrk(torokusha, inSession, torokuLine);
                torokushaListForInsert.add(torokusha);

                // IP(�t�H���[�A�b�v)�̏ꍇ�A�����c�񐔂̗L�����`�F�b�N�E���ێ�
                if (BmaConstants.SKN_KSU_CODE_IP.equals(sknKsuCode) && BmaConstants.SHUBETSU_CODE_FOLLOW_UP.equals(shubetsuCode)) {
                    String muryoZanCnt = hoyuShikakuMst.getMuryoZanCount();
                    if (!BmaUtility.isNullOrEmpty(muryoZanCnt)) {
                        if (Integer.parseInt(muryoZanCnt) > 0) {
                            HoyuShikakuMst muryoShikaku = new HoyuShikakuMst();
                            List<HoyuShikakuMst> hoyuShikakuMstMuryo = inSession.getHoyuShikakuMstMuryo();
                            BeanUtils.copyProperties(muryoShikaku, hoyuShikakuMst);
                            muryoShikaku.setMoshikomishaId(torokuLine.getMoshikomishaId());
                            hoyuShikakuMstMuryo.add(muryoShikaku);
                            inSession.setHoyuShikakuMstMuryo(hoyuShikakuMstMuryo);
                        }
                    }
                }
            } else {
                // �\������o�^����
                /* �o�^���Z�b�g */
                CSVmoshikomiTrk1(moshikomi, inSession, torokuLine);
                moshikomiListForInsert.add(moshikomi);
                //��t�ԍ���ۑ�����
                torokuLine.setUketsukeNo(moshikomi.getUketsukeNo());
                torokuLine.setMoshikomishaId(moshikomi.getMoshikomishaId());
                // �\�����i�Ə��Ǘ���o�^����
                /* �o�^���Z�b�g */
                CSVskkmnjTrk1(mSkkMnjKanri, inSession, torokuLine);
                mSkkMnjKanriListForInsert.add(mSkkMnjKanri);
                // �摜��o�^����
                /* �K�v�ȉ摜�敪�𔻒� */
                checkGazoKbn(inSession, mSkkMnjKanri, inputGazoKbnList);
                /* �o�^���Z�b�g */
                for (String gazoKbn : inputGazoKbnList) {
                    gazo = new Gazo();
                    CSVgazoTrk1(gazo, inSession, torokuLine, gazoKbn);
                    gazoListForInsert.add(gazo);
                }
                if (checkNeedGakureki(torokuLine)) {
                    // �w������o�^����
                    /* �o�^���Z�b�g */
                    shokureki = new Shokureki();
                    CSVgakurekiTrk(shokureki, inSession, torokuLine.getMoshikomishaId(), torokuLine);
                    shokurekiListForInsert.add(shokureki);
                }
                if (checkNeedKunrenreki(torokuLine)) {
                    // �P��������o�^����
                    /* �o�^���Z�b�g */
                    shokureki = new Shokureki();
                    CSVkurenrekiTrk(shokureki, inSession, torokuLine.getMoshikomishaId(), torokuLine);
                    shokurekiListForInsert.add(shokureki);
                }
                List<String> kinmusakiKaishaNameList = torokuLine.getKinmusakiKaishaNameList();
                int seq = 00;
                for (int i = 0; i < kinmusakiKaishaNameList.size(); i++) {
                    String kinmusakiKaishaName0 = null;
                    String bushoYakushokuName0 = null;
                    String shozaichi0 = null;
                    String shokumuNaiyo0 = null;
                    String zaisekikikanFrom0 = null;
                    String zaisekikikanTo0 = null;
                    if (!kinmusakiKaishaNameList.get(i).isEmpty()) {
                        Class<?> c = Class.forName("jp.co.nii.bma.business.rto.MskUploadJoho");
                        Method kinmusakiKaishaName = c.getMethod("getKinmusakiKaishaName" + (i + 1));
                        Method bushoYakushokuName = c.getMethod("getBushoYakushokuName" + (i + 1));
                        Method shozaichi = c.getMethod("getShozaichi" + (i + 1));
                        Method shokumuNaiyo = c.getMethod("getShokumuNaiyo" + (i + 1));
                        Method zaisekikikanFrom = c.getMethod("getZaisekikikanFrom" + (i + 1));
                        Method zaisekikikanTo = c.getMethod("getZaisekikikanTo" + (i + 1));
                        kinmusakiKaishaName0 = (String) kinmusakiKaishaName.invoke(torokuLine);
                        bushoYakushokuName0 = (String) bushoYakushokuName.invoke(torokuLine);
                        shozaichi0 = (String) shozaichi.invoke(torokuLine);
                        shokumuNaiyo0 = (String) shokumuNaiyo.invoke(torokuLine);
                        zaisekikikanFrom0 = (String) zaisekikikanFrom.invoke(torokuLine);
                        zaisekikikanTo0 = (String) zaisekikikanTo.invoke(torokuLine);
                    }
                    if (!kinmusakiKaishaNameList.get(i).isEmpty()) {
                        seq = seq + 1;
                        // �E������o�^����
                        /* �o�^���Z�b�g */
                        shokureki = new Shokureki();
                        CSVshokurekiTrk(shokureki, inSession, String.valueOf(seq), torokuLine,
                                kinmusakiKaishaName0, bushoYakushokuName0, shokumuNaiyo0, shozaichi0,
                                zaisekikikanFrom0, zaisekikikanTo0);
                        shokurekiListForInsert.add(shokureki);
                    }
                }
                // �o�^�҂�o�^����
                /* �o�^���Z�b�g */
                CSVtorokushaTrk(torokusha, inSession, torokuLine);
                torokushaListForInsert.add(torokusha);
            }
            // ����ʂ�DB�o�^�p�ɁA�Z�b�V�����ۑ�
            inSession.setMoshikomiListForInsert(moshikomiListForInsert);
            inSession.setMSkkMnjKanriListForInsert(mSkkMnjKanriListForInsert);
            inSession.setHoyuShikakuMstMapForUpdate(hoyuShikakuMstMapForUpdate);
            inSession.setTorokushaListForInsert(torokushaListForInsert);
            inSession.setGazoListForInsert(gazoListForInsert);
            inSession.setShokurekiListForInsert(shokurekiListForInsert);
        } catch (Exception ex) {
            // ���[���o�b�N
            rollbackTransaction();
        }
    }

    /**
     * �\������o�^����
     *
     * @param bo
     * @param inSession
     */
    public void CSVmoshikomiTrk1(Moshikomi bo, MskUploadJoho inSession, MskUploadJoho torokuLine) throws Exception {
        Saiban saiban = new SaibanService(DATA_SOURCE_NAME).getSaibanAndUpdate(BmaConstants.SAIBAN_TOROKUSHAID, inSession.getMoshikomishaId());

        bo.setMoshikomishaId(saiban.getGenzaiNo());
        bo.setNendo(torokuLine.getNendo());
        bo.setSknKsuCode(torokuLine.getSknKsuCode());
        bo.setShubetsuCode(torokuLine.getShubetsuCode());
        bo.setKaisuCode(torokuLine.getKaisuCode());
        if (BmaConstants.SKN_KBN.equals(inSession.getSknKsuKbn())) {
            bo.setKiboKaisaichiCode(torokuLine.getKiboShikenchi());
            bo.setKaijoCode1("");
            bo.setKaijoId2("");
        } else if (BmaConstants.KSU_KBN.equals(inSession.getSknKsuKbn())) {
            bo.setKiboKaisaichiCode("");
            bo.setKaijoId1(torokuLine.getKaijoId1());
            bo.setKaijoId2(torokuLine.getKaijoId2());
        }
        bo.setKaisaichiCode1("");
        bo.setKaijoCode1("");
        bo.setKyoshitsuCode1("");
        bo.setKaijoCode2("");
        bo.setKyoshitsuCode2("");
        bo.setMoshikomiKbn("1");
        bo.setKojinDantaiKbn("2");
        bo.setKaiinShinseiFlg("1");
        bo.setMoshikomiJokyoKbn("02");
        bo.setUnyoJokyoKbn("02");
        bo.setGohiJokyoKbn("");
        bo.setShomenUketsukeNo("");
        saiban = new SaibanService(DATA_SOURCE_NAME).getSaibanAndUpdate(BmaConstants.SAIBAN_NOID_UKETSUKENO_WEB, inSession.getMoshikomishaId());
        bo.setUketsukeNo(saiban.getGenzaiNo());
        bo.setJukenJukoNo("");
        if (BmaConstants.SKN_KBN.equals(inSession.getSknKsuKbn())) {
            bo.setShikenNaiyoKbn(torokuLine.getShikenNaiyoKbn());
        } else if (BmaConstants.KSU_KBN.equals(inSession.getSknKsuKbn())) {
            bo.setShikenNaiyoKbn("00");
        }
        bo.setSofuSakiKbn(torokuLine.getSofuSakiKbn());
        bo.setHairyoFlg("00");
        bo.setHairyoNaiyo("");
        if (torokuLine.getGenmenFlg().isEmpty()) {
            bo.setGenmenFlg("0");
        } else {
            bo.setGenmenFlg(torokuLine.getGenmenFlg());
        }
        bo.setNenrei(torokuLine.getNenrei());
        bo.setKariUketsukeBi("");
        bo.setKariUketsukeTime("");
        bo.setMoshikomiTorokuDate(inSession.getTorokuDate());
        bo.setMoshikomiTorokuTime(inSession.getTorokuTime());
        bo.setMoshikomiFinishBi("");
        bo.setMoshikomiFinishTime("");
        bo.setHoseiIraiKbn("1");
        bo.setKanriMemo("");
        bo.setKoshinKbn("I");
        bo.setTorokuDate(inSession.getTorokuDate());
        bo.setTorokuTime(inSession.getTorokuTime());
        bo.setTorokuUserId(inSession.getMoshikomishaId());
        bo.setKoshinDate("");
        bo.setKoshinTime("");
        bo.setKoshinUserId("");
        bo.setRonriSakujoFlg("0");
    }

    /**
     * �\������o�^����
     *
     * @param bo
     * @param inSession
     */
    public void CSVmoshikomiTrk2(Moshikomi bo, MskUploadJoho inSession, MskUploadJoho torokuLine) throws Exception {
        Saiban saiban = new SaibanService(DATA_SOURCE_NAME).getSaibanAndUpdate(BmaConstants.SAIBAN_TOROKUSHAID, inSession.getMoshikomishaId());

        bo.setMoshikomishaId(saiban.getGenzaiNo());
        bo.setNendo(torokuLine.getNendo());
        bo.setSknKsuCode(torokuLine.getSknKsuCode());
        bo.setShubetsuCode(torokuLine.getShubetsuCode());
        bo.setKaisuCode(torokuLine.getKaisuCode());
        bo.setKiboKaisaichiCode("");
        bo.setKaijoId1(torokuLine.getKaijoId1());
        bo.setKaisaichiCode1("");
        bo.setKaijoCode1("");
        bo.setKyoshitsuCode1("");
        bo.setKaijoId2(torokuLine.getKaijoId2());
        bo.setKaijoCode2("");
        bo.setKyoshitsuCode2("");
        bo.setMoshikomiKbn("1");
        bo.setKojinDantaiKbn("2");
        bo.setKaiinShinseiFlg("1");
        bo.setMoshikomiJokyoKbn("02");
        bo.setUnyoJokyoKbn("02");
        bo.setGohiJokyoKbn("");
        bo.setShomenUketsukeNo("");
        saiban = new SaibanService(DATA_SOURCE_NAME).getSaibanAndUpdate(BmaConstants.SAIBAN_NOID_UKETSUKENO_WEB, inSession.getMoshikomishaId());
        bo.setUketsukeNo(saiban.getGenzaiNo());
        bo.setJukenJukoNo("");
        bo.setShikenNaiyoKbn("00");
        bo.setSofuSakiKbn(torokuLine.getSofuSakiKbn());
        bo.setHairyoFlg("00");
        bo.setHairyoNaiyo("");
        bo.setGenmenFlg("0");
        bo.setNenrei(torokuLine.getNenrei());
        bo.setKariUketsukeBi("");
        bo.setKariUketsukeTime("");
        bo.setMoshikomiTorokuDate(inSession.getTorokuDate());
        bo.setMoshikomiTorokuTime(inSession.getTorokuTime());
        bo.setMoshikomiFinishBi("");
        bo.setMoshikomiFinishTime("");
        bo.setHoseiIraiKbn("1");
        bo.setKanriMemo("");
        bo.setKoshinKbn("I");
        bo.setTorokuDate(inSession.getTorokuDate());
        bo.setTorokuTime(inSession.getTorokuTime());
        bo.setTorokuUserId(inSession.getMoshikomishaId());
        bo.setKoshinDate("");
        bo.setKoshinTime("");
        bo.setKoshinUserId("");
        bo.setRonriSakujoFlg("0");
    }

    /**
     * �摜����o�^����
     *
     * @param bo
     * @param inSession
     */
    public void CSVgazoTrk1(Gazo bo, MskUploadJoho inSession, MskUploadJoho torokuLine, String gazoKbn) throws Exception {
        Saiban saiban = new SaibanService(DATA_SOURCE_NAME).getSaibanAndUpdate(BmaConstants.SAIBAN_GAZOIDX, inSession.getMoshikomishaId());
        bo.setGazoIdx(saiban.getGenzaiNo());
        bo.setNendo(torokuLine.getNendo());
        bo.setUketsukeNo(torokuLine.getUketsukeNo());
        bo.setGazoKbn(gazoKbn);
        bo.setSeq("01");
        bo.setHoseiIraiKbn("1");
        bo.setGazoHyojiKbn("4");
        bo.setHoseiIraiBi("");
        bo.setHoseiIraiTime("");
        bo.setHoseiIraiCode1("");
        bo.setHoseiIraiCode2("");
        bo.setHoseiIraiCode3("");
        bo.setHoseiTaioBi("");
        bo.setHoseiTaioTime("");
        bo.setHoseiFinishBi("");
        bo.setHoseiFinishTime("");
        bo.setHoseiIraiMailSoshinFlg("0");
        bo.setHoseiKigenBi("");
        bo.setKoshinKbn("I");
        bo.setTorokuDate(inSession.getTorokuDate());
        bo.setTorokuTime(inSession.getTorokuTime());
        bo.setTorokuUserId(inSession.getMoshikomishaId());
        bo.setKoshinDate("");
        bo.setKoshinTime("");
        bo.setKoshinUserId("");
        bo.setRonriSakujoFlg("0");
    }

    /**
     * �摜����o�^����
     *
     * @param bo
     * @param inSession
     */
    public void CSVgazoTrk2(Gazo bo, MskUploadJoho inSession, MskUploadJoho torokuLine) throws Exception {
        Saiban saiban = new SaibanService(DATA_SOURCE_NAME).getSaibanAndUpdate(BmaConstants.SAIBAN_GAZOIDX, inSession.getMoshikomishaId());
        bo.setGazoIdx(saiban.getGenzaiNo());
        bo.setNendo(torokuLine.getNendo());
        bo.setUketsukeNo(torokuLine.getUketsukeNo());
        bo.setGazoKbn("00");
        bo.setSeq("01");
        bo.setHoseiIraiKbn("1");
        bo.setGazoHyojiKbn("4");
        bo.setHoseiIraiBi("");
        bo.setHoseiIraiTime("");
        bo.setHoseiIraiCode1("");
        bo.setHoseiIraiCode2("");
        bo.setHoseiIraiCode3("");
        bo.setHoseiTaioBi("");
        bo.setHoseiTaioTime("");
        bo.setHoseiFinishBi("");
        bo.setHoseiFinishTime("");
        bo.setHoseiIraiMailSoshinFlg("0");
        bo.setHoseiKigenBi("");
        bo.setKoshinKbn("I");
        bo.setTorokuDate(inSession.getTorokuDate());
        bo.setTorokuTime(inSession.getTorokuTime());
        bo.setTorokuUserId(inSession.getMoshikomishaId());
        bo.setKoshinDate("");
        bo.setKoshinTime("");
        bo.setKoshinUserId("");
        bo.setRonriSakujoFlg("0");
    }

    /**
     * �\���Ə��Ǘ���o�^����
     *
     * @param bo
     * @param inSession
     */
    public void CSVskkmnjTrk1(MSkkMnjKanri bo, MskUploadJoho inSession, MskUploadJoho torokuLine) throws Exception {
        bo.setNendo(torokuLine.getNendo());
        bo.setUketsukeNo(torokuLine.getUketsukeNo());

        // �����u�K��ƂɁA���i�R�[�h�Ɛ\�����i�ԍ����Z�b�g
        if (   BmaConstants.SKN_KSU_CODE_BC.equals(inSession.getSknKsuCode()) && BmaConstants.SHUBETSU_CODE_THREE.equals(inSession.getShubetsuCode())
            || BmaConstants.SKN_KSU_CODE_BE.equals(inSession.getSknKsuCode()) && BmaConstants.SHUBETSU_CODE_TWO.equals(inSession.getShubetsuCode())
            || BmaConstants.SKN_KSU_CODE_HC.equals(inSession.getSknKsuCode()) && BmaConstants.SHUBETSU_CODE_NEW.equals(inSession.getShubetsuCode())) {
            bo.setShikakuCode("0001");
            bo.setShinseiShikakuNo(torokuLine.getShuryouSkkNo());
        } else if (BmaConstants.SKN_KSU_CODE_IP.equals(inSession.getSknKsuCode()) && BmaConstants.SHUBETSU_CODE_NEW.equals(inSession.getShubetsuCode())) {
            if (!BmaUtility.isNullOrEmpty(torokuLine.getShikakuCode01())) {
                bo.setShikakuCode("0001");
                bo.setShinseiShikakuNo(torokuLine.getShikakuCode01());
            } else if (!BmaUtility.isNullOrEmpty(torokuLine.getShikakuCode02())) {
                bo.setShikakuCode("0002");
                bo.setShinseiShikakuNo(torokuLine.getShikakuCode02());
            } else if (!BmaUtility.isNullOrEmpty(torokuLine.getShikakuCode03())) {
                bo.setShikakuCode("0003");
                bo.setShinseiShikakuNo(torokuLine.getShikakuCode03());
            } else if (!BmaUtility.isNullOrEmpty(torokuLine.getShikakuCode04())) {
                bo.setShikakuCode("0004");
                bo.setShinseiShikakuNo(torokuLine.getShikakuCode04());
            } else if (!BmaUtility.isNullOrEmpty(torokuLine.getShikakuCode05())) {
                bo.setShikakuCode("0005");
                bo.setShinseiShikakuNo(torokuLine.getShikakuCode05());
            }
        } else {
            bo.setShikakuCode(torokuLine.getJukenSkkCode());
            bo.setShinseiShikakuNo(torokuLine.getJukenSkkNo());
        }

        bo.setMenjoCode(torokuLine.getMenjoSkkCode());
        bo.setShinseiMenjoNo(torokuLine.getMenjoSkkNo());
        bo.setKoshinKbn("I");
        bo.setTorokuDate(inSession.getTorokuDate());
        bo.setTorokuTime(inSession.getTorokuTime());
        bo.setTorokuUserId(inSession.getMoshikomishaId());
        bo.setKoshinDate("");
        bo.setKoshinTime("");
        bo.setKoshinUserId("");
        bo.setRonriSakujoFlg("0");
    }

    /**
     * �\���Ə��Ǘ���o�^����
     *
     * @param bo
     * @param inSession
     */
    public void CSVskkmnjTrk2(MSkkMnjKanri bo, MskUploadJoho inSession, MskUploadJoho torokuLine) throws Exception {
        bo.setNendo(torokuLine.getNendo());
        bo.setUketsukeNo(torokuLine.getUketsukeNo());
        bo.setShikakuCode("0000");
        bo.setShinseiShikakuNo(torokuLine.getShuryouSkkNo());
        bo.setMenjoCode("");
        bo.setShinseiMenjoNo("");
        bo.setKoshinKbn("I");
        bo.setTorokuDate(inSession.getTorokuDate());
        bo.setTorokuTime(inSession.getTorokuTime());
        bo.setTorokuUserId(inSession.getMoshikomishaId());
        bo.setKoshinDate("");
        bo.setKoshinTime("");
        bo.setKoshinUserId("");
        bo.setRonriSakujoFlg("0");
    }

    /**
     * �ۗL���i�}�X�^���X�V����i�\����ID�ȊO�j
     *
     * @param bo
     * @param inSession
     */
    public void CSVhoyuShiakuMstUpd(HoyuShikakuMst bo, MskUploadJoho inSession, MskUploadJoho torokuLine) throws Exception {
        HoyuShikakuMst hoyuShikakuMst = inSession.getHoyuShikakuMstMapForUpdateBefore().get(torokuLine.getShuryouSkkNo());
        BeanUtils.copyProperties(bo, hoyuShikakuMst);

        bo.setKoshinKbn("U");
        bo.setKoshinDate(inSession.getTorokuDate());
        bo.setKoshinTime(inSession.getTorokuTime());
        bo.setKoshinUserId(inSession.getMoshikomishaId());
        bo.setRonriSakujoFlg("0");
    }

    /**
     * �w����o�^����
     *
     * @param bo
     * @param inSession
     * @param moshikomiId
     * @throws java.lang.Exception
     */
    public void CSVgakurekiTrk(Shokureki bo, MskUploadJoho inSession, String moshikomiId, MskUploadJoho torokuLine) throws Exception {
        bo.setNendo(torokuLine.getNendo());
        bo.setUketsukeNo(torokuLine.getUketsukeNo());
        bo.setMoshikomishaId(moshikomiId);
        bo.setShokurekiKbn("3");
        bo.setShokurekiSeq("01");
        bo.setKinmusakiKaishaName(torokuLine.getGakurekiName());
        bo.setBushoYakushokuName(torokuLine.getGakurekiNaiyo());
        bo.setShokumuNaiyo("");
        bo.setShozaichi(torokuLine.getGakurekiShozaichi());
        bo.setZaisekikikanFrom("");
        bo.setZaisekikikanTo(torokuLine.getGakurekiDate());
        bo.setKoshinKbn("I");
        bo.setTorokuDate(inSession.getTorokuDate());
        bo.setTorokuTime(inSession.getTorokuTime());
        bo.setTorokuUserId(inSession.getMoshikomishaId());
        bo.setKoshinDate("");
        bo.setKoshinTime("");
        bo.setKoshinUserId("");
        bo.setRonriSakujoFlg("0");
    }

    /**
     * �P������o�^����
     *
     * @param bo
     * @param inSession
     * @param moshikomiId
     * @throws java.lang.Exception
     */
    public void CSVkurenrekiTrk(Shokureki bo, MskUploadJoho inSession, String moshikomiId, MskUploadJoho torokuLine) throws Exception {
        bo.setNendo(torokuLine.getNendo());
        bo.setUketsukeNo(torokuLine.getUketsukeNo());
        bo.setMoshikomishaId(moshikomiId);
        bo.setShokurekiKbn("4");
        bo.setShokurekiSeq("01");
        bo.setKinmusakiKaishaName(torokuLine.getKurenrekiName());
        bo.setBushoYakushokuName(torokuLine.getKurenrekiNaiyo());
        bo.setShokumuNaiyo("");
        bo.setShozaichi(torokuLine.getKurenrekiShozaichi());
        bo.setZaisekikikanFrom(torokuLine.getKurenrekiFrom());
        bo.setZaisekikikanTo(torokuLine.getKurenrekiTo());
        bo.setKoshinKbn("I");
        bo.setTorokuDate(inSession.getTorokuDate());
        bo.setTorokuTime(inSession.getTorokuTime());
        bo.setTorokuUserId(inSession.getMoshikomishaId());
        bo.setKoshinDate("");
        bo.setKoshinTime("");
        bo.setKoshinUserId("");
        bo.setRonriSakujoFlg("0");
    }

    /**
     * �E����o�^����
     *
     * @param bo
     * @param inSession
     * @param seq
     * @param moshikomiId
     * @param kinmusakiKaishaName
     * @param shokumuNaiyo
     * @param bushoYakushokuName
     * @param shozaichi
     * @param zaisekikikanFrom
     * @param zaisekikikanTo
     * @throws java.lang.Exception
     */
    public void CSVshokurekiTrk(Shokureki bo, MskUploadJoho inSession, String seq, MskUploadJoho torokuLine, String kinmusakiKaishaName,
            String bushoYakushokuName, String shokumuNaiyo, String shozaichi, String zaisekikikanFrom, String zaisekikikanTo) throws Exception {
        bo.setNendo(torokuLine.getNendo());
        bo.setUketsukeNo(torokuLine.getUketsukeNo());
        bo.setMoshikomishaId(torokuLine.getMoshikomishaId());
        bo.setShokurekiKbn("1");
        bo.setShokurekiSeq(String.format("%2s", seq).replace(' ', '0'));
        bo.setKinmusakiKaishaName(kinmusakiKaishaName);
        bo.setBushoYakushokuName(bushoYakushokuName);
        bo.setShokumuNaiyo(shokumuNaiyo);
        bo.setShozaichi(shozaichi);
        bo.setZaisekikikanFrom(zaisekikikanFrom);
        bo.setZaisekikikanTo(zaisekikikanTo);
        bo.setKoshinKbn("I");
        bo.setTorokuDate(inSession.getTorokuDate());
        bo.setTorokuTime(inSession.getTorokuTime());
        bo.setTorokuUserId(inSession.getMoshikomishaId());
        bo.setKoshinDate("");
        bo.setKoshinTime("");
        bo.setKoshinUserId("");
        bo.setRonriSakujoFlg("0");
    }

    /**
     * �o�^�҂�o�^����
     *
     * @param bo
     * @param inSession
     * @param moshikomishaId
     * @throws java.lang.Exception
     */
    public void CSVtorokushaTrk(Torokusha bo, MskUploadJoho inSession, MskUploadJoho torokuLine) throws Exception {
        // �c�̒S���҂̃f�[�^���擾
        Torokusha dantaiTantosha = bo.find(inSession.getMoshikomishaId());
        bo.setMoshikomishaId(torokuLine.getMoshikomishaId());
        bo.setKaiinId("");
        bo.setKaiinKbn("1");
        bo.setLoginKbn("02");
        bo.setKengenKbn("00");
        bo.setShimei(torokuLine.getShimei());
        bo.setFurigana(torokuLine.getFurigana());
        bo.setBirthday(torokuLine.getBirthday());
        bo.setSex(torokuLine.getSex());
        bo.setYubinNo(torokuLine.getYubinNo());
        bo.setTodofukenCode(torokuLine.getTodofuken());
        bo.setJusho1(torokuLine.getJusho1());
        bo.setJusho2(torokuLine.getJusho2());
        bo.setTatemono(torokuLine.getTatemono());
        bo.setTelNo(torokuLine.getTelNo());
        bo.setFaxNo(torokuLine.getFaxNo());
        bo.setMailAddress(torokuLine.getMailAddress());
        bo.setKuniId("");
        bo.setKunimeiJpn("");
        bo.setKunimeiEng("");
        bo.setZairyuCardNo("");
        
        // �Ζ�����̓��͂�����ꍇ�A�c�̒S���҂̋Ζ��於��o�^
        if (!BmaUtility.isNullOrEmpty(torokuLine.getKinmusakiYubinNo())) {
            bo.setKinmusakiName(dantaiTantosha.getKinmusakiName());
        }
        bo.setKinmusakiYubinNo(torokuLine.getKinmusakiYubinNo());
        bo.setKinmusakiTodofukenCode(torokuLine.getKinmusakiTodofuken());
        bo.setKinmusakiJusho1(torokuLine.getKinmusakiJusho1());
        bo.setKinmusakiJusho2(torokuLine.getKinmusakiJusho2());
        bo.setKinmusakiTatemono(torokuLine.getKinmusakiTatemono());
        bo.setKinmusakiTelNo(torokuLine.getKinmusakiTelNo());
        bo.setKinmusakiFaxNo(torokuLine.getKinmusakiFaxNo());
        bo.setKigyoCode(dantaiTantosha.getKigyoCode());
        bo.setKigyoHpUrl("");
        bo.setKyokaiName("");
        bo.setGaijiFlg(torokuLine.getGaijiFlg());
        bo.setGaijiShosai(torokuLine.getGaijiShosai());
        bo.setKekkakuFlg("0");
        bo.setBiko("");
        bo.setKoshinKbn("I");
        bo.setTorokuDate(inSession.getTorokuDate());
        bo.setTorokuTime(inSession.getTorokuTime());
        bo.setTorokuUserId(inSession.getMoshikomishaId());
        bo.setKoshinDate("");
        bo.setKoshinTime("");
        bo.setKoshinUserId("");
        bo.setRonriSakujoFlg("0");
    }

    /**
     * �o�^���K�v�ȉ摜�敪�𔻒肷��
     *
     * @param inSession �Z�b�V�������
     * @param mSkkMnjKanri ���i�Ə��Ǘ����
     * @param inputGazoKbnList �o�^����摜�敪���X�g
     */
    public void checkGazoKbn(MskUploadJoho inSession, MSkkMnjKanri mSkkMnjKanri, List<String> inputGazoKbnList) throws Exception {
        // ��ʐ^�K�{
        inputGazoKbnList.add(BmaConstants.GAZO_KBN_KAO_IMG);
        if (BmaConstants.SKN_KBN.equals(inSession.getSknKsuKbn())) {
            // �����̏ꍇ�A�N��m�F���ޕK�{
            inputGazoKbnList.add(BmaConstants.GAZO_KBN_NENREI_IMG);
            // ���i�ؖ����ޔ���
            if (!BmaConstants.SKK_CODE_01.equals(mSkkMnjKanri.getShikakuCode())) {
                inputGazoKbnList.add(BmaConstants.GAZO_KBN_SHIKAKU_IMG);
            }
            // �Ə��ؖ����ޔ���
            if (!BmaUtility.isNullOrEmpty(mSkkMnjKanri.getMenjoCode())) {
                inputGazoKbnList.add(BmaConstants.GAZO_KBN_MENJO_IMG);
            }
        }
    }

    /**
     * �w���̓o�^���K�v���ǂ����𔻒肷��
     *
     * @param inputData ���͏����
     */
    public Boolean checkNeedGakureki(MskUploadJoho inputData) {
        Boolean result = false;
        // BE1��
        if (BmaConstants.SKN_KSU_CODE_BE.equals(inputData.getSknKsuCode()) && BmaConstants.SHUBETSU_CODE_ONE.equals(inputData.getShubetsuCode())) {
            switch (inputData.getJukenSkkCode()) {
                case BmaConstants.SKK_CODE_02:
                case BmaConstants.SKK_CODE_03:
                case BmaConstants.SKK_CODE_04:
                case BmaConstants.SKK_CODE_05:
                case BmaConstants.SKK_CODE_06:
                    result = true;
                    break;
                default:
                    break;
            }
        }

        return result;
    }

    /**
     * �P�����̓o�^���K�v���ǂ����𔻒肷��
     *
     * @param inputData ���͏����
     */
    public Boolean checkNeedKunrenreki(MskUploadJoho inputData) {
        Boolean result = false;
        if (BmaConstants.SKN_KSU_CODE_BC.equals(inputData.getSknKsuCode()) && BmaConstants.SHUBETSU_CODE_ONE.equals(inputData.getShubetsuCode())) {
            // BC1��
            switch (inputData.getJukenSkkCode()) {
                case BmaConstants.SKK_CODE_05:
                    result = true;
                    break;
                default:
                    break;
            }
        } else if (BmaConstants.SKN_KSU_CODE_BC.equals(inputData.getSknKsuCode()) && BmaConstants.SHUBETSU_CODE_TWO.equals(inputData.getShubetsuCode())) {
            // BC2��
            switch (inputData.getJukenSkkCode()) {
                case BmaConstants.SKK_CODE_04:
                    result = true;
                    break;
                default:
                    break;
            }
        } else if (BmaConstants.SKN_KSU_CODE_BE.equals(inputData.getSknKsuCode()) && BmaConstants.SHUBETSU_CODE_ONE.equals(inputData.getShubetsuCode())) {
            // BE1��
            switch (inputData.getJukenSkkCode()) {
                case BmaConstants.SKK_CODE_07:
                case BmaConstants.SKK_CODE_08:
                case BmaConstants.SKK_CODE_09:
                    result = true;
                    break;
                default:
                    break;
            }
        }

        return result;
    }
}
