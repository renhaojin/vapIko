package jp.co.nii.bma.business.rto;

import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import jp.co.nii.bma.utility.BmaStringUtility;
import jp.co.nii.sew.presentation.AbstractRequestTransferObject;

/**
 * �^�C�g��: �\����� ����: �\�����RTO ���쌠: Copyright (c) 2020 ��Ж�: ���{���Y�Ɗ������
 *
 * @author S.WEIBING
 */
public class TopJoho extends AbstractRequestTransferObject {

    /**
     * �\���҂h�c
     */
    private String moshikomishaId;
    /**
     * ���ID
     */
    private String kaiinId;
    /**
     * ����
     */
    private String simei;
    /**
     * ����敪
     */
    private String kaiinKbn;
    /**
     * ���O�C���敪
     */
    private String loginKbn;
    /**
     * �����\���{�^��
     */
    private String sikenMousikomiBtn;
    /**
     * �u�K��\���{�^��
     */
    private String ksuMousikomiBtn;
    /**
     * �o�^���{�^��
     */
    private String kaiinJohoBtn;
    /**
     * �\�������{�^��
     */
    private String mousikomiRirekiBtn;
    /**
     * �摜�؎�c�[���{�^��
     */
    private String gazokiritoriToolBtn;
    // ���X�g
    /**
     * �g�s�b�N�@���X�g
     */
    private List<TopJoho> topicList;
    /**
     * �g�s�b�N��
     */
    private String topicName;
    /**
     * �����u�K��R�[�h
     */
    private String sknKsuCode;
    /**
     * �����u�K�
     */
    private String sknKsuName;
    /**
     * �t���K�i
     */
    private String furigana;
    /**
     * ���N����
     */
    private String birthday;
    /**
     * �o�^���[�U�[�h�c
     */
    private String torokuUserId;

    /**
     * �R���X�g���N�^
     */
    public TopJoho() {
        clearInfo();
    }

    /**
     * ���������\�b�h
     */
    public void clearInfo() {
        setMoshikomishaId("");
        setKaiinId("");
        setSimei("");
        setKaiinKbn("");

        setSikenMousikomiBtn("");
        setKsuMousikomiBtn("");
        setKaiinJohoBtn("");
        setMousikomiRirekiBtn("");
        setGazokiritoriToolBtn("");

    }

    /**
     * ���N�G�X�g��������擾���郁�\�b�h
     *
     * @param request ���N�G�X�g
     */
    @Override
    public void copyFromRequest(HttpServletRequest request) {

        HttpSession session = request.getSession();
        if (session.getAttribute("TopJoho") != null) {
            /*�}�C�y�[�W�̏�񂪂������ꍇ*/
            TopJoho myp = (TopJoho) session.getAttribute("TopJoho");
            if (request.getAttribute("commandLogin") != null) {

                /*�}�C�y�[�W���O�C���̏����Z�b�V���������U�폜*/
                session.removeAttribute("TopJoho");
            } else if (request.getAttribute("commandMypKessaiSelect") != null) {
                /*���ϕ��@�I���̏ꍇ*/
                setMoshikomishaId(myp.getMoshikomishaId());
                setKaiinId(myp.getKaiinId());
            }
        }

    }

    /**
     * ��������͕ϐ��̑Strim
     */
    public void trimStringInputField() {
        this.kaiinId = BmaStringUtility.trimSpace2(kaiinId);
        this.simei = BmaStringUtility.trimSpace2(simei);
        this.kaiinKbn = BmaStringUtility.trimSpace2(kaiinKbn);
    }

    /**
     * ���ID
     *
     * @return the kaiinId
     */
    public String getKaiinId() {
        return kaiinId;
    }

    /**
     * ���ID
     *
     * @param kaiinId the kaiinId to set
     */
    public void setKaiinId(String kaiinId) {
        this.kaiinId = kaiinId;
    }

    /**
     * ����
     *
     * @return the simei
     */
    public String getSimei() {
        return simei;
    }

    /**
     * ����
     *
     * @param simei the simei to set
     */
    public void setSimei(String simei) {
        this.simei = simei;
    }

    public void setKaiinKbn(String kaiinKbn) {
        this.kaiinKbn = kaiinKbn;
    }

    public void setSikenMousikomiBtn(String sikenMousikomiBtn) {
        this.sikenMousikomiBtn = sikenMousikomiBtn;
    }

    public void setKsuMousikomiBtn(String ksuMousikomiBtn) {
        this.ksuMousikomiBtn = ksuMousikomiBtn;
    }

    public void setKaiinJohoBtn(String kaiinJohoBtn) {
        this.kaiinJohoBtn = kaiinJohoBtn;
    }

    public void setMousikomiRirekiBtn(String mousikomiRirekiBtn) {
        this.mousikomiRirekiBtn = mousikomiRirekiBtn;
    }

    public void setGazokiritoriToolBtn(String gazokiritoriToolBtn) {
        this.gazokiritoriToolBtn = gazokiritoriToolBtn;
    }

    public String getKaiinKbn() {
        return kaiinKbn;
    }

    public String getSikenMousikomiBtn() {
        return sikenMousikomiBtn;
    }

    public String getKsuMousikomiBtn() {
        return ksuMousikomiBtn;
    }

    public String getKaiinJohoBtn() {
        return kaiinJohoBtn;
    }

    public String getMousikomiRirekiBtn() {
        return mousikomiRirekiBtn;
    }

    public String getGazokiritoriToolBtn() {
        return gazokiritoriToolBtn;
    }

    public String getKaiinKbnDisp() {
        String rtn = "";
        if (this.getKaiinKbn().equals("1")) {
            rtn = "���";
        } else {
            rtn = "���";
        }
        return rtn;
    }

    public String getMoshikomishaId() {
        return moshikomishaId;
    }

    public String getLoginKbn() {
        return loginKbn;
    }

    public void setLoginKbn(String loginKbn) {
        this.loginKbn = loginKbn;
    }

    public void setMoshikomishaId(String moshikomishaId) {
        this.moshikomishaId = moshikomishaId;
    }

    public List<TopJoho> getTopicList() {
        return topicList;
    }

    public void setTopicList(List<TopJoho> topicList) {
        this.topicList = topicList;
    }

    public String getTopicName() {
        return topicName;
    }

    public void setTopicName(String topicName) {
        this.topicName = topicName;
    }

    public String getSknKsuCode() {
        return sknKsuCode;
    }

    public void setSknKsuCode(String sknKsuCode) {
        this.sknKsuCode = sknKsuCode;
    }

    public String getSknKsuName() {
        return sknKsuName;
    }

    public void setSknKsuName(String sknKsuName) {
        this.sknKsuName = sknKsuName;
    }

    public String getFurigana() {
        return furigana;
    }

    public void setFurigana(String furigana) {
        this.furigana = furigana;
    }

    public String getBirthday() {
        return birthday;
    }

    public void setBirthday(String birthday) {
        this.birthday = birthday;
    }

    public String getTorokuUserId() {
        return torokuUserId;
    }

    public void setTorokuUserId(String torokuUserId) {
        this.torokuUserId = torokuUserId;
    }

}
