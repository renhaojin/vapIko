package jp.co.nii.bma.integration;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import static jp.co.nii.bma.business.domain.GeneratedHoyuShikakuMstDao.TABLE_NAME;
import jp.co.nii.bma.business.domain.HoyuShikakuMst;
import jp.co.nii.bma.business.domain.HoyuShikakuMstDao;
import jp.co.nii.bma.business.domain.MoshikomiDao;
import jp.co.nii.bma.business.domain.SknksuMstDao;
import jp.co.nii.bma.business.domain.TorokushaDao;
import jp.co.nii.bma.business.rto.MskSikakuJoho;
import jp.co.nii.bma.business.rto.RrkMskJoho;
import jp.co.nii.bma.business.service.common.BmaConstants;
import static jp.co.nii.bma.integration.GeneratedHoyuShikakuMstDaoImpl.FIELDS_DECRYPT;
import jp.co.nii.sew.common.LogGenerate;
import jp.co.nii.sew.integration.SQLStateSQLExceptionTranslater;
import jp.co.nii.sew.utility.DateUtility;

/**
 * �ۗL���i�}�X�^ DAO�����N���X
 *
 * @author DB�Ǘ��c�[��
 */
public class HoyuShikakuMstDaoImpl extends GeneratedHoyuShikakuMstDaoImpl implements HoyuShikakuMstDao {

    /**
     * �C���X�^���X�𐶐�����B
     *
     * @param datasource �f�[�^�\�[�X��
     */
    public HoyuShikakuMstDaoImpl(String datasource) {
        super(datasource);
    }

    /**
     * ���i���̍��i�ԍ�����������B<br>
     *
     * @param bo �ۗL���i�}�X�^bean
     * @return Map<String, String> �����������i�ԍ��}�b�v�f�[�^<��ʃR�[�h, ���i�ԍ�><br>
     */
    @Override
    public Map<String, String> getSkkGokakuNoMap(HoyuShikakuMst bo) {
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = "";
        Map<String, String> map = new HashMap<String, String>();
//        String currentDate = DateUtility.convertDateToYyyyMMdd(new Date());
        try {
            con = getConnection();
            sql = "SELECT " + FIELDS_DECRYPT
                    + " FROM " + getSchemaName() + "." + TABLE_NAME
                    + " WHERE"
                    + " MOSHIKOMISHA_ID = ?"
                    + " AND SKN_KSU_CODE = ?"
//                    + " AND ( (SHUBETSU_CODE = ? AND (to_date(?,'YYYYMMDD') - to_date(GOKAKU_BI,'YYYYMMDD') >= 365) )  "
//                    + " OR (SHUBETSU_CODE = ? AND (to_date(?,'YYYYMMDD') - to_date(GOKAKU_BI,'YYYYMMDD') >= 365*3) ) ) "
                    + " AND RONRI_SAKUJO_FLG = ?";

            stmt = con.prepareStatement(sql);
            int i = 1;
            stmt.setString(i++, bo.getMoshikomishaId());
            stmt.setString(i++, bo.getSknKsuCode());
//            stmt.setString(i++, BmaConstants.SHUBETSU_CODE_TWO);
//            stmt.setString(i++, currentDate);
//            stmt.setString(i++, BmaConstants.SHUBETSU_CODE_THREE);
//            stmt.setString(i++, currentDate);
            stmt.setString(i++, BmaConstants.FLG_OFF);

            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();
            if (rs.next()) {
                try {
                    map.put(rs.getString("SHUBETSU_CODE"), rs.getString("GOKAKU_NO"));
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return map;
    }

    /**
     * ��u���i�̍��i�ԍ�����������B<br>
     *
     * @param moshikomishaId �\���҂h�c
     * @return Map<String, String> �����������i�ԍ��}�b�v�f�[�^<��ʃR�[�h, ���i�ԍ�><br>
     */
    @Override
    public Map<String, String> getJkSkkGokakuNoMapByMoshikomishaId(String moshikomishaId) {
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = "";
        Map<String, String> map = new HashMap<String, String>();
        try {
            con = getConnection();
            sql = "SELECT " + FIELDS_DECRYPT
                    + " FROM " + getSchemaName() + "." + TABLE_NAME
                    + " WHERE"
                    + " MOSHIKOMISHA_ID = ?"
                    + " AND SKN_KSU_CODE = ?"
                    + " AND SHUBETSU_CODE IN(?, ?)  "
                    + " AND RONRI_SAKUJO_FLG = ? "
                    + " ORDER BY SHUBETSU_CODE ASC ";

            stmt = con.prepareStatement(sql);
            int i = 1;
            stmt.setString(i++, moshikomishaId);
            stmt.setString(i++, BmaConstants.SKN_KSU_CODE_BC);
            stmt.setString(i++, "01"); //�r���N1��
            stmt.setString(i++, "27");  //�P�ꓙ��
            stmt.setString(i++, BmaConstants.FLG_OFF);

            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();
            if (rs.next()) {
                try {
                    map.put(rs.getString("SHUBETSU_CODE"), rs.getString("GOKAKU_NO"));
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return map;
    }

    /**
     * ���i���̍��i�ԍ������݂��邩�ǂ����B<br>
     *
     * @param gokakuNo ���i���̍��i�ԍ�
     * @return ���i�ԍ������݂��邩�ǂ���<br>
     */
    public Boolean checkByGokakuNo(String gokakuNo) {
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = "";
        Boolean result = false;
        try {
            con = getConnection();
            sql = "SELECT " + FIELDS_DECRYPT
                    + " FROM " + getSchemaName() + "." + TABLE_NAME
                    + " WHERE"
                    + " GOKAKU_NO = ?"
                    + " AND RONRI_SAKUJO_FLG = ?";

            stmt = con.prepareStatement(sql);
            int i = 1;
            stmt.setString(i++, gokakuNo);
            stmt.setString(i++, BmaConstants.FLG_OFF);

            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();
            if (rs.next()) {
                result = true;
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return result;
    }

    /**
     * ���i������������B<br>
     *
     * @param sknksuCode �����u�K��R�[�h
     * @param gokakuNo ���i���̍��i�ԍ�
     * @return ���i���<br>
     */
    public HoyuShikakuMst getByGokakuNo(String sknksuCode, String gokakuNo) {
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = "";
        HoyuShikakuMst bo = new HoyuShikakuMst();
        try {
            con = getConnection();
            sql = "SELECT " + FIELDS_DECRYPT
                    + " FROM " + getSchemaName() + "." + TABLE_NAME
                    + " WHERE"
                    + " SKN_KSU_CODE = ?"
                    + " AND GOKAKU_NO = ?"
                    + " AND RONRI_SAKUJO_FLG = ?"
                    + " LIMIT 1";

            stmt = con.prepareStatement(sql);
            int i = 1;
            stmt.setString(i++, sknksuCode);
            stmt.setString(i++, gokakuNo);
            stmt.setString(i++, BmaConstants.FLG_OFF);

            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();
            if (rs.next()) {
                setBoFromResultSet(bo, rs);
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return bo;
    }

    /**
     * �\���Ҏ�t�ԍ����擾�B<br>
     *
     * @param search ���i���
     * @return �\���Ҏ�t�ԍ����X�g<br>
     */
    @Override
    public List<String> SearchOutIndex(RrkMskJoho search) {

        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = "";

        List<String> param = new ArrayList<String>();
        List<String> ret = new ArrayList<String>();
        try {
            con = getConnection();
            sql = "SELECT "
                    + "mc.UKETSUKE_NO AS OUT_INDEX"
                    + " FROM " + getSchemaName() + "." + HoyuShikakuMstDao.TABLE_NAME + " AS hs"
                    + " INNER JOIN " + getSchemaName() + "." + MoshikomiDao.TABLE_NAME + " AS mc"
                    + " ON " + "hs.SKN_KSU_CODE  =  mc.SKN_KSU_CODE "
                    + " AND " + "hs.SHUBETSU_CODE  =  mc.SHUBETSU_CODE "
                    + " AND " + "hs.KAISU_CODE  =  mc.KAISU_CODE "
                    + " AND " + "hs.MOSHIKOMISHA_ID  =  mc.MOSHIKOMISHA_ID "
                    + " AND " + "hs.NENDO  =  mc.NENDO "
                    + " INNER JOIN " + getSchemaName() + "." + SknksuMstDao.TABLE_NAME + " AS sm"
                    + " ON " + "hs.SKN_KSU_CODE  =  sm.SKN_KSU_CODE "
                    + " AND " + "hs.SHUBETSU_CODE  =  sm.SHUBETSU_CODE "
                    + " AND " + "hs.KAISU_CODE  =  sm.KAISU_CODE "
                    + " INNER JOIN " + getSchemaName() + "." + TorokushaDao.TABLE_NAME + " AS tou"
                    + " ON " + "mc.MOSHIKOMISHA_ID  =  tou.MOSHIKOMISHA_ID "
                    + " WHERE"
                    + "  mc.RONRI_SAKUJO_FLG = ?"
                    + "  AND mc.toroku_user_id= ?"
                    + "  AND mc.gohi_jokyo_kbn= '01'";

            param.add(BmaConstants.FLG_OFF);
            param.add(search.getMoshikomishaId());
            
            sql = makeSql(param, search, sql);

            /* ORDER�� */
            sql += " ORDER BY mc.UKETSUKE_NO DESC";

            stmt = con.prepareStatement(sql);
            int i = 1;
            for (String pm : param) {
                stmt.setString(i++, pm);
            }

            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();
            while (rs.next()) {
                ret.add(rs.getString("OUT_INDEX"));
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return ret;

    }

    /**
     * ���i���Ȃǎ擾�B<br>
     *
     * @param search ���i���
     * @return ���i���Ȃǃ��X�g<br>
     */
    @Override
    public List<RrkMskJoho> findListShikakuGroup(RrkMskJoho search) {

        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = "";
        List<RrkMskJoho> shikakuMst = new ArrayList<>();
        List<String> test = new ArrayList<String>();
        test = search.getDispKeyList();
        List<String> param = new ArrayList<String>();

        try {
            con = getConnection();
            sql = "SELECT "
                    + "hs.MOSHIKOMISHA_ID AS MOSHIKOMISHA_ID,"
                    + "hs.GOKAKU_NO AS GOKAKU_NO,"
                    + "mc.NENDO AS NENDO,"
                    + "mc.UKETSUKE_NO AS UKETSUKE_NO,"
                    + "mc.SHIKEN_NAIYO_KBN AS SHIKEN_NAIYO_KBN,"
                    + "mc.MOSHIKOMISHA_ID AS MOSHIKOMISHA_ID,"
                    + "mc.SKN_KSU_CODE AS SKN_KSU_CODE,"
                    + "mc.UNYO_JOKYO_KBN AS UNYO_JOKYO_KBN,"
                    + "mc.GOHI_JOKYO_KBN AS GOHI_JOKYO_KBN,"
                    + "mc.JUKEN_JUKO_NO AS JUKEN_JUKO_NO,"
                    + "mc.SHUBETSU_CODE AS SHUBETSU_CODE,"
                    + "mc.MOSHIKOMI_JOKYO_KBN AS MOSHIKOMI_JOKYO_KBN,"
                    + "sm.SKN_KSU_KBN AS SKN_KSU_KBN,"
                    + "sm.SHUBETSU_CODE AS SHUBETSU_CODE,"
                    + "sm.KAISU_CODE AS KAISU_CODE,"
                    + "sm.SKN_KSU_NAME AS SKN_KSU_NAM,"
                    + "convert_from(bma.decrypt( tou.SHIMEI , '\\x506a363457356672'::bytea, 'aes'::text), 'UTF8'::name) AS SHIMEI,"
                    + "convert_from(bma.decrypt( tou.FURIGANA , '\\x506a363457356672'::bytea, 'aes'::text), 'UTF8'::name) AS FURIGANA"
                    + " FROM " + getSchemaName() + "." + HoyuShikakuMstDao.TABLE_NAME + " AS hs"
                    + " INNER JOIN " + getSchemaName() + "." + MoshikomiDao.TABLE_NAME + " AS mc"
                    + " ON " + "hs.SKN_KSU_CODE  =  mc.SKN_KSU_CODE "
                    + " AND " + "hs.SHUBETSU_CODE  =  mc.SHUBETSU_CODE "
                    + " AND " + "hs.KAISU_CODE  =  mc.KAISU_CODE "
                    + " AND " + "hs.MOSHIKOMISHA_ID  =  mc.MOSHIKOMISHA_ID "
                    + " AND " + "hs.NENDO  =  mc.NENDO "
                    + " INNER JOIN " + getSchemaName() + "." + SknksuMstDao.TABLE_NAME + " AS sm"
                    + " ON " + "hs.SKN_KSU_CODE  =  sm.SKN_KSU_CODE "
                    + " AND " + "hs.SHUBETSU_CODE  =  sm.SHUBETSU_CODE "
                    + " AND " + "hs.KAISU_CODE  =  sm.KAISU_CODE "
                    + " INNER JOIN " + getSchemaName() + "." + TorokushaDao.TABLE_NAME + " AS tou"
                    + " ON " + "mc.MOSHIKOMISHA_ID  =  tou.MOSHIKOMISHA_ID "
                    + " WHERE"
                    + "  mc.RONRI_SAKUJO_FLG = ?"
                    + "  AND mc.toroku_user_id= ?"
                    + "  AND mc.gohi_jokyo_kbn= '01'";

            param.add(BmaConstants.FLG_OFF);
            param.add(search.getMoshikomishaId());

            sql = makeSql(param, search, sql);

            /*���������ǉ�*/
            sql += " AND  mc.UKETSUKE_NO IN (";
            boolean isFirst = true;

            for (String no : test) {
                if (!isFirst) {
                    sql += ",";
                } else {
                    isFirst = false;
                }
                sql += "?";
                param.add(no);
            }
            sql += ")";

            /* ORDER�� */
            sql += " ORDER BY mc.NENDO DESC ";

            /* ����������l���Z�b�g */
            stmt = con.prepareStatement(sql);
            int i = 1;
            for (String pm : param) {
                stmt.setString(i++, pm);
            }

            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();

            while (rs.next()) {
                RrkMskJoho detail = new RrkMskJoho();

                detail.setNendo(rs.getString("NENDO"));
                detail.setUketsukeNo(rs.getString("UKETSUKE_NO"));
                detail.setMoshikomishaId(rs.getString("MOSHIKOMISHA_ID"));
                detail.setGokakuNo(rs.getString("GOKAKU_NO"));

                detail.setShikenNaiyoKbn(rs.getString("SHIKEN_NAIYO_KBN"));
                // �����u�K��敪	
                detail.setSknKsuKbn(rs.getString("SKN_KSU_KBN"));
                detail.setShubetsuCode(rs.getString("SHUBETSU_CODE"));
                detail.setKaisuCode(rs.getString("KAISU_CODE"));

                detail.setSknksuName(rs.getString("SKN_KSU_NAM"));

                detail.setJukenJukoNo(rs.getString("JUKEN_JUKO_NO"));

                detail.setShimei(rs.getString("SHIMEI"));
                detail.setFurigana(rs.getString("FURIGANA"));
                detail.setSknKsuCode(rs.getString("SKN_KSU_CODE"));

                detail.setUnyoJokyoKbn(rs.getString("UNYO_JOKYO_KBN"));
                detail.setMoshikomiJokyoKbn(rs.getString("MOSHIKOMI_JOKYO_KBN"));
                detail.setGohiJokyoKbn(rs.getString("GOHI_JOKYO_KBN"));
                shikakuMst.add(detail);
            }

        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return shikakuMst;
    }

    /**
     * ���i�ԍ��i�C���ԍ��j���擾�B(�C���y�N�y�t�H���[�z (2),�a�@�y�āz (2))<br>
     *
     * @param bo �ۗL���i�}�X�^bean
     * @return �\�����i���<br>
     */
    @Override
    public MskSikakuJoho searchSkkShuryoNo(HoyuShikakuMst bo) {
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = "";
        MskSikakuJoho bean = new MskSikakuJoho();
        try {
            con = getConnection();
            sql = "SELECT " + FIELDS_DECRYPT
                    + " FROM " + getSchemaName() + "." + TABLE_NAME
                    + " WHERE"
                    + " MOSHIKOMISHA_ID = ?"
                    + " AND SKN_KSU_CODE = ?"
                    + " AND SHUBETSU_CODE = ?"
                    + " AND NENDO = ? "
                    + " AND RONRI_SAKUJO_FLG = ?"
                    + " LIMIT 1";

            stmt = con.prepareStatement(sql);
            int i = 1;
            stmt.setString(i++, bo.getMoshikomishaId());
            stmt.setString(i++, bo.getSknKsuCode());
            stmt.setString(i++, bo.getShubetsuCode());
            stmt.setString(i++, bo.getNendo());
            stmt.setString(i++, BmaConstants.FLG_OFF);

            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();
            if (rs.next()) {
                bean.setShubetsuCode(rs.getString("SHUBETSU_CODE"));
                bean.setNendo(rs.getString("NENDO"));
                bean.setShinseiShikakuNo(rs.getString("GOKAKU_NO"));
                bean.setMuryoZanCount(rs.getString("MURYO_ZAN_COUNT"));
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return bean;
    }

    /**
     * ����SQL�쐬<br>
     *
     * @param param �p�����[�^
     * @param search �ۗL���i�}�X�^bean
     * @return �쐬SQL�쐬<br>
     */
    private String makeSql(List<String> param, RrkMskJoho search, String sql) {

        if (!search.getSknKsuKbn().isEmpty()) {
            sql = sql + "and SKN_KSU_KBN =  ?";
            param.add(search.getSknKsuKbn());
        }

        if (search.getSknNameSeach() != null && search.getSknKsuKbn().equals(BmaConstants.SKN_KBN)) {
            String sknksucode = search.getSknNameSeach().substring(0, 2);
            String shubetsucode = search.getSknNameSeach().substring(2, 4);
            String kaisucode = search.getSknNameSeach().substring(4, 6);

            sql = sql + " and sm.SKN_KSU_CODE =  ?";
            param.add(sknksucode);
            sql = sql + " and sm.SHUBETSU_CODE =  ?";
            param.add(shubetsucode);
            sql = sql + " and sm.KAISU_CODE =  ?";
            param.add(kaisucode);
        } else if (search.getSknNameSeach() != null && !search.getSknNameSeach().isEmpty() && search.getSknKsuKbn().equals(BmaConstants.KSU_KBN)) {
            String sknksucode = search.getKsuNameSeach().substring(0, 2);
            String shubetsucode = search.getKsuNameSeach().substring(2, 4);
            String kaisucode = search.getKsuNameSeach().substring(4, 6);

            sql = sql + " and sm.SKN_KSU_CODE =  ?";
            param.add(sknksucode);
            sql = sql + " and sm.SHUBETSU_CODE =  ?";
            param.add(shubetsucode);
            sql = sql + " and sm.KAISU_CODE =  ?";
            param.add(kaisucode);
        }
        return sql;
    }

    /**
     * ���i�N�������擾�i���i���_�a�@�y�V�z��ʁj�B<br>
     *
     * @param moshikomishaId �\���҂h�c
     * @param sknKsuCode �����u�K��R�[�h
     * @param shubetsuCode ��ʃR�[�h
     * @param kaisuCode �񐔃R�[�h
     * @param nendo �N�x
     * @return �����������i�N����<br>
     */
    @Override
    public String getGokakuBi(String moshikomishaId, String sknKsuCode, String shubetsuCode, String kaisuCode, String nendo) {
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = "";
        String date = "";
        try {
            con = getConnection();
            sql = "SELECT " + FIELDS_DECRYPT
                    + " FROM " + getSchemaName() + "." + TABLE_NAME
                    + " WHERE"
                    + " MOSHIKOMISHA_ID = ?"
                    + " AND SKN_KSU_CODE = ?"
                    + " AND SHUBETSU_CODE = ?"
                    + " AND KAISU_CODE = ?"
                    + " AND NENDO = ?"
                    + " AND RONRI_SAKUJO_FLG = ?";

            stmt = con.prepareStatement(sql);
            int i = 1;
            stmt.setString(i++, moshikomishaId);
            stmt.setString(i++, sknKsuCode);
            stmt.setString(i++, shubetsuCode);
            stmt.setString(i++, kaisuCode);
            stmt.setString(i++, nendo);
            stmt.setString(i++, BmaConstants.FLG_OFF);

            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();
            if (rs.next()) {
                date = rs.getString("GOKAKU_BI");
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return date;
    }

    /**
     * �\����ID���X�V����B<br>
     * @param hoyuShikakuMst �X�Vbo
     * @param moshikomishaId �V�����\���҂h�c
     */
    @Override
    public Boolean updateWithMoshikomishaId(HoyuShikakuMst hoyuShikakuMst, String moshikomishaId) {
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = "";
        try {
            con = getConnection();
            sql = "UPDATE " + getSchemaName() + "." + TABLE_NAME + " SET "
                    + " MOSHIKOMISHA_ID = ?"
                    + " , KOSHIN_KBN = ?"
                    + " , KOSHIN_DATE = ?"
                    + " , KOSHIN_TIME = ?"
                    + " , KOSHIN_USER_ID = ?"
                    + " WHERE"
                    + " MOSHIKOMISHA_ID = ?"
                    + " AND SKN_KSU_CODE = ?"
                    + " AND SHUBETSU_CODE = ?"
                    + " AND KAISU_CODE = ?"
                    + " AND NENDO = ?"
                    + " AND RONRI_SAKUJO_FLG = ?";

            stmt = con.prepareStatement(sql);
            int i = 1;
            stmt.setString(i++, moshikomishaId);
            stmt.setString(i++, hoyuShikakuMst.getKoshinKbn());
            stmt.setString(i++, hoyuShikakuMst.getKoshinDate());
            stmt.setString(i++, hoyuShikakuMst.getKoshinTime());
            stmt.setString(i++, hoyuShikakuMst.getKoshinUserId());

            stmt.setString(i++, hoyuShikakuMst.getMoshikomishaId());
            stmt.setString(i++, hoyuShikakuMst.getSknKsuCode());
            stmt.setString(i++, hoyuShikakuMst.getShubetsuCode());
            stmt.setString(i++, hoyuShikakuMst.getKaisuCode());
            stmt.setString(i++, hoyuShikakuMst.getNendo());
            stmt.setString(i++, BmaConstants.FLG_OFF);

            LogGenerate.debugOutput(getSql(stmt));
            if (stmt.executeUpdate() == 0) {
                return false;
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt);
        }
        return true;
    }
}
