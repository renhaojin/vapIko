package jp.co.nii.bma.business.service.moshikomi;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import jp.co.nii.bma.business.domain.HoyuMenjoMst;
import jp.co.nii.bma.business.domain.HoyuShikakuMst;
import jp.co.nii.bma.business.domain.MShikakuMst;
import jp.co.nii.bma.business.domain.MeishoKanri;
import jp.co.nii.bma.business.domain.MoshikomiHenkoRireki;
import jp.co.nii.bma.business.domain.Schedule;
import jp.co.nii.bma.business.domain.ShiyoKaijo;
import jp.co.nii.bma.business.domain.Shokureki;
import jp.co.nii.bma.business.domain.YukoKigenMst;
import jp.co.nii.bma.business.rto.MskKsuJoho;
import jp.co.nii.bma.business.rto.MskSikakuJoho;
import jp.co.nii.bma.business.service.common.BmaConstants;
import jp.co.nii.bma.business.service.common.BmaLogger;
import jp.co.nii.bma.business.service.common.BmaValidator;
import jp.co.nii.bma.utility.BmaDateTimeUtility;
import jp.co.nii.bma.utility.BmaStringUtility;
import jp.co.nii.bma.utility.BmaUtility;
import jp.co.nii.sew.business.SystemTime;
import jp.co.nii.sew.business.service.AbstractService;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_RELOAD;
import jp.co.nii.sew.presentation.Message;
import jp.co.nii.sew.presentation.Messages;
import jp.co.nii.sew.presentation.Option;
import jp.co.nii.sew.presentation.RequestTransferObject;
import jp.co.nii.sew.utility.CheckUtility;
import jp.co.nii.sew.utility.PropertyUtility;

/**
 * <p>
 * �^�C�g��: �\��������</p>
 * <p>
 * ����: �\�����i�����̓T�[�r�X</p>
 * <p>
 * ���쌠: Copyright (c) 2020</p>
 * <p>
 * ��Ж�: ���{���Y�Ɗ������</p>
 */
public class MskSikakuJohoInputService extends AbstractService {

    /**
     * DB�ڑ��̃f�[�^�\�[�X
     */
    private static String DATA_SOURCE_NAME;
    /**
     * ���O
     */
    BmaLogger log = (BmaLogger) BmaLogger.getLogger(this.getClass().getName());
    /**
     * �Ɩ��R�[�h
     */
    private static final String BUSINESS_CODE = PropertyUtility.getProperty("business_code");
    /**
     * ���׃e�X�g���[�h
     */
    private static final String STRESS_MODE = PropertyUtility.getProperty(BUSINESS_CODE + "stress_mode");

    public MskSikakuJohoInputService() {
        super();
        /* DB�ڑ����̃��[�U�[������ */
        DATA_SOURCE_NAME = BmaConstants.DS_REGISTRANT;
    }

    // �O�N�O
    private static String NENDO_3YEARS_BEFORE = "";
    //���i��� ���i��̐E���v�Z�p��N
    private static final String GOKAKU_SHOKUREKI_NEN = PropertyUtility.getProperty(BUSINESS_CODE + "gokaku_shokureki_nen");
    //���i��� ���i��̐E���v�Z�p�����
    private static final String GOKAKU_SHOKUREKI_TSUKIHI = PropertyUtility.getProperty(BUSINESS_CODE + "gokaku_shokureki_tsukihi");

    /**
     * �T�[�r�X�N���X�̎��s���\�b�h
     *
     * @param rto ���N�G�X�g��񂩂�擾����rto
     * @param rtoInSession �Z�b�V�������rto
     * @return foward��
     * @throws Exception ��O
     */
    @Override
    public String doService(RequestTransferObject rto, RequestTransferObject rtoInSession) throws Exception {

        MskSikakuJoho inRequest = (MskSikakuJoho) rto;
        MskSikakuJoho inSession = (MskSikakuJoho) rtoInSession;
        String processName = "";

        // �R�N�O�ݒ�
        NENDO_3YEARS_BEFORE = String.valueOf(Integer.parseInt(inRequest.getNendo()) - 3);

        /*�G���[���b�Z�[�W������*/
        inSession.setErrors(new Messages());
        try {
            if (!BmaUtility.isNullOrEmpty(inRequest.getNextDoi()) || !BmaUtility.isNullOrEmpty(inRequest.getKaijoSentakuNext())) {
                /*���i�ۗ̕L���j��*/
                inSession.setHoyuMenjoAriFlg(BmaConstants.FLG_OFF);
                inSession.setHoyuMenjoTannitsuFlg(BmaConstants.FLG_OFF);
                inSession.setHoyuShikakuAriFlg(BmaConstants.FLG_OFF);
                inSession.setShinseiMenjoNoCheck(" ");
                inSession.setShinseiShikakuNoCheck(" ");
                /*���͒l���Z�b�V�����ɕۑ�*/
                setValueRequestToSession(inRequest, inSession);
                /* ���̃��X�g���Z�b�g���� */
                setMeishoList(inSession);
                //�����̏ꍇ
                if (BmaConstants.SKN_KBN.equals(inRequest.getSknKsuKbn())) {
                    //�������e�敪���Z�b�V�����ɑ��݂��Ȃ��ꍇ
                    if (BmaUtility.isNullOrEmpty(inSession.getSknNaiyoKbn())) {
                        //�ۗL�Ə��}�X�^�e�[�u�����猟��
                        HoyuMenjoMst hoyuMenjoMst = new HoyuMenjoMst(DATA_SOURCE_NAME);
                        hoyuMenjoMst.setMoshikomishaId(inSession.getMoshikomishaId());
                        hoyuMenjoMst.setSknKsuCode(inSession.getSknKsuCode());
                        hoyuMenjoMst.setShubetsuCode(inSession.getShubetsuCode());
                        hoyuMenjoMst.setKaisuCode(inSession.getKaisuCode());
                        String[] shubetsuCodes = {"", "", "", ""};
                        setYukoShubetsuCodes(hoyuMenjoMst, shubetsuCodes);
                        List<String> menjoKbnList = hoyuMenjoMst.findMenjoKbnList(hoyuMenjoMst, shubetsuCodes);
                        if (menjoKbnList.contains("1")) {
                            //�������ʂ�"1"�u�w�ȖƏ��v���܂܂�Ă���ꍇ�A�w�ȖƏ���I����Ԃɂ�
                            inSession.setSknNaiyoKbn(BmaConstants.SKN_NAIYO_KBN_GAKKA_MENJO);
                        } else if (menjoKbnList.contains("2")) {
                            //�������ʂ�"2"�u���Z�Ə��v���܂܂�Ă���ꍇ�A���Z�Ə���I����Ԃɂ��Ă���
                            inSession.setSknNaiyoKbn(BmaConstants.SKN_NAIYO_KBN_JITSUGI_MENJO);
                        } else {
                            //��L�ȊO�̏ꍇ�A�u�w�ȁE���Z�v��I����Ԃɐݒ肷��B
                            inSession.setSknNaiyoKbn(BmaConstants.SKN_NAIYO_KBN_GAKKA_JITSUGI);
                        }
                    }

                    List<String> disabledSknNaiyoKbnList = new ArrayList<>();
                    if (BmaConstants.SKN_NAIYO_KBN_GAKKA_MENJO.equals(inSession.getSknNaiyoKbn())) {
                        // �w�ȖƏ��E�w�Ȃ݂̂̃��W�I�{�^���񊈐�
                        disabledSknNaiyoKbnList.add("");
                        disabledSknNaiyoKbnList.add("");
                        disabledSknNaiyoKbnList.add(BmaConstants.SKN_NAIYO_KBN_JITSUGI_MENJO);
                        disabledSknNaiyoKbnList.add(BmaConstants.SKN_NAIYO_KBN_GAKKA_NOMI);
                        disabledSknNaiyoKbnList.add("");
                    } else if (BmaConstants.SKN_NAIYO_KBN_JITSUGI_MENJO.equals(inSession.getSknNaiyoKbn())) {
                        // ���Z�Ə��E���Z�݂̂̃��W�I�{�^���񊈐�
                        disabledSknNaiyoKbnList.add("");
                        disabledSknNaiyoKbnList.add(BmaConstants.SKN_NAIYO_KBN_GAKKA_MENJO);
                        disabledSknNaiyoKbnList.add("");
                        disabledSknNaiyoKbnList.add("");
                        disabledSknNaiyoKbnList.add(BmaConstants.SKN_NAIYO_KBN_JITSUGI_NOMI);
                    }
                    inSession.setDisabledSknNaiyoKbnList(disabledSknNaiyoKbnList);

                    //�Ə����A���i�ԍ����Z�b�V�����ɑ��݂��Ȃ��ꍇ
                    if (BmaUtility.isNullOrEmpty(inSession.getShinseiMenjoNo())) {
                        //�e�[�u�����獇�i�ԍ�����������
                        HoyuMenjoMst hoyuMenjoMst = new HoyuMenjoMst(DATA_SOURCE_NAME);
                        hoyuMenjoMst.setMoshikomishaId(inSession.getMoshikomishaId());
                        hoyuMenjoMst.setNendo(inRequest.getNendo());
                        hoyuMenjoMst.setSknKsuCode(inSession.getSknKsuCode());
                        if (BmaConstants.SKN_NAIYO_KBN_GAKKA_MENJO.equals(inSession.getSknNaiyoKbn())) {
                            hoyuMenjoMst.setMenjoKbn("1");
                        }
                        if (BmaConstants.SKN_NAIYO_KBN_JITSUGI_MENJO.equals(inSession.getSknNaiyoKbn())) {
                            hoyuMenjoMst.setMenjoKbn("2");
                        }
                        List<MskSikakuJoho> mskSikakuJohoList = hoyuMenjoMst.getMenjoGokakuNoList(hoyuMenjoMst);
                        String gokakuNo1 = "";
                        String gokakuNo2 = "";
                        if (mskSikakuJohoList.size() > 0) {
                            //�r���N�̏ꍇ
                            if (BmaConstants.SKN_KSU_CODE_BC.equals(inRequest.getSknKsuCode())) {
                                for (MskSikakuJoho mskSikakuJoho : mskSikakuJohoList) {
                                    if (BmaConstants.SKN_KSU_CODE_BC.equals(mskSikakuJoho.getSknKsuCode())
                                            && !"27".equals(mskSikakuJoho.getMnjShubetsuCode())) {
                                        gokakuNo1 = mskSikakuJoho.getShinseiMenjoNo();
                                        inSession.setShinseiMenjoNo(gokakuNo1);
                                        // �r���N���i�̏ꍇ�A�󌟎��i������
                                        inSession.setHoyuMenjoAriFlg(BmaConstants.FLG_ON);
                                        inSession.setHoyuShikakuAriFlg(BmaConstants.FLG_ON);
                                        break;
                                    }
                                }
                                for (MskSikakuJoho mskSikakuJoho : mskSikakuJohoList) {
                                    if (BmaConstants.SKN_KSU_CODE_BC.equals(mskSikakuJoho.getSknKsuCode())
                                            && "27".equals(mskSikakuJoho.getMnjShubetsuCode())) {
                                        gokakuNo2 = mskSikakuJoho.getShinseiMenjoNo();
                                        inSession.setShinseiMenjoNo(gokakuNo2);
                                        // �P�ꓙ���̏ꍇ�A�󌟎��i�̒�o�K�v
                                        inSession.setHoyuMenjoTannitsuFlg(BmaConstants.FLG_ON);
                                        break;
                                    }
                                }
                            }

                            //�r���݂̏ꍇ
                            if (BmaConstants.SKN_KSU_CODE_BE.equals(inRequest.getSknKsuCode())) {
                                for (MskSikakuJoho mskSikakuJoho : mskSikakuJohoList) {
                                    if (BmaConstants.SKN_KSU_CODE_BE.equals(mskSikakuJoho.getSknKsuCode())) {
                                        gokakuNo1 = mskSikakuJoho.getShinseiMenjoNo();
                                        inSession.setShinseiMenjoNo(gokakuNo1);
                                        // �r���ݎ��i�̏ꍇ�A�󌟎��i������
                                        inSession.setHoyuMenjoAriFlg(BmaConstants.FLG_ON);
                                        inSession.setHoyuShikakuAriFlg(BmaConstants.FLG_ON);
                                        break;
                                    }
                                }
                            }

                            //�@�̍��i�ԍ�
                            if (!BmaUtility.isNullOrEmpty(gokakuNo1)) {
                                inSession.setMenjoCheckbox("1");
                                inSession.setMenjoGakaGokakuNo1(gokakuNo1.substring(0, 2));
                                inSession.setMenjoGakaGokakuNo2(gokakuNo1.substring(3, 4));
                                inSession.setMenjoGakaGokakuNo3(gokakuNo1.substring(4, 10));
                                inSession.setMenjoGakaGokakuNo4(gokakuNo1.substring(10, 15));
                                // �Ə����ޔ�
                                inSession.setMenjoCodeCheck(inSession.getMenjoCheckbox());
                                inSession.setShinseiMenjoNoCheck(gokakuNo1);
                            }
                            //�A�̍��i�ԍ�
                            if (!BmaUtility.isNullOrEmpty(gokakuNo2)) {
                                inSession.setMenjoCheckbox("2");
                                inSession.setMenjoGakaGokakuNo5(gokakuNo2.substring(0, 2));
                                inSession.setMenjoGakaGokakuNo6(gokakuNo2.substring(3, 4));
                                inSession.setMenjoGakaGokakuNo7(gokakuNo2.substring(4, 10));
                                inSession.setMenjoGakaGokakuNo8(gokakuNo2.substring(10, 15));
                                // �Ə����ޔ�
                                inSession.setMenjoCodeCheck(inSession.getMenjoCheckbox());
                                inSession.setShinseiMenjoNoCheck(gokakuNo2);
                            }
                        }
                    }

                    //���i���:���i�ԍ����Z�b�V�����ɑ��݂��Ȃ��ꍇ
                    if (BmaUtility.isNullOrEmpty(inSession.getShinseiShikakuNo())) {
                        //�e�[�u�����獇�i�ԍ�����������
                        HoyuShikakuMst hoyuShikakuMst = new HoyuShikakuMst(DATA_SOURCE_NAME);
                        hoyuShikakuMst.setMoshikomishaId(inSession.getMoshikomishaId());
                        hoyuShikakuMst.setSknKsuCode(inSession.getSknKsuCode());
                        Map<String, String> gokakuNoMap = hoyuShikakuMst.getSkkGokakuNoMap(hoyuShikakuMst);
                        if (gokakuNoMap.size() > 0) {
                            inSession.setHoyuShikakuAriFlg(BmaConstants.FLG_ON);
                            String sskGokakuNo;
                            //�r���N�ꍇ
                            if (BmaConstants.SKN_KSU_CODE_BC.equals(inRequest.getSknKsuCode())) {
                                //�r���N1��
                                if (BmaConstants.SHUBETSU_CODE_ONE.equals(inSession.getShubetsuCode())) {
                                    //���i�ԍ����擾�i�r���N���[�j���O�Z�\�m2���̍��i�ҁj
                                    sskGokakuNo = gokakuNoMap.get(BmaConstants.SHUBETSU_CODE_TWO);
                                    if (!BmaUtility.isNullOrEmpty(sskGokakuNo) && sskGokakuNo.length() == 17) {
                                        inSession.setShinseiShikakuNo(sskGokakuNo);
                                        inSession.setShikakuCheckbox("2");
                                        inSession.setSskGokakuNo1(sskGokakuNo.substring(1, 3));
                                        inSession.setSskGokakuNo2(sskGokakuNo.substring(4, 5));
                                        inSession.setSskGokakuNo3(sskGokakuNo.substring(6, 9));
                                        inSession.setSskGokakuNo4(sskGokakuNo.substring(10, 16));
                                        // ���i���ޔ�
                                        inSession.setShikakuCodeCheck(inSession.getShikakuCheckbox());
                                        inSession.setShinseiShikakuNoCheck(sskGokakuNo);
                                    }
                                    //���i�ԍ����擾�i�r���N���[�j���O�Z�\�m3���̍��i�ҁj
                                    sskGokakuNo = gokakuNoMap.get(BmaConstants.SHUBETSU_CODE_THREE);
                                    if (!BmaUtility.isNullOrEmpty(sskGokakuNo) && sskGokakuNo.length() == 17) {
                                        inSession.setShinseiShikakuNo(sskGokakuNo);
                                        inSession.setShikakuCheckbox("3");
                                        inSession.setSskGokakuNo5(sskGokakuNo.substring(1, 3));
                                        inSession.setSskGokakuNo6(sskGokakuNo.substring(4, 5));
                                        inSession.setSskGokakuNo7(sskGokakuNo.substring(6, 9));
                                        inSession.setSskGokakuNo8(sskGokakuNo.substring(10, 16));
                                        // ���i���ޔ�
                                        inSession.setShikakuCodeCheck(inSession.getShikakuCheckbox());
                                        inSession.setShinseiShikakuNoCheck(sskGokakuNo);
                                    }
                                }
                                //�r���N2��
                                if (BmaConstants.SHUBETSU_CODE_TWO.equals(inSession.getShubetsuCode())) {
                                    //���i�ԍ����擾�i�r���N���[�j���O�Z�\�m3���̍��i�ҁj
                                    sskGokakuNo = gokakuNoMap.get(BmaConstants.SHUBETSU_CODE_THREE);
                                    if (!BmaUtility.isNullOrEmpty(sskGokakuNo) && sskGokakuNo.length() == 17) {
                                        inSession.setShinseiShikakuNo(sskGokakuNo);
                                        inSession.setShikakuCheckbox("2");
                                        inSession.setSskGokakuNo1(sskGokakuNo.substring(1, 3));
                                        inSession.setSskGokakuNo2(sskGokakuNo.substring(4, 5));
                                        inSession.setSskGokakuNo3(sskGokakuNo.substring(6, 9));
                                        inSession.setSskGokakuNo4(sskGokakuNo.substring(10, 16));
                                        // ���i���ޔ�
                                        inSession.setShikakuCodeCheck(inSession.getShikakuCheckbox());
                                        inSession.setShinseiShikakuNoCheck(sskGokakuNo);
                                    }
                                }
                            }
                            //�r����1���̏ꍇ
                            if (BmaConstants.SKN_KSU_CODE_BE.equals(inRequest.getSknKsuCode())
                                    && BmaConstants.SHUBETSU_CODE_ONE.equals(inSession.getShubetsuCode())) {
                                //���i�ԍ����擾�i�r���ݔ��Ǘ��Z�\����2���̍��i�ҁj
                                sskGokakuNo = gokakuNoMap.get(BmaConstants.SHUBETSU_CODE_TWO);
                                if (!BmaUtility.isNullOrEmpty(sskGokakuNo) && sskGokakuNo.length() == 17) {
                                    inSession.setShinseiShikakuNo(sskGokakuNo);
                                    inSession.setShikakuCheckbox2("11");
                                    inSession.setSskGokakuNo1(sskGokakuNo.substring(1, 3));
                                    inSession.setSskGokakuNo2(sskGokakuNo.substring(4, 5));
                                    inSession.setSskGokakuNo3(sskGokakuNo.substring(6, 9));
                                    inSession.setSskGokakuNo4(sskGokakuNo.substring(10, 16));
                                    // ���i���ޔ�
                                    inSession.setShikakuCodeCheck(inSession.getShikakuCheckbox());
                                    inSession.setShinseiShikakuNoCheck(sskGokakuNo);
                                }
                            }
                        }
                    }

                    /**
                     * �P������� 2020/09/25 update �d�l�ύX *
                     */
                    //�Z�b�V�����ɑ��݂��Ȃ��ꍇ
//                    if(BmaUtility.isNullOrEmpty(inSession.getKunrenShisetsuName())){
//                        Shokureki shokureki = new Shokureki(DATA_SOURCE_NAME);
//                        //�E���敪(1 : �E��;  4 : �P����)
//                        List<Shokureki> kurenrekiList = shokureki.getShokurekiListByMoshikomishaId(inSession.getMoshikomishaId(), "4");
//                        if(kurenrekiList.size() > 1){
//                            Shokureki kurenrek = kurenrekiList.get(0);
//                            inSession.setKunrenShisetsuName(kurenrek.getKinmusakiKaishaName());
//                            inSession.setKunrenka(kurenrek.getBushoYakushokuName());
//                            inSession.setKunrenShozaichi(kurenrek.getShozaichi());
//                            if(!BmaUtility.isNullOrEmpty(kurenrek.getZaisekikikanFrom())){
//                                inSession.setKunrenKikanYearFrom(kurenrek.getZaisekikikanFrom().substring(0, 4));
//                                inSession.setKunrenKikanMonthFrom(kurenrek.getZaisekikikanFrom().substring(4, 6));
//                            }
//                            if(!BmaUtility.isNullOrEmpty(kurenrek.getZaisekikikanTo())){
//                                inSession.setKunrenKikanYearTo(kurenrek.getZaisekikikanTo().substring(0, 4));
//                                inSession.setKunrenKikanMonthTo(kurenrek.getZaisekikikanTo().substring(4, 6));
//                            }
//                        }
//                    }
                    /**
                     * �E����� 2020/09/25 update �d�l�ύX *
                     */
//                    inSession.setShokurekiKbn("1");
//                    setShokurekiListJoho(inSession);
                    //�Z�b�V�����ɑ��݂��Ȃ��ꍇ
                    if (inSession.getShokurekiList().size() < 1) {
                        List<MskSikakuJoho> shokurekiJohoList;
                        shokurekiJohoList = new ArrayList<MskSikakuJoho>();
                        MskSikakuJoho shokurekiJoho = new MskSikakuJoho();
                        shokurekiJoho.setShokurekiSeq("1");
                        //�r����2���̏ꍇ
                        if (BmaConstants.SKN_KSU_CODE_BE.equals(inRequest.getSknKsuCode())) {
                            shokurekiJoho.setShokumuNaiyo("03");
                        }
                        shokurekiJohoList.add(shokurekiJoho);
                        inSession.setShokurekiList(shokurekiJohoList);
                    }
                }

                //�u�K��̏ꍇ
                if (BmaConstants.KSU_KBN.equals(inRequest.getSknKsuKbn())) {
                    //�N�x���擾
                    MoshikomiHenkoRireki moshikomiHenkoRireki = new MoshikomiHenkoRireki(DATA_SOURCE_NAME);
                    String nendo = moshikomiHenkoRireki.getNendo(inSession.getMoshikomishaId(), inSession.getSknKsuCode(), inSession.getShubetsuCode());
                    if (!BmaUtility.isNullOrEmpty(nendo)) {
                        inSession.setNendo(nendo);
                    }

                    //�C���y�N�̏ꍇ
                    if (BmaConstants.SKN_KSU_CODE_IP.equals(inRequest.getSknKsuCode())) {
                        //�C���y�N�y�V�z
                        if (BmaConstants.SHUBETSU_CODE_NEW.equals(inRequest.getShubetsuCode())) {
                            //��u���i:���i�ԍ����Z�b�V�����ɑ��݂��Ȃ��ꍇ
                            if (BmaUtility.isNullOrEmpty(inSession.getShinseiShikakuNo())) {
                                //�e�[�u�����獇�i�ԍ�����������
                                HoyuShikakuMst hoyuShikakuMst = new HoyuShikakuMst(DATA_SOURCE_NAME);
                                Map<String, String> gokakuNoMap = hoyuShikakuMst.getJkSkkGokakuNoMapByMoshikomishaId(inSession.getMoshikomishaId());
                                if (gokakuNoMap.size() > 0) {
                                    String sskGokakuNo;
                                    //���i�ԍ����擾�i1���r���N���[�j���O�Z�\�m�j
                                    sskGokakuNo = gokakuNoMap.get(BmaConstants.SHUBETSU_CODE_ONE);
                                    if (!BmaUtility.isNullOrEmpty(sskGokakuNo) && sskGokakuNo.length() == 17) {
                                        inSession.setShinseiShikakuNo(sskGokakuNo);
                                        inSession.setShikakuCheckbox("1");
                                        inSession.setSskGokakuNo1(sskGokakuNo.substring(1, 3));
                                        inSession.setSskGokakuNo2(sskGokakuNo.substring(4, 5));
                                        inSession.setSskGokakuNo3(sskGokakuNo.substring(6, 9));
                                        inSession.setSskGokakuNo4(sskGokakuNo.substring(10, 16));
                                    }
                                    //���i�ԍ����擾�i�P�ꓙ���@�r���N���[�j���O�Z�\�m�j
                                    sskGokakuNo = gokakuNoMap.get(BmaConstants.SHUBETSU_CODE_TANITI);
                                    if (!BmaUtility.isNullOrEmpty(sskGokakuNo) && sskGokakuNo.length() == 17) {
                                        inSession.setShinseiShikakuNo(sskGokakuNo);
                                        inSession.setShikakuCheckbox("2");
                                        inSession.setSskGokakuNo5(sskGokakuNo.substring(1, 3));
                                        inSession.setSskGokakuNo6(sskGokakuNo.substring(4, 5));
                                        inSession.setSskGokakuNo7(sskGokakuNo.substring(6, 9));
                                        inSession.setSskGokakuNo8(sskGokakuNo.substring(10, 16));
                                    }
                                }

                            }

                        }

                        //�C���y�N�y�t�H���[�z (2)
                        if (BmaConstants.SHUBETSU_CODE_FOLLOW_UP.equals(inRequest.getShubetsuCode())) {
                            //���i�ԍ��i�C���ԍ��j:���Z�b�V�����ɑ��݂��Ȃ��ꍇ
                            if (BmaUtility.isNullOrEmpty(inSession.getShinseiShikakuNo())) {
                                //�L�������}�X�^�e�[�u������N�����擾����
                                YukoKigenMst yukoKigenMst = new YukoKigenMst(DATA_SOURCE_NAME);
                                String nensu = yukoKigenMst.getNensu(inSession.getSknKsuCode(), inSession.getShubetsuCode());
                                //�N�x���@���@�Z�b�V����.�N�x - �L�������}�X�^.�N��
                                int nendosa = 0;
                                try {
                                    nendosa = Integer.parseInt(inSession.getNendo()) - Integer.parseInt(nensu);
                                    inSession.setSskShuryoNo1(String.valueOf(nendosa));
                                    inSession.setSskShuryoNo3(String.valueOf(nendosa));
                                    inSession.setSskShuryoNo4("F");
                                } catch (Exception e) {
                                    e.printStackTrace();
                                    throw e;
                                }

                                //�ۗL���i�}�X�^�e�[�u�����獇�i�ԍ�����������
                                HoyuShikakuMst hoyuShikakuMst = new HoyuShikakuMst(DATA_SOURCE_NAME);
                                hoyuShikakuMst.setMoshikomishaId(inSession.getMoshikomishaId());
                                hoyuShikakuMst.setSknKsuCode(inSession.getSknKsuCode());
                                hoyuShikakuMst.setNendo(String.valueOf(nendosa));
                                //��ʃR�[�h="11"�u�V�K�v�̏ꍇ
                                hoyuShikakuMst.setShubetsuCode(BmaConstants.SHUBETSU_CODE_NEW);
                                MskSikakuJoho joho = hoyuShikakuMst.searchSkkShuryoNo(hoyuShikakuMst);
                                String sskShuryoNo = "";
                                //���i�ԍ��i�C���ԍ��j���擾�i����j
                                if (joho.getShinseiShikakuNo().length() == 10) {
                                    inSession.setShikakuCheckbox("1");
                                    sskShuryoNo = joho.getShinseiShikakuNo();
                                    inSession.setShinseiShikakuNo(sskShuryoNo);
                                    inSession.setMuryoZanCount(joho.getMuryoZanCount());
                                    inSession.setSskShuryoNo1(sskShuryoNo.substring(1, 5));
                                    inSession.setSskShuryoNo2(sskShuryoNo.substring(6, 10));
                                }

                                //��ʃR�[�h="12"�u�t�H���[�A�b�v�v�̏ꍇ
                                hoyuShikakuMst.setShubetsuCode(BmaConstants.SHUBETSU_CODE_FOLLOW_UP);
                                joho = hoyuShikakuMst.searchSkkShuryoNo(hoyuShikakuMst);
                                //���i�ԍ��i�C���ԍ��j���擾�i�Q��ڈȍ~�j
                                if (joho.getShinseiShikakuNo().length() == 12) {
                                    inSession.setShikakuCheckbox("2");
                                    sskShuryoNo = joho.getShinseiShikakuNo();
                                    inSession.setShinseiShikakuNo(sskShuryoNo);
                                    inSession.setMuryoZanCount(joho.getMuryoZanCount());
                                    inSession.setSskShuryoNo3(sskShuryoNo.substring(1, 5));
                                    inSession.setSskShuryoNo4(sskShuryoNo.substring(6, 7));
                                    inSession.setSskShuryoNo5(sskShuryoNo.substring(8, 12));
                                }

                                //�擾���Ă��������񐔎c>0�̏ꍇ�A�Z�b�V�����Ɍ��ϕ��@�敪=4��ێ�����
                                if (joho.getMuryoZanCount().compareTo("0") > 0) {
                                    inSession.setKessaiHohoKbn("4");
                                }
                            }

                        }

                    }

                    //���i���_�a�@�y�V�z
                    if (BmaConstants.SKN_KSU_CODE_HC.equals(inRequest.getSknKsuCode())) {
                        //�a�@�y�V�z
                        if (BmaConstants.SHUBETSU_CODE_NEW.equals(inRequest.getShubetsuCode())) {
                            /**
                             * ��u���i�́@�E�����  *
                             */
                            /**
                             * �E����� 2020/09/25 update �d�l�ύX *
                             */
//                            inSession.setShokurekiKbn("1");
//                            setShokurekiListJoho(inSession);
                            //�Z�b�V�����ɑ��݂��Ȃ��ꍇ
                            if (inSession.getShokurekiList().size() < 1) {
                                List<MskSikakuJoho> shokurekiJohoList;
                                shokurekiJohoList = new ArrayList<MskSikakuJoho>();
                                MskSikakuJoho shokurekiJoho = new MskSikakuJoho();
                                shokurekiJoho.setShokurekiSeq("1");
                                shokurekiJohoList.add(shokurekiJoho);
                                inSession.setShokurekiList(shokurekiJohoList);
                            }

//                            //������擾
//                            Schedule schedule = new Schedule(DATA_SOURCE_NAME);
//                            String kijunBi = schedule.getKijunbi(inSession.getNendo(), inSession.getSknKsuCode(), inSession.getShubetsuCode(), inSession.getKaisuCode());
//
//                            //���i�N�������擾
//                            HoyuShikakuMst hoyuShikakuMst = new HoyuShikakuMst(DATA_SOURCE_NAME);
//                            String gokakuBi = hoyuShikakuMst.getGokakuBi(inSession.getMoshikomishaId(), inSession.getSknKsuCode(), inSession.getShubetsuCode(), inSession.getKaisuCode(), inSession.getNendo());
//
//                            //�����o������(DB����)�̌v�Z
//                            int jitsumuKeikenDB = 0;
//                            try {
//                                if (!BmaUtility.isNullOrEmpty(kijunBi) && !BmaUtility.isNullOrEmpty(kijunBi)
//                                        && gokakuBi.compareTo(kijunBi) > 0) {
//                                    //�����݂̂Ōv�Z���� : ���i�N���� - ���
//                                    jitsumuKeikenDB = BmaDateTimeUtility.differenceMonth(gokakuBi, kijunBi) + 1;
//                                }
//                            } catch (Exception e) {
//                                e.printStackTrace();
//                            }
//                            inSession.setJitsumuKeikenDB(String.valueOf(jitsumuKeikenDB));
                        }

                        //�a�@�y�āz (2)
                        if (BmaConstants.SHUBETSU_CODE_SAIKSU.equals(inRequest.getShubetsuCode())) {
                            //���i�ԍ��i�C���ԍ��j:���Z�b�V�����ɑ��݂��Ȃ��ꍇ
                            if (BmaUtility.isNullOrEmpty(inSession.getShinseiShikakuNo())) {
                                //�e�[�u�����獇�i�ԍ�����������
                                HoyuShikakuMst hoyuShikakuMst = new HoyuShikakuMst(DATA_SOURCE_NAME);
                                hoyuShikakuMst.setMoshikomishaId(inSession.getMoshikomishaId());
                                hoyuShikakuMst.setSknKsuCode(inSession.getSknKsuCode());
                                hoyuShikakuMst.setNendo(NENDO_3YEARS_BEFORE);
                                //�a�@�y�āz (2),  ��ʃR�[�h="13"
                                hoyuShikakuMst.setShubetsuCode(BmaConstants.SHUBETSU_CODE_SAIKSU);
                                MskSikakuJoho joho = hoyuShikakuMst.searchSkkShuryoNo(hoyuShikakuMst);
                                String sskShuryoNo = "";
                                //���i�ԍ��i�C���ԍ��j���擾�i����j
                                if (joho.getShinseiShikakuNo().length() == 12) {
                                    sskShuryoNo = joho.getShinseiShikakuNo();
                                    inSession.setShinseiShikakuNo(sskShuryoNo);
                                    inSession.setSskShuryoNo1(sskShuryoNo.substring(5, 6));
                                    inSession.setSskShuryoNo2(sskShuryoNo.substring(7, 12));
                                } else {
                                    // �a�@�y�āz�ɏC���ԍ����Ȃ��ꍇ�A�a�@�y�V�K�z�ۗ̕L���i���擾  add 2020.10.14
                                    hoyuShikakuMst.setShubetsuCode(BmaConstants.SHUBETSU_CODE_NEW);
                                    joho = hoyuShikakuMst.searchSkkShuryoNo(hoyuShikakuMst);
                                    if (joho.getShinseiShikakuNo().length() == 12) {
                                        sskShuryoNo = joho.getShinseiShikakuNo();
                                        inSession.setShinseiShikakuNo(sskShuryoNo);
                                        inSession.setSskShuryoNo1(sskShuryoNo.substring(5, 6));
                                        inSession.setSskShuryoNo2(sskShuryoNo.substring(7, 12));
                                    }
                                }
                            }
                        }
                    }
                }

                /*�{�^��������*/
                processName = "MskSikakuJohoInput";
                log.Start(processName);

                return FWD_NM_SUCCESS;
            } else if (!BmaUtility.isNullOrEmpty(inRequest.getSkkConfirmBtn())) {
                /*�m�F�{�^��������*/
                processName = "searchSkkShuryoNo";
                log.Start(processName);
                Messages errors = new Messages();

                /*���͒l���Z�b�V�����ɕۑ�*/
                setValueRequestToSession(inRequest, inSession);

                /*���͒l�`�F�b�N*/
                if (!validateInputSkkShuryoNo(inSession, errors)) {
                    /*�G���[���������ꍇ�͌���������ʍĕ\��*/
                    return FWD_NM_RELOAD;
                } else {
                    String skkShuryoNoKbn = "";
                    //IP followUp
                    if (BmaConstants.SKN_KSU_CODE_IP.equals(inRequest.getSknKsuCode())
                            && BmaConstants.SHUBETSU_CODE_FOLLOW_UP.equals(inRequest.getShubetsuCode())) {
                        //���i�ԍ��i�C���ԍ��j���擾
                        if ("1".equals(inSession.getShikakuCheckbox())
                                && !BmaUtility.isNullOrEmpty(inSession.getSskShuryoNo1())
                                && !BmaUtility.isNullOrEmpty(inSession.getSskShuryoNo2())) {
                            inSession.setShinseiShikakuNo("C" + inSession.getSskShuryoNo1() + "-" + inSession.getSskShuryoNo2());
                            skkShuryoNoKbn = "�����";
                        }
                        if ("2".equals(inSession.getShikakuCheckbox())
                                && !BmaUtility.isNullOrEmpty(inSession.getSskShuryoNo3())
                                && !BmaUtility.isNullOrEmpty(inSession.getSskShuryoNo4())
                                && !BmaUtility.isNullOrEmpty(inSession.getSskShuryoNo5())) {
                            inSession.setShinseiShikakuNo("C" + inSession.getSskShuryoNo3() + "-" + inSession.getSskShuryoNo4() + "-" + inSession.getSskShuryoNo5());
                            skkShuryoNoKbn = "2��ڈȍ~��";
                        }
                    }

                    //�a�@�y�āz (2)
                    if (BmaConstants.SKN_KSU_CODE_HC.equals(inRequest.getSknKsuCode())
                            && BmaConstants.SHUBETSU_CODE_SAIKSU.equals(inRequest.getShubetsuCode())) {
                        //���i�ԍ��i�C���ԍ��j���擾
                        if (!BmaUtility.isNullOrEmpty(inSession.getSskShuryoNo1())
                                || !BmaUtility.isNullOrEmpty(inSession.getSskShuryoNo2())) {
                            inSession.setShinseiShikakuNo(NENDO_3YEARS_BEFORE + "-" + inSession.getSskShuryoNo1() + "-" + inSession.getSskShuryoNo2());
                        }
                    }

                    //���i�ԍ��i�C���ԍ��j�����݂��邩�ǂ���
                    if (!BmaUtility.isNullOrEmpty(inSession.getShinseiShikakuNo())) {
                        //�ۗL�Ə��}�X�^�e�[�u�����猟��
                        HoyuShikakuMst hoyuShikakuMst = new HoyuShikakuMst(DATA_SOURCE_NAME);
                        hoyuShikakuMst = hoyuShikakuMst.getByGokakuNo(inSession.getSknKsuCode(), inSession.getShinseiShikakuNo());
                        if (BmaUtility.isNullOrEmpty(hoyuShikakuMst.getGokakuNo())) {
                            // ���i�ԍ������݂��Ȃ������i�ԍ��s��v
                            inSession.setSskNumberError("1");
                            inSession.setSkkConfirmBtn("confirm");
                        } else {
                            // �����񐔎c���Z�b�V�����ɕۑ�
                            inSession.setHoyuShikakuMstForUpdate(hoyuShikakuMst);
                            inSession.setMuryoZanCount(hoyuShikakuMst.getMuryoZanCount());
                            //�u�ۗL���i�}�X�^�v�̍X�V�F�\����ID���X�y�[�X�������ꍇ�A�\����ID��ݒ�
                            if (BmaUtility.isNullOrEmpty(hoyuShikakuMst.getMoshikomishaId().trim())) {
                                /* �V�X�e���������擾 */
                                SystemTime sysTime = new SystemTime();
                                /* �\����ID */
                                hoyuShikakuMst.setMoshikomishaId(inSession.getMoshikomishaId());
                                /**
                                 * �X�V�敪
                                 */
                                hoyuShikakuMst.setKoshinKbn("U");
                                /**
                                 * �X�V���t
                                 */
                                hoyuShikakuMst.setKoshinDate(sysTime.getymd1());
                                /**
                                 * �X�V����
                                 */
                                hoyuShikakuMst.setKoshinTime(sysTime.gethms1());
                                /**
                                 * �X�V���[�U�[�h�c
                                 */
                                hoyuShikakuMst.setKoshinUserId(inSession.getMoshikomishaId());
                                //�X�V
                                hoyuShikakuMst.update();
                                inSession.setHoyuShikakuMstForUpdate(hoyuShikakuMst);
                            }

                            //�ԍ���v
                            if (!hoyuShikakuMst.getGokakuNo().equals(inSession.getShinseiShikakuNo())) {
                                inSession.setSskNumberError("1");
                            } else {
                                inSession.setSskNumberError("");
                            }

                            //���N������v
                            if (!hoyuShikakuMst.getBirthday().equals(inSession.getBirthday())) {
                                inSession.setSskBirthdayError("1");
                            } else {
                                inSession.setSskBirthdayError("");
                            }

                            //�t���K�i��v
                            if (!hoyuShikakuMst.getFurigana().equals(inSession.getFurigana())) {
                                inSession.setSskFuriganaError("1");
                                // �ۗL���i�t���K�i����󔒍폜
                                String furigana = hoyuShikakuMst.getFurigana();
                                furigana = furigana.replaceAll(" ", "");
                                furigana = furigana.replaceAll("�@", "");
                                inSession.setHoyuShikakuFurigana(furigana);
                            } else {
                                inSession.setSskFuriganaError("");
                            }

                            //�m�F�{�^��flag
                            inSession.setSkkConfirmBtn("confirm");
                        }
                    }
                }

                if (!errors.isEmpty()) {
                    /*�G���[���������ꍇ�͌���������ʍĕ\��*/
                    return FWD_NM_RELOAD;
                }

                return FWD_NM_RELOAD;
            } else if (!BmaUtility.isNullOrEmpty(inRequest.getSkkJohoNext())) {
                /*�{�^��������*/
                processName = "MskSikakuJohoInputNext";
                log.Start(processName);
                Messages errors = new Messages();

                /*���͒l���Z�b�V�����ɕۑ�*/
                setValueRequestToSession(inRequest, inSession);

                //�����̏ꍇ
                if (BmaConstants.SKN_KBN.equals(inSession.getSknKsuKbn())) {
                    //�摜�A�b�v���[�hflag
                    inSession.setKaoImg("00");
                    inSession.setNenreiImg("01");
                    inSession.setShikakuImg("02");
                    inSession.setMenjyoImg("03");

                    /*���͒l�`�F�b�N*/
                    if (!validateInputSkn(inSession, errors)) {
                        /*�G���[���������ꍇ�͌���������ʍĕ\��*/
                        return FWD_NM_RELOAD;
                    }

                    /** �\�����i�ԍ� */
//                        inSession.setMenjoCheckbox("");
//                        inSession.setShinseiMenjoNo("");
                        //�r���N�̏ꍇ
                        if (BmaConstants.SKN_KSU_CODE_BC.equals(inSession.getSknKsuCode())) {
                            if ("2".equals(inSession.getShikakuCheckbox())
                                    && !BmaUtility.isNullOrEmpty(inSession.getSskGokakuNo1())
                                    && !BmaUtility.isNullOrEmpty(inSession.getSskGokakuNo2())
                                    && !BmaUtility.isNullOrEmpty(inSession.getSskGokakuNo3())
                                    && !BmaUtility.isNullOrEmpty(inSession.getSskGokakuNo4())) {
                                inSession.setShinseiShikakuNo("��" + inSession.getSskGokakuNo1() + "-" + inSession.getSskGokakuNo2() + "-" + inSession.getSskGokakuNo3() + "-" + inSession.getSskGokakuNo4() + "��");
                            } else if ("3".equals(inSession.getShikakuCheckbox())
                                    && !BmaUtility.isNullOrEmpty(inSession.getSskGokakuNo5())
                                    && !BmaUtility.isNullOrEmpty(inSession.getSskGokakuNo6())
                                    && !BmaUtility.isNullOrEmpty(inSession.getSskGokakuNo7())
                                    && !BmaUtility.isNullOrEmpty(inSession.getSskGokakuNo8())) {
                                inSession.setShinseiShikakuNo("��" + inSession.getSskGokakuNo5() + "-" + inSession.getSskGokakuNo6() + "-" + inSession.getSskGokakuNo7() + "-" + inSession.getSskGokakuNo8() + "��");
                            } else {
                                inSession.setShinseiShikakuNo(" ");
                            }
                            // �����o���݂̂̏ꍇ�A���i�ؖ����ޕs�v
                            if ("1".equals(inSession.getShikakuCheckbox())) {
                                inSession.setShikakuImg("");
                            }
                            //�摜�A�b�v���[�hflag �ۗL���i�}�X�^�ɑ��݂��鎑�i�ł̐\���Ȃ�A���i�ؖ��摜��o�Ȃ�
                            if (BmaConstants.FLG_ON.equals(inSession.getHoyuShikakuAriFlg())) {
                                if (inSession.getShikakuCodeCheck().equals(inSession.getShikakuCheckbox())
                                        && inSession.getShinseiShikakuNoCheck().equals(inSession.getShinseiShikakuNo())) {
                                    inSession.setShikakuImg("");
                                }
                            }
                        }
                        //�r���݂̏ꍇ
                        if (BmaConstants.SKN_KSU_CODE_BE.equals(inSession.getSknKsuCode())) {
                            if (BmaConstants.SHUBETSU_CODE_ONE.equals(inSession.getShubetsuCode())
                                    && "11".equals(inSession.getShikakuCheckbox2())
                                    && !BmaUtility.isNullOrEmpty(inSession.getSskGokakuNo1())
                                    && !BmaUtility.isNullOrEmpty(inSession.getSskGokakuNo2())
                                    && !BmaUtility.isNullOrEmpty(inSession.getSskGokakuNo3())
                                    && !BmaUtility.isNullOrEmpty(inSession.getSskGokakuNo4())) {
                                inSession.setShinseiShikakuNo("��" + inSession.getSskGokakuNo1() + "-" + inSession.getSskGokakuNo2() + "-" + inSession.getSskGokakuNo3() + "-" + inSession.getSskGokakuNo4() + "��");
                            } else {
                                inSession.setShinseiShikakuNo(" ");
                            }
                            // �����o���݂̂̏ꍇ�A���i�ؖ����ޕs�v
                            if ("1".equals(inSession.getShikakuCheckbox())) {
                                inSession.setShikakuImg("");
                            }
                        }
                        // �Ə��\�����Ă��Ȃ���ΖƏ����ނ̒�o�Ȃ�
                        if ("01".equals(inSession.getSknNaiyoKbn()) || "04".equals(inSession.getSknNaiyoKbn()) || "05".equals(inSession.getSknNaiyoKbn())) {
                            inSession.setMenjyoImg("");
                        }
                    //�摜�A�b�v���[�hflag �ۗL���i�}�X�^�ɑ��݂��鎑�i�ł̐\���Ȃ�A���i�ؖ��摜��o�Ȃ�
                    if (BmaConstants.FLG_ON.equals(inSession.getHoyuShikakuAriFlg())) {
                        if (inSession.getShikakuCodeCheck().equals(inSession.getShikakuCheckbox())
                                && inSession.getShinseiShikakuNoCheck().equals(inSession.getShinseiShikakuNo())) {
                            inSession.setShikakuImg("");
                        }
                    }

                        //���i���̍��i�ԍ������݂��邩�ǂ���
//                        if(!BmaUtility.isNullOrEmpty(inSession.getShinseiShikakuNo().trim())){
//                            //�ۗL�Ə��}�X�^�e�[�u�����猟��
//                            HoyuShikakuMst hoyuShikakuMst = new HoyuShikakuMst(DATA_SOURCE_NAME);
//                            if(!hoyuShikakuMst.checkByGokakuNo(inSession.getShinseiShikakuNo())){
//                                addError(errors, "shinseiShikakuNo", "���i���̍��i�ԍ������݂��Ă��Ȃ��ł��B");
//                            }else{
//                                inSession.setShikakuImg("");
//                            }
//                        }

                    /**
                     * �\���Ə��ԍ�
                     */
                    if ("02".equals(inRequest.getSknNaiyoKbn()) || "03".equals(inRequest.getSknNaiyoKbn())) {
//                        inSession.setShikakuCheckbox("");
//                        inSession.setShinseiShikakuNo("");
                        if (!"3".equals(inSession.getMenjoCheckbox())) {
                            inSession.setMenjoKyu("");
                        }
                        if ("1".equals(inSession.getMenjoCheckbox())
                                && !BmaUtility.isNullOrEmpty(inSession.getMenjoGakaGokakuNo1())
                                && !BmaUtility.isNullOrEmpty(inSession.getMenjoGakaGokakuNo2())
                                && !BmaUtility.isNullOrEmpty(inSession.getMenjoGakaGokakuNo3())
                                && !BmaUtility.isNullOrEmpty(inSession.getMenjoGakaGokakuNo4())) {
                            inSession.setShinseiMenjoNo(inSession.getMenjoGakaGokakuNo1() + "-" + inSession.getMenjoGakaGokakuNo2() + inSession.getMenjoGakaGokakuNo3() + inSession.getMenjoGakaGokakuNo4());
                        } else if ("2".equals(inSession.getMenjoCheckbox())
                                && !BmaUtility.isNullOrEmpty(inSession.getMenjoGakaGokakuNo5())
                                && !BmaUtility.isNullOrEmpty(inSession.getMenjoGakaGokakuNo6())
                                && !BmaUtility.isNullOrEmpty(inSession.getMenjoGakaGokakuNo7())
                                && !BmaUtility.isNullOrEmpty(inSession.getMenjoGakaGokakuNo8())) {
                            inSession.setShinseiMenjoNo(inSession.getMenjoGakaGokakuNo5() + "-" + inSession.getMenjoGakaGokakuNo6() + inSession.getMenjoGakaGokakuNo7() + inSession.getMenjoGakaGokakuNo8());
                        } else {
                            inSession.setShinseiMenjoNo(" ");
                        }
                        //�摜�A�b�v���[�hflag �ۗL�Ə��}�X�^�ɑ��݂��鎑�i�ł̐\���Ȃ�A�Ə��ؖ��摜��o�Ȃ�
                        if (BmaConstants.FLG_ON.equals(inSession.getHoyuMenjoAriFlg()) || BmaConstants.FLG_ON.equals(inSession.getHoyuMenjoTannitsuFlg())) {
                            if (inSession.getMenjoCodeCheck().equals(inSession.getMenjoCheckbox())
                                    && inSession.getShinseiMenjoNoCheck().equals(inSession.getShinseiMenjoNo())) {
                                inSession.setMenjyoImg("");
                            }
                        }

                        //�Ə����̍��i�ԍ������݂��邩�ǂ���
//                        if(!BmaUtility.isNullOrEmpty(inSession.getShinseiMenjoNo().trim())){
//                            //�ۗL�Ə��}�X�^�e�[�u�����猟��
//                            HoyuMenjoMst hoyuMenjoMst = new HoyuMenjoMst(DATA_SOURCE_NAME);
//                            if(!hoyuMenjoMst.findByGokakuNo(inSession.getShinseiMenjoNo())){
//                                addError(errors, "shinseiMenjoNo", "�Ə����̍��i�ԍ������݂��Ă��Ȃ��ł��B");
//                            }else{
//                                inSession.setMenjyoImg("");
//                            }
//                        }
                    }
                }

                //�u�K��̏ꍇ
                if (BmaConstants.KSU_KBN.equals(inSession.getSknKsuKbn())) {
                    /*���͒l�`�F�b�N*/
                    if (!validateInputKsu(inSession, errors)) {
                        /*�G���[���������ꍇ�͌���������ʍĕ\��*/
                        return FWD_NM_RELOAD;
                    }

                    //�摜�A�b�v���[�hflag
                    inSession.setKaoImg("00");
                    inSession.setNenreiImg("");
                    inSession.setShikakuImg("");
                    inSession.setMenjyoImg("");

                    //�C���y�N
                    if (BmaConstants.SKN_KSU_CODE_IP.equals(inSession.getSknKsuCode())) {
                        //�C���y�N�y�V�z
                        if (BmaConstants.SHUBETSU_CODE_NEW.equals(inRequest.getShubetsuCode())) {
                            /**
                             * ��u���i�̍��i�ԍ�
                             */
                            if ("1".equals(inSession.getShikakuCheckbox())
                                    && !BmaUtility.isNullOrEmpty(inSession.getSskGokakuNo1())
                                    && !BmaUtility.isNullOrEmpty(inSession.getSskGokakuNo2())
                                    && !BmaUtility.isNullOrEmpty(inSession.getSskGokakuNo3())
                                    && !BmaUtility.isNullOrEmpty(inSession.getSskGokakuNo4())) {
                                inSession.setShinseiShikakuNo("��" + inSession.getSskGokakuNo1() + "-" + inSession.getSskGokakuNo2() + "-" + inSession.getSskGokakuNo3() + "-" + inSession.getSskGokakuNo4() + "��");
                            } else if ("2".equals(inSession.getShikakuCheckbox())
                                    && !BmaUtility.isNullOrEmpty(inSession.getSskGokakuNo5())
                                    && !BmaUtility.isNullOrEmpty(inSession.getSskGokakuNo6())
                                    && !BmaUtility.isNullOrEmpty(inSession.getSskGokakuNo7())
                                    && !BmaUtility.isNullOrEmpty(inSession.getSskGokakuNo8())) {
                                inSession.setShinseiShikakuNo("��" + inSession.getSskGokakuNo5() + "-" + inSession.getSskGokakuNo6() + "-" + inSession.getSskGokakuNo7() + "-" + inSession.getSskGokakuNo8() + "��");
                            } else if ("3".equals(inSession.getShikakuCheckbox())) {
                                inSession.setShinseiShikakuNo(inSession.getSagyoKantokuSikakuNo());
                            } else if ("4".equals(inSession.getShikakuCheckbox())) {
                                inSession.setShinseiShikakuNo(inSession.getEiseikanrigijutsushaSikakuNo());
                            } else if ("5".equals(inSession.getShikakuCheckbox())) {
                                inSession.setShinseiShikakuNo(inSession.getTokatsukanrishaSikakuNo());
                            } else {
                                inSession.setShinseiShikakuNo(" ");
                            }

//                            //��u���i�̍��i�ԍ������݂��邩�ǂ���
//                            if(!BmaUtility.isNullOrEmpty(inSession.getShinseiShikakuNo().trim())){
//                                //�ۗL���i�}�X�^�e�[�u�����猟��
//                                HoyuShikakuMst hoyuShikakuMst = new HoyuShikakuMst(DATA_SOURCE_NAME);
//                                if(!hoyuShikakuMst.checkByGokakuNo(inSession.getShinseiShikakuNo())){
//                                    addError(errors, "shinseiShikakuNo", "��u���i�̍��i�ԍ������݂��Ă��Ȃ��ł��B");
//                                }
//                            }
                        }

                        //�C���y�N�y�t�H���[�z (2)
                        if (BmaConstants.SHUBETSU_CODE_FOLLOW_UP.equals(inRequest.getShubetsuCode())) {
                            //���i�ԍ��i�C���ԍ��j���擾
                            String skkShuryoNoKbn = "";
                            if ("1".equals(inSession.getShikakuCheckbox())
                                    && !BmaUtility.isNullOrEmpty(inSession.getSskShuryoNo1())
                                    && !BmaUtility.isNullOrEmpty(inSession.getSskShuryoNo2())) {
                                inSession.setShinseiShikakuNo("C" + inSession.getSskShuryoNo1() + "-" + inSession.getSskShuryoNo2());
                                skkShuryoNoKbn = "�����";
                            }
                            if ("2".equals(inSession.getShikakuCheckbox())
                                    && !BmaUtility.isNullOrEmpty(inSession.getSskShuryoNo3())
                                    && !BmaUtility.isNullOrEmpty(inSession.getSskShuryoNo4())
                                    && !BmaUtility.isNullOrEmpty(inSession.getSskShuryoNo5())) {
                                inSession.setShinseiShikakuNo("C" + inSession.getSskShuryoNo3() + "-" + inSession.getSskShuryoNo4() + "-" + inSession.getSskShuryoNo5());
                                skkShuryoNoKbn = "2��ڈȍ~��";
                            }

                            //���i�ԍ��i�C���ԍ��j�����݂��邩�ǂ���
                            if (!BmaUtility.isNullOrEmpty(inSession.getShinseiShikakuNo())) {
                                //�ۗL���i�}�X�^�e�[�u�����猟��
                                HoyuShikakuMst hoyuShikakuMst = new HoyuShikakuMst(DATA_SOURCE_NAME);
                                if (!hoyuShikakuMst.checkByGokakuNo(inSession.getShinseiShikakuNo())) {
                                    addError(errors, "shinseiShikakuNo", skkShuryoNoKbn + "���i�ԍ������݂��Ă��Ȃ��ł��B");
                                }
                            }

                        }
                    }

                    //�a�@ �ču�K
                    if (BmaConstants.SKN_KSU_CODE_HC.equals(inSession.getSknKsuCode())
                            && BmaConstants.SHUBETSU_CODE_SAIKSU.equals(inSession.getShubetsuCode())) {
                        //���i�ԍ��i�C���ԍ��j���擾
                        if (!BmaUtility.isNullOrEmpty(inSession.getSskShuryoNo1())
                                || !BmaUtility.isNullOrEmpty(inSession.getSskShuryoNo2())) {
                            inSession.setShinseiShikakuNo(NENDO_3YEARS_BEFORE + "-" + inSession.getSskShuryoNo1() + "-" + inSession.getSskShuryoNo2());
                        }

                        //���i�ԍ��i�C���ԍ��j�����݂��邩�ǂ���
                        if (!BmaUtility.isNullOrEmpty(inSession.getShinseiShikakuNo())) {
                            //�ۗL���i�}�X�^�e�[�u�����猟��
                            HoyuShikakuMst hoyuShikakuMst = new HoyuShikakuMst(DATA_SOURCE_NAME);
                            if (!hoyuShikakuMst.checkByGokakuNo(inSession.getShinseiShikakuNo())) {
                                addError(errors, "shinseiShikakuNo", "���i�ԍ������݂��Ă��Ȃ��ł��B");
                            }
                        }

                    }
                }

                if (!errors.isEmpty()) {
                    /*�G���[���������ꍇ�͌���������ʍĕ\��*/
                    return FWD_NM_RELOAD;
                }

                //���i���̐ݒ�
                setShikakuJoho(inSession);
                //�Ə����̐ݒ�
                setMenjoJoho(inSession);

                return "upload";
            } else if (!BmaUtility.isNullOrEmpty(inRequest.getSkkJohoBack())) {
                /*�{�^��������*/
                processName = "";
                log.Start(processName);

                /*���͒l���Z�b�V�����ɕۑ�*/
                setValueRequestToSession(inRequest, inSession);
                inSession.setSknNaiyoKbn(inRequest.getSknNaiyoKbn());

                // �u�K��̏ꍇ�A�g�p���Ď擾
                if (BmaConstants.KSU_KBN.equals(inRequest.getSknKsuKbn())) {
                    List<MskKsuJoho> kaijoList = new ArrayList<>();
                    List<MskKsuJoho> kaijoListNew = new ArrayList<>();
                    ShiyoKaijo shiyoKaijo = new ShiyoKaijo(BmaConstants.DS_REGISTRANT);
                    MskKsuJoho mskKsuJoho = inRequest.getMskKsuJoho();
                    /*��ꃊ�X�g�擾*/
                    kaijoList = shiyoKaijo.searchKaijoList(inSession.getNendo(), inSession.getSknKsuCode(),
                            inSession.getShubetsuCode(), inSession.getKaisuCode(), "0");
                    /*�J�Òn�擾*/
                    Map<String, List<MskKsuJoho>> kaisaichi = kaijoList.stream().collect(
                            Collectors.groupingBy(MskKsuJoho::getKaisaichiCode));
                    /*��ꃊ�X�g����J�Òn���Ɣz��*/
                    for (Map.Entry<String, List<MskKsuJoho>> entry : kaisaichi.entrySet()) {
                        List<MskKsuJoho> listGroup = entry.getValue();
                        for (MskKsuJoho item : listGroup) {
                            item.setCount(listGroup.size() + "");
                            kaijoListNew.add(item);
                        }
                    }
                    mskKsuJoho.setKaiMskJohoList(kaijoListNew);
                }

                String result = FWD_NM_SESSION;
                if (BmaConstants.SKN_KBN.equals(inRequest.getSknKsuKbn())) {
                    return "backDoi";
                } else if (BmaConstants.KSU_KBN.equals(inRequest.getSknKsuKbn())) {
                    return "backKaijo";
                }
                return result;
            } else if (!BmaUtility.isNullOrEmpty(inRequest.getShokurekiTsuika())) {
                /*�u�E����ǉ��v�{�^��������*/
                processName = "shokurekiTsuika";
                log.Start(processName);

                /*���͒l���Z�b�V�����ɕۑ�*/
                setValueRequestToSession(inRequest, inSession);

                //�E����񂪍ő�s�����̏ꍇ�A��̐E�������P���ǉ�����.
                List<MskSikakuJoho> shokurekiList = inRequest.getShokurekiList();
                if (shokurekiList.size() < BmaConstants.MAX_SHOKUREKI_COUNT) {
                    MskSikakuJoho shokurekiJoho = new MskSikakuJoho();
                    shokurekiList.add(shokurekiJoho);
                }
                inSession.setShokurekiList(shokurekiList);

                return FWD_NM_RELOAD;
            } else {
                /*�ُ�J��*/
                log.IllegalFWD();
                return FWD_NM_SESSION;
            }
        } catch (Exception e) {
            throw e;
        } finally {
            log.End(processName);
        }
    }

    /**
     * ���̃��X�g���Z�b�g����B
     *
     * @param inSession
     */
    private void setMeishoList(MskSikakuJoho inSession) {
        /* ���̊Ǘ��I�u�W�F�N�g�擾 */
        MeishoKanri meisho = new MeishoKanri(DATA_SOURCE_NAME);
        List<Option> list;

        /*�������e���X�g�擾*/
        list = new ArrayList<Option>();
        meisho.findByGroupCode(BmaConstants.SHIKEN_NAIYO_KBN, list);
        list.remove(0); // [00:�敪�Ȃ�]���폜����
        inSession.setSknNaiyoList(list);

        /*�E�����e���X�g�擾*/
        list = new ArrayList<Option>();
        list.add(new Option("01", "���퐴�|"));
        list.add(new Option("02", "������|"));
        list.add(new Option("03", "�^�]"));
        list.add(new Option("04", "�ێ�"));
        list.add(new Option("05", "��Ë@��"));
        list.add(new Option("06", "���̑�"));
        inSession.setShokumuNaiyoList(list);
    }

    /**
     * ���̓f�[�^���Z�b�V�����f�[�^�ɃZ�b�g����B
     *
     * @param InputInRequest ���N�G�X�g��̓��̓f�[�^
     * @param InputInSession �Z�b�V������̓��̓f�[�^
     */
    private void setValueRequestToSession(MskSikakuJoho inRequest, MskSikakuJoho inSession) {
        inSession.setMoshikomishaId(inRequest.getMoshikomishaId());
        inSession.setSknKsuCode(inRequest.getSknKsuCode());
        inSession.setShubetsuCode(inRequest.getShubetsuCode());
        inSession.setKaisuCode(inRequest.getKaisuCode());
        if (!BmaUtility.isNullOrEmpty(inRequest.getSknNaiyoKbn())) {
            inSession.setSknNaiyoKbn(inRequest.getSknNaiyoKbn());
        }
        inSession.setSknKsuKbn(inRequest.getSknKsuKbn());
        inSession.setSknKsuNameNosbt(inRequest.getSknKsuNameNosbt());
        inSession.setShubetsuName(inRequest.getShubetsuName());
        inSession.setKaiinKbn(inRequest.getKaiinKbn());
        inSession.setFurigana(inRequest.getFurigana());
        inSession.setBirthday(inRequest.getBirthday());
        inSession.setNendo(inRequest.getNendo());

        //�m�F�{�^��
        inSession.setSkkConfirmBtn(inRequest.getSkkConfirmBtn());

        //�Ə����
        String menjoCheck = !BmaUtility.isNullOrEmpty(inRequest.getMenjoCheckbox()) ? inRequest.getMenjoCheckbox() : "";
        inSession.setMenjoCheckbox(menjoCheck);
        inSession.setMenjoCode(inRequest.getMenjoCode());
        inSession.setShinseiMenjoNo(inRequest.getShinseiMenjoNo());
        inSession.setMenjoGakaGokakuNo1(inRequest.getMenjoGakaGokakuNo1());
        inSession.setMenjoGakaGokakuNo2(inRequest.getMenjoGakaGokakuNo2());
        inSession.setMenjoGakaGokakuNo3(inRequest.getMenjoGakaGokakuNo3());
        inSession.setMenjoGakaGokakuNo4(inRequest.getMenjoGakaGokakuNo4());
        inSession.setMenjoGakaGokakuNo5(inRequest.getMenjoGakaGokakuNo5());
        inSession.setMenjoGakaGokakuNo6(inRequest.getMenjoGakaGokakuNo6());
        inSession.setMenjoGakaGokakuNo7(inRequest.getMenjoGakaGokakuNo7());
        inSession.setMenjoGakaGokakuNo8(inRequest.getMenjoGakaGokakuNo8());
        /**
         * �Ə�-��
         */
        inSession.setMenjoKyu(inRequest.getMenjoKyu());

        //���i���
        String shikakuCheck = !BmaUtility.isNullOrEmpty(inRequest.getShikakuCheckbox()) ? inRequest.getShikakuCheckbox() : "";
        inSession.setShikakuCheckbox(shikakuCheck);
        inSession.setShikakuCheckbox2(inRequest.getShikakuCheckbox2());
        inSession.setShikakuCode(inRequest.getShikakuCode());
        inSession.setShinseiShikakuNo(inRequest.getShinseiShikakuNo());
        inSession.setSskGokakuNo1(inRequest.getSskGokakuNo1());
        inSession.setSskGokakuNo2(inRequest.getSskGokakuNo2());
        inSession.setSskGokakuNo3(inRequest.getSskGokakuNo3());
        inSession.setSskGokakuNo4(inRequest.getSskGokakuNo4());
        inSession.setSskGokakuNo5(inRequest.getSskGokakuNo5());
        inSession.setSskGokakuNo6(inRequest.getSskGokakuNo6());
        inSession.setSskGokakuNo7(inRequest.getSskGokakuNo7());
        inSession.setSskGokakuNo8(inRequest.getSskGokakuNo8());
        inSession.setSagyoKantokuSikakuNo(inRequest.getSagyoKantokuSikakuNo());
        inSession.setEiseikanrigijutsushaSikakuNo(inRequest.getEiseikanrigijutsushaSikakuNo());
        inSession.setTokatsukanrishaSikakuNo(inRequest.getTokatsukanrishaSikakuNo());

        //�P�������
        inSession.setKunrenShisetsuName(inRequest.getKunrenShisetsuName());
        inSession.setKunrenka(inRequest.getKunrenka());
        inSession.setKunrenShozaichi(inRequest.getKunrenShozaichi());
        inSession.setKunrenKikanYearFrom(inRequest.getKunrenKikanYearFrom());
        if (!BmaUtility.isNullOrEmpty(inRequest.getKunrenKikanMonthFrom())) {
            inSession.setKunrenKikanMonthFrom(String.format("%02d", Integer.valueOf(inRequest.getKunrenKikanMonthFrom())));
        } else {
            inSession.setKunrenKikanMonthFrom("");
        }
        inSession.setKunrenKikanYearTo(inRequest.getKunrenKikanYearTo());
        if (!BmaUtility.isNullOrEmpty(inRequest.getKunrenKikanMonthTo())) {
            inSession.setKunrenKikanMonthTo(String.format("%02d", Integer.valueOf(inRequest.getKunrenKikanMonthTo())));
        } else {
            inSession.setKunrenKikanMonthTo("");
        }

        //�E�����
        List<MskSikakuJoho> list = new ArrayList<>();
        MskSikakuJoho mskSikakuJoho = new MskSikakuJoho();
        list.add(mskSikakuJoho);
        inSession.setShokurekiList(inRequest.getShokurekiList().isEmpty() ? list:inRequest.getShokurekiList());
        //�ݐЊ��Ԃ̏�����
        inSession.setZaishokuKikanGokei("");

        //�w�����
        inSession.setGakkouName(inRequest.getGakkouName());
        inSession.setGakkouGakka(inRequest.getGakkouGakka());
        inSession.setGakkouShozaichi(inRequest.getGakkouShozaichi());
        inSession.setGakkouSotsugyoYear(inRequest.getGakkouSotsugyoYear());
        inSession.setGakkouSotsugyoMonth(inRequest.getGakkouSotsugyoMonth());

        //��u���i
        inSession.setSagyoKantokuSikakuNo(inRequest.getSagyoKantokuSikakuNo());
        inSession.setEiseikanrigijutsushaSikakuNo(inRequest.getEiseikanrigijutsushaSikakuNo());
        inSession.setTokatsukanrishaSikakuNo(inRequest.getTokatsukanrishaSikakuNo());

        //���i�ԍ��i�C���ԍ��j
        inSession.setSskShuryoNo1(inRequest.getSskShuryoNo1());
        inSession.setSskShuryoNo2(inRequest.getSskShuryoNo2());
        inSession.setSskShuryoNo3(inRequest.getSskShuryoNo3());
        inSession.setSskShuryoNo4(inRequest.getSskShuryoNo4());
        inSession.setSskShuryoNo5(inRequest.getSskShuryoNo5());
    }

    /**
     * �����A���̓`�F�b�N
     *
     * @param inSession �Z�b�V����RTO
     * @return true:�G���[��
     */
    private boolean validateInputSkn(MskSikakuJoho inSession, Messages errors) {
        String groupCode;
        String itemName;
        //�������X�g�F�@1�i1���j�A2�i2���j�A3�i3���j
        List<String> toukyuList;
        //���i�敪���X�g�F�ꕔ�i�w�ȁj�F�w�ȍ��i�A�ꕔ�i���Z�j�F���Z���i
        List<String> gokakuKbnList;
        //�󌟒n�惊�X�g�F�k�C�A���k�A�����A�֓��A�����A�ߋE�A�����A�l���A��B
        List<String> jukenchikuList;
        /*�A�ԁA�����R���A001�`999 */
        List<String> renban3List = new ArrayList<String>();
        for (int i = 1; i <= 999; i++) {
            renban3List.add(String.format("%03d", i));
        }
        /*�A�ԁA�����S���A0001�`9999 */
        List<String> renban4List = new ArrayList<String>();
        for (int i = 1; i <= 9999; i++) {
            renban4List.add(String.format("%04d", i));
        }

        try {
            //�r���N�̏ꍇ
            if (BmaConstants.SKN_KSU_CODE_BC.equals(inSession.getSknKsuCode())) {
                toukyuList = new ArrayList<String>();
                toukyuList.add("1");
                toukyuList.add("2");
                toukyuList.add("3");
                gokakuKbnList = new ArrayList<String>();
                gokakuKbnList.add("�ꕔ�i�w�ȁj");
                gokakuKbnList.add("�ꕔ�i���Z�j");
                jukenchikuList = new ArrayList<String>();
                jukenchikuList.add("�k�C");
                jukenchikuList.add("���k");
                jukenchikuList.add("����");
                jukenchikuList.add("�֓�");
                jukenchikuList.add("����");
                jukenchikuList.add("�ߋE");
                jukenchikuList.add("����");
                jukenchikuList.add("�l��");
                jukenchikuList.add("��B");

                if ("02".equals(inSession.getSknNaiyoKbn()) || "03".equals(inSession.getSknNaiyoKbn())) {
                    /**
                     * �Ə���� *
                     */
                    groupCode = "menjoCheckbox";
                    itemName = "�Ə����̃`�F�b�N�{�b�N�X";
                    if (BmaUtility.isNullOrEmpty(inSession.getMenjoCheckbox())) {
                        addError(errors, groupCode, "�Ə��̐\�����s���ꍇ�A" + itemName + "��K����I�����Ă��������B");
                    }
                    groupCode = "shinseiMenjoNo1";
                    itemName = "�Ə��@�̍��i�ԍ�";
                    if ("1".equals(inSession.getMenjoCheckbox())) {
                        if (BmaUtility.isNullOrEmpty(inSession.getMenjoGakaGokakuNo1())
                                || BmaUtility.isNullOrEmpty(inSession.getMenjoGakaGokakuNo2())
                                || BmaUtility.isNullOrEmpty(inSession.getMenjoGakaGokakuNo3())
                                || BmaUtility.isNullOrEmpty(inSession.getMenjoGakaGokakuNo4())) {
                            addError(errors, groupCode, itemName + "����͂��Ă��������B");
                        } else {
                            if (inSession.getMenjoGakaGokakuNo1().length() != 2
                                    || inSession.getMenjoGakaGokakuNo2().length() != 1
                                    || inSession.getMenjoGakaGokakuNo3().length() != 6
                                    || inSession.getMenjoGakaGokakuNo4().length() != 5
                                    || !CheckUtility.isNumber(inSession.getMenjoGakaGokakuNo1())
                                    || !toukyuList.contains(inSession.getMenjoGakaGokakuNo2())
                                    || !gokakuKbnList.contains(inSession.getMenjoGakaGokakuNo3())
                                    || !jukenchikuList.contains(inSession.getMenjoGakaGokakuNo4().substring(0, 2))
                                    || !renban3List.contains(inSession.getMenjoGakaGokakuNo4().substring(2))) {
                                addError(errors, groupCode, itemName + "�̓��͂Ɍ�肪����܂��B");
                            }
                        }
                    }
                    groupCode = "shinseiMenjoNo2";
                    itemName = "�Ə��A�̍��i�ԍ�";
                    if ("2".equals(inSession.getMenjoCheckbox())) {
                        if (BmaUtility.isNullOrEmpty(inSession.getMenjoGakaGokakuNo5())
                                || BmaUtility.isNullOrEmpty(inSession.getMenjoGakaGokakuNo6())
                                || BmaUtility.isNullOrEmpty(inSession.getMenjoGakaGokakuNo7())
                                || BmaUtility.isNullOrEmpty(inSession.getMenjoGakaGokakuNo8())) {
                            addError(errors, groupCode, itemName + "����͂��Ă��������B");
                        } else {
                            if (inSession.getMenjoGakaGokakuNo5().length() != 2
                                    || inSession.getMenjoGakaGokakuNo6().length() != 1
                                    || inSession.getMenjoGakaGokakuNo7().length() != 6
                                    || inSession.getMenjoGakaGokakuNo8().length() != 5
                                    || !CheckUtility.isNumber(inSession.getMenjoGakaGokakuNo5())
                                    || !"�P".equals(inSession.getMenjoGakaGokakuNo6())
                                    || !gokakuKbnList.contains(inSession.getMenjoGakaGokakuNo7())
                                    || !jukenchikuList.contains(inSession.getMenjoGakaGokakuNo8().substring(0, 2))
                                    || !renban3List.contains(inSession.getMenjoGakaGokakuNo8().substring(2))) {
                                addError(errors, groupCode, itemName + "�̓��͂Ɍ�肪����܂��B");
                            }
                        }
                    }
                    groupCode = "shinseiMenjoNo3";
                    itemName = "�Ə��B";
                    List<Option> menjoKyuList = new ArrayList<Option>();
                    menjoKyuList.add(new Option("1", "1��"));
                    if (!BmaConstants.SHUBETSU_CODE_ONE.equals(inSession.getShubetsuCode())) {
                        menjoKyuList.add(new Option("2", "2��"));
                    }
                    if ("3".equals(inSession.getMenjoCheckbox())) {
                        BmaValidator.validateSelect(inSession.getMenjoKyu(), errors, groupCode, itemName);
                        BmaValidator.validatePermissionSelect(inSession.getMenjoKyu(), menjoKyuList, errors, groupCode, itemName);
                    }
                }

                if(  ("01".equals(inSession.getSknNaiyoKbn()))
                        || ("04".equals(inSession.getSknNaiyoKbn()))
                        || ("05".equals(inSession.getSknNaiyoKbn()))
                        || (("02".equals(inSession.getSknNaiyoKbn())) || ("03".equals(inSession.getSknNaiyoKbn()))) && (BmaConstants.FLG_OFF.equals(inSession.getHoyuMenjoAriFlg()))
                   ){
                    /** ���i��� **/
                    groupCode = "shikakuCheckbox";
                    itemName = "���i";
                    if (BmaUtility.isNullOrEmpty(inSession.getShikakuCheckbox())) {
                        addError(errors, groupCode, itemName + "����I�����Ă��������I");
                    }

                    //�r���N1�̂ƃr���N2�̏ꍇ
                    if (BmaConstants.SHUBETSU_CODE_ONE.equals(inSession.getShubetsuCode())
                            || BmaConstants.SHUBETSU_CODE_TWO.equals(inSession.getShubetsuCode())) {
                        groupCode = "shinseiShikakuNo2";
                        itemName = "���i�A�̍��i�ԍ�";
                        if ("2".equals(inSession.getShikakuCheckbox())) {
                            if (BmaUtility.isNullOrEmpty(inSession.getSskGokakuNo1())
                                    || BmaUtility.isNullOrEmpty(inSession.getSskGokakuNo2())
                                    || BmaUtility.isNullOrEmpty(inSession.getSskGokakuNo3())
                                    || BmaUtility.isNullOrEmpty(inSession.getSskGokakuNo4())) {
                                addError(errors, groupCode, itemName + "����͂��Ă��������B");
                            } else {
                                if (inSession.getSskGokakuNo1().length() != 2
                                        || inSession.getSskGokakuNo2().length() != 1
                                        || inSession.getSskGokakuNo3().length() != 3
                                        || inSession.getSskGokakuNo4().length() != 6
                                        || !CheckUtility.isNumber(inSession.getSskGokakuNo1())
                                        || !toukyuList.contains(inSession.getSskGokakuNo2())
                                        || !"120".equals(inSession.getSskGokakuNo3())
                                        || !jukenchikuList.contains(inSession.getSskGokakuNo4().substring(0, 2))
                                        || !renban4List.contains(inSession.getSskGokakuNo4().substring(2))) {
                                    addError(errors, groupCode, itemName + "�̓��͂Ɍ�肪����܂��B");
                                }
                            }
                        }

                        //�r���N1�̂�
                        if (BmaConstants.SHUBETSU_CODE_ONE.equals(inSession.getShubetsuCode())) {
                            groupCode = "shinseiShikakuNo3";
                            itemName = "���i�B�̍��i�ԍ�";
                            if ("3".equals(inSession.getShikakuCheckbox())) {
                                if (BmaUtility.isNullOrEmpty(inSession.getSskGokakuNo5())
                                        || BmaUtility.isNullOrEmpty(inSession.getSskGokakuNo6())
                                        || BmaUtility.isNullOrEmpty(inSession.getSskGokakuNo7())
                                        || BmaUtility.isNullOrEmpty(inSession.getSskGokakuNo8())) {
                                    addError(errors, groupCode, itemName + "����͂��Ă��������B");
                                } else {
                                    if (inSession.getSskGokakuNo5().length() != 2
                                            || inSession.getSskGokakuNo6().length() != 1
                                            || inSession.getSskGokakuNo7().length() != 3
                                            || inSession.getSskGokakuNo8().length() != 6
                                            || !CheckUtility.isNumber(inSession.getSskGokakuNo5())
                                            || !toukyuList.contains(inSession.getSskGokakuNo6())
                                            || !"120".equals(inSession.getSskGokakuNo7())
                                            || !jukenchikuList.contains(inSession.getSskGokakuNo8().substring(0, 2))
                                            || !renban4List.contains(inSession.getSskGokakuNo8().substring(2))) {
                                        addError(errors, groupCode, itemName + "�̓��͂Ɍ�肪����܂��B");
                                    }
                                }
                            }

                            //�P�������
                            if ("5".equals(inSession.getShikakuCheckbox())) {
                                /*���͒l�`�F�b�N*/
                                validateInputKunrenreki(inSession, errors);
                            }

                            //�E�����
                            if ("1".equals(inSession.getShikakuCheckbox())
                                    || "2".equals(inSession.getShikakuCheckbox())
                                    || "3".equals(inSession.getShikakuCheckbox())
                                    || "5".equals(inSession.getShikakuCheckbox())) {
                                /*���͒l�`�F�b�N*/
                                validateInputShokureki(inSession, errors);
                            }
                        }

                        //�r���N2
                        if (BmaConstants.SHUBETSU_CODE_TWO.equals(inSession.getShubetsuCode())) {
                            //�P�������
                            if ("4".equals(inSession.getShikakuCheckbox())) {
                                /*���͒l�`�F�b�N*/
                                validateInputKunrenreki(inSession, errors);
                            }

                            //�E�����
                            if ("1".equals(inSession.getShikakuCheckbox())
                                    || "4".equals(inSession.getShikakuCheckbox())) {
                                /*���͒l�`�F�b�N*/
                                validateInputShokureki(inSession, errors);
                            }
                        }
                    }

                    //�r���N3
//                    if(BmaConstants.SHUBETSU_CODE_THREE.equals(inSession.getShubetsuCode())){
//                        //�E�����
//                        if("1".equals(inSession.getShikakuCheckbox())){
//                             /*���͒l�`�F�b�N*/
//                            validateInputShokureki(inSession, errors);
//                        }
//                    }
                }
            }

            //�r���݂̏ꍇ
            if (BmaConstants.SKN_KSU_CODE_BE.equals(inSession.getSknKsuCode())) {
                toukyuList = new ArrayList<String>();
                toukyuList.add("1");
                toukyuList.add("2");
                gokakuKbnList = new ArrayList<String>();
                gokakuKbnList.add("�ꕔ�i�w�ȁj");
                gokakuKbnList.add("�ꕔ�i���Z�j");
                jukenchikuList = new ArrayList<String>();
                jukenchikuList.add("����");
                jukenchikuList.add("�ߋE");

                if ("02".equals(inSession.getSknNaiyoKbn()) || "03".equals(inSession.getSknNaiyoKbn())) {
                    /**
                     * �Ə���� *
                     */
                    groupCode = "menjoCheckbox";
                    itemName = "�Ə����̃`�F�b�N�{�b�N�X";
                    if (BmaUtility.isNullOrEmpty(inSession.getMenjoCheckbox())) {
                        addError(errors, groupCode, "�Ə��̐\�����s���ꍇ�A" + itemName + "��K����I�����Ă��������B");
                    }
                    groupCode = "shinseiMenjoNo1";
                    itemName = "�Ə��@�̍��i�ԍ�";
                    if ("1".equals(inSession.getMenjoCheckbox())) {
                        if (BmaUtility.isNullOrEmpty(inSession.getMenjoGakaGokakuNo1())
                                || BmaUtility.isNullOrEmpty(inSession.getMenjoGakaGokakuNo2())
                                || BmaUtility.isNullOrEmpty(inSession.getMenjoGakaGokakuNo3())
                                || BmaUtility.isNullOrEmpty(inSession.getMenjoGakaGokakuNo4())) {
                            addError(errors, groupCode, itemName + "����͂��Ă��������B");
                        } else {
                            if (inSession.getMenjoGakaGokakuNo1().length() != 2
                                    || inSession.getMenjoGakaGokakuNo2().length() != 1
                                    || inSession.getMenjoGakaGokakuNo3().length() != 6
                                    || inSession.getMenjoGakaGokakuNo4().length() != 5
                                    || !CheckUtility.isNumber(inSession.getMenjoGakaGokakuNo1())
                                    || !toukyuList.contains(inSession.getMenjoGakaGokakuNo2())
                                    || !gokakuKbnList.contains(inSession.getMenjoGakaGokakuNo3())
                                    || !jukenchikuList.contains(inSession.getMenjoGakaGokakuNo4().substring(0, 2))
                                    || !renban3List.contains(inSession.getMenjoGakaGokakuNo4().substring(2))) {
                                addError(errors, groupCode, itemName + "�̓��͂Ɍ�肪����܂��B");
                            }
                        }
                        groupCode = "shinseiMenjoNo3";
                        itemName = "�Ə��B";
                        List<Option> menjoKyuList = new ArrayList<Option>();
                        menjoKyuList.add(new Option("1", "1��"));
                        if (!BmaConstants.SHUBETSU_CODE_ONE.equals(inSession.getShubetsuCode())) {
                            menjoKyuList.add(new Option("2", "2��"));
                        }
                        if ("3".equals(inSession.getMenjoCheckbox())) {
                            BmaValidator.validateSelect(inSession.getMenjoKyu(), errors, groupCode, itemName);
                            BmaValidator.validatePermissionSelect(inSession.getMenjoKyu(), menjoKyuList, errors, groupCode, itemName);
                        }
                    }
                }

                //���i���
                if(  ("01".equals(inSession.getSknNaiyoKbn()))
                        || ("04".equals(inSession.getSknNaiyoKbn()))
                        || ("05".equals(inSession.getSknNaiyoKbn()))
                        || (("02".equals(inSession.getSknNaiyoKbn())) || ("03".equals(inSession.getSknNaiyoKbn()))) && (BmaConstants.FLG_OFF.equals(inSession.getHoyuMenjoAriFlg()))
                   ){
                    //�r����1
                    if (BmaConstants.SHUBETSU_CODE_ONE.equals(inSession.getShubetsuCode())) {
                        groupCode = "shinseiShikakuNo1";
                        itemName = "���i�̍��i�ԍ�";
                        if ("11".equals(inSession.getShikakuCheckbox2())) {
                            if (BmaUtility.isNullOrEmpty(inSession.getSskGokakuNo1())
                                    || BmaUtility.isNullOrEmpty(inSession.getSskGokakuNo2())
                                    || BmaUtility.isNullOrEmpty(inSession.getSskGokakuNo3())
                                    || BmaUtility.isNullOrEmpty(inSession.getSskGokakuNo4())) {
                                addError(errors, groupCode, itemName + "����͂��Ă��������B");
                            } else {
                                if (inSession.getSskGokakuNo1().length() != 2
                                        || inSession.getSskGokakuNo2().length() != 1
                                        || inSession.getSskGokakuNo3().length() != 3
                                        || inSession.getSskGokakuNo4().length() != 6
                                        || !CheckUtility.isNumber(inSession.getSskGokakuNo1())
                                        || !toukyuList.contains(inSession.getSskGokakuNo2())
                                        || !"165".equals(inSession.getSskGokakuNo3())
                                        || !jukenchikuList.contains(inSession.getSskGokakuNo4().substring(0, 2))
                                        || !renban4List.contains(inSession.getSskGokakuNo4().substring(2))) {
                                    addError(errors, groupCode, itemName + "�̓��͂Ɍ�肪����܂��B");
                                }
                            }
                        }

                        //�w�����
                        if ("2".equals(inSession.getShikakuCheckbox())
                                || "3".equals(inSession.getShikakuCheckbox())
                                || "4".equals(inSession.getShikakuCheckbox())
                                || "5".equals(inSession.getShikakuCheckbox())
                                || "6".equals(inSession.getShikakuCheckbox())) {
                            /*���͒l�`�F�b�N*/
                            validateInputGakureki(inSession, errors);
                        } else {
                            inSession.setGakkouName("");
                        }

                        //�P�������
                        if ("7".equals(inSession.getShikakuCheckbox())
                                || "8".equals(inSession.getShikakuCheckbox())
                                || "9".equals(inSession.getShikakuCheckbox())) {
                            /*���͒l�`�F�b�N*/
                            validateInputKunrenreki(inSession, errors);
                        }

                        //�E�����
                        /*���͒l�`�F�b�N*/
                        validateInputShokureki(inSession, errors);
                    }

                    //�r����2
                    if (BmaConstants.SHUBETSU_CODE_TWO.equals(inSession.getShubetsuCode())) {
                        //�E�����
                        if ("1".equals(inSession.getShikakuCheckbox())) {
                            /*���͒l�`�F�b�N*/
                            validateInputShokureki(inSession, errors);
                        }
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }

        inSession.setErrors(errors);
        return errors.isEmpty();
    }

    /**
     * �u�K��A���̓`�F�b�N
     *
     * @param inSession �Z�b�V����RTO
     * @return true:�G���[��
     */
    private boolean validateInputKsu(MskSikakuJoho inSession, Messages errors) {
        String groupCode;
        String itemName;
        //�������X�g�F�@1�i1���j�A2�i2���j�A3�i3���j
        List<String> toukyuList;
        //���i�敪���X�g�F�ꕔ�i�w�ȁj�F�w�ȍ��i�A�ꕔ�i���Z�j�F���Z���i
        List<String> gokakuKbnList;
        //�󌟒n�惊�X�g�F�k�C�A���k�A�����A�֓��A�����A�ߋE�A�����A�l���A��B
        List<String> jukenchikuList;
        /*�A�ԁA�����S���A0001�`9999 */
        List<String> renban4List = new ArrayList<String>();
        for (int i = 1; i <= 9999; i++) {
            renban4List.add(String.format("%04d", i));
        }

        try {

            //�C���y�N�̏ꍇ
            if (BmaConstants.SKN_KSU_CODE_IP.equals(inSession.getSknKsuCode())) {
                //�C���y�N�y�V�z
                if (BmaConstants.SHUBETSU_CODE_NEW.equals(inSession.getShubetsuCode())) {
                    //�C���y�N�y�V�z
                    toukyuList = new ArrayList<String>();
                    toukyuList.add("1");
                    toukyuList.add("2");
                    toukyuList.add("3");
                    gokakuKbnList = new ArrayList<String>();
                    gokakuKbnList.add("�ꕔ�i�w�ȁj");
                    gokakuKbnList.add("�ꕔ�i���Z�j");
                    jukenchikuList = new ArrayList<String>();
                    jukenchikuList.add("�k�C");
                    jukenchikuList.add("���k");
                    jukenchikuList.add("����");
                    jukenchikuList.add("�֓�");
                    jukenchikuList.add("����");
                    jukenchikuList.add("�ߋE");
                    jukenchikuList.add("����");
                    jukenchikuList.add("�l��");
                    jukenchikuList.add("��B");

                    /**
                     * ��u��� *
                     */
                    groupCode = "shikakuCheckbox";
                    itemName = "��u���̃`�F�b�N�{�b�N�X";
                    if (BmaUtility.isNullOrEmpty(inSession.getShikakuCheckbox())) {
                        addError(errors, groupCode, itemName + "��K����I�����Ă��������I");
                    }

                    groupCode = "shinseiShikakuNo1";
                    itemName = "��u���i�@�̍��i�ԍ�";
                    if ("1".equals(inSession.getShikakuCheckbox())) {
                        if (BmaUtility.isNullOrEmpty(inSession.getSskGokakuNo1())
                                || BmaUtility.isNullOrEmpty(inSession.getSskGokakuNo2())
                                || BmaUtility.isNullOrEmpty(inSession.getSskGokakuNo3())
                                || BmaUtility.isNullOrEmpty(inSession.getSskGokakuNo4())) {
                            addError(errors, groupCode, itemName + "����͂��Ă��������B");
                        } else {
                            if (inSession.getSskGokakuNo1().length() != 2
                                    || inSession.getSskGokakuNo2().length() != 1
                                    || inSession.getSskGokakuNo3().length() != 3
                                    || inSession.getSskGokakuNo4().length() != 6
                                    || !CheckUtility.isNumber(inSession.getSskGokakuNo1())
                                    || !toukyuList.contains(inSession.getSskGokakuNo2())
                                    || !"120".equals(inSession.getSskGokakuNo3())
                                    || !jukenchikuList.contains(inSession.getSskGokakuNo4().substring(0, 2))
                                    || !renban4List.contains(inSession.getSskGokakuNo4().substring(2))) {
                                addError(errors, groupCode, itemName + "�̓��͂Ɍ�肪����܂��B");
                            }
                        }
                    }

                    groupCode = "shinseiShikakuNo2";
                    itemName = "��u���i�A�̍��i�ԍ�";
                    if ("2".equals(inSession.getShikakuCheckbox())) {
                        if (BmaUtility.isNullOrEmpty(inSession.getSskGokakuNo5())
                                || BmaUtility.isNullOrEmpty(inSession.getSskGokakuNo6())
                                || BmaUtility.isNullOrEmpty(inSession.getSskGokakuNo7())
                                || BmaUtility.isNullOrEmpty(inSession.getSskGokakuNo8())) {
                            addError(errors, groupCode, itemName + "����͂��Ă��������B");
                        } else {
                            if (inSession.getSskGokakuNo5().length() != 2
                                    || inSession.getSskGokakuNo6().length() != 1
                                    || inSession.getSskGokakuNo7().length() != 3
                                    || inSession.getSskGokakuNo8().length() != 6
                                    || !CheckUtility.isNumber(inSession.getSskGokakuNo5())
                                    || !"�P".equals(inSession.getSskGokakuNo6())
                                    || !"120".equals(inSession.getSskGokakuNo7())
                                    || !jukenchikuList.contains(inSession.getSskGokakuNo8().substring(0, 2))
                                    || !renban4List.contains(inSession.getSskGokakuNo8().substring(2))) {
                                addError(errors, groupCode, itemName + "�̓��͂Ɍ�肪����܂��B");
                            }
                        }
                    }

                    /**
                     * ���|��Ɗē� *
                     */
                    groupCode = "sagyoKantokuSikakuNo";
                    itemName = "���|��Ɗē҂̎��i�ԍ�";
                    if ("3".equals(inSession.getShikakuCheckbox())) {
                        BmaValidator.validateRequired(inSession.getSagyoKantokuSikakuNo(), errors, groupCode, itemName);
                        BmaValidator.validateMojiCodeForBiko(inSession.getSagyoKantokuSikakuNo(), errors, groupCode, itemName);
                        BmaValidator.validateMaxLength(inSession.getSagyoKantokuSikakuNo(), 20, errors, groupCode, itemName);
                    }

                    /**
                     * ���z�����q���Ǘ��Z�p�� *
                     */
                    groupCode = "eiseikanrigijutsushaSikakuNo";
                    itemName = "���z�����q���Ǘ��Z�p�҂̎��i�ԍ�";
                    if ("4".equals(inSession.getShikakuCheckbox())) {
                        BmaValidator.validateRequired(inSession.getEiseikanrigijutsushaSikakuNo(), errors, groupCode, itemName);
                        BmaValidator.validateMojiCodeForBiko(inSession.getEiseikanrigijutsushaSikakuNo(), errors, groupCode, itemName);
                        BmaValidator.validateMaxLength(inSession.getEiseikanrigijutsushaSikakuNo(), 20, errors, groupCode, itemName);
                    }

                    /**
                     * ���z�����q���Ǘ��Z�p�� *
                     */
                    groupCode = "tokatsukanrishaSikakuNo";
                    itemName = "�����Ǘ��҂̎��i�ԍ�";
                    if ("5".equals(inSession.getShikakuCheckbox())) {
                        BmaValidator.validateRequired(inSession.getTokatsukanrishaSikakuNo(), errors, groupCode, itemName);
                        BmaValidator.validateMojiCodeForBiko(inSession.getTokatsukanrishaSikakuNo(), errors, groupCode, itemName);
                        BmaValidator.validateMaxLength(inSession.getTokatsukanrishaSikakuNo(), 20, errors, groupCode, itemName);
                    }

                }

                //�C���y�N�y�t�H���[�z (2)
                if (BmaConstants.SHUBETSU_CODE_FOLLOW_UP.equals(inSession.getShubetsuCode())) {
                    /*���͒l�`�F�b�N*/
                    validateInputSkkShuryoNo(inSession, errors);
                }

            }

            //�a�@�̏ꍇ
            if (BmaConstants.SKN_KSU_CODE_HC.equals(inSession.getSknKsuCode())) {
                //�a�@�V�K�̏ꍇ
                if (BmaConstants.SHUBETSU_CODE_NEW.equals(inSession.getShubetsuCode())) {
                    /*��Ë@�ւ̐E���@���͒l�`�F�b�N*/
                    validateInputShokurekiIryou(inSession, errors);
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }

        inSession.setErrors(errors);
        return errors.isEmpty();
    }

    /**
     * �w�����̓��̓`�F�b�N
     *
     * @param inSession �Z�b�V����RTO
     * @return true:�G���[��
     */
    private boolean validateInputGakureki(MskSikakuJoho inSession, Messages errors) {
        String groupCode;
        String itemName;
        try {
            //�S�p�ϊ����s
           inSession.setGakkouName(BmaStringUtility.convertHankakuToZenkakuBma(inSession.getGakkouName()));
           inSession.setGakkouGakka(BmaStringUtility.convertHankakuToZenkakuBma(inSession.getGakkouGakka()));
           inSession.setGakkouShozaichi(BmaStringUtility.convertHankakuToZenkakuBma(inSession.getGakkouShozaichi()));

            //�w�Z��
            groupCode = "gakkouName";
            itemName = "�w�Z��";
            BmaValidator.validateRequired(inSession.getGakkouName(), errors, groupCode, itemName);
            BmaValidator.validateMojiCode3(inSession.getGakkouName(), errors, groupCode, itemName);
            BmaValidator.validateMaxLength(inSession.getGakkouName(), BmaConstants.MAX_LENGTH_SHIKUCHOSON_NAME, errors, groupCode, itemName);

            //�w�Ȗ��͉ے�
            groupCode = "gakkouGakka";
            itemName = "�w�Ȗ��͉ے�";
            BmaValidator.validateRequired(inSession.getGakkouGakka(), errors, groupCode, itemName);
            BmaValidator.validateMojiCode3(inSession.getGakkouGakka(), errors, groupCode, itemName);
            BmaValidator.validateMaxLength(inSession.getGakkouGakka(), BmaConstants.MAX_LENGTH_SHIKUCHOSON_NAME, errors, groupCode, itemName);

            //���ݒn
            groupCode = "gakkouShozaichi";
            itemName = "�w���̏��ݒn";
            BmaValidator.validateRequired(inSession.getGakkouShozaichi(), errors, groupCode, itemName);
            BmaValidator.validateMojiCode3(inSession.getGakkouShozaichi(), errors, groupCode, itemName);
            BmaValidator.validateMaxLength(inSession.getGakkouShozaichi(), BmaConstants.MAX_LENGTH_SHIKUCHOSON_NAME, errors, groupCode, itemName);

            //���ƔN��
            groupCode = "gakkouSotsugyoYear";
            itemName = "���ƔN���̔N";
            BmaValidator.validateRequired(inSession.getGakkouSotsugyoYear(), errors, groupCode, itemName);
            BmaValidator.validateNumber(inSession.getGakkouSotsugyoYear(), errors, groupCode, itemName);
            BmaValidator.validateEqualLength(inSession.getGakkouSotsugyoYear(), 4, errors, groupCode, itemName);

            groupCode = "gakkouSotsugyoMonth";
            itemName = "���ƔN���̌�";
            BmaValidator.validateRequired(inSession.getGakkouSotsugyoMonth(), errors, groupCode, itemName);
            BmaValidator.validateNumber(inSession.getGakkouSotsugyoMonth(), errors, groupCode, itemName);
            BmaValidator.validateEqualLength(inSession.getGakkouSotsugyoMonth(), BmaConstants.MAX_LENGTH_BIRTHDAY_TSUKI, errors, groupCode, itemName);

            groupCode = "gakkouSotsugyo";
            itemName = "���ƔN��";
            if (!BmaUtility.isNullOrEmpty(inSession.getGakkouSotsugyoYear())
                    && !BmaUtility.isNullOrEmpty(inSession.getGakkouSotsugyoMonth())) {
                /*���ݓ��`�F�b�N*/
                String date = inSession.getGakkouSotsugyoYear() + inSession.getGakkouSotsugyoMonth() + "01";
                BmaValidator.validateDate(date, errors, groupCode, itemName);
            }

        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }

        inSession.setErrors(errors);
        return errors.isEmpty();
    }

    /**
     * �P�������̓��̓`�F�b�N
     *
     * @param inSession �Z�b�V����RTO
     * @return true:�G���[��
     */
    private boolean validateInputKunrenreki(MskSikakuJoho inSession, Messages errors) {
        String groupCode;
        String itemName;
        try {
            //�S�p�ϊ����s
           inSession.setKunrenShisetsuName(BmaStringUtility.convertHankakuToZenkakuBma(inSession.getKunrenShisetsuName()));
           inSession.setKunrenka(BmaStringUtility.convertHankakuToZenkakuBma(inSession.getKunrenka()));
           inSession.setKunrenShozaichi(BmaStringUtility.convertHankakuToZenkakuBma(inSession.getKunrenShozaichi()));

            //�P���{�ݖ�
            groupCode = "kunrenShisetsuName";
            itemName = "�P���{�ݖ�";
            BmaValidator.validateRequired(inSession.getKunrenShisetsuName(), errors, groupCode, itemName);
            BmaValidator.validateMojiCode3(inSession.getKunrenShisetsuName(), errors, groupCode, itemName);
            BmaValidator.validateMaxLength(inSession.getKunrenShisetsuName(), BmaConstants.MAX_LENGTH_SHIKUCHOSON_NAME, errors, groupCode, itemName);

            //�P����
            groupCode = "kunrenka";
            itemName = "�P����";
            BmaValidator.validateRequired(inSession.getKunrenka(), errors, groupCode, itemName);
            BmaValidator.validateMojiCode3(inSession.getKunrenka(), errors, groupCode, itemName);
            BmaValidator.validateMaxLength(inSession.getKunrenka(), BmaConstants.MAX_LENGTH_SHIKUCHOSON_NAME, errors, groupCode, itemName);

            //���ݒn
            groupCode = "kunrenShozaichi";
            itemName = "�P�����̏��ݒn";
            BmaValidator.validateRequired(inSession.getKunrenShozaichi(), errors, groupCode, itemName);
            BmaValidator.validateMojiCode3(inSession.getKunrenShozaichi(), errors, groupCode, itemName);
            BmaValidator.validateMaxLength(inSession.getKunrenShozaichi(), BmaConstants.MAX_LENGTH_SHIKUCHOSON_NAME, errors, groupCode, itemName);

            //�P������
            groupCode = "kunrenKikanYearFrom";
            itemName = "�P�����Ԃ̔N�e�q�n�l";
            BmaValidator.validateRequired(inSession.getKunrenKikanYearFrom(), errors, groupCode, itemName);
            BmaValidator.validateNumber(inSession.getKunrenKikanYearFrom(), errors, groupCode, itemName);
            BmaValidator.validateEqualLength(inSession.getKunrenKikanYearFrom(), 4, errors, groupCode, itemName);

            groupCode = "kunrenKikanMonthFrom";
            itemName = "�P�����Ԃ̌��e�q�n�l";
            BmaValidator.validateRequired(inSession.getKunrenKikanMonthFrom(), errors, groupCode, itemName);
            BmaValidator.validateNumber(inSession.getKunrenKikanMonthFrom(), errors, groupCode, itemName);
            BmaValidator.validateEqualLength(inSession.getKunrenKikanMonthFrom(), BmaConstants.MAX_LENGTH_BIRTHDAY_TSUKI, errors, groupCode, itemName);

            groupCode = "kunrenKikanYearTo";
            itemName = "�P�����Ԃ̔N�s�n";
            BmaValidator.validateRequired(inSession.getKunrenKikanYearTo(), errors, groupCode, itemName);
            BmaValidator.validateNumber(inSession.getKunrenKikanYearTo(), errors, groupCode, itemName);
            BmaValidator.validateEqualLength(inSession.getKunrenKikanYearTo(), 4, errors, groupCode, itemName);

            groupCode = "kunrenKikanMonthTo";
            itemName = "�P�����Ԃ̌��s�n";
            BmaValidator.validateRequired(inSession.getKunrenKikanMonthTo(), errors, groupCode, itemName);
            BmaValidator.validateNumber(inSession.getKunrenKikanMonthTo(), errors, groupCode, itemName);
            BmaValidator.validateEqualLength(inSession.getKunrenKikanMonthTo(), BmaConstants.MAX_LENGTH_BIRTHDAY_TSUKI, errors, groupCode, itemName);

            groupCode = "kunrenKikan";
            itemName = "�P������";
            if (!BmaUtility.isNullOrEmpty(inSession.getKunrenKikanYearFrom())
                    && !BmaUtility.isNullOrEmpty(inSession.getKunrenKikanMonthFrom())
                    && !BmaUtility.isNullOrEmpty(inSession.getKunrenKikanYearTo())
                    && !BmaUtility.isNullOrEmpty(inSession.getKunrenKikanMonthTo())) {
                /*���ݓ��`�F�b�N*/
                Boolean dateOk = true;
                String dateFrom = inSession.getKunrenKikanYearFrom() + inSession.getKunrenKikanMonthFrom() + "01";
                String dateTo = inSession.getKunrenKikanYearTo() + inSession.getKunrenKikanMonthTo() + "01";
                if (!BmaValidator.validateDate(dateFrom, errors, groupCode, itemName + "�e�q�n�l")) {
                    dateOk = false;
                }
                if (!BmaValidator.validateDate(dateTo, errors, groupCode, itemName + "�s�n")) {
                    dateOk = false;
                }
                /*�召*/
                if (dateOk && dateFrom.compareTo(dateTo) > 0) {
                    addError(errors, groupCode, "�P������From�̓��t > �P������To�̓��t�B");
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }

        inSession.setErrors(errors);
        return errors.isEmpty();
    }

    /**
     * �E�����̓��̓`�F�b�N
     *
     * @param inSession �Z�b�V����RTO
     * @return true:�G���[��
     */
    private boolean validateInputShokureki(MskSikakuJoho inSession, Messages errors) {
        String groupCode;
        String itemName;
        /*�E����e���X�g*/
        List<Option> shokumuNaiyoList = new ArrayList<Option>();
        //�r���N�̏ꍇ
        if (BmaConstants.SKN_KSU_CODE_BC.equals(inSession.getSknKsuCode())) {
            shokumuNaiyoList = new ArrayList<Option>();
            shokumuNaiyoList.add(new Option("01", "���퐴�|"));
            shokumuNaiyoList.add(new Option("02", "������|"));
        }
        //�r���݂̏ꍇ
        if (BmaConstants.SKN_KSU_CODE_BE.equals(inSession.getSknKsuCode())) {
            shokumuNaiyoList = new ArrayList<Option>();
            shokumuNaiyoList.add(new Option("03", "�^�]"));
            shokumuNaiyoList.add(new Option("04", "�ێ�"));
        }

        try {
            List<MskSikakuJoho> shokurekiList = inSession.getShokurekiList();
            if (shokurekiList.size() < 1) {
                addError(errors, "shokurekiChecked", "�E������1�ȏ�̃`�F�b�N�{�b�N�X��I�����Ă��������B");
            } else {
                int cntMonthAll = 0;
                Boolean shokurekiChecked = false;
                //�E�����X�g��index �A�P����
                int i = 0;
                for (MskSikakuJoho shokureki : shokurekiList) {
                    i++;
                    //�`�F�b�N�����ꍇ
                    if ("1".equals(shokureki.getShokurekiSeq())) {
                        //�E�����`�F�b�N�����ꍇ
                        shokurekiChecked = true;

                        //�S�p�ϊ����s
                       shokureki.setKinmusakiKaishaName(BmaStringUtility.convertHankakuToZenkakuBma(shokureki.getKinmusakiKaishaName()));
                       shokureki.setBushoYakushokuName(BmaStringUtility.convertHankakuToZenkakuBma(shokureki.getBushoYakushokuName()));
                       shokureki.setShokurekiShozaichi(BmaStringUtility.convertHankakuToZenkakuBma(shokureki.getShokurekiShozaichi()));

                        //�Ζ���Ж��y�ю��Ə�
                        groupCode = "kinmusakiKaishaName" + i;
                        itemName = "�E��" + i + "��" + "�Ζ���Ж��y�ю��Ə�";
                        BmaValidator.validateRequired(shokureki.getKinmusakiKaishaName(), errors, groupCode, itemName);
                        BmaValidator.validateMojiCode3(shokureki.getKinmusakiKaishaName(), errors, groupCode, itemName);
                        BmaValidator.validateMaxLength(shokureki.getKinmusakiKaishaName(), BmaConstants.MAX_LENGTH_SHIKUCHOSON_NAME, errors, groupCode, itemName);

                        //������E��
                        groupCode = "bushoYakushokuName" + i;
                        itemName = "�E��" + i + "��" + "������E��";
                        BmaValidator.validateRequired(shokureki.getBushoYakushokuName(), errors, groupCode, itemName);
                        BmaValidator.validateMojiCode3(shokureki.getBushoYakushokuName(), errors, groupCode, itemName);
                        BmaValidator.validateMaxLength(shokureki.getBushoYakushokuName(), BmaConstants.MAX_LENGTH_SHIKUCHOSON_NAME, errors, groupCode, itemName);

                        //�E�����e
                        groupCode = "shokumuNaiyo" + i;
                        itemName = "�E��" + i + "��" + "�E�����e";
                        BmaValidator.validateSelect(shokureki.getShokumuNaiyo(), errors, groupCode, itemName);
                        BmaValidator.validatePermissionSelect(shokureki.getShokumuNaiyo(), shokumuNaiyoList, errors, groupCode, itemName);

                        //���ݒn
                        groupCode = "shokurekiShozaichi" + i;
                        itemName = "�E��" + i + "��" + "���ݒn";
                        BmaValidator.validateRequired(shokureki.getShokurekiShozaichi(), errors, groupCode, itemName);
                        BmaValidator.validateMojiCode3(shokureki.getShokurekiShozaichi(), errors, groupCode, itemName);
                        BmaValidator.validateMaxLength(shokureki.getShokurekiShozaichi(), BmaConstants.MAX_LENGTH_SHIKUCHOSON_NAME, errors, groupCode, itemName);

                        //�ݐЊ���
                        groupCode = "zaisekikikanYearFrom";
                        itemName = "�E��" + i + "��" + "�ݐЊ��Ԃ̔N�e�q�n�l";
                        BmaValidator.validateRequired(shokureki.getZaisekikikanYearFrom(), errors, groupCode, itemName);
                        BmaValidator.validateNumber(shokureki.getZaisekikikanYearFrom(), errors, groupCode, itemName);
                        BmaValidator.validateEqualLength(shokureki.getZaisekikikanYearFrom(), 4, errors, groupCode, itemName);

                        groupCode = "zaisekikikanMonthFrom";
                        itemName = "�E��" + i + "��" + "�ݐЊ��Ԃ̌��e�q�n�l";
                        BmaValidator.validateRequired(shokureki.getZaisekikikanMonthFrom(), errors, groupCode, itemName);
                        BmaValidator.validateNumber(shokureki.getZaisekikikanMonthFrom(), errors, groupCode, itemName);
                        BmaValidator.validateEqualLength(shokureki.getZaisekikikanMonthFrom(), BmaConstants.MAX_LENGTH_BIRTHDAY_TSUKI, errors, groupCode, itemName);

                        groupCode = "zaisekikikanYearTo";
                        itemName = "�E��" + i + "��" + "�ݐЊ��Ԃ̔N�s�n";
                        BmaValidator.validateRequired(shokureki.getZaisekikikanYearTo(), errors, groupCode, itemName);
                        BmaValidator.validateNumber(shokureki.getZaisekikikanYearTo(), errors, groupCode, itemName);
                        BmaValidator.validateEqualLength(shokureki.getZaisekikikanYearTo(), 4, errors, groupCode, itemName);

                        groupCode = "zaisekikikanMonthTo";
                        itemName = "�E��" + i + "��" + "�ݐЊ��Ԃ̌��s�n";
                        BmaValidator.validateRequired(shokureki.getZaisekikikanMonthTo(), errors, groupCode, itemName);
                        BmaValidator.validateNumber(shokureki.getZaisekikikanMonthTo(), errors, groupCode, itemName);
                        BmaValidator.validateEqualLength(shokureki.getZaisekikikanMonthTo(), BmaConstants.MAX_LENGTH_BIRTHDAY_TSUKI, errors, groupCode, itemName);

                        groupCode = "zaisekikikan";
                        itemName = "�E��" + i + "��" + "�ݐЊ���";
                        if (!BmaUtility.isNullOrEmpty(shokureki.getZaisekikikanYearFrom())
                                && !BmaUtility.isNullOrEmpty(shokureki.getZaisekikikanMonthFrom())
                                && !BmaUtility.isNullOrEmpty(shokureki.getZaisekikikanYearTo())
                                && !BmaUtility.isNullOrEmpty(shokureki.getZaisekikikanMonthTo())) {
                            /*���ݓ��`�F�b�N*/
                            Boolean dateOk = true;
                            String dateFrom = shokureki.getZaisekikikanYearFrom() + shokureki.getZaisekikikanMonthFrom() + "01";
                            String dateTo = shokureki.getZaisekikikanYearTo() + shokureki.getZaisekikikanMonthTo() + "01";
                            if (!BmaValidator.validateDate(dateFrom, errors, groupCode, itemName + "�e�q�n�l")) {
                                dateOk = false;
                            }
                            if (!BmaValidator.validateDate(dateTo, errors, groupCode, itemName + "�s�n")) {
                                dateOk = false;
                            }
                            /*�召*/
                            if (dateOk && dateFrom.compareTo(dateTo) > 0) {
                                addError(errors, groupCode, "�E��" + i + "��" + "�ݐЊ���From�̓��t > �ݐЊ���To�̓��t�B");
                            }
                            if (dateOk && dateFrom.compareTo(dateTo) <= 0) {
                                cntMonthAll = cntMonthAll + BmaDateTimeUtility.differenceMonth(dateTo, dateFrom) + 1;
                            }
                        }
                    }
                }

                if (!shokurekiChecked == true) {
                    addError(errors, "shokurekiChecked", "�E������1�ȏ�̃`�F�b�N�{�b�N�X��I�����Ă��������B");
                }

                //�����o���N��
                groupCode = "skkYear";
                itemName = "�����o���N��";
                int skkYear = cntMonthAll / 12;
                inSession.setZaishokuKikanGokei(skkYear + " �N " + cntMonthAll % 12 + " ����");
                //�r���N�̏ꍇ
                if (BmaConstants.SKN_KSU_CODE_BC.equals(inSession.getSknKsuCode())) {
                    //�r���N1��
                    if (BmaConstants.SHUBETSU_CODE_ONE.equals(inSession.getShubetsuCode())) {
                        if (("1".equals(inSession.getShikakuCheckbox()) && skkYear < 5)
                                || ("2".equals(inSession.getShikakuCheckbox()) && skkYear < 1)
                                || ("3".equals(inSession.getShikakuCheckbox()) && skkYear < 3)
                                || ("5".equals(inSession.getShikakuCheckbox()) && skkYear < 4)) {
                            addError(errors, groupCode, itemName + "���s�����Ă��܂��B");
                        }
                    }
                    //�r���N2��
                    if (BmaConstants.SHUBETSU_CODE_TWO.equals(inSession.getShubetsuCode())) {
                        if (("1".equals(inSession.getShikakuCheckbox()) && skkYear < 2)
                                || ("4".equals(inSession.getShikakuCheckbox()) && skkYear < 1)) {
                            addError(errors, groupCode, itemName + "���s�����Ă��܂��B");
                        }
                    }
                }
                //�r���݂̏ꍇ
                if (BmaConstants.SKN_KSU_CODE_BE.equals(inSession.getSknKsuCode())) {
                    //�r����1��
                    if (BmaConstants.SHUBETSU_CODE_ONE.equals(inSession.getShubetsuCode())) {
                        //DB�̎��i�o���N�����擾
                        MShikakuMst mShikakuMst = new MShikakuMst(DATA_SOURCE_NAME);
                        List<String> sskKeikenNenList = mShikakuMst.getSskKeikenNenList(inSession);
                        //���i�o������1
                        int ssk_keiken_month1 = 0;
                        //���i�o������2
                        int ssk_keiken_month2 = 0;
                        try {
                            if (sskKeikenNenList.size() > 0 && !BmaUtility.isNullOrEmpty(sskKeikenNenList.get(0))) {
                                ssk_keiken_month1 = Integer.parseInt(sskKeikenNenList.get(0).substring(0, 2)) * 12 + Integer.parseInt(sskKeikenNenList.get(0).substring(2, 4));
                            }
                            if (sskKeikenNenList.size() > 1 && !BmaUtility.isNullOrEmpty(sskKeikenNenList.get(1))) {
                                ssk_keiken_month2 = Integer.parseInt(sskKeikenNenList.get(1).substring(0, 2)) * 12 + Integer.parseInt(sskKeikenNenList.get(1).substring(2, 4));
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                            throw e;
                        }

                        //2�����i
                        if ("11".equals(inSession.getShikakuCheckbox2())) {
                            if (("1".equals(inSession.getShikakuCheckbox()) && cntMonthAll < ssk_keiken_month2)
                                    || ("2".equals(inSession.getShikakuCheckbox()) && cntMonthAll < ssk_keiken_month2)
                                    || ("3".equals(inSession.getShikakuCheckbox()) && cntMonthAll < ssk_keiken_month2)
                                    || ("4".equals(inSession.getShikakuCheckbox()) && cntMonthAll < ssk_keiken_month2)
                                    || ("5".equals(inSession.getShikakuCheckbox()) && cntMonthAll < ssk_keiken_month2)
                                    || ("6".equals(inSession.getShikakuCheckbox()) && cntMonthAll < ssk_keiken_month2)
                                    || ("7".equals(inSession.getShikakuCheckbox()) && cntMonthAll < ssk_keiken_month2)
                                    || ("8".equals(inSession.getShikakuCheckbox()) && cntMonthAll < ssk_keiken_month2)
                                    || ("9".equals(inSession.getShikakuCheckbox()) && cntMonthAll < ssk_keiken_month2)
                                    || ("10".equals(inSession.getShikakuCheckbox()) && cntMonthAll < ssk_keiken_month2)) {
                                addError(errors, groupCode, itemName + "���s�����Ă��܂��B");
                            }
                        } else {
                            //2�����i���Ȃ�
                            if (("1".equals(inSession.getShikakuCheckbox()) && cntMonthAll < ssk_keiken_month1)
                                    || ("2".equals(inSession.getShikakuCheckbox()) && cntMonthAll < ssk_keiken_month1)
                                    || ("3".equals(inSession.getShikakuCheckbox()) && cntMonthAll < ssk_keiken_month1)
                                    || ("4".equals(inSession.getShikakuCheckbox()) && cntMonthAll < ssk_keiken_month1)
                                    || ("5".equals(inSession.getShikakuCheckbox()) && cntMonthAll < ssk_keiken_month1)
                                    || ("6".equals(inSession.getShikakuCheckbox()) && cntMonthAll < ssk_keiken_month1)
                                    || ("7".equals(inSession.getShikakuCheckbox()) && cntMonthAll < ssk_keiken_month1)
                                    || ("8".equals(inSession.getShikakuCheckbox()) && cntMonthAll < ssk_keiken_month1)
                                    || ("9".equals(inSession.getShikakuCheckbox()) && cntMonthAll < ssk_keiken_month1)
                                    || ("10".equals(inSession.getShikakuCheckbox()) && cntMonthAll < ssk_keiken_month1)) {
                                addError(errors, groupCode, itemName + "���s�����Ă��܂��B");
                            }
                        }
                    }

                    //�r����2��
                    if (BmaConstants.SHUBETSU_CODE_TWO.equals(inSession.getShubetsuCode())) {
                        if (("1".equals(inSession.getShikakuCheckbox()) && skkYear < 2)) {
                            addError(errors, groupCode, itemName + "���s�����Ă��܂��B");
                        }
                    }
                }

                if (errors.isEmpty()) {
                    /* ���i��Z�N�̐E�����m�F */
                    String gokakuNen = "";
                    int gokakugoHitsuyoNensu = 0;
                    Boolean result = true;
                    if (BmaConstants.SKN_KSU_CODE_BC.equals(inSession.getSknKsuCode()) && BmaConstants.SHUBETSU_CODE_ONE.equals(inSession.getShubetsuCode())) {
                        // BC1��
                        if (BmaConstants.SKK_CODE_02.equals(inSession.getShikakuCode())) {
                            // ���i�R�[�h0002 ���i��1�N
                            gokakuNen = inSession.getSskGokakuNo1();
                            gokakugoHitsuyoNensu = 1;
                            result = checkGokakugoShokureki(inSession, gokakuNen, gokakugoHitsuyoNensu);
                        } else if (BmaConstants.SKK_CODE_03.equals(inSession.getShikakuCode())) {
                            // ���i�R�[�h0003 ���i��3�N
                            gokakuNen = inSession.getSskGokakuNo5();
                            gokakugoHitsuyoNensu = 3;
                            result = checkGokakugoShokureki(inSession, gokakuNen, gokakugoHitsuyoNensu);
                        }
                    } else if (BmaConstants.SKN_KSU_CODE_BE.equals(inSession.getSknKsuCode()) && BmaConstants.SHUBETSU_CODE_ONE.equals(inSession.getShubetsuCode())) {
                        // BE1�� BE2���̐\����
                        if ("11".equals(inSession.getShikakuCheckbox2())) {
                            if (BmaConstants.SKK_CODE_10.equals(inSession.getShikakuCode())) {
                                // ���i�R�[�h0010 ���i��1�N
                                gokakuNen = inSession.getSskGokakuNo1();
                                gokakugoHitsuyoNensu = 1;
                                result = checkGokakugoShokureki(inSession, gokakuNen, gokakugoHitsuyoNensu);
                            } else {
                                // ���i�R�[�h0010�ȊO ���i��2�N
                                gokakuNen = inSession.getSskGokakuNo1();
                                gokakugoHitsuyoNensu = 2;
                                result = checkGokakugoShokureki(inSession, gokakuNen, gokakugoHitsuyoNensu);
                            }
                        }
                    }
                    if (!result) {
                        addError(errors, groupCode, "���i���" + itemName + "���s�����Ă��܂��B");
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        inSession.setErrors(errors);
        return errors.isEmpty();
    }

    /**
     * �a�@�V�K�̏ꍇ�A ��Ë@�ւ̐E�����̓��̓`�F�b�N
     *
     * @param inSession �Z�b�V����RTO
     * @return true:�G���[��
     */
    private boolean validateInputShokurekiIryou(MskSikakuJoho inSession, Messages errors) {
        String groupCode;
        String itemName;
        /*�E����e���X�g*/
        List<Option> shokumuNaiyoList = new ArrayList<Option>();
        //�a�@�V�K�̏ꍇ
        shokumuNaiyoList.add(new Option("05", "��Ë@��"));
        shokumuNaiyoList.add(new Option("06", "���̑�"));

        try {
            List<MskSikakuJoho> shokurekiList = inSession.getShokurekiList();
            if (shokurekiList.size() < 1) {
                addError(errors, "shokurekiChecked", "�E������1�ȏ�̃`�F�b�N�{�b�N�X��I�����Ă��������B");
            } else {
                int cntMonthAll = 0;
                int cntMonthIryo = 0;
                Boolean shokurekiChecked = false;
                //�E�����X�g��index �A�P����
                int i = 0;
                for (MskSikakuJoho shokureki : shokurekiList) {
                    i++;
                    //�`�F�b�N�����ꍇ
                    if ("1".equals(shokureki.getShokurekiSeq())) {
                        //�E�����`�F�b�N�����ꍇ
                        shokurekiChecked = true;

                        //�S�p�ϊ����s
                        shokureki.setKinmusakiKaishaName(BmaStringUtility.convertHankakuToZenkakuBma(shokureki.getKinmusakiKaishaName()));
                        shokureki.setBushoYakushokuName(BmaStringUtility.convertHankakuToZenkakuBma(shokureki.getBushoYakushokuName()));
                        shokureki.setShokurekiShozaichi(BmaStringUtility.convertHankakuToZenkakuBma(shokureki.getShokurekiShozaichi()));
//                        shokureki.setKinmuNaiyo(BmaStringUtility.convertHankakuToZenkakuBma(shokureki.getKinmuNaiyo()));

                        //��Ɩ�
                        groupCode = "kinmusakiKaishaName" + i;
                        itemName = "�E��" + i + "��" + "��Ɩ�";
                        BmaValidator.validateRequired(shokureki.getKinmusakiKaishaName(), errors, groupCode, itemName);
                        BmaValidator.validateMojiCode3(shokureki.getKinmusakiKaishaName(), errors, groupCode, itemName);
                        BmaValidator.validateMaxLength(shokureki.getKinmusakiKaishaName(), BmaConstants.MAX_LENGTH_SHIKUCHOSON_NAME, errors, groupCode, itemName);

                        //�z�����Ë@�֓�����
                        groupCode = "bushoYakushokuName" + i;
                        itemName = "�E��" + i + "��" + "�z�����Ë@�֓�����";
                        BmaValidator.validateRequired(shokureki.getBushoYakushokuName(), errors, groupCode, itemName);
                        BmaValidator.validateMojiCode3(shokureki.getBushoYakushokuName(), errors, groupCode, itemName);
                        BmaValidator.validateMaxLength(shokureki.getBushoYakushokuName(), BmaConstants.MAX_LENGTH_SHIKUCHOSON_NAME, errors, groupCode, itemName);

                        //���ݒn
                        groupCode = "shokurekiShozaichi" + i;
                        itemName = "�E��" + i + "��" + "���ݒn";
                        BmaValidator.validateRequired(shokureki.getShokurekiShozaichi(), errors, groupCode, itemName);
                        BmaValidator.validateMojiCode3(shokureki.getShokurekiShozaichi(), errors, groupCode, itemName);
                        BmaValidator.validateMaxLength(shokureki.getShokurekiShozaichi(), BmaConstants.MAX_LENGTH_SHIKUCHOSON_NAME, errors, groupCode, itemName);

                        //�E�����e
                        groupCode = "shokumuNaiyo" + i;
                        itemName = "�E��" + i + "��" + "�E�����e";
                        BmaValidator.validateSelect(shokureki.getShokumuNaiyo(), errors, groupCode, itemName);
                        BmaValidator.validatePermissionSelect(shokureki.getShokumuNaiyo(), shokumuNaiyoList, errors, groupCode, itemName);

                        //�ݐЊ���
                        groupCode = "zaisekikikanYearFrom";
                        itemName = "�E��" + i + "��" + "�ݐЊ��Ԃ̔N�e�q�n�l";
                        BmaValidator.validateRequired(shokureki.getZaisekikikanYearFrom(), errors, groupCode, itemName);
                        BmaValidator.validateNumber(shokureki.getZaisekikikanYearFrom(), errors, groupCode, itemName);
                        BmaValidator.validateEqualLength(shokureki.getZaisekikikanYearFrom(), 4, errors, groupCode, itemName);

                        groupCode = "zaisekikikanMonthFrom";
                        itemName = "�E��" + i + "��" + "�ݐЊ��Ԃ̌��e�q�n�l";
                        BmaValidator.validateRequired(shokureki.getZaisekikikanMonthFrom(), errors, groupCode, itemName);
                        BmaValidator.validateNumber(shokureki.getZaisekikikanMonthFrom(), errors, groupCode, itemName);
                        BmaValidator.validateEqualLength(shokureki.getZaisekikikanMonthFrom(), BmaConstants.MAX_LENGTH_BIRTHDAY_TSUKI, errors, groupCode, itemName);

                        groupCode = "zaisekikikanYearTo";
                        itemName = "�E��" + i + "��" + "�ݐЊ��Ԃ̔N�s�n";
                        BmaValidator.validateRequired(shokureki.getZaisekikikanYearTo(), errors, groupCode, itemName);
                        BmaValidator.validateNumber(shokureki.getZaisekikikanYearTo(), errors, groupCode, itemName);
                        BmaValidator.validateEqualLength(shokureki.getZaisekikikanYearTo(), 4, errors, groupCode, itemName);

                        groupCode = "zaisekikikanMonthTo";
                        itemName = "�E��" + i + "��" + "�ݐЊ��Ԃ̌��s�n";
                        BmaValidator.validateRequired(shokureki.getZaisekikikanMonthTo(), errors, groupCode, itemName);
                        BmaValidator.validateNumber(shokureki.getZaisekikikanMonthTo(), errors, groupCode, itemName);
                        BmaValidator.validateEqualLength(shokureki.getZaisekikikanMonthTo(), BmaConstants.MAX_LENGTH_BIRTHDAY_TSUKI, errors, groupCode, itemName);

                        groupCode = "zaisekikikan";
                        itemName = "�E��" + i + "��" + "�ݐЊ���";
                        if (!BmaUtility.isNullOrEmpty(shokureki.getZaisekikikanYearFrom())
                                && !BmaUtility.isNullOrEmpty(shokureki.getZaisekikikanMonthFrom())
                                && !BmaUtility.isNullOrEmpty(shokureki.getZaisekikikanYearTo())
                                && !BmaUtility.isNullOrEmpty(shokureki.getZaisekikikanMonthTo())) {
                            /*���ݓ��`�F�b�N*/
                            Boolean dateOk = true;
                            String dateFrom = shokureki.getZaisekikikanYearFrom() + shokureki.getZaisekikikanMonthFrom() + "01";
                            String dateTo = shokureki.getZaisekikikanYearTo() + shokureki.getZaisekikikanMonthTo() + "01";
                            if (!BmaValidator.validateDate(dateFrom, errors, groupCode, itemName + "�e�q�n�l")) {
                                dateOk = false;
                            }
                            if (!BmaValidator.validateDate(dateTo, errors, groupCode, itemName + "�s�n")) {
                                dateOk = false;
                            }
                            /*�召*/
                            if (dateOk && dateFrom.compareTo(dateTo) > 0) {
                                addError(errors, groupCode, "�E��" + i + "��" + "�ݐЊ���From�̓��t > �ݐЊ���To�̓��t�B");
                            }
                            //�E�����e����Ë@�ւ̏ꍇ,���Ԃ��v�Z����
                            if (dateOk && dateFrom.compareTo(dateTo) <= 0) {
                                if ("05".equals(shokureki.getShokumuNaiyo())) {
                                    cntMonthIryo = cntMonthIryo + BmaDateTimeUtility.differenceMonth(dateTo, dateFrom) + 1;
                                }
                                cntMonthAll = cntMonthAll + BmaDateTimeUtility.differenceMonth(dateTo, dateFrom) + 1;
                            }
                        }

                        //�Ζ����e
//                        groupCode = "kinmuNaiyo" + i;
//                        itemName = "�E��" + i + "��" + "�Ζ����e";
//                        BmaValidator.validateMojiCode3(shokureki.getKinmuNaiyo(), errors, groupCode, itemName);
//                        BmaValidator.validateMaxLength(shokureki.getKinmuNaiyo(), BmaConstants.MAX_LENGTH_SHIKUCHOSON_NAME, errors, groupCode, itemName);
                    }
                }

                if (!shokurekiChecked == true) {
                    addError(errors, "shokurekiChecked", "�E������1�ȏ�̃`�F�b�N�{�b�N�X��I�����Ă��������B");
                }

                //��u���i�A��Ë@�ւ̌���
                groupCode = "iryouMonth";
                itemName = "��Ë@�ւ̌���";
                if (cntMonthIryo < 6) {
                    addError(errors, groupCode, itemName + "���s�����Ă��܂��B");
                } else {
                    groupCode = "jukouMonth";
                    itemName = "�����o���N��";
//                    try {
//                        cntMonthAll = cntMonthAll + Integer.parseInt(inSession.getJitsumuKeikenDB());
//                    } catch (Exception e) {
//                        e.printStackTrace();
//                    }

                    //�����o���N��<�R�N�̏ꍇ
                    if (cntMonthAll < 36) {
                        addError(errors, groupCode, itemName + "���s�����Ă��܂��B");
                    } else {
                        inSession.setZaishokuKikanGokei(cntMonthAll / 12 + " �N " + cntMonthAll % 12 + " ����");
                    }
                }

            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        inSession.setErrors(errors);
        return errors.isEmpty();
    }

    /**
     * ���i�ԍ��i�C���ԍ��j�̓��̓`�F�b�N
     *
     * @param inSession �Z�b�V����RTO
     * @return true:�G���[��
     */
    private boolean validateInputSkkShuryoNo(MskSikakuJoho inSession, Messages errors) {
        String groupCode;
        String itemName;

        try {
            //IP followUp
            if (BmaConstants.SKN_KSU_CODE_IP.equals(inSession.getSknKsuCode())
                    && BmaConstants.SHUBETSU_CODE_FOLLOW_UP.equals(inSession.getShubetsuCode())) {
                /*�A�ԁA�����S���A0001�`9999 */
                List<String> renban4List = new ArrayList<String>();
                for (int i = 1; i <= 9999; i++) {
                    renban4List.add(String.format("%04d", i));
                }

                /**
                 * ���i���̃`�F�b�N�{�b�N�X *
                 */
                groupCode = "shikakuCheckbox";
                itemName = "���i";
                if (BmaUtility.isNullOrEmpty(inSession.getShikakuCheckbox())) {
                    addError(errors, groupCode, itemName + "����I�����Ă��������I");
                }

                //���i�ԍ��i�C���ԍ��j�F����
                groupCode = "shinseiShikakuNo1";
                itemName = "����̎��i�ԍ�";
                if ("1".equals(inSession.getShikakuCheckbox())) {
                    if (BmaUtility.isNullOrEmpty(inSession.getSskShuryoNo1())
                            || BmaUtility.isNullOrEmpty(inSession.getSskShuryoNo2())) {
                        addError(errors, groupCode, itemName + "����͂��Ă��������B");
                    } else {
                        if (inSession.getSskShuryoNo1().length() != 4
                                || inSession.getSskShuryoNo2().length() != 4
                                || !CheckUtility.isNumber(inSession.getSskShuryoNo1())
                                || !renban4List.contains(inSession.getSskShuryoNo2())) {
                            addError(errors, groupCode, itemName + "�̓��͂Ɍ�肪����܂��B");
                        }
                    }
                }

                //���i�ԍ��i�C���ԍ��j�F�Q��ڈȍ~
                groupCode = "shinseiShikakuNo2";
                itemName = "�Q��ڈȍ~�̎��i�ԍ�";
                if ("2".equals(inSession.getShikakuCheckbox())) {
                    if (BmaUtility.isNullOrEmpty(inSession.getSskShuryoNo3())
                            || BmaUtility.isNullOrEmpty(inSession.getSskShuryoNo4())
                            || BmaUtility.isNullOrEmpty(inSession.getSskShuryoNo5())) {
                        addError(errors, groupCode, itemName + "����͂��Ă��������B");
                    } else {
                        if (inSession.getSskShuryoNo3().length() != 4
                                || inSession.getSskShuryoNo4().length() != 1
                                || inSession.getSskShuryoNo5().length() != 4
                                || !CheckUtility.isNumber(inSession.getSskShuryoNo3())
                                || !"F".equals(inSession.getSskShuryoNo4())
                                || !renban4List.contains(inSession.getSskShuryoNo5())) {
                            addError(errors, groupCode, itemName + "�̓��͂Ɍ�肪����܂��B");
                        }
                    }
                }
            }

            //�a�@�y�āz (2)
            if (BmaConstants.SKN_KSU_CODE_HC.equals(inSession.getSknKsuCode())
                    && BmaConstants.SHUBETSU_CODE_SAIKSU.equals(inSession.getShubetsuCode())) {
                /*��u�敪,  N�i�V�K�j�AR�i�ču�K�j*/
                List<String> jukouKbnList = new ArrayList<String>();
                jukouKbnList.add("N");
                jukouKbnList.add("R");
                /*�A�ԁA�����T���A00001�`99999 */
                List<String> renban5List = new ArrayList<String>();
                for (int i = 1; i <= 99999; i++) {
                    renban5List.add(String.format("%05d", i));
                }

                //���i�ԍ��i�C���ԍ��j
                groupCode = "shinseiShikakuNo";
                itemName = "���i�ԍ�";
                if (BmaUtility.isNullOrEmpty(inSession.getSskShuryoNo1())
                        && BmaUtility.isNullOrEmpty(inSession.getSskShuryoNo2())) {
                    addError(errors, groupCode, itemName + "����͂��Ă��������B");
                } else {
                    if (inSession.getSskShuryoNo1().length() != 1
                            || inSession.getSskShuryoNo2().length() != 5
                            || !jukouKbnList.contains(inSession.getSskShuryoNo1())
                            || !renban5List.contains(inSession.getSskShuryoNo2())) {
                        addError(errors, groupCode, itemName + "�̓��͂Ɍ�肪����܂��B");
                    }
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }

        inSession.setErrors(errors);
        return errors.isEmpty();
    }

    /**
     * �E�����X�g�̐ݒ�
     *
     * @param inSession �\�����i���Z�b�V����
     */
    public void setShokurekiListJoho(MskSikakuJoho inSession) {
        /**
         * �E�����  *
         */
        //�Z�b�V�����ɑ��݂��Ȃ��ꍇ
        if (inSession.getShokurekiList().size() < 1) {
            Shokureki shokureki = new Shokureki(DATA_SOURCE_NAME);
            //�E���e�[�u������擾
            List<Shokureki> shokurekiList;
            List<MskSikakuJoho> shokurekiJohoList;
            MskSikakuJoho shokurekiJoho;
            //�E���敪(1 : �E��;  4 : �P����)
            shokurekiList = shokureki.getShokurekiListByMoshikomishaId(inSession.getMoshikomishaId(), inSession.getShokurekiKbn());

            if (shokurekiList.size() > 0) {
                shokurekiJohoList = new ArrayList<MskSikakuJoho>();
                int i = 0;
                for (Shokureki shokureki1 : shokurekiList) {
                    shokurekiJoho = new MskSikakuJoho();
                    //���ڂ̐E�����`�F�b�N
                    i++;
                    if (i == 1) {
                        shokurekiJoho.setShokurekiSeq("1");
                    }
                    shokurekiJoho.setKinmusakiKaishaName(shokureki1.getKinmusakiKaishaName());
                    shokurekiJoho.setBushoYakushokuName(shokureki1.getBushoYakushokuName());
                    shokurekiJoho.setShokumuNaiyo(shokureki1.getShokumuNaiyo());
                    shokurekiJoho.setShokurekiShozaichi(shokureki1.getShozaichi());
                    if (!BmaUtility.isNullOrEmpty(shokureki1.getZaisekikikanFrom())) {
                        shokurekiJoho.setZaisekikikanYearFrom(shokureki1.getZaisekikikanFrom().substring(0, 4));
                        shokurekiJoho.setZaisekikikanMonthFrom(shokureki1.getZaisekikikanFrom().substring(4, 6));
                    }
                    if (!BmaUtility.isNullOrEmpty(shokureki1.getZaisekikikanTo())) {
                        shokurekiJoho.setZaisekikikanYearTo(shokureki1.getZaisekikikanTo().substring(0, 4));
                        shokurekiJoho.setZaisekikikanMonthTo(shokureki1.getZaisekikikanTo().substring(4, 6));
                    }
                    shokurekiJohoList.add(shokurekiJoho);
                }
                inSession.setShokurekiList(shokurekiJohoList);
            } else {
                //��ł��Ȃ��ꍇ, �ǉ�
                shokurekiJohoList = new ArrayList<MskSikakuJoho>();
                shokurekiJoho = new MskSikakuJoho();
                shokurekiJoho.setShokurekiSeq("1");
                shokurekiJohoList.add(shokurekiJoho);
                inSession.setShokurekiList(shokurekiJohoList);
            }
        }
    }

    /**
     * ���i�����u���i��Z�N�̎����o���v�̔���
     *
     * @param inSession �\�����i���Z�b�V����
     * @param gokakuNen ���i�N�i���2���j
     * @param gokakugoHitsuyoNensu ���i��ɕK�v�Ȏ����o���N��
     * @return result ���i��̔N���𖞂����Ă����true�A����ȊO��false
     */
    public Boolean checkGokakugoShokureki(MskSikakuJoho inSession, String gokakuNen, int gokakugoHitsuyoNensu) {
        Boolean result = false;
        int gokakuNendo = 0;
        int cntMonthAll = 0;
        String gokakuDate = "";
        String dateFrom = "";
        String dateTo = "";
        String calcDateFrom = "";
        String calcDateTo = "";

        try {
            // ���i�ԍ�����A���i�N�������擾
            gokakuNendo = Integer.parseInt(GOKAKU_SHOKUREKI_NEN) + Integer.parseInt(gokakuNen);
            gokakuDate = String.valueOf(gokakuNendo) + GOKAKU_SHOKUREKI_TSUKIHI;

            //�E�����X�g��index �A�P����
            for (MskSikakuJoho shokureki : inSession.getShokurekiList()) {
                //�`�F�b�N�����ꍇ
                if ("1".equals(shokureki.getShokurekiSeq())) {
                    dateFrom = shokureki.getZaisekikikanYearFrom() + shokureki.getZaisekikikanMonthFrom() + "01";
                    dateTo = shokureki.getZaisekikikanYearTo() + shokureki.getZaisekikikanMonthTo() + "01";

                    if (dateTo.compareTo(gokakuDate) < 0) {
                        // ���i�ȑO�̐E����Skip
                        continue;
                    }
                    // �ݐЊ���From�Ɣ�r
                    if (dateFrom.compareTo(gokakuDate) < 0) {
                        // ���i�N�������O�̐E���́A���i�N�������g�p
                        calcDateFrom = gokakuDate;
                    } else {
                        // ���i�N�����ȍ~�̐E���́A�E��From���g�p
                        calcDateFrom = dateFrom;
                    }
                    // �ݐЊ���To�Ɣ�r
                    if (dateTo.compareTo(gokakuDate) > 0) {
                        // ���i�N��������̐E���́A�E��To���g�p
                        calcDateTo = dateTo;
                    } else {
                        // ���i�N�����ȑO�̐E���́A���i�N�������g�p
                        calcDateTo = gokakuDate;
                    }
                    cntMonthAll = cntMonthAll + BmaDateTimeUtility.differenceMonth(calcDateTo, calcDateFrom) + 1;
                }
            }

            int skkYear = cntMonthAll / 12;
            // ���i��ɕK�v�Ȍo���N���𒴂��Ă����true��Ԃ�
            if (gokakugoHitsuyoNensu <= skkYear) {
                result = true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return result;
    }

    /**
     * �����̓`�F�b�N���s�� ���͒l��null,�u�����N,���p�X�y�[�X�݂̂̏ꍇfalse ����ȊO�̏ꍇtrue��Ԃ�
     * ���ʂ������擾�������ꍇ�AMessages�I�u�W�F�N�g��null���Z�b�g���� ���b�Z�[�W�E���\�[�X�L�[:"errors.required"
     *
     * @param errors Messages�I�u�W�F�N�g
     * @param errGroupName Messages�̃O���[�v��
     * @param newMessage ���b�Z�[�W�ɕ\�����鍀�ږ�
     */
    protected static void addError(Messages errors, String errGroupName, String newMessage) {
        if (errors != null) {
            Message error = errors.get(errGroupName);
            if (error != null) {
                // �����O���[�v�̃G���[�����ɂ���΃��b�Z�[�W�𑫂�����
                error.add(newMessage);
            } else {
                // �����O���[�v�̃G���[���܂��Ȃ���΃G���[������ă��b�Z�[�W�𑫂����ăG���[��o�^
                error = new Message();
                error.add(newMessage);
                errors.put(errGroupName, error);
            }
        }
    }

    /**
     * ���i���̐ݒ�
     *
     * @param inSession �\�����i���Z�b�V����
     */
    public void setShikakuJoho(MskSikakuJoho inSession) {
        //�����̏ꍇ
        if(BmaConstants.SKN_KBN.equals(inSession.getSknKsuKbn())){
            /** �\�����i�ԍ� */
            if (("01".equals(inSession.getSknNaiyoKbn()))
                    || ("04".equals(inSession.getSknNaiyoKbn()))
                    || ("05".equals(inSession.getSknNaiyoKbn()))
                    || (("02".equals(inSession.getSknNaiyoKbn())) || ("03".equals(inSession.getSknNaiyoKbn()))) && (BmaConstants.FLG_OFF.equals(inSession.getHoyuMenjoAriFlg()))) {
                String checkedBox = inSession.getShikakuCheckbox();
                //�r���N�̏ꍇ
                if (BmaConstants.SKN_KSU_CODE_BC.equals(inSession.getSknKsuCode())) {
                    //�r���N1�̏ꍇ
                    if (BmaConstants.SHUBETSU_CODE_ONE.equals(inSession.getShubetsuCode())) {
                        switch (checkedBox) {
                            case "1":
                                inSession.setJukenSikaku("5�N�ȏ�̎����o��������");
                                inSession.setShinseiShikakuTitle("");
                                break;
                            case "2":
                                inSession.setJukenSikaku("�r���N���[�j���O�Z�\����  2��  �̍��i��");
                                inSession.setShinseiShikakuTitle("���i�ԍ�");
                                break;
                            case "3":
                                inSession.setJukenSikaku("�r���N���[�j���O�Z�\����  3��  �̍��i��");
                                inSession.setShinseiShikakuTitle("���i�ԍ�");
                                break;
                            case "4":
                                inSession.setJukenSikaku("���z���q���Ǘ��ۂ̐E�ƌP���w�����Ƌ���L�����");
                                inSession.setShinseiShikakuTitle("");
                                break;
                            case "5":
                                inSession.setJukenSikaku("�r���N���[�j���O�Ɋւ���Z���ے��̕��ʐE�ƌP���ő����ԂV�O�O���Ԉȏ�̂��̂��C��");
                                inSession.setShinseiShikakuTitle("");
                                break;
                            default:
                                inSession.setJukenSikaku("");
                                inSession.setShinseiShikakuTitle("");
                        }
                    }
                    //�r���N2�̏ꍇ
                    if (BmaConstants.SHUBETSU_CODE_TWO.equals(inSession.getShubetsuCode())) {
                        switch (checkedBox) {
                            case "1":
                                inSession.setJukenSikaku("2�N�ȏ�̎����o��������");
                                inSession.setShinseiShikakuTitle("");
                                break;
                            case "2":
                                inSession.setJukenSikaku("�r���N���[�j���O�Z�\�m  3��  �̍��i��");
                                inSession.setShinseiShikakuTitle("���i�ԍ�");
                                break;
                            case "3":
                                inSession.setJukenSikaku("���z���q���Ǘ��Ȃ̐E�ƌP���w�����Ƌ���L�����");
                                inSession.setShinseiShikakuTitle("");
                                break;
                            case "4":
                                inSession.setJukenSikaku("�r���N���[�j���O�Ɋւ���Z���ے��̕��ʐE�ƌP���ő����ԂV�O�O���Ԉȏ�̂��̂��C��");
                                inSession.setShinseiShikakuTitle("");
                                break;
                            default:
                                inSession.setJukenSikaku("");
                                inSession.setShinseiShikakuTitle("");
                        }
                    }
                    //�r���N3�̏ꍇ
                    if (BmaConstants.SHUBETSU_CODE_THREE.equals(inSession.getShubetsuCode())) {
                        switch (checkedBox) {
                            case "1":
                                inSession.setJukenSikaku("�r���N���[�j���O�Ɩ��ɏ]�����Ă���Җ��͏]�����悤�Ƃ����");
                                inSession.setShinseiShikakuTitle("");
                                break;
                            default:
                                inSession.setJukenSikaku("");
                                inSession.setShinseiShikakuTitle("");
                        }
                    }
                }

                //�r���݂̏ꍇ
                if (BmaConstants.SKN_KSU_CODE_BE.equals(inSession.getSknKsuCode())) {
                    switch (checkedBox) {
                        case "1":
                            inSession.setJukenSikaku("�r���ݔ��Ǘ��Ɋւ�������o���̂�");
                            break;
                        case "2":
                            inSession.setJukenSikaku("�r���ݔ��Ǘ��Ɋւ��鍂�Z����");
                            break;
                        case "3":
                            inSession.setJukenSikaku("�r���ݔ��Ǘ��Ɋւ���Z��E����E���Z��U�ȑ���");
                            break;
                        case "4":
                            inSession.setJukenSikaku("�r���ݔ��Ǘ��Ɋւ����w����");
                            break;
                        case "5":
                            inSession.setJukenSikaku("�r���ݔ��Ǘ��Ɋւ����C�w�Z���͊e��w�Z���Ɓi800���Ԉȏ�j");
                            break;
                        case "6":
                            inSession.setJukenSikaku("�r���ݔ��Ǘ��Ɋւ����C�w�Z���͊e��w�Z���Ɓi3,200���Ԉȏ�j");
                            break;
                        case "7":
                            inSession.setJukenSikaku("�r���ݔ��Ǘ��Ɋւ���Z���ے��̕��ʐE�ƌP���C���i700���Ԉȏ�j");
                            break;
                        case "8":
                            inSession.setJukenSikaku("�r���ݔ��Ǘ��Ɋւ��镁�ʉے��̕��ʐE�ƌP���C���i2,800���Ԗ����j");
                            break;
                        case "9":
                            inSession.setJukenSikaku("�r���ݔ��Ǘ��Ɋւ��镁�ʉے��̕��ʐE�ƌP���C���i2,800���Ԉȏ�j");
                            break;
                        case "10":
                            inSession.setJukenSikaku("���z�ݔ��Ǘ��Ǘ��Ȃ̐E�ƌP���w�����Ƌ��擾");
                            break;
                        default:
                            inSession.setJukenSikaku("");
                            inSession.setShinseiShikakuTitle("");
                    }
                    if ("11".equals(inSession.getShikakuCheckbox2()) && !BmaUtility.isNullOrEmpty(inSession.getShinseiShikakuNo())) {
                        inSession.setShinseiShikakuTitle("���i�ԍ�");
                    } else {
                        inSession.setShinseiShikakuTitle("");
                    }
                }
            }
        }

        //�u�K��̏ꍇ
        if (BmaConstants.KSU_KBN.equals(inSession.getSknKsuKbn())) {
            String checkedBox = inSession.getShikakuCheckbox();
            //IP�̏ꍇ
            if (BmaConstants.SKN_KSU_CODE_IP.equals(inSession.getSknKsuCode())) {
                //IP�V�K�̏ꍇ
                if (BmaConstants.SHUBETSU_CODE_NEW.equals(inSession.getShubetsuCode())) {
                    switch (checkedBox) {
                        case "1":
                            inSession.setJukenSikaku("1��  �r���N���[�j���O�Z�\�m");
                            inSession.setShinseiShikakuTitle("���i�ԍ�");
                            break;
                        case "2":
                            inSession.setJukenSikaku("�P�ꓙ��  �r���N���[�j���O�Z�\�m");
                            inSession.setShinseiShikakuTitle("���i�ԍ�");
                            break;
                        case "3":
                            inSession.setJukenSikaku("���|��Ɗē�");
                            inSession.setShinseiShikakuTitle("���i�ԍ�");
                            break;
                        case "4":
                            inSession.setJukenSikaku("���z�����q���Ǘ��Z�p��");
                            inSession.setShinseiShikakuTitle("���i�ԍ�");
                            break;
                        case "5":
                            inSession.setJukenSikaku("�����Ǘ���");
                            inSession.setShinseiShikakuTitle("���i�ԍ�");
                            break;
                        default:
                            inSession.setJukenSikaku("");
                            inSession.setShinseiShikakuTitle("");
                    }
                }
                //IP followUp�̏ꍇ
                if (BmaConstants.SHUBETSU_CODE_FOLLOW_UP.equals(inSession.getShubetsuCode())) {
                    switch (checkedBox) {
                        case "1":
                            inSession.setJukenSikaku("���i�ԍ��i�C���ԍ��j");
                            inSession.setShinseiShikakuTitle("����");
                            break;
                        case "2":
                            inSession.setJukenSikaku("���i�ԍ��i�C���ԍ��j");
                            inSession.setShinseiShikakuTitle("�Q��ڈȍ~");
                            break;
                        default:
                            inSession.setJukenSikaku("");
                            inSession.setShinseiShikakuTitle("");
                    }
                }
            }

            //�a�@�̏ꍇ
            if (BmaConstants.SKN_KSU_CODE_HC.equals(inSession.getSknKsuCode())) {
                //�a�@�V�K�̏ꍇ
                if (BmaConstants.SHUBETSU_CODE_NEW.equals(inSession.getShubetsuCode())) {
                    inSession.setJukenSikaku("");
                    inSession.setShinseiShikakuTitle("");
                }
                //�a�@�ču�K�̏ꍇ
                if (BmaConstants.SHUBETSU_CODE_SAIKSU.equals(inSession.getShubetsuCode())) {
                    inSession.setJukenSikaku("���i�ԍ��i�C���ԍ��j");
                    inSession.setShinseiShikakuTitle(NENDO_3YEARS_BEFORE + "�N�x");
                }
            }
        }
    }

    /**
     * �Ə����̐ݒ�
     * �Ə��R�[�h��������Őݒ肷��
     *
     * @param inSession �\�����i���Z�b�V����
     */
    public void setMenjoJoho(MskSikakuJoho inSession) {
        //�����̏ꍇ
        if (BmaConstants.SKN_KBN.equals(inSession.getSknKsuKbn())) {
            /**
             * �\���Ə��ԍ�
             */
            if ("02".equals(inSession.getSknNaiyoKbn()) || "03".equals(inSession.getSknNaiyoKbn())) {
                String checkedBox = inSession.getMenjoCheckbox();
                //�r���N�̏ꍇ
                if (BmaConstants.SKN_KSU_CODE_BC.equals(inSession.getSknKsuCode())) {
                    switch (checkedBox) {
                        case "1":
                            inSession.setJukenMenjo("�r���N���[�j���O�Z�\����  �̈ꕔ���i��");
                            if ("02".equals(inSession.getSknNaiyoKbn())) {
                                inSession.setShinseiMenjoTitle("�w�ȍ��i�ԍ�");
                                if ("1".equals(inSession.getMenjoGakaGokakuNo2())) {
                                    inSession.setMenjoCode("0001");
                                } else if ("2".equals(inSession.getMenjoGakaGokakuNo2())) {
                                    inSession.setMenjoCode("0003");
                                } else if ("3".equals(inSession.getMenjoGakaGokakuNo2())) {
                                    inSession.setMenjoCode("0005");
                                }
                            } else if ("03".equals(inSession.getSknNaiyoKbn())) {
                                inSession.setShinseiMenjoTitle("���Z���i�ԍ�");
                                if ("1".equals(inSession.getMenjoGakaGokakuNo2())) {
                                    inSession.setMenjoCode("0002");
                                } else if ("2".equals(inSession.getMenjoGakaGokakuNo2())) {
                                    inSession.setMenjoCode("0004");
                                } else if ("3".equals(inSession.getMenjoGakaGokakuNo2())) {
                                    inSession.setMenjoCode("0006");
                                }
                            }
                            break;
                        case "2":
                            inSession.setJukenMenjo("�����Q�V�N�x�܂ł̒P�ꓙ���ɂ��r���N���[�j���O�Z�\����̈ꕔ���i��");
                            if ("02".equals(inSession.getSknNaiyoKbn())) {
                                inSession.setShinseiMenjoTitle("�w�ȍ��i�ԍ�");
                                if (BmaConstants.SHUBETSU_CODE_ONE.equals(inSession.getShubetsuCode())) {
                                    inSession.setMenjoCode("0003");
                                } else if (BmaConstants.SHUBETSU_CODE_TWO.equals(inSession.getShubetsuCode())) {
                                    inSession.setMenjoCode("0005");
                                } else if (BmaConstants.SHUBETSU_CODE_THREE.equals(inSession.getShubetsuCode())) {
                                    inSession.setMenjoCode("0007");
                                }
                            } else {
                                inSession.setShinseiMenjoTitle("���Z���i�ԍ�");
                                if (BmaConstants.SHUBETSU_CODE_ONE.equals(inSession.getShubetsuCode())) {
                                    inSession.setMenjoCode("0004");
                                } else if (BmaConstants.SHUBETSU_CODE_TWO.equals(inSession.getShubetsuCode())) {
                                    inSession.setMenjoCode("0006");
                                } else if (BmaConstants.SHUBETSU_CODE_THREE.equals(inSession.getShubetsuCode())) {
                                    inSession.setMenjoCode("0008");
                                }
                            }
                            break;
                        case "3":
                            inSession.setJukenMenjo("�r���N���[�j���O�E��ɌW��Z���ے��̕��ʐE�ƌP�����I�m�ɍs��ꂽ�ƔF�߂���C���������̍��i��");
                            inSession.setShinseiMenjoTitle("");
                                if (BmaConstants.SHUBETSU_CODE_ONE.equals(inSession.getShubetsuCode())) {
                                    inSession.setMenjoCode("0005");
                                } else if (BmaConstants.SHUBETSU_CODE_TWO.equals(inSession.getShubetsuCode())) {
                                    if ("1".equals(inSession.getMenjoKyu())) {
                                        inSession.setMenjoCode("0007");
                                    } else if ("2".equals(inSession.getMenjoKyu())) {
                                        inSession.setMenjoCode("0008");
                                    }
                                }
                            break;
                        default:
                            inSession.setJukenMenjo("");
                            inSession.setShinseiMenjoTitle("");
                            inSession.setMenjoCode("");
                    }
                }

                //�r���݂̏ꍇ
                if (BmaConstants.SKN_KSU_CODE_BE.equals(inSession.getSknKsuCode())) {
                    switch (checkedBox) {
                        case "1":
                            inSession.setJukenMenjo("�r���ݔ��Ǘ��Z�\����  �̈ꕔ���i��");
                            if ("02".equals(inSession.getSknNaiyoKbn())) {
                                inSession.setShinseiMenjoTitle("�w�ȍ��i�ԍ�");
                                if ("1".equals(inSession.getMenjoGakaGokakuNo2())) {
                                    inSession.setMenjoCode("0001");
                                } else if ("2".equals(inSession.getMenjoGakaGokakuNo2())) {
                                    inSession.setMenjoCode("0003");
                                }
                            } else {
                                inSession.setShinseiMenjoTitle("���Z���i�ԍ�");
                                if ("1".equals(inSession.getMenjoGakaGokakuNo2())) {
                                    inSession.setMenjoCode("0002");
                                } else if ("2".equals(inSession.getMenjoGakaGokakuNo2())) {
                                    inSession.setMenjoCode("0004");
                                }
                            }
                            break;
                        case "2":
                            inSession.setJukenMenjo("�E�ƌP���w���������ɍ��i�����Җ��͐E�ƌP���w�����Ƌ����󂯂���");
                            inSession.setShinseiMenjoTitle("");
                            if (BmaConstants.SHUBETSU_CODE_ONE.equals(inSession.getShubetsuCode())) {
                                inSession.setMenjoCode("0003");
                            } else if (BmaConstants.SHUBETSU_CODE_TWO.equals(inSession.getShubetsuCode())) {
                                inSession.setMenjoCode("0005");
                            }
                            break;
                        case "3":
                            inSession.setJukenMenjo("�Z�\�m�R�[�X�ɂ�����C���������̍��i�҂ŁA���Y�P�����C��������");
                            inSession.setShinseiMenjoTitle("");
                                if (BmaConstants.SHUBETSU_CODE_ONE.equals(inSession.getShubetsuCode())) {
                                    inSession.setMenjoCode("0004");
                                } else if (BmaConstants.SHUBETSU_CODE_TWO.equals(inSession.getShubetsuCode())) {
                                    if ("1".equals(inSession.getMenjoKyu())) {
                                        inSession.setMenjoCode("0006");
                                    } else if ("2".equals(inSession.getMenjoKyu())) {
                                        inSession.setMenjoCode("0007");
                                    }
                                }
                            break;
                        default:
                            inSession.setJukenMenjo("");
                            inSession.setShinseiMenjoTitle("");
                            inSession.setMenjoCode("");
                    }
                }
            }
        }
    }

    /**
     * �Ə��L���Ȏ�ʃR�[�h�ݒ�
     *
     * @param hoyuMenjoMst �ۗL�Ə��}�X�^�f�[�^
     */
    public void setYukoShubetsuCodes(HoyuMenjoMst hoyuMenjoMst, String[] shubetsuCodes) {
        if (BmaConstants.SKN_KSU_CODE_BC.equals(hoyuMenjoMst.getSknKsuCode())) {
            if (BmaConstants.SHUBETSU_CODE_ONE.equals(hoyuMenjoMst.getShubetsuCode())) {
                shubetsuCodes[0] = BmaConstants.SHUBETSU_CODE_ONE;
                shubetsuCodes[1] = BmaConstants.SHUBETSU_CODE_TANITI;
            } else if (BmaConstants.SHUBETSU_CODE_TWO.equals(hoyuMenjoMst.getShubetsuCode())) {
                shubetsuCodes[0] = BmaConstants.SHUBETSU_CODE_ONE;
                shubetsuCodes[1] = BmaConstants.SHUBETSU_CODE_TWO;
                shubetsuCodes[2] = BmaConstants.SHUBETSU_CODE_TANITI;
            } else if (BmaConstants.SHUBETSU_CODE_THREE.equals(hoyuMenjoMst.getShubetsuCode())) {
                shubetsuCodes[0] = BmaConstants.SHUBETSU_CODE_ONE;
                shubetsuCodes[1] = BmaConstants.SHUBETSU_CODE_TWO;
                shubetsuCodes[2] = BmaConstants.SHUBETSU_CODE_THREE;
                shubetsuCodes[3] = BmaConstants.SHUBETSU_CODE_TANITI;
            }
        } else if (BmaConstants.SKN_KSU_CODE_BE.equals(hoyuMenjoMst.getSknKsuCode())) {
            if (BmaConstants.SHUBETSU_CODE_ONE.equals(hoyuMenjoMst.getShubetsuCode())) {
                shubetsuCodes[0] = BmaConstants.SHUBETSU_CODE_ONE;
            } else if (BmaConstants.SHUBETSU_CODE_TWO.equals(hoyuMenjoMst.getShubetsuCode())) {
                shubetsuCodes[0] = BmaConstants.SHUBETSU_CODE_ONE;
                shubetsuCodes[1] = BmaConstants.SHUBETSU_CODE_TWO;
            }
        }
    }
}
