package jp.co.nii.bma.integration;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import jp.co.nii.bma.business.domain.MeishoKanriDao;
import jp.co.nii.sew.common.LogGenerate;
import jp.co.nii.sew.integration.SQLStateSQLExceptionTranslater;
import jp.co.nii.sew.presentation.Option;

/**
 * ���̊Ǘ� DAO�����N���X
 * @author DB�Ǘ��c�[��
 */
public class MeishoKanriDaoImpl extends GeneratedMeishoKanriDaoImpl implements MeishoKanriDao {

    /**
     * �C���X�^���X�𐶐�����B
     * @param datasource �f�[�^�\�[�X��
     */
    public MeishoKanriDaoImpl(String datasource) {
        super(datasource);
    }
    
    /**
     * �O���[�v�R�[�h���烊�X�g�ƃ}�b�v���擾����
     *
     * @param groupCode
     * @param list
     * @param map
     */
    @Override
    public void findByGroupCode(String groupCode, List<Option> list, Map<String, String> map) {

        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql;
        ArrayList<String> paramList = new ArrayList<String>();

        try {
            con = getConnection();
            sql = "SELECT " + FIELDS_DECRYPT
                    + " FROM " + getSchemaName() + "." + TABLE_NAME
                    + " WHERE"
                    + " GROUP_CODE = ?"
                    + " AND RONRI_SAKUJO_FLG = '0'"
                    + " ORDER BY to_number(HYOJI_JUNJO,'999')";

            paramList.add(groupCode);
            stmt = con.prepareStatement(sql);

            int i = 1;
            for (String param : paramList) {
                stmt.setString(i++, param);
            }
            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();

            while (rs.next()) {
                if (list != null) {
                    list.add(new Option(rs.getString("HANYO_CODE"), rs.getString("HANYO_CHI")));
                }
                if (map != null) {
                    map.put(rs.getString("HANYO_CODE"), rs.getString("HANYO_CHI"));
                }
            }

        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
    }
    
    /**
     * �O���[�v�R�[�h�Ɣėp�l����s���{���R�[�h���擾����
     *
     * @param groupCode
     * @param hanyochi
     */
    @Override
    public String findByHanyochi(String groupCode, String hanyochi) {
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql;
        ArrayList<String> paramList = new ArrayList<String>();
        String todofukenCode = "";

        try {
            con = getConnection();
            sql = "SELECT " + FIELDS_DECRYPT
                    + " FROM " + getSchemaName() + "." + TABLE_NAME
                    + " WHERE"
                    + " GROUP_CODE = ?"
                    + " AND HANYO_CHI LIKE ?"
                    + " AND RONRI_SAKUJO_FLG = '0'"
                    + " ORDER BY to_number(HYOJI_JUNJO,'999')"
                    + " LIMIT 1";

            paramList.add(groupCode);
            paramList.add(hanyochi + "%");
            stmt = con.prepareStatement(sql);

            int i = 1;
            for (String param : paramList) {
                stmt.setString(i++, param);
            }
            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();

            while (rs.next()) {
                    todofukenCode = rs.getString("HANYO_CODE");
            }

        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return todofukenCode;
    }
}
