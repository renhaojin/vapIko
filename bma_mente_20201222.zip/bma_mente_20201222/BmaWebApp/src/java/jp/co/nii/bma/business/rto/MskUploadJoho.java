package jp.co.nii.bma.business.rto;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import jp.co.nii.bma.business.domain.Gazo;
import jp.co.nii.bma.business.domain.HoyuShikakuMst;
import jp.co.nii.bma.business.domain.MSkkMnjKanri;
import jp.co.nii.bma.business.domain.Moshikomi;
import jp.co.nii.bma.business.domain.Shokureki;
import jp.co.nii.bma.business.domain.Torokusha;
import jp.co.nii.bma.business.service.moshikomi.MskUploadGroupService;
import jp.co.nii.sew.presentation.DownloadRTO;
import jp.co.nii.sew.presentation.Messages;
import org.apache.commons.fileupload.disk.DiskFileItem;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;

/**
 * �^�C�g��: �\���f�[�^�A�b�v���[�h ����: �\�����RTO ���쌠: Copyright (c) 2020 ��Ж�: ���{���Y�Ɗ������
 *
 * @author Luo-Yang
 */
public class MskUploadJoho extends DownloadRTO {

    private Messages errors;
    private String sknksuKbn;
    private String moshikomishaId;
    private String mskTmpDl;
    private String sknName;
    private String ksuName;
    private String sknKsuCode;
    private String shubetsuCode;
    private String kaisuCode;
    private String nendo;
    private DiskFileItem mskFileChoice;
    private String shomenMsk;
    private String[] uketsukeNos;
    private Workbook workbook;
    private List<String> errorLog;
    private List<String> shomenNoList;
    private String uploadCheck;
    private Sheet sheet;
    private String fileName;
    private Map<String, Object> excelMap;
    private List<Object>[] excelList;
    private HashMap<String, List<Object>[]> excelListMap;
    private Map<String, List<Object>[]> excelSyukeiList;
    private int sheetNo;
    private String mskUl;
    private String csvFlg;
    private String uketsukeNo;
    private String shimei;
    private String furigana;
    private String birthday;
    private String nenrei;
    private String sex;
    private String yubinNo;
    private String todofuken;
    private String jusho1;
    private String jusho2;
    private String tatemono;
    private String telNo;
    private String faxNo;
    private String kaijoSentakuNext;
    private String mailAddress;
    private String kinmusakiYubinNo;
    private String kinmusakiTodofuken;
    private String kinmusakiJusho1;
    private String kinmusakiJusho2;
    private String kaijoCode;
    private String kuusekiSuu;
    private String kinmusakiTatemono;
    private String kinmusakiTelNo;
    private String kinmusakiFaxNo;
    private String sofuSakiKbn;
    private String shikenNaiyoKbn;
    private String kiboShikenchi;
    private String genmenFlg;
    private String gaijiFlg;
    private String gaijiShosai;
    private String jukenSkkCode;
    private String jukenSkkNo;
    private String kurenrekiName;
    private String kurenrekiNaiyo;
    private String kurenrekiShozaichi;
    private String kurenrekiFrom;
    private String kurenrekiTo;
    private String gakurekiName;
    private String gakurekiNaiyo;
    private String gakurekiShozaichi;
    private String gakurekiDate;
    private String kinmusakiKaishaName0;
    private String bushoYakushokuName0;
    private String shozaichi0;
    private String shokumuNaiyo0;
    private String zaisekikikanFrom0;
    private String zaisekikikanTo0;
    private String kinmusakiKaishaName1;
    private String bushoYakushokuName1;
    private String shozaichi1;
    private String shokumuNaiyo1;
    private String zaisekikikanFrom1;
    private String zaisekikikanTo1;
    private String kinmusakiKaishaName2;
    private String bushoYakushokuName2;
    private String shozaichi2;
    private String shokumuNaiyo2;
    private String zaisekikikanFrom2;
    private String zaisekikikanTo2;
    private String kinmusakiKaishaName3;
    private String bushoYakushokuName3;
    private String shozaichi3;
    private String shokumuNaiyo3;
    private String zaisekikikanFrom3;
    private String zaisekikikanTo3;
    private String kinmusakiKaishaName4;
    private String bushoYakushokuName4;
    private String shozaichi4;
    private String shokumuNaiyo4;
    private String zaisekikikanFrom4;
    private String zaisekikikanTo4;
    private String kinmusakiKaishaName5;
    private String bushoYakushokuName5;
    private String shozaichi5;
    private String shokumuNaiyo5;
    private String zaisekikikanFrom5;
    private String zaisekikikanTo5;
    private String kinmusakiKaishaName6;
    private String bushoYakushokuName6;
    private String shozaichi6;
    private String shokumuNaiyo6;
    private String zaisekikikanFrom6;
    private String zaisekikikanTo6;
    private String kinmusakiKaishaName7;
    private String bushoYakushokuName7;
    private String shozaichi7;
    private String shokumuNaiyo7;
    private String zaisekikikanFrom7;
    private String zaisekikikanTo7;
    private String kinmusakiKaishaName8;
    private String bushoYakushokuName8;
    private String shozaichi8;
    private String shokumuNaiyo8;
    private String zaisekikikanFrom8;
    private String zaisekikikanTo8;
    private String kinmusakiKaishaName9;
    private String bushoYakushokuName9;
    private String shozaichi9;
    private String shokumuNaiyo9;
    private String zaisekikikanFrom9;
    private String zaisekikikanTo9;
    private String kinmusakiKaishaName10;
    private String bushoYakushokuName10;
    private String shozaichi10;
    private String shokumuNaiyo10;
    private String zaisekikikanFrom10;
    private String zaisekikikanTo10;
    private String menjoSkkCode;
    private String menjoSkkNo;
    private String kaijoId1;
    private String kaijoId2;
    private String shomenUketsukeNo;
    private String shuryouSkkNo;
    private String shikakuCode01;
    private String shikakuCode02;
    private String shikakuCode03;
    private String shikakuCode04;
    private String shikakuCode05;
    private String sknKsuNameNosbt;
    private String sknKsuKbn;
    private String shubetsuName;
    private String updBack;
    private String updNext;
    private String errorLogCheck;
    private String updCheck;
    private String torokuUserId;
    private String torokuDate;
    private String torokuTime;
    private String nextDoi;
    private List<HoyuShikakuMst> hoyuShikakuMstMuryo;
    private String mskKakuninBack;
    private List<MskKsuJoho> kiboKaijoList;
    private List<String> jukenSkkNoList;
    private List<String> shikakuCode01List;
    private List<String> shikakuCode02List;
    private List<String> shikakuCode03List;
    private List<String> shikakuCode04List;
    private List<String> shikakuCode05List;
    private List<String> shuryouSkkNoList;
    private List<String> kinmusakiKaishaNameList;
    //����Ȑ�����p�i�u�K��̂݁j
    private List<MskKsuJoho> shiyoKaijoKsuList;
    //DB�o�^�X�V�p
    private List<Moshikomi> moshikomiListForInsert;
    private List<MSkkMnjKanri> mSkkMnjKanriListForInsert;
    private List<Torokusha> torokushaListForInsert;
    private List<Gazo> gazoListForInsert;
    private List<Shokureki> shokurekiListForInsert;
    private Map<String, HoyuShikakuMst> hoyuShikakuMstMapForUpdateBefore;
    private Map<String, HoyuShikakuMst> hoyuShikakuMstMapForUpdate;
    private String furiganaOnlyErrFlg;
    private String errorLogFlg;
    private List<MskUploadGroupService.ErrorMsg> errorLogForDownload;
    //�u�K��I���A���I���@bean
    private MskKsuJoho mskKsuJoho;

    /**
     * �R���X�g���N�^
     */
    public MskUploadJoho() {
        clearInfo();
    }

    /**
     * ���������\�b�h
     */
    public void clearInfo() {
        setErrors(new Messages());
        setSknksuKbn("");
        setMskTmpDl("");
        setNendo("");
        setMskUl("");
        setUketsukeNo("");
        setShubetsuCode("");
        setMoshikomishaId("");
        setKaisuCode("");
        setShomenMsk("");
        setNextDoi("");
        setMskKakuninBack("");
        setShimei("");
        setFurigana("");
        setBirthday("");
        setNenrei("");
        setKaijoSentakuNext("");
        setSex("");
        setYubinNo("");
        setTodofuken("");
        setHoyuShikakuMstMuryo(new ArrayList<>());
        setJusho1("");
        setJusho2("");
        setKaijoCode("");
        setKuusekiSuu("");
        setTatemono("");
        setTelNo("");
        setFaxNo("");
        setMailAddress("");
        setKinmusakiYubinNo("");
        setKinmusakiTodofuken("");
        setKinmusakiJusho1("");
        setKinmusakiJusho2("");
        setKinmusakiTatemono("");
        setKinmusakiTelNo("");
        setKinmusakiFaxNo("");
        setSofuSakiKbn("");
        setShikenNaiyoKbn("");
        setKiboShikenchi("");
        setGenmenFlg("");
        setGaijiFlg("");
        setUpdCheck("");
        setGaijiShosai("");
        setUketsukeNos(null);
        setCsvFlg("");
        setShomenNoList(new ArrayList<>());
        setJukenSkkCode("");
        setJukenSkkNo("");
        setKurenrekiName("");
        setKurenrekiNaiyo("");
        setKurenrekiShozaichi("");
        setKurenrekiFrom("");
        setKurenrekiTo("");
        setGakurekiName("");
        setGakurekiNaiyo("");
        setGakurekiShozaichi("");
        setGakurekiDate("");
        setKinmusakiKaishaName0("");
        setBushoYakushokuName0("");
        setShozaichi0("");
        setShokumuNaiyo0("");
        setZaisekikikanFrom0("");
        setZaisekikikanTo0("");
        setKinmusakiKaishaName1("");
        setBushoYakushokuName1("");
        setShozaichi1("");
        setShokumuNaiyo1("");
        setZaisekikikanFrom1("");
        setZaisekikikanTo1("");
        setKinmusakiKaishaName2("");
        setBushoYakushokuName2("");
        setShozaichi2("");
        setShokumuNaiyo2("");
        setZaisekikikanFrom2("");
        setZaisekikikanTo2("");
        setKinmusakiKaishaName3("");
        setBushoYakushokuName3("");
        setShozaichi3("");
        setShokumuNaiyo3("");
        setZaisekikikanFrom3("");
        setZaisekikikanTo3("");
        setKinmusakiKaishaName4("");
        setBushoYakushokuName4("");
        setShozaichi4("");
        setShokumuNaiyo4("");
        setZaisekikikanFrom4("");
        setZaisekikikanTo4("");
        setKinmusakiKaishaName5("");
        setBushoYakushokuName5("");
        setShozaichi5("");
        setShokumuNaiyo5("");
        setZaisekikikanFrom5("");
        setZaisekikikanTo5("");
        setKinmusakiKaishaName6("");
        setBushoYakushokuName6("");
        setShozaichi6("");
        setShokumuNaiyo6("");
        setZaisekikikanFrom6("");
        setZaisekikikanTo6("");
        setKinmusakiKaishaName7("");
        setBushoYakushokuName7("");
        setShozaichi7("");
        setShokumuNaiyo7("");
        setZaisekikikanFrom7("");
        setZaisekikikanTo7("");
        setKinmusakiKaishaName8("");
        setBushoYakushokuName8("");
        setShozaichi8("");
        setShokumuNaiyo8("");
        setZaisekikikanFrom8("");
        setZaisekikikanTo8("");
        setKinmusakiKaishaName9("");
        setBushoYakushokuName9("");
        setShozaichi9("");
        setShokumuNaiyo9("");
        setZaisekikikanFrom9("");
        setZaisekikikanTo9("");
        setKinmusakiKaishaName10("");
        setBushoYakushokuName10("");
        setShozaichi10("");
        setShokumuNaiyo10("");
        setZaisekikikanFrom10("");
        setZaisekikikanTo10("");
        setMenjoSkkCode("");
        setMenjoSkkNo("");
        setKaijoId1("");
        setKaijoId2("");
        setShomenUketsukeNo("");
        setShuryouSkkNo("");
        setShikakuCode01("");
        setShikakuCode02("");
        setShikakuCode03("");
        setShikakuCode04("");
        setShikakuCode05("");
        setSknKsuNameNosbt("");
        setSknKsuKbn("");
        setShubetsuName("");
        setUpdBack("");
        setUpdNext("");
        setErrorLogCheck("");
        setTorokuUserId("");
        setTorokuDate("");
        setTorokuTime("");
        setJukenSkkNoList(new ArrayList<>());
        setShikakuCode01List(new ArrayList<>());
        setShikakuCode02List(new ArrayList<>());
        setShikakuCode03List(new ArrayList<>());
        setShikakuCode04List(new ArrayList<>());
        setShikakuCode05List(new ArrayList<>());
        setShuryouSkkNoList(new ArrayList<>());
        setKinmusakiKaishaNameList(new ArrayList<>());
        setShiyoKaijoKsuList(new ArrayList<>());
        setMoshikomiListForInsert(new ArrayList<>());
        setMSkkMnjKanriListForInsert(new ArrayList<>());
        setTorokushaListForInsert(new ArrayList<>());
        setGazoListForInsert(new ArrayList<>());
        setShokurekiListForInsert(new ArrayList<>());
        setHoyuShikakuMstMapForUpdateBefore(new HashMap<>());
        setHoyuShikakuMstMapForUpdate(new HashMap<>());
        setFuriganaOnlyErrFlg("");
        setErrorLogFlg("");
        setErrorLogForDownload(new ArrayList<>());
    }

    /**
     * ���N�G�X�g��������擾���郁�\�b�h
     *
     * @param request ���N�G�X�g
     */
    @Override
    public void copyFromRequest(HttpServletRequest request) {
        setMskTmpDl((String) request.getAttribute("mskTmpDl"));
        setMskUl((String) request.getAttribute("mskUl"));
        setCsvFlg((String) request.getAttribute("csvFlg"));
        setUketsukeNo((String) request.getAttribute("uketsukeNo"));
        setUketsukeNos((String[]) request.getAttribute("uketsukeNos"));
        setShimei((String) request.getAttribute("shimei"));
        setKaijoSentakuNext((String) request.getAttribute("kaijoSentakuNext"));
        setFurigana((String) request.getAttribute("furigana"));
        setBirthday((String) request.getAttribute("birthday"));
        setSex((String) request.getAttribute("sex"));
        setNextDoi((String) request.getAttribute("nextDoi"));
        setMskKakuninBack((String) request.getAttribute("mskKakuninBack"));
        setYubinNo((String) request.getAttribute("yubinNo"));
        setTodofuken((String) request.getAttribute("todofuken"));
        setJusho1((String) request.getAttribute("jusho1"));
        setJusho2((String) request.getAttribute("Jusho2"));
        setKaijoCode((String) request.getAttribute("kaijoCode"));
        setKuusekiSuu((String) request.getAttribute("kuusekiSuu"));
        setTatemono((String) request.getAttribute("tatemono"));
        setTelNo((String) request.getAttribute("telNo"));
        setFaxNo((String) request.getAttribute("faxNo"));
        setUpdCheck((String) request.getAttribute("updCheck"));
        setMailAddress((String) request.getAttribute("mailAddress"));
        setKinmusakiYubinNo((String) request.getAttribute("kinmusakiYubinNo"));
        setKinmusakiTodofuken((String) request.getAttribute("kinmusakiTodofuken"));
        setKinmusakiJusho1((String) request.getAttribute("kinmusakiJusho1"));
        setKinmusakiJusho2((String) request.getAttribute("kinmusakiJusho2"));
        setKinmusakiTatemono((String) request.getAttribute("kinmusakiTatemono"));
        setKinmusakiTelNo((String) request.getAttribute("kinmusakiTelNo"));
        setKinmusakiFaxNo((String) request.getAttribute("kinmusakiFaxNo"));
        setSofuSakiKbn((String) request.getAttribute("sofuSakiKbn"));
        setShikenNaiyoKbn((String) request.getAttribute("shikenNaiyoKbn"));
        setKiboShikenchi((String) request.getAttribute("kiboShikenchi"));
        setGenmenFlg((String) request.getAttribute("genmenFlg"));
        setGaijiFlg((String) request.getAttribute("gaijiFlg"));
        setGaijiShosai((String) request.getAttribute("saijiShosai"));
        setJukenSkkCode((String) request.getAttribute("jukenSkkCode"));
        setJukenSkkNo((String) request.getAttribute("jukenSkkNo"));
        setKurenrekiName((String) request.getAttribute("kurenrekiName"));
        setKurenrekiNaiyo((String) request.getAttribute("kurenrekiNaiyo"));
        setKurenrekiShozaichi((String) request.getAttribute("kurenrekiShozaichi"));
        setKurenrekiFrom((String) request.getAttribute("kurenrekiFrom"));
        setKurenrekiTo((String) request.getAttribute("kurenrekiTo"));
        setGakurekiName((String) request.getAttribute("gakurekiName"));
        setGakurekiNaiyo((String) request.getAttribute("gakurekiNaiyo"));
        setGakurekiShozaichi((String) request.getAttribute("gakurekiShozaichi"));
        setGakurekiDate((String) request.getAttribute("gakurekiDate"));
        setUpdBack((String) request.getAttribute("updBack"));
        setUpdNext((String) request.getAttribute("updNext"));
        setErrorLogCheck((String) request.getAttribute("errorLogCheck"));
        setKinmusakiKaishaName0((String) request.getAttribute("kinmusakiKaishaName0"));
        setBushoYakushokuName0((String) request.getAttribute("bushoYakushokuName0"));
        setShozaichi0((String) request.getAttribute("shozaichi0"));
        setShokumuNaiyo0((String) request.getAttribute("shokumuNaiyo0"));
        setZaisekikikanFrom0((String) request.getAttribute("zaisekikikanFrom0"));
        setZaisekikikanTo0((String) request.getAttribute("zaisekikikanTo10"));
        setKinmusakiKaishaName1((String) request.getAttribute("kinmusakiKaishaName1"));
        setBushoYakushokuName1((String) request.getAttribute("bushoYakushokuName1"));
        setShozaichi1((String) request.getAttribute("shozaichi1"));
        setShokumuNaiyo1((String) request.getAttribute("shokumuNaiyo1"));
        setZaisekikikanFrom1((String) request.getAttribute("zaisekikikanFrom1"));
        setZaisekikikanTo1((String) request.getAttribute("zaisekikikanTo1"));
        setKinmusakiKaishaName2((String) request.getAttribute("kinmusakiKaishaName2"));
        setBushoYakushokuName2((String) request.getAttribute("bushoYakushokuName2"));
        setShozaichi2((String) request.getAttribute("shozaichi2"));
        setShokumuNaiyo2((String) request.getAttribute("shokumuNaiyo2"));
        setZaisekikikanFrom2((String) request.getAttribute("zaisekikikanFrom2"));
        setZaisekikikanTo2((String) request.getAttribute("zaisekikikanTo2"));
        setKinmusakiKaishaName3((String) request.getAttribute("kinmusakiKaishaName3"));
        setBushoYakushokuName3((String) request.getAttribute("bushoYakushokuName3"));
        setShozaichi3((String) request.getAttribute("shozaichi3"));
        setShokumuNaiyo3((String) request.getAttribute("shokumuNaiyo3"));
        setZaisekikikanFrom3((String) request.getAttribute("zaisekikikanFrom3"));
        setZaisekikikanTo3((String) request.getAttribute("zaisekikikanTo3"));
        setKinmusakiKaishaName4((String) request.getAttribute("kinmusakiKaishaName4"));
        setBushoYakushokuName4((String) request.getAttribute("bushoYakushokuName4"));
        setShozaichi4((String) request.getAttribute("shozaichi4"));
        setShokumuNaiyo4((String) request.getAttribute("shokumuNaiyo4"));
        setZaisekikikanFrom4((String) request.getAttribute("zaisekikikanFrom4"));
        setZaisekikikanTo4((String) request.getAttribute("zaisekikikanTo4"));
        setKinmusakiKaishaName5((String) request.getAttribute("kinmusakiKaishaName5"));
        setBushoYakushokuName5((String) request.getAttribute("bushoYakushokuName5"));
        setShozaichi5((String) request.getAttribute("shozaichi5"));
        setShokumuNaiyo5((String) request.getAttribute("shokumuNaiyo5"));
        setZaisekikikanFrom5((String) request.getAttribute("zaisekikikanFrom5"));
        setZaisekikikanTo5((String) request.getAttribute("zaisekikikanTo5"));
        setKinmusakiKaishaName6((String) request.getAttribute("kinmusakiKaishaName6"));
        setBushoYakushokuName6((String) request.getAttribute("bushoYakushokuName6"));
        setShozaichi6((String) request.getAttribute("shozaichi6"));
        setShokumuNaiyo6((String) request.getAttribute("shokumuNaiyo6"));
        setZaisekikikanFrom6((String) request.getAttribute("zaisekikikanFrom6"));
        setZaisekikikanTo6((String) request.getAttribute("zaisekikikanTo6"));
        setKinmusakiKaishaName7((String) request.getAttribute("kinmusakiKaishaName7"));
        setBushoYakushokuName7((String) request.getAttribute("bushoYakushokuName7"));
        setShozaichi7((String) request.getAttribute("shozaichi7"));
        setShokumuNaiyo7((String) request.getAttribute("shokumuNaiyo7"));
        setZaisekikikanFrom7((String) request.getAttribute("zaisekikikanFrom7"));
        setZaisekikikanTo7((String) request.getAttribute("zaisekikikanTo7"));
        setKinmusakiKaishaName8((String) request.getAttribute("kinmusakiKaishaName8"));
        setBushoYakushokuName8((String) request.getAttribute("bushoYakushokuName8"));
        setShozaichi8((String) request.getAttribute("shozaichi8"));
        setShokumuNaiyo8((String) request.getAttribute("shokumuNaiyo8"));
        setZaisekikikanFrom8((String) request.getAttribute("zaisekikikanFrom8"));
        setZaisekikikanTo8((String) request.getAttribute("zaisekikikanTo8"));
        setKinmusakiKaishaName9((String) request.getAttribute("kinmusakiKaishaName9"));
        setBushoYakushokuName9((String) request.getAttribute("bushoYakushokuName9"));
        setShozaichi9((String) request.getAttribute("shozaichi9"));
        setShokumuNaiyo9((String) request.getAttribute("shokumuNaiyo9"));
        setZaisekikikanFrom9((String) request.getAttribute("zaisekikikanFrom9"));
        setZaisekikikanTo9((String) request.getAttribute("zaisekikikanTo9"));
        setKinmusakiKaishaName10((String) request.getAttribute("kinmusakiKaishaName10"));
        setBushoYakushokuName10((String) request.getAttribute("bushoYakushokuName10"));
        setShozaichi10((String) request.getAttribute("shozaichi10"));
        setShokumuNaiyo10((String) request.getAttribute("shokumuNaiyo10"));
        setZaisekikikanFrom10((String) request.getAttribute("zaisekikikanFrom10"));
        setZaisekikikanTo10((String) request.getAttribute("zaisekikikanTo10"));
        setMenjoSkkCode((String) request.getAttribute("menjoSkkCode"));
        setMenjoSkkNo((String) request.getAttribute("menjoSkkNo"));
        setKaijoId1((String) request.getAttribute("kaijoId1"));
        setKaijoId2((String) request.getAttribute("kaijoId2"));
        setShomenUketsukeNo((String) request.getAttribute("shomenUketsukeNo"));
        setShuryouSkkNo((String) request.getAttribute("shuryouSkkNo"));
        setShikakuCode01((String) request.getAttribute("shikakuCode01"));
        setShikakuCode02((String) request.getAttribute("shikakuCode02"));
        setShikakuCode03((String) request.getAttribute("shikakuCode03"));
        setShikakuCode04((String) request.getAttribute("shikakuCode04"));
        setShikakuCode05((String) request.getAttribute("shikakuCode05"));
        setTorokuUserId((String) request.getAttribute("torokuUserId"));
        setTorokuDate((String) request.getAttribute("torokuDate"));
        setTorokuTime((String) request.getAttribute("torokuTime"));
        setMskFileChoice((DiskFileItem) request.getAttribute("mskFileChoice"));
        HttpSession session = request.getSession(false);
        setShomenMsk((String) request.getAttribute("shomenMsk"));
        if (session.getAttribute("TopJoho") != null) {
            TopJoho tmp = (TopJoho) session.getAttribute("TopJoho");
            setMoshikomishaId(tmp.getMoshikomishaId());
        }
        if (session.getAttribute("MskKsuJoho") != null) {
            MskKsuJoho tmp = (MskKsuJoho) session.getAttribute("MskKsuJoho");
            setMskKsuJoho(tmp);
            setKiboKaijoList(tmp.getKiboKaijoList());
        }
        if (session.getAttribute("MskSknJoho") != null) {
            MskSknJoho tmp = (MskSknJoho) session.getAttribute("MskSknJoho");
            setMoshikomishaId(tmp.getMoshikomishaId());
            setSknKsuCode(tmp.getSknKsuCode());
            setShubetsuCode(tmp.getShubetsuCode());
            setKaisuCode(tmp.getKaisuCode());
            setSknKsuKbn(tmp.getSknKsuKbn());
            setSknKsuNameNosbt(tmp.getSknKsuNameNosbt());
            setShubetsuName(tmp.getShubetsuName());
            setNendo(tmp.getNendo());
        }
    }

    public Messages getErrors() {
        return errors;
    }

    public void setErrors(Messages errors) {
        this.errors = errors;
    }

    public String getSknksuKbn() {
        return sknksuKbn;
    }

    public void setSknksuKbn(String sknksuKbn) {
        this.sknksuKbn = sknksuKbn;
    }

    public String getSknName() {
        return sknName;
    }

    public void setSknName(String sknName) {
        this.sknName = sknName;
    }

    public String getMskUl() {
        return mskUl;
    }

    public void setMskUl(String mskUl) {
        this.mskUl = mskUl;
    }

    public String getShomenMsk() {
        return shomenMsk;
    }

    public void setShomenMsk(String shomenMsk) {
        this.shomenMsk = shomenMsk;
    }

    public DiskFileItem getMskFileChoice() {
        return mskFileChoice;
    }

    public void setMskFileChoice(DiskFileItem mskFileChoice) {
        this.mskFileChoice = mskFileChoice;
    }

    public String getMskTmpDl() {
        return mskTmpDl;
    }

    public void setMskTmpDl(String mskTmpDl) {
        this.mskTmpDl = mskTmpDl;
    }

    public String getKsuName() {
        return ksuName;
    }

    public void setKsuName(String ksuName) {
        this.ksuName = ksuName;
    }

    /**
     * @return the sknKsuCode
     */
    public String getSknKsuCode() {
        return sknKsuCode;
    }

    /**
     * @param sknKsuCode the sknKsuCode to set
     */
    public void setSknKsuCode(String sknKsuCode) {
        this.sknKsuCode = sknKsuCode;
    }

    /**
     * @return the shubetsuCode
     */
    public String getShubetsuCode() {
        return shubetsuCode;
    }

    /**
     * @param shubetsuCode the shubetsuCode to set
     */
    public void setShubetsuCode(String shubetsuCode) {
        this.shubetsuCode = shubetsuCode;
    }

    /**
     * @return the kaisuCode
     */
    public String getKaisuCode() {
        return kaisuCode;
    }

    /**
     * @param kaisuCode the kaisuCode to set
     */
    public void setKaisuCode(String kaisuCode) {
        this.kaisuCode = kaisuCode;
    }

    /**
     * @return the nendo
     */
    public String getNendo() {
        return nendo;
    }

    /**
     * @param nendo the nendo to set
     */
    public void setNendo(String nendo) {
        this.nendo = nendo;
    }

    /**
     * ���[�N�u�b�N���擾����S
     *
     * @return ���[�N�u�b�N
     */
    public Workbook getWorkbook() {
        return workbook;
    }

    /**
     * ���[�N�u�b�N���Z�b�g����
     *
     * @param workbook ���[�N�u�b�N
     */
    public void setWorkbook(Workbook workbook) {
        this.workbook = workbook;
    }

    /**
     * �V�[�g���擾����
     *
     * @return �V�[�g
     */
    public Sheet getSheet() {
        return sheet;
    }

    /**
     * �V�[�g���Z�b�g����
     *
     * @param sheet �V�[�g
     */
    public void setSheet(Sheet sheet) {
        this.sheet = sheet;
    }

    /**
     * �t�@�C�������擾����
     *
     * @return �t�@�C����
     */
    public String getFileName() {
        return fileName;
    }

    /**
     * �t�@�C�������Z�b�g����
     *
     * @param fileName �t�@�C����
     */
    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    /**
     * Excel�o�͒l�ݒ�}�b�v���擾����
     *
     * @return Excel�o�͒l�ݒ�}�b�v
     */
    public Map<String, Object> getExcelMap() {
        return excelMap;
    }

    /**
     * Excel�o�͒l�ݒ�}�b�v���Z�b�g����
     *
     * @param excelMap Excel�o�͒l�ݒ�}�b�v
     */
    public void setExcelMap(Map<String, Object> excelMap) {
        this.excelMap = excelMap;
    }

    /**
     * Excel�o�͒l�ݒ胊�X�g���擾����
     *
     * @return Excel�o�͒l�ݒ胊�X�g
     */
    public List<Object>[] getExcelList() {
        return excelList;
    }

    /**
     * Excel�o�͒l�ݒ胊�X�g���Z�b�g����
     *
     * @param excelList Excel�o�͒l�ݒ胊�X�g
     */
    public void setExcelList(List<Object>[] excelList) {
        this.excelList = excelList;
    }

    /**
     * �V�[�g�i���o�[���擾����
     *
     * @return �V�[�g�i���o�[
     */
    public int getSheetNo() {
        return sheetNo;
    }

    /**
     * �V�[�g�i���o�[���Z�b�g����
     *
     * @param sheetNo �V�[�g�i���o�[
     */
    public void setSheetNo(int sheetNo) {
        this.sheetNo = sheetNo;
    }

    /**
     * @return the excelSyukeiList
     */
    public Map<String, List<Object>[]> getExcelSyukeiList() {
        return excelSyukeiList;
    }

    /**
     * @param excelSyukeiList the excelSyukeiList to set
     */
    public void setExcelSyukeiList(Map<String, List<Object>[]> excelSyukeiList) {
        this.excelSyukeiList = excelSyukeiList;
    }

    /**
     * Excel�o�͒l�ݒ�(���X�g)
     *
     * @param key �L�[
     * @param value �l
     */
    public void setExcelSyukeiList(String key, List<Object>[] value) {
        this.excelSyukeiList.put(key, value);
    }

    /**
     * Excel�o�͒l�ݒ�(�}�b�v)
     *
     * @param key �ݒ�L�[
     * @param value �l
     */
    public void setExcelMap(String key, Object value) {
        this.excelMap.put(key, value);
    }

    /**
     * Excel�o�͒l�ݒ�(���X�g)
     *
     * @param index �C���f�b�N�X
     * @param value �l
     */
    public void setExcelList(int index, Object value) {
        this.excelList[index].add(value);
    }

    /**
     * Excel�o�͒l�ݒ胊�X�g�}�b�v
     *
     * @param writeKey
     * @param excelList
     */
    public void setExcelListMap(String writeKey, List<Object>[] excelList) {
        this.excelListMap.put(writeKey, excelList);
    }

    /**
     * Excel�o�͒l�ݒ�(���X�g)�̏�����
     *
     * @param size ���X�g�T�C�Y
     */
    public void initExcelList(int size) {
        this.excelList = new ArrayList[size];
        for (int i = 0; i < size; i++) {
            this.excelList[i] = new ArrayList();
        }
    }

    /**
     * �V�[�g����ݒ肷��
     *
     * @param sheetName �V�[�g��
     */
    public void setSheetName(String sheetName) {
        this.workbook.setSheetName(this.sheetNo, sheetName);
    }

    /**
     * @return the errorLog
     */
    public List<String> getErrorLog() {
        return errorLog;
    }

    /**
     * @param errorLog the errorLog to set
     */
    public void setErrorLog(List<String> errorLog) {
        this.errorLog = errorLog;
    }

    /**
     * @return the uploadCheck
     */
    public String getUploadCheck() {
        return uploadCheck;
    }

    /**
     * @param uploadCheck the uploadCheck to set
     */
    public void setUploadCheck(String uploadCheck) {
        this.uploadCheck = uploadCheck;
    }

    /**
     * @return the shomenNoList
     */
    public List<String> getShomenNoList() {
        return shomenNoList;
    }

    /**
     * @param shomenNoList the shomenNoList to set
     */
    public void setShomenNoList(List<String> shomenNoList) {
        this.shomenNoList = shomenNoList;
    }

    /**
     * @return the moshikomishaId
     */
    public String getMoshikomishaId() {
        return moshikomishaId;
    }

    /**
     * @param moshikomishaId the moshikomishaId to set
     */
    public void setMoshikomishaId(String moshikomishaId) {
        this.moshikomishaId = moshikomishaId;
    }

    /**
     * @return the csvFlg
     */
    public String getCsvFlg() {
        return csvFlg;
    }

    /**
     * @param csvFlg the csvFlg to set
     */
    public void setCsvFlg(String csvFlg) {
        this.csvFlg = csvFlg;
    }

    /**
     * @return the uketsukeNo
     */
    public String getUketsukeNo() {
        return uketsukeNo;
    }

    /**
     * @param uketsukeNo the uketsukeNo to set
     */
    public void setUketsukeNo(String uketsukeNo) {
        this.uketsukeNo = uketsukeNo;
    }

    /**
     * @return the uketsukeNos
     */
    public String[] getUketsukeNos() {
        return uketsukeNos;
    }

    /**
     * @param uketsukeNos the uketsukeNos to set
     */
    public void setUketsukeNos(String[] uketsukeNos) {
        this.uketsukeNos = uketsukeNos;
    }

    /**
     * @return the shimei
     */
    public String getShimei() {
        return shimei;
    }

    /**
     * @param shimei the shimei to set
     */
    public void setShimei(String shimei) {
        this.shimei = shimei;
    }

    /**
     * @return the furigana
     */
    public String getFurigana() {
        return furigana;
    }

    /**
     * @param furigana the furigana to set
     */
    public void setFurigana(String furigana) {
        this.furigana = furigana;
    }

    /**
     * @return the birthday
     */
    public String getBirthday() {
        return birthday;
    }

    /**
     * @param birthday the birthday to set
     */
    public void setBirthday(String birthday) {
        this.birthday = birthday;
    }

    /**
     * @return the nenrei
     */
    public String getNenrei() {
        return nenrei;
    }

    /**
     * @param nenrei the nenrei to set
     */
    public void setNenrei(String nenrei) {
        this.nenrei = nenrei;
    }

    /**
     * @return the sex
     */
    public String getSex() {
        return sex;
    }

    /**
     * @param sex the sex to set
     */
    public void setSex(String sex) {
        this.sex = sex;
    }

    /**
     * @return the yubinNo
     */
    public String getYubinNo() {
        return yubinNo;
    }

    /**
     * @param yubinNo the yubinNo to set
     */
    public void setYubinNo(String yubinNo) {
        this.yubinNo = yubinNo;
    }

    /**
     * @return the todofuken
     */
    public String getTodofuken() {
        return todofuken;
    }

    /**
     * @param todofuken the todofuken to set
     */
    public void setTodofuken(String todofuken) {
        this.todofuken = todofuken;
    }

    /**
     * @return the jusho1
     */
    public String getJusho1() {
        return jusho1;
    }

    /**
     * @param jusho1 the jusho1 to set
     */
    public void setJusho1(String jusho1) {
        this.jusho1 = jusho1;
    }

    /**
     * @return the jusho2
     */
    public String getJusho2() {
        return jusho2;
    }

    /**
     * @param jusho2 the jusho2 to set
     */
    public void setJusho2(String jusho2) {
        this.jusho2 = jusho2;
    }

    /**
     * @return the tatemono
     */
    public String getTatemono() {
        return tatemono;
    }

    /**
     * @param tatemono the tatemono to set
     */
    public void setTatemono(String tatemono) {
        this.tatemono = tatemono;
    }

    /**
     * @return the telNo
     */
    public String getTelNo() {
        return telNo;
    }

    /**
     * @param telNo the telNo to set
     */
    public void setTelNo(String telNo) {
        this.telNo = telNo;
    }

    /**
     * @return the faxNo
     */
    public String getFaxNo() {
        return faxNo;
    }

    /**
     * @param faxNo the faxNo to set
     */
    public void setFaxNo(String faxNo) {
        this.faxNo = faxNo;
    }

    /**
     * @return the mailAddress
     */
    public String getMailAddress() {
        return mailAddress;
    }

    /**
     * @param mailAddress the mailAddress to set
     */
    public void setMailAddress(String mailAddress) {
        this.mailAddress = mailAddress;
    }

    /**
     * @return the kinmusakiYubinNo
     */
    public String getKinmusakiYubinNo() {
        return kinmusakiYubinNo;
    }

    /**
     * @param kinmusakiYubinNo the kinmusakiYubinNo to set
     */
    public void setKinmusakiYubinNo(String kinmusakiYubinNo) {
        this.kinmusakiYubinNo = kinmusakiYubinNo;
    }

    /**
     * @return the kinmusakiTodofuken
     */
    public String getKinmusakiTodofuken() {
        return kinmusakiTodofuken;
    }

    /**
     * @param kinmusakiTodofuken the kinmusakiTodofuken to set
     */
    public void setKinmusakiTodofuken(String kinmusakiTodofuken) {
        this.kinmusakiTodofuken = kinmusakiTodofuken;
    }

    /**
     * @return the kinmusakiJusho1
     */
    public String getKinmusakiJusho1() {
        return kinmusakiJusho1;
    }

    /**
     * @param kinmusakiJusho1 the kinmusakiJusho1 to set
     */
    public void setKinmusakiJusho1(String kinmusakiJusho1) {
        this.kinmusakiJusho1 = kinmusakiJusho1;
    }

    /**
     * @return the kinmusakiJusho2
     */
    public String getKinmusakiJusho2() {
        return kinmusakiJusho2;
    }

    /**
     * @param kinmusakiJusho2 the kinmusakiJusho2 to set
     */
    public void setKinmusakiJusho2(String kinmusakiJusho2) {
        this.kinmusakiJusho2 = kinmusakiJusho2;
    }

    /**
     * @return the kinmusakiTatemono
     */
    public String getKinmusakiTatemono() {
        return kinmusakiTatemono;
    }

    /**
     * @param kinmusakiTatemono the kinmusakiTatemono to set
     */
    public void setKinmusakiTatemono(String kinmusakiTatemono) {
        this.kinmusakiTatemono = kinmusakiTatemono;
    }

    /**
     * @return the kinmusakiTelNo
     */
    public String getKinmusakiTelNo() {
        return kinmusakiTelNo;
    }

    /**
     * @param kinmusakiTelNo the kinmusakiTelNo to set
     */
    public void setKinmusakiTelNo(String kinmusakiTelNo) {
        this.kinmusakiTelNo = kinmusakiTelNo;
    }

    /**
     * @return the kinmusakiFaxNo
     */
    public String getKinmusakiFaxNo() {
        return kinmusakiFaxNo;
    }

    /**
     * @param kinmusakiFaxNo the kinmusakiFaxNo to set
     */
    public void setKinmusakiFaxNo(String kinmusakiFaxNo) {
        this.kinmusakiFaxNo = kinmusakiFaxNo;
    }

    /**
     * @return the sofuSakiKbn
     */
    public String getSofuSakiKbn() {
        return sofuSakiKbn;
    }

    /**
     * @param sofuSakiKbn the sofuSakiKbn to set
     */
    public void setSofuSakiKbn(String sofuSakiKbn) {
        this.sofuSakiKbn = sofuSakiKbn;
    }

    /**
     * @return the shikenNaiyoKbn
     */
    public String getShikenNaiyoKbn() {
        return shikenNaiyoKbn;
    }

    /**
     * @param shikenNaiyoKbn the shikenNaiyoKbn to set
     */
    public void setShikenNaiyoKbn(String shikenNaiyoKbn) {
        this.shikenNaiyoKbn = shikenNaiyoKbn;
    }

    /**
     * @return the kiboShikenchi
     */
    public String getKiboShikenchi() {
        return kiboShikenchi;
    }

    /**
     * @param kiboShikenchi the kiboShikenchi to set
     */
    public void setKiboShikenchi(String kiboShikenchi) {
        this.kiboShikenchi = kiboShikenchi;
    }

    /**
     * @return the genmenFlg
     */
    public String getGenmenFlg() {
        return genmenFlg;
    }

    /**
     * @param genmenFlg the genmenFlg to set
     */
    public void setGenmenFlg(String genmenFlg) {
        this.genmenFlg = genmenFlg;
    }

    /**
     * @return the gaijiFlg
     */
    public String getGaijiFlg() {
        return gaijiFlg;
    }

    /**
     * @param gaijiFlg the gaijiFlg to set
     */
    public void setGaijiFlg(String gaijiFlg) {
        this.gaijiFlg = gaijiFlg;
    }

    /**
     * @return the gaijiShosai
     */
    public String getGaijiShosai() {
        return gaijiShosai;
    }

    /**
     * @param gaijiShosai the gaijiShosai to set
     */
    public void setGaijiShosai(String gaijiShosai) {
        this.gaijiShosai = gaijiShosai;
    }

    /**
     * @return the jukenSkkCode
     */
    public String getJukenSkkCode() {
        return jukenSkkCode;
    }

    /**
     * @param jukenSkkCode the jukenSkkCode to set
     */
    public void setJukenSkkCode(String jukenSkkCode) {
        this.jukenSkkCode = jukenSkkCode;
    }

    /**
     * @return the jukenSkkNo
     */
    public String getJukenSkkNo() {
        return jukenSkkNo;
    }

    /**
     * @param jukenSkkNo the jukenSkkNo to set
     */
    public void setJukenSkkNo(String jukenSkkNo) {
        this.jukenSkkNo = jukenSkkNo;
    }

    /**
     * @return the kinmusakiKaishaName1
     */
    public String getKinmusakiKaishaName1() {
        return kinmusakiKaishaName1;
    }

    /**
     * @param kinmusakiKaishaName1 the kinmusakiKaishaName1 to set
     */
    public void setKinmusakiKaishaName1(String kinmusakiKaishaName1) {
        this.kinmusakiKaishaName1 = kinmusakiKaishaName1;
    }

    /**
     * @return the bushoYakushokuName1
     */
    public String getBushoYakushokuName1() {
        return bushoYakushokuName1;
    }

    /**
     * @param bushoYakushokuName1 the bushoYakushokuName1 to set
     */
    public void setBushoYakushokuName1(String bushoYakushokuName1) {
        this.bushoYakushokuName1 = bushoYakushokuName1;
    }

    /**
     * @return the shozaichi1
     */
    public String getShozaichi1() {
        return shozaichi1;
    }

    /**
     * @param shozaichi1 the shozaichi1 to set
     */
    public void setShozaichi1(String shozaichi1) {
        this.shozaichi1 = shozaichi1;
    }

    /**
     * @return the shokumuNaiyo1
     */
    public String getShokumuNaiyo1() {
        return shokumuNaiyo1;
    }

    /**
     * @param shokumuNaiyo1 the shokumuNaiyo1 to set
     */
    public void setShokumuNaiyo1(String shokumuNaiyo1) {
        this.shokumuNaiyo1 = shokumuNaiyo1;
    }

    /**
     * @return the zaisekikikanFrom1
     */
    public String getZaisekikikanFrom1() {
        return zaisekikikanFrom1;
    }

    /**
     * @param zaisekikikanFrom1 the zaisekikikanFrom1 to set
     */
    public void setZaisekikikanFrom1(String zaisekikikanFrom1) {
        this.zaisekikikanFrom1 = zaisekikikanFrom1;
    }

    /**
     * @return the zaisekikikanTo1
     */
    public String getZaisekikikanTo1() {
        return zaisekikikanTo1;
    }

    /**
     * @param zaisekikikanTo1 the zaisekikikanTo1 to set
     */
    public void setZaisekikikanTo1(String zaisekikikanTo1) {
        this.zaisekikikanTo1 = zaisekikikanTo1;
    }

    /**
     * @return the kinmusakiKaishaName2
     */
    public String getKinmusakiKaishaName2() {
        return kinmusakiKaishaName2;
    }

    /**
     * @param kinmusakiKaishaName2 the kinmusakiKaishaName2 to set
     */
    public void setKinmusakiKaishaName2(String kinmusakiKaishaName2) {
        this.kinmusakiKaishaName2 = kinmusakiKaishaName2;
    }

    /**
     * @return the bushoYakushokuName2
     */
    public String getBushoYakushokuName2() {
        return bushoYakushokuName2;
    }

    /**
     * @param bushoYakushokuName2 the bushoYakushokuName2 to set
     */
    public void setBushoYakushokuName2(String bushoYakushokuName2) {
        this.bushoYakushokuName2 = bushoYakushokuName2;
    }

    /**
     * @return the shozaichi2
     */
    public String getShozaichi2() {
        return shozaichi2;
    }

    /**
     * @param shozaichi2 the shozaichi2 to set
     */
    public void setShozaichi2(String shozaichi2) {
        this.shozaichi2 = shozaichi2;
    }

    /**
     * @return the shokumuNaiyo2
     */
    public String getShokumuNaiyo2() {
        return shokumuNaiyo2;
    }

    /**
     * @param shokumuNaiyo2 the shokumuNaiyo2 to set
     */
    public void setShokumuNaiyo2(String shokumuNaiyo2) {
        this.shokumuNaiyo2 = shokumuNaiyo2;
    }

    /**
     * @return the zaisekikikanFrom2
     */
    public String getZaisekikikanFrom2() {
        return zaisekikikanFrom2;
    }

    /**
     * @param zaisekikikanFrom2 the zaisekikikanFrom2 to set
     */
    public void setZaisekikikanFrom2(String zaisekikikanFrom2) {
        this.zaisekikikanFrom2 = zaisekikikanFrom2;
    }

    /**
     * @return the zaisekikikanTo2
     */
    public String getZaisekikikanTo2() {
        return zaisekikikanTo2;
    }

    /**
     * @param zaisekikikanTo2 the zaisekikikanTo2 to set
     */
    public void setZaisekikikanTo2(String zaisekikikanTo2) {
        this.zaisekikikanTo2 = zaisekikikanTo2;
    }

    /**
     * @return the kinmusakiKaishaName3
     */
    public String getKinmusakiKaishaName3() {
        return kinmusakiKaishaName3;
    }

    /**
     * @param kinmusakiKaishaName3 the kinmusakiKaishaName3 to set
     */
    public void setKinmusakiKaishaName3(String kinmusakiKaishaName3) {
        this.kinmusakiKaishaName3 = kinmusakiKaishaName3;
    }

    /**
     * @return the bushoYakushokuName3
     */
    public String getBushoYakushokuName3() {
        return bushoYakushokuName3;
    }

    /**
     * @param bushoYakushokuName3 the bushoYakushokuName3 to set
     */
    public void setBushoYakushokuName3(String bushoYakushokuName3) {
        this.bushoYakushokuName3 = bushoYakushokuName3;
    }

    /**
     * @return the shozaichi3
     */
    public String getShozaichi3() {
        return shozaichi3;
    }

    /**
     * @param shozaichi3 the shozaichi3 to set
     */
    public void setShozaichi3(String shozaichi3) {
        this.shozaichi3 = shozaichi3;
    }

    /**
     * @return the shokumuNaiyo3
     */
    public String getShokumuNaiyo3() {
        return shokumuNaiyo3;
    }

    /**
     * @param shokumuNaiyo3 the shokumuNaiyo3 to set
     */
    public void setShokumuNaiyo3(String shokumuNaiyo3) {
        this.shokumuNaiyo3 = shokumuNaiyo3;
    }

    /**
     * @return the zaisekikikanFrom3
     */
    public String getZaisekikikanFrom3() {
        return zaisekikikanFrom3;
    }

    /**
     * @param zaisekikikanFrom3 the zaisekikikanFrom3 to set
     */
    public void setZaisekikikanFrom3(String zaisekikikanFrom3) {
        this.zaisekikikanFrom3 = zaisekikikanFrom3;
    }

    /**
     * @return the zaisekikikanTo3
     */
    public String getZaisekikikanTo3() {
        return zaisekikikanTo3;
    }

    /**
     * @param zaisekikikanTo3 the zaisekikikanTo3 to set
     */
    public void setZaisekikikanTo3(String zaisekikikanTo3) {
        this.zaisekikikanTo3 = zaisekikikanTo3;
    }

    /**
     * @return the kinmusakiKaishaName4
     */
    public String getKinmusakiKaishaName4() {
        return kinmusakiKaishaName4;
    }

    /**
     * @param kinmusakiKaishaName4 the kinmusakiKaishaName4 to set
     */
    public void setKinmusakiKaishaName4(String kinmusakiKaishaName4) {
        this.kinmusakiKaishaName4 = kinmusakiKaishaName4;
    }

    /**
     * @return the bushoYakushokuName4
     */
    public String getBushoYakushokuName4() {
        return bushoYakushokuName4;
    }

    /**
     * @param bushoYakushokuName4 the bushoYakushokuName4 to set
     */
    public void setBushoYakushokuName4(String bushoYakushokuName4) {
        this.bushoYakushokuName4 = bushoYakushokuName4;
    }

    /**
     * @return the shozaichi4
     */
    public String getShozaichi4() {
        return shozaichi4;
    }

    /**
     * @param shozaichi4 the shozaichi4 to set
     */
    public void setShozaichi4(String shozaichi4) {
        this.shozaichi4 = shozaichi4;
    }

    /**
     * @return the shokumuNaiyo4
     */
    public String getShokumuNaiyo4() {
        return shokumuNaiyo4;
    }

    /**
     * @param shokumuNaiyo4 the shokumuNaiyo4 to set
     */
    public void setShokumuNaiyo4(String shokumuNaiyo4) {
        this.shokumuNaiyo4 = shokumuNaiyo4;
    }

    /**
     * @return the zaisekikikanFrom4
     */
    public String getZaisekikikanFrom4() {
        return zaisekikikanFrom4;
    }

    /**
     * @param zaisekikikanFrom4 the zaisekikikanFrom4 to set
     */
    public void setZaisekikikanFrom4(String zaisekikikanFrom4) {
        this.zaisekikikanFrom4 = zaisekikikanFrom4;
    }

    /**
     * @return the zaisekikikanTo4
     */
    public String getZaisekikikanTo4() {
        return zaisekikikanTo4;
    }

    /**
     * @param zaisekikikanTo4 the zaisekikikanTo4 to set
     */
    public void setZaisekikikanTo4(String zaisekikikanTo4) {
        this.zaisekikikanTo4 = zaisekikikanTo4;
    }

    /**
     * @return the kinmusakiKaishaName5
     */
    public String getKinmusakiKaishaName5() {
        return kinmusakiKaishaName5;
    }

    /**
     * @param kinmusakiKaishaName5 the kinmusakiKaishaName5 to set
     */
    public void setKinmusakiKaishaName5(String kinmusakiKaishaName5) {
        this.kinmusakiKaishaName5 = kinmusakiKaishaName5;
    }

    /**
     * @return the bushoYakushokuName5
     */
    public String getBushoYakushokuName5() {
        return bushoYakushokuName5;
    }

    /**
     * @param bushoYakushokuName5 the bushoYakushokuName5 to set
     */
    public void setBushoYakushokuName5(String bushoYakushokuName5) {
        this.bushoYakushokuName5 = bushoYakushokuName5;
    }

    /**
     * @return the shozaichi5
     */
    public String getShozaichi5() {
        return shozaichi5;
    }

    /**
     * @param shozaichi5 the shozaichi5 to set
     */
    public void setShozaichi5(String shozaichi5) {
        this.shozaichi5 = shozaichi5;
    }

    /**
     * @return the shokumuNaiyo5
     */
    public String getShokumuNaiyo5() {
        return shokumuNaiyo5;
    }

    /**
     * @param shokumuNaiyo5 the shokumuNaiyo5 to set
     */
    public void setShokumuNaiyo5(String shokumuNaiyo5) {
        this.shokumuNaiyo5 = shokumuNaiyo5;
    }

    /**
     * @return the zaisekikikanFrom5
     */
    public String getZaisekikikanFrom5() {
        return zaisekikikanFrom5;
    }

    /**
     * @param zaisekikikanFrom5 the zaisekikikanFrom5 to set
     */
    public void setZaisekikikanFrom5(String zaisekikikanFrom5) {
        this.zaisekikikanFrom5 = zaisekikikanFrom5;
    }

    /**
     * @return the zaisekikikanTo5
     */
    public String getZaisekikikanTo5() {
        return zaisekikikanTo5;
    }

    /**
     * @param zaisekikikanTo5 the zaisekikikanTo5 to set
     */
    public void setZaisekikikanTo5(String zaisekikikanTo5) {
        this.zaisekikikanTo5 = zaisekikikanTo5;
    }

    /**
     * @return the kinmusakiKaishaName6
     */
    public String getKinmusakiKaishaName6() {
        return kinmusakiKaishaName6;
    }

    /**
     * @param kinmusakiKaishaName6 the kinmusakiKaishaName6 to set
     */
    public void setKinmusakiKaishaName6(String kinmusakiKaishaName6) {
        this.kinmusakiKaishaName6 = kinmusakiKaishaName6;
    }

    /**
     * @return the bushoYakushokuName6
     */
    public String getBushoYakushokuName6() {
        return bushoYakushokuName6;
    }

    /**
     * @param bushoYakushokuName6 the bushoYakushokuName6 to set
     */
    public void setBushoYakushokuName6(String bushoYakushokuName6) {
        this.bushoYakushokuName6 = bushoYakushokuName6;
    }

    /**
     * @return the shozaichi6
     */
    public String getShozaichi6() {
        return shozaichi6;
    }

    /**
     * @param shozaichi6 the shozaichi6 to set
     */
    public void setShozaichi6(String shozaichi6) {
        this.shozaichi6 = shozaichi6;
    }

    /**
     * @return the shokumuNaiyo6
     */
    public String getShokumuNaiyo6() {
        return shokumuNaiyo6;
    }

    /**
     * @param shokumuNaiyo6 the shokumuNaiyo6 to set
     */
    public void setShokumuNaiyo6(String shokumuNaiyo6) {
        this.shokumuNaiyo6 = shokumuNaiyo6;
    }

    /**
     * @return the zaisekikikanFrom6
     */
    public String getZaisekikikanFrom6() {
        return zaisekikikanFrom6;
    }

    /**
     * @param zaisekikikanFrom6 the zaisekikikanFrom6 to set
     */
    public void setZaisekikikanFrom6(String zaisekikikanFrom6) {
        this.zaisekikikanFrom6 = zaisekikikanFrom6;
    }

    /**
     * @return the zaisekikikanTo6
     */
    public String getZaisekikikanTo6() {
        return zaisekikikanTo6;
    }

    /**
     * @param zaisekikikanTo6 the zaisekikikanTo6 to set
     */
    public void setZaisekikikanTo6(String zaisekikikanTo6) {
        this.zaisekikikanTo6 = zaisekikikanTo6;
    }

    /**
     * @return the kinmusakiKaishaName7
     */
    public String getKinmusakiKaishaName7() {
        return kinmusakiKaishaName7;
    }

    /**
     * @param kinmusakiKaishaName7 the kinmusakiKaishaName7 to set
     */
    public void setKinmusakiKaishaName7(String kinmusakiKaishaName7) {
        this.kinmusakiKaishaName7 = kinmusakiKaishaName7;
    }

    /**
     * @return the bushoYakushokuName7
     */
    public String getBushoYakushokuName7() {
        return bushoYakushokuName7;
    }

    /**
     * @param bushoYakushokuName7 the bushoYakushokuName7 to set
     */
    public void setBushoYakushokuName7(String bushoYakushokuName7) {
        this.bushoYakushokuName7 = bushoYakushokuName7;
    }

    /**
     * @return the shozaichi7
     */
    public String getShozaichi7() {
        return shozaichi7;
    }

    /**
     * @param shozaichi7 the shozaichi7 to set
     */
    public void setShozaichi7(String shozaichi7) {
        this.shozaichi7 = shozaichi7;
    }

    /**
     * @return the shokumuNaiyo7
     */
    public String getShokumuNaiyo7() {
        return shokumuNaiyo7;
    }

    /**
     * @param shokumuNaiyo7 the shokumuNaiyo7 to set
     */
    public void setShokumuNaiyo7(String shokumuNaiyo7) {
        this.shokumuNaiyo7 = shokumuNaiyo7;
    }

    /**
     * @return the zaisekikikanFrom7
     */
    public String getZaisekikikanFrom7() {
        return zaisekikikanFrom7;
    }

    /**
     * @param zaisekikikanFrom7 the zaisekikikanFrom7 to set
     */
    public void setZaisekikikanFrom7(String zaisekikikanFrom7) {
        this.zaisekikikanFrom7 = zaisekikikanFrom7;
    }

    /**
     * @return the zaisekikikanTo7
     */
    public String getZaisekikikanTo7() {
        return zaisekikikanTo7;
    }

    /**
     * @param zaisekikikanTo7 the zaisekikikanTo7 to set
     */
    public void setZaisekikikanTo7(String zaisekikikanTo7) {
        this.zaisekikikanTo7 = zaisekikikanTo7;
    }

    /**
     * @return the kinmusakiKaishaName8
     */
    public String getKinmusakiKaishaName8() {
        return kinmusakiKaishaName8;
    }

    /**
     * @param kinmusakiKaishaName8 the kinmusakiKaishaName8 to set
     */
    public void setKinmusakiKaishaName8(String kinmusakiKaishaName8) {
        this.kinmusakiKaishaName8 = kinmusakiKaishaName8;
    }

    /**
     * @return the bushoYakushokuName8
     */
    public String getBushoYakushokuName8() {
        return bushoYakushokuName8;
    }

    /**
     * @param bushoYakushokuName8 the bushoYakushokuName8 to set
     */
    public void setBushoYakushokuName8(String bushoYakushokuName8) {
        this.bushoYakushokuName8 = bushoYakushokuName8;
    }

    /**
     * @return the shozaichi8
     */
    public String getShozaichi8() {
        return shozaichi8;
    }

    /**
     * @param shozaichi8 the shozaichi8 to set
     */
    public void setShozaichi8(String shozaichi8) {
        this.shozaichi8 = shozaichi8;
    }

    /**
     * @return the shokumuNaiyo8
     */
    public String getShokumuNaiyo8() {
        return shokumuNaiyo8;
    }

    /**
     * @param shokumuNaiyo8 the shokumuNaiyo8 to set
     */
    public void setShokumuNaiyo8(String shokumuNaiyo8) {
        this.shokumuNaiyo8 = shokumuNaiyo8;
    }

    /**
     * @return the zaisekikikanFrom8
     */
    public String getZaisekikikanFrom8() {
        return zaisekikikanFrom8;
    }

    /**
     * @param zaisekikikanFrom8 the zaisekikikanFrom8 to set
     */
    public void setZaisekikikanFrom8(String zaisekikikanFrom8) {
        this.zaisekikikanFrom8 = zaisekikikanFrom8;
    }

    /**
     * @return the zaisekikikanTo8
     */
    public String getZaisekikikanTo8() {
        return zaisekikikanTo8;
    }

    /**
     * @param zaisekikikanTo8 the zaisekikikanTo8 to set
     */
    public void setZaisekikikanTo8(String zaisekikikanTo8) {
        this.zaisekikikanTo8 = zaisekikikanTo8;
    }

    /**
     * @return the kinmusakiKaishaName9
     */
    public String getKinmusakiKaishaName9() {
        return kinmusakiKaishaName9;
    }

    /**
     * @param kinmusakiKaishaName9 the kinmusakiKaishaName9 to set
     */
    public void setKinmusakiKaishaName9(String kinmusakiKaishaName9) {
        this.kinmusakiKaishaName9 = kinmusakiKaishaName9;
    }

    /**
     * @return the bushoYakushokuName9
     */
    public String getBushoYakushokuName9() {
        return bushoYakushokuName9;
    }

    /**
     * @param bushoYakushokuName9 the bushoYakushokuName9 to set
     */
    public void setBushoYakushokuName9(String bushoYakushokuName9) {
        this.bushoYakushokuName9 = bushoYakushokuName9;
    }

    /**
     * @return the shozaichi9
     */
    public String getShozaichi9() {
        return shozaichi9;
    }

    /**
     * @param shozaichi9 the shozaichi9 to set
     */
    public void setShozaichi9(String shozaichi9) {
        this.shozaichi9 = shozaichi9;
    }

    /**
     * @return the shokumuNaiyo9
     */
    public String getShokumuNaiyo9() {
        return shokumuNaiyo9;
    }

    /**
     * @param shokumuNaiyo9 the shokumuNaiyo9 to set
     */
    public void setShokumuNaiyo9(String shokumuNaiyo9) {
        this.shokumuNaiyo9 = shokumuNaiyo9;
    }

    /**
     * @return the zaisekikikanFrom9
     */
    public String getZaisekikikanFrom9() {
        return zaisekikikanFrom9;
    }

    /**
     * @param zaisekikikanFrom9 the zaisekikikanFrom9 to set
     */
    public void setZaisekikikanFrom9(String zaisekikikanFrom9) {
        this.zaisekikikanFrom9 = zaisekikikanFrom9;
    }

    /**
     * @return the zaisekikikanTo9
     */
    public String getZaisekikikanTo9() {
        return zaisekikikanTo9;
    }

    /**
     * @param zaisekikikanTo9 the zaisekikikanTo9 to set
     */
    public void setZaisekikikanTo9(String zaisekikikanTo9) {
        this.zaisekikikanTo9 = zaisekikikanTo9;
    }

    /**
     * @return the kinmusakiKaishaName10
     */
    public String getKinmusakiKaishaName10() {
        return kinmusakiKaishaName10;
    }

    /**
     * @param kinmusakiKaishaName10 the kinmusakiKaishaName10 to set
     */
    public void setKinmusakiKaishaName10(String kinmusakiKaishaName10) {
        this.kinmusakiKaishaName10 = kinmusakiKaishaName10;
    }

    /**
     * @return the bushoYakushokuName10
     */
    public String getBushoYakushokuName10() {
        return bushoYakushokuName10;
    }

    /**
     * @param bushoYakushokuName10 the bushoYakushokuName10 to set
     */
    public void setBushoYakushokuName10(String bushoYakushokuName10) {
        this.bushoYakushokuName10 = bushoYakushokuName10;
    }

    /**
     * @return the shozaichi10
     */
    public String getShozaichi10() {
        return shozaichi10;
    }

    /**
     * @param shozaichi10 the shozaichi10 to set
     */
    public void setShozaichi10(String shozaichi10) {
        this.shozaichi10 = shozaichi10;
    }

    /**
     * @return the shokumuNaiyo10
     */
    public String getShokumuNaiyo10() {
        return shokumuNaiyo10;
    }

    /**
     * @param shokumuNaiyo10 the shokumuNaiyo10 to set
     */
    public void setShokumuNaiyo10(String shokumuNaiyo10) {
        this.shokumuNaiyo10 = shokumuNaiyo10;
    }

    /**
     * @return the zaisekikikanFrom10
     */
    public String getZaisekikikanFrom10() {
        return zaisekikikanFrom10;
    }

    /**
     * @param zaisekikikanFrom10 the zaisekikikanFrom10 to set
     */
    public void setZaisekikikanFrom10(String zaisekikikanFrom10) {
        this.zaisekikikanFrom10 = zaisekikikanFrom10;
    }

    /**
     * @return the zaisekikikanTo10
     */
    public String getZaisekikikanTo10() {
        return zaisekikikanTo10;
    }

    /**
     * @param zaisekikikanTo10 the zaisekikikanTo10 to set
     */
    public void setZaisekikikanTo10(String zaisekikikanTo10) {
        this.zaisekikikanTo10 = zaisekikikanTo10;
    }

    /**
     * @return the menjoSkkCode
     */
    public String getMenjoSkkCode() {
        return menjoSkkCode;
    }

    /**
     * @param menjoSkkCode the menjoSkkCode to set
     */
    public void setMenjoSkkCode(String menjoSkkCode) {
        this.menjoSkkCode = menjoSkkCode;
    }

    /**
     * @return the menjoSkkNo
     */
    public String getMenjoSkkNo() {
        return menjoSkkNo;
    }

    /**
     * @param menjoSkkNo the menjoSkkNo to set
     */
    public void setMenjoSkkNo(String menjoSkkNo) {
        this.menjoSkkNo = menjoSkkNo;
    }

    /**
     * @return the kaijoId1
     */
    public String getKaijoId1() {
        return kaijoId1;
    }

    /**
     * @param kaijoId1 the kaijoId1 to set
     */
    public void setKaijoId1(String kaijoId1) {
        this.kaijoId1 = kaijoId1;
    }

    /**
     * @return the kaijoId2
     */
    public String getKaijoId2() {
        return kaijoId2;
    }

    /**
     * @param kaijoId2 the kaijoId2 to set
     */
    public void setKaijoId2(String kaijoId2) {
        this.kaijoId2 = kaijoId2;
    }

    /**
     * @return the shomenUketsukeNo
     */
    public String getShomenUketsukeNo() {
        return shomenUketsukeNo;
    }

    /**
     * @param shomenUketsukeNo the shomenUketsukeNo to set
     */
    public void setShomenUketsukeNo(String shomenUketsukeNo) {
        this.shomenUketsukeNo = shomenUketsukeNo;
    }

    /**
     * @return the shuryouSkkNo
     */
    public String getShuryouSkkNo() {
        return shuryouSkkNo;
    }

    /**
     * @param shuryouSkkNo the shuryouSkkNo to set
     */
    public void setShuryouSkkNo(String shuryouSkkNo) {
        this.shuryouSkkNo = shuryouSkkNo;
    }

    /**
     * @return the shikakuCode01
     */
    public String getShikakuCode01() {
        return shikakuCode01;
    }

    /**
     * @param shikakuCode01 the shikakuCode01 to set
     */
    public void setShikakuCode01(String shikakuCode01) {
        this.shikakuCode01 = shikakuCode01;
    }

    /**
     * @return the shikakuCode02
     */
    public String getShikakuCode02() {
        return shikakuCode02;
    }

    /**
     * @param shikakuCode02 the shikakuCode02 to set
     */
    public void setShikakuCode02(String shikakuCode02) {
        this.shikakuCode02 = shikakuCode02;
    }

    /**
     * @return the shikakuCode03
     */
    public String getShikakuCode03() {
        return shikakuCode03;
    }

    /**
     * @param shikakuCode03 the shikakuCode03 to set
     */
    public void setShikakuCode03(String shikakuCode03) {
        this.shikakuCode03 = shikakuCode03;
    }

    /**
     * @return the shikakuCode04
     */
    public String getShikakuCode04() {
        return shikakuCode04;
    }

    /**
     * @param shikakuCode04 the shikakuCode04 to set
     */
    public void setShikakuCode04(String shikakuCode04) {
        this.shikakuCode04 = shikakuCode04;
    }

    /**
     * @return the shikakuCode05
     */
    public String getShikakuCode05() {
        return shikakuCode05;
    }

    /**
     * @param shikakuCode05 the shikakuCode05 to set
     */
    public void setShikakuCode05(String shikakuCode05) {
        this.shikakuCode05 = shikakuCode05;
    }

    /**
     * @return the sknKsuNameNosbt
     */
    public String getSknKsuNameNosbt() {
        return sknKsuNameNosbt;
    }

    /**
     * @param sknKsuNameNosbt the sknKsuNameNosbt to set
     */
    public void setSknKsuNameNosbt(String sknKsuNameNosbt) {
        this.sknKsuNameNosbt = sknKsuNameNosbt;
    }

    /**
     * @return the jukenSkkNoList
     */
    public List<String> getJukenSkkNoList() {
        return jukenSkkNoList;
    }

    /**
     * @param jukenSkkNoList the jukenSkkNoList to set
     */
    public void setJukenSkkNoList(List<String> jukenSkkNoList) {
        this.jukenSkkNoList = jukenSkkNoList;
    }

    /**
     * @return the kiboKaijoList
     */
    public List<MskKsuJoho> getKiboKaijoList() {
        return kiboKaijoList;
    }

    /**
     * @param kiboKaijoList the kiboKaijoList to set
     */
    public void setKiboKaijoList(List<MskKsuJoho> kiboKaijoList) {
        this.kiboKaijoList = kiboKaijoList;
    }

    /**
     * @return the sknKsuKbn
     */
    public String getSknKsuKbn() {
        return sknKsuKbn;
    }

    /**
     * @param sknKsuKbn the sknKsuKbn to set
     */
    public void setSknKsuKbn(String sknKsuKbn) {
        this.sknKsuKbn = sknKsuKbn;
    }

    /**
     * @return the shubetsuName
     */
    public String getShubetsuName() {
        return shubetsuName;
    }

    /**
     * @param shubetsuName the shubetsuName to set
     */
    public void setShubetsuName(String shubetsuName) {
        this.shubetsuName = shubetsuName;
    }

    /**
     * @return the shikakuCode01List
     */
    public List<String> getShikakuCode01List() {
        return shikakuCode01List;
    }

    /**
     * @param shikakuCode01List the shikakuCode01List to set
     */
    public void setShikakuCode01List(List<String> shikakuCode01List) {
        this.shikakuCode01List = shikakuCode01List;
    }

    /**
     * @return the shikakuCode02List
     */
    public List<String> getShikakuCode02List() {
        return shikakuCode02List;
    }

    /**
     * @param shikakuCode02List the shikakuCode02List to set
     */
    public void setShikakuCode02List(List<String> shikakuCode02List) {
        this.shikakuCode02List = shikakuCode02List;
    }

    /**
     * @return the shikakuCode03List
     */
    public List<String> getShikakuCode03List() {
        return shikakuCode03List;
    }

    /**
     * @param shikakuCode03List the shikakuCode03List to set
     */
    public void setShikakuCode03List(List<String> shikakuCode03List) {
        this.shikakuCode03List = shikakuCode03List;
    }

    /**
     * @return the shikakuCode04List
     */
    public List<String> getShikakuCode04List() {
        return shikakuCode04List;
    }

    /**
     * @param shikakuCode04List the shikakuCode04List to set
     */
    public void setShikakuCode04List(List<String> shikakuCode04List) {
        this.shikakuCode04List = shikakuCode04List;
    }

    /**
     * @return the shikakuCode05List
     */
    public List<String> getShikakuCode05List() {
        return shikakuCode05List;
    }

    /**
     * @param shikakuCode05List the shikakuCode05List to set
     */
    public void setShikakuCode05List(List<String> shikakuCode05List) {
        this.shikakuCode05List = shikakuCode05List;
    }

    /**
     * @return the shuryouSkkNoList
     */
    public List<String> getShuryouSkkNoList() {
        return shuryouSkkNoList;
    }

    /**
     * @param shuryouSkkNoList the shuryouSkkNoList to set
     */
    public void setShuryouSkkNoList(List<String> shuryouSkkNoList) {
        this.shuryouSkkNoList = shuryouSkkNoList;
    }

    /**
     * @return the kurenrekiName
     */
    public String getKurenrekiName() {
        return kurenrekiName;
    }

    /**
     * @param kurenrekiName the kurenrekiName to set
     */
    public void setKurenrekiName(String kurenrekiName) {
        this.kurenrekiName = kurenrekiName;
    }

    /**
     * @return the kurenrekiNaiyo
     */
    public String getKurenrekiNaiyo() {
        return kurenrekiNaiyo;
    }

    /**
     * @param kurenrekiNaiyo the kurenrekiNaiyo to set
     */
    public void setKurenrekiNaiyo(String kurenrekiNaiyo) {
        this.kurenrekiNaiyo = kurenrekiNaiyo;
    }

    /**
     * @return the kurenrekiShozaichi
     */
    public String getKurenrekiShozaichi() {
        return kurenrekiShozaichi;
    }

    /**
     * @param kurenrekiShozaichi the kurenrekiShozaichi to set
     */
    public void setKurenrekiShozaichi(String kurenrekiShozaichi) {
        this.kurenrekiShozaichi = kurenrekiShozaichi;
    }

    /**
     * @return the kurenrekiFrom
     */
    public String getKurenrekiFrom() {
        return kurenrekiFrom;
    }

    /**
     * @param kurenrekiFrom the kurenrekiFrom to set
     */
    public void setKurenrekiFrom(String kurenrekiFrom) {
        this.kurenrekiFrom = kurenrekiFrom;
    }

    /**
     * @return the kurenrekiTo
     */
    public String getKurenrekiTo() {
        return kurenrekiTo;
    }

    /**
     * @param kurenrekiTo the kurenrekiTo to set
     */
    public void setKurenrekiTo(String kurenrekiTo) {
        this.kurenrekiTo = kurenrekiTo;
    }

    /**
     * @return the gakurekiName
     */
    public String getGakurekiName() {
        return gakurekiName;
    }

    /**
     * @param gakurekiName the gakurekiName to set
     */
    public void setGakurekiName(String gakurekiName) {
        this.gakurekiName = gakurekiName;
    }

    /**
     * @return the gakurekiNaiyo
     */
    public String getGakurekiNaiyo() {
        return gakurekiNaiyo;
    }

    /**
     * @param gakurekiNaiyo the gakurekiNaiyo to set
     */
    public void setGakurekiNaiyo(String gakurekiNaiyo) {
        this.gakurekiNaiyo = gakurekiNaiyo;
    }

    /**
     * @return the gakurekiShozaichi
     */
    public String getGakurekiShozaichi() {
        return gakurekiShozaichi;
    }

    /**
     * @param gakurekiShozaichi the gakurekiShozaichi to set
     */
    public void setGakurekiShozaichi(String gakurekiShozaichi) {
        this.gakurekiShozaichi = gakurekiShozaichi;
    }

    /**
     * @return the gakurekiDate
     */
    public String getGakurekiDate() {
        return gakurekiDate;
    }

    /**
     * @param gakurekiDate the gakurekiDate to set
     */
    public void setGakurekiDate(String gakurekiDate) {
        this.gakurekiDate = gakurekiDate;
    }

    /**
     * @return the kaijoCode
     */
    public String getKaijoCode() {
        return kaijoCode;
    }

    /**
     * @param kaijoCode the kaijoCode to set
     */
    public void setKaijoCode(String kaijoCode) {
        this.kaijoCode = kaijoCode;
    }

    /**
     * @return the kuusekiSuu
     */
    public String getKuusekiSuu() {
        return kuusekiSuu;
    }

    /**
     * @param kuusekiSuu the kuusekiSuu to set
     */
    public void setKuusekiSuu(String kuusekiSuu) {
        this.kuusekiSuu = kuusekiSuu;
    }

    /**
     * @return the kinmusakiKaishaName0
     */
    public String getKinmusakiKaishaName0() {
        return kinmusakiKaishaName0;
    }

    /**
     * @param kinmusakiKaishaName0 the kinmusakiKaishaName0 to set
     */
    public void setKinmusakiKaishaName0(String kinmusakiKaishaName0) {
        this.kinmusakiKaishaName0 = kinmusakiKaishaName0;
    }

    /**
     * @return the bushoYakushokuName0
     */
    public String getBushoYakushokuName0() {
        return bushoYakushokuName0;
    }

    /**
     * @param bushoYakushokuName0 the bushoYakushokuName0 to set
     */
    public void setBushoYakushokuName0(String bushoYakushokuName0) {
        this.bushoYakushokuName0 = bushoYakushokuName0;
    }

    /**
     * @return the shozaichi0
     */
    public String getShozaichi0() {
        return shozaichi0;
    }

    /**
     * @param shozaichi0 the shozaichi0 to set
     */
    public void setShozaichi0(String shozaichi0) {
        this.shozaichi0 = shozaichi0;
    }

    /**
     * @return the shokumuNaiyo0
     */
    public String getShokumuNaiyo0() {
        return shokumuNaiyo0;
    }

    /**
     * @param shokumuNaiyo0 the shokumuNaiyo0 to set
     */
    public void setShokumuNaiyo0(String shokumuNaiyo0) {
        this.shokumuNaiyo0 = shokumuNaiyo0;
    }

    /**
     * @return the zaisekikikanFrom0
     */
    public String getZaisekikikanFrom0() {
        return zaisekikikanFrom0;
    }

    /**
     * @param zaisekikikanFrom0 the zaisekikikanFrom0 to set
     */
    public void setZaisekikikanFrom0(String zaisekikikanFrom0) {
        this.zaisekikikanFrom0 = zaisekikikanFrom0;
    }

    /**
     * @return the zaisekikikanTo0
     */
    public String getZaisekikikanTo0() {
        return zaisekikikanTo0;
    }

    /**
     * @param zaisekikikanTo0 the zaisekikikanTo0 to set
     */
    public void setZaisekikikanTo0(String zaisekikikanTo0) {
        this.zaisekikikanTo0 = zaisekikikanTo0;
    }

    /**
     * @return the kinmusakiKaishaNameList
     */
    public List<String> getKinmusakiKaishaNameList() {
        return kinmusakiKaishaNameList;
    }

    /**
     * @param kinmusakiKaishaNameList the kinmusakiKaishaNameList to set
     */
    public void setKinmusakiKaishaNameList(List<String> kinmusakiKaishaNameList) {
        this.kinmusakiKaishaNameList = kinmusakiKaishaNameList;
    }

    /**
     * @return the updBack
     */
    public String getUpdBack() {
        return updBack;
    }

    /**
     * @param updBack the updBack to set
     */
    public void setUpdBack(String updBack) {
        this.updBack = updBack;
    }

    /**
     * @return the updNext
     */
    public String getUpdNext() {
        return updNext;
    }

    /**
     * @param updNext the updNext to set
     */
    public void setUpdNext(String updNext) {
        this.updNext = updNext;
    }

    /**
     * @return the errorLogCheck
     */
    public String getErrorLogCheck() {
        return errorLogCheck;
    }

    /**
     * @param errorLogCheck the errorLogCheck to set
     */
    public void setErrorLogCheck(String errorLogCheck) {
        this.errorLogCheck = errorLogCheck;
    }

    /**
     * @return the updCheck
     */
    public String getUpdCheck() {
        return updCheck;
    }

    /**
     * @param updCheck the updCheck to set
     */
    public void setUpdCheck(String updCheck) {
        this.updCheck = updCheck;
    }

    /**
     * @return the torokuUserId
     */
    public String getTorokuUserId() {
        return torokuUserId;
    }

    /**
     * @param torokuUserId the torokuUserId to set
     */
    public void setTorokuUserId(String torokuUserId) {
        this.torokuUserId = torokuUserId;
    }

    /**
     * @return the torokuDate
     */
    public String getTorokuDate() {
        return torokuDate;
    }

    /**
     * @param torokuDate the torokuDate to set
     */
    public void setTorokuDate(String torokuDate) {
        this.torokuDate = torokuDate;
    }

    /**
     * @return the torokuTime
     */
    public String getTorokuTime() {
        return torokuTime;
    }

    /**
     * @param torokuTime the torokuTime to set
     */
    public void setTorokuTime(String torokuTime) {
        this.torokuTime = torokuTime;
    }

    /**
     * @return the nextDoi
     */
    public String getNextDoi() {
        return nextDoi;
    }

    /**
     * @param nextDoi the nextDoi to set
     */
    public void setNextDoi(String nextDoi) {
        this.nextDoi = nextDoi;
    }
    
    
    /**
     * @return the mskKakuninBack
     */
    public String getMskKakuninBack() {
        return mskKakuninBack;
    }

    /**
     * @param mskKakuninBack the mskKakuninBack to set
     */
    public void setMskKakuninBack(String mskKakuninBack) {
        this.mskKakuninBack = mskKakuninBack;
    }
    
    /**
     * @return the hoyuShikakuMstMuryo
     */
    public List<HoyuShikakuMst> getHoyuShikakuMstMuryo() {
        return hoyuShikakuMstMuryo;
    }

    /**
     * @param hoyuShikakuMstMuryo the hoyuShikakuMstMuryo to set
     */
    public void setHoyuShikakuMstMuryo(List<HoyuShikakuMst> hoyuShikakuMstMuryo) {
        this.hoyuShikakuMstMuryo = hoyuShikakuMstMuryo;
    }
    
    /**
     * @return the kaijoSentakuNext
     */
    public String getKaijoSentakuNext() {
        return kaijoSentakuNext;
    }

    /**
     * @param kaijoSentakuNext the kaijoSentakuNext to set
     */
    public void setKaijoSentakuNext(String kaijoSentakuNext) {
        this.kaijoSentakuNext = kaijoSentakuNext;
    }

    public void setShiyoKaijoKsuList(List<MskKsuJoho> shiyoKaijoKsuList) {
        this.shiyoKaijoKsuList = shiyoKaijoKsuList;
    }

    public List<MskKsuJoho> getShiyoKaijoKsuList() {
        return shiyoKaijoKsuList;
    }

    public void setMoshikomiListForInsert(List<Moshikomi> moshikomiListForInsert) {
        this.moshikomiListForInsert = moshikomiListForInsert;
    }

    public List<Moshikomi> getMoshikomiListForInsert() {
        return moshikomiListForInsert;
    }

    public void setMSkkMnjKanriListForInsert(List<MSkkMnjKanri> mSkkMnjKanriListForInsert) {
        this.mSkkMnjKanriListForInsert = mSkkMnjKanriListForInsert;
    }

    public List<MSkkMnjKanri> getMSkkMnjKanriListForInsert() {
        return mSkkMnjKanriListForInsert;
    }

    public void setTorokushaListForInsert(List<Torokusha> torokushaListForInsert) {
        this.torokushaListForInsert = torokushaListForInsert;
    }

    public List<Torokusha> getTorokushaListForInsert() {
        return torokushaListForInsert;
    }

    public void setGazoListForInsert(List<Gazo> gazoListForInsert) {
        this.gazoListForInsert = gazoListForInsert;
    }

    public List<Gazo> getGazoListForInsert() {
        return gazoListForInsert;
    }

    public void setShokurekiListForInsert(List<Shokureki> shokurekiListForInsert) {
        this.shokurekiListForInsert = shokurekiListForInsert;
    }

    public List<Shokureki> getShokurekiListForInsert() {
        return shokurekiListForInsert;
    }

    public void setHoyuShikakuMstMapForUpdateBefore(Map<String, HoyuShikakuMst> hoyuShikakuMstMapForUpdateBefore) {
        this.hoyuShikakuMstMapForUpdateBefore = hoyuShikakuMstMapForUpdateBefore;
    }

    public Map<String, HoyuShikakuMst> getHoyuShikakuMstMapForUpdateBefore() {
        return hoyuShikakuMstMapForUpdateBefore;
    }

    public void setHoyuShikakuMstMapForUpdate(Map<String, HoyuShikakuMst> hoyuShikakuMstMapForUpdate) {
        this.hoyuShikakuMstMapForUpdate = hoyuShikakuMstMapForUpdate;
    }

    public Map<String, HoyuShikakuMst> getHoyuShikakuMstMapForUpdate() {
        return hoyuShikakuMstMapForUpdate;
    }

    public void setFuriganaOnlyErrFlg(String furiganaOnlyErrFlg) {
        this.furiganaOnlyErrFlg = furiganaOnlyErrFlg;
    }

    public String getFuriganaOnlyErrFlg() {
        return furiganaOnlyErrFlg;
    }

    public void setErrorLogFlg(String errorLogFlg) {
        this.errorLogFlg = errorLogFlg;
    }

    public String getErrorLogFlg() {
        return errorLogFlg;
    }

    public List<MskUploadGroupService.ErrorMsg> getErrorLogForDownload() {
        return errorLogForDownload;
    }

    public void setErrorLogForDownload(List<MskUploadGroupService.ErrorMsg> errorLogForDownload) {
        this.errorLogForDownload = errorLogForDownload;
    }

    public MskKsuJoho getMskKsuJoho() {
        return mskKsuJoho;
    }

    public void setMskKsuJoho(MskKsuJoho mskKsuJoho) {
        this.mskKsuJoho = mskKsuJoho;
    }

}
