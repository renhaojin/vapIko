package jp.co.nii.bma.integration;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import static jp.co.nii.bma.business.domain.GeneratedMoshikomiHenkoRirekiDao.TABLE_NAME;
import jp.co.nii.bma.business.domain.MoshikomiHenkoRireki;
import jp.co.nii.bma.business.domain.MoshikomiHenkoRirekiDao;
import jp.co.nii.bma.business.service.common.BmaConstants;
import static jp.co.nii.bma.integration.GeneratedMoshikomiHenkoRirekiDaoImpl.FIELDS_DECRYPT;
import jp.co.nii.sew.common.LogGenerate;
import jp.co.nii.sew.integration.SQLStateSQLExceptionTranslater;

/**
 * �\���ύX���� DAO�����N���X
 * @author DB�Ǘ��c�[��
 */
public class MoshikomiHenkoRirekiDaoImpl extends GeneratedMoshikomiHenkoRirekiDaoImpl implements MoshikomiHenkoRirekiDao {

    /**
     * �C���X�^���X�𐶐�����B
     * @param datasource �f�[�^�\�[�X��
     */
    public MoshikomiHenkoRirekiDaoImpl(String datasource) {
        super(datasource);
    }
    
     /**
     * ��������B<br>
     * �����L�[�Ƃ��Ď�L�[���w�肷��B
     * @param moshikomiId �\���h�c
     * @return ���������f�[�^�i���̃N���X�̃C���X�^���X�j<br>
     *         �Y������f�[�^�����݂��Ȃ��ꍇ��null��Ԃ��B
     */
    @Override
    public MoshikomiHenkoRireki findByMoshikomiId(String moshikomiId) {
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs =null;
        String sql = "";
        MoshikomiHenkoRireki bo = new MoshikomiHenkoRireki();
        try {
            con = getConnection();
            sql = "SELECT " + FIELDS_DECRYPT
                    + " FROM " + getSchemaName() + "." + TABLE_NAME
                    + " WHERE"
                    + " MOSHIKOMISHA_ID = ?"
                    + " AND RONRI_SAKUJO_FLG = ?"
                    + " ORDER BY MOSHIKOMI_HENKO_RIREKI_IDX DESC"
                    + " LIMIT 1 ";   

            stmt = con.prepareStatement(sql);
            int i = 1;
            stmt.setString(i++, moshikomiId);
            stmt.setString(i++, BmaConstants.FLG_OFF);

            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();
            if (rs.next()) {
                setBoFromResultSet(bo, rs);
            } else {
                bo = null;
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return bo;
    }
    
    /**
     * �N�x����������B<br>
     * @param moshikomishaId �\���҂h�c
     * @param sknKsuCode �����u�K��R�[�h
     * @param shubetsuCode ��ʃR�[�h
     * @return ���������N�x
     */
    @Override
    public String getNendo(String moshikomishaId,String sknKsuCode,String shubetsuCode){
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs =null;
        String sql = "";
        String nendo = "";
        try {
            con = getConnection();
            sql = "SELECT " + FIELDS_DECRYPT
                    + " FROM " + getSchemaName() + "." + TABLE_NAME
                    + " WHERE"
                    + " MOSHIKOMISHA_ID = ?"
                    + " AND SKN_KSU_CODE = ?"
                    + " AND SHUBETSU_CODE = ?"
                    + " AND RONRI_SAKUJO_FLG = ?"
                    + " ORDER BY NENDO DESC"
                    + " LIMIT 1 ";   

            stmt = con.prepareStatement(sql);
            int i = 1;
            stmt.setString(i++, moshikomishaId);
            stmt.setString(i++, sknKsuCode);
            stmt.setString(i++, shubetsuCode);
            stmt.setString(i++, BmaConstants.FLG_OFF);

            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();
            if (rs.next()) {
                try {
                    nendo = rs.getString("NENDO");
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return nendo;
    }
}
