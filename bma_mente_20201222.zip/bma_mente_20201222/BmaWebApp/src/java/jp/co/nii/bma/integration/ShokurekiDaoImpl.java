package jp.co.nii.bma.integration;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import static jp.co.nii.bma.business.domain.GeneratedShokurekiDao.TABLE_NAME;
import jp.co.nii.bma.business.domain.Shokureki;
import jp.co.nii.bma.business.domain.ShokurekiDao;
import jp.co.nii.bma.business.service.common.BmaConstants;
import static jp.co.nii.bma.integration.GeneratedShokurekiDaoImpl.FIELDS_DECRYPT;
import jp.co.nii.sew.common.LogGenerate;
import jp.co.nii.sew.integration.SQLStateSQLExceptionTranslater;

/**
 * �E�� DAO�����N���X
 *
 * @author DB�Ǘ��c�[��
 */
public class ShokurekiDaoImpl extends GeneratedShokurekiDaoImpl implements ShokurekiDao {

    /**
     * �C���X�^���X�𐶐�����B
     *
     * @param datasource �f�[�^�\�[�X��
     */
    public ShokurekiDaoImpl(String datasource) {
        super(datasource);
    }

    @Override
    public List<Shokureki> findByNendoUke(String nendo, String uketsukeNo) {

        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = "";

        List<Shokureki> ret = new ArrayList<Shokureki>();
        try {
            con = getConnection();
            sql = "SELECT " + FIELDS_DECRYPT
                    + " FROM " + getSchemaName() + "." + TABLE_NAME
                    + " WHERE"
                    + " NENDO = ?"
                    + " AND UKETSUKE_NO = ?";

            stmt = con.prepareStatement(sql);
            int i = 1;
            stmt.setString(i++, nendo);
            stmt.setString(i++, uketsukeNo);

            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();
            while (rs.next()) {
                Shokureki bo = new Shokureki();
                setBoFromResultSet(bo, rs);
                ret.add(bo);
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return ret;

    }

    @Override
    public List<Shokureki> findByNendoUkeShKbn(String nendo, String uketsukeNo, String shokurekiKbn) {

        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = "";

        List<Shokureki> ret = new ArrayList<Shokureki>();
        try {
            con = getConnection();
            sql = "SELECT " + FIELDS_DECRYPT
                    + " FROM " + getSchemaName() + "." + TABLE_NAME
                    + " WHERE"
                    + " NENDO = ?"
                    + " AND UKETSUKE_NO = ?"
                    + " AND SHOKUREKI_KBN = ?";

            stmt = con.prepareStatement(sql);
            int i = 1;
            stmt.setString(i++, nendo);
            stmt.setString(i++, uketsukeNo);
            stmt.setString(i++, shokurekiKbn);

            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();
            while (rs.next()) {
                Shokureki bo = new Shokureki();
                setBoFromResultSet(bo, rs);
                ret.add(bo);
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return ret;
    }
    
    /**
     * �E�𖔂͌P�������X�g����������B<br>
     * @param moshikomishaId �\���҂h�c
     * @param shokurekiKbn �E���敪(1 : �E��;4 : �P����)
     * @return ���������E�𖔂͌P�������X�g<br>
     */
    @Override
    public List<Shokureki> getShokurekiListByMoshikomishaId(String moshikomishaId, String shokurekiKbn){
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = "";
        List<Shokureki> ret = new ArrayList<Shokureki>();
        try {
            con = getConnection();
            sql = "SELECT " + FIELDS_DECRYPT
                    + " FROM " + getSchemaName() + "." + TABLE_NAME
                    + " WHERE"
                    + " MOSHIKOMISHA_ID = ?"
                    + " AND SHOKUREKI_KBN = ?"
                    + " AND RONRI_SAKUJO_FLG = ?"
                    + " ORDER BY SHOKUREKI_KBN DESC, ZAISEKIKIKAN_FROM"
                    + " LIMIT 10";

            stmt = con.prepareStatement(sql);
            int i = 1;
            stmt.setString(i++, moshikomishaId);
            //�E���敪: 1 : �E��;4 : �P����
            stmt.setString(i++, shokurekiKbn);   
            stmt.setString(i++, BmaConstants.FLG_OFF);

            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();
            Shokureki bo;
            while (rs.next()) {
                bo = new Shokureki();
                setBoFromResultSet(bo, rs);
                ret.add(bo);
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return ret;
    }
}
