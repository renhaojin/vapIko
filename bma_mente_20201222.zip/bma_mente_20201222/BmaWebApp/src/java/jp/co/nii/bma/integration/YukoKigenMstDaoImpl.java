package jp.co.nii.bma.integration;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import jp.co.nii.bma.business.domain.YukoKigenMstDao;
import jp.co.nii.bma.business.service.common.BmaConstants;
import jp.co.nii.sew.common.LogGenerate;
import jp.co.nii.sew.integration.SQLStateSQLExceptionTranslater;

/**
 * �L�������}�X�^ DAO�����N���X
 * @author DB�Ǘ��c�[��
 */
public class YukoKigenMstDaoImpl extends GeneratedYukoKigenMstDaoImpl implements YukoKigenMstDao {

    /**
     * �C���X�^���X�𐶐�����B
     * @param datasource �f�[�^�\�[�X��
     */
    public YukoKigenMstDaoImpl(String datasource) {
        super(datasource);
    }
    
    /**
     * �N������������B<br>
     * @param sknKsuCode �����u�K��R�[�h
     * @param shubetsuCode ��ʃR�[�h
     * @return ���������N��
     */
    @Override
    public String getNensu(String sknKsuCode,String shubetsuCode){
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs =null;
        String sql = "";
        String nensu = "";
        try {
            con = getConnection();
            sql = "SELECT " + FIELDS_DECRYPT
                    + " FROM " + getSchemaName() + "." + TABLE_NAME
                    + " WHERE"
                    + " SKN_KSU_CODE = ?"
                    + " AND SHUBETSU_CODE = ?"
                    + " AND RONRI_SAKUJO_FLG = ?"
                    + " LIMIT 1 ";   

            stmt = con.prepareStatement(sql);
            int i = 1;
            stmt.setString(i++, sknKsuCode);
            stmt.setString(i++, shubetsuCode);
            stmt.setString(i++, BmaConstants.FLG_OFF);

            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();
            if (rs.next()) {
                try {
                    nensu = rs.getString("NENSU");
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return nensu;
    }
}
