package jp.co.nii.bma.business.service.common;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import jp.co.nii.bma.business.domain.MailTemplate;
import jp.co.nii.sew.business.Email;
import jp.co.nii.sew.utility.PropertyUtility;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.commons.validator.GenericValidator;

/**
 * �^�C�g��: ���[�����M�p ���ʃT�[�r�X</br> ����: ���[���̑��M�Ɋ֌W���鏈�����s�����ʃN���X</br> ���쌠: Copyright (c)
 * 2016</br> ��Ж�: ���{���Y�Ɗ������
 *
 * @author h.matsutaka
 */
public final class BmaMailSendService {

    /**
     * DB�ڑ��̃f�[�^�\�[�X
     */
    private static String DATA_SOURCE_NAME;

    //DB�ڑ����̃��[�U�[������
    public BmaMailSendService() {
        DATA_SOURCE_NAME = BmaConstants.DS_REGISTRANT;
    }
    //���O�o�͗p
    Log log = LogFactory.getLog(this.getClass());
    //�Ɩ��R�[�h
    private static final String BUSINESS_CODE = PropertyUtility.getProperty("business_code");
    //Mail�֘A�v���p�e�B
    private static final String MAIL_SERVER = PropertyUtility.getProperty(BUSINESS_CODE + "mail_server");
    private static final String MAIL_SERVER_BACKUP = PropertyUtility.getProperty(BUSINESS_CODE + "mail_server_backup");
    private static final String MAIL_FROM = PropertyUtility.getProperty(BUSINESS_CODE + "mail_from");
    private static final String MAIL_REPLY = PropertyUtility.getProperty(BUSINESS_CODE + "mail_reply");
    //���׃e�X�g���[�h
    private static final String STRESS_MODE = PropertyUtility.getProperty(BUSINESS_CODE + "stress_mode");

    /**
     * ���[���̑��M���s��
     *
     * @param mailAddress ���[�����M��A�h���X
     * @param mailTemplateCode �g�p���郁�[���e���v���[�g�̃R�[�h
     * @param replaceList �u�����������l�̃��X�g
     * @return
     */
    public boolean sendMail(String mailAddress, String mailTemplateCode, List<String> replaceList) {
        
        boolean status = false;

        //���׃e�X�g���[�h�̏ꍇ�A���[���̑��M���������s���Ȃ�
        if ("2".equals(STRESS_MODE)) {
            return true;
        }

        try {

            // ���[���e���v���[�g��DB����擾
            MailTemplate bo = new MailTemplate(DATA_SOURCE_NAME).find(mailTemplateCode, "");

            if (bo != null) {

                //�p�����[�^�̐��`
                formatReplaceList(replaceList);

                //�璷�����ꂽ���[���T�[�o�o�R�̃��[�����M
                new Email(
                        MAIL_SERVER,
                        MAIL_SERVER_BACKUP,
                        MAIL_FROM).sendViaRedundantServer(
                        mailAddress, // ����
                        createMailKenmei(bo, replaceList), // ����
                        createMailHonbun(bo, replaceList) + createMailFooter(bo, replaceList), // ���[���{���A�t�b�^�[
                        MAIL_REPLY);

                status = true;
            } else {
                status = false;
            }
        } catch (SQLException se) {
            status = false;
            log.error("���[���e���v���[�g�擾�Ɏ��s���܂���", se);
        } catch (Exception ex) {
            status = false;
            log.error("���[���̑��M�ŃG���[���N���܂����B", ex);
        } finally {
            return status;
        }

    }

    /**
     * �u�����������񃊃X�g�̐��`���s��
     *
     * @param replaceList
     */
    public void formatReplaceList(List<String> replaceList) {
        //�p�����[�^�Ƃ��ĕs�����Ă��镪���󕶎��Ŗ��߂�
        for (int i = replaceList.size(); i < 50; i++) {
            replaceList.add("");
        }
    }

    /**
     * ���[���������쐬�B<br/> �������ɖ��ߍ��܂ꂽ�p�����[�^�ɑ΂��AList�œn���ꂽ�l�ŏ��Ԃɒu�������鏈�����s���B<br/>
     *
     * �����[���e���v���[�g�̃p�����[�^��50�܂łł���A�Ƃ����O��ō쐬
     *
     * @param bo MailTemplate
     * @param replaceList �u�����������l�̃��X�g
     * @return
     */
    public String createMailKenmei(MailTemplate bo, List<String> replaceList) {
        String mailKenmei = bo.getMailKenmei();
        if ((!mailKenmei.isEmpty()) && (!replaceList.isEmpty())) {

            mailKenmei = replaceParameter(mailKenmei, bo.getMailParam01(), replaceList.get(0));
            mailKenmei = replaceParameter(mailKenmei, bo.getMailParam02(), replaceList.get(1));
            mailKenmei = replaceParameter(mailKenmei, bo.getMailParam03(), replaceList.get(2));
            mailKenmei = replaceParameter(mailKenmei, bo.getMailParam04(), replaceList.get(3));
            mailKenmei = replaceParameter(mailKenmei, bo.getMailParam05(), replaceList.get(4));
            mailKenmei = replaceParameter(mailKenmei, bo.getMailParam06(), replaceList.get(5));
            mailKenmei = replaceParameter(mailKenmei, bo.getMailParam07(), replaceList.get(6));
            mailKenmei = replaceParameter(mailKenmei, bo.getMailParam08(), replaceList.get(7));
            mailKenmei = replaceParameter(mailKenmei, bo.getMailParam09(), replaceList.get(8));
            mailKenmei = replaceParameter(mailKenmei, bo.getMailParam10(), replaceList.get(9));
            mailKenmei = replaceParameter(mailKenmei, bo.getMailParam11(), replaceList.get(10));
            mailKenmei = replaceParameter(mailKenmei, bo.getMailParam12(), replaceList.get(11));
            mailKenmei = replaceParameter(mailKenmei, bo.getMailParam13(), replaceList.get(12));
            mailKenmei = replaceParameter(mailKenmei, bo.getMailParam14(), replaceList.get(13));
            mailKenmei = replaceParameter(mailKenmei, bo.getMailParam15(), replaceList.get(14));
            mailKenmei = replaceParameter(mailKenmei, bo.getMailParam16(), replaceList.get(15));
            mailKenmei = replaceParameter(mailKenmei, bo.getMailParam17(), replaceList.get(16));
            mailKenmei = replaceParameter(mailKenmei, bo.getMailParam18(), replaceList.get(17));
            mailKenmei = replaceParameter(mailKenmei, bo.getMailParam19(), replaceList.get(18));
            mailKenmei = replaceParameter(mailKenmei, bo.getMailParam20(), replaceList.get(19));
            mailKenmei = replaceParameter(mailKenmei, bo.getMailParam21(), replaceList.get(20));
            mailKenmei = replaceParameter(mailKenmei, bo.getMailParam22(), replaceList.get(21));
            mailKenmei = replaceParameter(mailKenmei, bo.getMailParam23(), replaceList.get(22));
            mailKenmei = replaceParameter(mailKenmei, bo.getMailParam24(), replaceList.get(23));
            mailKenmei = replaceParameter(mailKenmei, bo.getMailParam25(), replaceList.get(24));
            mailKenmei = replaceParameter(mailKenmei, bo.getMailParam26(), replaceList.get(25));
            mailKenmei = replaceParameter(mailKenmei, bo.getMailParam27(), replaceList.get(26));
            mailKenmei = replaceParameter(mailKenmei, bo.getMailParam28(), replaceList.get(27));
            mailKenmei = replaceParameter(mailKenmei, bo.getMailParam29(), replaceList.get(28));
            mailKenmei = replaceParameter(mailKenmei, bo.getMailParam30(), replaceList.get(29));
            mailKenmei = replaceParameter(mailKenmei, bo.getMailParam31(), replaceList.get(30));
            mailKenmei = replaceParameter(mailKenmei, bo.getMailParam32(), replaceList.get(31));
            mailKenmei = replaceParameter(mailKenmei, bo.getMailParam33(), replaceList.get(32));
            mailKenmei = replaceParameter(mailKenmei, bo.getMailParam34(), replaceList.get(33));
            mailKenmei = replaceParameter(mailKenmei, bo.getMailParam35(), replaceList.get(34));
            mailKenmei = replaceParameter(mailKenmei, bo.getMailParam36(), replaceList.get(35));
            mailKenmei = replaceParameter(mailKenmei, bo.getMailParam37(), replaceList.get(36));
            mailKenmei = replaceParameter(mailKenmei, bo.getMailParam38(), replaceList.get(37));
            mailKenmei = replaceParameter(mailKenmei, bo.getMailParam39(), replaceList.get(38));
            mailKenmei = replaceParameter(mailKenmei, bo.getMailParam40(), replaceList.get(39));
            mailKenmei = replaceParameter(mailKenmei, bo.getMailParam41(), replaceList.get(40));
            mailKenmei = replaceParameter(mailKenmei, bo.getMailParam42(), replaceList.get(41));
            mailKenmei = replaceParameter(mailKenmei, bo.getMailParam43(), replaceList.get(42));
            mailKenmei = replaceParameter(mailKenmei, bo.getMailParam44(), replaceList.get(43));
            mailKenmei = replaceParameter(mailKenmei, bo.getMailParam45(), replaceList.get(44));
            mailKenmei = replaceParameter(mailKenmei, bo.getMailParam46(), replaceList.get(45));
            mailKenmei = replaceParameter(mailKenmei, bo.getMailParam47(), replaceList.get(46));
            mailKenmei = replaceParameter(mailKenmei, bo.getMailParam48(), replaceList.get(47));
            mailKenmei = replaceParameter(mailKenmei, bo.getMailParam49(), replaceList.get(48));
            mailKenmei = replaceParameter(mailKenmei, bo.getMailParam50(), replaceList.get(49));

        }
        return mailKenmei;
    }

    /**
     * ���[���{�����쐬�B<br/> �{�����ɖ��ߍ��܂ꂽ�p�����[�^�ɑ΂��AList�œn���ꂽ�l�ŏ��Ԃɒu�������鏈�����s���B<br/>
     *
     * �����[���e���v���[�g�̃p�����[�^��50�܂łł���A�Ƃ����O��ō쐬
     *
     * @param bo MailTemplate
     * @param replaceList �u�����������l�̃��X�g
     * @return
     */
    public String createMailHonbun(MailTemplate bo, List<String> replaceList) {

        String mailHonbun = bo.getMailHonbun();

        if ((!mailHonbun.isEmpty()) && (!replaceList.isEmpty())) {

            mailHonbun = replaceParameter(mailHonbun, bo.getMailParam01(), replaceList.get(0));
            mailHonbun = replaceParameter(mailHonbun, bo.getMailParam02(), replaceList.get(1));
            mailHonbun = replaceParameter(mailHonbun, bo.getMailParam03(), replaceList.get(2));
            mailHonbun = replaceParameter(mailHonbun, bo.getMailParam04(), replaceList.get(3));
            mailHonbun = replaceParameter(mailHonbun, bo.getMailParam05(), replaceList.get(4));
            mailHonbun = replaceParameter(mailHonbun, bo.getMailParam06(), replaceList.get(5));
            mailHonbun = replaceParameter(mailHonbun, bo.getMailParam07(), replaceList.get(6));
            mailHonbun = replaceParameter(mailHonbun, bo.getMailParam08(), replaceList.get(7));
            mailHonbun = replaceParameter(mailHonbun, bo.getMailParam09(), replaceList.get(8));
            mailHonbun = replaceParameter(mailHonbun, bo.getMailParam10(), replaceList.get(9));
            mailHonbun = replaceParameter(mailHonbun, bo.getMailParam11(), replaceList.get(10));
            mailHonbun = replaceParameter(mailHonbun, bo.getMailParam12(), replaceList.get(11));
            mailHonbun = replaceParameter(mailHonbun, bo.getMailParam13(), replaceList.get(12));
            mailHonbun = replaceParameter(mailHonbun, bo.getMailParam14(), replaceList.get(13));
            mailHonbun = replaceParameter(mailHonbun, bo.getMailParam15(), replaceList.get(14));
            mailHonbun = replaceParameter(mailHonbun, bo.getMailParam16(), replaceList.get(15));
            mailHonbun = replaceParameter(mailHonbun, bo.getMailParam17(), replaceList.get(16));
            mailHonbun = replaceParameter(mailHonbun, bo.getMailParam18(), replaceList.get(17));
            mailHonbun = replaceParameter(mailHonbun, bo.getMailParam19(), replaceList.get(18));
            mailHonbun = replaceParameter(mailHonbun, bo.getMailParam20(), replaceList.get(19));
            mailHonbun = replaceParameter(mailHonbun, bo.getMailParam21(), replaceList.get(20));
            mailHonbun = replaceParameter(mailHonbun, bo.getMailParam22(), replaceList.get(21));
            mailHonbun = replaceParameter(mailHonbun, bo.getMailParam23(), replaceList.get(22));
            mailHonbun = replaceParameter(mailHonbun, bo.getMailParam24(), replaceList.get(23));
            mailHonbun = replaceParameter(mailHonbun, bo.getMailParam25(), replaceList.get(24));
            mailHonbun = replaceParameter(mailHonbun, bo.getMailParam26(), replaceList.get(25));
            mailHonbun = replaceParameter(mailHonbun, bo.getMailParam27(), replaceList.get(26));
            mailHonbun = replaceParameter(mailHonbun, bo.getMailParam28(), replaceList.get(27));
            mailHonbun = replaceParameter(mailHonbun, bo.getMailParam29(), replaceList.get(28));
            mailHonbun = replaceParameter(mailHonbun, bo.getMailParam30(), replaceList.get(29));
            mailHonbun = replaceParameter(mailHonbun, bo.getMailParam31(), replaceList.get(30));
            mailHonbun = replaceParameter(mailHonbun, bo.getMailParam32(), replaceList.get(31));
            mailHonbun = replaceParameter(mailHonbun, bo.getMailParam33(), replaceList.get(32));
            mailHonbun = replaceParameter(mailHonbun, bo.getMailParam34(), replaceList.get(33));
            mailHonbun = replaceParameter(mailHonbun, bo.getMailParam35(), replaceList.get(34));
            mailHonbun = replaceParameter(mailHonbun, bo.getMailParam36(), replaceList.get(35));
            mailHonbun = replaceParameter(mailHonbun, bo.getMailParam37(), replaceList.get(36));
            mailHonbun = replaceParameter(mailHonbun, bo.getMailParam38(), replaceList.get(37));
            mailHonbun = replaceParameter(mailHonbun, bo.getMailParam39(), replaceList.get(38));
            mailHonbun = replaceParameter(mailHonbun, bo.getMailParam40(), replaceList.get(39));
            mailHonbun = replaceParameter(mailHonbun, bo.getMailParam41(), replaceList.get(40));
            mailHonbun = replaceParameter(mailHonbun, bo.getMailParam42(), replaceList.get(41));
            mailHonbun = replaceParameter(mailHonbun, bo.getMailParam43(), replaceList.get(42));
            mailHonbun = replaceParameter(mailHonbun, bo.getMailParam44(), replaceList.get(43));
            mailHonbun = replaceParameter(mailHonbun, bo.getMailParam45(), replaceList.get(44));
            mailHonbun = replaceParameter(mailHonbun, bo.getMailParam46(), replaceList.get(45));
            mailHonbun = replaceParameter(mailHonbun, bo.getMailParam47(), replaceList.get(46));
            mailHonbun = replaceParameter(mailHonbun, bo.getMailParam48(), replaceList.get(47));
            mailHonbun = replaceParameter(mailHonbun, bo.getMailParam49(), replaceList.get(48));
            mailHonbun = replaceParameter(mailHonbun, bo.getMailParam50(), replaceList.get(49));

        }

        return mailHonbun;
    }
    
    /**
     * ���[���t�b�^�[���쐬�B<br/> �{�����ɖ��ߍ��܂ꂽ�p�����[�^�ɑ΂��AList�œn���ꂽ�l�ŏ��Ԃɒu�������鏈�����s���B<br/>
     *
     * �����[���e���v���[�g�̃p�����[�^��50�܂łł���A�Ƃ����O��ō쐬
     *
     * @param bo MailTemplate
     * @param replaceList �u�����������l�̃��X�g
     * @return
     */
    public String createMailFooter(MailTemplate bo, List<String> replaceList) {

        String mailFooter = bo.getMailFooter();

        if ((!mailFooter.isEmpty()) && (!replaceList.isEmpty())) {

            mailFooter = replaceParameter(mailFooter, bo.getMailParam01(), replaceList.get(0));
            mailFooter = replaceParameter(mailFooter, bo.getMailParam02(), replaceList.get(1));
            mailFooter = replaceParameter(mailFooter, bo.getMailParam03(), replaceList.get(2));
            mailFooter = replaceParameter(mailFooter, bo.getMailParam04(), replaceList.get(3));
            mailFooter = replaceParameter(mailFooter, bo.getMailParam05(), replaceList.get(4));
            mailFooter = replaceParameter(mailFooter, bo.getMailParam06(), replaceList.get(5));
            mailFooter = replaceParameter(mailFooter, bo.getMailParam07(), replaceList.get(6));
            mailFooter = replaceParameter(mailFooter, bo.getMailParam08(), replaceList.get(7));
            mailFooter = replaceParameter(mailFooter, bo.getMailParam09(), replaceList.get(8));
            mailFooter = replaceParameter(mailFooter, bo.getMailParam10(), replaceList.get(9));
            mailFooter = replaceParameter(mailFooter, bo.getMailParam11(), replaceList.get(10));
            mailFooter = replaceParameter(mailFooter, bo.getMailParam12(), replaceList.get(11));
            mailFooter = replaceParameter(mailFooter, bo.getMailParam13(), replaceList.get(12));
            mailFooter = replaceParameter(mailFooter, bo.getMailParam14(), replaceList.get(13));
            mailFooter = replaceParameter(mailFooter, bo.getMailParam15(), replaceList.get(14));
            mailFooter = replaceParameter(mailFooter, bo.getMailParam16(), replaceList.get(15));
            mailFooter = replaceParameter(mailFooter, bo.getMailParam17(), replaceList.get(16));
            mailFooter = replaceParameter(mailFooter, bo.getMailParam18(), replaceList.get(17));
            mailFooter = replaceParameter(mailFooter, bo.getMailParam19(), replaceList.get(18));
            mailFooter = replaceParameter(mailFooter, bo.getMailParam20(), replaceList.get(19));
            mailFooter = replaceParameter(mailFooter, bo.getMailParam21(), replaceList.get(20));
            mailFooter = replaceParameter(mailFooter, bo.getMailParam22(), replaceList.get(21));
            mailFooter = replaceParameter(mailFooter, bo.getMailParam23(), replaceList.get(22));
            mailFooter = replaceParameter(mailFooter, bo.getMailParam24(), replaceList.get(23));
            mailFooter = replaceParameter(mailFooter, bo.getMailParam25(), replaceList.get(24));
            mailFooter = replaceParameter(mailFooter, bo.getMailParam26(), replaceList.get(25));
            mailFooter = replaceParameter(mailFooter, bo.getMailParam27(), replaceList.get(26));
            mailFooter = replaceParameter(mailFooter, bo.getMailParam28(), replaceList.get(27));
            mailFooter = replaceParameter(mailFooter, bo.getMailParam29(), replaceList.get(28));
            mailFooter = replaceParameter(mailFooter, bo.getMailParam30(), replaceList.get(29));
            mailFooter = replaceParameter(mailFooter, bo.getMailParam31(), replaceList.get(30));
            mailFooter = replaceParameter(mailFooter, bo.getMailParam32(), replaceList.get(31));
            mailFooter = replaceParameter(mailFooter, bo.getMailParam33(), replaceList.get(32));
            mailFooter = replaceParameter(mailFooter, bo.getMailParam34(), replaceList.get(33));
            mailFooter = replaceParameter(mailFooter, bo.getMailParam35(), replaceList.get(34));
            mailFooter = replaceParameter(mailFooter, bo.getMailParam36(), replaceList.get(35));
            mailFooter = replaceParameter(mailFooter, bo.getMailParam37(), replaceList.get(36));
            mailFooter = replaceParameter(mailFooter, bo.getMailParam38(), replaceList.get(37));
            mailFooter = replaceParameter(mailFooter, bo.getMailParam39(), replaceList.get(38));
            mailFooter = replaceParameter(mailFooter, bo.getMailParam40(), replaceList.get(39));
            mailFooter = replaceParameter(mailFooter, bo.getMailParam41(), replaceList.get(40));
            mailFooter = replaceParameter(mailFooter, bo.getMailParam42(), replaceList.get(41));
            mailFooter = replaceParameter(mailFooter, bo.getMailParam43(), replaceList.get(42));
            mailFooter = replaceParameter(mailFooter, bo.getMailParam44(), replaceList.get(43));
            mailFooter = replaceParameter(mailFooter, bo.getMailParam45(), replaceList.get(44));
            mailFooter = replaceParameter(mailFooter, bo.getMailParam46(), replaceList.get(45));
            mailFooter = replaceParameter(mailFooter, bo.getMailParam47(), replaceList.get(46));
            mailFooter = replaceParameter(mailFooter, bo.getMailParam48(), replaceList.get(47));
            mailFooter = replaceParameter(mailFooter, bo.getMailParam49(), replaceList.get(48));
            mailFooter = replaceParameter(mailFooter, bo.getMailParam50(), replaceList.get(49));

        }

        return mailFooter;
    }

    /**
     * str ���Ɋ܂܂�� target �� param �Œu��������
     *
     * target��param��null����empty�̎��͒u�������Ȃ��B
     *
     * param�̂�null����empty�̎��Aempty�ɒu��������B
     *
     * @param str
     * @param target
     * @param param
     * @return
     */
    private static String replaceParameter(String str, String target, String param) {

        String retStr = str;

        if (!GenericValidator.isBlankOrNull(target) && !GenericValidator.isBlankOrNull(param)) {
            retStr = retStr.replace(target, param);
        } else if (!GenericValidator.isBlankOrNull(target) && GenericValidator.isBlankOrNull(param)) {
            retStr = retStr.replace(target, "");
        }
        return retStr;
    }
}
