package jp.co.nii.bma.integration;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List;
import jp.co.nii.bma.business.domain.YubinBangoJishoDao;
import jp.co.nii.sew.business.Constants;
import static jp.co.nii.bma.business.domain.GeneratedYubinBangoJishoDao.TABLE_NAME;
import jp.co.nii.bma.business.domain.YubinBangoJisho;
import jp.co.nii.sew.common.LogGenerate;
import static jp.co.nii.sew.integration.AbstractDao.getSchemaName;
import jp.co.nii.sew.integration.SQLStateSQLExceptionTranslater;

/**
 * �X�֔ԍ����� DAO�����N���X
 *
 * @author DB�Ǘ��c�[��
 */
public class YubinBangoJishoDaoImpl extends GeneratedYubinBangoJishoDaoImpl implements YubinBangoJishoDao {

    /**
     * �C���X�^���X�𐶐�����B
     *
     * @param datasource �f�[�^�\�[�X��
     */
    public YubinBangoJishoDaoImpl(String datasource) {
        super(datasource);
    }

    @Override
    /**
     * �X�֔ԍ��Ō�������B
     *
     * @param yubinBango �X�֔ԍ��V��
     * @param lockMode ���b�N���@
     */
    public List findYubinBango(String yubinBango, String lockMode) {

        List ret = new LinkedList();

        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = "";
        try {
            con = getConnection();
            sql = "SELECT " + FIELDS_DECRYPT
                    + " FROM " + getSchemaName() + "." + TABLE_NAME
                    + " WHERE"
                    + " YUBIN_NO = ?"
                    + " AND"
                    + " RONRI_SAKUJO_FLG = ?";

            stmt = con.prepareStatement(sql + lockMode);
            int i = 1;
            stmt.setString(i++, yubinBango);
            stmt.setString(i++, Constants.FLG_OFF);

            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();

            while (rs.next()) {
                YubinBangoJisho bo = new YubinBangoJisho();
                setBoFromResultSet(bo, rs);
                ret.add(bo);
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }

        return ret;
    }
}
