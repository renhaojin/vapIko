package jp.co.nii.bma.business.service.moshikomi;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import jp.co.nii.bma.business.domain.ShiyoKaijo;
import jp.co.nii.bma.business.rto.MskKsuJoho;
import jp.co.nii.bma.business.service.common.BmaConstants;
import jp.co.nii.bma.business.service.common.BmaLogger;
import jp.co.nii.bma.business.service.common.BmaValidator;
import jp.co.nii.bma.utility.BmaUtility;
import jp.co.nii.sew.business.Validator;
import jp.co.nii.sew.business.service.AbstractService;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_BACK;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_ERROR;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_NEXT;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_SESSION;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_SUCCESS;
import jp.co.nii.sew.presentation.Messages;
import jp.co.nii.sew.presentation.RequestTransferObject;
import jp.co.nii.sew.utility.PropertyUtility;

/**
 * <p>
 * �^�C�g��: �\�����ӎ�����ʃT�[�r�X</p>
 * <p>
 * ����: �\�����ӎ�����ʃT�[�r�X</p>
 * <p>
 * ���쌠: Copyright (c) 2020</p>
 * <p>
 * ��Ж�: ���{���Y�Ɗ������</p>
 */
public class MskKshuKaijoSelectGroupService extends AbstractService {

    /**
     * DB�ڑ��̃f�[�^�\�[�X
     */
    private static String DATA_SOURCE_NAME;
    /**
     * ���O
     */
    BmaLogger log = (BmaLogger) BmaLogger.getLogger(this.getClass().getName());
    /**
     * �Ɩ��R�[�h
     */
    private static final String BUSINESS_CODE = PropertyUtility.getProperty("business_code");
    /**
     * ���׃e�X�g���[�h
     */
    private static final String STRESS_MODE = PropertyUtility.getProperty(BUSINESS_CODE + "stress_mode");
    /**
     * �N�x
     */
    private static final String NEN = PropertyUtility.getProperty(BUSINESS_CODE + "nen");

    /**
     * �R���X�g���N�^
     */
    public MskKshuKaijoSelectGroupService() {
        super();
        /* DB�ڑ����̃��[�U�[������ */
        DATA_SOURCE_NAME = BmaConstants.DS_REGISTRANT;
    }

    /**
     * �T�[�r�X�N���X�̎��s���\�b�h
     *
     * @param rto ���N�G�X�g��񂩂�擾����rto
     * @param rtoInSession �Z�b�V�������rto
     * @return foward��
     * @throws Exception ��O
     */
    @Override
    public String doService(RequestTransferObject rto, RequestTransferObject rtoInSession)
            throws Exception {

        MskKsuJoho inRequest = (MskKsuJoho) rto;
        MskKsuJoho inSession = (MskKsuJoho) rtoInSession;
        inSession.setNendo(inRequest.getNendo());
        String processName = "";
        /*�G���[���b�Z�[�W������*/
        inSession.setErrors(new Messages());
        try {
            if (!BmaUtility.isNullOrEmpty(inRequest.getNextDoi())) {
                processName = "MskKshuKaijoSelect";
                log.Start(processName);
                inSession.setSknKsuCode(inRequest.getSknKsuCode());
                inSession.setShubetsuCode(inRequest.getShubetsuCode());
                inSession.setKaisuCode(inRequest.getKaisuCode());
                inSession.setKaijoshikenkbn("0");
                List<MskKsuJoho> kaijoList = new ArrayList<>();
                List<MskKsuJoho> kaijoListNew = new ArrayList<>();
                ShiyoKaijo shiyoKaijo = new ShiyoKaijo(BmaConstants.DS_REGISTRANT);
                /*��ꃊ�X�g�擾*/
                kaijoList = shiyoKaijo.searchKaijoList(inSession.getNendo(), inSession.getSknKsuCode(),
                        inSession.getShubetsuCode(), inSession.getKaisuCode(), inSession.getKaijoshikenkbn());
                /*�J�Òn�擾*/
                Map<String, List<MskKsuJoho>> kaisaichi = kaijoList.stream().collect(
                        Collectors.groupingBy(MskKsuJoho::getKaisaichiCode));
                /*��ꃊ�X�g����J�Òn���Ɣz��*/
                for (Map.Entry<String, List<MskKsuJoho>> entry : kaisaichi.entrySet()) {
                    List<MskKsuJoho> listGroup = entry.getValue();
                    for (MskKsuJoho item : listGroup) {
                        item.setCount(listGroup.size() + "");
                        kaijoListNew.add(item);
                    }
                }
                inSession.setKaiMskJohoList(kaijoListNew);
                return FWD_NM_SUCCESS;
            } else if (!BmaUtility.isNullOrEmpty(inRequest.getKaijosentakuBack())) {
                processName = "MskKshuKaijoSelectBack";
                log.Start(processName);
                return FWD_NM_BACK;
            } else if (!BmaUtility.isNullOrEmpty(inRequest.getKaijoSentakuNext())) {
                processName = "MskKshuKaijoSelectNext";
                log.Start(processName);
                    return FWD_NM_NEXT;
            } else {
                /*�ُ�J��*/
                log.IllegalFWD();
                return FWD_NM_SESSION;
            }
        } catch (Exception e) {
            throw e;
        } finally {
            log.End(processName);
        }
    }
}
