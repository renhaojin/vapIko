package jp.co.nii.bma.integration;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import jp.co.nii.bma.business.domain.KessaiYokyuDao;
import jp.co.nii.bma.business.rto.MskKessaiJoho;
import jp.co.nii.bma.business.service.common.BmaConstants;
import jp.co.nii.sew.common.LogGenerate;
import static jp.co.nii.sew.integration.AbstractConfigDao.getSchemaName;
import jp.co.nii.sew.integration.SQLStateSQLExceptionTranslater;

/**
 * ���ϗv�� DAO�����N���X
 *
 * @author DB�Ǘ��c�[��
 */
public class KessaiYokyuDaoImpl extends GeneratedKessaiYokyuDaoImpl implements KessaiYokyuDao {

    /**
     * �C���X�^���X�𐶐�����B
     *
     * @param datasource �f�[�^�\�[�X��
     */
    public KessaiYokyuDaoImpl(String datasource) {
        super(datasource);
    }

    @Override
    public Boolean kessaiYokyuTrk(MskKessaiJoho bo) {
        Connection con = null;
        PreparedStatement stmt = null;
        String sql = "";
        String keissaiHoho = bo.getKessaiHoho();
        try {
            con = getConnection();
            sql = "INSERT INTO " + getSchemaName() + "." + TABLE_NAME + " ( "
                    + "TORIHIKI_CODE_NAIBU"
                    + ",SHOHIN_NAME_1"
                    + ",KINGAKU_1"
                    + ",KESSAI_HOHO"
                    + ",FINISH_URL"
                    + ",MODORI_URL"
                    + ",BUYER_KANJI_SHIMEI_SEI"
                    + ",BUYER_KANJI_SHIMEI_MEI"
                    + ",BUYER_KANA_SHIMEI_SEI"
                    + ",BUYER_KANA_SHIMEI_MEI"
                    + ",BUYER_ZIP_NUM_1"
                    + ",BUYER_TEL_NO"
                    + ",BUYER_JUSHO_1"
                    + ",BUYER_JUSHO_2"
                    + ",BUYER_MAIL_ADDRESS"
                    + ",SHIHARAI_KIGEN"
                    + ",UCHIZEI_GAKU"
                    + ",USER_ID"
                    + ",HYOJI_LANGUAGE"
                    + ",KESSAI_KAKUTEI"
                    + ",KOSHIN_KBN"
                    + ",TOROKU_DATE"
                    + ",TOROKU_TIME"
                    + ",TOROKU_USER_ID"
                    + " ) VALUES ("
                    + " ?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + "," + getSQLForEncryptByBynary("?")
                    + "," + getSQLForEncryptByBynary("?")
                    + "," + getSQLForEncryptByBynary("?")
                    + "," + getSQLForEncryptByBynary("?")
                    + "," + getSQLForEncryptByBynary("?")
                    + "," + getSQLForEncryptByBynary("?")
                    + "," + getSQLForEncryptByBynary("?")
                    + "," + getSQLForEncryptByBynary("?")
                    + "," + getSQLForEncryptByBynary("?")
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",'0'"
                    + ",?"
                    + ",'I'"
                    + ",?"
                    + ",?"
                    + ",?"
                    + " )";

            stmt = con.prepareStatement(sql);
            int i = 1;
            stmt.setString(i++, bo.getMoshikomiUketsukeNo());
            stmt.setString(i++, bo.getShikakuMeisho());
            stmt.setString(i++, bo.getKessaiGokeiKingaku());
            stmt.setString(i++, bo.getKessaiHoho());

            stmt.setString(i++, BmaConstants.KESSAI_OK_URL);
            stmt.setString(i++, BmaConstants.KESSAI_RT_URL);

            stmt.setString(i++, bo.getShimeiSei());
            stmt.setString(i++, bo.getShimeiMei());
            stmt.setString(i++, bo.getFuriganaSei());
            stmt.setString(i++, bo.getFuriganaMei());
            stmt.setString(i++, bo.getYubinNo());
            stmt.setString(i++, bo.getTelNo());
            stmt.setString(i++, bo.getJusho1());
            stmt.setString(i++, bo.getJusho2());
            stmt.setString(i++, bo.getMailAddress());
            if (keissaiHoho.equals("2")) {
                stmt.setString(i++, "");
            } else {
                stmt.setString(i++, "");
            }
            stmt.setString(i++, bo.getUchizei());
            stmt.setString(i++, bo.getMoshikomishaId());
            if (keissaiHoho.equals("1")) {
                stmt.setString(i++, "0");
            } else {
                stmt.setString(i++, "");
            }
            stmt.setString(i++, bo.getTorokuDate());
            stmt.setString(i++, bo.getTorokuTime());
            stmt.setString(i++, bo.getMoshikomishaId());

            LogGenerate.debugOutput(getSql(stmt));
            if (stmt.executeUpdate() == 0) {
                return false;
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt);
        }
        return true;
    }
}
