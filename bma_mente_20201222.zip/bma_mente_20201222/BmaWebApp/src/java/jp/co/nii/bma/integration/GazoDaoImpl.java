package jp.co.nii.bma.integration;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import jp.co.nii.bma.business.domain.Gazo;
import jp.co.nii.bma.business.domain.GazoDao;
import static jp.co.nii.bma.business.domain.GeneratedGazoDao.TABLE_NAME;
import jp.co.nii.bma.business.domain.Gazo;
import static jp.co.nii.bma.integration.GeneratedGazoDaoImpl.FIELDS_DECRYPT;
import jp.co.nii.sew.common.LogGenerate;
import jp.co.nii.sew.integration.SQLStateSQLExceptionTranslater;

/**
 * �摜 DAO�����N���X
 *
 * @author DB�Ǘ��c�[��
 */
public class GazoDaoImpl extends GeneratedGazoDaoImpl implements GazoDao {

    /**
     * �C���X�^���X�𐶐�����B
     *
     * @param datasource �f�[�^�\�[�X��
     */
    public GazoDaoImpl(String datasource) {
        super(datasource);
    }

    @Override
    public List<Gazo> findByNendoUke(String nendo, String uketsukeNo) {
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = "";

        List<Gazo> ret = new ArrayList<>();
        try {
            con = getConnection();
            sql = "SELECT " + FIELDS_DECRYPT
                    + " FROM " + getSchemaName() + "." + TABLE_NAME
                    + " WHERE"
                    + " NENDO = ?"
                    + " AND UKETSUKE_NO = ?"
                    + " ORDER BY gazo_kbn";
            stmt = con.prepareStatement(sql);
            int i = 1;
            stmt.setString(i++, nendo);
            stmt.setString(i++, uketsukeNo);

            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();
            while (rs.next()) {
                Gazo bo = new Gazo();
                setBoFromResultSet(bo, rs);
                ret.add(bo);
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return ret;
    }

}
