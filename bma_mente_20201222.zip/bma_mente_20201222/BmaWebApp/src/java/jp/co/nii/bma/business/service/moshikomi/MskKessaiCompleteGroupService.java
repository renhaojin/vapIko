package jp.co.nii.bma.business.service.moshikomi;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import jp.co.nii.bma.business.domain.Kessai;
import jp.co.nii.bma.business.domain.KessaiYokyuKanryoTsuchi;
import jp.co.nii.bma.business.domain.MailSoshinRireki;
import jp.co.nii.bma.business.domain.MailTemplate;
import jp.co.nii.bma.business.domain.MeishoKanri;
import jp.co.nii.bma.business.domain.Moshikomi;
import jp.co.nii.bma.business.domain.MoshikomiHenkoRireki;
import jp.co.nii.bma.business.domain.Saiban;
import jp.co.nii.bma.business.domain.Schedule;
import jp.co.nii.bma.business.rto.MskKessaiJoho;
import jp.co.nii.bma.business.service.common.BmaConstants;
import jp.co.nii.bma.business.service.common.BmaLogger;
import jp.co.nii.bma.business.service.common.BmaMailSendService;
import jp.co.nii.bma.business.service.common.KingakuKeisanService;
import jp.co.nii.bma.business.service.common.MoshikomiCommonService;
import jp.co.nii.bma.business.service.common.SaibanService;
import static jp.co.nii.bma.business.service.moshikomi.MskKessaiSelectGroupService.formatKingaku;
import jp.co.nii.bma.utility.BmaUtility;
import jp.co.nii.sew.business.service.AbstractService;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_EXCEPTION;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_SESSION;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_SUCCESS;
import jp.co.nii.sew.presentation.Messages;
import jp.co.nii.sew.presentation.RequestTransferObject;
import jp.co.nii.sew.utility.PropertyUtility;
import org.apache.commons.beanutils.BeanUtils;

/**
 * <p>
 * �^�C�g��: ���Ϗ����͊���</p>
 * <p>
 * ����: ���Ϗ����͊����T�[�r�X</p>
 * <p>
 * ���쌠: Copyright (c) 2016</p>
 * <p>
 * ��Ж�: ���{���Y�Ɗ������</p>
 */
public class MskKessaiCompleteGroupService extends AbstractService {

    /**
     * DB�ڑ��̃f�[�^�\�[�X
     */
    private static String DATA_SOURCE_NAME;
    /**
     * ���O
     */
    BmaLogger log = (BmaLogger) BmaLogger.getLogger(this.getClass().getName());
    /**
     * �Ɩ��R�[�h
     */
    private static final String BUSINESS_CODE = PropertyUtility.getProperty("business_code");
    /**
     * ���׃e�X�g���[�h
     */
    private static final String STRESS_MODE = PropertyUtility.getProperty(BUSINESS_CODE + "stress_mode");
    /**
     * ���ϊ������[���e���v���[�gID(�N���W�b�g)
     */
    private static final String KESSAI_FINISH_MAIL_TEMPLATE_ID_CARD = PropertyUtility.getProperty(BUSINESS_CODE + "kessai_finish_mail_template_id_card");
    /**
     * ���ϊ������[���e���v���[�gID(�R���r�j)
     */
    private static final String KESSAI_FINISH_MAIL_TEMPLATE_ID_CVS = PropertyUtility.getProperty(BUSINESS_CODE + "kessai_finish_mail_template_id_cvs");
    /**
     * ���ϊ������[���e���v���[�gID(�y�C�W�[)
     */
    private static final String KESSAI_FINISH_MAIL_TEMPLATE_ID_PAGE = PropertyUtility.getProperty(BUSINESS_CODE + "kessai_finish_mail_template_id_page");
    /**
     * ���ώ�����[���e���v���[�gID(�N���W�b�g)
     */
    private static final String KESSAI_CANCEL_MAIL_TEMPLATE_ID_CARD = PropertyUtility.getProperty(BUSINESS_CODE + "kessai_cancel_mail_template_id_cvs");
    /**
     * ����IP�R�[�h(�N���W�b�g)
     */
    private static final String KESSAI_IP_CODE_CARD = PropertyUtility.getProperty(BUSINESS_CODE + "kessai_ip_code_credit");
    /**
     * ����IP�R�[�h(�R���r�j)
     */
    private static final String KESSAI_IP_CODE_CVS = PropertyUtility.getProperty(BUSINESS_CODE + "kessai_ip_code_convenience");
    /**
     * ����IP�R�[�h(�y�[�W)
     */
    private static final String KESSAI_IP_CODE_PAGE = PropertyUtility.getProperty(BUSINESS_CODE + "kessai_ip_code_page");
    /**
     * �R���X�g���N�^
     */
    public MskKessaiCompleteGroupService() {
        super();
        /* DB�ڑ����̃��[�U�[������ */
        DATA_SOURCE_NAME = BmaConstants.DS_REGISTRANT;
    }

    /**
     * �T�[�r�X�N���X�̎��s���\�b�h
     *
     * @param rto ���N�G�X�g��񂩂�擾����rto
     * @param rtoInSession �Z�b�V�������rto
     * @return foward��
     * @throws Exception ��O
     */
    @Override
    public String doService(RequestTransferObject rto, RequestTransferObject rtoInSession) throws Exception {

        MskKessaiJoho inRequest = (MskKessaiJoho) rto;
        MskKessaiJoho inSession = (MskKessaiJoho) rtoInSession;
        String processName = "";

        /*�G���[���b�Z�[�W������*/
        inSession.setErrors(new Messages());
        String message;
        try {
            if (!BmaUtility.isNullOrEmpty(inRequest.getKessaiComplete())
                    || !BmaUtility.isNullOrEmpty(inRequest.getMskKakutei())) {
                processName = "MskKessaiCompleteCredit";
                log.Start(processName);
                String let = null;

                String kessaiHoho = inSession.getKessaiHoho();
                Date date = new Date();
                SimpleDateFormat dt = new SimpleDateFormat("yyyy�NMM��dd��");
                String mskDate = dt.format(date);
//                inSession.setFuka(inRequest.getFuka());
//                /* ���ω�Ж߂�d�� */
//                inSession.setFuka("AAAAA|BBBBB|CCCCC|DDDDDD|EEEEEE");
                inSession.setMskDate(mskDate);
                SimpleDateFormat sdFormat = new SimpleDateFormat("MMdd");
                SimpleDateFormat dt1 = new SimpleDateFormat("yyyy�NMM��dd��");
                Schedule schedule = new Schedule(DATA_SOURCE_NAME);
                String mskKigenbi = schedule.find(inRequest.getNendo(), inRequest.getSknKsuCode(), inRequest.getShubetsuCode(), inRequest.getKaisuCode(), "16", "02").getDate().substring(4, 8);
                inSession.setMskKigenbi(dt1.format(sdFormat.parse(mskKigenbi)));
                /* ���[���e���v���[�g�I�u�W�F�N�g�擾 */
                Calendar cal = Calendar.getInstance();
                MailTemplate mailTemplate = new MailTemplate(DATA_SOURCE_NAME);
                KessaiYokyuKanryoTsuchi kessaiYokyuKanryoTsuchi;
                int jkuryo = 0;
                if (null != kessaiHoho) {
                    switch (kessaiHoho) {
                        /* �N���W�b�g�J�[�h���� */
                        case BmaConstants.KESSAI_HOHO_KBN1:
                            // ��ʕ\�����Z�b�g
                            inSession.setKessaiJokyo("���ϊ���");
                            inSession.setJknJkuryo(inSession.getKessaiJknJkuryo());
                            inSession.setSystemRiyoryo(inSession.getKessaiJimutesuryo());
                            inSession.setGokei(inSession.getKessaiGokeiKingaku());
                            break;
                        /* �R���r�j���� */
                        case BmaConstants.KESSAI_HOHO_KBN2:
                            // ��ʕ\�����Z�b�g
                            inSession.setKessaiJokyo("������");
                            // ���ϗv�������ʒm���֘A�����擾
                            kessaiYokyuKanryoTsuchi = new KessaiYokyuKanryoTsuchi(DATA_SOURCE_NAME).find(inRequest.getTorihikiCode());
                            if (kessaiYokyuKanryoTsuchi == null) {
                                message = "���ϗv�������ʒm�e�[�u���Ƀf�[�^���o�^����Ă��܂���B"
                                        + " ����R�[�h�F"
                                        + inRequest.getTorihikiCode();
                                log.warn(message);
                                throw new Exception(message);
                            }
                            // �x������ݒ�
                            inSession.setHaraikomiDenpyoNo(kessaiYokyuKanryoTsuchi.getShiharaiJoho());
                            // �����p�R���r�j�[
                            inSession.setGoriyouConvenience(kessaiYokyuKanryoTsuchi.getKessaiHohoCvs());
                            
                            // ��u��
                            jkuryo = Integer.parseInt(kessaiYokyuKanryoTsuchi.getKessaiYoukyuKingaku()) - Integer.parseInt(kessaiYokyuKanryoTsuchi.getTesuryoKingaku());
                            inSession.setJknJkuryo(String.valueOf(jkuryo));
                            // �����萔��
                            inSession.setSystemRiyoryo(kessaiYokyuKanryoTsuchi.getTesuryoKingaku());
                            // ���ϗv�����z
                            inSession.setGokei(kessaiYokyuKanryoTsuchi.getKessaiYoukyuKingaku());
                            // ������
                            inSession.setShiharaiKigen((new MoshikomiCommonService(DATA_SOURCE_NAME).getKigenbi(inRequest.getNendo(), inRequest.getSknKsuCode(), inRequest.getShubetsuCode(), inRequest.getKaisuCode(), new Date())));
                            break;
                        /* �y�[�W���� */
                        case BmaConstants.KESSAI_HOHO_KBN3:
                            // ��ʕ\�����Z�b�g
                            inSession.setKessaiJokyo("������");
                            
                            // ���ϗv�������ʒm���֘A�����擾
                            kessaiYokyuKanryoTsuchi = new KessaiYokyuKanryoTsuchi(DATA_SOURCE_NAME).find(inRequest.getTorihikiCode());
                            if (kessaiYokyuKanryoTsuchi == null) {
                                message = "���ϗv�������ʒm�e�[�u���Ƀf�[�^���o�^����Ă��܂���B"
                                        + " ����R�[�h�F"
                                        + inRequest.getTorihikiCode();
                                log.warn(message);
                                throw new Exception(message);
                            }
                            // �x�����
                            String shiharaiJoho = kessaiYokyuKanryoTsuchi.getShiharaiJoho();
                            //���ώ��[�@�֔ԍ�	
                            inSession.setSyunokikanNo(shiharaiJoho.split(BmaConstants.HYPHEN)[0]);
                            //���ς��q�l�ԍ�
                            inSession.setUserNo(shiharaiJoho.split(BmaConstants.HYPHEN)[1]);
                            //���ϊm�F�ԍ�
                            inSession.setKakuninNo(shiharaiJoho.split(BmaConstants.HYPHEN)[2]);

                              // ��u��
                            jkuryo = Integer.parseInt(kessaiYokyuKanryoTsuchi.getKessaiYoukyuKingaku()) - Integer.parseInt(kessaiYokyuKanryoTsuchi.getTesuryoKingaku());
                            inSession.setJknJkuryo(String.valueOf(jkuryo));
                            // �����萔��
                            inSession.setSystemRiyoryo(kessaiYokyuKanryoTsuchi.getTesuryoKingaku());
                            // ���ϗv�����z
                            inSession.setGokei(kessaiYokyuKanryoTsuchi.getKessaiYoukyuKingaku());
                            // ������
                            inSession.setShiharaiKigen((new MoshikomiCommonService(DATA_SOURCE_NAME).getKigenbi(inRequest.getNendo(), inRequest.getSknKsuCode(), inRequest.getShubetsuCode(), inRequest.getKaisuCode(), new Date())));
                            break;
                        default:
                            inSession.setSknKsuCode(inRequest.getSknKsuCode());
                            inSession.setShubetsuCode(inRequest.getShubetsuCode());
                            inSession.setKaisuCode(inRequest.getKaisuCode());
                            inSession.setSknKsuKbn(inRequest.getSknKsuKbn());
                            inSession.setTorokuUserId(inRequest.getTorokuUserId());
                            inSession.setTorokuDate(inRequest.getTorokuDate());
                            inSession.setTorokuTime(inRequest.getTorokuTime());
                            inSession.setNendo(inRequest.getNendo());
                            inSession.setKessaiHohoChi("�Ə�");
                            inSession.setJknJkuryo("0�~");
                            inSession.setSystemRiyoryo("0�~");
                            inSession.setGokei("0�~");
                            inSession.setShiharaiKigenbi("");
                            
                            //�l�����擾
                            Moshikomi moshikomi = new Moshikomi(DATA_SOURCE_NAME);
                            inSession = moshikomi.getNinzuKsuKessai(inSession);
                            int sumNinzu = inSession.getMoshikomishaNinzu() + inSession.getKyuseidoNinzu();
                            inSession.setShokeiNinzu(sumNinzu);
                            inSession.setSumNinzu(sumNinzu);
                            inSession.setTesuryoGokei("0�~");
                            inSession.setMoshikomishaJknJkuryo("0�~");
                            inSession.setMoshikomishaGokei("0�~");
                            inSession.setKyuseidoJknJkuryo("0�~");
                            inSession.setKyuseidoGokei("0�~");
                            inSession.setShokeiGokei("0�~");
                            inSession.setSumNinzuGokei("0�~");
                            break;
                    }
                }
                if (mailTemplate != null) {
                    /*���[�����M*/
                    if (BmaUtility.isNullOrEmpty(inSession.getSoushinFlg())) {
                        try {
                            /* �g�����U�N�V�����擾&�J�n */
                            getTransaction();
                            beginTransaction();
                            List<String> MailParam = new ArrayList<>();
                            MailParam.add(inRequest.getShimeiSei() + " " + inRequest.getShimeiMei());
                            BmaMailSendService serv = new BmaMailSendService();
                            Boolean status = serv.sendMail("li-chenfeng@test-sys.net", inSession.getMailTemplateIdx(), MailParam);

                            // ���M�`�F�b�N
                            if (status) {
                                inSession.setSoushinFlg("1");
                            } else {
                                inSession.setSoushinFlg("0");
                            }
                            //���[�����ۑ�
                            inSession.setMailKenmei(mailTemplate.getMailKenmei());
                            inSession.setMailHonbun(mailTemplate.getMailHonbun());
                            inSession.setMailFooter(mailTemplate.getMailFooter());
                            if (inSession.getSoushinFlg().equals("1")) {
                                // �\��������������
                                Moshikomi moshikomi = new Moshikomi(DATA_SOURCE_NAME);
                                // �\�������X�V����
                                BeanUtils.copyProperties(moshikomi, moshikomi.find(inSession.getNendo(), inSession.getUketsukeNo()));
                                /* �X�V���Z�b�g */
                                MoshikomiUpd(moshikomi, inSession);
                                /*�A�b�v�f�[�g���s*/
                                moshikomi.update();
                                // �\���ύX��������o�^����
                                MoshikomiHenkoRireki moshikomiHenkoRireki = new MoshikomiHenkoRireki(DATA_SOURCE_NAME);
                                /* �\����񂩂�\���ύX�������ɒl���R�s�[ */
                                BeanUtils.copyProperties(moshikomiHenkoRireki, moshikomi);
                                /* �o�^���Z�b�g */
                                MoshikomiHenkoTrk(moshikomiHenkoRireki, inSession);
                                /*�C���T�[�g���s*/
                                moshikomiHenkoRireki.create();
                                //���ς�o�^����
                                Kessai kessai = new Kessai(DATA_SOURCE_NAME);
                                kessai.find(moshikomi.getNendo(), moshikomi.getUketsukeNo());
                                if (kessai.getUketsukeNo().isEmpty()) {
                                    /* �o�^���Z�b�g */
                                    kessaiTrk(kessai, inSession);
                                    /*�C���T�[�g���s*/
                                    kessai.create();
                                }
                                //���[�����M��o�^����
                                MailSoshinRireki mailSoshinRireki = new MailSoshinRireki(DATA_SOURCE_NAME);
                                /* �o�^���Z�b�g */
                                mailSoshinTrk(mailSoshinRireki, inSession);
                                /*�C���T�[�g���s*/
                                mailSoshinRireki.create();
                            }
                            /* �R�~�b�g */
                            commitTransaction();
                        } catch (Exception ex) {
                            ex.printStackTrace();
                            // ���[���o�b�N
                            rollbackTransaction();
                            return FWD_NM_SESSION;
                        }
                    }
                }
                return FWD_NM_SUCCESS;
            } else {
                /*�ُ�J��*/
                log.IllegalFWD();
                return FWD_NM_SESSION;
            }
        } catch (Exception e) {
            return FWD_NM_EXCEPTION;
        } finally {
            log.End(processName);
        }
    }

    /**
     * �\�����X�V����
     *
     * @param bo
     * @param inSession
     */
    public void MoshikomiUpd(Moshikomi bo, MskKessaiJoho inSession) throws Exception {
        Date date = new Date();
        SimpleDateFormat dt = new SimpleDateFormat("yyyyMMdd");
        SimpleDateFormat tm = new SimpleDateFormat("HHmmss");
        String koshinDate = dt.format(date);
        String koshinTime = tm.format(date);
        if (inSession.getKessaiHoho().equals(BmaConstants.KESSAI_HOHO_KBN1)
                || inSession.getKessaiHoho().equals(BmaConstants.KESSAI_HOHO_KBN4)) {
            bo.setKariUketsukeBi(koshinDate);
            bo.setKariUketsukeTime(koshinTime);
        }
        bo.setKoshinKbn("U");
        bo.setKoshinDate(koshinDate);
        bo.setKoshinTime(koshinTime);
        bo.setKoshinUserId(inSession.getMoshikomishaId());
    }

    /**
     * �\���ύX������o�^����
     *
     * @param bo
     * @param inSession
     */
    public void MoshikomiHenkoTrk(MoshikomiHenkoRireki bo, MskKessaiJoho inSession) throws Exception {
        Date date = new Date();
        SimpleDateFormat dt = new SimpleDateFormat("yyyyMMdd");
        SimpleDateFormat tm = new SimpleDateFormat("HHmmss");
        String koshinDate = dt.format(date);
        String koshinTime = tm.format(date);
        Saiban saiban = new SaibanService(DATA_SOURCE_NAME).getSaibanAndUpdate(BmaConstants.SAIBAN_MOSHIKOMIHENKORIREKI_IDX, inSession.getMoshikomishaId());
        bo.setMoshikomiHenkoRirekiIdx(saiban.getGenzaiNo());
        bo.setHenkoKbn("1");
        bo.setKoshinKbn("I");
        bo.setTorokuDate(koshinDate);
        bo.setTorokuTime(koshinTime);
        bo.setTorokuUserId(inSession.getMoshikomishaId());
        bo.setKoshinDate("");
        bo.setKoshinTime("");
        bo.setKoshinUserId("");
    }

    /**
     * ���ς�o�^����
     *
     * @param bo
     * @param inSession
     */
    public void kessaiTrk(Kessai bo, MskKessaiJoho inSession) throws Exception {
        Date date = new Date();
        SimpleDateFormat dt = new SimpleDateFormat("yyyyMMdd");
        SimpleDateFormat tm = new SimpleDateFormat("HHmmss");
        Calendar cal = Calendar.getInstance();
        String koshinDate = dt.format(date);
        String koshinTime = tm.format(date);
        bo.setNendo(inSession.getNendo());
        bo.setUketsukeNo(inSession.getUketsukeNo());
        if (inSession.getKessaiHoho().equals(BmaConstants.KESSAI_HOHO_KBN1)) {
            bo.setKessaiJokyoKbn("1");
            bo.setIpCode(KESSAI_IP_CODE_CARD);
            bo.setKessaiKigenBi("");
            bo.setKessaiConvenienceShubetsu("");
            bo.setKessaiConvenienceHaraikomiNo("");
            bo.setKessaiShunoKikanNo("");
            bo.setKessaiOkyakusamaNo("");
            bo.setKessaiKakuninNo("");
            bo.setKessaiKigenBi("");
            bo.setKessaiKingaku(inSession.getKessaiJknJkuryo().replaceAll("�~", "").replaceAll(",", ""));
            bo.setKessaiTesuryo(inSession.getKessaiJimutesuryo().replaceAll("�~", "").replaceAll(",", ""));
            bo.setKessaiKingakuTotal(inSession.getKessaiGokeiKingaku().replaceAll("�~", "").replaceAll(",", ""));
        } else if (inSession.getKessaiHoho().equals(BmaConstants.KESSAI_HOHO_KBN2)) {
            bo.setKessaiJokyoKbn("2");
            bo.setIpCode(KESSAI_IP_CODE_CVS);
//            bo.setKessaiConvenienceShubetsu(inSession.getFuka().split("\\|")[0]);
            bo.setKessaiConvenienceHaraikomiNo(inSession.getHaraikomiDenpyoNo());
//            bo.setKessaiConvenienceShubetsu(inSession.getFuka().split("\\|")[0]);
//            bo.setKessaiConvenienceHaraikomiNo(inSession.getFuka().split("\\|")[1]);
            
            bo.setKessaiShunoKikanNo("");
            bo.setKessaiOkyakusamaNo("");
            bo.setKessaiKakuninNo("");
            bo.setKessaiKigenBi(inSession.getShiharaiKigenbi());
            bo.setKessaiKingaku(inSession.getKessaiJknJkuryo().replaceAll("�~", "").replaceAll(",", ""));
            bo.setKessaiTesuryo(inSession.getKessaiJimutesuryo().replaceAll("�~", "").replaceAll(",", ""));
            bo.setKessaiKingakuTotal(inSession.getKessaiGokeiKingaku().replaceAll("�~", "").replaceAll(",", ""));
        } else if (inSession.getKessaiHoho().equals(BmaConstants.KESSAI_HOHO_KBN3)) {
            bo.setKessaiJokyoKbn("2");
            bo.setIpCode(KESSAI_IP_CODE_PAGE);
            bo.setKessaiConvenienceShubetsu("");
            bo.setKessaiConvenienceHaraikomiNo("");

            bo.setKessaiShunoKikanNo(inSession.getSyunokikanNo());
            bo.setKessaiOkyakusamaNo(inSession.getUserNo());
            bo.setKessaiKakuninNo(inSession.getKakuninNo());
            bo.setKessaiKigenBi(inSession.getShiharaiKigenbi());
            bo.setKessaiKingaku(inSession.getKessaiJknJkuryo().replaceAll("�~", "").replaceAll(",", ""));
            bo.setKessaiTesuryo(inSession.getKessaiJimutesuryo().replaceAll("�~", "").replaceAll(",", ""));
            bo.setKessaiKingakuTotal(inSession.getKessaiGokeiKingaku().replaceAll("�~", "").replaceAll(",", ""));
        } else if (inSession.getKessaiHoho().equals(BmaConstants.KESSAI_HOHO_KBN4)) {
            bo.setKessaiJokyoKbn("1");
            bo.setIpCode("");
            bo.setKessaiKigenBi("");
            bo.setKessaiConvenienceShubetsu("");
            bo.setKessaiConvenienceHaraikomiNo("");
            bo.setKessaiShunoKikanNo("");
            bo.setKessaiOkyakusamaNo("");
            bo.setKessaiKakuninNo("");
            bo.setKessaiKigenBi("");
            bo.setKessaiKingaku("0");
            bo.setKessaiTesuryo("0");
            bo.setKessaiKingakuTotal("0");
        }
        bo.setKessaiHohoKbn(inSession.getKessaiHoho());

        bo.setTorihikiCode(inSession.getUketsukeNo());

        bo.setKessaiHaraikomihyoUrl("");
        bo.setKessaiTokusokuMailSoshinFlg("0");
        bo.setKoshinKbn("I");
        bo.setTorokuDate(koshinDate);
        bo.setTorokuTime(koshinTime);
        bo.setTorokuUserId(inSession.getMoshikomishaId());
        bo.setKoshinDate("");
        bo.setKoshinTime("");
        bo.setKoshinUserId("");
        bo.setRonriSakujoFlg("0");
    }

    /**
     * ���[�����M������o�^����
     *
     * @param bo
     * @param inSession
     */
    public void mailSoshinTrk(MailSoshinRireki bo, MskKessaiJoho inSession) throws Exception {
        Date date = new Date();
        SimpleDateFormat dt = new SimpleDateFormat("yyyyMMdd");
        SimpleDateFormat tm = new SimpleDateFormat("HHmmss");
        String koshinDate = dt.format(date);
        String koshinTime = tm.format(date);
        Saiban saiban = new SaibanService(DATA_SOURCE_NAME).getSaibanAndUpdate(BmaConstants.SAIBAN_SENDMAILRIREKI_IDX, inSession.getMoshikomishaId());
        bo.setMailSoshinRirekiIdx(saiban.getGenzaiNo());
        bo.setMailKenmei(inSession.getMailKenmei());
        bo.setMailHonbun(inSession.getMailHonbun());
        bo.setMailFooter(inSession.getMailFooter());
        bo.setMailSoshinKensu("1");
        if (inSession.getSoushinFlg().equals("0")) {
            bo.setMailSoshinJokyoKbn("3");
        } else {
            bo.setMailSoshinJokyoKbn("2");
        }
        bo.setMailParam01("");
        bo.setMailParam02("");
        bo.setMailParam03("");
        bo.setMailParam04("");
        bo.setMailParam05("");
        bo.setMailParam06("");
        bo.setMailParam07("");
        bo.setMailParam08("");
        bo.setMailParam09("");
        bo.setMailParam10("");
        bo.setMailParam11("");
        bo.setMailParam12("");
        bo.setMailParam13("");
        bo.setMailParam14("");
        bo.setMailParam15("");
        bo.setMailParam16("");
        bo.setMailParam17("");
        bo.setMailParam18("");
        bo.setMailParam19("");
        bo.setMailParam20("");
        bo.setMailParam21("");
        bo.setMailParam22("");
        bo.setMailParam23("");
        bo.setMailParam24("");
        bo.setMailParam25("");
        bo.setMailParam26("");
        bo.setMailParam27("");
        bo.setMailParam28("");
        bo.setMailParam29("");
        bo.setMailParam30("");
        bo.setMailParam31("");
        bo.setMailParam32("");
        bo.setMailParam33("");
        bo.setMailParam34("");
        bo.setMailParam35("");
        bo.setMailParam36("");
        bo.setMailParam37("");
        bo.setMailParam38("");
        bo.setMailParam39("");
        bo.setMailParam40("");
        bo.setMailParam41("");
        bo.setMailParam42("");
        bo.setMailParam43("");
        bo.setMailParam44("");
        bo.setMailParam45("");
        bo.setMailParam46("");
        bo.setMailParam47("");
        bo.setMailParam48("");
        bo.setMailParam49("");
        bo.setMailParam50("");
        bo.setKoshinKbn("I");
        bo.setTorokuDate(koshinDate);
        bo.setTorokuTime(koshinTime);
        bo.setTorokuUserId(inSession.getMoshikomishaId());
        bo.setKoshinDate("");
        bo.setKoshinTime("");
        bo.setKoshinUserId("");
        bo.setRonriSakujoFlg("0");
    }
    
        /**
     * ���ϕ��@���X�g���Z�b�g����
     *
     * @param sknNaiyoKbn
     * @param kessaiHoho
     * @param genmenShinsei
     * @param inSession
     * @return
     */
    public Long kingakuKeisan(String sknNaiyoKbn, String kessaiHoho, String genmenShinsei, MskKessaiJoho inSession) {
        Long jknJkuryo;
        KingakuKeisanService KingakuKeisan = new KingakuKeisanService(DATA_SOURCE_NAME);
        String sknKsuCode = inSession.getSknKsuCode();
        String shubetsuCode = inSession.getShubetsuCode();
        String mskKbnSentaku = BmaConstants.SKN_KBN.equals(inSession.getSknKsuKbn()) ? "0" : "1";
        String tesuryoFlag = "1";
        jknJkuryo = KingakuKeisan.calcAmount(sknKsuCode, shubetsuCode,
                mskKbnSentaku, sknNaiyoKbn, kessaiHoho, genmenShinsei, tesuryoFlag, 0L).get(0);
        return jknJkuryo;
    }

}
