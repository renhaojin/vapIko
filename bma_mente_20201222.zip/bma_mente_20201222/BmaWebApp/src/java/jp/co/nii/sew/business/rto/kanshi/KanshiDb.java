package jp.co.nii.sew.business.rto.kanshi;

import javax.servlet.http.HttpServletRequest;
import jp.co.nii.sew.presentation.AbstractRequestTransferObject;

/**
 *
 * @author
 */
public class KanshiDb extends AbstractRequestTransferObject {

    public KanshiDb() {
        this.clearInfo();
    }

    /**
     * ������
     */
    public void clearInfo() {
    }

    /**
     * �Z�b�V��������rto�ɏ����擾
     *
     * @param HttpServletRequest request
     */
    @Override
    public void copyFromRequest(HttpServletRequest request) {
    }
}
