package jp.co.nii.bma.business.domain;

import jp.co.nii.bma.business.rto.MskKessaiJoho;

/**
 * ���ϗv�� BO�N���X
 *
 * @author DB�Ǘ��c�[��
 */
public class KessaiYokyu extends GeneratedKessaiYokyu {

    /**
     * �C���X�^���X�𐶐�����B
     */
    public KessaiYokyu() {
        super();
    }

    /**
     * �C���X�^���X�𐶐�����B
     *
     * @param connectionUser �f�[�^�\�[�X��
     */
    public KessaiYokyu(String connectionUser) {
        super(connectionUser);
    }

    /**
     * �摜�R���ɂ��\�������X�V����B
     *
     * @param uketukeNo
     * @param shikakuMeisho
     * @param goukei
     * @param kessaiHoho
     * @param shimeiSei
     * @param shimeiMei
     * @param furiganaSei
     * @param furiganaMei
     * @param yubinNo
     * @param telNo
     * @param jusho1
     * @param jusho2
     * @param mailAddress
     * @param uchizei
     * @param moshikomishaId
     * @param torokuDate
     * @param torokuTime
     * @return bo
     */
    public Boolean mskJohoUpd(String uketukeNo,
            String shikakuMeisho,
            String goukei,
            String kessaiHoho,
            String shimeiSei,
            String shimeiMei,
            String furiganaSei,
            String furiganaMei,
            String yubinNo,
            String telNo,
            String jusho1,
            String jusho2,
            String mailAddress,
            String uchizei,
            String moshikomishaId,
            String torokuDate,
            String torokuTime) {
        MskKessaiJoho bo = new MskKessaiJoho();
        return dao.kessaiYokyuTrk(bo);
    }
}
