package jp.co.nii.bma.business.service.common;

import java.util.ArrayList;
import java.util.List;
import jp.co.nii.bma.business.domain.Ryokin;
import jp.co.nii.bma.business.domain.Tesuryo;
import jp.co.nii.bma.utility.BmaUtility;
import jp.co.nii.sew.business.domain.LockException;

/**
 * �����v�Z�T�[�r�X�N���X
 *
 * @author C.Li
 */
public class KingakuKeisanService {

    /**
     * DB�ڑ��̃f�[�^�\�[�X
     */
    private static String DATA_SOURCE_NAME;

    /**
     * �R���X�g���N�^
     *
     * @param datasource
     */
    public KingakuKeisanService(String datasource) {
        super();
        /* DB�ڑ����̃��[�U�[������ */
        DATA_SOURCE_NAME = datasource;
    }

    /**
     * �����v�Z���\�b�h
     *
     * @param shokeiGokei
     * @�����u�K��R�[�h
     * @param sknKsuCode
     * @��ʃR�[�h
     * @param shubetsuCode
     * @����敪
     * @param mskKbnSentaku
     * @�������e�敪
     * @param sknNaiyoKbn
     * @���ϕ��@�敪
     * @param kessaiHoho
     * @���Ɛ\��
     * @param genmenShinsei
     * @�萔���t���O
     * @param tesuryoFlag
     * @return
     */
    public List<Long> calcAmount(String sknKsuCode, String shubetsuCode, String mskKbnSentaku,
            String sknNaiyoKbn, String kessaiHoho, String genmenShinsei, String tesuryoFlag, Long shokeiGokei) {
        try {
            List<Long> kingakuList = new ArrayList<>();
            List<String> ryokinKbnList = new ArrayList<>();
            if (mskKbnSentaku.equals(BmaConstants.KAIN_CODE_MEMBER)) {
                ryokinKbnList.add(BmaConstants.RYOKIN_KBN2);
            } else {
                ryokinKbnList.add(BmaConstants.RYOKIN_KBN1);
            }
            switch (sknNaiyoKbn) {
                case BmaConstants.SKN_NAIYO_KBN_NASHI:
                    break;
                case BmaConstants.SKN_NAIYO_KBN_GAKKA_JITSUGI:
                    ryokinKbnList.add(BmaConstants.RYOKIN_KBN3);
                    ryokinKbnList.add(BmaConstants.RYOKIN_KBN4);
                    break;
                case BmaConstants.SKN_NAIYO_KBN_GAKKA_MENJO:
                    ryokinKbnList.add(BmaConstants.RYOKIN_KBN4);
                    break;
                case BmaConstants.SKN_NAIYO_KBN_JITSUGI_MENJO:
                    ryokinKbnList.add(BmaConstants.RYOKIN_KBN3);
                    break;
                case BmaConstants.SKN_NAIYO_KBN_GAKKA_NOMI:
                    ryokinKbnList.add(BmaConstants.RYOKIN_KBN3);
                    break;
                case BmaConstants.SKN_NAIYO_KBN_JITSUGI_NOMI:
                    ryokinKbnList.add(BmaConstants.RYOKIN_KBN4);
                    break;
                default:
                    break;
            }
            if (kessaiHoho.equals(BmaConstants.KESSAI_HOHO_KBN_BENEFITS)) {
                ryokinKbnList.add(BmaConstants.RYOKIN_KBN6);
            }
            if (genmenShinsei != null) {
                if (genmenShinsei.equals(BmaConstants.GENMEN_ARI)) {
                    ryokinKbnList.add(BmaConstants.RYOKIN_KBN5);
                }
            }
            Double jknJkuryo = 0.0;
            Double jknJkuryoKeisan = 0.0;
            Ryokin ryokin = new Ryokin(BmaConstants.DS_REGISTRANT);
            for (String ryokinKbn : ryokinKbnList) {
                String kingaku = ryokin.findByRyokinKbn(sknKsuCode, shubetsuCode, ryokinKbn);
                if (!BmaUtility.isNullOrEmpty(kingaku)) {
                    if (ryokinKbn.equals(BmaConstants.RYOKIN_KBN5)) {
                        jknJkuryoKeisan = jknJkuryo - Double.parseDouble(kingaku);
                    } else if (ryokinKbn.equals(BmaConstants.RYOKIN_KBN6)) {
                        jknJkuryoKeisan = Double.parseDouble(kingaku);
                    } else {
                        jknJkuryoKeisan = jknJkuryo + Double.parseDouble(kingaku);
                    }
                    jknJkuryo = jknJkuryoKeisan;
                }
            }
            kingakuList.add(Math.round(jknJkuryoKeisan));

            if (shokeiGokei != 0) {
                jknJkuryoKeisan = (double) shokeiGokei;
            }

            Double tesuryoKeisan = 0.0;
            if (tesuryoFlag.equals(BmaConstants.TESURYO_FLAG_ARI)) {
                Tesuryo tesuryo = new Tesuryo(BmaConstants.DS_REGISTRANT);
                List<Tesuryo>  tesuryoList = tesuryo.findByRyokinKbn(kessaiHoho);
                for (int i = 0; i < tesuryoList.size(); i++) {
                    Double kakakuFrom = Double.parseDouble(tesuryoList.get(i).getKakakuFrom());
                    Double kakakuTo = Double.parseDouble(tesuryoList.get(i).getKakakuTo());
                    if (jknJkuryoKeisan.compareTo(kakakuFrom) >= 0 && jknJkuryoKeisan.compareTo(kakakuTo) <= 0) {
                        if (kessaiHoho.equals(BmaConstants.KESSAI_HOHO_KBN_CREDIT)) {
                            tesuryoKeisan = Double.parseDouble(tesuryoList.get(i).getTesuryo()) * jknJkuryoKeisan;
                            if (tesuryoList.get(i).getMarumeKbn().equals("0")) {
                                tesuryoKeisan = Math.floor(tesuryoKeisan);
                            } else {
                                tesuryoKeisan = Math.ceil(tesuryoKeisan);
                            }
                        } else {
                            tesuryoKeisan = Double.parseDouble(tesuryoList.get(i).getTesuryo());
                        }
                    }
                }

                kingakuList.add(Math.round(tesuryoKeisan));
                kingakuList.add(Math.round(jknJkuryoKeisan + tesuryoKeisan));
            } else {
                kingakuList.add(Math.round(tesuryoKeisan));
                kingakuList.add(Math.round(tesuryoKeisan + 0.0));
            }
            return kingakuList;
        } catch (LockException | NumberFormatException le) {
            throw le;
        }
    }
}
