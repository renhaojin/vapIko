package jp.co.nii.bma.business.rto;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import jp.co.nii.bma.business.domain.Gazo;
import jp.co.nii.bma.business.domain.HoyuShikakuMst;
import jp.co.nii.bma.business.domain.MSkkMnjKanri;
import jp.co.nii.bma.business.domain.Moshikomi;
import jp.co.nii.bma.business.domain.Shokureki;
import jp.co.nii.bma.business.domain.Torokusha;
import jp.co.nii.bma.business.service.common.BmaConstants;
import jp.co.nii.bma.utility.BmaUtility;
import jp.co.nii.sew.presentation.AbstractRequestTransferObject;
import jp.co.nii.sew.presentation.Messages;
import jp.co.nii.sew.presentation.Option;

/**
 * �\�����
 * 
 * @author BP80139
 */
public class MskJoho extends AbstractRequestTransferObject {

    /**
     * �G���[���Z�[�W
     */
    private Messages errors;
    /**
     * �\���҂h�c
     */
    private String moshikomishaId;
    /**
     * ����敪
     */
    private String kaiinKbn;
    /**
     * �����u�K��R�[�h
     */
    private String sknKsuCode;
    /**
     * ��ʃR�[�h
     */
    private String shubetsuCode;
    /**
     * �񐔃R�[�h
     */
    private String kaisuCode;
    /**
     * �������e�敪
     */
    private String sknNaiyoKbn;
    /**
     * �����u�K��敪
     */
    private String sknKsuKbn;
    /**
     * �����u�K�
     */
    private String sknKsuName;
    /**
     * �����u�K��Q��ʂȂ�
     */
    private String sknKsuNameNosbt;
    /**
     * ��ʖ�
     */
    private String shubetsuName;
    /**
     * �񐔖�
     */
    private String kaisuName;
    /**
     * ��t�ԍ�
     */
    private String uketsukeNo;
    /**
     * �o�^���[�U�[�h�c
     */
    private String torokuUserId;
    /**
     * �o�^���t
     */
    private String torokuDate;
    /**
     * �o�^����
     */
    private String torokuTime;
    /**
     * �N�x
     */
    private String nendo;
    /**
     * �N��
     */
    private String nenrei;

    /**
     * ����敪�̑I��
     */
    private String mskKbnSentaku;

    /**
     * ���Ӊ�ʂ̋K����e
     */
    private String agreementContent;
    /**
     * �J�[�\���ʒu
     */
    private String cursorPosition;

    private String backDoi;
    private String nextDoi;
    private String chkKiyakuDoi;
    private String sknKsu;
    private String sknShubetsu;
    private MskJoho mskJoho;
    private String gazoUpdNext;
    private String mskJohoBack;
    private String mskJohoNext;
    private String kessai;

    //�l���
    private String shimei;
    private String furigana;
    private String birthday;
    private String gender;
    private String yubinNo;
    private String yubinNoFront;
    private String yubinNoBack;
    private String jusho1;
    private String jusho2;
    private String tatemono;
    private String telNo;
    private String telNo1st;
    private String telNo2nd;
    private String telNo3rd;
    private String faxNo;
    private String faxNo1st;
    private String faxNo2nd;
    private String faxNo3rd;
    private String mailAddress;
    private String kokuseki;
    private String zairyucardNo;
    private String mailAddressKakunin;
    private String birthYear;
    private String birthMonth;
    private String birthDay;
    /**
     * �s���{��
     */
    private String todofuken;

    //�Ζ�����
    private String kinmusakiName;
    private String kinmusakiYubinNo;
    private String kinmusakiYubinFront;
    private String kinmusakiYubinBack;
    private String kinmusakiJusho1;
    private String kinmusakiJusho2;
    private String kinmusakiTatemono;
    private String kinmusakiTelNo;
    private String kinmusakiTelNo1st;
    private String kinmusakiTelNo2nd;
    private String kinmusakiTelNo3rd;
    private String kinmusakiFaxNo;
    private String kinmusakiFaxNo1st;
    private String kinmusakiFaxNo2nd;
    private String kinmusakiFaxNo3rd;
    /**
     * �Ζ���s���{��
     */
    private String kinmusakiTodofuken;

    //���t��
    private String sofusakiChoice;
    private String menjoCheck;
    private int gakaJitsugiGenmenNasiNinzu;
    private int gakaJitsugiGenmenNinzu;
    private int gakaOnlyNinzu;
    private int jitsugiOnlyGenmenNasiNinzu;
    private int jitsugiOnlyGenmenNinzu;
    private int gakaMenjoGenmenNasiNinzu;
    private int gakaMenjoGenmenNinzu;
    private int jitsugiMenjoNinzu;
    private int shokeiNinzu;
    private int sumNinzu;
    private int moshikomishaNinzu;
    private int kyuseidoNinzu;

    //�E�����
    private String kinmusaki;
    private String bushoyakushokuName;
    private String kinmuNaiyo;
    private String shozaichi;
    private String zaishokuKikan_From;
    private String zaishokuKikan_To;
    private String zaishokuKikanGokei;
    //�w�����  
    private String gakkouName;
    private String gakkouGakka;
    private String gakkouShozaichi;
    private String gakkouSotsugyonengappi;
    //�P�������
    private String kunrenShisetsuName;
    private String kunrenka;
    private String kunrenShozaichi;
    private String kunrenSyuryonengappi;
    //�Ə����
    private String menjoSikenName;
    private String menjoNaiyo;
    private String menjoNendo;
    private String menjoKyu;
    private String menjoGokaku;

    //�u���ϑI�� (�Ə��Ώێ�)�v�Ɖ�ʁu���ϕ��@�I���v�ɑJ�ڂ���t���b�O�i�\���m�F��ʗp�j
    private String kessaiSelectFlag;

    /**
     * �c��_�\�����m�F���
     */
    //�\�����F�l��
    private int ninzu;
    //���ׁF
    private int gakaJitsugiGenmenNasi;
    private int gakaJitsugiGenmen;
    private int gakaOnly;
    private int jitsugiOnlyGenmenNasi;
    private int jitsugiOnlyGenmen;
    private int gakaMenjoGenmenNasi;
    private int gakaMenjoGenmen;
    private int jitsugiMenjo;
    private int moshikomisha;
    private int kyuseido;

    //���X�g
    private List<MskJoho> gakurekiList;
    private List<MskJoho> kunrenList;
    private List<MskJoho> shokurekiList;

    /**
     * �s���{�����X�g
     */
    private List<Option> todofukenList;
    /**
     * ���ʃ��X�g
     */
    private List<Option> genderList;
    /**
     * ���t��敪���X�g
     */
    private List<Option> sofusakiList;
    /**
     * �󌟎萔���̌��Ɛ\�����X�g
     */
    private List<Option> genmenList;
    /**
     * ��]���{�n�惊�X�g
     */
    private List<Option> kaisaitiList;
    /**
     * ���N���� �N���X�g
     */
    private List<Option> birthYearList;
    /**
     * ���N���� �����X�g
     */
    private List<Option> birthMonthList;
    /**
     * ���N���� �����X�g
     */
    private List<Option> birthDayList;
    /**
     * ����\�����X�g(����敪���)
     */
    private List<String> kaiinMskList;
    /**
     * ��ʐ\�����X�g(����敪���)
     */
    private List<String> ipanMskList;
    /**
     * ����񃊃X�g(�\���m�F��ʗp)
     */
    private List<MskKsuJoho> kiboKaijoList;
    /**
     * �G���[���Z�[�W�}�b�v(�\���m�F��ʗp)
     */
    private Map<Option, Messages> errorJohoMaps;

    //�o�^��
    private String mskKakuninBack;
    private String mskKakutei;

    //�����I��bean
    private MskSknJoho mskSknJoho;
    //�u�K��I���A���I���@bean
    private MskKsuJoho mskKsuJoho;
    //���i���bean
    private MskSikakuJoho mskSikakuJoho;
    //�摜���bean
    private MskGazoJoho mskGazoJoho;

    private String mosikomi;
//    private String genmenShinseiTeigi;
    private String genmenShinsei;
    private String kiboJissiChiku;
    private String mosikomiFlag;

    private String mskKbnSentakuBack;
    private String mskKbnSentakuNext;

    // ���Ɛ\�� �N�Ƌ��z�\���p
    private String genmenKijunBi;
    private String genmenBirthYear;
    private String jitsugiKingaku;
    private String genmenKingaku;

    //DB�o�^�X�V�p
    private List<Moshikomi> moshikomiListForInsert;
    private List<MSkkMnjKanri> mSkkMnjKanriListForInsert;
    private List<Torokusha> torokushaListForInsert;
    private List<Gazo> gazoListForInsert;
    private List<Shokureki> shokurekiListForInsert;
    private Map<String, HoyuShikakuMst> hoyuShikakuMstMapForUpdate;
    private List<HoyuShikakuMst> hoyuShikakuMstMuryo;

    public MskJoho() {
        clearInfo();
    }

    private void clearInfo() {
        setErrors(new Messages());
        setMoshikomishaId("");
        setKaiinKbn("");
        setSknKsuCode("");
        setShubetsuCode("");
        setKaisuCode("");
        setSknNaiyoKbn("");
        setSknKsuKbn("");
        setSknKsuName("");
        setSknKsuNameNosbt("");
        setShubetsuName("");
        setKaisuName("");
        setUketsukeNo("");
        setTorokuUserId("");
        setTorokuDate("");
        setTorokuTime("");
        setNendo("");
        setNenrei("");
        setMenjoCheck("");

        /**
         * ����敪�̑I��
         */
        setMskKbnSentaku("");
        /**
         * ���Ӊ�ʂ̋K����e
         */
        setAgreementContent("");
        /**
         * �J�[�\���ʒu
         */
        setCursorPosition("");

        setBackDoi("");
        setNextDoi("");
        setChkKiyakuDoi("");
        setSknKsu("");
        setSknShubetsu("");
        setGazoUpdNext("");
        setMskJohoBack("");
        setMskJohoNext("");
        setKessai("");

        //�l���
        setShimei("");
        setFurigana("");
        setBirthday("");
        setGender("");
        setYubinNo("");
        setJusho1("");
        setJusho2("");
        setTatemono("");
        setTelNo("");
        setFaxNo("");
        setMailAddress("");
        setMailAddressKakunin("");
        setKokuseki("");
        setZairyucardNo("");
        setYubinNoFront("");
        setYubinNoBack("");
        setTelNo1st("");
        setTelNo2nd("");
        setTelNo3rd("");
        setFaxNo1st("");
        setFaxNo2nd("");
        setFaxNo3rd("");
        setBirthYear("");
        setBirthMonth("");
        setBirthDay("");

        //�Ζ�����
        setKinmusakiName("");
        setKinmusakiYubinNo("");
        setKinmusakiJusho1("");
        setKinmusakiJusho2("");
        setKinmusakiTatemono("");
        setKinmusakiTelNo("");
        setKinmusakiFaxNo("");
        setKinmusakiYubinFront("");
        setKinmusakiYubinBack("");
        setKinmusakiTelNo1st("");
        setKinmusakiTelNo2nd("");
        setKinmusakiTelNo3rd("");
        setKinmusakiFaxNo1st("");
        setKinmusakiFaxNo2nd("");
        setKinmusakiFaxNo3rd("");

        //���t��
        setSofusakiChoice("");

        setGakaJitsugiGenmenNasiNinzu(0);
        setGakaJitsugiGenmenNinzu(0);
        setGakaOnlyNinzu(0);
        setJitsugiOnlyGenmenNasiNinzu(0);
        setJitsugiOnlyGenmenNinzu(0);
        setGakaMenjoGenmenNasiNinzu(0);
        setGakaMenjoGenmenNinzu(0);
        setJitsugiMenjoNinzu(0);
        setShokeiNinzu(0);
        setSumNinzu(0);
        setMoshikomishaNinzu(0);
        setKyuseidoNinzu(0);

        //�E�����
        setKinmusaki("");
        setBushoyakushokuName("");
        setKinmuNaiyo("");
        setShozaichi("");
        setZaishokuKikan_From("");
        setZaishokuKikan_To("");
        setZaishokuKikanGokei("");
        //�w�����
        setGakkouName("");
        setGakkouGakka("");
        setGakkouShozaichi("");
        setGakkouSotsugyonengappi("");
        //�P�������
        setKunrenShisetsuName("");
        setKunrenka("");
        setKunrenShozaichi("");
        setKunrenSyuryonengappi("");
        //�Ə����
        setMenjoSikenName("");
        setMenjoNaiyo("");
        setMenjoNendo("");
        setMenjoKyu("");
        setMenjoGokaku("");

        //�J�ڃt���b�O
        setKessaiSelectFlag("");

        // ���Ɛ\�� �N�Ƌ��z�\���p
        setGenmenKijunBi("");
        setGenmenBirthYear("");
        setJitsugiKingaku("");
        setGenmenKingaku("");

        /**
         * �c��_�\�����m�F���
         */
        //�\�����F�l��
        setNinzu(0);
        //���ׁF
        setGakaJitsugiGenmenNasi(0);
        setGakaJitsugiGenmen(0);
        setGakaOnly(0);
        setJitsugiOnlyGenmenNasi(0);
        setJitsugiOnlyGenmen(0);
        setGakaMenjoGenmenNasi(0);
        setGakaMenjoGenmen(0);
        setJitsugiMenjo(0);
        setMoshikomisha(0);
        setKyuseido(0);
        setSumNinzu(0);

        //���X�g
        setGakurekiList(new ArrayList<MskJoho>());
        setKunrenList(new ArrayList<MskJoho>());
        setShokurekiList(new ArrayList<MskJoho>());

        setGenderList(new ArrayList<Option>());
        setTodofukenList(new ArrayList<Option>());
        setGenmenList(new ArrayList<Option>());
        setSofusakiList(new ArrayList<Option>());
        setKaisaitiList(new ArrayList<Option>());
        setBirthYearList(new ArrayList<Option>());
        setBirthMonthList(new ArrayList<Option>());
        setBirthDayList(new ArrayList<Option>());
        setKaiinMskList(new ArrayList<String>());
        setIpanMskList(new ArrayList<String>());
        setKiboKaijoList(new ArrayList<MskKsuJoho>());
        setErrorJohoMaps(new HashMap<Option, Messages>());

        //�o�^��
        setMskKakuninBack("");
        setMskKakutei("");
        setMosikomi("");
        setMosikomiFlag("");
        setGenmenShinsei("");
        setKiboJissiChiku("");
        setTodofuken("");
        setKinmusakiTodofuken("");
        setMskKbnSentakuBack("");
        setMskKbnSentakuNext("");

        //bean
        setMskSknJoho(new MskSknJoho());
        setMskKsuJoho(new MskKsuJoho());
        setMskSikakuJoho(new MskSikakuJoho());
        setMskGazoJoho(new MskGazoJoho());
    }

    @Override
    public void copyFromRequest(HttpServletRequest request) {
        setMoshikomishaId((String) request.getAttribute("moshikomishaId"));
        setKaiinKbn((String) request.getAttribute("kaiinKbn"));
        setSknKsuCode((String) request.getAttribute("sknKsuCode"));
        setShubetsuCode((String) request.getAttribute("shubetsuCode"));
        setKaisuCode((String) request.getAttribute("kaisuCode"));
        setSknNaiyoKbn((String) request.getAttribute("sknNaiyoKbn"));
        setSknKsuKbn((String) request.getAttribute("sknKsuKbn"));
        setSknKsuName((String) request.getAttribute("sknKsuName"));
        setSknKsuNameNosbt((String) request.getAttribute("sknKsuNameNosbt"));
        setShubetsuName((String) request.getAttribute("shubetsuName"));
        setKaisuName((String) request.getAttribute("kaisuName"));
        setUketsukeNo((String) request.getAttribute("uketsukeNo"));

        /**
         * ����敪�̑I��
         */
        setMskKbnSentaku((String) request.getAttribute("mskKbnSentaku"));
        /**
         * ���Ӊ�ʂ̋K����e
         */
        setAgreementContent((String) request.getAttribute("agreementContent"));
        /**
         * �J�[�\���ʒu
         */
        setCursorPosition((String) request.getAttribute("cursorPosition"));

        setBackDoi((String) request.getAttribute("backDoi"));
        setNextDoi((String) request.getAttribute("nextDoi"));
        setChkKiyakuDoi((String) request.getAttribute("chkKiyakuDoi"));
        setSknKsu((String) request.getAttribute("sknKsu"));
        setSknShubetsu((String) request.getAttribute("sknShubetsu"));
        setMskJoho((MskJoho) request.getAttribute("mskJoho"));
        setGazoUpdNext((String) request.getAttribute("gazoUpdNext"));
        setMskJohoBack((String) request.getAttribute("mskJohoBack"));
        setMskJohoNext((String) request.getAttribute("mskJohoNext"));
        setKessai((String) request.getAttribute("kessai"));

        //�l���
        setShimei((String) request.getAttribute("shimei"));
        setFurigana((String) request.getAttribute("furigana"));
        setBirthday((String) request.getAttribute("birthday"));
        setGender((String) request.getAttribute("gender"));
        setYubinNo((String) request.getAttribute("yubinNo"));
        setJusho1((String) request.getAttribute("jusho1"));
        setJusho2((String) request.getAttribute("jusho2"));
        setTatemono((String) request.getAttribute("tatemono"));
        setTelNo((String) request.getAttribute("telNo"));
        setFaxNo((String) request.getAttribute("faxNo"));
        setMailAddress((String) request.getAttribute("mailAddress"));
        setMailAddressKakunin((String) request.getAttribute("mailAddressKakunin"));
        setKokuseki((String) request.getAttribute("kokuseki"));
        setZairyucardNo((String) request.getAttribute("zairyucardNo"));
        setYubinNoFront((String) request.getAttribute("yubinNoFront"));
        setYubinNoBack((String) request.getAttribute("yubinNoBack"));
        setTelNo1st((String) request.getAttribute("telNo1st"));
        setTelNo2nd((String) request.getAttribute("telNo2nd"));
        setTelNo3rd((String) request.getAttribute("telNo3rd"));
        setFaxNo1st((String) request.getAttribute("faxNo1st"));
        setFaxNo2nd((String) request.getAttribute("faxNo2nd"));
        setFaxNo3rd((String) request.getAttribute("faxNo3rd"));
        setBirthYear((String) request.getAttribute("birthYear"));
        setBirthMonth((String) request.getAttribute("birthMonth"));
        setBirthDay((String) request.getAttribute("birthDay"));

        //�Ζ�����
        setKinmusakiName((String) request.getAttribute("kinmusakiName"));
        setKinmusakiYubinNo((String) request.getAttribute("kinmusakiYubinNo"));
        setKinmusakiJusho1((String) request.getAttribute("kinmusakiJusho1"));
        setKinmusakiJusho2((String) request.getAttribute("kinmusakiJusho2"));
        setKinmusakiTatemono((String) request.getAttribute("kinmusakiTatemono"));
        setKinmusakiTelNo((String) request.getAttribute("kinmusakiTelNo"));
        setKinmusakiFaxNo((String) request.getAttribute("kinmusakiFaxNo"));
        setKinmusakiYubinFront((String) request.getAttribute("kinmusakiYubinFront"));
        setKinmusakiYubinBack((String) request.getAttribute("kinmusakiYubinBack"));
        setKinmusakiTelNo1st((String) request.getAttribute("kinmusakiTelNo1st"));
        setKinmusakiTelNo2nd((String) request.getAttribute("kinmusakiTelNo2nd"));
        setKinmusakiTelNo3rd((String) request.getAttribute("kinmusakiTelNo3rd"));
        setKinmusakiFaxNo1st((String) request.getAttribute("kinmusakiFaxNo1st"));
        setKinmusakiFaxNo2nd((String) request.getAttribute("kinmusakiFaxNo2nd"));
        setKinmusakiFaxNo3rd((String) request.getAttribute("kinmusakiFaxNo3rd"));

        //���t��
        setSofusakiChoice((String) request.getAttribute("sofusakiChoice"));

        //�E�����
        setKinmusaki((String) request.getAttribute("kinmusaki"));
        setBushoyakushokuName((String) request.getAttribute("bushoyakushokuName"));
        setKinmuNaiyo((String) request.getAttribute("kinmuNaiyo"));
        setShozaichi((String) request.getAttribute("shozaichi"));
        setZaishokuKikan_From((String) request.getAttribute("zaishokuKikan_From"));
        setZaishokuKikan_To((String) request.getAttribute("zaishokuKikan_To"));
        setZaishokuKikanGokei((String) request.getAttribute("zaishokuKikanGokei"));

        //�w�����
        setGakkouName((String) request.getAttribute("gakkouName"));
        setGakkouGakka((String) request.getAttribute("gakkouGakka"));
        setGakkouShozaichi((String) request.getAttribute("gakkouShozaichi"));
        setGakkouSotsugyonengappi((String) request.getAttribute("gakkouSotsugyonengappi"));

        //�P�������
        setKunrenShisetsuName((String) request.getAttribute("kunrenShisetsuName"));
        setKunrenka((String) request.getAttribute("kunrenka"));
        setKunrenShozaichi((String) request.getAttribute("kunrenShozaichi"));
        setGakkouShozaichi((String) request.getAttribute("gakkouShozaichi"));
        setKunrenSyuryonengappi((String) request.getAttribute("kunrenSyuryonengappi"));

        //�Ə����
        setMenjoSikenName((String) request.getAttribute("menjoSikenName"));
        setMenjoNendo((String) request.getAttribute("menjoNendo"));
        setMenjoKyu((String) request.getAttribute("menjoKyu"));
        setMenjoGokaku((String) request.getAttribute("menjoGokaku"));

        //�J�ڃt���b�O
        setKessaiSelectFlag((String) request.getAttribute("kessaiSelectFlag"));

        //�o�^��
        setMskKakuninBack((String) request.getAttribute("mskKakuninBack"));
        setMskKakutei((String) request.getAttribute("mskKakutei"));
        setMosikomi((String) request.getAttribute("mosikomi"));
        setGenmenShinsei((String) request.getAttribute("genmenShinsei"));
        setKiboJissiChiku((String) request.getAttribute("kiboJissiChiku"));
        setTodofuken((String) request.getAttribute("todofuken"));
        setKinmusakiTodofuken((String) request.getAttribute("kinmusakiTodofuken"));
        setMskKbnSentakuBack((String) request.getAttribute("mskKbnSentakuBack"));
        setMskKbnSentakuNext((String) request.getAttribute("mskKbnSentakuNext"));

        HttpSession session = request.getSession(false);
        if (session.getAttribute("MskSknJoho") != null) {
            MskSknJoho tmp = (MskSknJoho) session.getAttribute("MskSknJoho");
            setMoshikomishaId(tmp.getMoshikomishaId());
            setSknKsuCode(tmp.getSknKsuCode());
            setShubetsuCode(tmp.getShubetsuCode());
            setKaisuCode(tmp.getKaisuCode());
            setSknKsuKbn(tmp.getSknKsuKbn());
            setSknKsuNameNosbt(tmp.getSknKsuNameNosbt());
            setShubetsuName(tmp.getShubetsuName());
            setKaiinKbn(tmp.getKaiinKbn());
            setNendo(tmp.getNendo());

            setMskSknJoho(tmp);
        }

        if (session.getAttribute("MskKsuJoho") != null) {
            MskKsuJoho tmp = (MskKsuJoho) session.getAttribute("MskKsuJoho");
            setMskKsuJoho(tmp);
        }

        if (session.getAttribute("MskSikakuJoho") != null) {
            MskSikakuJoho tmp = (MskSikakuJoho) session.getAttribute("MskSikakuJoho");
            setSknNaiyoKbn(tmp.getSknNaiyoKbn());
            setMskSikakuJoho(tmp);
        }

        if (session.getAttribute("MskGazoJoho") != null) {
            MskGazoJoho tmp = (MskGazoJoho) session.getAttribute("MskGazoJoho");
            setMskGazoJoho(tmp);
        }

        if (session.getAttribute("TopJoho") != null) {
            TopJoho temp = (TopJoho) session.getAttribute("TopJoho");
            setMoshikomishaId(temp.getMoshikomishaId());
        }
        if (session.getAttribute("MskUploadJoho") != null) {
            MskUploadJoho temp = (MskUploadJoho) session.getAttribute("MskUploadJoho");
            setTorokuUserId(temp.getTorokuUserId());
            setTorokuDate(temp.getTorokuDate());
            setTorokuTime(temp.getTorokuTime());
            setMoshikomiListForInsert(temp.getMoshikomiListForInsert());
            setMSkkMnjKanriListForInsert(temp.getMSkkMnjKanriListForInsert());
            setTorokushaListForInsert(temp.getTorokushaListForInsert());
            setGazoListForInsert(temp.getGazoListForInsert());
            setShokurekiListForInsert(temp.getShokurekiListForInsert());
            setHoyuShikakuMstMapForUpdate(temp.getHoyuShikakuMstMapForUpdate());
            setHoyuShikakuMstMuryo(temp.getHoyuShikakuMstMuryo());
        }
    }

    /**
     * @return the errors
     */
    public Messages getErrors() {
        return errors;
    }

    /**
     * @param errors the errors to set
     */
    public void setErrors(Messages errors) {
        this.errors = errors;
    }

    public Map<Option, Messages> getErrorJohoMaps() {
        return errorJohoMaps;
    }

    public void setErrorJohoMaps(Map<Option, Messages> errorJohoMaps) {
        this.errorJohoMaps = errorJohoMaps;
    }

    /**
     * @return the backDoi
     */
    public String getBackDoi() {
        return backDoi;
    }

    /**
     * @param backDoi the backDoi to set
     */
    public void setBackDoi(String backDoi) {
        this.backDoi = backDoi;
    }

    /**
     * @return the nextDoi
     */
    public String getNextDoi() {
        return nextDoi;
    }

    /**
     * @param nextDoi the nextDoi to set
     */
    public void setNextDoi(String nextDoi) {
        this.nextDoi = nextDoi;
    }

    /**
     * @return the chkKiyakuDoi
     */
    public String getChkKiyakuDoi() {
        return chkKiyakuDoi;
    }

    /**
     * @param chkKiyakuDoi the chkKiyakuDoi to set
     */
    public void setChkKiyakuDoi(String chkKiyakuDoi) {
        this.chkKiyakuDoi = chkKiyakuDoi;
    }

    /**
     * @return the sknKsu
     */
    public String getSknKsu() {
        return sknKsu;
    }

    /**
     * @param sknKsu the sknKsu to set
     */
    public void setSknKsu(String sknKsu) {
        this.sknKsu = sknKsu;
    }

    /**
     * @return the sknShubetsu
     */
    public String getSknShubetsu() {
        return sknShubetsu;
    }

    /**
     * @param sknShubetsu the sknShubetsu to set
     */
    public void setSknShubetsu(String sknShubetsu) {
        this.sknShubetsu = sknShubetsu;
    }

    /**
     * @return the mskJoho
     */
    public MskJoho getMskJoho() {
        return mskJoho;
    }

    /**
     * @param mskJoho the mskJoho to set
     */
    public void setMskJoho(MskJoho mskJoho) {
        this.mskJoho = mskJoho;
    }

    /**
     * @return the gazoUpdNext
     */
    public String getGazoUpdNext() {
        return gazoUpdNext;
    }

    /**
     * @param gazoUpdNext the gazoUpdNext to set
     */
    public void setGazoUpdNext(String gazoUpdNext) {
        this.gazoUpdNext = gazoUpdNext;
    }

    /**
     * @return the mskJohoBack
     */
    public String getMskJohoBack() {
        return mskJohoBack;
    }

    /**
     * @param mskJohoBack the mskJohoBack to set
     */
    public void setMskJohoBack(String mskJohoBack) {
        this.mskJohoBack = mskJohoBack;
    }

    /**
     * @return the mskJohoNext
     */
    public String getMskJohoNext() {
        return mskJohoNext;
    }

    /**
     * @param mskJohoNext the mskJohoNext to set
     */
    public void setMskJohoNext(String mskJohoNext) {
        this.mskJohoNext = mskJohoNext;
    }

    /**
     * @return the kessai
     */
    public String getKessai() {
        return kessai;
    }

    /**
     * @param kessai the kessai to set
     */
    public void setKessai(String kessai) {
        this.kessai = kessai;
    }

    public String getShimei() {
        return shimei;
    }

    public void setShimei(String shimei) {
        this.shimei = shimei;
    }

    public String getFurigana() {
        return furigana;
    }

    public void setFurigana(String furigana) {
        this.furigana = furigana;
    }

    public String getBirthday() {
        return birthday;
    }

    public void setBirthday(String birthday) {
        this.birthday = birthday;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getYubinNo() {
        return yubinNo;
    }

    public void setYubinNo(String yubinNo) {
        this.yubinNo = yubinNo;
    }

    public String getYubinNoFront() {
        return yubinNoFront;
    }

    public void setYubinNoFront(String yubinNoFront) {
        this.yubinNoFront = yubinNoFront;
    }

    public String getYubinNoBack() {
        return yubinNoBack;
    }

    public void setYubinNoBack(String yubinNoBack) {
        this.yubinNoBack = yubinNoBack;
    }

    public String getJusho1() {
        return jusho1;
    }

    public void setJusho1(String jusho1) {
        this.jusho1 = jusho1;
    }

    public String getJusho2() {
        return jusho2;
    }

    public void setJusho2(String jusho2) {
        this.jusho2 = jusho2;
    }

    public String getTatemono() {
        return tatemono;
    }

    public void setTatemono(String tatemono) {
        this.tatemono = tatemono;
    }

    public String getTelNo() {
        return telNo;
    }

    public void setTelNo(String telNo) {
        this.telNo = telNo;
    }

    public String getTelNo1st() {
        return telNo1st;
    }

    public void setTelNo1st(String telNo1st) {
        this.telNo1st = telNo1st;
    }

    public String getTelNo2nd() {
        return telNo2nd;
    }

    public void setTelNo2nd(String telNo2nd) {
        this.telNo2nd = telNo2nd;
    }

    public String getTelNo3rd() {
        return telNo3rd;
    }

    public void setTelNo3rd(String telNo3rd) {
        this.telNo3rd = telNo3rd;
    }

    public String getFaxNo() {
        return faxNo;
    }

    public void setFaxNo(String faxNo) {
        this.faxNo = faxNo;
    }

    public String getFaxNo1st() {
        return faxNo1st;
    }

    public void setFaxNo1st(String faxNo1st) {
        this.faxNo1st = faxNo1st;
    }

    public String getFaxNo2nd() {
        return faxNo2nd;
    }

    public void setFaxNo2nd(String faxNo2nd) {
        this.faxNo2nd = faxNo2nd;
    }

    public String getFaxNo3rd() {
        return faxNo3rd;
    }

    public void setFaxNo3rd(String faxNo3rd) {
        this.faxNo3rd = faxNo3rd;
    }

    public String getMailAddress() {
        return mailAddress;
    }

    public void setMailAddress(String mailAddress) {
        this.mailAddress = mailAddress;
    }

    public String getKokuseki() {
        return kokuseki;
    }

    public void setKokuseki(String kokuseki) {
        this.kokuseki = kokuseki;
    }

    public String getZairyucardNo() {
        return zairyucardNo;
    }

    public void setZairyucardNo(String zairyucardNo) {
        this.zairyucardNo = zairyucardNo;
    }

    public String getMailAddressKakunin() {
        return mailAddressKakunin;
    }

    public void setMailAddressKakunin(String mailAddressKakunin) {
        this.mailAddressKakunin = mailAddressKakunin;
    }

    public String getKinmusakiName() {
        return kinmusakiName;
    }

    public void setKinmusakiName(String kinmusakiName) {
        this.kinmusakiName = kinmusakiName;
    }

    public String getKinmusakiYubinNo() {
        return kinmusakiYubinNo;
    }

    public void setKinmusakiYubinNo(String kinmusakiYubinNo) {
        this.kinmusakiYubinNo = kinmusakiYubinNo;
    }

    public String getKinmusakiYubinFront() {
        return kinmusakiYubinFront;
    }

    public void setKinmusakiYubinFront(String kinmusakiYubinFront) {
        this.kinmusakiYubinFront = kinmusakiYubinFront;
    }

    public String getKinmusakiYubinBack() {
        return kinmusakiYubinBack;
    }

    public void setKinmusakiYubinBack(String kinmusakiYubinBack) {
        this.kinmusakiYubinBack = kinmusakiYubinBack;
    }

    public String getKinmusakiJusho1() {
        return kinmusakiJusho1;
    }

    public void setKinmusakiJusho1(String kinmusakiJusho1) {
        this.kinmusakiJusho1 = kinmusakiJusho1;
    }

    public String getKinmusakiJusho2() {
        return kinmusakiJusho2;
    }

    public void setKinmusakiJusho2(String kinmusakiJusho2) {
        this.kinmusakiJusho2 = kinmusakiJusho2;
    }

    public String getKinmusakiTatemono() {
        return kinmusakiTatemono;
    }

    public void setKinmusakiTatemono(String kinmusakiTatemono) {
        this.kinmusakiTatemono = kinmusakiTatemono;
    }

    public String getKinmusakiTelNo() {
        return kinmusakiTelNo;
    }

    public void setKinmusakiTelNo(String kinmusakiTelNo) {
        this.kinmusakiTelNo = kinmusakiTelNo;
    }

    public String getKinmusakiTelNo1st() {
        return kinmusakiTelNo1st;
    }

    public void setKinmusakiTelNo1st(String kinmusakiTelNo1st) {
        this.kinmusakiTelNo1st = kinmusakiTelNo1st;
    }

    public String getKinmusakiTelNo2nd() {
        return kinmusakiTelNo2nd;
    }

    public void setKinmusakiTelNo2nd(String kinmusakiTelNo2nd) {
        this.kinmusakiTelNo2nd = kinmusakiTelNo2nd;
    }

    public String getKinmusakiTelNo3rd() {
        return kinmusakiTelNo3rd;
    }

    public void setKinmusakiTelNo3rd(String kinmusakiTelNo3rd) {
        this.kinmusakiTelNo3rd = kinmusakiTelNo3rd;
    }

    public String getKinmusakiFaxNo() {
        return kinmusakiFaxNo;
    }

    public void setKinmusakiFaxNo(String kinmusakiFaxNo) {
        this.kinmusakiFaxNo = kinmusakiFaxNo;
    }

    public String getKinmusakiFaxNo1st() {
        return kinmusakiFaxNo1st;
    }

    public void setKinmusakiFaxNo1st(String kinmusakiFaxNo1st) {
        this.kinmusakiFaxNo1st = kinmusakiFaxNo1st;
    }

    public String getKinmusakiFaxNo2nd() {
        return kinmusakiFaxNo2nd;
    }

    public void setKinmusakiFaxNo2nd(String kinmusakiFaxNo2nd) {
        this.kinmusakiFaxNo2nd = kinmusakiFaxNo2nd;
    }

    public String getKinmusakiFaxNo3rd() {
        return kinmusakiFaxNo3rd;
    }

    public void setKinmusakiFaxNo3rd(String kinmusakiFaxNo3rd) {
        this.kinmusakiFaxNo3rd = kinmusakiFaxNo3rd;
    }

    public String getSofusakiChoice() {
        return sofusakiChoice;
    }

    public void setSofusakiChoice(String sofusakiChoice) {
        this.sofusakiChoice = sofusakiChoice;
    }

    public String getGenderDisp() {
        String str = "";
        if (BmaConstants.SEX_CODE_MALE.equals(this.getGender())) {
            str = "�j��";
        } else if (BmaConstants.SEX_CODE_FEMALE.equals(this.getGender())) {
            str = "����";
        }
        return str;
    }

    public String getBirthYear() {
        return birthYear;
    }

    public void setBirthYear(String birthYear) {
        this.birthYear = birthYear;
    }

    public String getBirthMonth() {
        return birthMonth;
    }

    public void setBirthMonth(String birthMonth) {
        this.birthMonth = birthMonth;
    }

    public String getBirthDay() {
        return birthDay;
    }

    public void setBirthDay(String birthDay) {
        this.birthDay = birthDay;
    }

    public String getCursorPosition() {
        return cursorPosition;
    }

    public void setCursorPosition(String cursorPosition) {
        this.cursorPosition = cursorPosition;
    }

    /**
     * @return the mskKakuninBack
     */
    public String getMskKakuninBack() {
        return mskKakuninBack;
    }

    /**
     * @param mskKakuninBack the mskKakuninBack to set
     */
    public void setMskKakuninBack(String mskKakuninBack) {
        this.mskKakuninBack = mskKakuninBack;
    }

    /**
     * @return the mskKakutei
     */
    public String getMskKakutei() {
        return mskKakutei;
    }

    /**
     * @param mskKakutei the mskKakutei to set
     */
    public void setMskKakutei(String mskKakutei) {
        this.mskKakutei = mskKakutei;
    }

    public String getKinmusaki() {
        return kinmusaki;
    }

    public void setKinmusaki(String kinmusaki) {
        this.kinmusaki = kinmusaki;
    }

    public String getBushoyakushokuName() {
        return bushoyakushokuName;
    }

    public void setBushoyakushokuName(String bushoyakushokuName) {
        this.bushoyakushokuName = bushoyakushokuName;
    }

    public String getKinmuNaiyo() {
        return kinmuNaiyo;
    }

    public void setKinmuNaiyo(String kinmuNaiyo) {
        this.kinmuNaiyo = kinmuNaiyo;
    }

    public String getShozaichi() {
        return shozaichi;
    }

    public void setShozaichi(String shozaichi) {
        this.shozaichi = shozaichi;
    }

    public String getZaishokuKikan_From() {
        return zaishokuKikan_From;
    }

    public void setZaishokuKikan_From(String zaishokuKikan_From) {
        this.zaishokuKikan_From = zaishokuKikan_From;
    }

    public String getZaishokuKikan_To() {
        return zaishokuKikan_To;
    }

    public void setZaishokuKikan_To(String zaishokuKikan_To) {
        this.zaishokuKikan_To = zaishokuKikan_To;
    }

    public String getZaishokuKikanGokei() {
        return zaishokuKikanGokei;
    }

    public void setZaishokuKikanGokei(String zaishokuKikanGokei) {
        this.zaishokuKikanGokei = zaishokuKikanGokei;
    }

    public String getGakkouName() {
        return gakkouName;
    }

    public void setGakkouName(String gakkouName) {
        this.gakkouName = gakkouName;
    }

    public String getGakkouGakka() {
        return gakkouGakka;
    }

    public void setGakkouGakka(String gakkouGakka) {
        this.gakkouGakka = gakkouGakka;
    }

    public String getGakkouShozaichi() {
        return gakkouShozaichi;
    }

    public void setGakkouShozaichi(String gakkouShozaichi) {
        this.gakkouShozaichi = gakkouShozaichi;
    }

    public String getGakkouSotsugyonengappi() {
        return gakkouSotsugyonengappi;
    }

    public void setGakkouSotsugyonengappi(String gakkouSotsugyonengappi) {
        this.gakkouSotsugyonengappi = gakkouSotsugyonengappi;
    }

    public String getKunrenShisetsuName() {
        return kunrenShisetsuName;
    }

    public void setKunrenShisetsuName(String kunrenShisetsuName) {
        this.kunrenShisetsuName = kunrenShisetsuName;
    }

    public String getKunrenka() {
        return kunrenka;
    }

    public void setKunrenka(String kunrenka) {
        this.kunrenka = kunrenka;
    }

    public String getKunrenShozaichi() {
        return kunrenShozaichi;
    }

    public void setKunrenShozaichi(String kunrenShozaichi) {
        this.kunrenShozaichi = kunrenShozaichi;
    }

    public String getKunrenSyuryonengappi() {
        return kunrenSyuryonengappi;
    }

    public void setKunrenSyuryonengappi(String kunrenSyuryonengappi) {
        this.kunrenSyuryonengappi = kunrenSyuryonengappi;
    }

    public String getMenjoSikenName() {
        return menjoSikenName;
    }

    public void setMenjoSikenName(String menjoSikenName) {
        this.menjoSikenName = menjoSikenName;
    }

    public String getMenjoNaiyo() {
        return menjoNaiyo;
    }

    public void setMenjoNaiyo(String menjoNaiyo) {
        this.menjoNaiyo = menjoNaiyo;
    }

    public String getMenjoNendo() {
        return menjoNendo;
    }

    public void setMenjoNendo(String menjoNendo) {
        this.menjoNendo = menjoNendo;
    }

    public String getMenjoKyu() {
        return menjoKyu;
    }

    public void setMenjoKyu(String menjoKyu) {
        this.menjoKyu = menjoKyu;
    }

    public String getMenjoGokaku() {
        return menjoGokaku;
    }

    public void setMenjoGokaku(String menjoGokaku) {
        this.menjoGokaku = menjoGokaku;
    }

    public String getKessaiSelectFlag() {
        return kessaiSelectFlag;
    }

    public void setKessaiSelectFlag(String kessaiSelectFlag) {
        this.kessaiSelectFlag = kessaiSelectFlag;
    }

    public int getNinzu() {
        return ninzu;
    }

    public void setNinzu(int ninzu) {
        this.ninzu = ninzu;
    }

    public int getGakaJitsugiGenmenNasi() {
        return gakaJitsugiGenmenNasi;
    }

    public void setGakaJitsugiGenmenNasi(int gakaJitsugiGenmenNasi) {
        this.gakaJitsugiGenmenNasi = gakaJitsugiGenmenNasi;
    }

    public int getGakaJitsugiGenmen() {
        return gakaJitsugiGenmen;
    }

    public void setGakaJitsugiGenmen(int gakaJitsugiGenmen) {
        this.gakaJitsugiGenmen = gakaJitsugiGenmen;
    }

    public int getGakaOnly() {
        return gakaOnly;
    }

    public void setGakaOnly(int gakaOnly) {
        this.gakaOnly = gakaOnly;
    }

    public int getJitsugiOnlyGenmenNasi() {
        return jitsugiOnlyGenmenNasi;
    }

    public void setJitsugiOnlyGenmenNasi(int jitsugiOnlyGenmenNasi) {
        this.jitsugiOnlyGenmenNasi = jitsugiOnlyGenmenNasi;
    }

    public int getJitsugiOnlyGenmen() {
        return jitsugiOnlyGenmen;
    }

    public void setJitsugiOnlyGenmen(int jitsugiOnlyGenmen) {
        this.jitsugiOnlyGenmen = jitsugiOnlyGenmen;
    }

    public int getGakaMenjoGenmenNasi() {
        return gakaMenjoGenmenNasi;
    }

    public void setGakaMenjoGenmenNasi(int gakaMenjoGenmenNasi) {
        this.gakaMenjoGenmenNasi = gakaMenjoGenmenNasi;
    }

    public int getGakaMenjoGenmen() {
        return gakaMenjoGenmen;
    }

    public void setGakaMenjoGenmen(int gakaMenjoGenmen) {
        this.gakaMenjoGenmen = gakaMenjoGenmen;
    }

    public int getJitsugiMenjo() {
        return jitsugiMenjo;
    }

    public void setJitsugiMenjo(int jitsugiMenjo) {
        this.jitsugiMenjo = jitsugiMenjo;
    }

    public int getMoshikomisha() {
        return moshikomisha;
    }

    public void setMoshikomisha(int moshikomisha) {
        this.moshikomisha = moshikomisha;
    }

    public int getKyuseido() {
        return kyuseido;
    }

    public void setKyuseido(int kyuseido) {
        this.kyuseido = kyuseido;
    }

    public int getSumNinzu() {
        return sumNinzu;
    }

    public void setSumNinzu(int sumNinzu) {
        this.sumNinzu = sumNinzu;
    }

    public List<MskJoho> getShokurekiList() {
        return shokurekiList;
    }

    public void setShokurekiList(List<MskJoho> shokurekiList) {
        this.shokurekiList = shokurekiList;
    }

    public List<MskKsuJoho> getKiboKaijoList() {
        return kiboKaijoList;
    }

    public void setKiboKaijoList(List<MskKsuJoho> kiboKaijoList) {
        this.kiboKaijoList = kiboKaijoList;
    }

    /**
     * @return the mskSknJoho
     */
    public MskSknJoho getMskSknJoho() {
        return mskSknJoho;
    }

    /**
     * @param mskSknJoho the mskSknJoho to set
     */
    public void setMskSknJoho(MskSknJoho mskSknJoho) {
        this.mskSknJoho = mskSknJoho;
    }

    public MskSikakuJoho getMskSikakuJoho() {
        return mskSikakuJoho;
    }

    public void setMskSikakuJoho(MskSikakuJoho mskSikakuJoho) {
        this.mskSikakuJoho = mskSikakuJoho;
    }

    public MskGazoJoho getMskGazoJoho() {
        return mskGazoJoho;
    }

    public void setMskGazoJoho(MskGazoJoho mskGazoJoho) {
        this.mskGazoJoho = mskGazoJoho;
    }

    /**
     * @return the mskKsuJoho
     */
    public MskKsuJoho getMskKsuJoho() {
        return mskKsuJoho;
    }

    /**
     * @param mskKsuJoho the mskKsuJoho to set
     */
    public void setMskKsuJoho(MskKsuJoho mskKsuJoho) {
        this.mskKsuJoho = mskKsuJoho;
    }

    public void setMosikomi(String mosikomi) {
        this.mosikomi = mosikomi;
    }

    public String getMosikomi() {
        return mosikomi;
    }

    public void setMosikomiFlag(String mosikomiFlag) {
        this.mosikomiFlag = mosikomiFlag;
    }

    public String getMosikomiFlag() {
        return mosikomiFlag;
    }

    public void setGenmenKijunBi(String genmenKijunBi) {
        this.genmenKijunBi = genmenKijunBi;
    }

    public String getGenmenKijunBi() {
        return genmenKijunBi;
    }

    public void setGenmenBirthYear(String genmenBirthYear) {
        this.genmenBirthYear = genmenBirthYear;
    }

    public String getGenmenBirthYear() {
        return genmenBirthYear;
    }

    public void setJitsugiKingaku(String jitsugiKingaku) {
        this.jitsugiKingaku = jitsugiKingaku;
    }

    public String getJitsugiKingaku() {
        return jitsugiKingaku;
    }

    public void setGenmenKingaku(String genmenKingaku) {
        this.genmenKingaku = genmenKingaku;
    }

    public String getGenmenKingaku() {
        return genmenKingaku;
    }

//    public String getHcnKeikenYear() {
//        return hcnKeikenYear;
//    }
//
//    public void setHcnKeikenYear(String hcnKeikenYear) {
//        this.hcnKeikenYear = hcnKeikenYear;
//    }
    public List<MskJoho> getGakurekiList() {
        return gakurekiList;
    }

    public void setGakurekiList(List<MskJoho> gakurekiList) {
        this.gakurekiList = gakurekiList;
    }

    public List<MskJoho> getKunrenList() {
        return kunrenList;
    }

    public void setKunrenList(List<MskJoho> kunrenList) {
        this.kunrenList = kunrenList;
    }

    /**
     * @return the genmenShinsei
     */
    public String getGenmenShinsei() {
        return genmenShinsei;
    }

    /**
     * @param genmenShinsei the genmenShinsei to set
     */
    public void setGenmenShinsei(String genmenShinsei) {
        this.genmenShinsei = genmenShinsei;
    }

    /**
     * @return the kiboJissiChiku
     */
    public String getKiboJissiChiku() {
        return kiboJissiChiku;
    }

    /**
     * @param kiboJissiChiku the kiboJissiChiku to set
     */
    public void setKiboJissiChiku(String kiboJissiChiku) {
        this.kiboJissiChiku = kiboJissiChiku;
    }

    /**
     * @return the todofuken
     */
    public String getTodofuken() {
        return todofuken;
    }

    /**
     * @param todofuken the todofuken to set
     */
    public void setTodofuken(String todofuken) {
        this.todofuken = todofuken;
    }

    /**
     * @return the kinmusakiTodofuken
     */
    public String getKinmusakiTodofuken() {
        return kinmusakiTodofuken;
    }

    /**
     * @param kinmusakiTodofuken the kinmusakiTodofuken to set
     */
    public void setKinmusakiTodofuken(String kinmusakiTodofuken) {
        this.kinmusakiTodofuken = kinmusakiTodofuken;
    }

    /**
     * @return the mskKbnSentaku
     */
    public String getMskKbnSentaku() {
        return mskKbnSentaku;
    }

    /**
     * @param mskKbnSentaku the mskKbnSentaku to set
     */
    public void setMskKbnSentaku(String mskKbnSentaku) {
        this.mskKbnSentaku = mskKbnSentaku;
    }

    /**
     * @return the mskKbnSentakuBack
     */
    public String getMskKbnSentakuBack() {
        return mskKbnSentakuBack;
    }

    /**
     * @param mskKbnSentakuBack the mskKbnSentakuBack to set
     */
    public void setMskKbnSentakuBack(String mskKbnSentakuBack) {
        this.mskKbnSentakuBack = mskKbnSentakuBack;
    }

    /**
     * @return the mskKbnSentakuNext
     */
    public String getMskKbnSentakuNext() {
        return mskKbnSentakuNext;
    }

    /**
     * @param mskKbnSentakuNext the mskKbnSentakuNext to set
     */
    public void setMskKbnSentakuNext(String mskKbnSentakuNext) {
        this.mskKbnSentakuNext = mskKbnSentakuNext;
    }

    public String getAgreementContent() {
        return agreementContent;
    }

    public void setAgreementContent(String agreementContent) {
        this.agreementContent = agreementContent;
    }

    public String getSknKsuKbn() {
        return sknKsuKbn;
    }

    public void setSknKsuKbn(String sknKsuKbn) {
        this.sknKsuKbn = sknKsuKbn;
    }

    public String getMoshikomishaId() {
        return moshikomishaId;
    }

    public void setMoshikomishaId(String moshikomishaId) {
        this.moshikomishaId = moshikomishaId;
    }

    /**
     * ����敪 ���擾����B
     *
     * @return ����敪
     */
    public String getKaiinKbn() {
        return kaiinKbn;
    }

    /**
     * ����敪 ���Z�b�g����B
     *
     * @param kaiinKbn ����敪
     */
    public void setKaiinKbn(String kaiinKbn) {
        this.kaiinKbn = kaiinKbn;
    }

    public String getSknKsuCode() {
        return sknKsuCode;
    }

    public void setSknKsuCode(String sknKsuCode) {
        this.sknKsuCode = sknKsuCode;
    }

    public String getShubetsuCode() {
        return shubetsuCode;
    }

    public void setShubetsuCode(String shubetsuCode) {
        this.shubetsuCode = shubetsuCode;
    }

    public String getKaisuCode() {
        return kaisuCode;
    }

    public void setKaisuCode(String kaisuCode) {
        this.kaisuCode = kaisuCode;
    }

    public String getSknKsuName() {
        return sknKsuName;
    }

    public void setSknKsuName(String sknKsuName) {
        this.sknKsuName = sknKsuName;
    }

    public String getSknKsuNameNosbt() {
        return sknKsuNameNosbt;
    }

    public void setSknKsuNameNosbt(String sknKsuNameNosbt) {
        this.sknKsuNameNosbt = sknKsuNameNosbt;
    }

    public String getShubetsuName() {
        return shubetsuName;
    }

    public void setShubetsuName(String shubetsuName) {
        this.shubetsuName = shubetsuName;
    }

    public String getKaisuName() {
        return kaisuName;
    }

    public void setKaisuName(String kaisuName) {
        this.kaisuName = kaisuName;
    }

    public String getUketsukeNo() {
        return uketsukeNo;
    }

    public void setUketsukeNo(String uketsukeNo) {
        this.uketsukeNo = uketsukeNo;
    }

    /**
     * �o�^���� ���擾����B
     *
     * @return �o�^����
     */
    public String getTorokuTime() {
        return torokuTime;
    }

    /**
     * �o�^���� ���Z�b�g����B
     *
     * @param torokuTime �o�^����
     */
    public void setTorokuTime(String torokuTime) {
        this.torokuTime = torokuTime;
    }

    public String getNendo() {
        return nendo;
    }

    public void setNendo(String nendo) {
        this.nendo = nendo;
    }

    /**
     * �N�� ���擾����B
     *
     * @return �N��
     */
    public String getNenrei() {
        return nenrei;
    }

    /**
     * �N�� ���Z�b�g����B
     *
     * @param nenrei �N��
     */
    public void setNenrei(String nenrei) {
        this.nenrei = nenrei;
    }

    /**
     * �o�^���[�U�[�h�c ���擾����B
     *
     * @return �o�^���[�U�[�h�c
     */
    public String getTorokuUserId() {
        return torokuUserId;
    }

    /**
     * �o�^���[�U�[�h�c ���Z�b�g����B
     *
     * @param torokuUserId �o�^���[�U�[�h�c
     */
    public void setTorokuUserId(String torokuUserId) {
        this.torokuUserId = torokuUserId;
    }

    public String getSknNaiyoKbn() {
        return sknNaiyoKbn;
    }

    public void setSknNaiyoKbn(String sknNaiyoKbn) {
        this.sknNaiyoKbn = sknNaiyoKbn;
    }

    public List<Option> getTodofukenList() {
        return todofukenList;
    }

    public void setTodofukenList(List<Option> todofukenList) {
        this.todofukenList = todofukenList;
    }

    public List<Option> getKaisaitiList() {
        return kaisaitiList;
    }

    public void setKaisaitiList(List<Option> kaisaitiList) {
        this.kaisaitiList = kaisaitiList;
    }

    public List<Option> getSofusakiList() {
        return sofusakiList;
    }

    public void setSofusakiList(List<Option> sofusakiList) {
        this.sofusakiList = sofusakiList;
    }

    public List<Option> getGenmenList() {
        return genmenList;
    }

    public void setGenmenList(List<Option> genmenList) {
        this.genmenList = genmenList;
    }

    public List<Option> getGenderList() {
        return genderList;
    }

    public void setGenderList(List<Option> genderList) {
        this.genderList = genderList;
    }

    public List<Option> getBirthYearList() {
        return birthYearList;
    }

    public void setBirthYearList(List<Option> birthYearList) {
        this.birthYearList = birthYearList;
    }

    public List<Option> getBirthMonthList() {
        return birthMonthList;
    }

    public void setBirthMonthList(List<Option> birthMonthList) {
        this.birthMonthList = birthMonthList;
    }

    public List<Option> getBirthDayList() {
        return birthDayList;
    }

    public void setBirthDayList(List<Option> birthDayList) {
        this.birthDayList = birthDayList;
    }

    public List<String> getKaiinMskList() {
        return kaiinMskList;
    }

    public void setKaiinMskList(List<String> kaiinMskList) {
        this.kaiinMskList = kaiinMskList;
    }

    public List<String> getIpanMskList() {
        return ipanMskList;
    }

    public void setIpanMskList(List<String> ipanMskList) {
        this.ipanMskList = ipanMskList;
    }

    /**
     * �s���{���擾
     *
     * @return the todofukenDisp
     */
    public String getTodofukenDisp() {
        String ret = "";
        if (BmaUtility.isNullOrEmpty(getTodofuken())) {
            return ret;
        }
        for (Option option : getTodofukenList()) {
            if (option.getValue().equals(getTodofuken())) {
                ret = option.getLabel();
                // �s�A�{�A����t����
                ret = getTodofukenExt(getTodofuken(), ret);
                break;
            }
        }
        return ret;
    }

    /**
     * �Ζ���s���{���擾
     *
     * @return the kinmusakiTodofukenDisp
     */
    public String getKinmusakiTodofukenDisp() {
        String ret = "";
        if (BmaUtility.isNullOrEmpty(getKinmusakiTodofuken())) {
            return ret;
        }
        for (Option option : getTodofukenList()) {
            if (option.getValue().equals(getKinmusakiTodofuken())) {
                ret = option.getLabel();
                // �s�A�{�A����t����
                ret = getTodofukenExt(getKinmusakiTodofuken(), ret);
                break;
            }
        }
        return ret;
    }

    /**
     * ���t����擾
     *
     * @return the sofusakiChoiceDisp
     */
    public String getSofusakiChoiceDisp() {
        String ret = "";
        if (BmaUtility.isNullOrEmpty(getSofusakiChoice())) {
            return ret;
        }
        for (Option option : getSofusakiList()) {
            if (option.getValue().equals(getSofusakiChoice())) {
                ret = option.getLabel();
                break;
            }
        }
        return ret;
    }

    /**
     * ��]���{�n��擾
     *
     * @return the kiboJissiChikuDisp
     */
    public String getKiboJissiChikuDisp() {
        String ret = "";
        if (BmaUtility.isNullOrEmpty(getKiboJissiChiku())) {
            return ret;
        }
        for (Option option : getKaisaitiList()) {
            if (option.getValue().equals(getKiboJissiChiku())) {
                ret = option.getLabel();
                break;
            }
        }
        return ret;
    }

    /**
     * ���Z�����󌟎萔���̌��Ɛ\���擾
     *
     * @return the genmenShinseiDisp
     */
    public String getGenmenShinseiDisp() {
        String ret = "";
        if (BmaUtility.isNullOrEmpty(getGenmenShinsei())) {
            return ret;
        }
        for (Option option : getGenmenList()) {
            if (option.getValue().equals(getGenmenShinsei())) {
                ret = option.getLabel();
                break;
            }
        }
        return ret;
    }

    /**
     * �����u�K��R�[�h�擾 (�C���X�y�N�^�[)
     *
     * @return the sknKsuCodeIP
     */
    public String getSknKsuCodeIP() {
        return BmaConstants.SKN_KSU_CODE_IP;
    }

    /**
     * �����u�K��R�[�h�擾 (�a�@���|����ӔC�ҍu�K)
     *
     * @return the sknKsuCodeHC
     */
    public String getSknKsuCodeHC() {
        return BmaConstants.SKN_KSU_CODE_HC;
    }

    /**
     * �����u�K��R�[�h�擾 (�r���N���[�j���O�Z�\����)
     *
     * @return the sknKsuCodeBC
     */
    public String getSknKsuCodeBC() {
        return BmaConstants.SKN_KSU_CODE_BC;
    }

    /**
     * �����u�K��R�[�h�擾 (�r���ݔ��Ǘ��Z�p�Z�p����)
     *
     * @return the sknKsuCodeBE
     */
    public String getSknKsuCodeBE() {
        return BmaConstants.SKN_KSU_CODE_BE;
    }

    /**
     * �����u�K��R�[�h�擾 (����Z�\�]������)
     *
     * @return the sknKsuCodeBS
     */
    public String getSknKsuCodeBS() {
        return BmaConstants.SKN_KSU_CODE_BS;
    }

    /**
     * ��ʃR�[�h�擾 (1��)
     *
     * @return the shubetsuCodeOne
     */
    public String getShubetsuCodeOne() {
        return BmaConstants.SHUBETSU_CODE_ONE;
    }

    /**
     * ��ʃR�[�h�擾 (2��)
     *
     * @return the shubetsuCodeOne
     */
    public String getShubetsuCodeTwo() {
        return BmaConstants.SHUBETSU_CODE_TWO;
    }

    /**
     * ��ʃR�[�h�擾 (3��)
     *
     * @return the shubetsuCodeThree
     */
    public String getShubetsuCodeThree() {
        return BmaConstants.SHUBETSU_CODE_THREE;
    }

    /**
     * ��ʃR�[�h�擾 (�V�K)
     *
     * @return the shubetsuCodeNew
     */
    public String getShubetsuCodeNew() {
        return BmaConstants.SHUBETSU_CODE_NEW;
    }

    /**
     * ��ʃR�[�h�擾 (�t�H���[�A�b�v)
     *
     * @return the shubetsuCodeFollowUp
     */
    public String getShubetsuCodeFollowUp() {
        return BmaConstants.SHUBETSU_CODE_FOLLOW_UP;
    }

    /**
     * ��ʃR�[�h�擾 (�ču�K)
     *
     * @return the shubetsuCodeSaiKsu
     */
    public String getShubetsuCodeSaiKsu() {
        return BmaConstants.SHUBETSU_CODE_SAIKSU;
    }

    /**
     * @return the torokuDate
     */
    public String getTorokuDate() {
        return torokuDate;
    }

    /**
     * @param torokuDate the torokuDate to set
     */
    public void setTorokuDate(String torokuDate) {
        this.torokuDate = torokuDate;
    }

    /**
     * @return the gakaJitsugiGenmenNasiNinzu
     */
    public int getGakaJitsugiGenmenNasiNinzu() {
        return gakaJitsugiGenmenNasiNinzu;
    }

    /**
     * @param gakaJitsugiGenmenNasiNinzu the gakaJitsugiGenmenNasiNinzu to set
     */
    public void setGakaJitsugiGenmenNasiNinzu(int gakaJitsugiGenmenNasiNinzu) {
        this.gakaJitsugiGenmenNasiNinzu = gakaJitsugiGenmenNasiNinzu;
    }

    /**
     * @return the gakaJitsugiGenmenNinzu
     */
    public int getGakaJitsugiGenmenNinzu() {
        return gakaJitsugiGenmenNinzu;
    }

    /**
     * @param gakaJitsugiGenmenNinzu the gakaJitsugiGenmenNinzu to set
     */
    public void setGakaJitsugiGenmenNinzu(int gakaJitsugiGenmenNinzu) {
        this.gakaJitsugiGenmenNinzu = gakaJitsugiGenmenNinzu;
    }

    /**
     * @return the gakaOnlyNinzu
     */
    public int getGakaOnlyNinzu() {
        return gakaOnlyNinzu;
    }

    /**
     * @param gakaOnlyNinzu the gakaOnlyNinzu to set
     */
    public void setGakaOnlyNinzu(int gakaOnlyNinzu) {
        this.gakaOnlyNinzu = gakaOnlyNinzu;
    }

    /**
     * @return the jitsugiOnlyGenmenNasiNinzu
     */
    public int getJitsugiOnlyGenmenNasiNinzu() {
        return jitsugiOnlyGenmenNasiNinzu;
    }

    /**
     * @param jitsugiOnlyGenmenNasiNinzu the jitsugiOnlyGenmenNasiNinzu to set
     */
    public void setJitsugiOnlyGenmenNasiNinzu(int jitsugiOnlyGenmenNasiNinzu) {
        this.jitsugiOnlyGenmenNasiNinzu = jitsugiOnlyGenmenNasiNinzu;
    }

    /**
     * @return the jitsugiOnlyGenmenNinzu
     */
    public int getJitsugiOnlyGenmenNinzu() {
        return jitsugiOnlyGenmenNinzu;
    }

    /**
     * @param jitsugiOnlyGenmenNinzu the jitsugiOnlyGenmenNinzu to set
     */
    public void setJitsugiOnlyGenmenNinzu(int jitsugiOnlyGenmenNinzu) {
        this.jitsugiOnlyGenmenNinzu = jitsugiOnlyGenmenNinzu;
    }

    /**
     * @return the gakaMenjoGenmenNasiNinzu
     */
    public int getGakaMenjoGenmenNasiNinzu() {
        return gakaMenjoGenmenNasiNinzu;
    }

    /**
     * @param gakaMenjoGenmenNasiNinzu the gakaMenjoGenmenNasiNinzu to set
     */
    public void setGakaMenjoGenmenNasiNinzu(int gakaMenjoGenmenNasiNinzu) {
        this.gakaMenjoGenmenNasiNinzu = gakaMenjoGenmenNasiNinzu;
    }

    /**
     * @return the gakaMenjoGenmenNinzu
     */
    public int getGakaMenjoGenmenNinzu() {
        return gakaMenjoGenmenNinzu;
    }

    /**
     * @param gakaMenjoGenmenNinzu the gakaMenjoGenmenNinzu to set
     */
    public void setGakaMenjoGenmenNinzu(int gakaMenjoGenmenNinzu) {
        this.gakaMenjoGenmenNinzu = gakaMenjoGenmenNinzu;
    }

    /**
     * @return the jitsugiMenjoNinzu
     */
    public int getJitsugiMenjoNinzu() {
        return jitsugiMenjoNinzu;
    }

    /**
     * @param jitsugiMenjoNinzu the jitsugiMenjoNinzu to set
     */
    public void setJitsugiMenjoNinzu(int jitsugiMenjoNinzu) {
        this.jitsugiMenjoNinzu = jitsugiMenjoNinzu;
    }

    /**
     * @return the shokeiNinzu
     */
    public int getShokeiNinzu() {
        return shokeiNinzu;
    }

    /**
     * @param shokeiNinzu the shokeiNinzu to set
     */
    public void setShokeiNinzu(int shokeiNinzu) {
        this.shokeiNinzu = shokeiNinzu;
    }

    /**
     * @return the moshikomishaNinzu
     */
    public int getMoshikomishaNinzu() {
        return moshikomishaNinzu;
    }

    /**
     * @param moshikomishaNinzu the moshikomishaNinzu to set
     */
    public void setMoshikomishaNinzu(int moshikomishaNinzu) {
        this.moshikomishaNinzu = moshikomishaNinzu;
    }

    /**
     * @return the kyuseidoNinzu
     */
    public int getKyuseidoNinzu() {
        return kyuseidoNinzu;
    }

    /**
     * @param kyuseidoNinzu the kyuseidoNinzu to set
     */
    public void setKyuseidoNinzu(int kyuseidoNinzu) {
        this.kyuseidoNinzu = kyuseidoNinzu;
    }

    /**
     * @return the menjoCheck
     */
    public String getMenjoCheck() {
        return menjoCheck;
    }

    /**
     * @param menjoCheck the menjoCheck to set
     */
    public void setMenjoCheck(String menjoCheck) {
        this.menjoCheck = menjoCheck;
    }

    public void setMoshikomiListForInsert(List<Moshikomi> moshikomiListForInsert) {
        this.moshikomiListForInsert = moshikomiListForInsert;
    }

    public List<Moshikomi> getMoshikomiListForInsert() {
        return moshikomiListForInsert;
    }

    public void setMSkkMnjKanriListForInsert(List<MSkkMnjKanri> mSkkMnjKanriListForInsert) {
        this.mSkkMnjKanriListForInsert = mSkkMnjKanriListForInsert;
    }

    public List<MSkkMnjKanri> getMSkkMnjKanriListForInsert() {
        return mSkkMnjKanriListForInsert;
    }

    public void setTorokushaListForInsert(List<Torokusha> torokushaListForInsert) {
        this.torokushaListForInsert = torokushaListForInsert;
    }

    public List<Torokusha> getTorokushaListForInsert() {
        return torokushaListForInsert;
    }

    public void setGazoListForInsert(List<Gazo> gazoListForInsert) {
        this.gazoListForInsert = gazoListForInsert;
    }

    public List<Gazo> getGazoListForInsert() {
        return gazoListForInsert;
    }

    public void setShokurekiListForInsert(List<Shokureki> shokurekiListForInsert) {
        this.shokurekiListForInsert = shokurekiListForInsert;
    }

    public List<Shokureki> getShokurekiListForInsert() {
        return shokurekiListForInsert;
    }

    public void setHoyuShikakuMstMapForUpdate(Map<String, HoyuShikakuMst> hoyuShikakuMstMapForUpdate) {
        this.hoyuShikakuMstMapForUpdate = hoyuShikakuMstMapForUpdate;
    }

    public Map<String, HoyuShikakuMst> getHoyuShikakuMstMapForUpdate() {
        return hoyuShikakuMstMapForUpdate;
    }

    public void setHoyuShikakuMstMuryo(List<HoyuShikakuMst> hoyuShikakuMstMuryo) {
        this.hoyuShikakuMstMuryo = hoyuShikakuMstMuryo;
    }

    public List<HoyuShikakuMst> getHoyuShikakuMstMuryo() {
        return hoyuShikakuMstMuryo;
    }

    /**
     * �s�A�{�A����t����
     *
     * @param todofukenCode �s���{���R�[�h
     * @param todofuken �s�A�{�A����n�������s���{����
     * @return �s�A�{�A����t�����s���{������Ԃ�
     */
    public String getTodofukenExt(String todofukenCode, String todofuken) {
        // ���A�{�A�s��t����
        switch (todofukenCode) {
            case BmaConstants.TODOFUKEN_CODE_HOKAIDO:
                break;
            case BmaConstants.TODOFUKEN_CODE_TOKYOTO:
                todofuken = todofuken + BmaConstants.TO;
                break;
            case BmaConstants.TODOFUKEN_CODE_KYOTOFU:
            case BmaConstants.TODOFUKEN_CODE_OSAKAFU:
                todofuken = todofuken + BmaConstants.FU;
                break;
            default:
                todofuken = todofuken + BmaConstants.KEN;
        }
        return todofuken;
    }
}
