package jp.co.nii.bma.business.service.moshikomi;

import java.util.ArrayList;
import java.util.List;
import jp.co.nii.bma.business.domain.MeishoKanri;
import jp.co.nii.bma.business.rto.MskGazoJoho;
import jp.co.nii.bma.business.service.common.BmaConstants;
import jp.co.nii.bma.business.service.common.BmaLogger;
import jp.co.nii.bma.business.service.common.BmaValidator;
import jp.co.nii.bma.presentation.common.BmaText;
import jp.co.nii.bma.utility.BmaUtility;
import jp.co.nii.sew.business.service.AbstractService;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_SUCCESS;
import jp.co.nii.sew.presentation.Messages;
import jp.co.nii.sew.presentation.Option;
import jp.co.nii.sew.presentation.RequestTransferObject;
import jp.co.nii.sew.utility.PropertyUtility;

/**
 * <p>
 * �^�C�g��: ��ʐ^�A�b�v���[�h�T�[�r�X</p>
 * <p>
 * ����: ��ʐ^�A�b�v���[�h�T�[�r�X</p>
 * <p>
 * ���쌠: Copyright (c) 2016</p>
 * <p>
 * ��Ж�: ���{���Y�Ɗ������</p>
 */
public class MskGazoUploadService extends AbstractService {

    /**
     * DB�ڑ��̃f�[�^�\�[�X
     */
    private static String DATA_SOURCE_NAME;
    /**
     * ���O
     */
    BmaLogger log = (BmaLogger) BmaLogger.getLogger(this.getClass().getName());
    /**
     * �Ɩ��R�[�h
     */
    private static final String BUSINESS_CODE = PropertyUtility.getProperty("business_code");
    /**
     * ���׃e�X�g���[�h
     */
    private static final String STRESS_MODE = PropertyUtility.getProperty(BUSINESS_CODE + "stress_mode");

    /**
     * �R���X�g���N�^
     */
    public MskGazoUploadService() {
        super();
        /* DB�ڑ����̃��[�U�[������ */
        DATA_SOURCE_NAME = BmaConstants.DS_REGISTRANT;
    }

    /**
     * �T�[�r�X�N���X�̎��s���\�b�h
     *
     * @param rto ���N�G�X�g��񂩂�擾����rto
     * @param rtoInSession �Z�b�V�������rto
     * @return foward��
     * @throws Exception ��O
     */
    @Override
    public String doService(RequestTransferObject rto, RequestTransferObject rtoInSession)
            throws Exception {

        MskGazoJoho inRequest = (MskGazoJoho) rto;
        MskGazoJoho inSession = (MskGazoJoho) rtoInSession;
        String processName = "";
        /*�G���[���b�Z�[�W������*/
        inSession.setErrors(new Messages());
        try {
            if (!BmaUtility.isNullOrEmpty(inRequest.getReload())){
                /*�����[�h��*/
                processName = "MskGazoUpload";

                return FWD_NM_RELOAD;
            } else if (!BmaUtility.isNullOrEmpty(inRequest.getSkkJohoNext())
                    && BmaUtility.isNullOrEmpty(inSession.getUpdCheck())) {
                inSession.clearInfo();
                /*�{�^��������*/
                processName = "MskGazoUpload";
                log.Start(processName);
                ArrayList<MskGazoJoho> shomeishoList = new ArrayList<>();
                ArrayList<MskGazoJoho> jknSikakuList = new ArrayList<>();
                ArrayList<MskGazoJoho> menjoList = new ArrayList<>();
                List<Option> list = new ArrayList<>();
                MeishoKanri meishoKanri = new MeishoKanri(BmaConstants.DS_REGISTRANT);
                meishoKanri.findByGroupCode(BmaConstants.GAZO_KBN, list);
                for (int i = 0; i < list.size(); i++) {
                    switch (i) {
                        case 0:
                            MskGazoJoho kaoshashin = new MskGazoJoho();
                            kaoshashin.setShomeishoruiShubetu(list.get(i).getLabel());
                            kaoshashin.setGazoKbn(list.get(i).getValue());
                            kaoshashin.setShomeishoruiUpdStatus(BmaConstants.GAZO_UPD_STATUS_MI);
                            shomeishoList.add(kaoshashin);
                            break;
                        case 1:
                            MskGazoJoho nenrei = new MskGazoJoho();
                            nenrei.setShomeishoruiShubetu(list.get(i).getLabel());
                            nenrei.setGazoKbn(list.get(i).getValue());
                            nenrei.setShomeishoruiUpdStatus(BmaConstants.GAZO_UPD_STATUS_MI);
                            shomeishoList.add(nenrei);
                            break;
                        case 2:
                            MskGazoJoho shikaku = new MskGazoJoho();
                            shikaku.setJknsikakuShubetu(list.get(i).getLabel());
                            shikaku.setGazoKbn(list.get(i).getValue());
                            shikaku.setJknsikakuUpdStatus(BmaConstants.GAZO_UPD_STATUS_MI);
                            jknSikakuList.add(shikaku);
                            break;
                        case 3:
                            MskGazoJoho menjo = new MskGazoJoho();
                            menjo.setMenjoShubetu(list.get(i).getLabel());
                            menjo.setGazoKbn(list.get(i).getValue());
                            menjo.setMenjoUpdStatus(BmaConstants.GAZO_UPD_STATUS_MI);
                            menjoList.add(menjo);
                            break;
                        default:
                            break;
                    }
                }
                
                if (BmaConstants.KSU_KBN.equals(inRequest.getSknKsuKbn())) {
                        shomeishoList.remove(1);
                }

                inSession.setShomeishoList(shomeishoList);
                inSession.setJknSikakuList(jknSikakuList);
                inSession.setMenjoList(menjoList);
                inSession.setKaoImg(inRequest.getKaoImg());
                inSession.setNenreiImg(inRequest.getNenreiImg());
                inSession.setShikakuImg(inRequest.getShikakuImg());
                inSession.setMenjyoImg(inRequest.getMenjyoImg());
                inSession.setSkkJohoNext(inRequest.getSkkJohoNext());
                return FWD_NM_SUCCESS;
            } else if (!BmaUtility.isNullOrEmpty(inRequest.getSkkJohoNext())
                    && !BmaUtility.isNullOrEmpty(inSession.getUpdCheck())) {
                /*�{�^��������*/
                processName = "MskGazoUpload";
                log.Start(processName);
                boolean retCheck = UploadCheck(inSession);
                if (retCheck) {
                    inSession.setGazoUpdNext("1");
                } else {
                    if (!BmaUtility.isNullOrEmpty(inRequest.getGazoUpdNext())) {
                        Messages errors = new Messages();
                        BmaValidator.addMessage(errors, "gazoUpdNext", BmaText.E00055, "");
                        inSession.setErrors(errors);
                    }
                }
                return FWD_NM_RELOAD;
            } else if (!BmaUtility.isNullOrEmpty(inRequest.getGazoUpdBack())) {
                /*�{�^��������*/
                if (!BmaUtility.isNullOrEmpty(inSession.getUpdCheck())) {
                    inSession.clearInfo();
                }
                processName = "MskSikakuJohoInput";
                log.Start(processName);
                return FWD_NM_BACK;
            } else if (!BmaUtility.isNullOrEmpty(inRequest.getGazoUpdNext())
                    || !BmaUtility.isNullOrEmpty(inSession.getGazoUpdNext())) {
                /*���փ{�^��������*/
                processName = "MskJohoInput";
                boolean retCheck = UploadCheck(inSession);
                if (!retCheck) {
                    Messages errors = new Messages();
                    BmaValidator.addMessage(errors, "gazoUpdNext", BmaText.E00055, "");
                    inSession.setErrors(errors);
                    return FWD_NM_RELOAD;
                }
                inSession.setUpdCheck("");
                inSession.setGazoUpdNext("");
                return FWD_NM_NEXT;
            } else {
                /* �ُ�ȑJ�� */
                log.IllegalFWD();
                return FWD_NM_SESSION;
            }
        } catch (Exception ex) {
            throw ex;
        } finally {
            log.End(processName);
        }
    }

    /**
     * �A�b�v���[�h�`�F�b�N
     *
     * @param InSession
     * @return ��肪�Ȃ���� true�A����� false
     */
    private boolean UploadCheck(MskGazoJoho inSession) throws Exception {
        List<MskGazoJoho> shomeishoList;
        List<MskGazoJoho> jknSikakuList;
        List<MskGazoJoho> menjoList;
        shomeishoList = inSession.getShomeishoList();
        jknSikakuList = inSession.getJknSikakuList();
        menjoList = inSession.getMenjoList();
        if (!BmaUtility.isNullOrEmpty(inSession.getKaoImg())) {
            if (shomeishoList.get(0).getShomeishoruiUpdStatus().equals(BmaConstants.GAZO_UPD_STATUS_MI)) {
                return false;
            }
        }

        if (!BmaUtility.isNullOrEmpty(inSession.getNenreiImg())) {
            if (shomeishoList.get(1).getShomeishoruiUpdStatus().equals(BmaConstants.GAZO_UPD_STATUS_MI)) {
                return false;
            }
        }

        if (!BmaUtility.isNullOrEmpty(inSession.getShikakuImg())) {
            if (jknSikakuList.get(0).getJknsikakuUpdStatus().equals(BmaConstants.GAZO_UPD_STATUS_MI)) {
                return false;
            }
        }
        if (!BmaUtility.isNullOrEmpty(inSession.getMenjyoImg())) {
            if (menjoList.get(0).getMenjoUpdStatus().equals(BmaConstants.GAZO_UPD_STATUS_MI)) {
                return false;
            }
        }
        return true;
    }
}
