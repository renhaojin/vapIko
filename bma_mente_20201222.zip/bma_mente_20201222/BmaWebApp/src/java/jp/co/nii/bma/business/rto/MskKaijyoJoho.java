package jp.co.nii.bma.business.rto;

import javax.servlet.http.HttpServletRequest;
import jp.co.nii.sew.presentation.AbstractRequestTransferObject;

/**
 * �^�C�g��: TOP��� ����: TOP���RTO ���쌠: Copyright (c) 2020 ��Ж�: ���{���Y�Ɗ������
 */
public class MskKaijyoJoho extends AbstractRequestTransferObject {

    private String date1;
    private String date2;
    private String kaijoName;
    private String kaijoJusho;
    private String kuusekiSuu;
    private String daiichiKibo;
    private String dainiKibo;

    public MskKaijyoJoho() {
        clearInfo();
    }

    private void clearInfo() {
        setDate1("");
        setDate2("");
        setKaijoName("");
        setKaijoJusho("");
        setKuusekiSuu("");
        setDaiichiKibo("");
        setDainiKibo("");
    }

    @Override
    public void copyFromRequest(HttpServletRequest request) {
        setDate1((String) request.getAttribute("nextDoi"));
        setKaijoName((String) request.getAttribute("chkKiyakuDoi"));
        setKaijoJusho((String) request.getAttribute("kaijoJusho"));
        setKuusekiSuu((String) request.getAttribute("kuusekiSuu"));
        setDainiKibo((String) request.getAttribute("dainiKibo"));
        setDaiichiKibo((String) request.getAttribute("daiichiKibo"));
    }

    public void setDate1(String date1) {
        this.date1 = date1;
    }

    public void setKaijoName(String kaijoName) {
        this.kaijoName = kaijoName;
    }

    public String getDate1() {
        return date1;
    }

    public void setDate2(String date2) {
        this.date2 = date2;
    }

    public String getDate2() {
        return date2;
    }

    public String getKaijoName() {
        return kaijoName;
    }

    public String getKaijoJusho() {
        return kaijoJusho;
    }

    public void setKaijoJusho(String kaijoJusho) {
        this.kaijoJusho = kaijoJusho;
    }

    public String getKuusekiSuu() {
        return kuusekiSuu;
    }

    public String getDaiichiKibo() {
        return daiichiKibo;
    }

    public void setKuusekiSuu(String kuusekiSuu) {
        this.kuusekiSuu = kuusekiSuu;
    }

    public void setDaiichiKibo(String daiichiKibo) {
        this.daiichiKibo = daiichiKibo;
    }

    public String getDainiKibo() {
        return dainiKibo;
    }

    public void setDainiKibo(String dainiKibo) {
        this.dainiKibo = dainiKibo;
    }

}
