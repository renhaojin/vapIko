//package jp.co.nii.bma.integration;
//
//import java.sql.Connection;
//import java.sql.PreparedStatement;
//import java.sql.ResultSet;
//import java.sql.SQLException;
//import java.util.ArrayList;
//import java.util.List;
//import jp.co.nii.bma.business.domain.KaijoDao;
//import jp.co.nii.bma.business.service.common.BmaConstants;
//import jp.co.nii.bma.presentation.moshikomi.KaijoOption;
//import jp.co.nii.sew.common.LogGenerate;
//import jp.co.nii.sew.integration.SQLStateSQLExceptionTranslater;
//
///**
// * ��� DAO�����N���X
// *
// * @author DB�Ǘ��c�[��
// */
//public class KaijoDaoImpl extends GeneratedKaijoDaoImpl implements KaijoDao {
//
//    /**
//     * �C���X�^���X�𐶐�����B
//     *
//     * @param datasource �f�[�^�\�[�X��
//     */
//    public KaijoDaoImpl(String datasource) {
//        super(datasource);
//    }
//
//    /**
//     * ���I�����X�g���擾����B
//     *
//     * @param nen �N
//     * @param shikenKbnCode �����敪�R�[�h
//     * @param todofukenCode �s���{���R�[�h
//     * @return ���Option���X�g
//     */
//    @Override
//    public List<KaijoOption> findKaijoOption(String nen, String shikenKbnCode, String todofukenCode, String shikenShuruiCode) {
//        Connection con = null;
//        PreparedStatement stmt = null;
//        ResultSet rs = null;
//        String sql = "";
//        KaijoOption bo;
//        String kaijo1;
//        String kaijoName1;
//        String kaijo2;
//        String kaijoName2;
//        boolean sentakuKanoFlg;
//        List<KaijoOption> ret = new ArrayList<KaijoOption>();
//        boolean isGakka = shikenKbnCode.equals(BmaConstants.SHIKEN_KBN_CODE_GAKKA);
//        try {
//            con = getConnection();
//            sql = "SELECT "
//                    + "  KAIJO1.KAIJO_CODE AS KAIJO_CODE1"
//                    + "  , KAIJO1.SHIKEN_KAIJO_NAME AS KAIJO_NAME1"
//                    + (isGakka
//                    ? "  , KAIJO2.KAIJO_CODE AS KAIJO_CODE2"
//                    + "  , KAIJO2.SHIKEN_KAIJO_NAME AS KAIJO_NAME2"
//                    : "")
//                    + "  , TO_NUMBER(TEIIN.GENZAI_NO,'9999999999') < TO_NUMBER(TEIIN.NO_JOGEN,'9999999999') AS SENTAKU_KANO_FLG "
//                    + " FROM "
//                    + getSchemaName() + "." + TABLE_NAME + " AS KAIJO1 "
//                    + "  INNER JOIN " + getSchemaName() + "." + SaibanDaoImpl.TABLE_NAME + " AS TEIIN "
//                    + "    ON KAIJO1.NEN = TEIIN.NEN "
//                    + "    AND ? || KAIJO1.KAIJO_CODE = TEIIN.NO_ID "
//                    + "    AND TEIIN.RONRI_SAKUJO_FLG = ? "
//                    + (isGakka
//                    ? "  INNER JOIN " + getSchemaName() + "." + TABLE_NAME + " AS KAIJO2 "
//                    + "    ON KAIJO1.NEN = KAIJO2.NEN "
//                    + "    AND KAIJO1.SEIZU_KAIJO_SHIKIBETSU_CODE = KAIJO2.KAIJO_CODE "
//                    + "    AND KAIJO2.RONRI_SAKUJO_FLG = ? "
//                    : "")
//                    + "WHERE"
//                    + "  KAIJO1.RONRI_SAKUJO_FLG = ? "
//                    + "  AND KAIJO1.NEN = ? "
//                    + "  AND KAIJO1.TODOFUKEN_CODE = ? "
//                    + "  AND KAIJO1.SHIKEN_KBN_CODE = ? "
//                    + "  AND SUBSTR(KAIJO1.KAIJO_CODE,1,1) = ? "
//                    + (!isGakka
//                    ? "  AND KAIJO1.SEKKEI_SEIZU_SENTAKU_KANO_FLG = ?"
//                    : "")
//                    + " ORDER BY KAIJO1.KAIJO_CODE"
//                    + (isGakka ? ", KAIJO2.KAIJO_CODE" : "");
//
//            stmt = con.prepareStatement(sql);
//            int i = 1;
//            stmt.setString(i++, BmaConstants.SAIBAN_NO_ID_SETTO_KAIJO_MOSHIKOMISU);
//            stmt.setString(i++, BmaConstants.FLG_OFF);
//            if (isGakka) {
//                stmt.setString(i++, BmaConstants.FLG_OFF);
//            }
//            stmt.setString(i++, BmaConstants.FLG_OFF);
//            stmt.setString(i++, nen);
//            stmt.setString(i++, todofukenCode);
//            stmt.setString(i++, shikenKbnCode);
//            stmt.setString(i++, shikenShuruiCode);
//            if (!isGakka) {
//                stmt.setString(i++, BmaConstants.SEKKEI_SEIZU_SENTAKU_KANO_FLG);
//            }
//
//            LogGenerate.debugOutput(getSql(stmt));
//            rs = stmt.executeQuery();
//            while (rs.next()) {
//                kaijo1 = rs.getString("KAIJO_CODE1");
//                kaijoName1 = rs.getString("KAIJO_NAME1");
//                kaijo2 = isGakka ? rs.getString("KAIJO_CODE2") : "";
//                kaijoName2 = isGakka ? rs.getString("KAIJO_NAME2") : "";
//                sentakuKanoFlg = rs.getBoolean("SENTAKU_KANO_FLG");
//                if (isGakka) {
//                    bo = new KaijoOption(kaijo1 + BmaConstants.KAIJO_CODE_SEPARATOR + kaijo2, kaijoName1, kaijoName2, sentakuKanoFlg);
//                } else {
//                    bo = new KaijoOption(kaijo1, kaijoName1, "", sentakuKanoFlg);
//                }
//                ret.add(bo);
//            }
//        } catch (SQLException ex) {
//            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
//        } finally {
//            close(con, stmt, rs);
//        }
//        return ret;
//    }
//
//    /**
//     * ���I�����X�g���擾����B
//     *
//     * �w�ȉ��E���}��ꂪ�ʁX�p
//     *
//     * @param nen �N
//     * @param shikenKbnCode �����敪�R�[�h
//     * @param todofukenCode �s���{���R�[�h
//     * @return ���Option���X�g
//     */
//    @Override
//    public List<KaijoOption> findKaijoOptionKobetsu(String nen, String shikenKbnCode, String todofukenCode, String shikenShuruiCode) {
//        Connection con = null;
//        PreparedStatement stmt = null;
//        ResultSet rs = null;
//        String sql = "";
//        KaijoOption bo;
//        String kaijo1;
//        String kaijoName1;
//        boolean sentakuKanoFlg;
//        boolean isGakka = BmaConstants.SHIKEN_KBN_CODE_GAKKA.equals(shikenKbnCode);
//        List<KaijoOption> ret = new ArrayList<KaijoOption>();
//        try {
//            con = getConnection();
//            sql = "SELECT "
//                    + "  KAIJO1.KAIJO_CODE AS KAIJO_CODE1"
//                    + "  , KAIJO1.SHIKEN_KAIJO_NAME AS KAIJO_NAME1"
//                    + "  , TO_NUMBER(TEIIN.GENZAI_NO,'9999999999') < TO_NUMBER(TEIIN.NO_JOGEN,'9999999999') AS SENTAKU_KANO_FLG "
//                    + " FROM "
//                    + getSchemaName() + "." + TABLE_NAME + " AS KAIJO1 "
//                    + "  INNER JOIN " + getSchemaName() + "." + SaibanDaoImpl.TABLE_NAME + " AS TEIIN "
//                    + "    ON KAIJO1.NEN = TEIIN.NEN "
//                    + "    AND ? || KAIJO1.KAIJO_CODE = TEIIN.NO_ID "
//                    + "    AND TEIIN.RONRI_SAKUJO_FLG = ? "
//                    + "WHERE"
//                    + "  KAIJO1.RONRI_SAKUJO_FLG = ? "
//                    + "  AND KAIJO1.NEN = ? "
//                    + "  AND KAIJO1.TODOFUKEN_CODE = ? "
//                    + "  AND KAIJO1.SHIKEN_KBN_CODE = ? "
//                    + "  AND SUBSTR(KAIJO1.KAIJO_CODE,1,1) = ? "
//                    + (!isGakka
//                    ? "  AND KAIJO1.SEKKEI_SEIZU_SENTAKU_KANO_FLG = ?"
//                    : "")
//                    + " ORDER BY KAIJO1.KAIJO_CODE";
//
//            stmt = con.prepareStatement(sql);
//            int i = 1;
//            stmt.setString(i++, BmaConstants.SAIBAN_NO_ID_SETTO_KAIJO_MOSHIKOMISU);
//            stmt.setString(i++, BmaConstants.FLG_OFF);
//            stmt.setString(i++, BmaConstants.FLG_OFF);
//            stmt.setString(i++, nen);
//            stmt.setString(i++, todofukenCode);
//            stmt.setString(i++, shikenKbnCode);
//            stmt.setString(i++, shikenShuruiCode);
//            if (!isGakka) {
//                stmt.setString(i++, BmaConstants.SEKKEI_SEIZU_SENTAKU_KANO_FLG);
//            }
//
//            LogGenerate.debugOutput(getSql(stmt));
//            rs = stmt.executeQuery();
//            while (rs.next()) {
//                kaijo1 = rs.getString("KAIJO_CODE1");
//                kaijoName1 = rs.getString("KAIJO_NAME1");
//                sentakuKanoFlg = rs.getBoolean("SENTAKU_KANO_FLG");
//                bo = new KaijoOption(kaijo1, kaijoName1, "", sentakuKanoFlg);
//                ret.add(bo);
//            }
//        } catch (SQLException ex) {
//            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
//        } finally {
//            close(con, stmt, rs);
//        }
//        return ret;
//    }
//}
