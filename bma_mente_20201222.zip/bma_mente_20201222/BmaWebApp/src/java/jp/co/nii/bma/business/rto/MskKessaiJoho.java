package jp.co.nii.bma.business.rto;

import java.util.ArrayList;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import jp.co.nii.bma.business.domain.HoyuShikakuMst;
import jp.co.nii.bma.business.domain.MeishoKanri;
import jp.co.nii.bma.business.domain.Moshikomi;
import jp.co.nii.bma.business.domain.Ryokin;
import jp.co.nii.bma.business.service.common.BmaConstants;
import jp.co.nii.bma.utility.BmaUtility;
import jp.co.nii.sew.presentation.AbstractRequestTransferObject;
import jp.co.nii.sew.presentation.Messages;
import jp.co.nii.sew.presentation.Option;

/**
 * �^�C�g��: ���Ϗ�� ����: ���Ϗ��RTO ���쌠: Copyright (c) 2020 ��Ж�: ���{���Y�Ɗ������
 */
public class MskKessaiJoho extends AbstractRequestTransferObject {
   /**
     * �t�����
     */
    private String hukaJoho;
    /**
     * ����R�[�h
     */
    private String torihikiCode;
    /**
     * �x�����
     */
    private String shiharaiJoho;
    /**
     * ���ϕ��@
     */
    private String kessaiHoho;
        
    private String shikenShuruiCode;
    private String shikenKbnCode;
    private String moshikomiUketsukeNo;
    private String kessaiSID;
    private String shiharaiKigen;
    private Messages errors;
    private String sknKsuName;
    private String shubetsuName;
    private String sknchiKaijo;
    private String sknchiKaijoJusho;
    private String mskDate;
    private String kessaiJokyo;
    private String jknJkuryo;
    private String systemRiyoryo;
    private String gokei;
    private String mskKigenbi;
    private String mskOshiharaibi;
    private String haraikomiDenpyoNo;
    private String goriyouConvenience;
    private String shiharaiKigenbi;
    private String syunokikanNo;
    private String userNo;
    private String mailKenmei;
    private String mailHonbun;
    private String mailFooter;
    private String kakuninNo;
    private String kessai;
    private String close;
    private String enter;
    private String nendo;
    private String uketsukeNo;
    private String soushinFlg;
    private String fuka;
    private String scrollPlace;
    private String mailTemplateIdx;
    private String kiboKaijoList;
    private String kessaiHohoNext;
    private String kessaiHohoBack;
    private String[] kessaiCodes;
    private String[] kessaiNames;
    private String kessaiJknJkuryo;
    private String kessaiJimutesuryo;
    private String kingaku;
    private String kessaiGokeiKingaku;
    private String kingakuKakuninBack;
    private String kingakuKakuninNext;
    private String kessaiSelectComplete;
    private String kessaiSelectMenjoBack;
    private String mskKakutei;
    private String sknKsuKbn;
    private String kaiinKbn;
    private String menjoCheck;
    private MeishoKanri meishoKanri;
    private List<Option> kessaiHohoList;
    private List<Ryokin> kessaiJknJkuryoList;
    private MskJoho mskJoho;
    private String sknKsuCode;
    private String shubetsuCode;
    private String kaisuCode;
    private String mskKbnSentaku;
    private String sknNaiyoKbn;
    private String genmenShinsei;
    private List<String> ryokinKbnList;
    private Ryokin ryokin;
    private String shikakuMeisho;
    private String shimeiSei;
    private String shimeiMei;
    private String furiganaSei;
    private String furiganaMei;
    private String yubinNo;
    private String telNo;
    private String jusho1;
    private String jusho2;
    private String mailAddress;
    private String shiharaKigen;
    private String uchizei;
    private String torokuDate;
    private String torokuTime;
    private String moshikomishaId;
    private String kessaiKakutei;
//    private String kessaihoho;
    private String ip;
    private String sid;
    private String n1;
    private String k1;
    private String kakutei;
    private String store;
    private String kigen;
    private String tax;
    private String okurl;
    private String rt;
    private String name1;
    private String name2;
    private String kana1;
    private String kana2;
    private String yubin1;
    private String yubin2;
    private String mail;
    private String adr1;
    private String kessaiComplete;
    //�u���ϑI�� (�Ə��Ώێ�)�v�Ɖ�ʁu���ϕ��@�I���v�ɑJ�ڂ���t���b�O
    private String kessaiSelectFlag;

    //�c��
    private int ninzu;
    private int gakaJitsugiGenmenNasiNinzu;
    private String gakaJitsugiGenmenNasiJknJkuryo;
    private String gakaJitsugiGenmenNasiGokei;
    private int gakaJitsugiGenmenNinzu;
    private String gakaJitsugiGenmenJknJkuryo;
    private String gakaJitsugiGenmenGokei;
    private int gakaOnlyNinzu;
    private String gakaOnlyJknJkuryo;
    private String gakaOnlyGokei;
    private int jitsugiOnlyGenmenNasiNinzu;
    private String jitsugiOnlyGenmenNasiJknJkuryo;
    private String jitsugiOnlyGenmenNasiGokei;
    private int jitsugiOnlyGenmenNinzu;
    private String jitsugiOnlyGenmenJknJkuryo;
    private String jitsugiOnlyGenmenGokei;
    private int gakaMenjoGenmenNasiNinzu;
    private String gakaMenjoGenmenNasiJknJkuryo;
    private String gakaMenjoGenmenNasiGokei;
    private int gakaMenjoGenmenNinzu;
    private String gakaMenjoGenmenJknJkuryo;
    private String gakaMenjoGenmenGokei;
    private int jitsugiMenjoNinzu;
    private String jitsugiMenjoJknJkuryo;
    private String jitsugiMenjoGokei;
    private int shokeiNinzu;
    private String shokeiGokei;
    private String tesuryoGokei;
    private int sumNinzu;
    private String sumNinzuGokei;
    private int moshikomishaNinzu;
    private String moshikomishaJknJkuryo;
    private String moshikomishaGokei;
    private int kyuseidoNinzu;
    private String kyuseidoJknJkuryo;
    private String kyuseidoGokei;
    private String kessaiHohoChi;
    private String torokuUserId;
    private List<Moshikomi> moshikomiListForInsert;
    private List<HoyuShikakuMst> hoyuShikakuMstMuryo;
    private HoyuShikakuMst hoyuShikakuMstForUpdate;

    //<editor-fold defaultstate="collapsed" desc="�R���X�g���N�^/������/���N�G�X�g�擾">
    /**
     * �R���X�g���N�^
     */
    public MskKessaiJoho() {
        clearInfo();
    }

    /**
     * ���������\�b�h
     */
    public void clearInfo() {
        setHukaJoho("");
        setTorihikiCode("");
        setShiharaiJoho("");
        
        setKessaiComplete("");
        setShikenShuruiCode("");
        setShikenKbnCode("");
        setMoshikomiUketsukeNo("");
        setKessaiSID("");
        setShiharaiKigen("");
        setNendo("");
        setUketsukeNo("");
        setMskKigenbi("");
        setMskOshiharaibi("");
        setErrors(new Messages());

        setSknKsuName("");
        setShubetsuName("");
        setKaisuCode("");
        //���Ϗ�����(�N���W�b�g)
        setSknchiKaijo("");
        setSknchiKaijoJusho("");
        setMskDate("");
        setKessaiJokyo("");
        setJknJkuryo("");
        setSystemRiyoryo("");
        setGokei("");
        setHaraikomiDenpyoNo("");
        setGoriyouConvenience("");
        setShiharaiKigenbi("");
        setSyunokikanNo("");
        setUserNo("");
        setKakuninNo("");
        setShikakuMeisho("");
        setShimeiSei("");
        setShimeiMei("");
        setFuriganaSei("");
        setFuriganaMei("");
        setYubinNo("");
        setTelNo("");
        setJusho1("");
        setJusho2("");
        setMailAddress("");
        setMailKenmei("");
        setMailHonbun("");
        setMailFooter("");
        setShiharaKigen("");
        setUchizei("");
        setTorokuDate("");
        setTorokuTime("");
        setMoshikomishaId("");
        setKessaiKakutei("");
        setSoushinFlg("");
        setMailTemplateIdx("");
        setFuka("");
        //�o�^��
        setClose("");
        setEnter("");
        setScrollPlace("");
        setKessaiHoho("");
        setKessaiHohoNext("");
        setKessaiHohoBack("");
        setKessai("");
        setMskKakutei("");
        setKingaku("");
        setKessaiJknJkuryo("");
        setKessaiJimutesuryo("");
        setKessaiGokeiKingaku("");
        setKingakuKakuninBack("");
        setKingakuKakuninNext("");
        setKessaiSelectComplete("");
        setKessaiSelectMenjoBack("");
        setKessaiHohoList(new ArrayList<Option>());
        setKessaiJknJkuryoList(new ArrayList<Ryokin>());

        setIp("");
        setSid("");
        setN1("");
        setK1("");
        setKakutei("");
        setStore("");
        setKigen("");
        setTax("");
        setOkurl("");
        setRt("");
        setName1("");
        setName2("");
        setKana1("");
        setKana2("");
        setYubin1("");
        setYubin2("");
        setMail("");
        setAdr1("");
        setSknKsuKbn("");
        setKaiinKbn("");
        setMenjoCheck("");

        //�c��
        setNinzu(0);
        setGakaJitsugiGenmenNasiNinzu(0);
        setGakaJitsugiGenmenNasiJknJkuryo("");
        setGakaJitsugiGenmenNasiGokei("");
        setGakaJitsugiGenmenNinzu(0);
        setGakaJitsugiGenmenJknJkuryo("");
        setGakaJitsugiGenmenGokei("");
        setGakaOnlyNinzu(0);
        setGakaOnlyJknJkuryo("");
        setGakaOnlyGokei("");
        setJitsugiOnlyGenmenNasiNinzu(0);
        setJitsugiOnlyGenmenNasiJknJkuryo("");
        setJitsugiOnlyGenmenNasiGokei("");
        setJitsugiOnlyGenmenNinzu(0);
        setJitsugiOnlyGenmenJknJkuryo("");
        setJitsugiOnlyGenmenGokei("");
        setGakaMenjoGenmenNasiNinzu(0);
        setGakaMenjoGenmenNasiJknJkuryo("");
        setGakaMenjoGenmenNasiGokei("");
        setGakaMenjoGenmenNinzu(0);
        setGakaMenjoGenmenJknJkuryo("");
        setGakaMenjoGenmenGokei("");
        setJitsugiMenjoNinzu(0);
        setJitsugiMenjoJknJkuryo("");
        setJitsugiMenjoGokei("");
        setShokeiNinzu(0);
        setShokeiGokei("");
        setTesuryoGokei("");
        setSumNinzu(0);
        setSumNinzuGokei("");
        setMoshikomishaNinzu(0);
        setMoshikomishaJknJkuryo("");
        setMoshikomishaGokei("");
        setKyuseidoNinzu(0);
        setKyuseidoJknJkuryo("");
        setKyuseidoGokei("");
        setKessaiHohoChi("");
        setTorokuUserId("");
        setMoshikomiListForInsert(new ArrayList<>());
        setHoyuShikakuMstMuryo(new ArrayList<>());
        setHoyuShikakuMstForUpdate(new HoyuShikakuMst());
    }

    /**
     * ���N�G�X�g��������擾���郁�\�b�h
     *
     * @param request ���N�G�X�g
     */
    @Override
    public void copyFromRequest(HttpServletRequest request) {
        setKessaiComplete((String) request.getAttribute("kessaiComplete"));
        setTorihikiCode((String) request.getAttribute("SID"));
        setHukaJoho((String) request.getAttribute("FUKA"));
        setKessaiHoho((String) request.getAttribute("kessaiHoho"));
        setSknKsuName((String) request.getAttribute("sknKsuName"));
        setShubetsuName((String) request.getAttribute("shubetsuName"));
        setMskKigenbi((String) request.getAttribute("mskKigenbi"));
        setMskOshiharaibi((String) request.getAttribute("mskOshiharaibi"));
        //���Ϗ�����(�N���W�b�g)
        setSknchiKaijo((String) request.getAttribute("sknchiKaijo"));
        setSknchiKaijoJusho((String) request.getAttribute("sknchiKaijoJusho"));
        setMskDate((String) request.getAttribute("mskDate"));
        setKessaiJokyo((String) request.getAttribute("kessaiJokyo"));
        setJknJkuryo((String) request.getAttribute("jknJkuryo"));
        setSystemRiyoryo((String) request.getAttribute("systemRiyoryo"));
        setGokei((String) request.getAttribute("gokei"));
        setHaraikomiDenpyoNo((String) request.getAttribute("haraikomiDenpyoNo"));
        setGoriyouConvenience((String) request.getAttribute("goriyouConvenience"));
        setShiharaiKigenbi((String) request.getAttribute("shiharaiKigenbi"));
        setSyunokikanNo((String) request.getAttribute("syunokikanNo"));
        setUserNo((String) request.getAttribute("userNo"));
        setKakuninNo((String) request.getAttribute("kakuninNo"));
        setKessaiKakutei((String) request.getAttribute("kessaiKakutei"));
        setMailKenmei((String) request.getAttribute("mailKenmei"));
        setMailHonbun((String) request.getAttribute("mailHonbun"));
        setMailFooter((String) request.getAttribute("mailFooter"));
        //�o�^��
        setClose((String) request.getAttribute("close"));
        setEnter((String) request.getAttribute("enter"));
        setSoushinFlg((String) request.getAttribute("soushinFlg"));
        setMailTemplateIdx((String) request.getAttribute("mailTemplateIdx"));
        setScrollPlace((String) request.getAttribute("scrollPlace"));
        setKessaiHohoNext((String) request.getAttribute("kessaiHohoNext"));
        setKessaiHohoBack((String) request.getAttribute("kessaiHohoBack"));
        setKessai((String) request.getAttribute("kessai"));
        setKessaiSelectComplete((String) request.getAttribute("kessaiSelectComplete"));
        setKessaiSelectMenjoBack((String) request.getAttribute("kessaiSelectMenjoBack"));
        setKessaiJknJkuryo((String) request.getAttribute("kessaiJknJkuryo"));
        setKessaiJimutesuryo((String) request.getAttribute("kessaiJimutesuryo"));
        setKessaiGokeiKingaku((String) request.getAttribute("kessaiGokeiKingaku"));
        setKingakuKakuninBack((String) request.getAttribute("kingakuKakuninBack"));
        setKingakuKakuninNext((String) request.getAttribute("kingakuKakuninNext"));
        setMskKakutei((String) request.getAttribute("mskKakutei"));
        setMeishoKanri((MeishoKanri) request.getAttribute("meishoKanri"));
        setRyokin((Ryokin) request.getAttribute("ryokin"));
        setNendo((String) request.getAttribute("nendo"));
        HttpSession session = request.getSession(false);
        if (session != null && session.getAttribute("MskJoho") != null) {
            MskJoho temp = (MskJoho) session.getAttribute("MskJoho");
            setSknKsuCode(temp.getSknKsuCode());
            setUketsukeNo(temp.getUketsukeNo());
            setMoshikomiUketsukeNo(temp.getUketsukeNo());
            setShubetsuCode(temp.getShubetsuCode());
            setKaisuCode(temp.getKaisuCode());
            setNendo(temp.getNendo());
            setMskKbnSentaku(temp.getMskKbnSentaku());
            setGenmenShinsei(temp.getGenmenShinsei());
            if (!temp.getShimei().equals("")) {
                setShimeiSei(temp.getShimei().replaceAll("�@", " ").split(" ")[0]);
                setShimeiMei(temp.getShimei().replaceAll("�@", " ").split(" ")[1]);
            }
            if (!temp.getFurigana().equals("")) {
                setFuriganaSei(temp.getFurigana().replaceAll("�@", " ").split(" ")[0]);
                setFuriganaMei(temp.getFurigana().replaceAll("�@", " ").split(" ")[1]);
            }
            setYubinNo(temp.getYubinNoFront() + temp.getYubinNoBack());
            setTelNo(temp.getTelNo());
            setJusho1(temp.getJusho1());
            setJusho2(temp.getJusho2());
            setMailAddress(temp.getMailAddress());
            setUchizei("");
            setMoshikomishaId(temp.getMoshikomishaId());
            setKessaiSelectFlag(temp.getKessaiSelectFlag());
            if (temp.getSknKsuKbn().equals(BmaConstants.SKN_KBN)) {
                setSknchiKaijo(temp.getKiboJissiChiku());
            }
            setSknKsuKbn(temp.getSknKsuKbn());
            setKaiinKbn(temp.getKaiinKbn());
            setMenjoCheck(temp.getMenjoCheck());
        }
        if (session != null && session.getAttribute("MskSikakuJoho") != null) {
            MskSikakuJoho temp = (MskSikakuJoho) session.getAttribute("MskSikakuJoho");
            setSknNaiyoKbn(temp.getSknNaiyoKbn());
            setHoyuShikakuMstForUpdate(temp.getHoyuShikakuMstForUpdate());
        }
        if (session != null && session.getAttribute("MskKsuJoho") != null) {
            MskKsuJoho temp = (MskKsuJoho) session.getAttribute("MskKsuJoho");
            if (BmaConstants.KSU_KBN.equals(getSknKsuKbn()) && !temp.getKiboKaijoList().isEmpty()) {
                setSknchiKaijo(temp.getKiboKaijoList().get(0).getKaijoName());
                setSknchiKaijoJusho(temp.getKiboKaijoList().get(0).getKaijoJusho());
            }
        }
        // �N�x�擾
        if (session != null && session.getAttribute("MskSknJoho") != null) {
            MskSknJoho mskSknJoho = (MskSknJoho) session.getAttribute("MskSknJoho");
            setNendo(mskSknJoho.getNendo());
        }
        if (session != null && session.getAttribute("TopJoho") != null) {
            TopJoho temp = (TopJoho) session.getAttribute("TopJoho");
        }
        if (session != null && session.getAttribute("MskUploadJoho") != null) {
            MskUploadJoho temp = (MskUploadJoho) session.getAttribute("MskUploadJoho");
            setTorokuUserId(temp.getTorokuUserId());
            setTorokuDate(temp.getTorokuDate());
            setTorokuTime(temp.getTorokuTime());
            setMoshikomiListForInsert(temp.getMoshikomiListForInsert());
            setHoyuShikakuMstMuryo(temp.getHoyuShikakuMstMuryo());
        }
        setGakaJitsugiGenmenNasiJknJkuryo((String) request.getAttribute("gakaJitsugiGenmenNasiJknJkuryo"));
        setGakaJitsugiGenmenNasiGokei((String) request.getAttribute("gakaJitsugiGenmenNasiGokei"));
        setGakaJitsugiGenmenJknJkuryo((String) request.getAttribute("gakaJitsugiGenmenJknJkuryo"));
        setGakaJitsugiGenmenGokei((String) request.getAttribute("gakaJitsugiGenmenGokei"));
        setGakaOnlyJknJkuryo((String) request.getAttribute("gakaOnlyJknJkuryo"));
        setGakaOnlyGokei((String) request.getAttribute("gakaOnlyGokei"));
        setJitsugiOnlyGenmenNasiJknJkuryo((String) request.getAttribute("jitsugiOnlyGenmenNasiJknJkuryo"));
        setJitsugiOnlyGenmenNasiGokei((String) request.getAttribute("jitsugiOnlyGenmenNasiGokei"));
        setJitsugiOnlyGenmenJknJkuryo((String) request.getAttribute("jitsugiOnlyGenmenJknJkuryo"));
        setJitsugiOnlyGenmenGokei((String) request.getAttribute("jitsugiOnlyGenmenGokei"));
        setGakaMenjoGenmenNasiJknJkuryo((String) request.getAttribute("gakaMenjoGenmenNasiJknJkuryo"));
        setGakaMenjoGenmenNasiGokei((String) request.getAttribute("gakaMenjoGenmenNasiGokei"));
        setGakaMenjoGenmenJknJkuryo((String) request.getAttribute("gakaMenjoGenmenJknJkuryo"));
        setGakaMenjoGenmenGokei((String) request.getAttribute("gakaMenjoGenmenGokei"));
        setJitsugiMenjoJknJkuryo((String) request.getAttribute("jitsugiMenjoJknJkuryo"));
        setJitsugiMenjoGokei((String) request.getAttribute("jitsugiMenjoGokei"));
        setShokeiGokei((String) request.getAttribute("shokeiGokei"));
        setTesuryoGokei((String) request.getAttribute("tesuryoGokei"));
        setSumNinzuGokei((String) request.getAttribute("sumNinzuGokei"));
        setMoshikomishaJknJkuryo((String) request.getAttribute("moshikomishaJknJkuryo"));
        setMoshikomishaGokei((String) request.getAttribute("moshikomishaGokei"));
        setKyuseidoJknJkuryo((String) request.getAttribute("kyuseidoJknJkuryo"));
        setKyuseidoGokei((String) request.getAttribute("kyuseidoGokei"));
        setKessaiHohoChi((String) request.getAttribute("kessaiHohoChi"));
    }
    //</editor-fold>

    //<editor-fold defaultstate="collapsed" desc="�Q�b�^�[/�Z�b�^�[">
    /**
     * ������ރR�[�h
     *
     * @return the shikenShuruiCode
     */
    public String getShikenShuruiCode() {
        return shikenShuruiCode;
    }

    /**
     * ������ރR�[�h
     *
     * @param shikenShuruiCode the shikenShuruiCode to set
     */
    public void setShikenShuruiCode(String shikenShuruiCode) {
        this.shikenShuruiCode = shikenShuruiCode;
    }

    /**
     * �����敪�R�[�h
     *
     * @return the shikenKbnCode
     */
    public String getShikenKbnCode() {
        return shikenKbnCode;
    }

    /**
     * �����敪�R�[�h
     *
     * @param shikenKbnCode the shikenKbnCode to set
     */
    public void setShikenKbnCode(String shikenKbnCode) {
        this.shikenKbnCode = shikenKbnCode;
    }

    /**
     * �\����t�ԍ�
     *
     * @return the moshikomiUketsukeNo
     */
    public String getMoshikomiUketsukeNo() {
        return moshikomiUketsukeNo;
    }

    /**
     * �\����t�ԍ�
     *
     * @param moshikomiUketsukeNo the moshikomiUketsukeNo to set
     */
    public void setMoshikomiUketsukeNo(String moshikomiUketsukeNo) {
        this.moshikomiUketsukeNo = moshikomiUketsukeNo;
    }

    /**
     * ����SID
     *
     * @return the kessaiSID
     */
    public String getKessaiSID() {
        return kessaiSID;
    }

    /**
     * ����SID
     *
     * @param kessaiSID the kessaiSID to set
     */
    public void setKessaiSID(String kessaiSID) {
        this.kessaiSID = kessaiSID;
    }

    /**
     * �x����������
     *
     * @return the shiharaiKigen
     */
    public String getShiharaiKigen() {
        return shiharaiKigen;
    }

    /**
     * �x����������
     *
     * @param shiharaiKigen the shiharaiKigen to set
     */
    public void setShiharaiKigen(String shiharaiKigen) {
        this.shiharaiKigen = shiharaiKigen;
    }

    /**
     * �x�����������擾
     *
     * @return �x����������
     */
    public String getShiharaiKigenMonth() {
        if (BmaUtility.isNullOrEmpty(this.shiharaiKigen) || this.shiharaiKigen.length() < 8) {
            return "";
        }
        return this.shiharaiKigen.substring(4, 6).replaceFirst("^0+", "");
    }

    /**
     * �x�����������擾
     *
     * @return �x����������
     */
    public String getShiharaiKigenDay() {
        if (BmaUtility.isNullOrEmpty(this.shiharaiKigen) || this.shiharaiKigen.length() < 8) {
            return "";
        }
        return this.shiharaiKigen.substring(6, 8).replaceFirst("^0+", "");
    }

    public String getMskDate() {
        return mskDate;
    }

    public void setMskDate(String mskDate) {
        this.mskDate = mskDate;
    }

    public String getKessaiJokyo() {
        return kessaiJokyo;
    }

    public void setKessaiJokyo(String kessaiJokyo) {
        this.kessaiJokyo = kessaiJokyo;
    }

    public String getSystemRiyoryo() {
        return systemRiyoryo;
    }

    public void setSystemRiyoryo(String systemRiyoryo) {
        this.systemRiyoryo = systemRiyoryo;
    }

    public String getGokei() {
        return gokei;
    }

    public void setGokei(String gokei) {
        this.gokei = gokei;
    }

    public String getClose() {
        return close;
    }

    public void setClose(String close) {
        this.close = close;
    }

    public String getEnter() {
        return enter;
    }

    public void setEnter(String enter) {
        this.enter = enter;
    }

    public Messages getErrors() {
        return errors;
    }

    public void setErrors(Messages errors) {
        this.errors = errors;
    }

    public String getSknKsuName() {
        return sknKsuName;
    }

    public void setSknKsuName(String sknKsuName) {
        this.sknKsuName = sknKsuName;
    }

    public String getShubetsuName() {
        return shubetsuName;
    }

    public void setShubetsuName(String shubetsuName) {
        this.shubetsuName = shubetsuName;
    }

    public String getHaraikomiDenpyoNo() {
        return haraikomiDenpyoNo;
    }

    public void setHaraikomiDenpyoNo(String haraikomiDenpyoNo) {
        this.haraikomiDenpyoNo = haraikomiDenpyoNo;
    }

    public String getGoriyouConvenience() {
        return goriyouConvenience;
    }

    public void setGoriyouConvenience(String goriyouConvenience) {
        this.goriyouConvenience = goriyouConvenience;
    }

    public String getShiharaiKigenbi() {
        return shiharaiKigenbi;
    }

    public void setShiharaiKigenbi(String shiharaiKigenbi) {
        this.shiharaiKigenbi = shiharaiKigenbi;
    }

    public String getSyunokikanNo() {
        return syunokikanNo;
    }

    public void setSyunokikanNo(String syunokikanNo) {
        this.syunokikanNo = syunokikanNo;
    }

    public String getUserNo() {
        return userNo;
    }

    public void setUserNo(String userNo) {
        this.userNo = userNo;
    }

    public String getKakuninNo() {
        return kakuninNo;
    }

    public void setKakuninNo(String kakuninNo) {
        this.kakuninNo = kakuninNo;
    }

    /**
     * @return the scrollPlace
     */
    public String getScrollPlace() {
        return scrollPlace;
    }

    /**
     * @param scrollPlace the scrollPlace to set
     */
    public void setScrollPlace(String scrollPlace) {
        this.scrollPlace = scrollPlace;
    }

    /**
     * @return the kessaiHoho
     */
    public String getKessaiHoho() {
        return kessaiHoho;
    }

    /**
     * @param kessaiHoho the kessaiHoho to set
     */
    public void setKessaiHoho(String kessaiHoho) {
        this.kessaiHoho = kessaiHoho;
    }

    /**
     * @return the kessaiHohoNext
     */
    public String getKessaiHohoNext() {
        return kessaiHohoNext;
    }

    /**
     * @param kessaiHohoNext the kessaiHohoNext to set
     */
    public void setKessaiHohoNext(String kessaiHohoNext) {
        this.kessaiHohoNext = kessaiHohoNext;
    }

    /**
     * @return the kessai
     */
    public String getKessai() {
        return kessai;
    }

    /**
     * @param kessai the kessai to set
     */
    public void setKessai(String kessai) {
        this.kessai = kessai;
    }

    /**
     * @return the kessaiCodes
     */
    public String[] getKessaiCodes() {
        return kessaiCodes;
    }

    /**
     * @param kessaiCodes the kessaiCodes to set
     */
    public void setKessaiCodes(String[] kessaiCodes) {
        this.kessaiCodes = kessaiCodes;
    }

    /**
     * @return the kessaiNames
     */
    public String[] getKessaiNames() {
        return kessaiNames;
    }

    /**
     * @param kessaiNames the kessaiNames to set
     */
    public void setKessaiNames(String[] kessaiNames) {
        this.kessaiNames = kessaiNames;
    }

    /**
     * @return the kessaiJknJkuryo
     */
    public String getKessaiJknJkuryo() {
        return kessaiJknJkuryo;
    }

    /**
     * @param kessaiJknJkuryo the kessaiJknJkuryo to set
     */
    public void setKessaiJknJkuryo(String kessaiJknJkuryo) {
        this.kessaiJknJkuryo = kessaiJknJkuryo;
    }

    /**
     * @return the kessaiJimutesuryo
     */
    public String getKessaiJimutesuryo() {
        return kessaiJimutesuryo;
    }

    /**
     * @param kessaiJimutesuryo the kessaiJimutesuryo to set
     */
    public void setKessaiJimutesuryo(String kessaiJimutesuryo) {
        this.kessaiJimutesuryo = kessaiJimutesuryo;
    }

    /**
     * @return the kessaiGokeiKingaku
     */
    public String getKessaiGokeiKingaku() {
        return kessaiGokeiKingaku;
    }

    /**
     * @param kessaiGokeiKingaku the kessaiGokeiKingaku to set
     */
    public void setKessaiGokeiKingaku(String kessaiGokeiKingaku) {
        this.kessaiGokeiKingaku = kessaiGokeiKingaku;
    }

    /**
     * @return the kingakuKakuninBack
     */
    public String getKingakuKakuninBack() {
        return kingakuKakuninBack;
    }

    /**
     * @param kingakuKakuninBack the kingakuKakuninBack to set
     */
    public void setKingakuKakuninBack(String kingakuKakuninBack) {
        this.kingakuKakuninBack = kingakuKakuninBack;
    }

    /**
     * @return the kingakuKakuninNext
     */
    public String getKingakuKakuninNext() {
        return kingakuKakuninNext;
    }

    /**
     * @param kingakuKakuninNext the kingakuKakuninNext to set
     */
    public void setKingakuKakuninNext(String kingakuKakuninNext) {
        this.kingakuKakuninNext = kingakuKakuninNext;
    }

    /**
     * @return the kessaiHohoBack
     */
    public String getKessaiHohoBack() {
        return kessaiHohoBack;
    }

    /**
     * @param kessaiHohoBack the kessaiHohoBack to set
     */
    public void setKessaiHohoBack(String kessaiHohoBack) {
        this.kessaiHohoBack = kessaiHohoBack;
    }

    public String getSknchiKaijo() {
        return sknchiKaijo;
    }

    public void setSknchiKaijo(String sknchiKaijo) {
        this.sknchiKaijo = sknchiKaijo;
    }

    public String getSknchiKaijoJusho() {
        return sknchiKaijoJusho;
    }

    public void setSknchiKaijoJusho(String sknchiKaijoJusho) {
        this.sknchiKaijoJusho = sknchiKaijoJusho;
    }

    public String getJknJkuryo() {
        return jknJkuryo;
    }

    public void setJknJkuryo(String jknJkuryo) {
        this.jknJkuryo = jknJkuryo;
    }

    /**
     * @return the mskKakutei
     */
    public String getMskKakutei() {
        return mskKakutei;
    }

    /**
     * @param mskKakutei the mskKakutei to set
     */
    public void setMskKakutei(String mskKakutei) {
        this.mskKakutei = mskKakutei;
    }

    /**
     * ���ϕ��@���X�g
     *
     * @return the kessaiHohoList
     */
    public List<Option> getKessaiHohoList() {
        return kessaiHohoList;
    }

    /**
     * ���ϕ��@���X�g
     *
     * @param kessaiHohoList the kessaiHohoList to set
     */
    public void setKessaiHohoList(List<Option> kessaiHohoList) {
        this.kessaiHohoList = kessaiHohoList;
    }

    /**
     * �������X�g
     *
     * @return the kessaiJknJkuryoList
     */
    public List<Ryokin> getKessaiJknJkuryoList() {
        return kessaiJknJkuryoList;
    }

    /**
     * �������X�g
     *
     * @param kessaiJknJkuryoList the kessaiJknJkuryoList to set
     */
    public void setKessaiJknJkuryoList(List<Ryokin> kessaiJknJkuryoList) {
        this.kessaiJknJkuryoList = kessaiJknJkuryoList;
    }

    /**
     * @return the meishoKanri
     */
    public MeishoKanri getMeishoKanri() {
        return meishoKanri;
    }

    /**
     * @param meishoKanri the meishoKanri to set
     */
    public void setMeishoKanri(MeishoKanri meishoKanri) {
        this.meishoKanri = meishoKanri;
    }

    /**
     * @return the sknKsuCode
     */
    public String getSknKsuCode() {
        return sknKsuCode;
    }

    /**
     * @param sknKsuCode the sknKsuCode to set
     */
    public void setSknKsuCode(String sknKsuCode) {
        this.sknKsuCode = sknKsuCode;
    }

    /**
     * @return the shubetsuCode
     */
    public String getShubetsuCode() {
        return shubetsuCode;
    }

    /**
     * @param shubetsuCode the shubetsuCode to set
     */
    public void setShubetsuCode(String shubetsuCode) {
        this.shubetsuCode = shubetsuCode;
    }

    /**
     * @return the mskKbnSentaku
     */
    public String getMskKbnSentaku() {
        return mskKbnSentaku;
    }

    /**
     * @param mskKbnSentaku the mskKbnSentaku to set
     */
    public void setMskKbnSentaku(String mskKbnSentaku) {
        this.mskKbnSentaku = mskKbnSentaku;
    }

    /**
     * @return the sknNaiyoKbn
     */
    public String getSknNaiyoKbn() {
        return sknNaiyoKbn;
    }

    /**
     * @param sknNaiyoKbn the sknNaiyoKbn to set
     */
    public void setSknNaiyoKbn(String sknNaiyoKbn) {
        this.sknNaiyoKbn = sknNaiyoKbn;
    }

    /**
     * @return the genmenShinsei
     */
    public String getGenmenShinsei() {
        return genmenShinsei;
    }

    /**
     * @param genmenShinsei the genmenShinsei to set
     */
    public void setGenmenShinsei(String genmenShinsei) {
        this.genmenShinsei = genmenShinsei;
    }

    /**
     * @return the mskJoho
     */
    public MskJoho getMskJoho() {
        return mskJoho;
    }

    /**
     * @param mskJoho the mskJoho to set
     */
    public void setMskJoho(MskJoho mskJoho) {
        this.mskJoho = mskJoho;
    }

    /**
     * @return the ryokin
     */
    public Ryokin getRyokin() {
        return ryokin;
    }

    /**
     * @param ryokin the ryokin to set
     */
    public void setRyokin(Ryokin ryokin) {
        this.ryokin = ryokin;
    }

    /**
     * @return the ryokinKbnList
     */
    public List<String> getRyokinKbnList() {
        return ryokinKbnList;
    }

    /**
     * @param ryokinKbnList the ryokinKbnList to set
     */
    public void setRyokinKbnList(List<String> ryokinKbnList) {
        this.ryokinKbnList = ryokinKbnList;
    }

    /**
     * @return the kingaku
     */
    public String getKingaku() {
        return kingaku;
    }

    /**
     * @param kingaku the kingaku to set
     */
    public void setKingaku(String kingaku) {
        this.kingaku = kingaku;
    }

    /**
     * @return the shikakuMeisho
     */
    public String getShikakuMeisho() {
        return shikakuMeisho;
    }

    /**
     * @param shikakuMeisho the shikakuMeisho to set
     */
    public void setShikakuMeisho(String shikakuMeisho) {
        this.shikakuMeisho = shikakuMeisho;
    }

    /**
     * @return the shimeiSei
     */
    public String getShimeiSei() {
        return shimeiSei;
    }

    /**
     * @param shimeiSei the shimeiSei to set
     */
    public void setShimeiSei(String shimeiSei) {
        this.shimeiSei = shimeiSei;
    }

    /**
     * @return the shimeiMei
     */
    public String getShimeiMei() {
        return shimeiMei;
    }

    /**
     * @param shimeiMei the shimeiMei to set
     */
    public void setShimeiMei(String shimeiMei) {
        this.shimeiMei = shimeiMei;
    }

    /**
     * @return the furiganaSei
     */
    public String getFuriganaSei() {
        return furiganaSei;
    }

    /**
     * @param furiganaSei the furiganaSei to set
     */
    public void setFuriganaSei(String furiganaSei) {
        this.furiganaSei = furiganaSei;
    }

    /**
     * @return the furiganaMei
     */
    public String getFuriganaMei() {
        return furiganaMei;
    }

    /**
     * @param furiganaMei the furiganaMei to set
     */
    public void setFuriganaMei(String furiganaMei) {
        this.furiganaMei = furiganaMei;
    }

    /**
     * @return the yubinNo
     */
    public String getYubinNo() {
        return yubinNo;
    }

    /**
     * @param yubinNo the yubinNo to set
     */
    public void setYubinNo(String yubinNo) {
        this.yubinNo = yubinNo;
    }

    /**
     * @return the telNo
     */
    public String getTelNo() {
        return telNo;
    }

    /**
     * @param telNo the telNo to set
     */
    public void setTelNo(String telNo) {
        this.telNo = telNo;
    }

    /**
     * @return the jusho1
     */
    public String getJusho1() {
        return jusho1;
    }

    /**
     * @param jusho1 the jusho1 to set
     */
    public void setJusho1(String jusho1) {
        this.jusho1 = jusho1;
    }

    /**
     * @return the jusho2
     */
    public String getJusho2() {
        return jusho2;
    }

    /**
     * @param jusho2 the jusho2 to set
     */
    public void setJusho2(String jusho2) {
        this.jusho2 = jusho2;
    }

    /**
     * @return the mailAddress
     */
    public String getMailAddress() {
        return mailAddress;
    }

    /**
     * @param mailAddress the mailAddress to set
     */
    public void setMailAddress(String mailAddress) {
        this.mailAddress = mailAddress;
    }

    /**
     * @return the shiharaKigen
     */
    public String getShiharaKigen() {
        return shiharaKigen;
    }

    /**
     * @param shiharaKigen the shiharaKigen to set
     */
    public void setShiharaKigen(String shiharaKigen) {
        this.shiharaKigen = shiharaKigen;
    }

    /**
     * @return the uchizei
     */
    public String getUchizei() {
        return uchizei;
    }

    /**
     * @param uchizei the uchizei to set
     */
    public void setUchizei(String uchizei) {
        this.uchizei = uchizei;
    }

    /**
     * @return the torokuDate
     */
    public String getTorokuDate() {
        return torokuDate;
    }

    /**
     * @param torokuDate the torokuDate to set
     */
    public void setTorokuDate(String torokuDate) {
        this.torokuDate = torokuDate;
    }

    /**
     * @return the torokuTime
     */
    public String getTorokuTime() {
        return torokuTime;
    }

    /**
     * @param torokuTime the torokuTime to set
     */
    public void setTorokuTime(String torokuTime) {
        this.torokuTime = torokuTime;
    }

    /**
     * @return the moshikomishaId
     */
    public String getMoshikomishaId() {
        return moshikomishaId;
    }

    /**
     * @param moshikomishaId the moshikomishaId to set
     */
    public void setMoshikomishaId(String moshikomishaId) {
        this.moshikomishaId = moshikomishaId;
    }

    /**
     * @return the kaisuCode
     */
    public String getKaisuCode() {
        return kaisuCode;
    }

    /**
     * @param kaisuCode the kaisuCode to set
     */
    public void setKaisuCode(String kaisuCode) {
        this.kaisuCode = kaisuCode;
    }

    /**
     * @return the kessaiKakutei
     */
    public String getKessaiKakutei() {
        return kessaiKakutei;
    }

    /**
     * @param kessaiKakutei the kessaiKakutei to set
     */
    public void setKessaiKakutei(String kessaiKakutei) {
        this.kessaiKakutei = kessaiKakutei;
    }

    /**
     * @return the ip
     */
    public String getIp() {
        return ip;
    }

    /**
     * @param ip the ip to set
     */
    public void setIp(String ip) {
        this.ip = ip;
    }

    /**
     * @return the sid
     */
    public String getSid() {
        return sid;
    }

    /**
     * @param sid the sid to set
     */
    public void setSid(String sid) {
        this.sid = sid;
    }

    /**
     * @return the n1
     */
    public String getN1() {
        return n1;
    }

    /**
     * @param n1 the n1 to set
     */
    public void setN1(String n1) {
        this.n1 = n1;
    }

    /**
     * @return the k1
     */
    public String getK1() {
        return k1;
    }

    /**
     * @param k1 the k1 to set
     */
    public void setK1(String k1) {
        this.k1 = k1;
    }

    /**
     * @return the kakutei
     */
    public String getKakutei() {
        return kakutei;
    }

    /**
     * @param kakutei the kakutei to set
     */
    public void setKakutei(String kakutei) {
        this.kakutei = kakutei;
    }

    /**
     * @return the store
     */
    public String getStore() {
        return store;
    }

    /**
     * @param store the store to set
     */
    public void setStore(String store) {
        this.store = store;
    }

    /**
     * @return the kigen
     */
    public String getKigen() {
        return kigen;
    }

    /**
     * @param kigen the kigen to set
     */
    public void setKigen(String kigen) {
        this.kigen = kigen;
    }

    /**
     * @return the tax
     */
    public String getTax() {
        return tax;
    }

    /**
     * @param tax the tax to set
     */
    public void setTax(String tax) {
        this.tax = tax;
    }

    /**
     * @return the okurl
     */
    public String getOkurl() {
        return okurl;
    }

    /**
     * @param okurl the okurl to set
     */
    public void setOkurl(String okurl) {
        this.okurl = okurl;
    }

    /**
     * @return the rt
     */
    public String getRt() {
        return rt;
    }

    /**
     * @param rt the rt to set
     */
    public void setRt(String rt) {
        this.rt = rt;
    }

    /**
     * @return the name1
     */
    public String getName1() {
        return name1;
    }

    /**
     * @param name1 the name1 to set
     */
    public void setName1(String name1) {
        this.name1 = name1;
    }

    /**
     * @return the name2
     */
    public String getName2() {
        return name2;
    }

    /**
     * @param name2 the name2 to set
     */
    public void setName2(String name2) {
        this.name2 = name2;
    }

    /**
     * @return the kana1
     */
    public String getKana1() {
        return kana1;
    }

    /**
     * @param kana1 the kana1 to set
     */
    public void setKana1(String kana1) {
        this.kana1 = kana1;
    }

    /**
     * @return the kana2
     */
    public String getKana2() {
        return kana2;
    }

    /**
     * @param kana2 the kana2 to set
     */
    public void setKana2(String kana2) {
        this.kana2 = kana2;
    }

    /**
     * @return the yubin1
     */
    public String getYubin1() {
        return yubin1;
    }

    /**
     * @param yubin1 the yubin1 to set
     */
    public void setYubin1(String yubin1) {
        this.yubin1 = yubin1;
    }

    /**
     * @return the yubin2
     */
    public String getYubin2() {
        return yubin2;
    }

    /**
     * @param yubin2 the yubin2 to set
     */
    public void setYubin2(String yubin2) {
        this.yubin2 = yubin2;
    }

    /**
     * @return the mail
     */
    public String getMail() {
        return mail;
    }

    /**
     * @param mail the mail to set
     */
    public void setMail(String mail) {
        this.mail = mail;
    }

    /**
     * @return the adr1
     */
    public String getAdr1() {
        return adr1;
    }

    /**
     * @param adr1 the adr1 to set
     */
    public void setAdr1(String adr1) {
        this.adr1 = adr1;
    }

    public String getKessaiSelectFlag() {
        return kessaiSelectFlag;
    }

    public void setKessaiSelectFlag(String kessaiSelectFlag) {
        this.kessaiSelectFlag = kessaiSelectFlag;
    }

    /**
     * @return the kessaiSelectComplete
     */
    public String getKessaiSelectComplete() {
        return kessaiSelectComplete;
    }

    /**
     * @param kessaiSelectComplete the kessaiSelectComplete to set
     */
    public void setKessaiSelectComplete(String kessaiSelectComplete) {
        this.kessaiSelectComplete = kessaiSelectComplete;
    }

    /**
     * @return the kessaiSelectMenjoBack
     */
    public String getKessaiSelectMenjoBack() {
        return kessaiSelectMenjoBack;
    }

    /**
     * @param kessaiSelectMenjoBack the kessaiSelectMenjoBack to set
     */
    public void setKessaiSelectMenjoBack(String kessaiSelectMenjoBack) {
        this.kessaiSelectMenjoBack = kessaiSelectMenjoBack;
    }

    /**
     * @return the sknKsuKbn
     */
    public String getSknKsuKbn() {
        return sknKsuKbn;
    }

    /**
     * @param sknKsuKbn the sknKsuKbn to set
     */
    public void setSknKsuKbn(String sknKsuKbn) {
        this.sknKsuKbn = sknKsuKbn;
    }

    public String getKaiinKbn() {
        return kaiinKbn;
    }

    public void setKaiinKbn(String kaiinKbn) {
        this.kaiinKbn = kaiinKbn;
    }

    public String getMenjoCheck() {
        return menjoCheck;
    }

    public void setMenjoCheck(String menjoCheck) {
        this.menjoCheck = menjoCheck;
    }

    /**
     * @return the nendo
     */
    public String getNendo() {
        return nendo;
    }

    /**
     * @param nendo the nendo to set
     */
    public void setNendo(String nendo) {
        this.nendo = nendo;
    }

    /**
     * @return the uketsukeNo
     */
    public String getUketsukeNo() {
        return uketsukeNo;
    }

    /**
     * @param uketsukeNo the uketsukeNo to set
     */
    public void setUketsukeNo(String uketsukeNo) {
        this.uketsukeNo = uketsukeNo;
    }

    /**
     * @return the soushinFlg
     */
    public String getSoushinFlg() {
        return soushinFlg;
    }

    /**
     * @param soushinFlg the soushinFlg to set
     */
    public void setSoushinFlg(String soushinFlg) {
        this.soushinFlg = soushinFlg;
    }

    /**
     * @return the mailTemplateIdx
     */
    public String getMailTemplateIdx() {
        return mailTemplateIdx;
    }

    /**
     * @param mailTemplateIdx the mailTemplateIdx to set
     */
    public void setMailTemplateIdx(String mailTemplateIdx) {
        this.mailTemplateIdx = mailTemplateIdx;
    }

    /**
     * @return the fuka
     */
    public String getFuka() {
        return fuka;
    }

    /**
     * @param fuka the fuka to set
     */
    public void setFuka(String fuka) {
        this.fuka = fuka;
    }

    /**
     * @return the kiboKaijoList
     */
    public String getKiboKaijoList() {
        return kiboKaijoList;
    }

    /**
     * @param kiboKaijoList the kiboKaijoList to set
     */
    public void setKiboKaijoList(String kiboKaijoList) {
        this.kiboKaijoList = kiboKaijoList;
    }

    /**
     * @return the mailKenmei
     */
    public String getMailKenmei() {
        return mailKenmei;
    }

    /**
     * @param mailKenmei the mailKenmei to set
     */
    public void setMailKenmei(String mailKenmei) {
        this.mailKenmei = mailKenmei;
    }

    /**
     * @return the mailHonbun
     */
    public String getMailHonbun() {
        return mailHonbun;
    }

    /**
     * @param mailHonbun the mailHonbun to set
     */
    public void setMailHonbun(String mailHonbun) {
        this.mailHonbun = mailHonbun;
    }

    /**
     * @return the mailFooter
     */
    public String getMailFooter() {
        return mailFooter;
    }

    /**
     * @param mailFooter the mailFooter to set
     */
    public void setMailFooter(String mailFooter) {
        this.mailFooter = mailFooter;
    }

    /**
     * @return the mskKigenbi
     */
    public String getMskKigenbi() {
        return mskKigenbi;
    }

    /**
     * @param mskKigenbi the mskKigenbi to set
     */
    public void setMskKigenbi(String mskKigenbi) {
        this.mskKigenbi = mskKigenbi;
    }

    /**
     * @return the ninzu
     */
    public int getNinzu() {
        return ninzu;
    }

    /**
     * @param ninzu the ninzu to set
     */
    public void setNinzu(int ninzu) {
        this.ninzu = ninzu;
    }

    /**
     * @return the gakaJitsugiGenmenNasiNinzu
     */
    public int getGakaJitsugiGenmenNasiNinzu() {
        return gakaJitsugiGenmenNasiNinzu;
    }

    /**
     * @param gakaJitsugiGenmenNasiNinzu the gakaJitsugiGenmenNasiNinzu to set
     */
    public void setGakaJitsugiGenmenNasiNinzu(int gakaJitsugiGenmenNasiNinzu) {
        this.gakaJitsugiGenmenNasiNinzu = gakaJitsugiGenmenNasiNinzu;
    }

    /**
     * @return the gakaJitsugiGenmenNasiJknJkuryo
     */
    public String getGakaJitsugiGenmenNasiJknJkuryo() {
        return gakaJitsugiGenmenNasiJknJkuryo;
    }

    /**
     * @param gakaJitsugiGenmenNasiJknJkuryo the gakaJitsugiGenmenNasiJknJkuryo
     * to set
     */
    public void setGakaJitsugiGenmenNasiJknJkuryo(String gakaJitsugiGenmenNasiJknJkuryo) {
        this.gakaJitsugiGenmenNasiJknJkuryo = gakaJitsugiGenmenNasiJknJkuryo;
    }

    /**
     * @return the gakaJitsugiGenmenNasiGokei
     */
    public String getGakaJitsugiGenmenNasiGokei() {
        return gakaJitsugiGenmenNasiGokei;
    }

    /**
     * @param gakaJitsugiGenmenNasiGokei the gakaJitsugiGenmenNasiGokei to set
     */
    public void setGakaJitsugiGenmenNasiGokei(String gakaJitsugiGenmenNasiGokei) {
        this.gakaJitsugiGenmenNasiGokei = gakaJitsugiGenmenNasiGokei;
    }

    /**
     * @return the gakaJitsugiGenmenNinzu
     */
    public int getGakaJitsugiGenmenNinzu() {
        return gakaJitsugiGenmenNinzu;
    }

    /**
     * @param gakaJitsugiGenmenNinzu the gakaJitsugiGenmenNinzu to set
     */
    public void setGakaJitsugiGenmenNinzu(int gakaJitsugiGenmenNinzu) {
        this.gakaJitsugiGenmenNinzu = gakaJitsugiGenmenNinzu;
    }

    /**
     * @return the gakaJitsugiGenmenJknJkuryo
     */
    public String getGakaJitsugiGenmenJknJkuryo() {
        return gakaJitsugiGenmenJknJkuryo;
    }

    /**
     * @param gakaJitsugiGenmenJknJkuryo the gakaJitsugiGenmenJknJkuryo to set
     */
    public void setGakaJitsugiGenmenJknJkuryo(String gakaJitsugiGenmenJknJkuryo) {
        this.gakaJitsugiGenmenJknJkuryo = gakaJitsugiGenmenJknJkuryo;
    }

    /**
     * @return the gakaJitsugiGenmenGokei
     */
    public String getGakaJitsugiGenmenGokei() {
        return gakaJitsugiGenmenGokei;
    }

    /**
     * @param gakaJitsugiGenmenGokei the gakaJitsugiGenmenGokei to set
     */
    public void setGakaJitsugiGenmenGokei(String gakaJitsugiGenmenGokei) {
        this.gakaJitsugiGenmenGokei = gakaJitsugiGenmenGokei;
    }

    /**
     * @return the gakaOnlyNinzu
     */
    public int getGakaOnlyNinzu() {
        return gakaOnlyNinzu;
    }

    /**
     * @param gakaOnlyNinzu the gakaOnlyNinzu to set
     */
    public void setGakaOnlyNinzu(int gakaOnlyNinzu) {
        this.gakaOnlyNinzu = gakaOnlyNinzu;
    }

    /**
     * @return the gakaOnlyJknJkuryo
     */
    public String getGakaOnlyJknJkuryo() {
        return gakaOnlyJknJkuryo;
    }

    /**
     * @param gakaOnlyJknJkuryo the gakaOnlyJknJkuryo to set
     */
    public void setGakaOnlyJknJkuryo(String gakaOnlyJknJkuryo) {
        this.gakaOnlyJknJkuryo = gakaOnlyJknJkuryo;
    }

    /**
     * @return the gakaOnlyGokei
     */
    public String getGakaOnlyGokei() {
        return gakaOnlyGokei;
    }

    /**
     * @param gakaOnlyGokei the gakaOnlyGokei to set
     */
    public void setGakaOnlyGokei(String gakaOnlyGokei) {
        this.gakaOnlyGokei = gakaOnlyGokei;
    }

    /**
     * @return the jitsugiOnlyGenmenNasiNinzu
     */
    public int getJitsugiOnlyGenmenNasiNinzu() {
        return jitsugiOnlyGenmenNasiNinzu;
    }

    /**
     * @param jitsugiOnlyGenmenNasiNinzu the jitsugiOnlyGenmenNasiNinzu to set
     */
    public void setJitsugiOnlyGenmenNasiNinzu(int jitsugiOnlyGenmenNasiNinzu) {
        this.jitsugiOnlyGenmenNasiNinzu = jitsugiOnlyGenmenNasiNinzu;
    }

    /**
     * @return the jitsugiOnlyGenmenNasiJknJkuryo
     */
    public String getJitsugiOnlyGenmenNasiJknJkuryo() {
        return jitsugiOnlyGenmenNasiJknJkuryo;
    }

    /**
     * @param jitsugiOnlyGenmenNasiJknJkuryo the jitsugiOnlyGenmenNasiJknJkuryo
     * to set
     */
    public void setJitsugiOnlyGenmenNasiJknJkuryo(String jitsugiOnlyGenmenNasiJknJkuryo) {
        this.jitsugiOnlyGenmenNasiJknJkuryo = jitsugiOnlyGenmenNasiJknJkuryo;
    }

    /**
     * @return the jitsugiOnlyGenmenNasiGokei
     */
    public String getJitsugiOnlyGenmenNasiGokei() {
        return jitsugiOnlyGenmenNasiGokei;
    }

    /**
     * @param jitsugiOnlyGenmenNasiGokei the jitsugiOnlyGenmenNasiGokei to set
     */
    public void setJitsugiOnlyGenmenNasiGokei(String jitsugiOnlyGenmenNasiGokei) {
        this.jitsugiOnlyGenmenNasiGokei = jitsugiOnlyGenmenNasiGokei;
    }

    /**
     * @return the jitsugiOnlyGenmenNinzu
     */
    public int getJitsugiOnlyGenmenNinzu() {
        return jitsugiOnlyGenmenNinzu;
    }

    /**
     * @param jitsugiOnlyGenmenNinzu the jitsugiOnlyGenmenNinzu to set
     */
    public void setJitsugiOnlyGenmenNinzu(int jitsugiOnlyGenmenNinzu) {
        this.jitsugiOnlyGenmenNinzu = jitsugiOnlyGenmenNinzu;
    }

    /**
     * @return the jitsugiOnlyGenmenJknJkuryo
     */
    public String getJitsugiOnlyGenmenJknJkuryo() {
        return jitsugiOnlyGenmenJknJkuryo;
    }

    /**
     * @param jitsugiOnlyGenmenJknJkuryo the jitsugiOnlyGenmenJknJkuryo to set
     */
    public void setJitsugiOnlyGenmenJknJkuryo(String jitsugiOnlyGenmenJknJkuryo) {
        this.jitsugiOnlyGenmenJknJkuryo = jitsugiOnlyGenmenJknJkuryo;
    }

    /**
     * @return the jitsugiOnlyGenmenGokei
     */
    public String getJitsugiOnlyGenmenGokei() {
        return jitsugiOnlyGenmenGokei;
    }

    /**
     * @param jitsugiOnlyGenmenGokei the jitsugiOnlyGenmenGokei to set
     */
    public void setJitsugiOnlyGenmenGokei(String jitsugiOnlyGenmenGokei) {
        this.jitsugiOnlyGenmenGokei = jitsugiOnlyGenmenGokei;
    }

    /**
     * @return the gakaMenjoGenmenNasiNinzu
     */
    public int getGakaMenjoGenmenNasiNinzu() {
        return gakaMenjoGenmenNasiNinzu;
    }

    /**
     * @param gakaMenjoGenmenNasiNinzu the gakaMenjoGenmenNasiNinzu to set
     */
    public void setGakaMenjoGenmenNasiNinzu(int gakaMenjoGenmenNasiNinzu) {
        this.gakaMenjoGenmenNasiNinzu = gakaMenjoGenmenNasiNinzu;
    }

    /**
     * @return the gakaMenjoGenmenNasiJknJkuryo
     */
    public String getGakaMenjoGenmenNasiJknJkuryo() {
        return gakaMenjoGenmenNasiJknJkuryo;
    }

    /**
     * @param gakaMenjoGenmenNasiJknJkuryo the gakaMenjoGenmenNasiJknJkuryo to
     * set
     */
    public void setGakaMenjoGenmenNasiJknJkuryo(String gakaMenjoGenmenNasiJknJkuryo) {
        this.gakaMenjoGenmenNasiJknJkuryo = gakaMenjoGenmenNasiJknJkuryo;
    }

    /**
     * @return the gakaMenjoGenmenNasiGokei
     */
    public String getGakaMenjoGenmenNasiGokei() {
        return gakaMenjoGenmenNasiGokei;
    }

    /**
     * @param gakaMenjoGenmenNasiGokei the gakaMenjoGenmenNasiGokei to set
     */
    public void setGakaMenjoGenmenNasiGokei(String gakaMenjoGenmenNasiGokei) {
        this.gakaMenjoGenmenNasiGokei = gakaMenjoGenmenNasiGokei;
    }

    /**
     * @return the gakaMenjoGenmenNinzu
     */
    public int getGakaMenjoGenmenNinzu() {
        return gakaMenjoGenmenNinzu;
    }

    /**
     * @param gakaMenjoGenmenNinzu the gakaMenjoGenmenNinzu to set
     */
    public void setGakaMenjoGenmenNinzu(int gakaMenjoGenmenNinzu) {
        this.gakaMenjoGenmenNinzu = gakaMenjoGenmenNinzu;
    }

    /**
     * @return the gakaMenjoGenmenJknJkuryo
     */
    public String getGakaMenjoGenmenJknJkuryo() {
        return gakaMenjoGenmenJknJkuryo;
    }

    /**
     * @param gakaMenjoGenmenJknJkuryo the gakaMenjoGenmenJknJkuryo to set
     */
    public void setGakaMenjoGenmenJknJkuryo(String gakaMenjoGenmenJknJkuryo) {
        this.gakaMenjoGenmenJknJkuryo = gakaMenjoGenmenJknJkuryo;
    }

    /**
     * @return the gakaMenjoGenmenGokei
     */
    public String getGakaMenjoGenmenGokei() {
        return gakaMenjoGenmenGokei;
    }

    /**
     * @param gakaMenjoGenmenGokei the gakaMenjoGenmenGokei to set
     */
    public void setGakaMenjoGenmenGokei(String gakaMenjoGenmenGokei) {
        this.gakaMenjoGenmenGokei = gakaMenjoGenmenGokei;
    }

    /**
     * @return the jitsugiMenjoNinzu
     */
    public int getJitsugiMenjoNinzu() {
        return jitsugiMenjoNinzu;
    }

    /**
     * @param jitsugiMenjoNinzu the jitsugiMenjoNinzu to set
     */
    public void setJitsugiMenjoNinzu(int jitsugiMenjoNinzu) {
        this.jitsugiMenjoNinzu = jitsugiMenjoNinzu;
    }

    /**
     * @return the jitsugiMenjoJknJkuryo
     */
    public String getJitsugiMenjoJknJkuryo() {
        return jitsugiMenjoJknJkuryo;
    }

    /**
     * @param jitsugiMenjoJknJkuryo the jitsugiMenjoJknJkuryo to set
     */
    public void setJitsugiMenjoJknJkuryo(String jitsugiMenjoJknJkuryo) {
        this.jitsugiMenjoJknJkuryo = jitsugiMenjoJknJkuryo;
    }

    /**
     * @return the jitsugiMenjoGokei
     */
    public String getJitsugiMenjoGokei() {
        return jitsugiMenjoGokei;
    }

    /**
     * @param jitsugiMenjoGokei the jitsugiMenjoGokei to set
     */
    public void setJitsugiMenjoGokei(String jitsugiMenjoGokei) {
        this.jitsugiMenjoGokei = jitsugiMenjoGokei;
    }

    /**
     * @return the shokeiNinzu
     */
    public int getShokeiNinzu() {
        return shokeiNinzu;
    }

    /**
     * @param shokeiNinzu the shokeiNinzu to set
     */
    public void setShokeiNinzu(int shokeiNinzu) {
        this.shokeiNinzu = shokeiNinzu;
    }

    /**
     * @return the shokeiGokei
     */
    public String getShokeiGokei() {
        return shokeiGokei;
    }

    /**
     * @param shokeiGokei the shokeiGokei to set
     */
    public void setShokeiGokei(String shokeiGokei) {
        this.shokeiGokei = shokeiGokei;
    }

    /**
     * @return the tesuryoGokei
     */
    public String getTesuryoGokei() {
        return tesuryoGokei;
    }

    /**
     * @param tesuryoGokei the tesuryoGokei to set
     */
    public void setTesuryoGokei(String tesuryoGokei) {
        this.tesuryoGokei = tesuryoGokei;
    }

    /**
     * @return the sumNinzu
     */
    public int getSumNinzu() {
        return sumNinzu;
    }

    /**
     * @param sumNinzu the sumNinzu to set
     */
    public void setSumNinzu(int sumNinzu) {
        this.sumNinzu = sumNinzu;
    }

    /**
     * @return the sumNinzuGokei
     */
    public String getSumNinzuGokei() {
        return sumNinzuGokei;
    }

    /**
     * @param sumNinzuGokei the sumNinzuGokei to set
     */
    public void setSumNinzuGokei(String sumNinzuGokei) {
        this.sumNinzuGokei = sumNinzuGokei;
    }

    /**
     * @return the moshikomishaNinzu
     */
    public int getMoshikomishaNinzu() {
        return moshikomishaNinzu;
    }

    /**
     * @param moshikomishaNinzu the moshikomishaNinzu to set
     */
    public void setMoshikomishaNinzu(int moshikomishaNinzu) {
        this.moshikomishaNinzu = moshikomishaNinzu;
    }

    /**
     * @return the moshikomishaJknJkuryo
     */
    public String getMoshikomishaJknJkuryo() {
        return moshikomishaJknJkuryo;
    }

    /**
     * @param moshikomishaJknJkuryo the moshikomishaJknJkuryo to set
     */
    public void setMoshikomishaJknJkuryo(String moshikomishaJknJkuryo) {
        this.moshikomishaJknJkuryo = moshikomishaJknJkuryo;
    }

    /**
     * @return the moshikomishaGokei
     */
    public String getMoshikomishaGokei() {
        return moshikomishaGokei;
    }

    /**
     * @param moshikomishaGokei the moshikomishaGokei to set
     */
    public void setMoshikomishaGokei(String moshikomishaGokei) {
        this.moshikomishaGokei = moshikomishaGokei;
    }

    /**
     * @return the kyuseidoNinzu
     */
    public int getKyuseidoNinzu() {
        return kyuseidoNinzu;
    }

    /**
     * @param kyuseidoNinzu the kyuseidoNinzu to set
     */
    public void setKyuseidoNinzu(int kyuseidoNinzu) {
        this.kyuseidoNinzu = kyuseidoNinzu;
    }

    /**
     * @return the kyuseidoJknJkuryo
     */
    public String getKyuseidoJknJkuryo() {
        return kyuseidoJknJkuryo;
    }

    /**
     * @param kyuseidoJknJkuryo the kyuseidoJknJkuryo to set
     */
    public void setKyuseidoJknJkuryo(String kyuseidoJknJkuryo) {
        this.kyuseidoJknJkuryo = kyuseidoJknJkuryo;
    }

    /**
     * @return the kyuseidoGokei
     */
    public String getKyuseidoGokei() {
        return kyuseidoGokei;
    }

    /**
     * @param kyuseidoGokei the kyuseidoGokei to set
     */
    public void setKyuseidoGokei(String kyuseidoGokei) {
        this.kyuseidoGokei = kyuseidoGokei;
    }

    /**
     * @return the mskOshiharaibi
     */
    public String getMskOshiharaibi() {
        return mskOshiharaibi;
    }

    /**
     * @param mskOshiharaibi the mskOshiharaibi to set
     */
    public void setMskOshiharaibi(String mskOshiharaibi) {
        this.mskOshiharaibi = mskOshiharaibi;
    }

    /**
     * @return the kessaiComplete
     */
    public String getKessaiComplete() {
        return kessaiComplete;
    }

    /**
     * @param kessaiComplete the kessaiComplete to set
     */
    public void setKessaiComplete(String kessaiComplete) {
        this.kessaiComplete = kessaiComplete;
    }

    /**
     * @return the KessaiHohoChi
     */
    public String getKessaiHohoChi() {
        return kessaiHohoChi;
    }

    /**
     * @param kessaiHohoChi the kessaiHohoChi to set
     */
    public void setKessaiHohoChi(String kessaiHohoChi) {
        this.kessaiHohoChi = kessaiHohoChi;
    }

    /**
     * @return the torokuUserId
     */
    public String getTorokuUserId() {
        return torokuUserId;
    }

    /**
     * @param torokuUserId the torokuUserId to set
     */
    public void setTorokuUserId(String torokuUserId) {
        this.torokuUserId = torokuUserId;
    }

    //</editor-fold>

 
    /**
     * @return the torihikiCode
     */
    public String getTorihikiCode() {
        return torihikiCode;
    }

    /**
     * @param torihikiCode the torihikiCode to set
     */
    public void setTorihikiCode(String torihikiCode) {
        this.torihikiCode = torihikiCode;
    }

    /**
     * @return the hukaJoho
     */
    public String getHukaJoho() {
        return hukaJoho;
    }

    /**
     * @param hukaJoho the hukaJoho to set
     */
    public void setHukaJoho(String hukaJoho) {
        this.hukaJoho = hukaJoho;
    }

    /**
     * @return the shiharaiJoho
     */
    public String getShiharaiJoho() {
        return shiharaiJoho;
    }

    /**
     * @param shiharaiJoho the shiharaiJoho to set
     */
    public void setShiharaiJoho(String shiharaiJoho) {
        this.shiharaiJoho = shiharaiJoho;
    }

    public void setMoshikomiListForInsert(List<Moshikomi> moshikomiListForInsert) {
        this.moshikomiListForInsert = moshikomiListForInsert;
    }

    public List<Moshikomi> getMoshikomiListForInsert() {
        return moshikomiListForInsert;
    }
    
    /**
     * @return the hoyuShikakuMstMuryo
     */
    public List<HoyuShikakuMst> getHoyuShikakuMstMuryo() {
        return hoyuShikakuMstMuryo;
    }

    /**
     * @param hoyuShikakuMstMuryo the hoyuShikakuMstMuryo to set
     */
    public void setHoyuShikakuMstMuryo(List<HoyuShikakuMst> hoyuShikakuMstMuryo) {
        this.hoyuShikakuMstMuryo = hoyuShikakuMstMuryo;
    }

    public HoyuShikakuMst getHoyuShikakuMstForUpdate() {
        return hoyuShikakuMstForUpdate;
    }

    public void setHoyuShikakuMstForUpdate(HoyuShikakuMst hoyuShikakuMstForUpdate) {
        this.hoyuShikakuMstForUpdate = hoyuShikakuMstForUpdate;
    }
}
