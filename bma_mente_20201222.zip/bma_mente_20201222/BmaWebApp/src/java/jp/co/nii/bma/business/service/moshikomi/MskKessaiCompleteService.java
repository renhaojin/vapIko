package jp.co.nii.bma.business.service.moshikomi;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import jp.co.nii.bma.business.domain.HoyuShikakuMst;
import jp.co.nii.bma.business.domain.Kessai;
import jp.co.nii.bma.business.domain.KessaiYokyu;
import jp.co.nii.bma.business.domain.KessaiYokyuKanryoTsuchi;
import jp.co.nii.bma.business.domain.MailSoshinRireki;
import jp.co.nii.bma.business.domain.MailTemplate;
import jp.co.nii.bma.business.domain.MeishoKanri;
import jp.co.nii.bma.business.domain.Moshikomi;
import jp.co.nii.bma.business.domain.MoshikomiHenkoRireki;
import jp.co.nii.bma.business.domain.Ryokin;
import jp.co.nii.bma.business.domain.Saiban;
import jp.co.nii.bma.business.domain.Schedule;
import jp.co.nii.bma.business.domain.Torokusha;
import jp.co.nii.bma.business.rto.MskKessaiJoho;
import jp.co.nii.bma.business.service.common.BmaConstants;
import jp.co.nii.bma.business.service.common.BmaLogger;
import jp.co.nii.bma.business.service.common.BmaMailSendService;
import jp.co.nii.bma.business.service.common.SaibanService;
import jp.co.nii.bma.utility.BmaStringUtility;
import jp.co.nii.bma.utility.BmaUtility;
import jp.co.nii.sew.business.service.AbstractService;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_SESSION;
import jp.co.nii.sew.presentation.Messages;
import jp.co.nii.sew.presentation.RequestTransferObject;
import jp.co.nii.sew.utility.PropertyUtility;
import org.apache.commons.beanutils.BeanUtils;
import jp.co.nii.bma.business.service.common.KingakuKeisanService;
import jp.co.nii.sew.utility.StringUtility;
import jp.co.nii.bma.business.service.common.MoshikomiCommonService;

/**
 * <p>
 * �^�C�g��: ���Ϗ����͊���</p>
 * <p>
 * ����: ���Ϗ����͊����T�[�r�X</p>
 * <p>
 * ���쌠: Copyright (c) 2020</p>
 * <p>
 * ��Ж�: ���{���Y�Ɗ������</p>
 */
public class MskKessaiCompleteService extends AbstractService {

    /**
     * DB�ڑ��̃f�[�^�\�[�X
     */
    private static String DATA_SOURCE_NAME;
    /**
     * ���O
     */
    BmaLogger log = (BmaLogger) BmaLogger.getLogger(this.getClass().getName());
    /**
     * �Ɩ��R�[�h
     */
    private static final String BUSINESS_CODE = PropertyUtility.getProperty("business_code");
    /**
     * ���׃e�X�g���[�h
     */
    private static final String STRESS_MODE = PropertyUtility.getProperty(BUSINESS_CODE + "stress_mode");
    /**
     * ���ώ�����[���e���v���[�gID(�N���W�b�g)
     */
    private static final String KESSAI_CANCEL_MAIL_TEMPLATE_ID_CARD = PropertyUtility.getProperty(BUSINESS_CODE + "kessai_cancel_mail_template_id_cvs");
    /**
     * ����IP�R�[�h(�N���W�b�g)
     */
    private static final String KESSAI_IP_CODE_CARD = PropertyUtility.getProperty(BUSINESS_CODE + "kessai_ip_code_credit");
    /**
     * ����IP�R�[�h(�R���r�j)
     */
    private static final String KESSAI_IP_CODE_CVS = PropertyUtility.getProperty(BUSINESS_CODE + "kessai_ip_code_convenience");
    /**
     * ����IP�R�[�h(�y�C�W�[)
     */
    private static final String KESSAI_IP_CODE_PAGE = PropertyUtility.getProperty(BUSINESS_CODE + "kessai_ip_code_page");

    /**
     * �R���X�g���N�^
     */
    public MskKessaiCompleteService() {
        super();
        /* DB�ڑ����̃��[�U�[������ */
        DATA_SOURCE_NAME = BmaConstants.DS_REGISTRANT;
    }

    /**
     * �T�[�r�X�N���X�̎��s���\�b�h
     *
     * @param rto ���N�G�X�g��񂩂�擾����rto
     * @param rtoInSession �Z�b�V�������rto
     * @return foward��
     * @throws Exception ��O
     */
    @Override
    public String doService(RequestTransferObject rto, RequestTransferObject rtoInSession) throws Exception {
        String processName = "MskKessaiComplete";
        log.Start(processName);

        MskKessaiJoho inRequest = (MskKessaiJoho) rto;
        MskKessaiJoho inSession = (MskKessaiJoho) rtoInSession;

        /*�G���[���b�Z�[�W������*/
        inSession.setErrors(new Messages());
        String message;
        // �N�x
        String nendo;
        // ��t�ԍ��擾
        String uketsukeNo;
        // �����u�K��敪
        String sknKsuKbn;
        // ���ϕ��@
        String kessaiHoho;
        // �l�c�̋敪
        String kojinDantaiKbn;
        String result = "";
        try {
            //�t�������K�v�����擾
            // �{�ԗp
            if (!BmaUtility.isNullOrEmpty(inRequest.getHukaJoho())) {
                // �N�x
                nendo = inRequest.getHukaJoho().split("\\" + BmaConstants.KESSAI_FUKA_SEPARATOR)[1];
                // ��t�ԍ��擾
                uketsukeNo = inRequest.getHukaJoho().split("\\" + BmaConstants.KESSAI_FUKA_SEPARATOR)[2];
                // �����u�K��敪
                sknKsuKbn = inRequest.getHukaJoho().split("\\" + BmaConstants.KESSAI_FUKA_SEPARATOR)[3];
                // ���ϕ��@
                kessaiHoho = inRequest.getHukaJoho().split("\\" + BmaConstants.KESSAI_FUKA_SEPARATOR)[4];
                // �l�c�̋敪
                kojinDantaiKbn = inRequest.getHukaJoho().split("\\" + BmaConstants.KESSAI_FUKA_SEPARATOR)[5];

            } else { // �e�X�g�p�A�܂��͖������T
                // �N�x
                nendo = inSession.getFuka().split("\\" + BmaConstants.KESSAI_FUKA_SEPARATOR)[1];
                // ��t�ԍ��擾
                uketsukeNo = inSession.getFuka().split("\\" + BmaConstants.KESSAI_FUKA_SEPARATOR)[2];
                // �����u�K��敪
                sknKsuKbn = inSession.getFuka().split("\\" + BmaConstants.KESSAI_FUKA_SEPARATOR)[3];
                // ���ϕ��@
                kessaiHoho = inSession.getFuka().split("\\" + BmaConstants.KESSAI_FUKA_SEPARATOR)[4];
                // �l�c�̋敪
                kojinDantaiKbn = inSession.getFuka().split("\\" + BmaConstants.KESSAI_FUKA_SEPARATOR)[5];
            }
            inSession.setNendo(nendo);
            inSession.setUketsukeNo(uketsukeNo);
            inSession.setMoshikomishaId(inRequest.getMoshikomishaId());
            inSession.setUserNo(uketsukeNo);
            inSession.setSknKsuKbn(sknKsuKbn);
            kessaiHoho = !BmaUtility.isNullOrEmpty(inSession.getKessaiHoho()) ? inSession.getKessaiHoho() : kessaiHoho;
            if (BmaConstants.GROUP.equals(kojinDantaiKbn) && "allMenjo".equals(inRequest.getMenjoCheck())) {
                kessaiHoho = BmaConstants.KESSAI_HOHO_KBN_BENEFITS;
            }
            inSession.setKessaiHoho(kessaiHoho);

            Date date = new Date();
            SimpleDateFormat f = new SimpleDateFormat("yyyyMMdd");
            SimpleDateFormat dt = new SimpleDateFormat("yyyy�NMM��dd��");
            String mskDate = dt.format(date);

            // �l�̏ꍇ
            if (BmaConstants.PRIVATE.equals(kojinDantaiKbn)) {
                /* �\���f�[�^�Z�b�g */
                MeishoKanri meishoKanri = new MeishoKanri(DATA_SOURCE_NAME);
                if (inRequest.getSknKsuKbn().equals(BmaConstants.SKN_KBN)) {
                    inSession.setSknchiKaijo(meishoKanri.find(BmaConstants.KAISAICHI_CODE, inRequest.getSknchiKaijo()).getHanyoChi());
                } else {
                    inSession.setSknchiKaijo(inRequest.getSknchiKaijo());
                    inSession.setSknchiKaijoJusho(inRequest.getSknchiKaijoJusho());
                }
            }
            // �\�����擾
            Moshikomi moshikomi = new Moshikomi(DATA_SOURCE_NAME).find(nendo, uketsukeNo);
            if (moshikomi == null) {
                message = "�\����񂪍폜����Ă��܂���B"
                        + " �N�x�F"
                        + nendo
                        + " ��t�ԍ��F"
                        + uketsukeNo;
                log.warn(message);
                throw new Exception(message);
            }
            inRequest.setSknKsuCode(moshikomi.getSknKsuCode());
            inRequest.setShubetsuCode(moshikomi.getShubetsuCode());
            inRequest.setKaisuCode(moshikomi.getKaisuCode());

            inSession.setMskDate(mskDate);
            // �\�����������擾
            Schedule schedule = new Schedule(DATA_SOURCE_NAME);
            String mskKigenbi = schedule.find(nendo, inRequest.getSknKsuCode(), inRequest.getShubetsuCode(), inRequest.getKaisuCode(), "16", "02").getDate();
            inSession.setMskKigenbi(dt.format(f.parse(mskKigenbi)));
            /* WEB���������擾 */
            String haraikomiKigenbiStr = schedule.find(nendo, inRequest.getSknKsuCode(), inRequest.getShubetsuCode(), inRequest.getKaisuCode(), BmaConstants.SCHEDULE_CODE_05, BmaConstants.SCHEDULE_KBN_2).getDate();
            Date haraikomiKigenbi = f.parse(haraikomiKigenbiStr);
            /* ���[���e���v���[�g�I�u�W�F�N�g�擾 */
            Calendar cal = Calendar.getInstance();
            MailTemplate mailTemplate = null;
            KessaiYokyuKanryoTsuchi kessaiYokyuKanryoTsuchi;
            KessaiYokyu kessaiYokyu;
            int jkuryo = 0;
            MoshikomiCommonService commonService;
            String kigenbi;
            SimpleDateFormat sdFormat;
            if (null != kessaiHoho) {
                switch (kessaiHoho) {
                    /* �N���W�b�g�J�[�h���� */
                    case BmaConstants.KESSAI_HOHO_KBN1:
                        // ��ʕ\�����Z�b�g
                        inSession.setKessaiJokyo("���ϊ���");
                        inSession.setJknJkuryo(inSession.getKessaiJknJkuryo());
                        inSession.setSystemRiyoryo(inSession.getKessaiJimutesuryo());
                        inSession.setGokei(inSession.getKessaiGokeiKingaku());
                        result = BmaConstants.PRIVATE.equals(kojinDantaiKbn) ? "card_" : "card_group_";
                        return result + FWD_NM_SUCCESS;
                    /* �R���r�j���� */
                    case BmaConstants.KESSAI_HOHO_KBN2:
                        // ��ʕ\�����Z�b�g
                        inSession.setKessaiJokyo("������");
                        // ��u��
                        String tesuryoFlag = "1";
                        List<Long> kingakuList = new KingakuKeisanService(DATA_SOURCE_NAME).calcAmount(inRequest.getSknKsuCode(), inRequest.getShubetsuCode(),
                                inRequest.getMskKbnSentaku(), inRequest.getSknNaiyoKbn(), kessaiHoho, inRequest.getGenmenShinsei(), tesuryoFlag, 0L);
                        inSession.setJknJkuryo(StringUtility.editComma(String.valueOf(kingakuList.get(0))) + "�~");
                        // �����萔��
                        inSession.setSystemRiyoryo(StringUtility.editComma(String.valueOf(kingakuList.get(1))) + "�~");
                        // ���ϗv�����z
                        inSession.setGokei(StringUtility.editComma(String.valueOf(kingakuList.get(2))) + "�~");
                        // ������
                        MoshikomiCommonService service = new MoshikomiCommonService(DATA_SOURCE_NAME);
                        kigenbi = service.getKigenbi(moshikomi.getNendo(), moshikomi.getSknKsuCode(), moshikomi.getShubetsuCode(), moshikomi.getKaisuCode(), new Date());
                        dt = new SimpleDateFormat("yyyy�NMM��dd��");
                        sdFormat = new SimpleDateFormat("yyyyMMdd");
                        inSession.setShiharaiKigen(dt.format(sdFormat.parse(kigenbi)));
                        result = BmaConstants.PRIVATE.equals(kojinDantaiKbn) ? "cvs_" : "cvs_group_";
                        return result + FWD_NM_SUCCESS;
                    /* �y�C�W�[���� */
                    case BmaConstants.KESSAI_HOHO_KBN3:
                        // ��ʕ\�����Z�b�g
                        inSession.setKessaiJokyo("������");
                        // ��u��
                        tesuryoFlag = "1";
                        kingakuList = new KingakuKeisanService(DATA_SOURCE_NAME).calcAmount(inRequest.getSknKsuCode(), inRequest.getShubetsuCode(),
                                inRequest.getMskKbnSentaku(), inRequest.getSknNaiyoKbn(), kessaiHoho, inRequest.getGenmenShinsei(), tesuryoFlag, 0L);
                        inSession.setJknJkuryo(StringUtility.editComma(String.valueOf(kingakuList.get(0))) + "�~");
                        // �����萔��
                        inSession.setSystemRiyoryo(StringUtility.editComma(String.valueOf(kingakuList.get(1))) + "�~");
                        // ���ϗv�����z
                        inSession.setGokei(StringUtility.editComma(String.valueOf(kingakuList.get(2))) + "�~");
                        // ������
                        commonService = new MoshikomiCommonService(DATA_SOURCE_NAME);
                        kigenbi = commonService.getKigenbi(moshikomi.getNendo(), moshikomi.getSknKsuCode(), moshikomi.getShubetsuCode(), moshikomi.getKaisuCode(), new Date());
                        dt = new SimpleDateFormat("yyyy�NMM��dd��");
                        sdFormat = new SimpleDateFormat("yyyyMMdd");
                        inSession.setShiharaiKigen(dt.format(sdFormat.parse(kigenbi)));
                        result = BmaConstants.PRIVATE.equals(kojinDantaiKbn) ? "page_" : "page_group_";
                        return result + FWD_NM_SUCCESS;
                    /* �ڍs���T�@����*/
                    case BmaConstants.KESSAI_HOHO_KBN4:
                        if (BmaConstants.GROUP.equals(kojinDantaiKbn)) {
                            createDetailJoho(inRequest, inSession);
                        }
                        inSession.setJknJkuryo("0�~");
                        inSession.setSystemRiyoryo("0�~");
                        inSession.setGokei("0�~");
                        inSession.setShiharaiKigenbi("");
                        result = BmaConstants.PRIVATE.equals(kojinDantaiKbn) ? "tokuten_" : "tokuten_group_";
                        break;
                    default:
                        break;
                }
            }

            /* DB�o�^�E�X�V */
            try {
                /* �g�����U�N�V�����擾&�J�n */
                getTransaction();
                beginTransaction();
                if (BmaConstants.PRIVATE.equals(kojinDantaiKbn)) {
                    moshikomi = new Moshikomi(DATA_SOURCE_NAME);
                    Moshikomi moshikomiBfr = moshikomi.find(nendo, uketsukeNo);
                    if (!BmaConstants.KESSAI_HOHO_KBN4.equals(kessaiHoho)) {
                        // �\���ύX��������o�^����
                        MoshikomiHenkoRireki moshikomiHenkoRireki = new MoshikomiHenkoRireki(DATA_SOURCE_NAME);
                        /* �\����񂩂�\���ύX�������ɒl���R�s�[ */
                        BeanUtils.copyProperties(moshikomiHenkoRireki, moshikomiBfr);
                        /* �o�^���Z�b�g */
                        MoshikomiHenkoTrk(moshikomiHenkoRireki, inSession);
                        /*�C���T�[�g���s*/
                        moshikomiHenkoRireki.create();
                    }
                    // �\�������X�V����
                    BeanUtils.copyProperties(moshikomi, moshikomiBfr);
                    /* �X�V���Z�b�g */
                    MoshikomiUpd(moshikomi, inSession);
                    /*�A�b�v�f�[�g���s*/
                    moshikomi.update();
                } else if (BmaConstants.GROUP.equals(kojinDantaiKbn)) {
                    Moshikomi moshikomiBfr = new Moshikomi(DATA_SOURCE_NAME);
                    MoshikomiHenkoRireki moshikomiHenkoRireki = new MoshikomiHenkoRireki(DATA_SOURCE_NAME);
                    for (Moshikomi moshikomiInsert : inRequest.getMoshikomiListForInsert()) {
                        // �\���ύX��������o�^����
                        /* �\����񂩂�\���ύX�������ɒl���R�s�[ */
                        moshikomiBfr = moshikomi.find(moshikomiInsert.getNendo(), moshikomiInsert.getUketsukeNo());
                        BeanUtils.copyProperties(moshikomiHenkoRireki, moshikomiBfr);
                        /* �o�^���Z�b�g */
                        MoshikomiHenkoTrk(moshikomiHenkoRireki, inSession);
                        /*�C���T�[�g���s*/
                        moshikomiHenkoRireki.create();
                        // �\�������X�V����
                        BeanUtils.copyProperties(moshikomi, moshikomiBfr);
                        /* �X�V���Z�b�g */
                        MoshikomiUpd(moshikomi, inSession);
                        /*�A�b�v�f�[�g���s*/
                        moshikomi.update();
                    }
                }
                // �����x�ڍs���T������ꍇ�A�ۗL���i�}�X�^���X�V����
                if (BmaConstants.PRIVATE.equals(kojinDantaiKbn) && BmaConstants.KESSAI_HOHO_KBN4.equals(kessaiHoho)) {
                    // �l�@���ϕ��@�Ŕ���
                    HoyuShikakuMst hoyuShikakuMst = new HoyuShikakuMst(DATA_SOURCE_NAME);
                    BeanUtils.copyProperties(hoyuShikakuMst, inRequest.getHoyuShikakuMstForUpdate());
                    HoyuShikakuMstUpd(hoyuShikakuMst, inSession);
                    hoyuShikakuMst.update();
                } else if (BmaConstants.GROUP.equals(kojinDantaiKbn) && inRequest.getHoyuShikakuMstMuryo().size() > 0) {
                    // �c�́@�X�V�p���X�g�̗L���Ŕ���
                    HoyuShikakuMst hoyuShikakuMst = new HoyuShikakuMst(DATA_SOURCE_NAME);
                    List<HoyuShikakuMst> hoyuShikakuMstMapForUpdate = inRequest.getHoyuShikakuMstMuryo();
                    for (HoyuShikakuMst hoyuMuryo : hoyuShikakuMstMapForUpdate) {
                        BeanUtils.copyProperties(hoyuShikakuMst, hoyuMuryo);
                        HoyuShikakuMstUpd(hoyuShikakuMst, inSession);
                        hoyuShikakuMst.update();
                    }
                }
                //���ς�o�^����
                Kessai kessai = new Kessai(DATA_SOURCE_NAME).find(nendo, uketsukeNo);
                if (kessai == null) {
                    /* �o�^���Z�b�g */
                    kessai = new Kessai(DATA_SOURCE_NAME);
                    kessaiTrk(kessai, inSession, haraikomiKigenbiStr);
                    /*�C���T�[�g���s*/
                    kessai.create();
                } else {
                    log.warn("���Ϗ��͂��łɓo�^����Ă��܂��B"
                            + " �N�x�F" + nendo
                            + " ��t�ԍ��F" + uketsukeNo
                    );
                }
                /* �R�~�b�g */
                commitTransaction();
            } catch (Exception ex) {
                ex.printStackTrace();
                // ���[���o�b�N
                rollbackTransaction();
                return FWD_NM_SESSION;
            }

            /*���[�����M*/
            List<String> mailParamList = null;
            Boolean status = false;
            commonService = new MoshikomiCommonService(DATA_SOURCE_NAME);
            mailParamList = commonService.getMailParamList(nendo, uketsukeNo, inRequest.getSknKsuKbn(), kessaiHoho, kojinDantaiKbn);
            BmaMailSendService serv = new BmaMailSendService();
            String mailTemplateId = commonService.getMailTemplateId(inRequest.getSknKsuKbn(), kessaiHoho, kojinDantaiKbn);

            if (BmaConstants.PRIVATE.equals(kojinDantaiKbn)) {
                status = serv.sendMail(inRequest.getMailAddress(), mailTemplateId, mailParamList);
            } else {
                // �c�̑�\�҂̃��[���A�h���X�擾
                Torokusha torokusha = new Torokusha(DATA_SOURCE_NAME);
                String mailAddress = torokusha.find(inSession.getMoshikomishaId()).getMailAddress();
                status = serv.sendMail(mailAddress, mailTemplateId, mailParamList);
            }
            // ���M�`�F�b�N
            if (status) {
                inSession.setSoushinFlg("1");
            } else {
                inSession.setSoushinFlg("0");
            }
            //���[�����M��o�^����
            try {
                /* �g�����U�N�V�����擾&l�n */
                getTransaction();
                beginTransaction();
                // ���[���e���v���[�g��DB����擾
                mailTemplate = new MailTemplate(DATA_SOURCE_NAME).find(mailTemplateId);
                MailSoshinRireki mailSoshinRireki = new MailSoshinRireki(DATA_SOURCE_NAME);
                /* �o�^���Z�b�g */
                mailSoshinTrk(mailSoshinRireki, inSession, mailTemplate, mailParamList);
                // ���[���p�����[�^�ݒ�
                commonService.setMailParameter(mailSoshinRireki, mailParamList);
               /*DB�o�^*/
                mailSoshinRireki.create();
                /* �R�~�b�g */
                commitTransaction();
            } catch (Exception ex) {
                ex.printStackTrace();
                // ���[���o�b�N
                rollbackTransaction();
                return FWD_NM_SESSION;
            }
            return result + FWD_NM_SUCCESS;
        } catch (Exception e) {
            e.printStackTrace();
            return FWD_NM_EXCEPTION;
        } finally {
            log.End(processName);
        }
    }

    /**
     * ��ʂɕ\�����閾�ׂ��쐬����i�c�̐\��_�Ə��̂݁j
     *
     * @param inRequest
     * @param inSession
     */
    public void createDetailJoho(MskKessaiJoho inRequest, MskKessaiJoho inSession) throws Exception {
        Ryokin ryokin = new Ryokin(DATA_SOURCE_NAME);
        MeishoKanri meishoKanri = new MeishoKanri(BmaConstants.DS_REGISTRANT);
        Moshikomi moshikomi = new Moshikomi(DATA_SOURCE_NAME);

        //���ϕ��@���̎擾
        String kessaiHohoChi = meishoKanri.find(BmaConstants.KESSAI_HOHO_KBN, inSession.getKessaiHoho()).getHanyoChi();
        inSession.setKessaiHohoChi(kessaiHohoChi);

        //�l�����擾
        MskKessaiJoho moshikomiNinzu = moshikomi.getNinzuKsuKessai(inRequest);
        int sumNinzu = moshikomiNinzu.getMoshikomishaNinzu() + moshikomiNinzu.getKyuseidoNinzu();
        inSession.setMoshikomishaNinzu(moshikomiNinzu.getMoshikomishaNinzu());
        inSession.setKyuseidoNinzu(moshikomiNinzu.getKyuseidoNinzu());
        inSession.setNinzu(moshikomiNinzu.getNinzu());
        inSession.setShokeiNinzu(sumNinzu);
        inSession.setSumNinzu(sumNinzu);

        // ������ݒ�
        String ryokinKbn = BmaConstants.KAIN_KUBUN_SEI_KAIIN.equals(inRequest.getKaiinKbn()) ? BmaConstants.RYOKIN_KBN2 : BmaConstants.RYOKIN_KBN1;
        String moshikomishaJknJkuryo = ryokin.find(inRequest.getSknKsuCode(), inRequest.getShubetsuCode(), ryokinKbn).getRyokin();
        inSession.setMoshikomishaJknJkuryo(BmaStringUtility.editComma(moshikomishaJknJkuryo) + "�~");
        inSession.setTesuryoGokei("0�~");
        inSession.setMoshikomishaGokei("0�~");
        inSession.setKyuseidoJknJkuryo("0�~");
        inSession.setKyuseidoGokei("0�~");
        inSession.setShokeiGokei("0�~");
        inSession.setSumNinzuGokei("0�~");
    }

    /**
     * �\�����X�V����
     *
     * @param bo
     * @param inSession
     */
    public void MoshikomiUpd(Moshikomi bo, MskKessaiJoho inSession) throws Exception {
        Date date = new Date();
        SimpleDateFormat dt = new SimpleDateFormat("yyyyMMdd");
        SimpleDateFormat tm = new SimpleDateFormat("HHmmss");
        String koshinDate = dt.format(date);
        String koshinTime = tm.format(date);
        bo.setKariUketsukeBi(koshinDate);
        bo.setKariUketsukeTime(koshinTime);
        bo.setKoshinKbn(BmaConstants.SHORI_KBN_UPDATE);
        bo.setKoshinDate(koshinDate);
        bo.setKoshinTime(koshinTime);
        bo.setKoshinUserId(inSession.getMoshikomishaId());
    }

    /**
     * �\���ύX������o�^����
     *
     * @param bo
     * @param inSession
     */
    public void MoshikomiHenkoTrk(MoshikomiHenkoRireki bo, MskKessaiJoho inSession) throws Exception {
        Date date = new Date();
        SimpleDateFormat dt = new SimpleDateFormat("yyyyMMdd");
        SimpleDateFormat tm = new SimpleDateFormat("HHmmss");
        String koshinDate = dt.format(date);
        String koshinTime = tm.format(date);
        Saiban saiban = new SaibanService(DATA_SOURCE_NAME).getSaibanAndUpdate(BmaConstants.SAIBAN_MOSHIKOMIHENKORIREKI_IDX, inSession.getMoshikomishaId());
        bo.setMoshikomiHenkoRirekiIdx(saiban.getGenzaiNo());
        bo.setHenkoKbn("1");
        bo.setKoshinKbn("I");
        bo.setTorokuDate(koshinDate);
        bo.setTorokuTime(koshinTime);
        bo.setTorokuUserId(inSession.getMoshikomishaId());
        bo.setKoshinDate("");
        bo.setKoshinTime("");
        bo.setKoshinUserId("");
    }

    /**
     * �ۗL���i�}�X�^���X�V����
     *
     * @param bo
     * @param inSession
     */
    public void HoyuShikakuMstUpd(HoyuShikakuMst bo, MskKessaiJoho inSession) throws Exception {
        Date date = new Date();
        SimpleDateFormat dt = new SimpleDateFormat("yyyyMMdd");
        SimpleDateFormat tm = new SimpleDateFormat("HHmmss");
        String koshinDate = dt.format(date);
        String koshinTime = tm.format(date);

        int muryoZanCount = Integer.parseInt(bo.getMuryoZanCount());
        bo.setMuryoZanCount(String.valueOf(muryoZanCount - 1));

        bo.setKoshinKbn(BmaConstants.SHORI_KBN_UPDATE);
        bo.setKoshinDate(koshinDate);
        bo.setKoshinTime(koshinTime);
        bo.setKoshinUserId(inSession.getMoshikomishaId());
    }

    /**
     * ���ς�o�^����
     *
     * @param bo
     * @param inSession
     */
    public void kessaiTrk(Kessai bo, MskKessaiJoho inSession, String haraikomiKigenbi) throws Exception {
        Date date = new Date();
        SimpleDateFormat dt = new SimpleDateFormat("yyyyMMdd");
        SimpleDateFormat tm = new SimpleDateFormat("HHmmss");
        Calendar cal = Calendar.getInstance();
        String koshinDate = dt.format(date);
        String koshinTime = tm.format(date);
        bo.setNendo(inSession.getNendo());
        bo.setUketsukeNo(inSession.getUketsukeNo());
        bo.setKessaiJokyoKbn("1");
        bo.setIpCode("");
        bo.setKessaiKigenBi("");
        bo.setKessaiConvenienceShubetsu("");
        bo.setKessaiConvenienceHaraikomiNo("");
        bo.setKessaiShunoKikanNo("");
        bo.setKessaiOkyakusamaNo("");
        bo.setKessaiKakuninNo("");
        bo.setKessaiKigenBi("");
        bo.setKessaiKingaku("0");
        bo.setKessaiTesuryo("0");
        bo.setKessaiKingakuTotal("0");
        bo.setKessaiHohoKbn(inSession.getKessaiHoho());
        bo.setTorihikiCode(inSession.getUketsukeNo());
        bo.setKessaiHaraikomihyoUrl("");
        bo.setKessaiTokusokuMailSoshinFlg("0");
        bo.setKoshinKbn("I");
        bo.setTorokuDate(koshinDate);
        bo.setTorokuTime(koshinTime);
        bo.setTorokuUserId(inSession.getMoshikomishaId());
        bo.setKoshinDate("");
        bo.setKoshinTime("");
        bo.setKoshinUserId("");
        bo.setRonriSakujoFlg("0");
    }

    /**
     * ���[�����M������o�^����
     *
     * @param bo
     * @param inSession
     * @param mailParam
     */
    public void mailSoshinTrk(MailSoshinRireki bo, MskKessaiJoho inSession, MailTemplate mailTemplate, List<String> mailParam) throws Exception {
        Date date = new Date();
        BmaMailSendService mailSendService = new BmaMailSendService();
        SimpleDateFormat dt = new SimpleDateFormat("yyyyMMdd");
        SimpleDateFormat tm = new SimpleDateFormat("HHmmss");
        String koshinDate = dt.format(date);
        String koshinTime = tm.format(date);
        Saiban saiban = new SaibanService(DATA_SOURCE_NAME).getSaibanAndUpdate(BmaConstants.SAIBAN_SENDMAILRIREKI_IDX, inSession.getMoshikomishaId());
        bo.setMailSoshinRirekiIdx(saiban.getGenzaiNo());
        mailSendService.formatReplaceList(mailParam);
        bo.setMailKenmei(mailSendService.createMailKenmei(mailTemplate, mailParam));
        bo.setMailHonbun(mailSendService.createMailHonbun(mailTemplate, mailParam));
        bo.setMailFooter(mailSendService.createMailFooter(mailTemplate, mailParam));
        bo.setMailSoshinKensu("1");
        if (inSession.getSoushinFlg().equals("0")) {
            bo.setMailSoshinJokyoKbn("2");
        } else {
            bo.setMailSoshinJokyoKbn("1");
        }
        bo.setKoshinKbn("I");
        bo.setTorokuDate(koshinDate);
        bo.setTorokuTime(koshinTime);
        bo.setTorokuUserId(inSession.getMoshikomishaId());
        bo.setKoshinDate("");
        bo.setKoshinTime("");
        bo.setKoshinUserId("");
        bo.setRonriSakujoFlg("0");
    }
}
