package jp.co.nii.bma.business.service.moshikomi;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import jp.co.nii.bma.business.domain.KessaiYokyu;
import jp.co.nii.bma.business.domain.MeishoKanri;
import jp.co.nii.bma.business.domain.SknksuMst;
import jp.co.nii.bma.business.rto.MskKessaiJoho;
import jp.co.nii.bma.business.service.common.BmaConstants;
import jp.co.nii.bma.business.service.common.BmaLogger;
import jp.co.nii.bma.business.service.common.BmaValidator;
import jp.co.nii.bma.business.service.common.KingakuKeisanService;
import jp.co.nii.bma.business.service.common.MoshikomiCommonService;
import jp.co.nii.bma.utility.BmaStringUtility;
import jp.co.nii.bma.utility.BmaUtility;
import jp.co.nii.sew.business.Validator;
import jp.co.nii.sew.business.service.AbstractService;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_ERROR;
import jp.co.nii.sew.presentation.Messages;
import jp.co.nii.sew.presentation.Option;
import jp.co.nii.sew.presentation.RequestTransferObject;
import jp.co.nii.sew.utility.PropertyUtility;
import jp.co.nii.sew.utility.StringUtility;

/**
 * <p>
 * �^�C�g��: ���Ϗ��I��</p>
 * <p>
 * ����: ���Ϗ��I���T�[�r�X</p>
 * <p>
 * ���쌠: Copyright (c) 2020</p>
 * <p>
 * ��Ж�: ���{���Y�Ɗ������</p>
 */
public class MskKessaiSelectService extends AbstractService {

    /**
     * DB�ڑ��̃f�[�^�\�[�X
     */
    private static String DATA_SOURCE_NAME;
    /**
     * ���O
     */
    BmaLogger log = (BmaLogger) BmaLogger.getLogger(this.getClass().getName());
    /**
     * �Ɩ��R�[�h
     */
    private static final String BUSINESS_CODE = PropertyUtility.getProperty("business_code");
    /**
     * ���׃e�X�g���[�h
     */
    private static final String STRESS_MODE = PropertyUtility.getProperty(BUSINESS_CODE + "stress_mode");

    /**
     * �R���X�g���N�^
     */
    public MskKessaiSelectService() {
        super();
        /* DB�ڑ����̃��[�U�[������ */
        DATA_SOURCE_NAME = BmaConstants.DS_REGISTRANT;
    }

    /**
     * �T�[�r�X�N���X�̎��s���\�b�h
     *
     * @param rto ���N�G�X�g��񂩂�擾����rto
     * @param rtoInSession �Z�b�V�������rto
     * @return foward��
     * @throws Exception ��O
     */
    @Override
    public String doService(RequestTransferObject rto, RequestTransferObject rtoInSession)
            throws Exception {

        MskKessaiJoho inRequest = (MskKessaiJoho) rto;
        MskKessaiJoho inSession = (MskKessaiJoho) rtoInSession;

        String processName = "";
        String message;
        try {
            if (!BmaUtility.isNullOrEmpty(inRequest.getMskKakutei())) {
                processName = "MskKessaiSelect";
                log.Start(processName);
                //���ϕ��@���擾����B
                setOptionList(BmaConstants.KESSAI_HOHO_KBN, inSession);
                inSession.setErrors(new Messages());
                inSession.setKessaiSelectFlag(inRequest.getKessaiSelectFlag());
                String result = "";
                inSession.setMskKakutei(inRequest.getMskKakutei());
                if ("kessaiHoho".equals(inRequest.getKessaiSelectFlag())) {
                    result = FWD_NM_SUCCESS;
                } else if ("kessaiSelectMenjo".equals(inRequest.getKessaiSelectFlag())) {
                    inSession.setKessaiHoho(BmaConstants.KESSAI_HOHO_KBN_BENEFITS);
                    inSession.setNendo(inRequest.getNendo());
                    inSession.setUketsukeNo(inRequest.getUketsukeNo());
                    inSession.setSknKsuKbn(inRequest.getSknKsuKbn());
                    // �t�����ݒ�
                    MoshikomiCommonService commonService = new MoshikomiCommonService(DATA_SOURCE_NAME);
                    commonService.setFukaInfo(inRequest, inSession);
                  
                    result = "confirm";
                }
                return result;
            } else if (!BmaUtility.isNullOrEmpty(inRequest.getKingakuKakuninBack())) {
                processName = "kingakuKakuninBack";
                log.Start(processName);
                inSession.setErrors(new Messages());
                return FWD_NM_BACK;
            } else if (!BmaUtility.isNullOrEmpty(inRequest.getKessaiHohoNext())) {
                processName = "MskKingakuConfirm";
                log.Start(processName);
                String kessaiHoho = inRequest.getKessaiHoho();
                /**
                 * �u���ցv�{�^�������� *
                 */
                boolean retCheck = ValidatorCaller(inSession, kessaiHoho);
                if (retCheck) {
                    inSession.setKessaiHoho(kessaiHoho);
                    String tesuryoFlag = "1";
                    List<Long> kingakuList = new ArrayList<>();
                    KingakuKeisanService KingakuKeisan;
                    kingakuList = new KingakuKeisanService(DATA_SOURCE_NAME).calcAmount(inRequest.getSknKsuCode(), inRequest.getShubetsuCode(),
                            inRequest.getMskKbnSentaku(), inRequest.getSknNaiyoKbn(), kessaiHoho, inRequest.getGenmenShinsei(), tesuryoFlag, 0L);
                    List<String> ryokinKbnList = new ArrayList<>();
                    inSession.setKessaiJknJkuryo(formatKingaku(kingakuList.get(0)) + "�~");
                    inSession.setKessaiJimutesuryo(formatKingaku(kingakuList.get(1)) + "�~");
                    inSession.setKessaiGokeiKingaku(formatKingaku(kingakuList.get(2)) + "�~");
                    return "kingaku";
                } else {
                    //�`�F�b�N�G���[
                    return FWD_NM_ERROR;
                }
                // ���σL�����Z��
            } else if (!BmaUtility.isNullOrEmpty(inRequest.getKessaiHohoBack())) {
                processName = "MskKessaiSelectBack";
                log.Start(processName);
                String result = inRequest.getKessaiHohoBack().equals("ok") ? FWD_NM_CANCEL : FWD_NM_RELOAD;
                return result;
            } else if (!BmaUtility.isNullOrEmpty(inRequest.getKingakuKakuninNext())) {
                processName = "MskKessaiSelectNext";
                log.Start(processName);
                inSession.setNendo(inRequest.getNendo());
                inSession.setUketsukeNo(inRequest.getUketsukeNo());
                inSession.setSknKsuKbn(inRequest.getSknKsuKbn());
                // �t�����ݒ�
                MoshikomiCommonService commonService = new MoshikomiCommonService(DATA_SOURCE_NAME);
                commonService.setFukaInfo(inRequest, inSession);
                KessaiYokyu kessaiYokyu = new KessaiYokyu(BmaConstants.DS_REGISTRANT);
                // ���ϗv���o�^�y�ь��ϗv�����ݒ�
                kessaiYokyuTrk(kessaiYokyu, inRequest, inSession);
                kessaiYokyu.create();
                return "redirect";
            } else if (!BmaUtility.isNullOrEmpty(inRequest.getKessaiSelectComplete())) {
                processName = "MskKessaiSelectComplete";
                log.Start(processName);
                return "complete";
            } else if (!BmaUtility.isNullOrEmpty(inRequest.getKessaiSelectMenjoBack())) {
                processName = "MskKessaiSelectMenjoBack";
                log.Start(processName);
                inSession.clearInfo();
                String result = inRequest.getKessaiHohoBack().equals("ok") ? FWD_NM_CANCEL : FWD_NM_RELOAD;
                return result;
            } else if (!BmaUtility.isNullOrEmpty(inRequest.getKessaiComplete())) {
                processName = "MskKessaiSelectComplete";
                log.Start(processName);
                String result = null;
                switch (inSession.getKessaiHoho()) {
                    case BmaConstants.KESSAI_HOHO_KBN1:
                        result = "card";
                        break;
                    case BmaConstants.KESSAI_HOHO_KBN2:
                        result = "conveni";
                        break;
                    case BmaConstants.KESSAI_HOHO_KBN3:
                        result = "payeasy";
                        break;
                    default:
                        break;
                }
                return result;
            } else {
                /*�ُ�J��*/
                log.IllegalFWD();
                return FWD_NM_SESSION;
            }
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        } finally {
            log.End(processName);
        }
    }

    /**
     * ���ϕ��@���X�g���Z�b�g����
     *
     * @param InSession
     * @param groupCode
     */
    public void setOptionList(String groupCode, MskKessaiJoho InSession) {
        List<Option> list = new ArrayList<>();
        //���ϕ��@��p�ӂ���
        MeishoKanri meishoKanri = new MeishoKanri(BmaConstants.DS_REGISTRANT);
        meishoKanri.findByGroupCode(groupCode, list);
        InSession.setKessaiHohoList(list);
    }

    /**
     * ���ϗv����o�^����
     *
     * @param bo
     * @param inSession
     * @param inRequest
     */
    public void kessaiYokyuTrk(KessaiYokyu bo, MskKessaiJoho inRequest, MskKessaiJoho inSession) throws Exception {
        Date date = new Date();
        SimpleDateFormat dt = new SimpleDateFormat("yyyyMMdd");
        SimpleDateFormat tm = new SimpleDateFormat("HHmmss");
        SknksuMst sknksuMst = new SknksuMst(BmaConstants.DS_REGISTRANT);
        String kessaiHoho = inSession.getKessaiHoho();
        bo.setTorihikiCodeNaibu(inRequest.getMoshikomiUketsukeNo());
        // ���i���P
        String shikakuName = StringUtility.cutString(sknksuMst.find(inRequest.getSknKsuCode(), inRequest.getShubetsuCode(), inRequest.getKaisuCode()).getSikakuName(), BmaConstants.KESSAI_YOKYU_SHOHIN_MEI_MAX_LENGTH);
        bo.setShohinName1(shikakuName);
        // ���z�P
        String kingaku = StringUtility.cutString(inSession.getKessaiGokeiKingaku().replace(",", "").replace("�~", ""), BmaConstants.KESSAI_YOKYU_KINGAKU_MAX_LENGTH);
        bo.setKingaku1(kingaku);
        bo.setShohinName2("");
        bo.setKingaku2("");
        bo.setShohinName3("");
        bo.setKingaku3("");
        bo.setShohinName4("");
        bo.setKingaku4("");
        bo.setShohinName5("");
        bo.setKingaku5("");
        bo.setShohinName6("");
        bo.setKingaku6("");
        bo.setHukaJoho(inRequest.getFuka());
        bo.setKessaiHohoStore((BmaConstants.KESSAI_HOHO_TO_STORE.get(kessaiHoho)));
        bo.setFinishUrl(BmaConstants.KESSAI_OK_URL);
        bo.setModoriUrl(BmaConstants.KESSAI_RT_URL);
        // ��������
        String kanjiShimei = StringUtility.cutString(BmaStringUtility.convertHankakuToZenkakuBma(inRequest.getShimeiSei()) + BmaConstants.KESSAI_FUKA_SEPARATOR + BmaStringUtility.convertHankakuToZenkakuBma(inRequest.getShimeiMei()), BmaConstants.KESSAI_YOKYU_KANJI_SHIMEI_MAX_LENGTH + 1);
        // ��������(��)
        bo.setBuyerKanjiShimeiSei(kanjiShimei.split("\\" + BmaConstants.KESSAI_FUKA_SEPARATOR)[0]);
        // ��������(��)
        bo.setBuyerKanjiShimeiMei(kanjiShimei.split("\\" + BmaConstants.KESSAI_FUKA_SEPARATOR)[1]);
        // �J�i����
        String kanaShimei = StringUtility.cutString(BmaStringUtility.convertHankakuToZenkakuBma(inRequest.getFuriganaSei()) + BmaConstants.KESSAI_FUKA_SEPARATOR + BmaStringUtility.convertHankakuToZenkakuBma(inRequest.getFuriganaMei()), BmaConstants.KESSAI_YOKYU_KANJI_SHIMEI_MAX_LENGTH + 1);
        kanaShimei = kanaShimei.replace("�@", "");
        // �J�i����(��)
        bo.setBuyerKanaShimeiSei(kanaShimei.split("\\" + BmaConstants.KESSAI_FUKA_SEPARATOR)[0]);
        // �J�i����(��)
        bo.setBuyerKanaShimeiMei(kanaShimei.split("\\" + BmaConstants.KESSAI_FUKA_SEPARATOR)[1]);
        // �X�֔ԍ��P
        bo.setBuyerZipNum1(inRequest.getYubinNo().substring(0, 3));
        // �X�֔ԍ��Q
        bo.setBuyerZipNum2(inRequest.getYubinNo().substring(3, 7));
        // �d�b�ԍ�
        bo.setBuyerTelNo(StringUtility.cutString(inRequest.getTelNo(), BmaConstants.KESSAI_YOKYU_TEL_MAX_LENGTH));
        // �Z���P
        bo.setBuyerJusho1(StringUtility.cutString(BmaStringUtility.convertHankakuToZenkakuBma(inRequest.getJusho1()), BmaConstants.KESSAI_YOKYU_ADR_MAX_LENGTH));
        // �Z���Q
        bo.setBuyerJusho2(StringUtility.cutString(BmaStringUtility.convertHankakuToZenkakuBma(inRequest.getJusho2()), BmaConstants.KESSAI_YOKYU_ADR_MAX_LENGTH));
        // ���[���A�h���X
        bo.setBuyerMailAddress(inRequest.getMailAddress());
        // ������
        MoshikomiCommonService commonService = new MoshikomiCommonService(DATA_SOURCE_NAME);
        String kigenbi = commonService.getKigenbi(inRequest.getNendo(), inRequest.getSknKsuCode(), inRequest.getShubetsuCode(), inRequest.getKaisuCode(), new Date());
        bo.setShiharaiKigen(kigenbi);
        bo.setUchizeiGaku("");
        bo.setUserId(inRequest.getMoshikomishaId());
        bo.setHyojiLanguage("0");
        bo.setKessaiKakutei((kessaiHoho.equals("1")) ? "0" : "");
        bo.setTsukiGakuKingaku("");
        bo.setTsukiGakuKakutei("");
        bo.setNextKessaiBi("");
        bo.setTsukiGakuKessaiBi("");
        bo.setHukaJohoGetsugakukessaiji("");
        bo.setKakuteiBi("");
        bo.setKoshinKbn("I");
        bo.setTorokuDate(dt.format(date));
        bo.setTorokuTime(tm.format(date));
        bo.setTorokuUserId(inRequest.getMoshikomishaId());
        bo.setKoshinDate("");
        bo.setKoshinTime("");
        bo.setKoshinUserId("");
        bo.setRonriSakujoFlg("");
        inRequest.setKessaiHoho(kessaiHoho);
        inRequest.setSid(inRequest.getMoshikomiUketsukeNo());
        // ���i���P
        inRequest.setN1(shikakuName);
        // ���z�P
        inRequest.setK1(kingaku);
        inRequest.setTax("");
        // ��������(��)
        inRequest.setName1(kanjiShimei.split("\\" + BmaConstants.KESSAI_FUKA_SEPARATOR)[0]);
        // ��������(��)
        inRequest.setName2(kanjiShimei.split("\\" + BmaConstants.KESSAI_FUKA_SEPARATOR)[1]);
        // �J�i����(��)
        inRequest.setKana1(kanaShimei.split("\\" + BmaConstants.KESSAI_FUKA_SEPARATOR)[0]);
        // �J�i����(��)
        inRequest.setKana2(kanaShimei.split("\\" + BmaConstants.KESSAI_FUKA_SEPARATOR)[1]);
        // �X�֔ԍ��P
        inRequest.setYubin1(inRequest.getYubinNo().substring(0, 3));
        // �X�֔ԍ��Q
        inRequest.setYubin2(inRequest.getYubinNo().substring(3, 7));
        // �d�b�ԍ�
        inRequest.setTelNo(StringUtility.cutString(inRequest.getTelNo(), BmaConstants.KESSAI_YOKYU_TEL_MAX_LENGTH));
        // ���[���A�h���X
        inRequest.setMail(inRequest.getMailAddress());
        // �Z���P
        inRequest.setAdr1(StringUtility.cutString(BmaStringUtility.convertHankakuToZenkakuBma(inRequest.getJusho1()), BmaConstants.KESSAI_YOKYU_ADR_MAX_LENGTH));
        // ������
        inRequest.setShiharaiKigen(kigenbi);
    }

    /**
     * �I���`�F�b�N
     *
     * @param InSession
     * @return ��肪�Ȃ���� true�A����� false
     */
    private boolean ValidatorCaller(MskKessaiJoho InSession, String kessaiHoho) throws Exception {
        Messages errors = new Messages();	//���b�Z�[�W�i�[�p
        List<Option> kessaiHohoList = InSession.getKessaiHohoList();
        int length = kessaiHohoList.size();
        String[] hanyocode = new String[length];
        for (int i = 0; i < length; i++) {
            hanyocode[i] = kessaiHohoList.get(i).getValue();
        }
        // ���ϕ��@�F�K�{�`�F�b�N
        BmaValidator.validateSelect(kessaiHoho, errors, BmaConstants.ERR_GROUP_KESSAI_HOHO, BmaConstants.ARG_KESSAI_HOHO);
        // ���ϕ��@�F�Ó����`�F�b�N
        Validator.validatePermissionSelect(kessaiHoho, hanyocode, errors, BmaConstants.ERR_GROUP_KESSAI_HOHO, BmaConstants.ARG_KESSAI_HOHO);
        if (!errors.isEmpty()) {
            InSession.setErrors(errors);
            return false;
        } else {
            return true;
        }
    }

    //�J���}��؂�ɕύX
    public static String formatKingaku(Long kingaku) {
        DecimalFormat df = new DecimalFormat("#,###");
        return df.format(kingaku);
    }
}
