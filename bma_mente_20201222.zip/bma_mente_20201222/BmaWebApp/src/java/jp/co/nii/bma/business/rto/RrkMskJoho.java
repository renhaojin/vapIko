package jp.co.nii.bma.business.rto;

import java.util.ArrayList;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import jp.co.nii.bma.business.service.common.BmaConstants;
import jp.co.nii.bma.utility.BmaDateTimeUtility;
import jp.co.nii.bma.utility.BmaDateUtility;
import jp.co.nii.bma.utility.BmaStringUtility;
import jp.co.nii.bma.utility.BmaUtility;
import jp.co.nii.sew.presentation.AbstractRequestTransferObject;
import jp.co.nii.sew.presentation.Messages;
import jp.co.nii.sew.presentation.Option;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItem;

/**
 * �^�C�g��: �\������ ����: �\������RTO ���쌠: Copyright (c) 2020 ��Ж�: ���{���Y�Ɗ������
 *
 * @author S.WEIBING
 */
public class RrkMskJoho extends AbstractRequestTransferObject {

    private String gazoKbn;
    private String ksuMsk;
    //04-2�\������_�ڍ�(�J�ÑO)��ʃe�X�g�p; �u�K: 1; ����: 2;
    private String dispNayo;
    private String moshikomishaId;
    private String moshikomishaId2;
    //"�\��������ʃ��[�v
    private String sknksuName;
    private String nendo;
    private String kariUketsukeBi;
    private String kariUketsukeTime;
    // �����u�K��R�[�h
    private String sknKsuCode;
    // �\���󋵋敪
    private String moshikomiJokyoKbn;
    private String torokuUserId;

    private String moshikomiFinishTime;
    // �^�p�󋵋敪
    private String unyoJokyoKbn;
    private String gohiJokyoKbn;
    private String shosai;
    private String moshinm;
    private String gohinm;
    private String unyounm;
    private String shubetsuNm;

    private String hanyoCode;
    // �����u�K��敪
    private String sknKsuKbn;
    private String shubetsuCode;
    private String kaisuCode;
    private String shikenNaiyoKbn;
    private String sknKsuSearch;
    private String scheduleCode;

    // ����/��u���ʏ��
    private String juyoResult;
    private String result;
    private String banngo;
    private String yukouKiken;
    private String moshikomiFinishBi;

    //�l���
    private String shimei;
    private String furigana;
    private String birthYmd;
    private String gender;

    private String jukenJukoNo;

    private String yubinNoFront;
    private String yubinNoBack;
    private String jusho1;
    private String jusho2;
    private String tatemono;
    private String telNo;
    private String faxNo;

    private String mailAddress;
    private String kokuseki;
    private String sikenBeforeAfter;

    private String birthDay;
    private String birthYear;
    private String birthMonth;

    private String nenrei;

    //�Ζ�����
    private String kinmusakiName;
    private String kinmusakiYubinFront;
    private String kinmusakiYubinBack;
    private String kinmusakiJusho1;
    private String kinmusakiJusho2;
    private String kinmusakiTatemono;
    private String kinmusakiTelNo;
    private String kinmusakiFaxNo;

    private String jissiJusho;
    //���t��
    private String sofusakiChoice;
    // ���Ɛ\���t���O
    private String genmenFlg;

    //"�\�������摜UPD���">
    private String gazoUpdNotes;
    private String shomeishoruiShubetu;
    private String shomeishoruiUpdStatus;
    private String shomeishoruiUpd;
    private String shomeishoruiKakunin;
    private String jknsikakuShubetu;
    private String jknsikakuUpdStatus;
    private String jknsikakuUpd;
    private String jknsikakuKakunin;
    private String menjoShubetu;
    private String menjoUpdStatus;
    private String menjoUpd;
    private String menjoKakunin;
    // �摜���

    private String gazoUpd;
    private String gazoHyojiKbn;
    private String Upload;
    // ���Ϗ��
    private String kessaiJokyo;
    private String rrkShosaiBack;
    private String rrkShosaiUpDate;
    private String moshikomiListBtn;
    private RrkMskJoho taihi;
    /**
     * �Z�b�V�����p�\�������J�n
     */
    private int firstDisp;
    /**
     * �Z�b�V�����p�\�������ő包��
     */
    private int maxDisp;
    /**
     * �y�[�W�J�ڗp�F�J�ڐ�y�[�W
     */
    private int page;
    /**
     * �y�[�W�J�ڗp�F���ڈړ��Œ�l
     */
    private int pageBegin;
    /**
     * �y�[�W�J�ڗp�F���ڈړ��ő�l
     */
    private int pageEnd;
    /**
     * �y�[�W�J�ڗp�F�ő�y�[�W��
     */
    private int pageMax;
    /**
     * ��������index���X�g
     */
    private List<String> searchOutIndex;

    /**
     * �R�}���h �y�[�W�J��
     */
    private String commandPage;
    /**
     * ��������
     */
    private List<String> dispKeyList;

    /**
     * �ڍ׉�ʑJ�ڑO
     */
    private String syosaiBack;
    /**
     * �ڍ׉�ʑJ�ڌ�
     */
    private String syosaiAfterBack;
    // �\������_�ڍ�(�J�ÑO)_�u�K
    // �����E�u�K�� ���i��� �\������_�ڍ׃C���y�N(�J�ÑO)
    private String isnKsuName;
    private String isnKsuKaijo;
    private String isnKsuKaijoJusho;
    private String isnKsuDate_From;
    private String isnKsuDate_To;
    private String ksuDate_From;
    private String ksuDate_To;
    private String ksuKaijo;
    private String ksuKaijoJusho;

    //�\������_�ڍ׃C���y�N�y�t�H���[�z(�J�ÑO)
    //�����`�[�ԍ�
    private String haraikomiDenpyoNo;
    //�����p�R���r�j
    private String goriyouConvenience;
    // �\������_�ڍ�(�I����)_�u�K
    private String ksuName;

    private String ksuNameSeach;
    private String sknNameSeach;

    private String ksuNendo;
    private String ksujknJkuNo;
    // ���i �s���i
    private String ksuKekka;
    private String ksuNo;
    private String ksuYukokigen;

    //�\������_�ڍ�(�I����)_����
    private String sknName;

    private String sknJissiNendo;
    private String sknJknNaiyou;
    private String sknJknJkuNo;
    private String sknKekka;
    private String sknGokakuTsutiNo;
    private String sknGokakuTsutiNoknGinosiNo;
    private String sknMenjoKikan;
    private String mskShosaiBack;

    private String count;

    // "�\������_�ڍ�(�J�ÑO)_����">
    //����/�u�K����
    private String uketsukeNo;
    private String jknNaiyo;
    private String Jusho;
    private String kibojissiTiku;
    private String gakkaKaijo;
    private String gakkaDate;
    private String jissiKaijo;
    private String jissiDate;
    private String jissiDateFrom;
    private String jissiDateTo;
    //���t����
    private String sofusakiKbn;
    private String sofusakiYubinNo;
    private String sofusakiJusho;
    //���i���
    private String bc2SikakuName;
    private String bc2GokakuNo;
    private String gokakuNo;

    private String moshikomiNinsu;
    private String goukakuNinsu;
    private String itibuGoukakuNinsuGa;
    private String itibuGoukakuNinsuJi;
    private String fuGoukakuNinsu;
    private String moshikomiFubiNinsu;
    private String moshikomiKanriNinsu;

    //�E�����
    private String shokurekiKbn;
    private String shokurekiKbn3;
    private String shokurekiKbn4;

    private String year;
    private String month;

    //�w�����
    private String gakkouName;
    private String gakkouGakka;
    private String gakkouShozaichi;
    private String gakkouSotsugyonengappi;
    //�P�������
    private String kunrenShisetsuName;
    private String kunrenka;
    private String kunrenShozaichi;
    private String kunrenRekiFrom;
    private String kunrenRekiTo;

    //�Ə����
    private String menjoSikenName;
    private String menjoNaiyo;

    //���Ϗ�
    private String kessaiHoho;
    private String kessaiJknjkuryo;
    private String kessaiJimutesuryo;
    private String kessaiGokeiKingaku;
    private String kessaiShiharaiNo;
    private String kessaiShiharaiKigenbi;
    //�y�C�W�[�̏ꍇ
    private String peijiKessaiShunokikanNo;
    private String kessaiUserNo;
    private String kessaiKakuninNo;

    /**
     * �s���{��
     */
    private String todofuken;

    private String kinmusakiTodofuken;

    // ���X�g
    private List<Option> sknKbnList;
    private List<Option> ksuKbnList;
    /**
     * �\���������@���X�g
     */
    private List<RrkMskJoho> rrkMskJohoList;

    /**
     * �\���ҏؖ����ށ@���X�g
     */
    private List<RrkMskJoho> shomeishoList;
    /**
     * �󌟎��i�@���X�g
     */
    private List<RrkMskJoho> jknSikakuList;
    /**
     * �󌟖Ə����i�@���X�g
     */
    private List<RrkMskJoho> menjoList;
    /**
     * �摜�@���X�g
     */
    private List<RrkMskSetToList> gazouList;
    /**
     * ���i�@���X�g
     */
    private List<RrkMskJoho> sikakuList;
    /**
     * �E�����@���X�g
     */
    private List<RrkMskSetToList> shokurekiList;
    /**
     * �s���{�����X�g
     */
    private List<Option> todofukenList;
    /**
     * ���ʃ��X�g
     */
    private List<Option> genderList;
    /**
     * ���t��敪���X�g
     */
    private List<Option> sofusakiList;
    /**
     * �󌟎萔���̌��Ɛ\�����X�g
     */
    private List<Option> genmenList;
    /**
     * ��]���{�n�惊�X�g
     */
    private List<Option> kaisaitiList;
    /**
     * ���N���� �N���X�g
     */
    private List<Option> birthYearList;
    /**
     * ���N���� �����X�g
     */
    private List<Option> birthMonthList;
    /**
     * ���N���� �����X�g
     */
    private List<Option> birthDayList;
    /**
     * �^�p�敪���X�g
     */
    private List<Option> unyouList;
    private List<RrkMskJoho> rrkMskGroupJohoList;

    // �{�^��
    /**
     * �R�}���h �\�������{�^��
     */
    private String mskRrk;
    /**
     * �g�b�v��� �\�����������{�^��
     */
    private String memJohoUpdate;
    /**
     * �g�b�v��� �o�^��񌟍��{�^��
     */
    private String kaiinJohoBtn;
    /**
     * �\�����ύX���͉�ʁ@�߂�{�^��
     */
    private String mskJohoUpdateBack;
    /**
     * �\�����ύX���͉�ʁ@�m�F�{�^��
     */
    private String mskJohoUpdateNext;

    /**
     * ���j���[�@���i�����^��
     */
    private String mskShikaku;
    /**
     * �X�֔ԍ�front
     */
    private String ybnBngFront;
    /**
     * �X�֔ԍ�back
     */
    private String ybnBngBack;
    /**
     * �Z���������̓{�^��
     */
    private String adrSrc;
    /**
     * �Ζ���X�֔ԍ�front
     */
    private String kinmusakiYbnBngFront;
    /**
     * �Ζ���X�֔ԍ�back
     */
    private String kinmusakiYbnBngBack;
    /**
     * �\�����ύX���͉�ʁ@�Ζ�����@�X�֔ԍ������{�^��
     */
    private String kinmusakiAdrSrc;
    /**
     * �\�����͕ύX�m�F��ʁ@�m��{�^��
     */
    private String mskUpdateConfirmKakutei;
    /**
     * �\�����͕ύX�m�F��ʁ@�߂�{�^��
     */
    private String mskUpdateConfirmBack;
    /**
     * �\�����ύX������ʁ@�߂�(�ڍ�)�{�^��
     */
    private String updateCompleteShosai;
    /**
     * �\�������摜UPD�@enter�{�^��
     */
    private String mskGazoUploadEnter;
    /**
     * �\�������摜UPD�@�A�b�v���[�h�{�^��
     */
    private String mskGazoUpload;
    /**
     * �\�������摜UPD�@�߂�{�^��
     */
    private String mskRrkGazoUpdBack;

    /**
     * �ύX�{�^�������s�A�̐���
     */
    private String buttonHekouFlag;
    private String search;
    /**
     * �G���[
     */
    private Messages errors;

    private String kaoImg;
    private String nenreiImg;
    private String shikakuImg;
    private String menjyoImg;
    private String kaoHyojiKbn;
    private String nenreiHyojiKbn;
    private String shikakuHyojiKbn;
    private String menjyoHyojiKbn;
    private String gazoIdx;
    private String uploadCheck;
    private String gazoUpdFlg;
    private DiskFileItem gazoHyoji;
    private FileItem fileItem;
    private String reload;
    
    //"�R���X�g���N�^/������/���N�G�X�g�擾">
    /**
     * �R���X�g���N�^
     */
    public RrkMskJoho() {
        clearInfo();
    }

    /**
     * ���������\�b�h
     */
    public final void clearInfo() {
        setKsuMsk("");
        setDispNayo("");
        setMoshikomishaId("");
        setSknksuName("");
        setNendo("");
        setSknKsuCode("");
        setMoshikomiJokyoKbn("");
        setTorokuUserId("");
        setMoshikomiFinishTime("");
        setUnyoJokyoKbn("");
        setGohiJokyoKbn("");
        setShosai("");
        setMoshinm("");
        setGohinm("");
        setUnyounm("");
        setShubetsuNm("");
        setSknKsuKbn("");
        setShubetsuCode("");
        setKaisuCode("");
        setShikenNaiyoKbn("");
        setSknKsuSearch("1");
        setJuyoResult("");
        setResult("");
        setBanngo("");
        setYukouKiken("");
        setMoshikomiFinishBi("");
        setShimei("");
        setFurigana("");
        setBirthYmd("");
        setGender("");
        setJukenJukoNo("");
        setYubinNoFront("");
        setYubinNoBack("");
        setJusho1("");
        setJusho2("");
        setTatemono("");
        setTelNo("");
        setGazoKbn("");
        setFaxNo("");
        setUploadCheck("");
        setMailAddress("");
        setKokuseki("");
        setSikenBeforeAfter("");
        setBirthDay("");
        setBirthYear("");
        setBirthMonth("");
        setNenrei("");
        setKinmusakiName("");
        setKinmusakiYubinFront("");
        setKinmusakiYubinBack("");
        setKinmusakiJusho1("");
        setKinmusakiJusho2("");
        setKinmusakiTatemono("");
        setKinmusakiTelNo("");
        setKinmusakiFaxNo("");
        setJissiJusho("");
        setSofusakiChoice("");
        setGenmenFlg("");
        setGazoUpdNotes("");
        setShomeishoruiShubetu("");
        setShomeishoruiUpdStatus("");
        setShomeishoruiUpd("");
        setShomeishoruiKakunin("");
        setJknsikakuShubetu("");
        setJknsikakuUpdStatus("");
        setJknsikakuUpd("");
        setJknsikakuKakunin("");
        setMenjoShubetu("");
        setMenjoUpdStatus("");
        setMenjoUpd("");
        setMenjoKakunin("");
        setGazoUpd("");
        setGazoHyojiKbn("");
        setKessaiJokyo("");
        setRrkShosaiBack("");
        setRrkShosaiUpDate("");
        setMoshikomiListBtn("");

        setCommandPage("");

        setSyosaiBack("");
        setSyosaiAfterBack("");
        setIsnKsuName("");
        setIsnKsuKaijo("");
        setIsnKsuKaijoJusho("");
        setIsnKsuDate_From("");
        setIsnKsuDate_To("");
        setKsuDate_From("");
        setKsuDate_To("");
        setKsuKaijo("");
        setKsuKaijoJusho("");
        setHaraikomiDenpyoNo("");
        setGoriyouConvenience("");
        setKsuNendo("");
        setKsujknJkuNo("");
        setKsuKekka("");
        setKsuNo("");
        setKsuYukokigen("");
        setSknJissiNendo("");
        setSknJknNaiyou("");
        setSknJknJkuNo("");
        setSknKekka("");
        setSknGokakuTsutiNo("");
        setSknGokakuTsutiNoknGinosiNo("");
        setSknMenjoKikan("");
        setMskShosaiBack("");
        setCount("");
        setUketsukeNo("");
        setJknNaiyo("");
        setJusho("");
        setKibojissiTiku("");
        setGakkaKaijo("");
        setGakkaDate("");
        setJissiKaijo("");
        setJissiDate("");
        setJissiDateFrom("");
        setJissiDateTo("");
        setSofusakiKbn("");
        setSofusakiYubinNo("");
        setSofusakiJusho("");

        setGokakuNo("");
//        setMoshikomiNinsu("");
//        setGoukakuNinsu("");
//        setItibuGoukakuNinsuGa("");
        setItibuGoukakuNinsuJi("");
        setFuGoukakuNinsu("");
        setMoshikomiFubiNinsu("");
        setMoshikomiKanriNinsu("");
        setShokurekiKbn("");
        setShokurekiKbn3("");
        setShokurekiKbn4("");

        setYear("");
        setMonth("");
        setGakkouName("");
        setGakkouGakka("");
        setGakkouShozaichi("");
        setGakkouSotsugyonengappi("");
        setKunrenShisetsuName("");
        setKunrenka("");
        setKunrenShozaichi("");
        setKunrenRekiFrom("");
        setKunrenRekiTo("");
        setMenjoSikenName("");
        setMenjoNaiyo("");
        setKessaiHoho("");
        setKessaiJknjkuryo("");
        setKessaiJimutesuryo("");
        setKessaiGokeiKingaku("");
        setKessaiShiharaiNo("");
        setKessaiShiharaiKigenbi("");
        setPeijiKessaiShunokikanNo("");
        setKessaiUserNo("");
        setKessaiKakuninNo("");
        setTodofuken("");
        setKinmusakiTodofuken("");

        setSknKbnList(new ArrayList<>());
        setKsuKbnList(new ArrayList<>());
        //setRrkMskJohoList(new ArrayList<>());
        setShomeishoList(new ArrayList<>());
        setJknSikakuList(new ArrayList<>());
        setMenjoList(new ArrayList<>());
        setSikakuList(new ArrayList<>());
        setShokurekiList(new ArrayList<>());
        setTodofukenList(new ArrayList<>());
        setGenderList(new ArrayList<>());
        setSofusakiList(new ArrayList<>());
        setGenmenList(new ArrayList<>());
        setKaisaitiList(new ArrayList<>());
        setBirthYearList(new ArrayList<>());
        setBirthMonthList(new ArrayList<>());
        setBirthDayList(new ArrayList<>());
        setUnyouList(new ArrayList<>());

        setRrkMskGroupJohoList(new ArrayList<>());

        setMskRrk("");
        setMemJohoUpdate("");
        setKaiinJohoBtn("");
        setMskJohoUpdateBack("");
        setMskJohoUpdateNext("");
        setMskShikaku("");
        setYbnBngFront("");
        setYbnBngBack("");
        setAdrSrc("");
        setKinmusakiYbnBngFront("");
        setKinmusakiYbnBngBack("");
        setKinmusakiAdrSrc("");
        setMskUpdateConfirmKakutei("");
        setMskUpdateConfirmBack("");
        setUpdateCompleteShosai("");
        setMskGazoUploadEnter("");
        setMskGazoUpload("");
        setMskRrkGazoUpdBack("");
        setButtonHekouFlag("");
        setSearch("");
        setSknName("");
        setKsuName("");
        setKaoImg("");
        setNenreiImg("");
        setShikakuImg("");
        setMenjyoImg("");
        setKaoHyojiKbn("");
        setNenreiHyojiKbn("");
        setShikakuHyojiKbn("");
        setMenjyoHyojiKbn("");
        setGazoIdx("");
        setErrors(new Messages());

        setSknNameSeach("BC0101");
        setKsuNameSeach("IP1101");
        setReload("");
    }

    /**
     * ���N�G�X�g��������擾���郁�\�b�h
     *
     * @param request ���N�G�X�g
     */
    @Override
    public void copyFromRequest(HttpServletRequest request) {

        setDispNayo((String) request.getAttribute("dispNayo"));

        //�\���������[�v
        setSknksuName((String) request.getAttribute("sknksuName"));
        setNendo((String) request.getAttribute("nendo"));
        setMoshikomiFinishTime((String) request.getAttribute("moshikomiFinishTime"));
        setUnyoJokyoKbn((String) request.getAttribute("unyoJokyoKbn"));
        setShosai((String) request.getAttribute("shosai"));
        setSknKsuCode((String) request.getAttribute("sknKsuCode"));
        setSknKsuKbn((String) request.getAttribute("sknKsuKbn"));
        setShubetsuCode((String) request.getAttribute("shubetsuCode"));
        setKaisuCode((String) request.getAttribute("kaisuCode"));
        setUketsukeNo((String) request.getAttribute("uketsukeNo"));
        setMoshikomiFinishTime((String) request.getAttribute("moshikomiFinishTime"));
        setMoshikomiFinishBi((String) request.getAttribute("moshikomiFinishBi"));
        setYbnBngFront((String) request.getAttribute("ybnBngFront"));
        setYbnBngBack((String) request.getAttribute("ybnBngBack"));
        setAdrSrc((String) request.getAttribute("adrSrc"));
        setShikenNaiyoKbn((String) request.getAttribute("shikenNaiyoKbn"));
        setGohiJokyoKbn((String) request.getAttribute("gohiJokyoKbn"));
        setKinmusakiYbnBngFront((String) request.getAttribute("kinmusakiYbnBngFront"));
        setKinmusakiYbnBngBack((String) request.getAttribute("kinmusakiYbnBngBack"));
        setKinmusakiAdrSrc((String) request.getAttribute("kinmusakiAdrSrc"));
        setSknKsuSearch((String) request.getAttribute("sknKsuSearch"));
        setGazoKbn((String) request.getAttribute("gazoKbn"));
        setSknName((String) request.getAttribute("sknName"));
        setKsuName((String) request.getAttribute("ksuName"));
        setGazoIdx((String) request.getAttribute("gazoIdx"));

        setSknNameSeach((String) request.getAttribute("sknNameSeach"));
        setKsuNameSeach((String) request.getAttribute("ksuNameSeach"));
        // �l���
        setShimei((String) request.getAttribute("shimei"));
        setFurigana((String) request.getAttribute("furigana"));
        setGender((String) request.getAttribute("gender"));

        setJusho1((String) request.getAttribute("jusho1"));
        setJusho2((String) request.getAttribute("jusho2"));
        setTatemono((String) request.getAttribute("tatemono"));
        setTelNo((String) request.getAttribute("telNo"));
        setFaxNo((String) request.getAttribute("faxNo"));
        setMailAddress((String) request.getAttribute("mailAddress"));
        setKokuseki((String) request.getAttribute("kokuseki"));
        setYubinNoFront((String) request.getAttribute("yubinNoFront"));
        setYubinNoBack((String) request.getAttribute("yubinNoBack"));

        setBirthYmd((String) request.getAttribute("birthYmd"));
        setBirthYear((String) request.getAttribute("birthYear"));
        setBirthMonth((String) request.getAttribute("birthMonth"));
        setBirthDay((String) request.getAttribute("birthDay"));

        setTodofuken((String) request.getAttribute("todofuken"));
        setKinmusakiTodofuken((String) request.getAttribute("kinmusakiTodofuken"));

        //�Ζ�����
        setKinmusakiName((String) request.getAttribute("kinmusakiName"));
        setKinmusakiJusho1((String) request.getAttribute("kinmusakiJusho1"));
        setKinmusakiJusho2((String) request.getAttribute("kinmusakiJusho2"));
        setKinmusakiTatemono((String) request.getAttribute("kinmusakiTatemono"));
        setKinmusakiTelNo((String) request.getAttribute("kinmusakiTelNo"));
        setKinmusakiFaxNo((String) request.getAttribute("kinmusakiFaxNo"));

        setKinmusakiYubinFront((String) request.getAttribute("kinmusakiYubinFront"));
        setKinmusakiYubinBack((String) request.getAttribute("kinmusakiYubinBack"));
        //���t��
        setSofusakiChoice((String) request.getAttribute("sofusakiChoice"));

        //�\�������摜UPD���
        setGazoUpdNotes((String) request.getAttribute("gazoUpdNotes"));
        setShomeishoruiShubetu((String) request.getAttribute("shomeishoruiShubetu"));
        setShomeishoruiUpdStatus((String) request.getAttribute("shomeishoruiUpdStatus"));
        setShomeishoruiUpd((String) request.getAttribute("shomeishoruiUpd"));
        setShomeishoruiKakunin((String) request.getAttribute("shomeishoruiKakunin"));
        setJknsikakuShubetu((String) request.getAttribute("jknsikakuShubetu"));
        setJknsikakuUpdStatus((String) request.getAttribute("jknsikakuUpdStatus"));
        setJknsikakuUpd((String) request.getAttribute("jknsikakuUpd"));
        setJknsikakuKakunin((String) request.getAttribute("jknsikakuKakunin"));
        setMenjoShubetu((String) request.getAttribute("menjoShubetu"));
        setMenjoUpdStatus((String) request.getAttribute("menjoUpdStatus"));
        setMenjoUpd((String) request.getAttribute("menjoUpd"));
        setMenjoKakunin((String) request.getAttribute("menjoKakunin"));

        //�o�^��
        setMskRrk((String) request.getAttribute("mskRrk"));
        setMemJohoUpdate((String) request.getAttribute("memJohoUpdate"));
        setKaiinJohoBtn((String) request.getAttribute("kaiinJohoBtn"));
        setMskJohoUpdateBack((String) request.getAttribute("mskJohoUpdateBack"));
        setMskJohoUpdateNext((String) request.getAttribute("mskJohoUpdateNext"));
        setMskShikaku((String) request.getAttribute("mskShikaku"));
        setMskUpdateConfirmKakutei((String) request.getAttribute("mskUpdateConfirmKakutei"));
        setSearch((String) request.getAttribute("search"));
        setMskUpdateConfirmBack((String) request.getAttribute("mskUpdateConfirmBack"));
        setUpdateCompleteShosai((String) request.getAttribute("updateCompleteShosai"));
        setMskGazoUpload((String) request.getAttribute("mskGazoUpload"));
        setMskRrkGazoUpdBack((String) request.getAttribute("mskRrkGazoUpdBack"));

        setSknKsuKbn((String) request.getAttribute("sknKsuKbn"));

        setGazoUpd((String) request.getAttribute("gazoUpd"));
        setKessaiJokyo((String) request.getAttribute("kessaiJokyo"));
        setRrkShosaiBack((String) request.getAttribute("rrkShosaiBack"));
        setRrkShosaiUpDate((String) request.getAttribute("rrkShosaiUpDate"));
        setMoshikomiListBtn((String) request.getAttribute("moshikomiListBtn"));
        //���i���
        setKsuMsk((String) request.getAttribute("ksuMsk"));
        setIsnKsuName((String) request.getAttribute("isnKsuName"));
        setIsnKsuKaijo((String) request.getAttribute("isnKsuKaijo"));
        setIsnKsuKaijoJusho((String) request.getAttribute("isnKsuKaijoJusho"));
        setIsnKsuDate_From((String) request.getAttribute("isnKsuDate_From"));
        setIsnKsuDate_To((String) request.getAttribute("isnKsuDate_To"));
        setKsuDate_From((String) request.getAttribute("ksuDate_From"));
        setKsuDate_To((String) request.getAttribute("ksuDate_To"));
        setKsuKaijo((String) request.getAttribute("ksuKaijo"));
        setKsuKaijoJusho((String) request.getAttribute("ksuKaijoJusho"));
        setSyosaiBack((String) request.getAttribute("syosaiBack"));
        setSyosaiAfterBack((String) request.getAttribute("syosaiAfterBack"));
        setCommandPage((String) request.getAttribute("commandPage"));
        //�\������_�ڍ׃C���y�N�y�t�H���[�z(�J�ÑO)
        setHaraikomiDenpyoNo((String) request.getAttribute("haraikomiDenpyoNo"));
        setGoriyouConvenience((String) request.getAttribute("goriyouConvenience"));
        setIsnKsuDate_From((String) request.getAttribute("isnKsuDate_From"));
        setKaoImg((String) request.getAttribute("kaoImg"));
        setNenreiImg((String) request.getAttribute("nenreiImg"));
        setShikakuImg((String) request.getAttribute("shikakuImg"));
        setMenjyoImg((String) request.getAttribute("menjyoImg"));
        setKaoHyojiKbn((String) request.getAttribute("kaoHyojiKbn"));
        setNenreiHyojiKbn((String) request.getAttribute("nenreiHyojiKbn"));
        setShikakuHyojiKbn((String) request.getAttribute("shikakuHyojiKbn"));
        setMenjyoHyojiKbn((String) request.getAttribute("menjyoHyojiKbn"));
        setMoshikomishaId2((String) request.getAttribute("moshikomishaId2"));
        setReload((String) request.getAttribute("reload"));
        HttpSession session = request.getSession(false);
        if (session.getAttribute("TopJoho") != null) {
            TopJoho tmp = (TopJoho) session.getAttribute("TopJoho");
            setMoshikomishaId(tmp.getMoshikomishaId());
            setTorokuUserId(tmp.getTorokuUserId());
        }
        if (session.getAttribute("MskGazoJoho") != null) {
            MskGazoJoho tmp = (MskGazoJoho) session.getAttribute("MskGazoJoho");
            setUploadCheck(tmp.getUploadCheck());
            setShomeishoList((List<RrkMskJoho>) tmp.getRrkShomeishoList());
            setJknSikakuList((List<RrkMskJoho>) tmp.getRrkJknSikakuList());
            setMenjoList((List<RrkMskJoho>) tmp.getRrkMenjoList());
        }
    }

    public String getKsuMsk() {
        return ksuMsk;
    }

    public void setKsuMsk(String ksuMsk) {
        this.ksuMsk = ksuMsk;
    }

    public String getGenderDisp() {
        String str = "";
        if (this.getGender().equals(BmaConstants.SEX_CODE_MALE)) {
            str = "�j��";
        } else if (this.getGender().equals(BmaConstants.SEX_CODE_FEMALE)) {
            str = "����";
        }
        return str;
    }

    public Messages getErrors() {
        return errors;
    }

    public void setErrors(Messages errors) {
        this.errors = errors;
    }

    public String getHaraikomiDenpyoNo() {
        return haraikomiDenpyoNo;
    }

    public void setHaraikomiDenpyoNo(String haraikomiDenpyoNo) {
        this.haraikomiDenpyoNo = haraikomiDenpyoNo;
    }

    public String getGoriyouConvenience() {
        return goriyouConvenience;
    }

    public void setGoriyouConvenience(String goriyouConvenience) {
        this.goriyouConvenience = goriyouConvenience;
    }

    public String getSknksuName() {
        return sknksuName;
    }

    public void setSknksuName(String sknksuName) {
        this.sknksuName = sknksuName;
    }

    public String getNendo() {
        return nendo;
    }

    public void setNendo(String nendo) {
        this.nendo = nendo;
    }

    public String getMoshikomiFinishTime() {
        return moshikomiFinishTime;
    }

    public void setMoshikomiFinishTime(String moshikomiFinishTime) {
        this.moshikomiFinishTime = moshikomiFinishTime;
    }

    public String getUnyoJokyoKbn() {
        return unyoJokyoKbn;
    }

    public void setUnyoJokyoKbn(String unyoJokyoKbn) {
        this.unyoJokyoKbn = unyoJokyoKbn;
    }

    /**
     * �^�p�󋵖��̂̕\����Ԃ�
     *
     * @return
     */
    public String getUnyoJokyoKbnDisp() {
        String ret = "";
        if (BmaUtility.isNullOrEmpty(getUnyoJokyoKbn())) {
            return ret;
        }
        for (Option option : getUnyouList()) {
            if (option.getValue().equals(getUnyoJokyoKbn())) {
                ret = option.getLabel();
                break;
            }
        }
        return ret;
    }

    public String getShosai() {
        return shosai;
    }

    public void setShosai(String shosai) {
        this.shosai = shosai;
    }

    public String getMskRrk() {
        return mskRrk;
    }

    public void setMskRrk(String mskRrk) {
        this.mskRrk = mskRrk;
    }

    public List<RrkMskJoho> getRrkMskJohoList() {
        return rrkMskJohoList;
    }

    public void setRrkMskJohoList(List<RrkMskJoho> rrkMskJohoList) {
        this.rrkMskJohoList = rrkMskJohoList;
    }

    public String getMemJohoUpdate() {
        return memJohoUpdate;
    }

    public void setMemJohoUpdate(String memJohoUpdate) {
        this.memJohoUpdate = memJohoUpdate;
    }

    public String getKaiinJohoBtn() {
        return kaiinJohoBtn;
    }

    public void setKaiinJohoBtn(String kaiinJohoBtn) {
        this.kaiinJohoBtn = kaiinJohoBtn;
    }

    public String getShimei() {
        return shimei;
    }

    public void setShimei(String shimei) {
        this.shimei = shimei;
    }

    public String getFurigana() {
        return furigana;
    }

    public void setFurigana(String furigana) {
        this.furigana = furigana;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getJusho1() {
        return jusho1;
    }

    public void setJusho1(String jusho1) {
        this.jusho1 = jusho1;
    }

    public String getJusho2() {
        return jusho2;
    }

    public void setJusho2(String jusho2) {
        this.jusho2 = jusho2;
    }

    public String getTatemono() {
        return tatemono;
    }

    public void setTatemono(String tatemono) {
        this.tatemono = tatemono;
    }

    public String getTelNo() {
        return telNo;
    }

    public void setTelNo(String telNo) {
        this.telNo = telNo;
    }

    public String getFaxNo() {
        return faxNo;
    }

    public void setFaxNo(String faxNo) {
        this.faxNo = faxNo;
    }

    public String getMailAddress() {
        return mailAddress;
    }

    public void setMailAddress(String mailAddress) {
        this.mailAddress = mailAddress;
    }

    public String getKokuseki() {
        return kokuseki;
    }

    public void setKokuseki(String kokuseki) {
        this.kokuseki = kokuseki;
    }

    public String getYubinNoFront() {
        return yubinNoFront;
    }

    public void setYubinNoFront(String yubinNoFront) {
        this.yubinNoFront = yubinNoFront;
    }

    public String getYubinNoBack() {
        return yubinNoBack;
    }

    public void setYubinNoBack(String yubinNoBack) {
        this.yubinNoBack = yubinNoBack;
    }

    public String getKinmusakiName() {
        return kinmusakiName;
    }

    public void setKinmusakiName(String kinmusakiName) {
        this.kinmusakiName = kinmusakiName;
    }

    public String getKinmusakiJusho1() {
        return kinmusakiJusho1;
    }

    public void setKinmusakiJusho1(String kinmusakiJusho1) {
        this.kinmusakiJusho1 = kinmusakiJusho1;
    }

    public String getKinmusakiJusho2() {
        return kinmusakiJusho2;
    }

    public void setKinmusakiJusho2(String kinmusakiJusho2) {
        this.kinmusakiJusho2 = kinmusakiJusho2;
    }

    public String getKinmusakiTatemono() {
        return kinmusakiTatemono;
    }

    public void setKinmusakiTatemono(String kinmusakiTatemono) {
        this.kinmusakiTatemono = kinmusakiTatemono;
    }

    public String getKinmusakiTelNo() {
        return kinmusakiTelNo;
    }

    public void setKinmusakiTelNo(String kinmusakiTelNo) {
        this.kinmusakiTelNo = kinmusakiTelNo;
    }

    public String getKinmusakiFaxNo() {
        return kinmusakiFaxNo;
    }

    public void setKinmusakiFaxNo(String kinmusakiFaxNo) {
        this.kinmusakiFaxNo = kinmusakiFaxNo;
    }

    public String getSofusakiChoice() {
        return sofusakiChoice;
    }

    public void setSofusakiChoice(String sofusakiChoice) {
        this.sofusakiChoice = sofusakiChoice;
    }

    public String getGenmenFlg() {
        return genmenFlg;
    }

    public void setGenmenFlg(String genmenFlg) {
        this.genmenFlg = genmenFlg;
    }

    public String getMskJohoUpdateBack() {
        return mskJohoUpdateBack;
    }

    public void setMskJohoUpdateBack(String mskJohoUpdateBack) {
        this.mskJohoUpdateBack = mskJohoUpdateBack;
    }

    public String getMskJohoUpdateNext() {
        return mskJohoUpdateNext;
    }

    public void setMskJohoUpdateNext(String mskJohoUpdateNext) {
        this.mskJohoUpdateNext = mskJohoUpdateNext;
    }

    public String getKinmusakiYubinFront() {
        return kinmusakiYubinFront;
    }

    public void setKinmusakiYubinFront(String kinmusakiYubinFront) {
        this.kinmusakiYubinFront = kinmusakiYubinFront;
    }

    public String getKinmusakiYubinBack() {
        return kinmusakiYubinBack;
    }

    public void setKinmusakiYubinBack(String kinmusakiYubinBack) {
        this.kinmusakiYubinBack = kinmusakiYubinBack;
    }

    /**
     * �X�֔ԍ�front
     *
     * @return the ybnBngFront
     */
    public String getYbnBngFront() {
        return ybnBngFront;
    }

    /**
     * �X�֔ԍ�front
     *
     * @param ybnBngFront the ybnBngFront to set
     */
    public void setYbnBngFront(String ybnBngFront) {
        this.ybnBngFront = ybnBngFront;
    }

    /**
     * �X�֔ԍ�back
     *
     * @return the ybnBngBack
     */
    public String getYbnBngBack() {
        return ybnBngBack;
    }

    /**
     * �X�֔ԍ�back
     *
     * @param ybnBngBack the ybnBngBack to set
     */
    public void setYbnBngBack(String ybnBngBack) {
        this.ybnBngBack = ybnBngBack;
    }

    /**
     * �Z���������̓{�^��
     *
     * @return the adrSrc
     */
    public String getAdrSrc() {
        return adrSrc;
    }

    /**
     * �Z���������̓{�^��
     *
     * @param adrSrc the adrSrc to set
     */
    public void setAdrSrc(String adrSrc) {
        this.adrSrc = adrSrc;
    }

    public String getKinmusakiAdrSrc() {
        return kinmusakiAdrSrc;
    }

    public void setKinmusakiAdrSrc(String kinmusakiAdrSrc) {
        this.kinmusakiAdrSrc = kinmusakiAdrSrc;
    }

    public String getMskUpdateConfirmKakutei() {
        return mskUpdateConfirmKakutei;
    }

    public void setMskUpdateConfirmKakutei(String mskUpdateConfirmKakutei) {
        this.mskUpdateConfirmKakutei = mskUpdateConfirmKakutei;
    }

    public String getMskUpdateConfirmBack() {
        return mskUpdateConfirmBack;
    }

    public void setMskUpdateConfirmBack(String mskUpdateConfirmBack) {
        this.mskUpdateConfirmBack = mskUpdateConfirmBack;
    }

    public String getUpdateCompleteShosai() {
        return updateCompleteShosai;
    }

    public void setUpdateCompleteShosai(String updateCompleteShosai) {
        this.updateCompleteShosai = updateCompleteShosai;
    }

    public String getMskGazoUpload() {
        return mskGazoUpload;
    }

    public void setMskGazoUpload(String mskGazoUpload) {
        this.mskGazoUpload = mskGazoUpload;
    }

    public String getGazoUpdNotes() {
        return gazoUpdNotes;
    }

    public void setGazoUpdNotes(String gazoUpdNotes) {
        this.gazoUpdNotes = gazoUpdNotes;
    }

    public String getShomeishoruiShubetu() {
        return shomeishoruiShubetu;
    }

    public void setShomeishoruiShubetu(String shomeishoruiShubetu) {
        this.shomeishoruiShubetu = shomeishoruiShubetu;
    }

    public String getShomeishoruiUpdStatus() {
        return shomeishoruiUpdStatus;
    }

    public void setShomeishoruiUpdStatus(String shomeishoruiUpdStatus) {
        this.shomeishoruiUpdStatus = shomeishoruiUpdStatus;
    }

    public String getShomeishoruiUpd() {
        return shomeishoruiUpd;
    }

    public void setShomeishoruiUpd(String shomeishoruiUpd) {
        this.shomeishoruiUpd = shomeishoruiUpd;
    }

    public String getShomeishoruiKakunin() {
        return shomeishoruiKakunin;
    }

    public void setShomeishoruiKakunin(String shomeishoruiKakunin) {
        this.shomeishoruiKakunin = shomeishoruiKakunin;
    }

    public String getJknsikakuShubetu() {
        return jknsikakuShubetu;
    }

    public void setJknsikakuShubetu(String jknsikakuShubetu) {
        this.jknsikakuShubetu = jknsikakuShubetu;
    }

    public String getJknsikakuUpdStatus() {
        return jknsikakuUpdStatus;
    }

    public void setJknsikakuUpdStatus(String jknsikakuUpdStatus) {
        this.jknsikakuUpdStatus = jknsikakuUpdStatus;
    }

    public String getJknsikakuUpd() {
        return jknsikakuUpd;
    }

    public void setJknsikakuUpd(String jknsikakuUpd) {
        this.jknsikakuUpd = jknsikakuUpd;
    }

    public String getJknsikakuKakunin() {
        return jknsikakuKakunin;
    }

    public void setJknsikakuKakunin(String jknsikakuKakunin) {
        this.jknsikakuKakunin = jknsikakuKakunin;
    }

    public String getMenjoShubetu() {
        return menjoShubetu;
    }

    public void setMenjoShubetu(String menjoShubetu) {
        this.menjoShubetu = menjoShubetu;
    }

    public String getMenjoUpdStatus() {
        return menjoUpdStatus;
    }

    public void setMenjoUpdStatus(String menjoUpdStatus) {
        this.menjoUpdStatus = menjoUpdStatus;
    }

    public String getMenjoUpd() {
        return menjoUpd;
    }

    public void setMenjoUpd(String menjoUpd) {
        this.menjoUpd = menjoUpd;
    }

    public String getMenjoKakunin() {
        return menjoKakunin;
    }

    public void setMenjoKakunin(String menjoKakunin) {
        this.menjoKakunin = menjoKakunin;
    }

    public String getMskGazoUploadEnter() {
        return mskGazoUploadEnter;
    }

    public void setMskGazoUploadEnter(String mskGazoUploadEnter) {
        this.mskGazoUploadEnter = mskGazoUploadEnter;
    }

    public String getMskRrkGazoUpdBack() {
        return mskRrkGazoUpdBack;
    }

    public void setMskRrkGazoUpdBack(String mskRrkGazoUpdBack) {
        this.mskRrkGazoUpdBack = mskRrkGazoUpdBack;
    }

    public List<RrkMskJoho> getShomeishoList() {
        return shomeishoList;
    }

    public void setShomeishoList(List<RrkMskJoho> shomeishoList) {
        this.shomeishoList = shomeishoList;
    }

    public List<RrkMskJoho> getJknSikakuList() {
        return jknSikakuList;
    }

    public void setJknSikakuList(List<RrkMskJoho> jknSikakuList) {
        this.jknSikakuList = jknSikakuList;
    }

    public List<RrkMskJoho> getMenjoList() {
        return menjoList;
    }

    public void setMenjoList(List<RrkMskJoho> menjoList) {
        this.menjoList = menjoList;
    }

    public String getBirthDay() {
        return birthDay;
    }

    public void setBirthDay(String birthDay) {
        this.birthDay = birthDay;
    }

    public String getBirthYear() {
        return birthYear;
    }

    public void setBirthYear(String birthYear) {
        this.birthYear = birthYear;
    }

    public String getBirthMonth() {
        return birthMonth;
    }

    public void setBirthMonth(String birthMonth) {
        this.birthMonth = birthMonth;
    }

    public String getNenrei() {
        return nenrei;
    }

    public void setNenrei(String nenrei) {
        this.nenrei = nenrei;
    }

    public List<RrkMskSetToList> getGazouList() {
        return gazouList;
    }

    public void setGazouList(List<RrkMskSetToList> gazouList) {
        this.gazouList = gazouList;
    }

    public List<RrkMskJoho> getSikakuList() {
        return sikakuList;
    }

    public void setSikakuList(List<RrkMskJoho> sikakuList) {
        this.sikakuList = sikakuList;
    }

    public String getIsnKsuName() {
        return isnKsuName;
    }

    public String getIsnKsuKaijo() {
        return isnKsuKaijo;
    }

    public String getIsnKsuKaijoJusho() {
        return isnKsuKaijoJusho;
    }

    public String getIsnKsuDate_From() {
        return isnKsuDate_From;
    }

    public String getIsnKsuDate_To() {
        return isnKsuDate_To;
    }

    public void setIsnKsuName(String isnKsuName) {
        this.isnKsuName = isnKsuName;
    }

    public void setIsnKsuKaijo(String isnKsuKaijo) {
        this.isnKsuKaijo = isnKsuKaijo;
    }

    public void setIsnKsuKaijoJusho(String isnKsuKaijoJusho) {
        this.isnKsuKaijoJusho = isnKsuKaijoJusho;
    }

    public void setIsnKsuDate_From(String isnKsuDate_From) {
        this.isnKsuDate_From = isnKsuDate_From;
    }

    public void setIsnKsuDate_To(String isnKsuDate_To) {
        this.isnKsuDate_To = isnKsuDate_To;
    }

    public String getJusho() {
        return Jusho;
    }

    public void setJusho(String Jusho) {
        this.Jusho = Jusho;
    }

    public String getSknName() {
        return sknName;
    }

    public String getSknJissiNendo() {
        return sknJissiNendo;
    }

    public String getSknJknNaiyou() {
        return sknJknNaiyou;
    }

    public String getSknJknJkuNo() {
        return sknJknJkuNo;
    }

    public String getSknKekka() {
        return sknKekka;
    }

    public String getSknGokakuTsutiNo() {
        return sknGokakuTsutiNo;
    }

    public String getSknGokakuTsutiNoknGinosiNo() {
        return sknGokakuTsutiNoknGinosiNo;
    }

    public String getSknMenjoKikan() {
        return sknMenjoKikan;
    }

    public String getMskShosaiBack() {
        return mskShosaiBack;
    }

    public void setSknName(String sknName) {
        this.sknName = sknName;
    }

    public void setSknJissiNendo(String sknJissiNendo) {
        this.sknJissiNendo = sknJissiNendo;
    }

    public void setSknJknNaiyou(String sknJknNaiyou) {
        this.sknJknNaiyou = sknJknNaiyou;
    }

    public void setSknJknJkuNo(String sknJknJkuNo) {
        this.sknJknJkuNo = sknJknJkuNo;
    }

    public void setSknKekka(String sknKekka) {
        this.sknKekka = sknKekka;
    }

    public void setSknGokakuTsutiNo(String sknGokakuTsutiNo) {
        this.sknGokakuTsutiNo = sknGokakuTsutiNo;
    }

    public void setSknGokakuTsutiNoknGinosiNo(String sknGokakuTsutiNoknGinosiNo) {
        this.sknGokakuTsutiNoknGinosiNo = sknGokakuTsutiNoknGinosiNo;
    }

    public void setSknMenjoKikan(String sknMenjoKikan) {
        this.sknMenjoKikan = sknMenjoKikan;
    }

    public void setMskShosaiBack(String mskShosaiBack) {
        this.mskShosaiBack = mskShosaiBack;
    }

    public String getKsuName() {
        return ksuName;
    }

    public void setKsuName(String ksuName) {
        this.ksuName = ksuName;
    }

    public String getKsujknJkuNo() {
        return ksujknJkuNo;
    }

    public String getKsuKekka() {
        return ksuKekka;
    }

    public String getKsuNo() {
        return ksuNo;
    }

    public String getKsuYukokigen() {
        return ksuYukokigen;
    }

    public void setKsujknJkuNo(String ksujknJkuNo) {
        this.ksujknJkuNo = ksujknJkuNo;
    }

    public void setKsuKekka(String ksuKekka) {
        this.ksuKekka = ksuKekka;
    }

    public void setKsuNo(String ksuNo) {
        this.ksuNo = ksuNo;
    }

    public void setKsuYukokigen(String ksuYukokigen) {
        this.ksuYukokigen = ksuYukokigen;
    }

    public String getDispNayo() {
        return dispNayo;
    }

    public void setDispNayo(String dispNayo) {
        this.dispNayo = dispNayo;
    }

    public String getUketsukeNo() {
        return uketsukeNo;
    }

    public void setUketsukeNo(String uketsukeNo) {
        this.uketsukeNo = uketsukeNo;
    }

    public String getKibojissiTiku() {
        return kibojissiTiku;
    }

    public void setKibojissiTiku(String kibojissiTiku) {
        this.kibojissiTiku = kibojissiTiku;
    }

    public String getGakkaKaijo() {
        return gakkaKaijo;
    }

    public void setGakkaKaijo(String gakkaKaijo) {
        this.gakkaKaijo = gakkaKaijo;
    }

    public String getGakkaDate() {
        return gakkaDate;
    }

    public void setGakkaDate(String gakkaDate) {
        this.gakkaDate = gakkaDate;
    }

    public String getJissiKaijo() {
        return jissiKaijo;
    }

    public void setJissiKaijo(String jissiKaijo) {
        this.jissiKaijo = jissiKaijo;
    }

    public String getJissiDate() {
        return jissiDate;
    }

    public void setJissiDate(String jissiDate) {
        this.jissiDate = jissiDate;
    }

    public String getBc2SikakuName() {
        return bc2SikakuName;
    }

    public void setBc2SikakuName(String bc2SikakuName) {
        this.bc2SikakuName = bc2SikakuName;
    }

    public String getBc2GokakuNo() {
        return bc2GokakuNo;
    }

    public void setBc2GokakuNo(String bc2GokakuNo) {
        this.bc2GokakuNo = bc2GokakuNo;
    }

    public String getGakkouName() {
        return gakkouName;
    }

    public void setGakkouName(String gakkouName) {
        this.gakkouName = gakkouName;
    }

    public String getGakkouGakka() {
        return gakkouGakka;
    }

    public void setGakkouGakka(String gakkouGakka) {
        this.gakkouGakka = gakkouGakka;
    }

    public String getGakkouShozaichi() {
        return gakkouShozaichi;
    }

    public void setGakkouShozaichi(String gakkouShozaichi) {
        this.gakkouShozaichi = gakkouShozaichi;
    }

    public String getGakkouSotsugyonengappi() {
        return gakkouSotsugyonengappi;
    }

    public void setGakkouSotsugyonengappi(String gakkouSotsugyonengappi) {
        this.gakkouSotsugyonengappi = gakkouSotsugyonengappi;
    }

    public String getGakkouSotsugyonengappiDisp() {
        return BmaDateTimeUtility.formatYMToDateString(gakkouSotsugyonengappi);
    }

    public String getKunrenRekiFromDisp() {
        return BmaDateTimeUtility.formatYMToDateString(kunrenRekiFrom) + "�`" + BmaDateTimeUtility.formatYMToDateString(kunrenRekiTo);
    }

    public String getKunrenRekiTo() {
        return kunrenRekiTo;
    }

    public void setKunrenRekiTo(String kunrenRekiTo) {
        this.kunrenRekiTo = kunrenRekiTo;
    }

    public String getKsuYukokigenDisp() {
        return BmaDateTimeUtility.formatYMDToDateString(ksuYukokigen);
    }

    public String getGakkaDateDisp() {
        return BmaDateUtility.convertYmdhmToMDWeekDay_nZenkaku(gakkaDate);
    }

    public String getJissiDateDisp() {
        return BmaDateUtility.convertYmdhmToMDWeekDay_nZenkaku(jissiDate);
    }

    public String getJissiDateFromToDisp() {
        if (jissiDateFrom.isEmpty() && jissiDateTo.isEmpty()) {
            return "";
        } else {
            return BmaDateUtility.convertYmdhmToMDWeekDay_nZenkaku(jissiDateFrom) + "�`" + BmaDateUtility.convertYmdhmToMDWeekDay_nZenkaku(jissiDateTo);
        }
    }

    public String getJissiDateFrom() {
        return jissiDateFrom;
    }

    public void setJissiDateFrom(String jissiDateFrom) {
        this.jissiDateFrom = jissiDateFrom;
    }

    public String getJissiDateTo() {
        return jissiDateTo;
    }

    public void setJissiDateTo(String jissiDateTo) {
        this.jissiDateTo = jissiDateTo;
    }

    public String getKunrenShisetsuName() {
        return kunrenShisetsuName;
    }

    public void setKunrenShisetsuName(String kunrenShisetsuName) {
        this.kunrenShisetsuName = kunrenShisetsuName;
    }

    public String getKunrenka() {
        return kunrenka;
    }

    public void setKunrenka(String kunrenka) {
        this.kunrenka = kunrenka;
    }

    public String getKunrenShozaichi() {
        return kunrenShozaichi;
    }

    public void setKunrenShozaichi(String kunrenShozaichi) {
        this.kunrenShozaichi = kunrenShozaichi;
    }

    public String getKunrenRekiFrom() {
        return kunrenRekiFrom;
    }

    public void setKunrenRekiFrom(String kunrenRekiFrom) {
        this.kunrenRekiFrom = kunrenRekiFrom;
    }

    public String getMenjoSikenName() {
        return menjoSikenName;
    }

    public void setMenjoSikenName(String menjoSikenName) {
        this.menjoSikenName = menjoSikenName;
    }

    public String getMenjoNaiyo() {
        return menjoNaiyo;
    }

    public void setMenjoNaiyo(String menjoNaiyo) {
        this.menjoNaiyo = menjoNaiyo;
    }

    public String getKessaiHoho() {
        return kessaiHoho;
    }

    public void setKessaiHoho(String kessaiHoho) {
        this.kessaiHoho = kessaiHoho;
    }

    public String getKessaiJknjkuryo() {
        return kessaiJknjkuryo;
    }

    public void setKessaiJknjkuryo(String kessaiJknjkuryo) {
        this.kessaiJknjkuryo = kessaiJknjkuryo;
    }

    public String getKessaiJimutesuryo() {
        return kessaiJimutesuryo;
    }

    public void setKessaiJimutesuryo(String kessaiJimutesuryo) {
        this.kessaiJimutesuryo = kessaiJimutesuryo;
    }

    public String getKessaiGokeiKingaku() {
        return kessaiGokeiKingaku;
    }

    public void setKessaiGokeiKingaku(String kessaiGokeiKingaku) {
        this.kessaiGokeiKingaku = kessaiGokeiKingaku;
    }

    public String getKessaiShiharaiNo() {
        return kessaiShiharaiNo;
    }

    public void setKessaiShiharaiNo(String kessaiShiharaiNo) {
        this.kessaiShiharaiNo = kessaiShiharaiNo;
    }

    public String getKessaiShiharaiKigenbiDisp() {
        return BmaDateTimeUtility.formatYMDToDateString(kessaiShiharaiKigenbi);
    }

    public String getKessaiShiharaiKigenbi() {
        return kessaiShiharaiKigenbi;
    }

    public void setKessaiShiharaiKigenbi(String kessaiShiharaiKigenbi) {
        this.kessaiShiharaiKigenbi = kessaiShiharaiKigenbi;
    }

    public String getPeijiKessaiShunokikanNo() {
        return peijiKessaiShunokikanNo;
    }

    public void setPeijiKessaiShunokikanNo(String peijiKessaiShunokikanNo) {
        this.peijiKessaiShunokikanNo = peijiKessaiShunokikanNo;
    }

    public String getKessaiUserNo() {
        return kessaiUserNo;
    }

    public void setKessaiUserNo(String kessaiUserNo) {
        this.kessaiUserNo = kessaiUserNo;
    }

    public String getKessaiKakuninNo() {
        return kessaiKakuninNo;
    }

    public void setKessaiKakuninNo(String kessaiKakuninNo) {
        this.kessaiKakuninNo = kessaiKakuninNo;
    }

    public List<RrkMskSetToList> getShokurekiList() {
        return shokurekiList;
    }

    public void setShokurekiList(List<RrkMskSetToList> shokurekiList) {
        this.shokurekiList = shokurekiList;
    }

    public String getJknNaiyo() {
        return jknNaiyo;
    }

    public void setJknNaiyo(String jknNaiyo) {
        this.jknNaiyo = jknNaiyo;
    }

    public String getSofusakiKbn() {
        return sofusakiKbn;
    }

    public void setSofusakiKbn(String sofusakiKbn) {
        this.sofusakiKbn = sofusakiKbn;
    }

    public String getSofusakiYubinNo() {
        return sofusakiYubinNo;
    }

    public void setSofusakiYubinNo(String sofusakiYubinNo) {
        this.sofusakiYubinNo = sofusakiYubinNo;
    }

    public String getSofusakiJusho() {
        return sofusakiJusho;
    }

    public void setSofusakiJusho(String sofusakiJusho) {
        this.sofusakiJusho = sofusakiJusho;
    }

    public String getKsuDate_From() {
        return ksuDate_From;
    }

    public void setKsuDate_From(String ksuDate_From) {
        this.ksuDate_From = ksuDate_From;
    }

    public String getKsuDate_To() {
        return ksuDate_To;
    }

    public void setKsuDate_To(String ksuDate_To) {
        this.ksuDate_To = ksuDate_To;
    }

    public String getKsuKaijo() {
        return ksuKaijo;
    }

    public void setKsuKaijo(String ksuKaijo) {
        this.ksuKaijo = ksuKaijo;
    }

    public String getKsuKaijoJusho() {
        return ksuKaijoJusho;
    }

    public void setKsuKaijoJusho(String ksuKaijoJusho) {
        this.ksuKaijoJusho = ksuKaijoJusho;
    }

    public String getShubetsuNm() {
        return shubetsuNm;
    }

    public void setShubetsuNm(String shubetsuNm) {
        this.shubetsuNm = shubetsuNm;
    }

    public void setMoshinm(String moshinm) {
        this.moshinm = moshinm;
    }

    public void setGohinm(String gohinm) {
        this.gohinm = gohinm;
    }

    public String getMoshinm() {
        return moshinm;
    }

    public String getGohinm() {
        return gohinm;
    }

    public String getMoshikomishaId() {
        return moshikomishaId;
    }

    public void setMoshikomishaId(String moshikomishaId) {
        this.moshikomishaId = moshikomishaId;
    }

    public String getSknKsuCode() {
        return sknKsuCode;
    }

    public void setSknKsuCode(String sknKsuCode) {
        this.sknKsuCode = sknKsuCode;
    }

    public String getSknKsuKbn() {
        return sknKsuKbn;
    }

    public String getShubetsuCode() {
        return shubetsuCode;
    }

    public String getKaisuCode() {
        return kaisuCode;
    }

    public void setSknKsuKbn(String sknKsuKbn) {
        this.sknKsuKbn = sknKsuKbn;
    }

    public void setShubetsuCode(String shubetsuCode) {
        this.shubetsuCode = shubetsuCode;
    }

    public void setKaisuCode(String kaisuCode) {
        this.kaisuCode = kaisuCode;
    }

    public String getShokurekiKbn() {
        return shokurekiKbn;
    }

    public void setShokurekiKbn(String shokurekiKbn) {
        this.shokurekiKbn = shokurekiKbn;
    }

    public String getYukouKikenDisp() {
        return BmaDateTimeUtility.formatYMDToDateString(yukouKiken);
    }

    public String getBirthYmdDisp() {
        return BmaDateTimeUtility.formatYMDToDateString(birthYmd);
    }

    public String getKessaiGokeiKingakuDisp() {
        return BmaStringUtility.editComma(kessaiGokeiKingaku) + "�~";
    }

    public String getkessaiJimutesuryoDisp() {
        return BmaStringUtility.editComma(kessaiJimutesuryo) + "�~";
    }

    public String getkessaiJknjkuryoDisp() {
        return BmaStringUtility.editComma(kessaiJknjkuryo) + "�~";
    }

    public String getShokurekiKbn3() {
        return shokurekiKbn3;
    }

    public String getShokurekiKbn4() {
        return shokurekiKbn4;
    }

    public void setShokurekiKbn3(String shokurekiKbn3) {
        this.shokurekiKbn3 = shokurekiKbn3;
    }

    public void setShokurekiKbn4(String shokurekiKbn4) {
        this.shokurekiKbn4 = shokurekiKbn4;
    }

    public String getYear() {
        return year;
    }

    public String getMonth() {
        return month;
    }

    public void setYear(String year) {
        this.year = year;
    }

    public void setMonth(String month) {
        this.month = month;
    }

    public String getKsuNendo() {
        return ksuNendo;
    }

    public String getKsuNendoDisp() {
        if (ksuNendo.isEmpty()) {
            return "";
        } else {
            return ksuNendo + "�N�x";
        }
    }

    public void setKsuNendo(String ksuNendo) {
        this.ksuNendo = ksuNendo;
    }

    public void setRrkShosaiBack(String rrkShosaiBack) {
        this.rrkShosaiBack = rrkShosaiBack;
    }

    public void setRrkShosaiUpDate(String rrkShosaiUpDate) {
        this.rrkShosaiUpDate = rrkShosaiUpDate;
    }

    public String getRrkShosaiBack() {
        return rrkShosaiBack;
    }

    public String getRrkShosaiUpDate() {
        return rrkShosaiUpDate;
    }

    public String getGazoUpd() {
        return gazoUpd;
    }

    public String getKessaiJokyo() {
        return kessaiJokyo;
    }

    public void setGazoUpd(String gazoUpd) {
        this.gazoUpd = gazoUpd;
    }

    public void setKessaiJokyo(String kessaiJokyo) {
        this.kessaiJokyo = kessaiJokyo;
    }

    public String getJuyoResult() {
        return juyoResult;
    }

    public void setJuyoResult(String juyoResult) {
        this.juyoResult = juyoResult;
    }

    public void setResult(String result) {
        this.result = result;
    }

    public void setYukouKiken(String yukouKiken) {
        this.yukouKiken = yukouKiken;
    }

    public String getResult() {
        return result;
    }

    public String getYukouKiken() {
        return yukouKiken;
    }

    public String getBanngo() {
        return banngo;
    }

    public void setBanngo(String banngo) {
        this.banngo = banngo;
    }

    public void setBirthYmd(String birthYmd) {
        this.birthYmd = birthYmd;
    }

    public String getBirthYmd() {
        return birthYmd;
    }

    public List<Option> getTodofukenList() {
        return todofukenList;
    }

    public void setTodofukenList(List<Option> todofukenList) {
        this.todofukenList = todofukenList;
    }

    public List<Option> getGenderList() {
        return genderList;
    }

    public void setGenderList(List<Option> genderList) {
        this.genderList = genderList;
    }

    public List<Option> getSofusakiList() {
        return sofusakiList;
    }

    public void setSofusakiList(List<Option> sofusakiList) {
        this.sofusakiList = sofusakiList;
    }

    public List<Option> getGenmenList() {
        return genmenList;
    }

    public void setGenmenList(List<Option> genmenList) {
        this.genmenList = genmenList;
    }

    public String getJissiJusho() {
        return jissiJusho;
    }

    public void setJissiJusho(String jissiJusho) {
        this.jissiJusho = jissiJusho;
    }

    public List<Option> getKaisaitiList() {
        return kaisaitiList;
    }

    public void setKaisaitiList(List<Option> kaisaitiList) {
        this.kaisaitiList = kaisaitiList;
    }

    public List<Option> getBirthYearList() {
        return birthYearList;
    }

    public void setBirthYearList(List<Option> birthYearList) {
        this.birthYearList = birthYearList;
    }

    public List<Option> getBirthMonthList() {
        return birthMonthList;
    }

    public void setBirthMonthList(List<Option> birthMonthList) {
        this.birthMonthList = birthMonthList;
    }

    public List<Option> getBirthDayList() {
        return birthDayList;
    }

    public void setBirthDayList(List<Option> birthDayList) {
        this.birthDayList = birthDayList;
    }

    public String getTodofuken() {
        return todofuken;
    }

    public void setTodofuken(String todofuken) {
        this.todofuken = todofuken;
    }

    public String getKinmusakiTodofuken() {
        return kinmusakiTodofuken;
    }

    public void setKinmusakiTodofuken(String kinmusakiTodofuken) {
        this.kinmusakiTodofuken = kinmusakiTodofuken;
    }

    public String getKinmusakiYbnBngFront() {
        return kinmusakiYbnBngFront;
    }

    public void setKinmusakiYbnBngFront(String kinmusakiYbnBngFront) {
        this.kinmusakiYbnBngFront = kinmusakiYbnBngFront;
    }

    public String getKinmusakiYbnBngBack() {
        return kinmusakiYbnBngBack;
    }

    public void setKinmusakiYbnBngBack(String kinmusakiYbnBngBack) {
        this.kinmusakiYbnBngBack = kinmusakiYbnBngBack;
    }

    /**
     * �s���{���擾
     *
     * @return the todofukenDisp
     */
    public String getTodofukenDisp() {
        String ret = "";
        if (BmaUtility.isNullOrEmpty(getTodofuken())) {
            return ret;
        }
        for (Option option : getTodofukenList()) {
            if (option.getValue().equals(getTodofuken())) {
                ret = option.getLabel();
                break;
            }
        }
        return ret;
    }

    /**
     * �Ζ��s���{���擾
     *
     * @return the kinmusakiTodofukenDisp
     */
    public String getkinmusakiTodofukenDisp() {
        String ret = "";
        if (BmaUtility.isNullOrEmpty(getKinmusakiTodofuken())) {
            return ret;
        }
        for (Option option : getTodofukenList()) {
            if (option.getValue().equals(getKinmusakiTodofuken())) {
                ret = option.getLabel();
                break;
            }
        }
        return ret;
    }

    /**
     * ���t����擾
     *
     * @return the jissiJusho
     */
    public String getSofusakiChoiceDisp() {
        String ret = "";
        if (BmaUtility.isNullOrEmpty(getSofusakiChoice())) {
            return ret;
        }
        for (Option option : getSofusakiList()) {
            if (option.getValue().equals(getSofusakiChoice())) {
                ret = option.getLabel();
                break;
            }
        }
        return ret;
    }

    public String getGazoHyojiKbn() {
        return gazoHyojiKbn;
    }

    public void setGazoHyojiKbn(String gazoHyojiKbn) {
        this.gazoHyojiKbn = gazoHyojiKbn;
    }

    public String getMoshikomiFinishBiDisp() {

        return BmaDateTimeUtility.formatYMDToDateString(moshikomiFinishBi);
    }

    public String getMoshikomiFinishBi() {
        return moshikomiFinishBi;
    }

    public void setMoshikomiFinishBi(String moshikomiFinishBi) {
        this.moshikomiFinishBi = moshikomiFinishBi;
    }

    public String getCountDisp() {
        return count + "�l";
    }

    public String getCount() {
        return count;
    }

    public void setCount(String count) {
        this.count = count;
    }

    public String getTorokuUserId() {
        return torokuUserId;
    }

    public void setTorokuUserId(String torokuUserId) {
        this.torokuUserId = torokuUserId;
    }

    public String getMoshikomiNinsu() {
        return moshikomiNinsu;
    }

    public void setMoshikomiNinsu(String moshikomiNinsu) {
        this.moshikomiNinsu = moshikomiNinsu;
    }

    public String getGoukakuNinsu() {
        return goukakuNinsu;
    }

    public void setGoukakuNinsu(String goukakuNinsu) {
        this.goukakuNinsu = goukakuNinsu;
    }

    public String getItibuGoukakuNinsuGa() {
        return itibuGoukakuNinsuGa;
    }

    public void setItibuGoukakuNinsuGa(String itibuGoukakuNinsuGa) {
        this.itibuGoukakuNinsuGa = itibuGoukakuNinsuGa;
    }

    public String getItibuGoukakuNinsuJi() {
        return itibuGoukakuNinsuJi;
    }

    public void setItibuGoukakuNinsuJi(String itibuGoukakuNinsuJi) {
        this.itibuGoukakuNinsuJi = itibuGoukakuNinsuJi;
    }

    public String getFuGoukakuNinsu() {
        return fuGoukakuNinsu;
    }

    public void setFuGoukakuNinsu(String fuGoukakuNinsu) {
        this.fuGoukakuNinsu = fuGoukakuNinsu;
    }

    public List<Option> getUnyouList() {
        return unyouList;
    }

    public void setUnyouList(List<Option> unyouList) {
        this.unyouList = unyouList;
    }

    public String getMoshikomiFubiNinsu() {
        return moshikomiFubiNinsu;
    }

    public void setMoshikomiFubiNinsu(String moshikomiFubiNinsu) {
        this.moshikomiFubiNinsu = moshikomiFubiNinsu;
    }

    public String getMoshikomiKanriNinsu() {
        return moshikomiKanriNinsu;
    }

    public void setMoshikomiKanriNinsu(String moshikomiKanriNinsu) {
        this.moshikomiKanriNinsu = moshikomiKanriNinsu;
    }

    public String getMoshikomiListBtn() {
        return moshikomiListBtn;
    }

    public void setMoshikomiListBtn(String moshikomiListBtn) {
        this.moshikomiListBtn = moshikomiListBtn;
    }

    public String getJukenJukoNo() {
        return jukenJukoNo;
    }

    public void setJukenJukoNo(String jukenJukoNo) {
        this.jukenJukoNo = jukenJukoNo;
    }

    public String getMoshikomiJokyoKbn() {
        return moshikomiJokyoKbn;
    }

    public void setMoshikomiJokyoKbn(String moshikomiJokyoKbn) {
        this.moshikomiJokyoKbn = moshikomiJokyoKbn;
    }

    public String getGohiJokyoKbn() {
        return gohiJokyoKbn;
    }

    public void setGohiJokyoKbn(String gohiJokyoKbn) {
        this.gohiJokyoKbn = gohiJokyoKbn;
    }

    public String getUnyounm() {
        return unyounm;
    }

    public void setUnyounm(String unyounm) {
        this.unyounm = unyounm;
    }

    /**
     * �Z�b�V�����p�\�������J�n
     *
     * @return the firstDisp
     */
    public int getFirstDisp() {
        return firstDisp;
    }

    /**
     * �Z�b�V�����p�\�������J�n
     *
     * @param firstDisp the firstDisp to set
     */
    public void setFirstDisp(int firstDisp) {
        this.firstDisp = firstDisp;
    }

    /**
     * �Z�b�V�����p�\�������ő包��
     *
     * @return the page
     */
    public int getPage() {
        return page;
    }

    /**
     * �Z�b�V�����p�\�������ő包��
     *
     * @param page the page to set
     */
    public void setPage(int page) {
        this.page = page;
    }

    /**
     * �Z�b�V�����p�\�������ő包��
     *
     * @return the maxDisp
     */
    public int getMaxDisp() {
        return maxDisp;
    }

    /**
     * �Z�b�V�����p�\�������ő包��
     *
     * @param maxDisp the maxDisp to set
     */
    public void setMaxDisp(int maxDisp) {
        this.maxDisp = maxDisp;
    }

    /**
     * �y�[�W�J�ڗp�F���ڈړ��Œ�l
     *
     * @return the pageBegin
     */
    public int getPageBegin() {
        return pageBegin;
    }

    /**
     * �y�[�W�J�ڗp�F���ڈړ��Œ�l
     *
     * @param pageBegin the pageBegin to set
     */
    public void setPageBegin(int pageBegin) {
        this.pageBegin = pageBegin;
    }

    /**
     * �y�[�W�J�ڗp�F���ڈړ��ő�l
     *
     * @return the pageEnd
     */
    public int getPageEnd() {
        return pageEnd;
    }

    /**
     * �y�[�W�J�ڗp�F���ڈړ��ő�l
     *
     * @param pageEnd the pageEnd to set
     */
    public void setPageEnd(int pageEnd) {
        this.pageEnd = pageEnd;
    }

    /**
     * �y�[�W�J�ڗp�F�ő�y�[�W��
     *
     * @return the pageMax
     */
    public int getPageMax() {
        return pageMax;
    }

    /**
     * �y�[�W�J�ڗp�F�ő�y�[�W��
     *
     * @param pageMax the pageMax to set
     */
    public void setPageMax(int pageMax) {
        this.pageMax = pageMax;
    }

    /**
     * ��������
     *
     * @return the dispKeyList
     */
    public List<String> getDispKeyList() {
        return dispKeyList;
    }

    /**
     * ��������
     *
     * @param dispKeyList the dispKeyList to set
     */
    public void setDispKeyList(List<String> dispKeyList) {
        this.dispKeyList = dispKeyList;
    }

    /**
     * ��������index���X�g
     *
     * @return the searchOutIndex
     */
    public List<String> getSearchOutIndex() {
        return searchOutIndex;
    }

    /**
     * ��������index���X�g
     *
     * @param searchOutIndex the searchOutIndex to set
     */
    public void setSearchOutIndex(List<String> searchOutIndex) {
        this.searchOutIndex = searchOutIndex;
    }

    /**
     * �R�}���h �y�[�W�J��
     *
     * @return the commandPage
     */
    public String getCommandPage() {
        return commandPage;
    }

    /**
     * �R�}���h �y�[�W�J��
     *
     * @param commandPage the commandPage to set
     */
    public void setCommandPage(String commandPage) {
        this.commandPage = commandPage;
    }

    public String getSyosaiBack() {
        return syosaiBack;
    }

    public void setSyosaiBack(String syosaiBack) {
        this.syosaiBack = syosaiBack;
    }

    public String getSikenBeforeAfter() {
        return sikenBeforeAfter;
    }

    public void setSikenBeforeAfter(String sikenBeforeAfter) {
        this.sikenBeforeAfter = sikenBeforeAfter;
    }

    public String getSyosaiAfterBack() {
        return syosaiAfterBack;
    }

    public void setSyosaiAfterBack(String syosaiAfterBack) {
        this.syosaiAfterBack = syosaiAfterBack;
    }

    public String getShikenNaiyoKbn() {
        return shikenNaiyoKbn;
    }

    public void setShikenNaiyoKbn(String shikenNaiyoKbn) {
        this.shikenNaiyoKbn = shikenNaiyoKbn;
    }

    public String getButtonHekouFlag() {
        return buttonHekouFlag;
    }

    public void setButtonHekouFlag(String buttonHekouFlag) {
        this.buttonHekouFlag = buttonHekouFlag;
    }

    public String getMskShikaku() {
        return mskShikaku;
    }

    public void setMskShikaku(String mskShikaku) {
        this.mskShikaku = mskShikaku;
    }

    public List<RrkMskJoho> getRrkMskGroupJohoList() {
        return rrkMskGroupJohoList;
    }

    public void setRrkMskGroupJohoList(List<RrkMskJoho> rrkMskGroupJohoList) {
        this.rrkMskGroupJohoList = rrkMskGroupJohoList;
    }

    public String getSknKsuSearch() {
        return sknKsuSearch;
    }

    public void setSknKsuSearch(String sknKsuSearch) {
        this.sknKsuSearch = sknKsuSearch;
    }

    public List<Option> getSknKbnList() {
        return sknKbnList;
    }

    public void setSknKbnList(List<Option> sknKbnList) {
        this.sknKbnList = sknKbnList;
    }

    public List<Option> getKsuKbnList() {
        return ksuKbnList;
    }

    public void setKsuKbnList(List<Option> ksuKbnList) {
        this.ksuKbnList = ksuKbnList;
    }

    public String getSearch() {
        return search;
    }

    public void setSearch(String search) {
        this.search = search;
    }

    public String getGokakuNo() {
        return gokakuNo;
    }

    public void setGokakuNo(String gokakuNo) {
        this.gokakuNo = gokakuNo;
    }

    public String getScheduleCode() {
        return scheduleCode;
    }

    public void setScheduleCode(String scheduleCode) {
        this.scheduleCode = scheduleCode;
    }

    public String getKsuNameSeach() {
        return ksuNameSeach;
    }

    public void setKsuNameSeach(String ksuNameSeach) {
        this.ksuNameSeach = ksuNameSeach;
    }

    public String getSknNameSeach() {
        return sknNameSeach;
    }

    public void setSknNameSeach(String sknNameSeach) {
        this.sknNameSeach = sknNameSeach;
    }

    /**
     * @return the gazoKbn
     */
    public String getGazoKbn() {
        return gazoKbn;
    }

    /**
     * @param gazoKbn the gazoKbn to set
     */
    public void setGazoKbn(String gazoKbn) {
        this.gazoKbn = gazoKbn;
    }

    /**
     * @return the kaoImg
     */
    public String getKaoImg() {
        return kaoImg;
    }

    /**
     * @param kaoImg the kaoImg to set
     */
    public void setKaoImg(String kaoImg) {
        this.kaoImg = kaoImg;
    }

    /**
     * @return the nenreiImg
     */
    public String getNenreiImg() {
        return nenreiImg;
    }

    /**
     * @param nenreiImg the nenreiImg to set
     */
    public void setNenreiImg(String nenreiImg) {
        this.nenreiImg = nenreiImg;
    }

    /**
     * @return the shikakuImg
     */
    public String getShikakuImg() {
        return shikakuImg;
    }

    /**
     * @param shikakuImg the shikakuImg to set
     */
    public void setShikakuImg(String shikakuImg) {
        this.shikakuImg = shikakuImg;
    }

    /**
     * @return the menjyoImg
     */
    public String getMenjyoImg() {
        return menjyoImg;
    }

    /**
     * @param menjyoImg the menjyoImg to set
     */
    public void setMenjyoImg(String menjyoImg) {
        this.menjyoImg = menjyoImg;
    }

    /**
     * @return the gazoIdx
     */
    public String getGazoIdx() {
        return gazoIdx;
    }

    /**
     * @param gazoIdx the gazoIdx to set
     */
    public void setGazoIdx(String gazoIdx) {
        this.gazoIdx = gazoIdx;
    }

    /**
     * @return the Upload
     */
    public String getUpload() {
        return Upload;
    }

    /**
     * @param Upload the Upload to set
     */
    public void setUpload(String Upload) {
        this.Upload = Upload;
    }

    /**
     * @return the gazoUpdFlg
     */
    public String getGazoUpdFlg() {
        return gazoUpdFlg;
    }

    /**
     * @param gazoUpdFlg the gazoUpdFlg to set
     */
    public void setGazoUpdFlg(String gazoUpdFlg) {
        this.gazoUpdFlg = gazoUpdFlg;
    }

    /**
     * @return the gazoHyoji
     */
    public DiskFileItem getGazoHyoji() {
        return gazoHyoji;
    }

    /**
     * @param gazoHyoji the gazoHyoji to set
     */
    public void setGazoHyoji(DiskFileItem gazoHyoji) {
        this.gazoHyoji = gazoHyoji;
    }

    /**
     * @return the fileItem
     */
    public FileItem getFileItem() {
        return fileItem;
    }

    /**
     * @param fileItem the fileItem to set
     */
    public void setFileItem(FileItem fileItem) {
        this.fileItem = fileItem;
    }

    /**
     * @return the kaoHyojiKbn
     */
    public String getKaoHyojiKbn() {
        return kaoHyojiKbn;
    }

    /**
     * @param kaoHyojiKbn the kaoHyojiKbn to set
     */
    public void setKaoHyojiKbn(String kaoHyojiKbn) {
        this.kaoHyojiKbn = kaoHyojiKbn;
    }

    /**
     * @return the nenreiHyojiKbn
     */
    public String getNenreiHyojiKbn() {
        return nenreiHyojiKbn;
    }

    /**
     * @param nenreiHyojiKbn the nenreiHyojiKbn to set
     */
    public void setNenreiHyojiKbn(String nenreiHyojiKbn) {
        this.nenreiHyojiKbn = nenreiHyojiKbn;
    }

    /**
     * @return the shikakuHyojiKbn
     */
    public String getShikakuHyojiKbn() {
        return shikakuHyojiKbn;
    }

    /**
     * @param shikakuHyojiKbn the shikakuHyojiKbn to set
     */
    public void setShikakuHyojiKbn(String shikakuHyojiKbn) {
        this.shikakuHyojiKbn = shikakuHyojiKbn;
    }

    /**
     * @return the menjyoHyojiKbn
     */
    public String getMenjyoHyojiKbn() {
        return menjyoHyojiKbn;
    }

    /**
     * @param menjyoHyojiKbn the menjyoHyojiKbn to set
     */
    public void setMenjyoHyojiKbn(String menjyoHyojiKbn) {
        this.menjyoHyojiKbn = menjyoHyojiKbn;
    }

    /**
     * @return the uploadCheck
     */
    public String getUploadCheck() {
        return uploadCheck;
    }

    /**
     * @param uploadCheck the uploadCheck to set
     */
    public void setUploadCheck(String uploadCheck) {
        this.uploadCheck = uploadCheck;
    }

    public String getMoshikomishaId2() {
        return moshikomishaId2;
    }

    public void setMoshikomishaId2(String moshikomishaId2) {
        this.moshikomishaId2 = moshikomishaId2;
    }

    public String getKariUketsukeBi() {
        return kariUketsukeBi;
    }

    public void setKariUketsukeBi(String kariUketsukeBi) {
        this.kariUketsukeBi = kariUketsukeBi;
    }

    public String getKariUketsukeTime() {
        return kariUketsukeTime;
    }

    public void setKariUketsukeTime(String kariUketsukeTime) {
        this.kariUketsukeTime = kariUketsukeTime;
    }

    public String getUnyounmDisp() {
        String ret = "";
        if (BmaUtility.isNullOrEmpty(getUnyounm())) {
            return ret;
        }
        for (Option option : getUnyouList()) {
            if (option.getValue().equals(getUnyounm())) {
                ret = option.getLabel();
                break;
            }
        }
        return ret;
    }

    public String getHanyoCode() {
        return hanyoCode;
    }

    public void setHanyoCode(String hanyoCode) {
        this.hanyoCode = hanyoCode;
    }

    public RrkMskJoho getTaihi() {
        return taihi;
    }

    public void setTaihi(RrkMskJoho taihi) {
        this.taihi = taihi;
    }

    /**
     * @return the reload
     */
    public String getReload() {
        return reload;
    }

    /**
     * @param reload the reload to set
     */
    public void setReload(String reload) {
        this.reload = reload;
    }

}
