package jp.co.nii.bma.integration;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import static jp.co.nii.bma.business.domain.GeneratedTorokushaDao.TABLE_NAME;
import jp.co.nii.bma.business.domain.Torokusha;
import jp.co.nii.bma.business.domain.TorokushaDao;
import static jp.co.nii.bma.integration.GeneratedTorokushaDaoImpl.FIELDS_DECRYPT;
import jp.co.nii.sew.business.domain.UniqueViolationException;
import jp.co.nii.sew.common.LogGenerate;
import jp.co.nii.sew.integration.SQLStateSQLExceptionTranslater;

/**
 * �o�^�� DAO�����N���X
 * @author DB�Ǘ��c�[��
 */
public class TorokushaDaoImpl extends GeneratedTorokushaDaoImpl implements TorokushaDao {

    /**
     * �C���X�^���X�𐶐�����B
     * @param datasource �f�[�^�\�[�X��
     */
    public TorokushaDaoImpl(String datasource) {
        super(datasource);
    }

    /* (non-Javadoc)
     * @see jp.co.nii.bma.business.domain.TorokushaDao#findByKaiinId(jp.co.nii.bma.business.domain.Torokusha, java.lang.String)
     */
    @Override
    public Torokusha findByKaiinId(Torokusha bo, String lockMode) {
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs =null;
        String sql = "";
        try {
            con = getConnection();
            sql = "SELECT " + FIELDS_DECRYPT
                    + " FROM " + getSchemaName() + "." + TABLE_NAME
                    + " WHERE"
                    + " KAIIN_ID = ?";

            stmt = con.prepareStatement(sql + lockMode);
            int i = 1;
            stmt.setString(i++, bo.getKaiinId());

            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();
            if (rs.next()) {
                setBoFromResultSet(bo, rs);
                if (rs.next()) {
                    throw new UniqueViolationException("�o�^�҃e�[�u���̉��ID" + bo.getKaiinId() +"����ӂł͂���܂���B");
                }
            } else {
                bo = null;
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return bo;
    }
}
