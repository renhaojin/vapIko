package jp.co.nii.bma.integration;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import jp.co.nii.bma.business.domain.HoyuMenjoMstDao;
import jp.co.nii.bma.business.domain. HoyuMenjoMst;
import jp.co.nii.bma.business.rto.MskSikakuJoho;
import jp.co.nii.bma.business.service.common.BmaConstants;
import jp.co.nii.sew.common.LogGenerate;
import jp.co.nii.sew.integration.SQLStateSQLExceptionTranslater;
import jp.co.nii.sew.utility.DateUtility;

/**
 * �ۗL�Ə��}�X�^ DAO�����N���X
 * @author DB�Ǘ��c�[��
 */
public class HoyuMenjoMstDaoImpl extends GeneratedHoyuMenjoMstDaoImpl implements HoyuMenjoMstDao {

    /**
     * �C���X�^���X�𐶐�����B
     * @param datasource �f�[�^�\�[�X��
     */
    public HoyuMenjoMstDaoImpl(String datasource) {
        super(datasource);
    }
    
    /**
     * �Ə��敪���X�g����������B<br>
     * @param bo �ۗL���i�}�X�^bean
     * @param shubetsuCodes �Ə��L���Ȏ�ʃR�[�h
     * @return ���������Ə��敪���X�g�f�[�^<br>
     */
    @Override
    public List<String> findMenjoKbnList(HoyuMenjoMst bo, String[] shubetsuCodes) {
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs =null;
        String sql = "";
        List<String> param = new ArrayList<>();
        List<String> menjoKbnList = new ArrayList<String>();
        String currentDate = DateUtility.convertDateToYyyyMMdd(new Date());
        try {
            con = getConnection();
            sql = "SELECT " + FIELDS_DECRYPT
                    + " FROM " + getSchemaName() + "." + TABLE_NAME
                    + " WHERE"
                    + " MOSHIKOMISHA_ID = ?"
                    + " AND SKN_KSU_CODE = ?"
                    + " AND YUKO_KIGEN > ?"
                    + " AND RONRI_SAKUJO_FLG = ?"
                    + " AND SHUBETSU_CODE IN ( ";
            
            for (int i=0; i < shubetsuCodes.length; i++) {
                if (i > 0) {
                    sql += ", ";
                }
                sql += "?";
            }
            sql += " )";
            sql += " ORDER BY SHUBETSU_CODE ASC, NENDO DESC"
                    + " LIMIT 1";

            stmt = con.prepareStatement(sql);
            int i = 1;
            stmt.setString(i++, bo.getMoshikomishaId());
            stmt.setString(i++, bo.getSknKsuCode());
            stmt.setString(i++, currentDate);
            stmt.setString(i++, BmaConstants.FLG_OFF);
            for (int j=0 ; j < shubetsuCodes.length; j++) {
                param.add(shubetsuCodes[j]);
            }
            for (String shubetsu : param) {
                stmt.setString(i++, shubetsu);
            }

            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();
            if (rs.next()) {
                try {
                    menjoKbnList.add(rs.getString("MENJO_KBN"));
                } catch (SQLException ex) {
                    throw new SQLStateSQLExceptionTranslater().translate(null, ex);
                }
            } else {
                bo = null;
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return menjoKbnList;
    }
    
    /**
     * �Ə����̍��i�ԍ����X�g����������B<br>
     * @param bo �\���Ə��}�X�^bean
     * @return �����������i�ԍ����X�g�f�[�^<br>
     */
    @Override
    public List<MskSikakuJoho> getMenjoGokakuNoList(HoyuMenjoMst bo) {
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs =null;
        String sql = "";
        List<MskSikakuJoho> resultList = new ArrayList<MskSikakuJoho>();
        String currentDate = DateUtility.convertDateToYyyyMMdd(new Date());
        try {
            con = getConnection();
            sql = "SELECT DISTINCT" +
                " HOYU_MENJO_MST.SKN_KSU_CODE" +
                ",M_MENJO_MST.MNJ_SHUBETSU_CODE" +
                ",HOYU_MENJO_MST.KAISU_CODE" +
                "	,HOYU_MENJO_MST.GOKAKU_TSUCHI_NO " +
                " FROM" +
                "	 BMA.HOYU_MENJO_MST HOYU_MENJO_MST LEFT JOIN BMA.M_MENJO_MST M_MENJO_MST" +
                "	 ON HOYU_MENJO_MST.SKN_KSU_CODE = M_MENJO_MST.MNJ_SKN_KSU_CODE" +
                "	 AND HOYU_MENJO_MST.SHUBETSU_CODE = M_MENJO_MST.MNJ_SHUBETSU_CODE" +
                " WHERE" +
                "	 HOYU_MENJO_MST.MOSHIKOMISHA_ID = ?" +
                "	 AND HOYU_MENJO_MST.SKN_KSU_CODE = ?" +
                "	 AND M_MENJO_MST.MNJ_SHUBETSU_CODE != ''" +
                "	 AND M_MENJO_MST.RONRI_SAKUJO_FLG = ?" +
                "	 AND HOYU_MENJO_MST.RONRI_SAKUJO_FLG = ?" +
                "	 AND HOYU_MENJO_MST.KAISU_CODE = ?" +
                "	 AND HOYU_MENJO_MST.MENJO_KBN = ?" +
                "	 AND HOYU_MENJO_MST.YUKO_KIGEN > ?" +
                " ORDER BY HOYU_MENJO_MST.SKN_KSU_CODE, M_MENJO_MST.MNJ_SHUBETSU_CODE ;";

            stmt = con.prepareStatement(sql);
            int i = 1;
            stmt.setString(i++, bo.getMoshikomishaId());
            stmt.setString(i++, bo.getSknKsuCode());
            stmt.setString(i++, BmaConstants.FLG_OFF);
            stmt.setString(i++, BmaConstants.FLG_OFF);
            stmt.setString(i++, "01");
            stmt.setString(i++, bo.getMenjoKbn());
            stmt.setString(i++, currentDate);

            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();
            MskSikakuJoho mskSikakuJoho;
            if (rs.next()) {
                try {
                    mskSikakuJoho = new MskSikakuJoho();
                    mskSikakuJoho.setSknKsuCode(rs.getString("SKN_KSU_CODE"));
                    mskSikakuJoho.setMnjShubetsuCode(rs.getString("MNJ_SHUBETSU_CODE"));
                    mskSikakuJoho.setKaisuCode(rs.getString("KAISU_CODE"));
                    mskSikakuJoho.setShinseiMenjoNo(rs.getString("GOKAKU_TSUCHI_NO"));
                    resultList.add(mskSikakuJoho);
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return resultList;
    }
    
    /**
     * �Ə����̍��i�ԍ������݂��邩�ǂ����B<br>
     * @param gokakuNo �Ə����̍��i�ԍ�
     * @return ���i�ԍ������݂��邩�ǂ���<br>
     */
    public Boolean findByGokakuNo(String gokakuNo){
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs =null;
        String sql = "";
        Boolean result = false;
        try {
            con = getConnection();
            sql = "SELECT " + FIELDS_DECRYPT
                    + " FROM " + getSchemaName() + "." + TABLE_NAME
                    + " WHERE"
                    + " GOKAKU_TSUCHI_NO = ?"
                    + " AND RONRI_SAKUJO_FLG = ?";

            stmt = con.prepareStatement(sql);
            int i = 1;
            stmt.setString(i++, gokakuNo);
            stmt.setString(i++, BmaConstants.FLG_OFF);

            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();
            if (rs.next()) {
                result = true;
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return result;
    }
}
