package jp.co.nii.bma.business.rto;

import javax.servlet.http.HttpServletRequest;
import jp.co.nii.sew.presentation.DownloadRTO;

/**
 * �^�C�g��: ���ϊ����ʒm�i�N���W�b�g�j ����: ���ϊ����ʒm�i�N���W�b�g�jRTO
 *
 * ���쌠: Copyright (c) 2020
 *
 * ��Ж�: ���{���Y�Ɗ������
 *
 * @author NII
 */
public class KessaiKanryoCredit extends DownloadRTO {

    /**
     * �N
     */
    private String nen;
    /**
     * �ʒm�ԍ�
     */
    private String tsuchiNo;
    /**
     * ������
     */
    private String nyukinBi;
    /**
     * ��������
     */
    private String nyukinTime;
    /**
     * �h�o�R�[�h
     */
    private String ipCode;
    /**
     * ����R�[�h
     */
    private String torihikiCode;
    /**
     * ���z
     */
    private String kingaku;
    /**
     * ���ϕ��@�i�J�[�h��Ж��j
     */
    private String kessaiHoho;
    /**
     * �X�܃R�[�h
     */
    private String tenpoCode;
    /**
     * ���F�ԍ�
     */
    private String shoninNo;
    /**
     * ��d������R�[�h
     */
    private String hishimukeSakiCode;
    /**
     * �t�����
     */
    private String hukaJoho;
    /**
     * �x���敪
     */
    private String shiharaiKbn;
    /**
     * ������
     */
    private String bunkatsuKaisu;
    /**
     * ���[�U�[�h�c
     */
    private String userId;

    //<editor-fold defaultstate="collapsed" desc="�R���X�g���N�^/������/���N�G�X�g�擾">
    /**
     * �R���X�g���N�^
     */
    public KessaiKanryoCredit() {
        clearInfo();
    }

    /**
     * ���������\�b�h
     */
    public void clearInfo() {
        setNen("");
        setTsuchiNo("");
        setNyukinBi("");
        setNyukinTime("");
        setIpCode("");
        setTorihikiCode("");
        setKingaku("");
        setKessaiHoho("");
        setTenpoCode("");
        setShoninNo("");
        setHishimukeSakiCode("");
        setHukaJoho("");
        setShiharaiKbn("");
        setBunkatsuKaisu("");
        setUserId("");
    }

    /**
     * ���N�G�X�g��������擾���郁�\�b�h
     *
     * @param request ���N�G�X�g
     */
    @Override
    public void copyFromRequest(HttpServletRequest request) {
        setTsuchiNo((String) request.getAttribute("SEQ"));
        setNyukinBi((String) request.getAttribute("DATE"));
        setNyukinTime((String) request.getAttribute("TIME"));
        setIpCode((String) request.getAttribute("IP"));
        setTorihikiCode((String) request.getAttribute("SID"));
        setKingaku((String) request.getAttribute("KINGAKU"));
        setKessaiHoho((String) request.getAttribute("CVS"));
        setTenpoCode((String) request.getAttribute("SCODE"));
        setShoninNo((String) request.getAttribute("SHONIN"));
        setHishimukeSakiCode((String) request.getAttribute("HISHIMUKE"));
        setHukaJoho((String) request.getAttribute("FUKA"));
        setShiharaiKbn((String) request.getAttribute("PAYMODE"));
        setBunkatsuKaisu((String) request.getAttribute("INCOUNT"));
        setUserId((String) request.getAttribute("IP_USER_ID"));
    }
    //</editor-fold>

    //<editor-fold defaultstate="collapsed" desc="�Q�b�^�[/�Z�b�^�[">
    /**
     * �N
     *
     * @return the nen
     */
    public String getNen() {
        return nen;
    }

    /**
     * �N
     *
     * @param nen the nen to set
     */
    public void setNen(String nen) {
        this.nen = nen;
    }

    /**
     * �ʒm�ԍ�
     *
     * @return the tsuchiNo
     */
    public String getTsuchiNo() {
        return tsuchiNo;
    }

    /**
     * �ʒm�ԍ�
     *
     * @param tsuchiNo the tsuchiNo to set
     */
    public void setTsuchiNo(String tsuchiNo) {
        this.tsuchiNo = tsuchiNo;
    }

    /**
     * ������
     *
     * @return the nyukinBi
     */
    public String getNyukinBi() {
        return nyukinBi;
    }

    /**
     * ������
     *
     * @param nyukinBi the nyukinBi to set
     */
    public void setNyukinBi(String nyukinBi) {
        this.nyukinBi = nyukinBi;
    }

    /**
     * ��������
     *
     * @return the nyukinTime
     */
    public String getNyukinTime() {
        return nyukinTime;
    }

    /**
     * ��������
     *
     * @param nyukinTime the nyukinTime to set
     */
    public void setNyukinTime(String nyukinTime) {
        this.nyukinTime = nyukinTime;
    }

    /**
     * �h�o�R�[�h
     *
     * @return the ipCode
     */
    public String getIpCode() {
        return ipCode;
    }

    /**
     * �h�o�R�[�h
     *
     * @param ipCode the ipCode to set
     */
    public void setIpCode(String ipCode) {
        this.ipCode = ipCode;
    }

    /**
     * ����R�[�h
     *
     * @return the torihikiCode
     */
    public String getTorihikiCode() {
        return torihikiCode;
    }

    /**
     * ����R�[�h
     *
     * @param torihikiCode the torihikiCode to set
     */
    public void setTorihikiCode(String torihikiCode) {
        this.torihikiCode = torihikiCode;
    }

    /**
     * ���z
     *
     * @return the kingaku
     */
    public String getKingaku() {
        return kingaku;
    }

    /**
     * ���z
     *
     * @param kingaku the kingaku to set
     */
    public void setKingaku(String kingaku) {
        this.kingaku = kingaku;
    }

    /**
     * ���ϕ��@�i�J�[�h��Ж��j
     *
     * @return the kessaiHoho
     */
    public String getKessaiHoho() {
        return kessaiHoho;
    }

    /**
     * ���ϕ��@�i�J�[�h��Ж��j
     *
     * @param kessaiHoho the kessaiHoho to set
     */
    public void setKessaiHoho(String kessaiHoho) {
        this.kessaiHoho = kessaiHoho;
    }

    /**
     * �X�܃R�[�h
     *
     * @return the tenpoCode
     */
    public String getTenpoCode() {
        return tenpoCode;
    }

    /**
     * �X�܃R�[�h
     *
     * @param tenpoCode the tenpoCode to set
     */
    public void setTenpoCode(String tenpoCode) {
        this.tenpoCode = tenpoCode;
    }

    /**
     * ���F�ԍ�
     *
     * @return the shoninNo
     */
    public String getShoninNo() {
        return shoninNo;
    }

    /**
     * ���F�ԍ�
     *
     * @param shoninNo the shoninNo to set
     */
    public void setShoninNo(String shoninNo) {
        this.shoninNo = shoninNo;
    }

    /**
     * ��d������R�[�h
     *
     * @return the hishimukeSakiCode
     */
    public String getHishimukeSakiCode() {
        return hishimukeSakiCode;
    }

    /**
     * ��d������R�[�h
     *
     * @param hishimukeSakiCode the hishimukeSakiCode to set
     */
    public void setHishimukeSakiCode(String hishimukeSakiCode) {
        this.hishimukeSakiCode = hishimukeSakiCode;
    }

    /**
     * �t�����
     *
     * @return the hukaJoho
     */
    public String getHukaJoho() {
        return hukaJoho;
    }

    /**
     * �t�����
     *
     * @param hukaJoho the hukaJoho to set
     */
    public void setHukaJoho(String hukaJoho) {
        this.hukaJoho = hukaJoho;
    }

    /**
     * �x���敪
     *
     * @return the shiharaiKbn
     */
    public String getShiharaiKbn() {
        return shiharaiKbn;
    }

    /**
     * �x���敪
     *
     * @param shiharaiKbn the shiharaiKbn to set
     */
    public void setShiharaiKbn(String shiharaiKbn) {
        this.shiharaiKbn = shiharaiKbn;
    }

    /**
     * ������
     *
     * @return the bunkatsuKaisu
     */
    public String getBunkatsuKaisu() {
        return bunkatsuKaisu;
    }

    /**
     * ������
     *
     * @param bunkatsuKaisu the bunkatsuKaisu to set
     */
    public void setBunkatsuKaisu(String bunkatsuKaisu) {
        this.bunkatsuKaisu = bunkatsuKaisu;
    }

    /**
     * ���[�U�[�h�c
     *
     * @return the userId
     */
    public String getUserId() {
        return userId;
    }

    /**
     * ���[�U�[�h�c
     *
     * @param userId the userId to set
     */
    public void setUserId(String userId) {
        this.userId = userId;
    }
    //</editor-fold>
}
