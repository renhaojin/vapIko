package jp.co.nii.bma.business.rto;

import javax.servlet.http.HttpServletRequest;
import jp.co.nii.bma.utility.BmaDateTimeUtility;
import jp.co.nii.sew.presentation.AbstractRequestTransferObject;

/**
 * �^�C�g��: �\����� ����: �\�����RTO ���쌠: Copyright (c) 2020 ��Ж�: ���{���Y�Ɗ������
 *
 * @author S.WEIBING
 */
public class RrkMskSetToList extends AbstractRequestTransferObject {


    // �摜���Ȃ�
    private String gazoIdx;
    private String nendo;
    private String uketsukeNo;
    private String seq;
    private String gazoKbn;
    private String gazoKbnDisp;
    private String gazoHyojiKbn;
    private String gazoHyojiKbnDisp;
    private String kinmusaki;
    private String bushoyakushokuName;
    private String kinmuNaiyo;
    private String shozaichi;
    private String zaisekikikanFrom;
    private String zaisekikikanTo;

    /**
     * �R���X�g���N�^
     */
    public RrkMskSetToList() {
        clearInfo();
    }

    /**
     * ���������\�b�h
     */
    public void clearInfo() {

    }

    /**
     * ���N�G�X�g��������擾���郁�\�b�h
     *
     * @param request ���N�G�X�g
     */
    @Override
    public void copyFromRequest(HttpServletRequest request) {
    }

    public String getGazoKbn() {
        return gazoKbn;
    }

    public void setGazoKbn(String gazoKbn) {
        this.gazoKbn = gazoKbn;
    }

    public String getGazoHyojiKbn() {
        return gazoHyojiKbn;
    }

    public void setGazoHyojiKbn(String gazoHyojiKbn) {
        this.gazoHyojiKbn = gazoHyojiKbn;
    }

    public String getKinmusaki() {
        return kinmusaki;
    }

    public void setKinmusaki(String kinmusaki) {
        this.kinmusaki = kinmusaki;
    }

    public String getBushoyakushokuName() {
        return bushoyakushokuName;
    }

    public void setBushoyakushokuName(String bushoyakushokuName) {
        this.bushoyakushokuName = bushoyakushokuName;
    }

    public String getKinmuNaiyo() {
        return kinmuNaiyo;
    }

    public void setKinmuNaiyo(String kinmuNaiyo) {
        this.kinmuNaiyo = kinmuNaiyo;
    }

    public String getShozaichi() {
        return shozaichi;
    }

    public void setShozaichi(String shozaichi) {
        this.shozaichi = shozaichi;
    }

    public String getZaisekikikanFrom() {
        return zaisekikikanFrom;
    }

    public void setZaisekikikanFrom(String zaisekikikanFrom) {
        this.zaisekikikanFrom = zaisekikikanFrom;
    }

    public String getZaisekikikanFromDisp() {
        return BmaDateTimeUtility.formatYMToDateString(zaisekikikanFrom);
    }

    public String getZaisekikikanToDisp() {
        return BmaDateTimeUtility.formatYMToDateString(zaisekikikanTo);
    }

    public String getZaisekikikanTo() {
        return zaisekikikanTo;
    }

    public void setZaisekikikanTo(String zaisekikikanTo) {
        this.zaisekikikanTo = zaisekikikanTo;
    }

    public String getGazoHyojiKbnDisp() {
        return gazoHyojiKbnDisp;
    }

    public void setGazoHyojiKbnDisp(String gazoHyojiKbnDisp) {
        this.gazoHyojiKbnDisp = gazoHyojiKbnDisp;
    }

    public String getGazoKbnDisp() {
        return gazoKbnDisp;
    }

    public void setGazoKbnDisp(String gazoKbnDisp) {
        this.gazoKbnDisp = gazoKbnDisp;
    }
    
    public String getGazoIdx() {
        return gazoIdx;
    }

    public void setGazoIdx(String gazoIdx) {
        this.gazoIdx = gazoIdx;
    }

    public String getNendo() {
        return nendo;
    }

    public void setNendo(String nendo) {
        this.nendo = nendo;
    }

    public String getUketsukeNo() {
        return uketsukeNo;
    }

    public void setUketsukeNo(String uketsukeNo) {
        this.uketsukeNo = uketsukeNo;
    }

    public String getSeq() {
        return seq;
    }

    public void setSeq(String seq) {
        this.seq = seq;
    }
}
