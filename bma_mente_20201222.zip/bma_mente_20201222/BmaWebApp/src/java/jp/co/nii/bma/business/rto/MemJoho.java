package jp.co.nii.bma.business.rto;

import java.util.ArrayList;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import jp.co.nii.bma.business.service.common.BmaConstants;
import jp.co.nii.sew.presentation.AbstractRequestTransferObject;
import jp.co.nii.sew.presentation.Messages;

/**
 * �^�C�g��: TOP��� ����: TOP���RTO ���쌠: Copyright (c) 2020 ��Ж�: ���{���Y�Ɗ������
 */
public class MemJoho extends AbstractRequestTransferObject {
//
//    //�l���
//    private String shimei;
//    private String furigana;
//    private String birthday;
//    private String gender;
//    private String yubinNo;
//    private String yubinNoFront;
//    private String yubinNoBack;
//    private String jusho1;
//    private String jusho2;
//    private String tatemono;
//    private String telNo;
//    private String telNo1st;
//    private String telNo2nd;
//    private String telNo3rd;
//    private String faxNo;
//    private String faxNo1st;
//    private String faxNo2nd;
//    private String faxNo3rd;
//    private String mailAddoress;
//    private String kokuseki;
//    private String zairyucardNo;
//    private String mailAddoressKakunin;
//    private String birthYear;
//    private String birthMonth;
//    private String birthDay;
//
//    //�Ζ�����
//    private String kinmusakiName;
//    private String kinmusakiYubinNo;
//    private String kinmusakiYubinFront;
//    private String kinmusakiYubinBack;
//    private String kinmusakiJusho1;
//    private String kinmusakiJusho2;
//    private String kinmusakiTatemono;
//    private String kinmusakiTelNo;
//    private String kinmusakiTelNo1st;
//    private String kinmusakiTelNo2nd;
//    private String kinmusakiTelNo3rd;
//    private String kinmusakiFaxNo;
//    private String kinmusakiFaxNo1st;
//    private String kinmusakiFaxNo2nd;
//    private String kinmusakiFaxNo3rd;
//
//    //���t��
//    private String sofusakiChoice;
//
//    //�L���i���
//    private String yushikakuName;
//    private String yushikakuGokakuNo;
//    private String yushikakuYukokigen;
//
//    /**
//     * �L���i���@���X�g
//     */
//    private List<MemJoho> yushikakuJohoList;
//    /**
//     * ���t��I���@���X�g
//     */
//    private List<String> sofusakiChoiceList;
//
//    /**
//     * �g�b�v��� �\�����������{�^��
//     */
//    private String memJohoUpdate;
//    /**
//     * �g�b�v��� �o�^��񌟍��{�^��
//     */
//    private String kaiinJoho;
//    /**
//     * �\�����ύX���͉�ʁ@�߂�{�^��
//     */
//    private String mskJohoUpdateBack;
//    /**
//     * �\�����ύX���͉�ʁ@�m�F�{�^��
//     */
//    private String mskJohoUpdateNext;
//    /**
//     * �\�����ύX���͉�ʁ@�l���@�X�֔ԍ������{�^��
//     */
//    private String adrSrc;
//    /**
//     * �\�����ύX���͉�ʁ@�Ζ�����@�X�֔ԍ������{�^��
//     */
//    private String kinmusakiAdrSrc;
//    /**
//     * �ύX�m���ʁ@�m��{�^��
//     */
//    private String memJohoKauninKakutei;
//    /**
//     * �ύX�m���ʁ@�߂�{�^��
//     */
//    private String memJohoKauninBack;
//    /**
//     * ������ʁ@�߂�{�^��
//     */
//    private String updateCompleteBack;
//    
//    /**
//     * �G���[
//     */
//    private Messages errors;
//    
//    
//    private String[] shozaichi_code_list;
//    private String[] shozaichi_kanji_list;
//
//    //�R���X�g���N�^/������/���N�G�X�g�擾
//    /**
//     * �R���X�g���N�^
//     */
//    public MemJoho() {
//        clearInfo();
//    }
//
//    /**
//     * ���������\�b�h
//     */
//    public void clearInfo() {
//        setErrors(new Messages());
//
//        //�l���
//        setShimei("");
//        setFurigana("");
//        setBirthday("");
//        setGender("");
//        setYubinNo("");
//        setJusho1("");
//        setJusho2("");
//        setTatemono("");
//        setTelNo("");
//        setFaxNo("");
//        setMailAddoress("");
//        setMailAddoressKakunin("");
//        setKokuseki("");
//        setZairyucardNo("");
//        setYubinNoFront("");
//        setYubinNoBack("");
//        setTelNo1st("");
//        setTelNo2nd("");
//        setTelNo3rd("");
//        setFaxNo1st("");
//        setFaxNo2nd("");
//        setFaxNo3rd("");
//        setBirthYear("");
//        setBirthMonth("");
//        setBirthDay("");
//        
//        //�Ζ�����
//        setKinmusakiName("");
//        setKinmusakiYubinNo("");
//        setKinmusakiJusho1("");
//        setKinmusakiJusho2("");
//        setKinmusakiTatemono("");
//        setKinmusakiTelNo("");
//        setKinmusakiFaxNo("");
//        setKinmusakiYubinFront("");
//        setKinmusakiYubinBack("");
//        setKinmusakiTelNo1st("");
//        setKinmusakiTelNo2nd("");
//        setKinmusakiTelNo3rd("");
//        setKinmusakiFaxNo1st("");
//        setKinmusakiFaxNo2nd("");
//        setKinmusakiFaxNo3rd("");
//
//        //���t��
//        setSofusakiChoice("");
//
//        //�o�^��
//        setMemJohoUpdate("");
//        setKaiinJoho("");
//        setMskJohoUpdateBack("");
//        setMskJohoUpdateNext("");
//
//        //�o�^��
//        setYushikakuName("");
//        setYushikakuGokakuNo("");
//        setYushikakuYukokigen("");
//
//        //���X�g
//        setSofusakiChoiceList(new ArrayList<String>());
//    }
//
//    /**
//     * ���N�G�X�g��������擾���郁�\�b�h
//     *
//     * @param request ���N�G�X�g
//     */
//    @Override
    public void copyFromRequest(HttpServletRequest request) {
//
//        //�l���
//        setShimei((String) request.getAttribute("shimei"));
//        setFurigana((String) request.getAttribute("furigana"));
//        setBirthday((String) request.getAttribute("birthday"));
//        setGender((String) request.getAttribute("gender"));
//        setYubinNo((String) request.getAttribute("yubinNo"));
//        setJusho1((String) request.getAttribute("jusho1"));
//        setJusho2((String) request.getAttribute("jusho2"));
//        setTatemono((String) request.getAttribute("tatemono"));
//        setTelNo((String) request.getAttribute("telNo"));
//        setFaxNo((String) request.getAttribute("faxNo"));
//        setMailAddoress((String) request.getAttribute("mailAddoress"));
//        setMailAddoressKakunin((String) request.getAttribute("mailAddoressKakunin"));
//        setKokuseki((String) request.getAttribute("kokuseki"));
//        setZairyucardNo((String) request.getAttribute("zairyucardNo"));
//        setYubinNoFront((String) request.getAttribute("yubinNoFront"));
//        setYubinNoBack((String) request.getAttribute("yubinNoBack"));
//        setTelNo1st((String) request.getAttribute("telNo1st"));
//        setTelNo2nd((String) request.getAttribute("telNo2nd"));
//        setTelNo3rd((String) request.getAttribute("telNo3rd"));
//        setFaxNo1st((String) request.getAttribute("faxNo1st"));
//        setFaxNo2nd((String) request.getAttribute("faxNo2nd"));
//        setFaxNo3rd((String) request.getAttribute("faxNo3rd"));
//        setBirthYear((String) request.getAttribute("birthYear"));
//        setBirthMonth((String) request.getAttribute("birthMonth"));
//        setBirthDay((String) request.getAttribute("birthDay"));
//
//        //�Ζ�����
//        setKinmusakiName((String) request.getAttribute("kinmusakiName"));
//        setKinmusakiYubinNo((String) request.getAttribute("kinmusakiYubinNo"));
//        setKinmusakiJusho1((String) request.getAttribute("kinmusakiJusho1"));
//        setKinmusakiJusho2((String) request.getAttribute("kinmusakiJusho2"));
//        setKinmusakiTatemono((String) request.getAttribute("kinmusakiTatemono"));
//        setKinmusakiTelNo((String) request.getAttribute("kinmusakiTelNo"));
//        setKinmusakiFaxNo((String) request.getAttribute("kinmusakiFaxNo"));
//
//        setKinmusakiYubinFront((String) request.getAttribute("kinmusakiYubinFront"));
//        setKinmusakiYubinBack((String) request.getAttribute("kinmusakiYubinBack"));
//        setKinmusakiTelNo1st((String) request.getAttribute("kinmusakiTelNo1st"));
//        setKinmusakiTelNo2nd((String) request.getAttribute("kinmusakiTelNo2nd"));
//        setKinmusakiTelNo3rd((String) request.getAttribute("kinmusakiTelNo3rd"));
//        setKinmusakiFaxNo1st((String) request.getAttribute("kinmusakiFaxNo1st"));
//        setKinmusakiFaxNo2nd((String) request.getAttribute("kinmusakiFaxNo2nd"));
//        setKinmusakiFaxNo3rd((String) request.getAttribute("kinmusakiFaxNo3rd"));
//
//        //���t��
//        setSofusakiChoice((String) request.getAttribute("sofusakiChoice"));
//
//        //�o�^��
//        setMemJohoUpdate((String) request.getAttribute("memJohoUpdate"));
//        setKaiinJoho((String) request.getAttribute("kaiinJoho"));
//        setMskJohoUpdateBack((String) request.getAttribute("mskJohoUpdateBack"));
//        setMskJohoUpdateNext((String) request.getAttribute("mskJohoUpdateNext"));
//
//        setMemJohoKauninKakutei((String) request.getAttribute("memJohoKauninKakutei"));
//        setMemJohoKauninBack((String) request.getAttribute("memJohoKauninBack"));
//        setUpdateCompleteBack((String) request.getAttribute("updateCompleteBack"));
//
    }
//
//    public String getGenderDisp() {
//        if (this.getGender().equals(BmaConstants.SEX_CODE_MALE)) {
//            return "�j��";
//        } else {
//            return "����";
//        }
//    }
//
//    public String getSofusakiChoiceDisp() {
//        if (this.getGender().equals(BmaConstants.SOFUSAKI_JITAKU)) {
//            return "����Z��";
//        } else {
//            return "�Ζ���Z��";
//        }
//    }
//
//    public Messages getErrors() {
//        return errors;
//    }
//
//    public void setErrors(Messages errors) {
//        this.errors = errors;
//    }
//
//    public String getMemJohoUpdate() {
//        return memJohoUpdate;
//    }
//
//    public void setMemJohoUpdate(String memJohoUpdate) {
//        this.memJohoUpdate = memJohoUpdate;
//    }
//
//    public String getKaiinJoho() {
//        return kaiinJoho;
//    }
//
//    public void setKaiinJoho(String kaiinJoho) {
//        this.kaiinJoho = kaiinJoho;
//    }
//
//    public String getShimei() {
//        return shimei;
//    }
//
//    public void setShimei(String shimei) {
//        this.shimei = shimei;
//    }
//
//    public String getFurigana() {
//        return furigana;
//    }
//
//    public void setFurigana(String furigana) {
//        this.furigana = furigana;
//    }
//
//    public String getBirthday() {
//        return birthday;
//    }
//
//    public void setBirthday(String birthday) {
//        this.birthday = birthday;
//    }
//
//    public String getGender() {
//        return gender;
//    }
//
//    public void setGender(String gender) {
//        this.gender = gender;
//    }
//
//    public String getYubinNo() {
//        return yubinNo;
//    }
//
//    public void setYubinNo(String yubinNo) {
//        this.yubinNo = yubinNo;
//    }
//
//    public String getJusho1() {
//        return jusho1;
//    }
//
//    public void setJusho1(String jusho1) {
//        this.jusho1 = jusho1;
//    }
//
//    public String getJusho2() {
//        return jusho2;
//    }
//
//    public void setJusho2(String jusho2) {
//        this.jusho2 = jusho2;
//    }
//
//    public String getTatemono() {
//        return tatemono;
//    }
//
//    public void setTatemono(String tatemono) {
//        this.tatemono = tatemono;
//    }
//
//    public String getTelNo() {
//        return telNo;
//    }
//
//    public void setTelNo(String telNo) {
//        this.telNo = telNo;
//    }
//
//    public String getFaxNo() {
//        return faxNo;
//    }
//
//    public void setFaxNo(String faxNo) {
//        this.faxNo = faxNo;
//    }
//
//    public String getMailAddoress() {
//        return mailAddoress;
//    }
//
//    public void setMailAddoress(String mailAddoress) {
//        this.mailAddoress = mailAddoress;
//    }
//
//    public String getKokuseki() {
//        return kokuseki;
//    }
//
//    public void setKokuseki(String kokuseki) {
//        this.kokuseki = kokuseki;
//    }
//
//    public String getZairyucardNo() {
//        return zairyucardNo;
//    }
//
//    public void setZairyucardNo(String zairyucardNo) {
//        this.zairyucardNo = zairyucardNo;
//    }
//
//    public String getKinmusakiName() {
//        return kinmusakiName;
//    }
//
//    public void setKinmusakiName(String kinmusakiName) {
//        this.kinmusakiName = kinmusakiName;
//    }
//
//    public String getKinmusakiYubinNo() {
//        return kinmusakiYubinNo;
//    }
//
//    public void setKinmusakiYubinNo(String kinmusakiYubinNo) {
//        this.kinmusakiYubinNo = kinmusakiYubinNo;
//    }
//
//    public String getKinmusakiJusho1() {
//        return kinmusakiJusho1;
//    }
//
//    public void setKinmusakiJusho1(String kinmusakiJusho1) {
//        this.kinmusakiJusho1 = kinmusakiJusho1;
//    }
//
//    public String getKinmusakiJusho2() {
//        return kinmusakiJusho2;
//    }
//
//    public void setKinmusakiJusho2(String kinmusakiJusho2) {
//        this.kinmusakiJusho2 = kinmusakiJusho2;
//    }
//
//    public String getKinmusakiTatemono() {
//        return kinmusakiTatemono;
//    }
//
//    public void setKinmusakiTatemono(String kinmusakiTatemono) {
//        this.kinmusakiTatemono = kinmusakiTatemono;
//    }
//
//    public String getKinmusakiTelNo() {
//        return kinmusakiTelNo;
//    }
//
//    public void setKinmusakiTelNo(String kinmusakiTelNo) {
//        this.kinmusakiTelNo = kinmusakiTelNo;
//    }
//
//    public String getKinmusakiFaxNo() {
//        return kinmusakiFaxNo;
//    }
//
//    public void setKinmusakiFaxNo(String kinmusakiFaxNo) {
//        this.kinmusakiFaxNo = kinmusakiFaxNo;
//    }
//
//    public String getSofusakiChoice() {
//        return sofusakiChoice;
//    }
//
//    public void setSofusakiChoice(String sofusakiChoice) {
//        this.sofusakiChoice = sofusakiChoice;
//    }
//
//    public String getMskJohoUpdateBack() {
//        return mskJohoUpdateBack;
//    }
//
//    public void setMskJohoUpdateBack(String mskJohoUpdateBack) {
//        this.mskJohoUpdateBack = mskJohoUpdateBack;
//    }
//
//    public String getMskJohoUpdateNext() {
//        return mskJohoUpdateNext;
//    }
//
//    public void setMskJohoUpdateNext(String mskJohoUpdateNext) {
//        this.mskJohoUpdateNext = mskJohoUpdateNext;
//    }
//
//    public String getYushikakuName() {
//        return yushikakuName;
//    }
//
//    public String getYushikakuGokakuNo() {
//        return yushikakuGokakuNo;
//    }
//
//    public String getYushikakuYukokigen() {
//        return yushikakuYukokigen;
//    }
//
//    public void setYushikakuName(String yushikakuName) {
//        this.yushikakuName = yushikakuName;
//    }
//
//    public void setYushikakuGokakuNo(String yushikakuGokakuNo) {
//        this.yushikakuGokakuNo = yushikakuGokakuNo;
//    }
//
//    public void setYushikakuYukokigen(String yushikakuYukokigen) {
//        this.yushikakuYukokigen = yushikakuYukokigen;
//    }
//
//    public List<MemJoho> getYushikakuJohoList() {
//        return yushikakuJohoList;
//    }
//
//    public void setYushikakuJohoList(List<MemJoho> yushikakuJohoList) {
//        this.yushikakuJohoList = yushikakuJohoList;
//    }
//
//    public String getYubinNoFront() {
//        return yubinNoFront;
//    }
//
//    public void setYubinNoFront(String yubinNoFront) {
//        this.yubinNoFront = yubinNoFront;
//    }
//
//    public String getYubinNoBack() {
//        return yubinNoBack;
//    }
//
//    public void setYubinNoBack(String yubinNoBack) {
//        this.yubinNoBack = yubinNoBack;
//    }
//
//    public String getTelNo1st() {
//        return telNo1st;
//    }
//
//    public void setTelNo1st(String telNo1st) {
//        this.telNo1st = telNo1st;
//    }
//
//    public String getTelNo2nd() {
//        return telNo2nd;
//    }
//
//    public void setTelNo2nd(String telNo2nd) {
//        this.telNo2nd = telNo2nd;
//    }
//
//    public String getTelNo3rd() {
//        return telNo3rd;
//    }
//
//    public void setTelNo3rd(String telNo3rd) {
//        this.telNo3rd = telNo3rd;
//    }
//
//    public String getFaxNo1st() {
//        return faxNo1st;
//    }
//
//    public void setFaxNo1st(String faxNo1st) {
//        this.faxNo1st = faxNo1st;
//    }
//
//    public String getFaxNo2nd() {
//        return faxNo2nd;
//    }
//
//    public void setFaxNo2nd(String faxNo2nd) {
//        this.faxNo2nd = faxNo2nd;
//    }
//
//    public String getFaxNo3rd() {
//        return faxNo3rd;
//    }
//
//    public void setFaxNo3rd(String faxNo3rd) {
//        this.faxNo3rd = faxNo3rd;
//    }
//
//    public String getKinmusakiYubinFront() {
//        return kinmusakiYubinFront;
//    }
//
//    public void setKinmusakiYubinFront(String kinmusakiYubinFront) {
//        this.kinmusakiYubinFront = kinmusakiYubinFront;
//    }
//
//    public String getKinmusakiYubinBack() {
//        return kinmusakiYubinBack;
//    }
//
//    public void setKinmusakiYubinBack(String kinmusakiYubinBack) {
//        this.kinmusakiYubinBack = kinmusakiYubinBack;
//    }
//
//    public String getKinmusakiTelNo1st() {
//        return kinmusakiTelNo1st;
//    }
//
//    public void setKinmusakiTelNo1st(String kinmusakiTelNo1st) {
//        this.kinmusakiTelNo1st = kinmusakiTelNo1st;
//    }
//
//    public String getKinmusakiTelNo2nd() {
//        return kinmusakiTelNo2nd;
//    }
//
//    public void setKinmusakiTelNo2nd(String kinmusakiTelNo2nd) {
//        this.kinmusakiTelNo2nd = kinmusakiTelNo2nd;
//    }
//
//    public String getKinmusakiTelNo3rd() {
//        return kinmusakiTelNo3rd;
//    }
//
//    public void setKinmusakiTelNo3rd(String kinmusakiTelNo3rd) {
//        this.kinmusakiTelNo3rd = kinmusakiTelNo3rd;
//    }
//
//    public String getKinmusakiFaxNo1st() {
//        return kinmusakiFaxNo1st;
//    }
//
//    public void setKinmusakiFaxNo1st(String kinmusakiFaxNo1st) {
//        this.kinmusakiFaxNo1st = kinmusakiFaxNo1st;
//    }
//
//    public String getKinmusakiFaxNo2nd() {
//        return kinmusakiFaxNo2nd;
//    }
//
//    public void setKinmusakiFaxNo2nd(String kinmusakiFaxNo2nd) {
//        this.kinmusakiFaxNo2nd = kinmusakiFaxNo2nd;
//    }
//
//    public String getKinmusakiFaxNo3rd() {
//        return kinmusakiFaxNo3rd;
//    }
//
//    public void setKinmusakiFaxNo3rd(String kinmusakiFaxNo3rd) {
//        this.kinmusakiFaxNo3rd = kinmusakiFaxNo3rd;
//    }
//
//    public String getMailAddoressKakunin() {
//        return mailAddoressKakunin;
//    }
//
//    public void setMailAddoressKakunin(String mailAddoressKakunin) {
//        this.mailAddoressKakunin = mailAddoressKakunin;
//    }
//
//    public String getAdrSrc() {
//        return adrSrc;
//    }
//
//    public void setAdrSrc(String adrSrc) {
//        this.adrSrc = adrSrc;
//    }
//
//    public String getKinmusakiAdrSrc() {
//        return kinmusakiAdrSrc;
//    }
//
//    public void setKinmusakiAdrSrc(String kinmusakiAdrSrc) {
//        this.kinmusakiAdrSrc = kinmusakiAdrSrc;
//    }
//
//    public List<String> getSofusakiChoiceList() {
//        return sofusakiChoiceList;
//    }
//
//    public void setSofusakiChoiceList(List<String> sofusakiChoiceList) {
//        this.sofusakiChoiceList = sofusakiChoiceList;
//    }
//
//    public String getMemJohoKauninKakutei() {
//        return memJohoKauninKakutei;
//    }
//
//    public String getMemJohoKauninBack() {
//        return memJohoKauninBack;
//    }
//
//    public void setMemJohoKauninKakutei(String memJohoKauninKakutei) {
//        this.memJohoKauninKakutei = memJohoKauninKakutei;
//    }
//
//    public void setMemJohoKauninBack(String memJohoKauninBack) {
//        this.memJohoKauninBack = memJohoKauninBack;
//    }
//
//    public String getUpdateCompleteBack() {
//        return updateCompleteBack;
//    }
//
//    public void setUpdateCompleteBack(String updateCompleteBack) {
//        this.updateCompleteBack = updateCompleteBack;
//    }
//
//    public String getBirthYear() {
//        return birthYear;
//    }
//
//    public void setBirthYear(String birthYear) {
//        this.birthYear = birthYear;
//    }
//
//    public String getBirthMonth() {
//        return birthMonth;
//    }
//
//    public void setBirthMonth(String birthMonth) {
//        this.birthMonth = birthMonth;
//    }
//
//    public String getBirthDay() {
//        return birthDay;
//    }
//
//    public void setBirthDay(String birthDay) {
//        this.birthDay = birthDay;
//    }
//
//    public String[] getShozaichi_code_list() {
//        return shozaichi_code_list;
//    }
//
//    public void setShozaichi_code_list(String[] shozaichi_code_list) {
//        this.shozaichi_code_list = shozaichi_code_list;
//    }
//
//    public String[] getShozaichi_kanji_list() {
//        return shozaichi_kanji_list;
//    }
//
//    public void setShozaichi_kanji_list(String[] shozaichi_kanji_list) {
//        this.shozaichi_kanji_list = shozaichi_kanji_list;
//    }
}
