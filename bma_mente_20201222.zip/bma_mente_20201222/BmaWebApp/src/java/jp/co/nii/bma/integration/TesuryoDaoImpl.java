package jp.co.nii.bma.integration;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import static jp.co.nii.bma.business.domain.GeneratedRyokinDao.TABLE_NAME;
import jp.co.nii.bma.business.domain.Ryokin;
import jp.co.nii.bma.business.domain.Tesuryo;
import jp.co.nii.bma.business.domain.TesuryoDao;
import static jp.co.nii.bma.integration.GeneratedRyokinDaoImpl.FIELDS_DECRYPT;
import jp.co.nii.sew.common.LogGenerate;
import jp.co.nii.sew.integration.SQLStateSQLExceptionTranslater;

/**
 * �萔�� DAO�����N���X
 * @author DB�Ǘ��c�[��
 */
public class TesuryoDaoImpl extends GeneratedTesuryoDaoImpl implements TesuryoDao {

    /**
     * �C���X�^���X�𐶐�����B
     * @param datasource �f�[�^�\�[�X��
     */
    public TesuryoDaoImpl(String datasource) {
        super(datasource);
    }
    
     /**
     * �萔�����擾����
     * @param bo
     * @return 
     */
    @Override
    public List<Tesuryo> findByRyokinKbn(Tesuryo bo) {

        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql;
        ArrayList<String> paramList = new ArrayList<>();
        List<Tesuryo> tesuryoList = new ArrayList<>();
        try {
            con = getConnection();
            sql = "SELECT " + FIELDS_DECRYPT
                    + " FROM " + getSchemaName() + "." + TABLE_NAME
                    + " WHERE"
                    + " KESSAI_HOHO_KBN = ?"
                    + " AND MOSHIKOMI_KBN = '1'"
                    + " AND RONRI_SAKUJO_FLG = '0'"
                    + " ORDER BY TESURYO_CODE";

            paramList.add(bo.getKessaiHohoKbn());
            stmt = con.prepareStatement(sql);

            int i = 1;
            for (String param : paramList) {
                
                stmt.setString(i++, param);
            }
            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();
            while (rs.next()) {
                Tesuryo tesuryo = new Tesuryo();
               tesuryo.setTesuryo(rs.getString("TESURYO"));
               tesuryo.setKakakuFrom(rs.getString("KAKAKU_FROM"));
               tesuryo.setKakakuTo(rs.getString("KAKAKU_TO"));
               tesuryo.setMarumeKbn(rs.getString("MARUME_KBN"));
               tesuryoList.add(tesuryo);
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return tesuryoList;
    }
}
