package jp.co.nii.bma.business.service.moshikomi;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import jp.co.nii.bma.business.domain.KessaiYokyu;
import jp.co.nii.bma.business.domain.MeishoKanri;
import jp.co.nii.bma.business.domain.Moshikomi;
import jp.co.nii.bma.business.domain.SknksuMst;
import jp.co.nii.bma.business.domain.Torokusha;
import jp.co.nii.bma.business.rto.MskKessaiJoho;
import jp.co.nii.bma.business.service.common.BmaConstants;
import jp.co.nii.bma.business.service.common.BmaLogger;
import jp.co.nii.bma.business.service.common.BmaValidator;
import jp.co.nii.bma.business.service.common.KingakuKeisanService;
import jp.co.nii.bma.business.service.common.MoshikomiCommonService;
import jp.co.nii.bma.utility.BmaStringUtility;
import jp.co.nii.bma.utility.BmaUtility;
import jp.co.nii.sew.business.Validator;
import jp.co.nii.sew.business.service.AbstractService;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_BACK;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_RELOAD;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_SESSION;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_SUCCESS;
import jp.co.nii.sew.presentation.Messages;
import jp.co.nii.sew.presentation.Option;
import jp.co.nii.sew.presentation.RequestTransferObject;
import jp.co.nii.sew.utility.PropertyUtility;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_CANCEL;
import jp.co.nii.sew.utility.StringUtility;

/**
 * <p>
 * �^�C�g��: �\��������</p>
 * <p>
 * ����: �c�̌��ϑI���T�[�r�X</p>
 * <p>
 * ���쌠: Copyright (c) 2020</p>
 * <p>
 * ��Ж�: ���{���Y�Ɗ������</p>
 */
public class MskKessaiSelectGroupService extends AbstractService {

    /**
     * DB�ڑ��̃f�[�^�\�[�X
     */
    private static String DATA_SOURCE_NAME;
    /**
     * ���O
     */
    BmaLogger log = (BmaLogger) BmaLogger.getLogger(this.getClass().getName());
    /**
     * �Ɩ��R�[�h
     */
    private static final String BUSINESS_CODE = PropertyUtility.getProperty("business_code");
    /**
     * ���׃e�X�g���[�h
     */
    private static final String STRESS_MODE = PropertyUtility.getProperty(BUSINESS_CODE + "stress_mode");

    /**
     * �R���X�g���N�^
     */
    public MskKessaiSelectGroupService() {
        super();
        /* DB�ڑ����̃��[�U�[������ */
        DATA_SOURCE_NAME = BmaConstants.DS_REGISTRANT;
    }

    /**
     * �T�[�r�X�N���X�̎��s���\�b�h
     *
     * @param rto ���N�G�X�g��񂩂�擾����rto
     * @param rtoinSession �Z�b�V�������rto
     * @return foward��
     * @throws Exception ��O
     */
    @Override
    public String doService(RequestTransferObject rto, RequestTransferObject rtoinSession)
            throws Exception {

        MskKessaiJoho inRequest = (MskKessaiJoho) rto;
        MskKessaiJoho inSession = (MskKessaiJoho) rtoinSession;

        String processName = "";
        try {

            if (!BmaUtility.isNullOrEmpty(inRequest.getMskKakutei())) {
                processName = "MskKessaiSelect";
                log.Start(processName);
                //�p�����[�^�[�ۑ�
                inSession.setSknKsuCode(inRequest.getSknKsuCode());
                inSession.setShubetsuCode(inRequest.getShubetsuCode());
                inSession.setKaisuCode(inRequest.getKaisuCode());
                inSession.setSknKsuKbn(inRequest.getSknKsuKbn());
                inSession.setTorokuUserId(inRequest.getTorokuUserId());
                inSession.setTorokuDate(inRequest.getTorokuDate());
                inSession.setTorokuTime(inRequest.getTorokuTime());
                setOptionList(BmaConstants.KESSAI_HOHO_KBN, inSession);
                inSession.setErrors(new Messages());
                inSession.setKessaiSelectFlag(inRequest.getKessaiSelectFlag());
                String result = "";
                inSession.setMskKakutei(inRequest.getMskKakutei());
                if ("kessaiHoho".equals(inRequest.getKessaiSelectFlag())) {
                    result = FWD_NM_SUCCESS;
                } else if ("kessaiSelectMenjo".equals(inRequest.getKessaiSelectFlag())) {
                    inSession.setKessaiHoho(BmaConstants.KESSAI_HOHO_KBN_BENEFITS);
                    result = "confirm";
                }
                return result;
            } else if (!BmaUtility.isNullOrEmpty(inRequest.getKingakuKakuninBack())) {
                processName = "kingakuKakuninBack";
                log.Start(processName);
                inSession.setErrors(new Messages());
                return FWD_NM_BACK;
            } else if (!BmaUtility.isNullOrEmpty(inRequest.getKessaiHohoNext())) {
                processName = "MskKingakuConfirm";
                log.Start(processName);
                //���ϕ��@�R�[�h�ۑ�
                String kessaiHoho = inRequest.getKessaiHoho();
                Boolean errCheck = ValidatorCaller(inSession, kessaiHoho);
                if (!errCheck) {
                    return FWD_NM_RELOAD;
                }
                inSession.setKessaiHoho(kessaiHoho);
                MeishoKanri meishoKanri = new MeishoKanri(BmaConstants.DS_REGISTRANT);
                //���ϕ��@���̎擾
                String kessaiHohoChi = meishoKanri.find(BmaConstants.KESSAI_HOHO_KBN, kessaiHoho).getHanyoChi();
                inSession.setKessaiHohoChi(kessaiHohoChi);
                //�N�x
                inSession.setNendo(inRequest.getNendo());
                //�\���m�F�����̏ꍇ
                if (BmaConstants.SKN_KBN.equals(inRequest.getSknKsuKbn())) {
                    //�l�����擾
                    Moshikomi moshikomi = new Moshikomi(DATA_SOURCE_NAME);
                    inSession = moshikomi.getNinzuSknKessai(inSession);
                    int sumNinzu = inSession.getGakaJitsugiGenmenNasiNinzu() + inSession.getGakaJitsugiGenmenNinzu() + inSession.getGakaOnlyNinzu() + inSession.getJitsugiOnlyGenmenNasiNinzu()
                            + inSession.getJitsugiOnlyGenmenNinzu() + inSession.getGakaMenjoGenmenNasiNinzu() + inSession.getGakaMenjoGenmenNinzu() + inSession.getJitsugiMenjoNinzu();
                    inSession.setShokeiNinzu(sumNinzu);
                    inSession.setSumNinzu(sumNinzu);

                    //�����擾
                    //�w�ȁE���Z
                    Long gakaJitsugiGenmenNasiJknJkuryo = kingakuKeisan(BmaConstants.SKN_NAIYO_KBN_GAKKA_JITSUGI, kessaiHoho, BmaConstants.GENMEN_NASHI, inSession);
                    Long gakaJitsugiGenmenNasiGokei = gakaJitsugiGenmenNasiJknJkuryo * inSession.getGakaJitsugiGenmenNasiNinzu();
                    Long gakaJitsugiGenmenJknJkuryo = kingakuKeisan(BmaConstants.SKN_NAIYO_KBN_GAKKA_JITSUGI, kessaiHoho, BmaConstants.GENMEN_ARI, inSession);
                    Long gakaJitsugiGenmenGokei = gakaJitsugiGenmenJknJkuryo * inSession.getGakaJitsugiGenmenNinzu();
                    //�w�Ȃ̂�
                    Long gakaOnlyJknJkuryo = kingakuKeisan(BmaConstants.SKN_NAIYO_KBN_GAKKA_NOMI, kessaiHoho, BmaConstants.GENMEN_NASHI, inSession);
                    Long gakaOnlyGokei = gakaOnlyJknJkuryo * inSession.getGakaOnlyNinzu();
                    //���Z�̂�
                    Long jitsugiOnlyGenmenNasiJknJkuryo = kingakuKeisan(BmaConstants.SKN_NAIYO_KBN_JITSUGI_NOMI, kessaiHoho, BmaConstants.GENMEN_NASHI, inSession);
                    Long jitsugiOnlyGenmenNasiGokei = jitsugiOnlyGenmenNasiJknJkuryo * inSession.getJitsugiOnlyGenmenNasiNinzu();
                    Long jitsugiOnlyGenmenJknJkuryo = kingakuKeisan(BmaConstants.SKN_NAIYO_KBN_JITSUGI_NOMI, kessaiHoho, BmaConstants.GENMEN_ARI, inSession);
                    Long jitsugiOnlyGenmenGokei = jitsugiOnlyGenmenJknJkuryo * inSession.getJitsugiOnlyGenmenNinzu();
                    //�w�ȖƏ�
                    Long gakaMenjoGenmenNasiJknJkuryo = kingakuKeisan(BmaConstants.SKN_NAIYO_KBN_GAKKA_MENJO, kessaiHoho, BmaConstants.GENMEN_NASHI, inSession);
                    Long gakaMenjoGenmenNasiGokei = gakaMenjoGenmenNasiJknJkuryo * inSession.getGakaMenjoGenmenNasiNinzu();
                    Long gakaMenjoGenmenJknJkuryo = kingakuKeisan(BmaConstants.SKN_NAIYO_KBN_GAKKA_MENJO, kessaiHoho, BmaConstants.GENMEN_ARI, inSession);
                    Long gakaMenjoGenmenGokei = gakaMenjoGenmenJknJkuryo * inSession.getGakaMenjoGenmenNinzu();
                    //���Z�Ə�
                    Long jitsugiMenjoJknJkuryo = kingakuKeisan(BmaConstants.SKN_NAIYO_KBN_JITSUGI_MENJO, kessaiHoho, BmaConstants.GENMEN_NASHI, inSession);
                    Long jitsugiMenjoGokei = jitsugiMenjoJknJkuryo * inSession.getJitsugiMenjoNinzu();
                    //�����ۑ�
                    inSession.setGakaJitsugiGenmenNasiJknJkuryo(formatKingaku(gakaJitsugiGenmenNasiJknJkuryo) + "�~");
                    inSession.setGakaJitsugiGenmenNasiGokei(formatKingaku(gakaJitsugiGenmenNasiGokei) + "�~");
                    inSession.setGakaJitsugiGenmenJknJkuryo(formatKingaku(gakaJitsugiGenmenJknJkuryo) + "�~");
                    inSession.setGakaJitsugiGenmenGokei(formatKingaku(gakaJitsugiGenmenGokei) + "�~");
                    inSession.setGakaOnlyJknJkuryo(formatKingaku(gakaOnlyJknJkuryo) + "�~");
                    inSession.setGakaOnlyGokei(formatKingaku(gakaOnlyGokei) + "�~");
                    inSession.setJitsugiOnlyGenmenNasiJknJkuryo(formatKingaku(jitsugiOnlyGenmenNasiJknJkuryo) + "�~");
                    inSession.setJitsugiOnlyGenmenNasiGokei(formatKingaku(jitsugiOnlyGenmenNasiGokei) + "�~");
                    inSession.setJitsugiOnlyGenmenJknJkuryo(formatKingaku(jitsugiOnlyGenmenJknJkuryo) + "�~");
                    inSession.setJitsugiOnlyGenmenGokei(formatKingaku(jitsugiOnlyGenmenGokei) + "�~");
                    inSession.setGakaMenjoGenmenNasiJknJkuryo(formatKingaku(gakaMenjoGenmenNasiJknJkuryo) + "�~");
                    inSession.setGakaMenjoGenmenNasiGokei(formatKingaku(gakaMenjoGenmenNasiGokei) + "�~");
                    inSession.setGakaMenjoGenmenJknJkuryo(formatKingaku(gakaMenjoGenmenJknJkuryo) + "�~");
                    inSession.setGakaMenjoGenmenGokei(formatKingaku(gakaMenjoGenmenGokei) + "�~");
                    inSession.setJitsugiMenjoJknJkuryo(formatKingaku(jitsugiMenjoJknJkuryo) + "�~");
                    inSession.setJitsugiMenjoGokei(formatKingaku(jitsugiMenjoGokei) + "�~");
                    KingakuKeisanService KingakuKeisan = new KingakuKeisanService(DATA_SOURCE_NAME);
                    Long shokeiGokei = gakaJitsugiGenmenNasiGokei + gakaJitsugiGenmenGokei + gakaOnlyGokei + jitsugiOnlyGenmenNasiGokei + jitsugiOnlyGenmenGokei
                            + gakaMenjoGenmenNasiGokei + gakaMenjoGenmenGokei + jitsugiMenjoGokei;
                    Long tesuryoGokei = KingakuKeisan.calcAmount(inSession.getSknKsuCode(), inSession.getShubetsuCode(),
                            "0", BmaConstants.SKN_NAIYO_KBN_NASHI, kessaiHoho, BmaConstants.GENMEN_NASHI, BmaConstants.TESURYO_FLAG_ARI, shokeiGokei).get(1);
                    inSession.setTesuryoGokei(formatKingaku(tesuryoGokei) + "�~");
                    inSession.setShokeiGokei(formatKingaku(shokeiGokei) + "�~");
                    inSession.setSumNinzuGokei(formatKingaku(shokeiGokei + tesuryoGokei) + "�~");
                }

                //�\���m�F�u�K��̏ꍇ
                if (BmaConstants.KSU_KBN.equals(inSession.getSknKsuKbn())) {
                    //�l�����擾
                    Moshikomi moshikomi = new Moshikomi(DATA_SOURCE_NAME);
                    inSession = moshikomi.getNinzuKsuKessai(inSession);
                    int sumNinzu = inSession.getMoshikomishaNinzu() + inSession.getKyuseidoNinzu();
                    inSession.setShokeiNinzu(sumNinzu);
                    inSession.setSumNinzu(sumNinzu);
                    Long moshikomishaJknJkuryo = kingakuKeisan(BmaConstants.SKN_NAIYO_KBN_NASHI, kessaiHoho, BmaConstants.GENMEN_NASHI, inSession);
                    Long moshikomishaGokei = moshikomishaJknJkuryo * inSession.getMoshikomishaNinzu();
                    Long kyuseidoJknJkuryo = kingakuKeisan(BmaConstants.SKN_NAIYO_KBN_NASHI, BmaConstants.KESSAI_HOHO_KBN_BENEFITS, BmaConstants.GENMEN_NASHI, inSession);
                    Long kyuseidoGokei = kyuseidoJknJkuryo * inSession.getKyuseidoNinzu();
                    KingakuKeisanService KingakuKeisan = new KingakuKeisanService(DATA_SOURCE_NAME);
                    Long shokeiGokei = moshikomishaGokei + kyuseidoGokei;
                    Long tesuryoGokei = KingakuKeisan.calcAmount(inSession.getSknKsuCode(), inSession.getShubetsuCode(),
                            "1", BmaConstants.SKN_NAIYO_KBN_NASHI, kessaiHoho, BmaConstants.GENMEN_NASHI, BmaConstants.TESURYO_FLAG_ARI, shokeiGokei).get(1);
                    inSession.setTesuryoGokei(formatKingaku(tesuryoGokei) + "�~");
                    inSession.setMoshikomishaJknJkuryo(formatKingaku(moshikomishaJknJkuryo) + "�~");
                    inSession.setMoshikomishaGokei(formatKingaku(moshikomishaGokei) + "�~");
                    inSession.setKyuseidoJknJkuryo(formatKingaku(kyuseidoJknJkuryo) + "�~");
                    inSession.setKyuseidoGokei(formatKingaku(kyuseidoGokei) + "�~");
                    inSession.setShokeiGokei(formatKingaku(shokeiGokei) + "�~");
                    inSession.setSumNinzuGokei(formatKingaku(shokeiGokei + tesuryoGokei) + "�~");
                }
                Moshikomi moshikomi = new Moshikomi(BmaConstants.DS_REGISTRANT);
                moshikomi = moshikomi.findByTorokuDate(inSession.getTorokuUserId(), inSession.getTorokuDate(), inSession.getTorokuTime());
                inSession.setMoshikomishaId(inRequest.getMoshikomishaId());
                inSession.setNendo(moshikomi.getNendo());
                inSession.setUketsukeNo(moshikomi.getUketsukeNo());
                return "kingaku";
            } else if (!BmaUtility.isNullOrEmpty(inRequest.getKessaiHohoBack())) {
                processName = "MskKessaiSelectBack";
                log.Start(processName);
                String result = inRequest.getKessaiHohoBack().equals("ok") ? FWD_NM_CANCEL : FWD_NM_RELOAD;
                return result;
            } else if (!BmaUtility.isNullOrEmpty(inRequest.getKingakuKakuninNext())) {
                processName = "MskKessaiSelectNext";
                log.Start(processName);
                // �t�����ݒ�
                MoshikomiCommonService commonService = new MoshikomiCommonService(DATA_SOURCE_NAME);
                commonService.setFukaInfo(inRequest, inSession);
                KessaiYokyu kessaiYokyu = new KessaiYokyu(BmaConstants.DS_REGISTRANT);
                kessaiYokyuTrk(kessaiYokyu, inRequest, inSession);
                kessaiYokyu.create();
                return "redirect";
            } else if (!BmaUtility.isNullOrEmpty(inRequest.getKessaiSelectComplete())) {
                processName = "MskKessaiSelectComplete";
                log.Start(processName);
                return "complete";
            } else if (!BmaUtility.isNullOrEmpty(inRequest.getKessaiSelectMenjoBack())) {
                processName = "MskKessaiSelectMenjoBack";
                log.Start(processName);
                inSession.clearInfo();
                String result = inRequest.getKessaiHohoBack().equals("ok") ? FWD_NM_CANCEL : FWD_NM_RELOAD;
                return result;
            } else if (!BmaUtility.isNullOrEmpty(inRequest.getKessaiComplete())) {
                processName = "MskKessaiSelectMenjoBack";
                log.Start(processName);
                String result = null;
                switch (inSession.getKessaiHoho()) {
                    case BmaConstants.KESSAI_HOHO_KBN1:
                        result = "card";
                        break;
                    case BmaConstants.KESSAI_HOHO_KBN2:
                        result = "conveni";
                        break;
                    case BmaConstants.KESSAI_HOHO_KBN3:
                        result = "payeasy";
                        break;
                    default:
                        break;
                }
                return result;
            } else {
                /*�ُ�J��*/
                log.IllegalFWD();
                return FWD_NM_SESSION;
            }
        } catch (Exception e) {
            throw e;
        } finally {
            log.End(processName);
        }
    }

    /**
     * ���ϕ��@���X�g���Z�b�g����
     *
     * @param sknNaiyoKbn
     * @param kessaiHoho
     * @param genmenShinsei
     * @param inSession
     * @return
     */
    public Long kingakuKeisan(String sknNaiyoKbn, String kessaiHoho, String genmenShinsei, MskKessaiJoho inSession) {
        Long jknJkuryo;
        KingakuKeisanService KingakuKeisan = new KingakuKeisanService(DATA_SOURCE_NAME);
        String sknKsuCode = inSession.getSknKsuCode();
        String shubetsuCode = inSession.getShubetsuCode();
        String mskKbnSentaku = BmaConstants.SKN_KBN.equals(inSession.getSknKsuKbn()) ? "0" : "1";
        String tesuryoFlag = "1";
        jknJkuryo = KingakuKeisan.calcAmount(sknKsuCode, shubetsuCode,
                mskKbnSentaku, sknNaiyoKbn, kessaiHoho, genmenShinsei, tesuryoFlag, 0L).get(0);
        return jknJkuryo;
    }

    /**
     * ���ϕ��@���X�g���Z�b�g����
     *
     * @param inSession
     * @param groupCode
     */
    public void setOptionList(String groupCode, MskKessaiJoho inSession) {
        List<Option> list = new ArrayList<>();
        //���ϕ��@��p�ӂ���
        MeishoKanri meishoKanri = new MeishoKanri(BmaConstants.DS_REGISTRANT);
        meishoKanri.findByGroupCode(groupCode, list);
        inSession.setKessaiHohoList(list);
    }

    /**
     * ���ϗv����o�^����
     *
     * @param bo
     * @param inSession
     * @param inRequest
     * @throws java.lang.Exception
     */
    public void kessaiYokyuTrk(KessaiYokyu bo, MskKessaiJoho inRequest, MskKessaiJoho inSession) throws Exception {
        Date date = new Date();
        SimpleDateFormat dt = new SimpleDateFormat("yyyyMMdd");
        SimpleDateFormat tm = new SimpleDateFormat("HHmmss");
        SknksuMst sknksuMst = new SknksuMst(BmaConstants.DS_REGISTRANT);
        String shikakuName = sknksuMst.find(inSession.getSknKsuCode(), inSession.getShubetsuCode(), inSession.getKaisuCode()).getSikakuName();
        String kessaiHoho = inSession.getKessaiHoho();
        Torokusha torokusha = new Torokusha(BmaConstants.DS_REGISTRANT);
        torokusha = torokusha.find(inSession.getMoshikomishaId());
        bo.setTorihikiCodeNaibu(inSession.getUketsukeNo());
        // ���i���P
        bo.setShohinName1(StringUtility.cutString(shikakuName,BmaConstants.KESSAI_YOKYU_SHOHIN_MEI_MAX_LENGTH));
         // ���z�P
        String kingaku = StringUtility.cutString(inSession.getSumNinzuGokei().replace(",", "").replace("�~", ""), BmaConstants.KESSAI_YOKYU_KINGAKU_MAX_LENGTH);
        bo.setKingaku1(kingaku);
        bo.setShohinName2("");
        bo.setKingaku2("");
        bo.setShohinName3("");
        bo.setKingaku3("");
        bo.setShohinName4("");
        bo.setKingaku4("");
        bo.setShohinName5("");
        bo.setKingaku5("");
        bo.setShohinName6("");
        bo.setKingaku6("");
        bo.setHukaJoho(inRequest.getFuka());
        bo.setKessaiHohoStore((BmaConstants.KESSAI_HOHO_TO_STORE.get(kessaiHoho)));
        bo.setFinishUrl(BmaConstants.KESSAI_OK_URL);
        bo.setModoriUrl(BmaConstants.KESSAI_RT_URL);
        String kanjiShimei;
        if (!torokusha.getShimei().equals("")) {
            // ��������
            kanjiShimei = StringUtility.cutString(BmaStringUtility.convertHankakuToZenkakuBma(torokusha.getShimei().replaceAll("�@", " ").split(" ")[0]) + BmaConstants.KESSAI_FUKA_SEPARATOR + BmaStringUtility.convertHankakuToZenkakuBma(torokusha.getShimei().replaceAll("�@", " ").split(" ")[1]), BmaConstants.KESSAI_YOKYU_KANJI_SHIMEI_MAX_LENGTH + 1);
            // ��������(��)
            inRequest.setShimeiSei(kanjiShimei.split("\\" + BmaConstants.KESSAI_FUKA_SEPARATOR)[0]);
            // ��������(��)
            inRequest.setShimeiMei(kanjiShimei.split("\\" + BmaConstants.KESSAI_FUKA_SEPARATOR)[1]);
        }
        String kanaShimei;
        if (!torokusha.getFurigana().equals("")) {
            // �J�i����
            kanaShimei = StringUtility.cutString(BmaStringUtility.convertHankakuToZenkakuBma(torokusha.getFurigana().replaceAll("�@", " ").split(" ")[0]) + BmaConstants.KESSAI_FUKA_SEPARATOR + BmaStringUtility.convertHankakuToZenkakuBma(torokusha.getFurigana().replaceAll("�@", " ").split(" ")[1]), BmaConstants.KESSAI_YOKYU_KANJI_SHIMEI_MAX_LENGTH + 1);
            kanaShimei = kanaShimei.replace("�@", "");
            // �J�i����(��)
            inRequest.setFuriganaSei(kanaShimei.split("\\" + BmaConstants.KESSAI_FUKA_SEPARATOR)[0]);
            // �J�i����(��)
            inRequest.setFuriganaMei(kanaShimei.split("\\" + BmaConstants.KESSAI_FUKA_SEPARATOR)[1]);
        }
        bo.setBuyerKanjiShimeiSei(inRequest.getShimeiSei());
        bo.setBuyerKanjiShimeiMei(inRequest.getShimeiMei());
        bo.setBuyerKanaShimeiSei(inRequest.getFuriganaSei());
        bo.setBuyerKanaShimeiMei(inRequest.getFuriganaMei());
        bo.setBuyerZipNum1(torokusha.getYubinNo());
        bo.setBuyerZipNum2("");
        bo.setBuyerTelNo(StringUtility.cutString(torokusha.getTelNo(), BmaConstants.KESSAI_YOKYU_TEL_MAX_LENGTH));
        bo.setBuyerJusho1(StringUtility.cutString(BmaStringUtility.convertHankakuToZenkakuBma(torokusha.getJusho1()), BmaConstants.KESSAI_YOKYU_ADR_MAX_LENGTH));
        bo.setBuyerJusho2(StringUtility.cutString(BmaStringUtility.convertHankakuToZenkakuBma(torokusha.getJusho2()), BmaConstants.KESSAI_YOKYU_ADR_MAX_LENGTH));
        bo.setBuyerMailAddress(torokusha.getMailAddress());
        // ������
        MoshikomiCommonService commonService = new MoshikomiCommonService(DATA_SOURCE_NAME);
        String kigenbi = commonService.getKigenbi(inRequest.getNendo(), inRequest.getSknKsuCode(), inRequest.getShubetsuCode(), inRequest.getKaisuCode(), new Date());
        bo.setShiharaiKigen(kigenbi);
        bo.setUchizeiGaku("");
        bo.setUserId(inRequest.getMoshikomishaId());
        bo.setHyojiLanguage("0");
        bo.setKessaiKakutei((kessaiHoho.equals("1")) ? "0" : "");
        bo.setTsukiGakuKingaku("");
        bo.setTsukiGakuKakutei("");
        bo.setNextKessaiBi("");
        bo.setTsukiGakuKessaiBi("");
        bo.setHukaJohoGetsugakukessaiji("");
        bo.setKakuteiBi("");
        bo.setKoshinKbn("I");
        bo.setTorokuDate(dt.format(date));
        bo.setTorokuTime(tm.format(date));
        bo.setTorokuUserId(inRequest.getMoshikomishaId());
        bo.setKoshinDate("");
        bo.setKoshinTime("");
        bo.setKoshinUserId("");
        bo.setRonriSakujoFlg("");
        inRequest.setKessaiHoho(kessaiHoho);
        inRequest.setSid(inSession.getUketsukeNo());
        inRequest.setN1(shikakuName);
        inRequest.setK1(inSession.getSumNinzuGokei().replace(",", "").replace("�~", ""));
        inRequest.setTelNo(bo.getBuyerTelNo());
        inRequest.setTax("");
        inRequest.setName1(inRequest.getShimeiSei());
        inRequest.setName2(inRequest.getShimeiMei());
        inRequest.setKana1(inRequest.getFuriganaSei());
        inRequest.setKana2(inRequest.getFuriganaMei());
        inRequest.setYubin1(torokusha.getYubinNo().substring(0, 3));
        inRequest.setYubin2(torokusha.getYubinNo().substring(3, 7));
        inRequest.setMail(torokusha.getMailAddress());
        inRequest.setAdr1(bo.getBuyerJusho1());
        inRequest.setShiharaiKigen(kigenbi);
    }

    /**
     * ����p�p�����[�^�[��ۑ�����
     *
     * @param inSession
     * @param inRequest
     */
    public void kessaiYokyuParameter(MskKessaiJoho inRequest, MskKessaiJoho inSession) {
    }

    /**
     * �I���`�F�b�N
     *
     * @param inSession
     * @return ��肪�Ȃ���� true�A����� false
     */
    private boolean ValidatorCaller(MskKessaiJoho inSession, String kessaiHoho) throws Exception {
        Messages errors = new Messages();	//���b�Z�[�W�i�[�p
        List<Option> kessaiHohoList = inSession.getKessaiHohoList();
        int length = kessaiHohoList.size();
        String[] hanyocode = new String[length];
        for (int i = 0; i < length; i++) {
            hanyocode[i] = kessaiHohoList.get(i).getValue();
        }
        // ���ϕ��@�F�K�{�`�F�b�N
        BmaValidator.validateSelect(kessaiHoho, errors, BmaConstants.ERR_GROUP_KESSAI_HOHO, BmaConstants.ARG_KESSAI_HOHO);
        // ���ϕ��@�F�Ó����`�F�b�N
        Validator.validatePermissionSelect(kessaiHoho, hanyocode, errors, BmaConstants.ERR_GROUP_KESSAI_HOHO, BmaConstants.ARG_KESSAI_HOHO);
        if (!errors.isEmpty()) {
            inSession.setErrors(errors);
            return false;
        } else {
            return true;
        }
    }

    //�J���}��؂�ɕύX
    public static String formatKingaku(Long kingaku) {
        DecimalFormat df = new DecimalFormat("#,###");
        return df.format(kingaku);
    }
}
