//package jp.co.nii.bma.integration;
//
//
//import java.sql.Connection;
//import java.sql.PreparedStatement;
//import java.sql.ResultSet;
//import java.sql.SQLException;
//import jp.co.nii.bma.business.domain.KakoJukensha;
//import jp.co.nii.bma.business.domain.KakoJukenshaDao;
//import jp.co.nii.bma.business.service.common.BmaConstants;
//import jp.co.nii.sew.common.LogGenerate;
//import jp.co.nii.sew.integration.SQLStateSQLExceptionTranslater;
//
///**
// * �ߋ��󌱎� DAO�����N���X
// * @author DB�Ǘ��c�[��
// */
//public class KakoJukenshaDaoImpl extends GeneratedKakoJukenshaDaoImpl implements KakoJukenshaDao {
//
//    /**
//     * �C���X�^���X�𐶐�����B
//     * @param datasource �f�[�^�\�[�X��
//     */
//    public KakoJukenshaDaoImpl(String datasource) {
//        super(datasource);
//    }
//    /* (non-Javadoc)
//     * @see jp.co.nii.bma.business.domain.GeneratedKakoJukenshaDao#find(jp.co.nii.bma.business.domain.GeneratedKakoJukensha, java.lang.String)
//     */
//    @Override
//    public KakoJukensha find(KakoJukensha bo,String kakoJukenKyu, String lockMode) {
//        Connection con = null;
//        PreparedStatement stmt = null;
//        ResultSet rs =null;
//        String sql = "";
//        try {
//            con = getConnection();
//            sql = "SELECT " + FIELDS_DECRYPT
//                    + " FROM " + getSchemaName() + "." + TABLE_NAME
//                    + " WHERE"
//                    + " KAKO_JUKEN_NEN = ?"
//                    + " AND KAKO_JUKEN_NO = ?"
//                    + " AND (SUBSTR(KAKO_JUKEN_NO,3,1) = ? "
//                    + " OR SUBSTR(KAKO_JUKEN_NO,3,1) = ? )";
//
//            stmt = con.prepareStatement(sql + lockMode);
//            int i = 1;
//            stmt.setString(i++, bo.getKakoJukenNen());
//            stmt.setString(i++, bo.getKakoJukenNo());
//            if (kakoJukenKyu.equals(BmaConstants.SHIKEN_SHURUI_CODE_IKKYU)){
//                stmt.setString(i++, BmaConstants.JUKEN_KBN_IKKYU_GAKKA);
//                stmt.setString(i++, BmaConstants.JUKEN_KBN_IKKYU_SEIZU);
//            } else if (kakoJukenKyu.equals(BmaConstants.SHIKEN_SHURUI_CODE_NIKYU)){
//                stmt.setString(i++, BmaConstants.JUKEN_KBN_NIKYU_GAKKA);
//                stmt.setString(i++, BmaConstants.JUKEN_KBN_NIKYU_SEIZU);
//            } else if (kakoJukenKyu.equals(BmaConstants.SHIKEN_SHURUI_CODE_MOKUZO)){
//                stmt.setString(i++, BmaConstants.JUKEN_KBN_MOKUZO_GAKKA);
//                stmt.setString(i++, BmaConstants.JUKEN_KBN_MOKUZO_SEIZU);
//            }
//
//            LogGenerate.debugOutput(getSql(stmt));
//            rs = stmt.executeQuery();
//            if (rs.next()) {
//                setBoFromResultSet(bo, rs);
//            } else {
//                bo = null;
//            }
//        } catch (SQLException ex) {
//            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
//        } finally {
//            close(con, stmt, rs);
//        }
//        return bo;
//    }
//
//}
