/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.nii.bma.business.rto;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import jp.co.nii.bma.business.service.common.BmaConstants;
import jp.co.nii.sew.presentation.AbstractRequestTransferObject;
import jp.co.nii.sew.presentation.Messages;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItem;

/**
 *
 * @author BP80139
 */
public class MskGazoJoho extends AbstractRequestTransferObject {

    /**
     * �摜�h�c�w
     */
    private String gazoIdx;
    /**
     * �N�x
     */
    private String nendo;
    /**
     * ��t�ԍ�
     */
    private String uketsukeNo;
    /**
     * �摜�敪
     */
    private String gazoKbn;
    /**
     * �r�d�p
     */
    private String seq;

    private Messages errors;
    private List<MskGazoJoho> shomeishoList;
    private List<MskGazoJoho> jknSikakuList;
    private List<MskGazoJoho> menjoList;
    private List<RrkMskJoho> rrkShomeishoList;
    private List<RrkMskJoho> rrkJknSikakuList;
    private List<RrkMskJoho> rrkMenjoList;
    private String shomeishoruiShubetu;
    private String shomeishoruiUpdStatus;
    private String jknsikakuShubetu;
    private String jknsikakuUpdStatus;
    private String uploadCheck;
    private String updCheck;
    private String menjoShubetu;
    private String menjoUpdStatus;
    private String gazoUpdNotes;
    private String shomeishoruiUpd;
    private String shomeishoruiKakunin;
    private String jknsikakuUpd;
    private String jknsikakuKakunin;
    private String menjoUpd;
    private String menjoKakunin;
    private String gazoUpdBack;
    private String gazoUpdNext;
    private String skkJohoNext;
    private String gazoShubetsu;
    private DiskFileItem gazoHyoji;
    private String gazoPreview;
    private String close;
    private String gazoUpd;
    private String scrollPlace;
    private String moshikomishaId;
    private FileItem fileItem;
    private List<MskGazoJoho> gazoUploadList;
    private List<String> gazoIdxs;
    private String kaoImg;
    private String nenreiImg;
    private String shikakuImg;
    private String menjyoImg;
    private String upload;
    private String fileName;
    private String fileKbn;
    private String gazoUpdFlg;
    // rto�N���A�Ή�
    private String kaoShashin;
    private String nenreiShomeiShrui;
    private String shikakuShomeiShorui;
    private String menjoShomeiShorui;
    
    private String rrkFlg;
    
    /** �����u�K��敪 */
    private String sknKsuKbn;
    
    /**
     * �����[�h
     */
    private String reload;

    
    public MskGazoJoho() {
        clearInfo();
    }

    public void clearInfo() {
        setGazoIdx("");
        setNendo("");
        setUketsukeNo("");
        setSeq("");

        setErrors(new Messages());
        setSkkJohoNext("");
        setShomeishoruiShubetu("");
        setShomeishoruiUpdStatus("");
        setJknsikakuShubetu("");
        setJknsikakuUpdStatus("");
        setMenjoShubetu("");
        setMenjoUpdStatus("");
        setGazoUpdNotes("");
        setShomeishoruiUpd("");
        setUploadCheck("");
        setUpdCheck("");
        setShomeishoruiKakunin("");
        setJknsikakuUpd("");
        setJknsikakuKakunin("");
        setMenjoUpd("");
        setMenjoKakunin("");
        setGazoUpdBack("");
        setGazoUpdNext("");
        setGazoShubetsu("");
        setGazoPreview("");
        setClose("");
        setGazoUpd("");
        setScrollPlace("");
        setGazoKbn("");
        setMoshikomishaId("");
        setUpload("");
        setFileName("");
        setFileKbn("");
        setGazoUpdFlg("");
        setShomeishoList(new ArrayList<>());
        setJknSikakuList(new ArrayList<>());
        setMenjoList(new ArrayList<>());
        setRrkShomeishoList(new ArrayList<>());
        setRrkJknSikakuList(new ArrayList<>());
        setRrkMenjoList(new ArrayList<>());

        setGazoIdxs(new ArrayList<>());
        
        setKaoShashin("");
        setNenreiShomeiShrui("");
        setShikakuShomeiShorui("");
        setMenjoShomeiShorui("");
        
        setRrkFlg("");
        
        setSknKsuKbn("");
        setReload("");

   }

    @Override
    public void copyFromRequest(HttpServletRequest request) {
        setGazoIdx((String) request.getAttribute("gazoIdx"));
        setNendo((String) request.getAttribute("nendo"));
        setUketsukeNo((String) request.getAttribute("uketsukeNo"));
        setSeq((String) request.getAttribute("gazoKbn"));
        setUploadCheck((String) request.getAttribute("uploadCheck"));
        setShomeishoruiShubetu((String) request.getAttribute("shomeishoruiShubetu"));
        setShomeishoruiUpdStatus((String) request.getAttribute("shomeishoruiUpdStatus"));
        setJknsikakuShubetu((String) request.getAttribute("jknsikakuShubetu"));
        setJknsikakuUpdStatus((String) request.getAttribute("jknsikakuUpdStatus"));
        setMenjoShubetu((String) request.getAttribute("menjoShubetu"));
        setMenjoUpdStatus((String) request.getAttribute("menjoUpdStatus"));
        setGazoUpdNotes((String) request.getAttribute("gazoUpdNotes"));
        setShomeishoruiUpd((String) request.getAttribute("shomeishoruiUpd"));
        setShomeishoruiKakunin((String) request.getAttribute("shomeishoruiKakunin"));
        setJknsikakuUpd((String) request.getAttribute("jknsikakuUpd"));
        setJknsikakuKakunin((String) request.getAttribute("jknsikakuKakunin"));
        setMenjoUpd((String) request.getAttribute("menjoUpd"));
        setMenjoKakunin((String) request.getAttribute("menjoKakunin"));
        setGazoUpdBack((String) request.getAttribute("gazoUpdBack"));
        setGazoUpdNext((String) request.getAttribute("gazoUpdNext"));
        setSkkJohoNext((String) request.getAttribute("skkJohoNext"));
        setGazoShubetsu((String) request.getAttribute("gazoShubetsu"));
        setGazoPreview((String) request.getAttribute("gazoPreview"));
        setClose((String) request.getAttribute("close"));
        setGazoUpd((String) request.getAttribute("gazoUpd"));
        setScrollPlace((String) request.getAttribute("scrollPlace"));
        setFileItem((FileItem) request.getAttribute("gazoHyoji"));
        setGazoKbn((String) request.getAttribute("gazoKbn"));
        setMoshikomishaId((String) request.getAttribute("moshikomishaId"));
        setUpload((String) request.getAttribute("upload"));
        setFileName((String) request.getAttribute("fileName"));
        setFileKbn((String) request.getAttribute("fileKbn"));
        setUpdCheck((String) request.getAttribute("updCheck"));
        setRrkFlg((String) request.getAttribute("rrkFlg"));
        setReload((String) request.getAttribute("reload"));

        HttpSession session = request.getSession(false);
        if (session.getAttribute("MskSikakuJoho") != null) {
            MskSikakuJoho temp = (MskSikakuJoho) session.getAttribute("MskSikakuJoho");
            setGazoUpdFlg("");
            setKaoImg(temp.getKaoImg());
            setNenreiImg(temp.getNenreiImg());
            setShikakuImg(temp.getShikakuImg());
            setMenjyoImg(temp.getMenjyoImg());
            
        }
        if (session.getAttribute("RrkMskJoho") != null) {
            RrkMskJoho temp = (RrkMskJoho) session.getAttribute("RrkMskJoho");
            setGazoUpdFlg((String) request.getAttribute("gazoUpdFlg"));
            setRrkShomeishoList(temp.getShomeishoList());
            setRrkJknSikakuList(temp.getJknSikakuList());
            setRrkMenjoList(temp.getMenjoList());
        }
        if (session.getAttribute("MskSknJoho") != null) {
            MskSknJoho tmp = (MskSknJoho) session.getAttribute("MskSknJoho");
            setNendo(tmp.getNendo());
            setSknKsuKbn(tmp.getSknKsuKbn());
        }
        if (session.getAttribute("TopJoho") != null) {
            TopJoho tmp = (TopJoho) session.getAttribute("TopJoho");
            setMoshikomishaId(tmp.getMoshikomishaId());
        }
    }

    /**
     * @return the skkJohoNext
     */
    public String getSkkJohoNext() {
        return skkJohoNext;
    }

    /**
     * @param skkJohoNext the skkJohoNext to set
     */
    public void setSkkJohoNext(String skkJohoNext) {
        this.skkJohoNext = skkJohoNext;
    }

    /**
     * @return the shomeishoruiShubetu
     */
    public String getShomeishoruiShubetu() {
        return shomeishoruiShubetu;
    }

    /**
     * @param shomeishoruiShubetu the shomeishoruiShubetu to set
     */
    public void setShomeishoruiShubetu(String shomeishoruiShubetu) {
        this.shomeishoruiShubetu = shomeishoruiShubetu;
    }

    /**
     * @return the shomeishoruiUpdStatus
     */
    public String getShomeishoruiUpdStatus() {
        return shomeishoruiUpdStatus;
    }

    /**
     * @param shomeishoruiUpdStatus the shomeishoruiUpdStatus to set
     */
    public void setShomeishoruiUpdStatus(String shomeishoruiUpdStatus) {
        this.shomeishoruiUpdStatus = shomeishoruiUpdStatus;
    }

    /**
     * @return the jknsikakuShubetu
     */
    public String getJknsikakuShubetu() {
        return jknsikakuShubetu;
    }

    /**
     * @param jknsikakuShubetu the jknsikakuShubetu to set
     */
    public void setJknsikakuShubetu(String jknsikakuShubetu) {
        this.jknsikakuShubetu = jknsikakuShubetu;
    }

    /**
     * @return the jknsikakuUpdStatus
     */
    public String getJknsikakuUpdStatus() {
        return jknsikakuUpdStatus;
    }

    /**
     * @param jknsikakuUpdStatus the jknsikakuUpdStatus to set
     */
    public void setJknsikakuUpdStatus(String jknsikakuUpdStatus) {
        this.jknsikakuUpdStatus = jknsikakuUpdStatus;
    }

    /**
     * @return the menjoShubetu
     */
    public String getMenjoShubetu() {
        return menjoShubetu;
    }

    /**
     * @param menjoShubetu the menjoShubetu to set
     */
    public void setMenjoShubetu(String menjoShubetu) {
        this.menjoShubetu = menjoShubetu;
    }

    /**
     * @return the menjoUpdStatus
     */
    public String getMenjoUpdStatus() {
        return menjoUpdStatus;
    }

    /**
     * @param menjoUpdStatus the menjoUpdStatus to set
     */
    public void setMenjoUpdStatus(String menjoUpdStatus) {
        this.menjoUpdStatus = menjoUpdStatus;
    }

    /**
     * @return the gazoUpdNotes
     */
    public String getGazoUpdNotes() {
        return gazoUpdNotes;
    }

    /**
     * @param gazoUpdNotes the gazoUpdNotes to set
     */
    public void setGazoUpdNotes(String gazoUpdNotes) {
        this.gazoUpdNotes = gazoUpdNotes;
    }

    /**
     * @return the shomeishoruiUpd
     */
    public String getShomeishoruiUpd() {
        return shomeishoruiUpd;
    }

    /**
     * @param shomeishoruiUpd the shomeishoruiUpd to set
     */
    public void setShomeishoruiUpd(String shomeishoruiUpd) {
        this.shomeishoruiUpd = shomeishoruiUpd;
    }

    /**
     * @return the shomeishoruiKakunin
     */
    public String getShomeishoruiKakunin() {
        return shomeishoruiKakunin;
    }

    /**
     * @param shomeishoruiKakunin the shomeishoruiKakunin to set
     */
    public void setShomeishoruiKakunin(String shomeishoruiKakunin) {
        this.shomeishoruiKakunin = shomeishoruiKakunin;
    }

    /**
     * @return the jknsikakuUpd
     */
    public String getJknsikakuUpd() {
        return jknsikakuUpd;
    }

    /**
     * @param jknsikakuUpd the jknsikakuUpd to set
     */
    public void setJknsikakuUpd(String jknsikakuUpd) {
        this.jknsikakuUpd = jknsikakuUpd;
    }

    /**
     * @return the jknsikakuKakunin
     */
    public String getJknsikakuKakunin() {
        return jknsikakuKakunin;
    }

    /**
     * @param jknsikakuKakunin the jknsikakuKakunin to set
     */
    public void setJknsikakuKakunin(String jknsikakuKakunin) {
        this.jknsikakuKakunin = jknsikakuKakunin;
    }

    /**
     * @return the menjoUpd
     */
    public String getMenjoUpd() {
        return menjoUpd;
    }

    /**
     * @param menjoUpd the menjoUpd to set
     */
    public void setMenjoUpd(String menjoUpd) {
        this.menjoUpd = menjoUpd;
    }

    /**
     * @return the menjoKakunin
     */
    public String getMenjoKakunin() {
        return menjoKakunin;
    }

    /**
     * @param menjoKakunin the menjoKakunin to set
     */
    public void setMenjoKakunin(String menjoKakunin) {
        this.menjoKakunin = menjoKakunin;
    }

    /**
     * @return the gazoUpdBack
     */
    public String getGazoUpdBack() {
        return gazoUpdBack;
    }

    /**
     * @param gazoUpdBack the gazoUpdBack to set
     */
    public void setGazoUpdBack(String gazoUpdBack) {
        this.gazoUpdBack = gazoUpdBack;
    }

    /**
     * @return the gazoUpdNext
     */
    public String getGazoUpdNext() {
        return gazoUpdNext;
    }

    /**
     * @param gazoUpdNext the gazoUpdNext to set
     */
    public void setGazoUpdNext(String gazoUpdNext) {
        this.gazoUpdNext = gazoUpdNext;
    }

    /**
     * @return the gazoShubetsu
     */
    public String getGazoShubetsu() {
        return gazoShubetsu;
    }

    /**
     * @param gazoShubetsu the gazoShubetsu to set
     */
    public void setGazoShubetsu(String gazoShubetsu) {
        this.gazoShubetsu = gazoShubetsu;
    }

    /**
     * @return the gazoHyoji
     */
    public DiskFileItem getGazoHyoji() {
        return gazoHyoji;
    }

    /**
     * @param gazoHyoji the gazoHyoji to set
     */
    public void setGazoHyoji(DiskFileItem gazoHyoji) {
        this.gazoHyoji = gazoHyoji;
    }

    /**
     * @return the gazoPreview
     */
    public String getGazoPreview() {
        return gazoPreview;
    }

    /**
     * @param gazoPreview the gazoPreview to set
     */
    public void setGazoPreview(String gazoPreview) {
        this.gazoPreview = gazoPreview;
    }

    /**
     * @return the close
     */
    public String getClose() {
        return close;
    }

    /**
     * @param close the close to set
     */
    public void setClose(String close) {
        this.close = close;
    }

    /**
     * @return the gazoUpd
     */
    public String getGazoUpd() {
        return gazoUpd;
    }

    /**
     * @param gazoUpd the gazoUpd to set
     */
    public void setGazoUpd(String gazoUpd) {
        this.gazoUpd = gazoUpd;
    }

    public String getGazoIdx() {
        return gazoIdx;
    }

    public void setGazoIdx(String gazoIdx) {
        this.gazoIdx = gazoIdx;
    }

    public String getNendo() {
        return nendo;
    }

    public void setNendo(String nendo) {
        this.nendo = nendo;
    }

    public String getUketsukeNo() {
        return uketsukeNo;
    }

    public void setUketsukeNo(String uketsukeNo) {
        this.uketsukeNo = uketsukeNo;
    }

    public String getSeq() {
        return seq;
    }

    public void setSeq(String seq) {
        this.seq = seq;
    }

    /**
     * @return the errors
     */
    public Messages getErrors() {
        return errors;
    }

    /**
     * @param errors the errors to set
     */
    public void setErrors(Messages errors) {
        this.errors = errors;
    }

    /**
     * @return the scrollPlace
     */
    public String getScrollPlace() {
        return scrollPlace;
    }

    /**
     * @param scrollPlace the scrollPlace to set
     */
    public void setScrollPlace(String scrollPlace) {
        this.scrollPlace = scrollPlace;
    }

    /**
     * �t�@�C���A�C�e��
     *
     * @return the fileItem
     */
    public FileItem getFileItem() {
        return fileItem;
    }

    /**
     * �t�@�C���A�C�e��
     *
     * @param fileItem the fileItem to set
     */
    public void setFileItem(FileItem fileItem) {
        this.fileItem = fileItem;
    }

    /**
     * @return the gazoKbn
     */
    public String getGazoKbn() {
        return gazoKbn;
    }

    /**
     * @param gazoKbn the gazoKbn to set
     */
    public void setGazoKbn(String gazoKbn) {
        this.gazoKbn = gazoKbn;
    }

    /**
     * @return the gazoUploadList
     */
    public List<MskGazoJoho> getGazoUploadList() {
        return gazoUploadList;
    }

    /**
     * @param gazoUploadList the gazoUploadList to set
     */
    public void setGazoUploadList(List<MskGazoJoho> gazoUploadList) {
        this.gazoUploadList = gazoUploadList;
    }

    /**
     * @return the moshikomishaId
     */
    public String getMoshikomishaId() {
        return moshikomishaId;
    }

    /**
     * @param moshikomishaId the moshikomishaId to set
     */
    public void setMoshikomishaId(String moshikomishaId) {
        this.moshikomishaId = moshikomishaId;
    }

    /**
     * @return the kaoImg
     */
    public String getKaoImg() {
        return kaoImg;
    }

    /**
     * @param kaoImg the kaoImg to set
     */
    public void setKaoImg(String kaoImg) {
        this.kaoImg = kaoImg;
    }

    /**
     * @return the nenreiImg
     */
    public String getNenreiImg() {
        return nenreiImg;
    }

    /**
     * @param nenreiImg the nenreiImg to set
     */
    public void setNenreiImg(String nenreiImg) {
        this.nenreiImg = nenreiImg;
    }

    /**
     * @return the shikakuImg
     */
    public String getShikakuImg() {
        return shikakuImg;
    }

    /**
     * @param shikakuImg the shikakuImg to set
     */
    public void setShikakuImg(String shikakuImg) {
        this.shikakuImg = shikakuImg;
    }

    /**
     * @return the menjyoImg
     */
    public String getMenjyoImg() {
        return menjyoImg;
    }

    /**
     * @param menjyoImg the menjyoImg to set
     */
    public void setMenjyoImg(String menjyoImg) {
        this.menjyoImg = menjyoImg;
    }

    /**
     * @return the shomeishoList
     */
    public List<MskGazoJoho> getShomeishoList() {
        return shomeishoList;
    }

    /**
     * @param shomeishoList the shomeishoList to set
     */
    public void setShomeishoList(List<MskGazoJoho> shomeishoList) {
        this.shomeishoList = shomeishoList;
    }

    /**
     * @return the jknSikakuList
     */
    public List<MskGazoJoho> getJknSikakuList() {
        return jknSikakuList;
    }

    /**
     * @param jknSikakuList the jknSikakuList to set
     */
    public void setJknSikakuList(List<MskGazoJoho> jknSikakuList) {
        this.jknSikakuList = jknSikakuList;
    }

    /**
     * @return the menjoList
     */
    public List<MskGazoJoho> getMenjoList() {
        return menjoList;
    }

    /**
     * @param menjoList the menjoList to set
     */
    public void setMenjoList(List<MskGazoJoho> menjoList) {
        this.menjoList = menjoList;
    }

    /**
     * @return the upload
     */
    public String getUpload() {
        return upload;
    }

    /**
     * @param upload the upload to set
     */
    public void setUpload(String upload) {
        this.upload = upload;
    }

    /**
     * @return the fileName
     */
    public String getFileName() {
        return fileName;
    }

    /**
     * @param fileName the fileName to set
     */
    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    /**
     * @return the fileKbn
     */
    public String getFileKbn() {
        return fileKbn;
    }

    /**
     * @param fileKbn the fileKbn to set
     */
    public void setFileKbn(String fileKbn) {
        this.fileKbn = fileKbn;
    }

    /**
     * @return the gazoUpdFlg
     */
    public String getGazoUpdFlg() {
        return gazoUpdFlg;
    }

    /**
     * @param gazoUpdFlg the gazoUpdFlg to set
     */
    public void setGazoUpdFlg(String gazoUpdFlg) {
        this.gazoUpdFlg = gazoUpdFlg;
    }

    /**
     * @return the rrkShomeishoList
     */
    public List<RrkMskJoho> getRrkShomeishoList() {
        return rrkShomeishoList;
    }

    /**
     * @param rrkShomeishoList the rrkShomeishoList to set
     */
    public void setRrkShomeishoList(List<RrkMskJoho> rrkShomeishoList) {
        this.rrkShomeishoList = rrkShomeishoList;
    }

    /**
     * @return the rrkJknSikakuList
     */
    public List<RrkMskJoho> getRrkJknSikakuList() {
        return rrkJknSikakuList;
    }

    /**
     * @param rrkJknSikakuList the rrkJknSikakuList to set
     */
    public void setRrkJknSikakuList(List<RrkMskJoho> rrkJknSikakuList) {
        this.rrkJknSikakuList = rrkJknSikakuList;
    }

    /**
     * @return the rrkMenjoList
     */
    public List<RrkMskJoho> getRrkMenjoList() {
        return rrkMenjoList;
    }

    /**
     * @param rrkMenjoList the rrkMenjoList to set
     */
    public void setRrkMenjoList(List<RrkMskJoho> rrkMenjoList) {
        this.rrkMenjoList = rrkMenjoList;
    }
    
    
    /**
     * @return the uploadCheck
     */
    public String getUploadCheck() {
        return uploadCheck;
    }

    /**
     * @param uploadCheck the uploadCheck to set
     */
    public void setUploadCheck(String uploadCheck) {
        this.uploadCheck = uploadCheck;
    }
    
    
    /**
     * @return the gazoIdxs
     */
    public List<String> getGazoIdxs() {
        return gazoIdxs;
    }

    /**
     * @param gazoIdxs the gazoIdxs to set
     */
    public void setGazoIdxs(List<String> gazoIdxs) {
        this.gazoIdxs = gazoIdxs;
    }
    
    
    /**
     * @return the updCheck
     */
    public String getUpdCheck() {
        return updCheck;
    }

    /**
     * @param updCheck the updCheck to set
     */
    public void setUpdCheck(String updCheck) {
        this.updCheck = updCheck;
    }

    /**
     * @return the kaoShashin
     */
    public String getKaoShashin() {
        return kaoShashin;
    }

    /**
     * @param kaoShashin the kaoShashin to set
     */
    public void setKaoShashin(String kaoShashin) {
        this.kaoShashin = kaoShashin;
    }

    /**
     * @return the nenreiShomeiShrui
     */
    public String getNenreiShomeiShrui() {
        return nenreiShomeiShrui;
    }

    /**
     * @param nenreiShomeiShrui the nenreiShomeiShrui to set
     */
    public void setNenreiShomeiShrui(String nenreiShomeiShrui) {
        this.nenreiShomeiShrui = nenreiShomeiShrui;
    }

    /**
     * @return the shikakuShomeiShorui
     */
    public String getShikakuShomeiShorui() {
        return shikakuShomeiShorui;
    }

    /**
     * @param shikakuShomeiShorui the shikakuShomeiShorui to set
     */
    public void setShikakuShomeiShorui(String shikakuShomeiShorui) {
        this.shikakuShomeiShorui = shikakuShomeiShorui;
    }

    /**
     * @return the menjoShomeiShorui
     */
    public String getMenjoShomeiShorui() {
        return menjoShomeiShorui;
    }

    /**
     * @param menjoShomeiShorui the menjoShomeiShorui to set
     */
    public void setMenjoShomeiShorui(String menjoShomeiShorui) {
        this.menjoShomeiShorui = menjoShomeiShorui;
    }

    /**
     * @return the rrkFlg
     */
    public String getRrkFlg() {
        return rrkFlg;
    }

    /**
     * @param rrkFlg the rrkFlg to set
     */
    public void setRrkFlg(String rrkFlg) {
        this.rrkFlg = rrkFlg;
    }

    /**
     * @return the sknKsuKbn
     */
    public String getSknKsuKbn() {
        return sknKsuKbn;
    }

    /**
     * @param sknKsuKbn the sknKsuKbn to set
     */
    public void setSknKsuKbn(String sknKsuKbn) {
        this.sknKsuKbn = sknKsuKbn;
    }

    /**
     * @return the reload
     */
    public String getReload() {
        return reload;
    }

    /**
     * @param reload the reload to set
     */
    public void setReload(String reload) {
        this.reload = reload;
    }
}
