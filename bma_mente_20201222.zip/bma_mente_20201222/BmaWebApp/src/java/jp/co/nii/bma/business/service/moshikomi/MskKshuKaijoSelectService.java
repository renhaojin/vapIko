package jp.co.nii.bma.business.service.moshikomi;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import jp.co.nii.bma.business.domain.ShiyoKaijo;
import jp.co.nii.bma.business.rto.MskKsuJoho;
import jp.co.nii.bma.business.service.common.BmaConstants;
import jp.co.nii.bma.business.service.common.BmaLogger;
import jp.co.nii.bma.business.service.common.BmaValidator;
import jp.co.nii.bma.utility.BmaUtility;
import jp.co.nii.sew.business.Validator;
import jp.co.nii.sew.business.service.AbstractService;
import jp.co.nii.sew.presentation.Messages;
import jp.co.nii.sew.presentation.RequestTransferObject;
import jp.co.nii.sew.utility.PropertyUtility;

/**
 * <p>
 * �^�C�g��: �\�����ӎ�����ʃT�[�r�X</p>
 * <p>
 * ����: �\�����ӎ�����ʃT�[�r�X</p>
 * <p>
 * ���쌠: Copyright (c) 2020</p>
 * <p>
 * ��Ж�: ���{���Y�Ɗ������</p>
 */
public class MskKshuKaijoSelectService extends AbstractService {

    /**
     * DB�ڑ��̃f�[�^�\�[�X
     */
    private static String DATA_SOURCE_NAME;
    /**
     * ���O
     */
    BmaLogger log = (BmaLogger) BmaLogger.getLogger(this.getClass().getName());
    /**
     * �Ɩ��R�[�h
     */
    private static final String BUSINESS_CODE = PropertyUtility.getProperty("business_code");
    /**
     * ���׃e�X�g���[�h
     */
    private static final String STRESS_MODE = PropertyUtility.getProperty(BUSINESS_CODE + "stress_mode");
    /**
     * �N�x
     */
    private static final String NEN = PropertyUtility.getProperty(BUSINESS_CODE + "nen");

    /**
     * �R���X�g���N�^
     */
    public MskKshuKaijoSelectService() {
        super();
        /* DB�ڑ����̃��[�U�[������ */
        DATA_SOURCE_NAME = BmaConstants.DS_REGISTRANT;
    }

    /**
     * �T�[�r�X�N���X�̎��s���\�b�h
     *
     * @param rto ���N�G�X�g��񂩂�擾����rto
     * @param rtoInSession �Z�b�V�������rto
     * @return foward��
     * @throws Exception ��O
     */
    @Override
    public String doService(RequestTransferObject rto, RequestTransferObject rtoInSession)
            throws Exception {

        MskKsuJoho inRequest = (MskKsuJoho) rto;
        MskKsuJoho inSession = (MskKsuJoho) rtoInSession;
        inSession.setNendo(inRequest.getNendo());
        String processName = "";
        /*�G���[���b�Z�[�W������*/
        inSession.setErrors(new Messages());
        try {
            if (!BmaUtility.isNullOrEmpty(inRequest.getNextDoi())) {
                processName = "MskKshuKaijoSelect";
                log.Start(processName);
                inSession.setSknKsuCode(inRequest.getSknKsuCode());
                inSession.setShubetsuCode(inRequest.getShubetsuCode());
                inSession.setKaisuCode(inRequest.getKaisuCode());
                inSession.setKaijoshikenkbn("0");
                List<MskKsuJoho> kaijoListNew = new ArrayList<>();
                ShiyoKaijo shiyoKaijo = new ShiyoKaijo(BmaConstants.DS_REGISTRANT);
                /*��ꃊ�X�g�擾*/
                List<MskKsuJoho> kaijoList = shiyoKaijo.searchKaijoList(inSession.getNendo(), inSession.getSknKsuCode(),
                        inSession.getShubetsuCode(), inSession.getKaisuCode(), inSession.getKaijoshikenkbn());
                /*�J�Òn�擾*/
                Map<String, List<MskKsuJoho>> kaisaichi = kaijoList.stream().collect(
                        Collectors.groupingBy(MskKsuJoho::getKaisaichiCode));
                /*��ꃊ�X�g����J�Òn���Ɣz��*/
                for (Map.Entry<String, List<MskKsuJoho>> entry : kaisaichi.entrySet()) {
                    List<MskKsuJoho> listGroup = entry.getValue();
                    for (MskKsuJoho item : listGroup) {
                        item.setCount(listGroup.size() + "");
                        kaijoListNew.add(item);
                    }
                }
                inSession.setKaiMskJohoList(kaijoListNew);
                return FWD_NM_SUCCESS;
            } else if (!BmaUtility.isNullOrEmpty(inRequest.getKaijosentakuBack())) {
                processName = "MskKshuKaijoSelectBack";
                log.Start(processName);
                return FWD_NM_BACK;
            } else if (!BmaUtility.isNullOrEmpty(inRequest.getKaijoSentakuNext())) {
                processName = "MskKshuKaijoSelectNext";
                log.Start(processName);
                /**
                 * �u���ցv�{�^�������� *
                 */
                boolean retCheck = ValidatorCaller(inRequest, inSession);
                if (retCheck) {
                    /*�I����ꃊ�X�g�ێ�*/
                    String kaijoCodeId1st = inRequest.getKaijoId1st();
                    String kaijoCodeId2nd = inRequest.getKaijoId2nd();
                    /*��ꃊ�X�g����I�����擾*/
                    List<MskKsuJoho> kiboKaijoList1st = ListStreamFilter(kaijoCodeId1st, inSession);
                    List<MskKsuJoho> kiboKaijoList2nd = ListStreamFilter(kaijoCodeId2nd, inSession);
                    kiboKaijoList1st.addAll(kiboKaijoList2nd);
                    inSession.setKiboKaijoList(kiboKaijoList1st);
                    return FWD_NM_NEXT;
                } else {
                    return FWD_NM_ERROR;
                }
            } else {
                /*�ُ�J��*/
                log.IllegalFWD();
                return FWD_NM_SESSION;
            }
        } catch (Exception e) {
            throw e;
        } finally {
            log.End(processName);
        }
    }

    /**
     * �I�����X�g�擾
     *
     * @param kaisaichiCode
     * @param kaijoCode
     * @param inSession
     */
    private List<MskKsuJoho> ListStreamFilter(String kaijoId, MskKsuJoho inSession) throws Exception {
        List<MskKsuJoho> kiboKaijoList = new ArrayList<>();
        kiboKaijoList = inSession.getKaiMskJohoList();
        kiboKaijoList = kiboKaijoList.stream().filter(
                s -> s.getKaijoId().equals(kaijoId)).collect(Collectors.toList());
        return kiboKaijoList;
    }

    /**
     * �I���`�F�b�N
     *
     * @param inRequest
     * @param inSession
     * @return ��肪�Ȃ���� true�A����� false
     */
    private boolean ValidatorCaller(MskKsuJoho inRequest, MskKsuJoho inSession) throws Exception {
        Messages errors = new Messages();	//���b�Z�[�W�i�[�p
        String daiichiKibo = inRequest.getDaiichiKibo();
        String dainiKibo = inRequest.getDainiKibo();
        String[] arinashi = {"0", "1"};
        // ����]�F�K�{�`�F�b�N
        BmaValidator.validateSelect(daiichiKibo, errors, BmaConstants.ERR_GROUP_DAIICHI_KIBO, BmaConstants.ARG_DAIICHI_KIBO);
        if (BmaValidator.validateMessageCheck(errors, BmaConstants.ERR_GROUP_DAIICHI_KIBO)) {
            // ����]�F�Ó����`�F�b�N
            Validator.validatePermissionSelect(daiichiKibo, arinashi, errors, BmaConstants.ERR_GROUP_DAIICHI_KIBO, BmaConstants.ARG_DAIICHI_KIBO);
        }
        // ����]�F�Ó����`�F�b�N
        BmaValidator.validateSelect(dainiKibo, errors, BmaConstants.ERR_GROUP_DAIINI_KIBO, BmaConstants.ARG_DAIINI_KIBO);
        if (BmaValidator.validateMessageCheck(errors, BmaConstants.ERR_GROUP_DAIINI_KIBO)) {
            // ����]�F�Ó����`�F�b�N
            Validator.validatePermissionSelect(dainiKibo, arinashi, errors, BmaConstants.ERR_GROUP_DAIINI_KIBO, BmaConstants.ARG_DAIINI_KIBO);
        }
        if (!errors.isEmpty()) {
            inSession.setErrors(errors);
            return false;
        } else {
            return true;
        }
    }
}
