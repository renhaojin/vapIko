/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.nii.bma.business.rto;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import jp.co.nii.bma.business.domain.HoyuShikakuMst;
import jp.co.nii.bma.business.service.common.BmaConstants;
import jp.co.nii.bma.utility.BmaUtility;
import jp.co.nii.sew.presentation.AbstractRequestTransferObject;
import jp.co.nii.sew.presentation.Messages;
import jp.co.nii.sew.presentation.Option;

/**
 *
 * @author BP80139
 */
public class MskSikakuJoho extends AbstractRequestTransferObject{

        private Messages errors;
        /** �\���҂h�c */
        private String moshikomishaId;
        /** ����敪 */
        private String kaiinKbn;
        /** �����u�K��R�[�h */
        private String sknKsuCode;
        /** ��ʃR�[�h */
        private String shubetsuCode;
        /** �񐔃R�[�h */
        private String kaisuCode;
        /** �������e�敪 */
        private String sknNaiyoKbn;
        /** �����u�K��敪 */
        private String sknKsuKbn;
        /** �����u�K� */
        private String sknKsuName;
        /** �����u�K��Q��ʂȂ� */
        private String sknKsuNameNosbt;
        /** ��ʖ� */
        private String shubetsuName;
        /** �񐔖� */
        private String kaisuName;
        /** �t���K�i */
        private String furigana;
        /** ���N���� */
        private String birthday;
        
        //�Ə����
        /** �Ə�chekbox */
        private String menjoCheckbox;
        /** �Ə��R�[�h*/
        private String menjoCode;
        /** �\���Ə��ԍ� */
        private String shinseiMenjoNo;
        /** �w�ȍ��i�ԍ� */
        private String menjoGakaGokakuNo1;
        private String menjoGakaGokakuNo2;
        private String menjoGakaGokakuNo3;
        private String menjoGakaGokakuNo4;
        private String menjoGakaGokakuNo5;
        private String menjoGakaGokakuNo6;
        private String menjoGakaGokakuNo7;
        private String menjoGakaGokakuNo8;
        /** �Ə�-��*/
        private String menjoKyu;
        /** �Ə���ʃR�[�h */
        private String mnjShubetsuCode;
        //�\���m�F��ʂ̕\���p
        private String jukenMenjo;
        private String shinseiMenjoTitle;
        private String shinseiMenjoNaiyo;
        
        //���i���
        /** ���ichekbox */
        private String shikakuCheckbox;
        /** ���i�R�[�h */
        private String shikakuCode;
        /** �\�����i�ԍ� */
        private String shinseiShikakuNo;
        /** ���i�ԍ� */
        private String sskGokakuNo1;
        private String sskGokakuNo2;
        private String sskGokakuNo3;
        private String sskGokakuNo4;
        private String sskGokakuNo5;
        private String sskGokakuNo6;
        private String sskGokakuNo7;
        private String sskGokakuNo8;
        //�\���m�F��ʂ̕\���p
        private String jukenSikaku;
        private String shinseiShikakuTitle;
        private String shinseiShikakuNaiyo;
        //�r����1��ʁA�Q�����i�҂̃`�F�b�N�{�b�N�X
        private String shikakuCheckbox2;
        /** �ۗL���i�}�X�^�o�^�̃t���K�i */
        private String hoyuShikakuFurigana;
        
        //�w�����
        private String gakkouName;
        private String gakkouGakka;
        private String gakkouShozaichi;
        private String gakkouSotsugyoYear;
        private String gakkouSotsugyoMonth;
        
        //�P�������
        private String kunrenShisetsuName;
        private String kunrenka;
        private String kunrenShozaichi;
        private String kunrenKikanYearFrom;
        private String kunrenKikanMonthFrom;
        private String kunrenKikanYearTo;
        private String kunrenKikanMonthTo;
        
        //�E�����
        /** �E���敪 */
        private String shokurekiKbn;
        /** �E���r�d�p */
        private String shokurekiSeq;
        /** �Ζ����Ж� */
        private String kinmusakiKaishaName;
        /** ������E�� */
        private String bushoYakushokuName;
        /** �E�����e */
        private String shokumuNaiyo;
        /** ���ݒn */
        private String shokurekiShozaichi;
        /** �ݐЊ��ԁi�N�j�e�q�n�l */
        private String zaisekikikanYearFrom;
        /** �ݐЊ��ԁi���j�e�q�n�l */
        private String zaisekikikanMonthFrom;
        /** �ݐЊ��ԁi�N�j�s�n */
        private String zaisekikikanYearTo;
        /** �ݐЊ��ԁi���j�s�n */
        private String zaisekikikanMonthTo;
        /** �ݐЊ��Ԃe�q�n�l */
        private String zaisekikikanFrom;
        /** �ݐЊ��Ԃs�n */
        private String zaisekikikanTo;
        /** �����o���N���i�N�j */
        private String jitsumuKeikenY;
        /** �����o���N���i���j */
        private String jitsumuKeikenM;
        /** �����o���N�� (DB����,=���i�N����- ���)*/
        private String jitsumuKeikenDB;
        /** �Ζ����e */
        private String kinmuNaiyo;
        private String zaishokuKikanGokei;
        
        /**���i���_�C���y�N�y�V�z**/
        private String nendo;
        //��u���i
        private String sagyoKantokuSikakuNo;
        private String eiseikanrigijutsushaSikakuNo;
        private String tokatsukanrishaSikakuNo;
        
        //���z�����|�Ǘ��]�����i�ҍu�K  �t�H���[�A�b�v
        //���i�ԍ��i�C���ԍ��j
        private String sskShuryoNo1;
        private String sskShuryoNo2;
        private String sskShuryoNo3;
        private String sskShuryoNo4;
        private String sskShuryoNo5;
        /** �����񐔎c */
        private String muryoZanCount;
        private HoyuShikakuMst hoyuShikakuMstForUpdate;
         /** ���ϕ��@�敪 */
        private String kessaiHohoKbn;
        
        //�G���[(�u�K��̂݁A�m�F�{�^��������)
        /** �ԍ��G���[ */
        private String sskNumberError;
        /** ���N�����G���[ */
        private String sskBirthdayError;
        /** �t���K�i�G���[ */
        private String sskFuriganaError;
        
        //�������e�敪�@���X�g
        private List<Option> sknNaiyoList;
        /**
        * �E�����@���X�g
        */
       private List<MskSikakuJoho> shokurekiList;
        /**
        * �E�����e�@���X�g
        */
       private List<Option> shokumuNaiyoList;
        /**
        * �������e�敪���W�I�{�^������p
        */
       private List<String> disabledSknNaiyoKbnList;
        
       
       //�{�^��
       private String nextDoi;
        private String skkJohoBack;
        private String skkJohoNext;
       /** �u�E����ǉ��v�{�^�� */
        private String shokurekiTsuika;
        /** �u���I����́v��ʂ̃{�^�� */
        private String kaijoSentakuNext;
        /** �uIP FollowUp�v��ʂ̊m�F�{�^�� */
        private String skkConfirmBtn;
        
        //�ێ����iflag
        private String hoyuShikakuAriFlg;
        private String hoyuMenjoAriFlg;
        private String hoyuMenjoTannitsuFlg;
        private String shikakuCodeCheck;
        private String shinseiShikakuNoCheck;
        private String menjoCodeCheck;
        private String shinseiMenjoNoCheck;
        
        //�摜�A�b�v���[�hflag
        private String kaoImg;
        private String nenreiImg;
        private String shikakuImg;
        private String menjyoImg;
        
        //�����I��bean
        private MskSknJoho mskSknJoho;
        //�u�K��I���A���I���@bean
        private MskKsuJoho mskKsuJoho;
        //�\�����bean
        private MskJoho mskJoho;
        
        public MskSikakuJoho() {
            clearInfo();
        }

    private void clearInfo() {
        setErrors(new Messages());
        setMoshikomishaId("");
        setKaiinKbn("");
        setSknKsuCode("");
        setShubetsuCode("");
        setKaisuCode("");
        setSknNaiyoKbn("");
        setSknKsuKbn("");
        setSknKsuName("");
        setSknKsuNameNosbt("");
        setShubetsuName("");
        setKaisuName("");
        setFurigana("");
        setBirthday("");
        
        //�m�F�{�^��
        setSkkConfirmBtn("");
        
        //�G���[
        setSskNumberError("");
        setSskBirthdayError("");
        setSskFuriganaError("");
        
        //�Ə����
        setMenjoCheckbox("");
        setMenjoCode("");
        setMenjoGakaGokakuNo1("");
        setMenjoGakaGokakuNo2("");
        setMenjoGakaGokakuNo3("");
        setMenjoGakaGokakuNo4("");
        setMenjoGakaGokakuNo5("");
        setMenjoGakaGokakuNo6("");
        setMenjoGakaGokakuNo7("");
        setMenjoGakaGokakuNo8("");
        setMenjoKyu("");
        setShinseiMenjoNo("");
        setJukenMenjo("");
        setShinseiMenjoTitle("");
        
        //���i���
        setShikakuCheckbox("");
        setShikakuCode("");
        setSskGokakuNo1("");
        setSskGokakuNo2("");
        setSskGokakuNo3("");
        setSskGokakuNo4("");
        setSskGokakuNo5("");
        setSskGokakuNo6("");
        setSskGokakuNo7("");
        setSskGokakuNo8("");
        setShinseiShikakuNo("");
        setJukenSikaku("");
        setShinseiShikakuTitle("");
        setShikakuCheckbox2("");
        setHoyuShikakuFurigana("");
        
        //�w�����
        setGakkouName("");
        setGakkouGakka("");
        setGakkouShozaichi("");
        setGakkouSotsugyoYear("");
        setGakkouSotsugyoMonth("");
        
        //�P�������
        setKunrenShisetsuName("");
        setKunrenka("");
        setKunrenShozaichi("");
        setKunrenKikanYearFrom("");
        setKunrenKikanMonthFrom("");
        setKunrenKikanYearTo("");
        setKunrenKikanMonthTo("");
        
        //�E�����F�����o���N��
        setJitsumuKeikenDB("");
        
        //��u���i
        setNendo("");
        setSagyoKantokuSikakuNo("");
        setEiseikanrigijutsushaSikakuNo("");
        setTokatsukanrishaSikakuNo("");
        
        //���i�ԍ��i�C���ԍ��j
        setSskShuryoNo1("");
        setSskShuryoNo2("");
        setSskShuryoNo3("");
        setSskShuryoNo4("");
        setSskShuryoNo5("");
        setHoyuShikakuMstForUpdate(new HoyuShikakuMst());
        setMuryoZanCount("");
        setKessaiHohoKbn("");
        
        //�{�^��
        setNextDoi("");
        setSkkJohoBack("");
        setSkkJohoNext("");
        setShokurekiTsuika("");
        setKaijoSentakuNext("");
        
        //�ێ����iflag
        setHoyuShikakuAriFlg("");
        setHoyuMenjoAriFlg("");
        setHoyuMenjoTannitsuFlg("");
        setShikakuCodeCheck("");
        setShinseiShikakuNoCheck("");
        setMenjoCodeCheck("");
        setShinseiMenjoNoCheck("");
        
        //�摜�A�b�v���[�hflag
        setKaoImg("");
        setNenreiImg("");
        setShikakuImg("");
        setMenjyoImg("");
        
        //���X�g
        setSknNaiyoList(new ArrayList<>());
        setShokurekiList(new ArrayList<>());
        setShokumuNaiyoList(new ArrayList<>());
    }
    
    
    @Override
    public void copyFromRequest(HttpServletRequest request) {
        setMoshikomishaId((String) request.getAttribute("moshikomishaId"));
        setKaiinKbn((String) request.getAttribute("kaiinKbn"));
        setSknKsuCode((String) request.getAttribute("sknKsuCode"));
        setShubetsuCode((String) request.getAttribute("shubetsuCode"));
        setKaisuCode((String) request.getAttribute("kaisuCode"));
        setSknNaiyoKbn((String) request.getAttribute("sknNaiyoKbn"));
        setSknKsuKbn((String) request.getAttribute("sknKsuKbn"));
        setSknKsuName((String) request.getAttribute("sknKsuName"));
        setSknKsuNameNosbt((String) request.getAttribute("sknKsuNameNosbt"));
        setShubetsuName((String) request.getAttribute("shubetsuName"));
        setKaisuName((String) request.getAttribute("kaisuName"));
        setFurigana((String) request.getAttribute("furigana"));
        setBirthday((String) request.getAttribute("birthday"));
        
        //�m�F�{�^��
        setSkkConfirmBtn((String) request.getAttribute("skkConfirmBtn"));
        
        //�G���[
        setSskNumberError((String) request.getAttribute("sskNumberError"));
        setSskBirthdayError((String) request.getAttribute("sskBirthdayError"));
        setSskFuriganaError((String) request.getAttribute("sskFuriganaError"));
        
        //�Ə����
        setMenjoCheckbox((String) request.getAttribute("menjoCheckbox"));
        setMenjoCode((String) request.getAttribute("menjoCode"));
        setMenjoGakaGokakuNo1((String) request.getAttribute("menjoGakaGokakuNo1"));
        setMenjoGakaGokakuNo2((String) request.getAttribute("menjoGakaGokakuNo2"));
        setMenjoGakaGokakuNo3((String) request.getAttribute("menjoGakaGokakuNo3"));
        setMenjoGakaGokakuNo4((String) request.getAttribute("menjoGakaGokakuNo4"));
        setMenjoGakaGokakuNo5((String) request.getAttribute("menjoGakaGokakuNo5"));
        setMenjoGakaGokakuNo6((String) request.getAttribute("menjoGakaGokakuNo6"));
        setMenjoGakaGokakuNo7((String) request.getAttribute("menjoGakaGokakuNo7"));
        setMenjoGakaGokakuNo8((String) request.getAttribute("menjoGakaGokakuNo8"));
        setMenjoKyu((String) request.getAttribute("menjoKyu"));
        setShinseiMenjoNo((String) request.getAttribute("shinseiMenjoNo"));
//        setJukenMenjo((String) request.getAttribute("jukenMenjo"));
//        setShinseiMenjoTitle((String) request.getAttribute("shinseiMenjoTitle"));
        
        //���i���
        setShikakuCheckbox((String) request.getAttribute("shikakuCheckbox"));
        setShikakuCode((String) request.getAttribute("shikakuCode"));
        setSskGokakuNo1((String) request.getAttribute("sskGokakuNo1"));
        setSskGokakuNo2((String) request.getAttribute("sskGokakuNo2"));
        setSskGokakuNo3((String) request.getAttribute("sskGokakuNo3"));
        setSskGokakuNo4((String) request.getAttribute("sskGokakuNo4"));
        setSskGokakuNo5((String) request.getAttribute("sskGokakuNo5"));
        setSskGokakuNo6((String) request.getAttribute("sskGokakuNo6"));
        setSskGokakuNo7((String) request.getAttribute("sskGokakuNo7"));
        setSskGokakuNo8((String) request.getAttribute("sskGokakuNo8"));
        setShinseiShikakuNo((String) request.getAttribute("shinseiShikakuNo"));
//        setJukenSikaku((String) request.getAttribute("jukenSikaku"));
//        setShinseiShikakuTitle((String) request.getAttribute("shinseiShikakuTitle"));
        setShikakuCheckbox2((String) request.getAttribute("shikakuCheckbox2"));
        
        //�w�����
        setGakkouName((String) request.getAttribute("gakkouName"));
        setGakkouGakka((String) request.getAttribute("gakkouGakka"));
        setGakkouShozaichi((String) request.getAttribute("gakkouShozaichi"));
        setGakkouSotsugyoYear((String) request.getAttribute("gakkouSotsugyoYear"));
        setGakkouSotsugyoMonth((String) request.getAttribute("gakkouSotsugyoMonth"));
        
        //�P�������
        setKunrenShisetsuName((String) request.getAttribute("kunrenShisetsuName"));
        setKunrenka((String) request.getAttribute("kunrenka"));
        setKunrenShozaichi((String) request.getAttribute("kunrenShozaichi"));
        setKunrenKikanYearFrom((String) request.getAttribute("kunrenKikanYearFrom"));
        setKunrenKikanMonthFrom((String) request.getAttribute("kunrenKikanMonthFrom"));
        setKunrenKikanYearTo((String) request.getAttribute("kunrenKikanYearTo"));
        setKunrenKikanMonthTo((String) request.getAttribute("kunrenKikanMonthTo"));
        
        //�E�����
        MskSikakuJoho shokurekiJoho;
        int shokurekiCnt = 0;
        if(request.getAttribute("shokurekiCount") != null){
            shokurekiCnt = Integer.parseInt((String) request.getAttribute("shokurekiCount"));
        }
        for (int i = 1; i <= shokurekiCnt; i++) {
           shokurekiJoho = new MskSikakuJoho();
           shokurekiJoho.copyFromRequest_Shokureki(request, i);
           shokurekiList.add(shokurekiJoho);
        }
        
        //�E�����F�����o���N��
        setJitsumuKeikenDB((String) request.getAttribute("jitsumuKeikenDB"));
        
        //��u���i
        setNendo((String) request.getAttribute("nendo"));
        setSagyoKantokuSikakuNo((String) request.getAttribute("sagyoKantokuSikakuNo"));
        setEiseikanrigijutsushaSikakuNo((String) request.getAttribute("eiseikanrigijutsushaSikakuNo"));
        setTokatsukanrishaSikakuNo((String) request.getAttribute("tokatsukanrishaSikakuNo"));
        
        //���i�ԍ��i�C���ԍ��j
        setSskShuryoNo1((String) request.getAttribute("sskShuryoNo1"));
        setSskShuryoNo2((String) request.getAttribute("sskShuryoNo2"));
        setSskShuryoNo3((String) request.getAttribute("sskShuryoNo3"));
        setSskShuryoNo4((String) request.getAttribute("sskShuryoNo4"));
        setSskShuryoNo5((String) request.getAttribute("sskShuryoNo5"));
        setMuryoZanCount((String) request.getAttribute("muryoZanCount"));
        setKessaiHohoKbn((String) request.getAttribute("kessaiHohoKbn"));
        
        //�{�^��
        setNextDoi((String) request.getAttribute("nextDoi"));
        setSkkJohoBack((String) request.getAttribute("skkJohoBack"));
        setSkkJohoNext((String) request.getAttribute("skkJohoNext"));
        setShokurekiTsuika((String) request.getAttribute("shokurekiTsuika"));
        setKaijoSentakuNext((String) request.getAttribute("kaijoSentakuNext"));
        
        //�摜�A�b�v���[�hflag
        setKaoImg((String) request.getAttribute("kaoImg"));
        setNenreiImg((String) request.getAttribute("nenreiImg"));
        setShikakuImg((String) request.getAttribute("shikakuImg"));
        setMenjyoImg((String) request.getAttribute("menjyoImg"));
        
        HttpSession session = request.getSession(false);
        if (session.getAttribute("MskSknJoho") != null) {
            MskSknJoho tmp = (MskSknJoho) session.getAttribute("MskSknJoho");
            setMoshikomishaId(tmp.getMoshikomishaId());
            setSknKsuCode(tmp.getSknKsuCode());
            setShubetsuCode(tmp.getShubetsuCode());
            setKaisuCode(tmp.getKaisuCode());
            setSknKsuKbn(tmp.getSknKsuKbn());
            setSknKsuNameNosbt(tmp.getSknKsuNameNosbt());
            setShubetsuName(tmp.getShubetsuName());
            setKaiinKbn(tmp.getKaiinKbn());
            setNendo(tmp.getNendo());
            
            setMskSknJoho(tmp);
        }
        
        if (session.getAttribute("MskKsuJoho") != null) {
            MskKsuJoho tmp = (MskKsuJoho) session.getAttribute("MskKsuJoho");
            setMskKsuJoho(tmp);
        }
        
        if (session.getAttribute("MskJoho") != null) {
            MskJoho tmp = (MskJoho) session.getAttribute("MskJoho");
            setMskJoho(tmp);
        }
        
        if(session.getAttribute("TopJoho") != null){
            TopJoho temp = (TopJoho) session.getAttribute("TopJoho");
            setMoshikomishaId(temp.getMoshikomishaId());
            setFurigana(temp.getFurigana());
            setBirthday(temp.getBirthday());
        }

        if (request.getRequestURI().contains(BmaConstants.TRANSITION_SOURCE_FOR_RTO_CLEAR_URI)) {
                // �摜�A�b�v���[�hRTO�N���A
                if (session.getAttribute("MskGazoJoho") != null) {
                    MskGazoJoho mskGazoJoho = (MskGazoJoho) session.getAttribute("MskGazoJoho");
                    mskGazoJoho.clearInfo();
                    session.setAttribute("MskGazoJoho", mskGazoJoho);
                }
        }
    }
    
    /**
     * ���N�G�X�g��������擾����
     * �E���̂�
     *
     * @param request ���N�G�X�g
     * @param idx �E��index
     */
    public void copyFromRequest_Shokureki(HttpServletRequest request, int idx) {
        setShokurekiKbn((String) request.getAttribute("shokurekiKbn"+idx));
        setShokurekiSeq((String) request.getAttribute("shokurekiSeq"+idx));
        setKinmusakiKaishaName((String) request.getAttribute("kinmusakiKaishaName"+idx));
        setBushoYakushokuName((String) request.getAttribute("bushoYakushokuName"+idx));
        setShokumuNaiyo((String) request.getAttribute("shokumuNaiyo"+idx));
        setShokurekiShozaichi((String) request.getAttribute("shokurekiShozaichi"+idx));
        setZaisekikikanYearFrom((String) request.getAttribute("zaisekikikanYearFrom"+idx));
        String monthFrom = (String) request.getAttribute("zaisekikikanMonthFrom"+idx);
        if(!BmaUtility.isNullOrEmpty(monthFrom)){
            setZaisekikikanMonthFrom(String.format("%02d", Integer.valueOf(monthFrom)));
        }
        setZaisekikikanYearTo((String) request.getAttribute("zaisekikikanYearTo"+idx));
        String monthTo = (String) request.getAttribute("zaisekikikanMonthTo"+idx);
        if(!BmaUtility.isNullOrEmpty(monthTo)){
            setZaisekikikanMonthTo(String.format("%02d", Integer.valueOf(monthTo)));
        }
        setZaisekikikanFrom((String) request.getAttribute("zaisekikikanFrom"+idx));
        setZaisekikikanTo((String) request.getAttribute("zaisekikikanTo"+idx));
        setJitsumuKeikenY((String) request.getAttribute("jitsumuKeikenY"+idx));
        setJitsumuKeikenM((String) request.getAttribute("jitsumuKeikenM"+idx));
        setKinmuNaiyo((String) request.getAttribute("kinmuNaiyo"+idx));
    }
    
    
    
    /**
     * @return the nextDoi
     */
    public String getNextDoi() {
        return nextDoi;
    }

    /**
     * @param nextDoi the nextDoi to set
     */
    public void setNextDoi(String nextDoi) {
        this.nextDoi = nextDoi;
    }
    
    /**
     * @return the errors
     */
    public Messages getErrors() {
        return errors;
    }
    
     /**
     * @return the skkJohoBack
     */
    public String getSkkJohoBack() {
        return skkJohoBack;
    }

    /**
     * @param skkJohoBack the skkJohoBack to set
     */
    public void setSkkJohoBack(String skkJohoBack) {
        this.skkJohoBack = skkJohoBack;
    }

    /**
     * @return the skkJohoNext
     */
    public String getSkkJohoNext() {
        return skkJohoNext;
    }

    /**
     * @param skkJohoNext the skkJohoNext to set
     */
    public void setSkkJohoNext(String skkJohoNext) {
        this.skkJohoNext = skkJohoNext;
    }
    
    /**
     * @return the shokurekiTsuika
     */
    public String getShokurekiTsuika() {
        return shokurekiTsuika;
    }

    /**
     * @param shokurekiTsuika the shokurekiTsuika to set
     */
    public void setShokurekiTsuika(String shokurekiTsuika) {
        this.shokurekiTsuika = shokurekiTsuika;
    }

    public String getKaijoSentakuNext() {
        return kaijoSentakuNext;
    }

    public void setKaijoSentakuNext(String kaijoSentakuNext) {
        this.kaijoSentakuNext = kaijoSentakuNext;
    }

    public String getKaoImg() {
        return kaoImg;
    }

    public void setKaoImg(String kaoImg) {
        this.kaoImg = kaoImg;
    }

    public String getNenreiImg() {
        return nenreiImg;
    }

    public void setNenreiImg(String nenreiImg) {
        this.nenreiImg = nenreiImg;
    }

    public String getShikakuImg() {
        return shikakuImg;
    }

    public void setShikakuImg(String shikakuImg) {
        this.shikakuImg = shikakuImg;
    }

    public String getMenjyoImg() {
        return menjyoImg;
    }

    public void setMenjyoImg(String menjyoImg) {
        this.menjyoImg = menjyoImg;
    }

    public String getHoyuShikakuAriFlg() {
        return hoyuShikakuAriFlg;
    }

    public void setHoyuShikakuAriFlg(String hoyuShikakuAriFlg) {
        this.hoyuShikakuAriFlg = hoyuShikakuAriFlg;
    }

    public String getHoyuMenjoAriFlg() {
        return hoyuMenjoAriFlg;
    }

    public void setHoyuMenjoAriFlg(String hoyuMenjoAriFlg) {
        this.hoyuMenjoAriFlg = hoyuMenjoAriFlg;
    }

    public String getHoyuMenjoTannitsuFlg() {
        return hoyuMenjoTannitsuFlg;
    }

    public void setHoyuMenjoTannitsuFlg(String hoyuMenjoTannitsuFlg) {
        this.hoyuMenjoTannitsuFlg = hoyuMenjoTannitsuFlg;
    }

    public String getShikakuCodeCheck() {
        return shikakuCodeCheck;
    }

    public void setShikakuCodeCheck(String shikakuCodeCheck) {
        this.shikakuCodeCheck = shikakuCodeCheck;
    }

    public String getShinseiShikakuNoCheck() {
        return shinseiShikakuNoCheck;
    }

    public void setShinseiShikakuNoCheck(String shinseiShikakuNoCheck) {
        this.shinseiShikakuNoCheck = shinseiShikakuNoCheck;
    }

    public String getMenjoCodeCheck() {
        return menjoCodeCheck;
    }

    public void setMenjoCodeCheck(String menjoCodeCheck) {
        this.menjoCodeCheck = menjoCodeCheck;
    }

    public String getShinseiMenjoNoCheck() {
        return shinseiMenjoNoCheck;
    }

    public void setShinseiMenjoNoCheck(String shinseiMenjoNoCheck) {
        this.shinseiMenjoNoCheck = shinseiMenjoNoCheck;
    }
    
    /**
     * @param errors the errors to set
     */
    public void setErrors(Messages errors) {
        this.errors = errors;
    }

    public String getMoshikomishaId() {
        return moshikomishaId;
    }

    public void setMoshikomishaId(String moshikomishaId) {
        this.moshikomishaId = moshikomishaId;
    }

    public String getKaiinKbn() {
        return kaiinKbn;
    }

    public void setKaiinKbn(String kaiinKbn) {
        this.kaiinKbn = kaiinKbn;
    }

    public String getSknKsuCode() {
        return sknKsuCode;
    }

    public void setSknKsuCode(String sknKsuCode) {
        this.sknKsuCode = sknKsuCode;
    }

    public String getShubetsuCode() {
        return shubetsuCode;
    }

    public void setShubetsuCode(String shubetsuCode) {
        this.shubetsuCode = shubetsuCode;
    }

    public String getKaisuCode() {
        return kaisuCode;
    }

    public void setKaisuCode(String kaisuCode) {
        this.kaisuCode = kaisuCode;
    }

    public String getSknNaiyoKbn() {
        return sknNaiyoKbn;
    }

    public void setSknNaiyoKbn(String sknNaiyoKbn) {
        this.sknNaiyoKbn = sknNaiyoKbn;
    }

    public String getSknKsuKbn() {
        return sknKsuKbn;
    }

    public void setSknKsuKbn(String sknKsuKbn) {
        this.sknKsuKbn = sknKsuKbn;
    }

    public String getSknKsuName() {
        return sknKsuName;
    }

    public void setSknKsuName(String sknKsuName) {
        this.sknKsuName = sknKsuName;
    }

    public String getSknKsuNameNosbt() {
        return sknKsuNameNosbt;
    }

    public void setSknKsuNameNosbt(String sknKsuNameNosbt) {
        this.sknKsuNameNosbt = sknKsuNameNosbt;
    }

    public String getShubetsuName() {
        return shubetsuName;
    }

    public void setShubetsuName(String shubetsuName) {
        this.shubetsuName = shubetsuName;
    }

    public String getKaisuName() {
        return kaisuName;
    }

    public void setKaisuName(String kaisuName) {
        this.kaisuName = kaisuName;
    }

    public String getFurigana() {
        return furigana;
    }

    public void setFurigana(String furigana) {
        this.furigana = furigana;
    }

    public String getBirthday() {
        return birthday;
    }

    public void setBirthday(String birthday) {
        this.birthday = birthday;
    }
    
    public String getSskGokakuNo1() {
        return sskGokakuNo1;
    }

    public void setSskGokakuNo1(String sskGokakuNo1) {
        this.sskGokakuNo1 = sskGokakuNo1;
    }

    public String getSskGokakuNo2() {
        return sskGokakuNo2;
    }

    public void setSskGokakuNo2(String sskGokakuNo2) {
        this.sskGokakuNo2 = sskGokakuNo2;
    }

    public String getSskGokakuNo3() {
        return sskGokakuNo3;
    }

    public void setSskGokakuNo3(String sskGokakuNo3) {
        this.sskGokakuNo3 = sskGokakuNo3;
    }

    public String getSskGokakuNo4() {
        return sskGokakuNo4;
    }

    public void setSskGokakuNo4(String sskGokakuNo4) {
        this.sskGokakuNo4 = sskGokakuNo4;
    }

    public String getSskGokakuNo5() {
        return sskGokakuNo5;
    }

    public void setSskGokakuNo5(String sskGokakuNo5) {
        this.sskGokakuNo5 = sskGokakuNo5;
    }

    public String getSskGokakuNo6() {
        return sskGokakuNo6;
    }

    public void setSskGokakuNo6(String sskGokakuNo6) {
        this.sskGokakuNo6 = sskGokakuNo6;
    }

    public String getSskGokakuNo7() {
        return sskGokakuNo7;
    }

    public void setSskGokakuNo7(String sskGokakuNo7) {
        this.sskGokakuNo7 = sskGokakuNo7;
    }

    public String getSskGokakuNo8() {
        return sskGokakuNo8;
    }

    public void setSskGokakuNo8(String sskGokakuNo8) {
        this.sskGokakuNo8 = sskGokakuNo8;
    }

    public String getJukenSikaku() {
        return jukenSikaku;
    }

    public void setJukenSikaku(String jukenSikaku) {
        this.jukenSikaku = jukenSikaku;
    }

    public String getShinseiShikakuTitle() {
        return shinseiShikakuTitle;
    }

    public void setShinseiShikakuTitle(String shinseiShikakuTitle) {
        this.shinseiShikakuTitle = shinseiShikakuTitle;
    }
    
    
    public String getSkkConfirmBtn() {
        return skkConfirmBtn;
    }

    public void setSkkConfirmBtn(String skkConfirmBtn) {
        this.skkConfirmBtn = skkConfirmBtn;
    }

    public String getSskNumberError() {
        return sskNumberError;
    }

    public void setSskNumberError(String sskNumberError) {
        this.sskNumberError = sskNumberError;
    }

    public String getSskBirthdayError() {
        return sskBirthdayError;
    }

    public void setSskBirthdayError(String sskBirthdayError) {
        this.sskBirthdayError = sskBirthdayError;
    }

    public String getSskFuriganaError() {
        return sskFuriganaError;
    }

    public void setSskFuriganaError(String sskFuriganaError) {
        this.sskFuriganaError = sskFuriganaError;
    }
    
    
    public String getShikakuCode() {
        return shikakuCode;
    }

    public void setShikakuCode(String shikakuCode) {
        this.shikakuCode = shikakuCode;
    }

    public String getShinseiShikakuNo() {
        return shinseiShikakuNo;
    }

    public void setShinseiShikakuNo(String shinseiShikakuNo) {
        this.shinseiShikakuNo = shinseiShikakuNo;
    }

    public String getGakkouName() {
        return gakkouName;
    }

    public void setGakkouName(String gakkouName) {
        this.gakkouName = gakkouName;
    }

    public String getGakkouGakka() {
        return gakkouGakka;
    }

    public void setGakkouGakka(String gakkouGakka) {
        this.gakkouGakka = gakkouGakka;
    }

    public String getGakkouShozaichi() {
        return gakkouShozaichi;
    }

    public void setGakkouShozaichi(String gakkouShozaichi) {
        this.gakkouShozaichi = gakkouShozaichi;
    }

    public String getGakkouSotsugyoYear() {
        return gakkouSotsugyoYear;
    }

    public void setGakkouSotsugyoYear(String gakkouSotsugyoYear) {
        this.gakkouSotsugyoYear = gakkouSotsugyoYear;
    }

    public String getGakkouSotsugyoMonth() {
        return gakkouSotsugyoMonth;
    }

    public void setGakkouSotsugyoMonth(String gakkouSotsugyoMonth) {
        this.gakkouSotsugyoMonth = gakkouSotsugyoMonth;
    }

    public String getMenjoCheckbox() {
        return menjoCheckbox;
    }

    public void setMenjoCheckbox(String menjoCheckbox) {
        this.menjoCheckbox = menjoCheckbox;
    }

    public String getShikakuCheckbox() {
        return shikakuCheckbox;
    }

    public void setShikakuCheckbox(String shikakuCheckbox) {
        this.shikakuCheckbox = shikakuCheckbox;
    }

    public String getMenjoCode() {
        return menjoCode;
    }

    public void setMenjoCode(String menjoCode) {
        this.menjoCode = menjoCode;
    }

    public String getMenjoGakaGokakuNo1() {
        return menjoGakaGokakuNo1;
    }

    public void setMenjoGakaGokakuNo1(String menjoGakaGokakuNo1) {
        this.menjoGakaGokakuNo1 = menjoGakaGokakuNo1;
    }

    public String getMenjoGakaGokakuNo2() {
        return menjoGakaGokakuNo2;
    }

    public void setMenjoGakaGokakuNo2(String menjoGakaGokakuNo2) {
        this.menjoGakaGokakuNo2 = menjoGakaGokakuNo2;
    }

    public String getMenjoGakaGokakuNo3() {
        return menjoGakaGokakuNo3;
    }

    public void setMenjoGakaGokakuNo3(String menjoGakaGokakuNo3) {
        this.menjoGakaGokakuNo3 = menjoGakaGokakuNo3;
    }

    public String getMenjoGakaGokakuNo4() {
        return menjoGakaGokakuNo4;
    }

    public void setMenjoGakaGokakuNo4(String menjoGakaGokakuNo4) {
        this.menjoGakaGokakuNo4 = menjoGakaGokakuNo4;
    }

    public String getMenjoGakaGokakuNo5() {
        return menjoGakaGokakuNo5;
    }

    public void setMenjoGakaGokakuNo5(String menjoGakaGokakuNo5) {
        this.menjoGakaGokakuNo5 = menjoGakaGokakuNo5;
    }

    public String getMenjoGakaGokakuNo6() {
        return menjoGakaGokakuNo6;
    }

    public void setMenjoGakaGokakuNo6(String menjoGakaGokakuNo6) {
        this.menjoGakaGokakuNo6 = menjoGakaGokakuNo6;
    }

    public String getMenjoGakaGokakuNo7() {
        return menjoGakaGokakuNo7;
    }

    public void setMenjoGakaGokakuNo7(String menjoGakaGokakuNo7) {
        this.menjoGakaGokakuNo7 = menjoGakaGokakuNo7;
    }

    public String getMenjoGakaGokakuNo8() {
        return menjoGakaGokakuNo8;
    }

    public void setMenjoGakaGokakuNo8(String menjoGakaGokakuNo8) {
        this.menjoGakaGokakuNo8 = menjoGakaGokakuNo8;
    }

    public String getMenjoKyu() {
        return menjoKyu;
    }

    public void setMenjoKyu(String menjoKyu) {
        this.menjoKyu = menjoKyu;
    }
    
    public String getShinseiMenjoNo() {
        return shinseiMenjoNo;
    }

    public void setShinseiMenjoNo(String shinseiMenjoNo) {
        this.shinseiMenjoNo = shinseiMenjoNo;
    }

    
    public String getMnjShubetsuCode() {
        return mnjShubetsuCode;
    }

    public void setMnjShubetsuCode(String mnjShubetsuCode) {
        this.mnjShubetsuCode = mnjShubetsuCode;
    }

    public String getJukenMenjo() {
        return jukenMenjo;
    }

    public void setJukenMenjo(String jukenMenjo) {
        this.jukenMenjo = jukenMenjo;
    }

    public String getShinseiMenjoTitle() {
        return shinseiMenjoTitle;
    }

    public void setShinseiMenjoTitle(String shinseiMenjoTitle) {
        this.shinseiMenjoTitle = shinseiMenjoTitle;
    }

    public String getShinseiMenjoNaiyo() {
        return shinseiMenjoNaiyo;
    }

    public void setShinseiMenjoNaiyo(String shinseiMenjoNaiyo) {
        this.shinseiMenjoNaiyo = shinseiMenjoNaiyo;
    }

    public String getShinseiShikakuNaiyo() {
        return shinseiShikakuNaiyo;
    }

    public void setShinseiShikakuNaiyo(String shinseiShikakuNaiyo) {
        this.shinseiShikakuNaiyo = shinseiShikakuNaiyo;
    }

    public String getShikakuCheckbox2() {
        return shikakuCheckbox2;
    }

    public void setShikakuCheckbox2(String shikakuCheckbox2) {
        this.shikakuCheckbox2 = shikakuCheckbox2;
    }

    public String getHoyuShikakuFurigana() {
        return hoyuShikakuFurigana;
    }

    public void setHoyuShikakuFurigana(String hoyuShikakuFurigana) {
        this.hoyuShikakuFurigana = hoyuShikakuFurigana;
    }
    
    public String getShokurekiKbn() {
        return shokurekiKbn;
    }

    public void setShokurekiKbn(String shokurekiKbn) {
        this.shokurekiKbn = shokurekiKbn;
    }

    public String getShokurekiSeq() {
        return shokurekiSeq;
    }

    public void setShokurekiSeq(String shokurekiSeq) {
        this.shokurekiSeq = shokurekiSeq;
    }

    public String getKinmusakiKaishaName() {
        return kinmusakiKaishaName;
    }

    public void setKinmusakiKaishaName(String kinmusakiKaishaName) {
        this.kinmusakiKaishaName = kinmusakiKaishaName;
    }

    public String getBushoYakushokuName() {
        return bushoYakushokuName;
    }

    public void setBushoYakushokuName(String bushoYakushokuName) {
        this.bushoYakushokuName = bushoYakushokuName;
    }

    public String getShokumuNaiyo() {
        return shokumuNaiyo;
    }

    public void setShokumuNaiyo(String shokumuNaiyo) {
        this.shokumuNaiyo = shokumuNaiyo;
    }

    public String getShokurekiShozaichi() {
        return shokurekiShozaichi;
    }

    public void setShokurekiShozaichi(String shokurekiShozaichi) {
        this.shokurekiShozaichi = shokurekiShozaichi;
    }

    public String getZaisekikikanYearFrom() {
        return zaisekikikanYearFrom;
    }

    public void setZaisekikikanYearFrom(String zaisekikikanYearFrom) {
        this.zaisekikikanYearFrom = zaisekikikanYearFrom;
    }

    public String getZaisekikikanMonthFrom() {
        return zaisekikikanMonthFrom;
    }

    public void setZaisekikikanMonthFrom(String zaisekikikanMonthFrom) {
        this.zaisekikikanMonthFrom = zaisekikikanMonthFrom;
    }

    public String getZaisekikikanYearTo() {
        return zaisekikikanYearTo;
    }

    public void setZaisekikikanYearTo(String zaisekikikanYearTo) {
        this.zaisekikikanYearTo = zaisekikikanYearTo;
    }

    public String getZaisekikikanMonthTo() {
        return zaisekikikanMonthTo;
    }

    public void setZaisekikikanMonthTo(String zaisekikikanMonthTo) {
        this.zaisekikikanMonthTo = zaisekikikanMonthTo;
    }
    
    
    public String getZaisekikikanFrom() {
        return zaisekikikanFrom;
    }

    public void setZaisekikikanFrom(String zaisekikikanFrom) {
        this.zaisekikikanFrom = zaisekikikanFrom;
    }

    public String getZaisekikikanTo() {
        return zaisekikikanTo;
    }

    public void setZaisekikikanTo(String zaisekikikanTo) {
        this.zaisekikikanTo = zaisekikikanTo;
    }

    public String getJitsumuKeikenY() {
        return jitsumuKeikenY;
    }

    public void setJitsumuKeikenY(String jitsumuKeikenY) {
        this.jitsumuKeikenY = jitsumuKeikenY;
    }

    public String getJitsumuKeikenM() {
        return jitsumuKeikenM;
    }

    public void setJitsumuKeikenM(String jitsumuKeikenM) {
        this.jitsumuKeikenM = jitsumuKeikenM;
    }

    public String getJitsumuKeikenDB() {
        return jitsumuKeikenDB;
    }

    public void setJitsumuKeikenDB(String jitsumuKeikenDB) {
        this.jitsumuKeikenDB = jitsumuKeikenDB;
    }

    public String getKinmuNaiyo() {
        return kinmuNaiyo;
    }

    public void setKinmuNaiyo(String kinmuNaiyo) {
        this.kinmuNaiyo = kinmuNaiyo;
    }

    public String getZaishokuKikanGokei() {
        return zaishokuKikanGokei;
    }

    public void setZaishokuKikanGokei(String zaishokuKikanGokei) {
        this.zaishokuKikanGokei = zaishokuKikanGokei;
    }
    
    public String getSskShuryoNo1() {
        return sskShuryoNo1;
    }

    public void setSskShuryoNo1(String sskShuryoNo1) {
        this.sskShuryoNo1 = sskShuryoNo1;
    }

    public String getSskShuryoNo2() {
        return sskShuryoNo2;
    }

    public void setSskShuryoNo2(String sskShuryoNo2) {
        this.sskShuryoNo2 = sskShuryoNo2;
    }

    public String getSskShuryoNo3() {
        return sskShuryoNo3;
    }

    public void setSskShuryoNo3(String sskShuryoNo3) {
        this.sskShuryoNo3 = sskShuryoNo3;
    }

    public String getSskShuryoNo4() {
        return sskShuryoNo4;
    }

    public void setSskShuryoNo4(String sskShuryoNo4) {
        this.sskShuryoNo4 = sskShuryoNo4;
    }

    public String getSskShuryoNo5() {
        return sskShuryoNo5;
    }

    public void setSskShuryoNo5(String sskShuryoNo5) {
        this.sskShuryoNo5 = sskShuryoNo5;
    }

    public HoyuShikakuMst getHoyuShikakuMstForUpdate() {
        return hoyuShikakuMstForUpdate;
    }

    public void setHoyuShikakuMstForUpdate(HoyuShikakuMst hoyuShikakuMstForUpdate) {
        this.hoyuShikakuMstForUpdate = hoyuShikakuMstForUpdate;
    }

    public String getMuryoZanCount() {
        return muryoZanCount;
    }

    public void setMuryoZanCount(String muryoZanCount) {
        this.muryoZanCount = muryoZanCount;
    }
    
    /**
     * ���ϕ��@�敪 ���擾����B
     * @return ���ϕ��@�敪
     */
    public String getKessaiHohoKbn() {
        return kessaiHohoKbn;
    }

    /**
     * ���ϕ��@�敪 ���Z�b�g����B
     * @param kessaiHohoKbn ���ϕ��@�敪
     */
    public void setKessaiHohoKbn(String kessaiHohoKbn) {
        this.kessaiHohoKbn = kessaiHohoKbn;
    }

    public String getNendo() {
        return nendo;
    }

    public void setNendo(String nendo) {
        this.nendo = nendo;
    }

    public String getSagyoKantokuSikakuNo() {
        return sagyoKantokuSikakuNo;
    }

    public void setSagyoKantokuSikakuNo(String sagyoKantokuSikakuNo) {
        this.sagyoKantokuSikakuNo = sagyoKantokuSikakuNo;
    }

    public String getEiseikanrigijutsushaSikakuNo() {
        return eiseikanrigijutsushaSikakuNo;
    }

    public void setEiseikanrigijutsushaSikakuNo(String eiseikanrigijutsushaSikakuNo) {
        this.eiseikanrigijutsushaSikakuNo = eiseikanrigijutsushaSikakuNo;
    }

    public String getTokatsukanrishaSikakuNo() {
        return tokatsukanrishaSikakuNo;
    }

    public void setTokatsukanrishaSikakuNo(String tokatsukanrishaSikakuNo) {
        this.tokatsukanrishaSikakuNo = tokatsukanrishaSikakuNo;
    }
    
    /**
     * @return the mskJoho
     */
    public MskJoho getMskJoho() {
        return mskJoho;
    }

    /**
     * @param mskJoho the mskJoho to set
     */
    public void setMskJoho(MskJoho mskJoho) {
        this.mskJoho = mskJoho;
    }

    public List<Option> getSknNaiyoList() {
        return sknNaiyoList;
    }

    public void setSknNaiyoList(List<Option> sknNaiyoList) {
        this.sknNaiyoList = sknNaiyoList;
    }

    public List<MskSikakuJoho> getShokurekiList() {
        return shokurekiList;
    }

    public void setShokurekiList(List<MskSikakuJoho> shokurekiList) {
        this.shokurekiList = shokurekiList;
    }

    public List<Option> getShokumuNaiyoList() {
        return BmaConstants.SHOKUMU_NAIYO_LIST;
    }

    public void setShokumuNaiyoList(List<Option> shokumuNaiyoList) {
        this.shokumuNaiyoList = shokumuNaiyoList;
    }
    
    /**
     * @return the kunrenShisetsuName
     */
    public String getKunrenShisetsuName() {
        return kunrenShisetsuName;
    }

    /**
     * @param kunrenShisetsuName the kunrenShisetsuName to set
     */
    public void setKunrenShisetsuName(String kunrenShisetsuName) {
        this.kunrenShisetsuName = kunrenShisetsuName;
    }

    public String getKunrenKikanYearFrom() {
        return kunrenKikanYearFrom;
    }

    public void setKunrenKikanYearFrom(String kunrenKikanYearFrom) {
        this.kunrenKikanYearFrom = kunrenKikanYearFrom;
    }

    public String getKunrenKikanMonthFrom() {
        return kunrenKikanMonthFrom;
    }

    public void setKunrenKikanMonthFrom(String kunrenKikanMonthFrom) {
        this.kunrenKikanMonthFrom = kunrenKikanMonthFrom;
    }

    public String getKunrenKikanYearTo() {
        return kunrenKikanYearTo;
    }

    public void setKunrenKikanYearTo(String kunrenKikanYearTo) {
        this.kunrenKikanYearTo = kunrenKikanYearTo;
    }

    public String getKunrenKikanMonthTo() {
        return kunrenKikanMonthTo;
    }

    public void setKunrenKikanMonthTo(String kunrenKikanMonthTo) {
        this.kunrenKikanMonthTo = kunrenKikanMonthTo;
    }

    /**
     * @return the kunrenka
     */
    public String getKunrenka() {
        return kunrenka;
    }

    /**
     * @param kunrenka the kunrenka to set
     */
    public void setKunrenka(String kunrenka) {
        this.kunrenka = kunrenka;
    }

    /**
     * @return the kunrenShozaichi
     */
    public String getKunrenShozaichi() {
        return kunrenShozaichi;
    }

    /**
     * @param kunrenShozaichi the kunrenShozaichi to set
     */
    public void setKunrenShozaichi(String kunrenShozaichi) {
        this.kunrenShozaichi = kunrenShozaichi;
    }
    
    public List<String> getDisabledSknNaiyoKbnList() {
        return disabledSknNaiyoKbnList;
    }
    
    public void setDisabledSknNaiyoKbnList(List<String> disabledSknNaiyoKbnList) {
        this.disabledSknNaiyoKbnList = disabledSknNaiyoKbnList;
    }

    public MskSknJoho getMskSknJoho() {
        return mskSknJoho;
    }

    public void setMskSknJoho(MskSknJoho mskSknJoho) {
        this.mskSknJoho = mskSknJoho;
    }

    public MskKsuJoho getMskKsuJoho() {
        return mskKsuJoho;
    }

    public void setMskKsuJoho(MskKsuJoho mskKsuJoho) {
        this.mskKsuJoho = mskKsuJoho;
    }
    
    /**
     * �E�����e�擾
     * @return the shokumuNaiyoDisp
     */
    public String getShokumuNaiyoDisp() {
        String ret = "";
        if(BmaUtility.isNullOrEmpty(getShokumuNaiyo())){
            return ret;
        }
        for (Option option : getShokumuNaiyoList()) {
            if(option.getValue().equals(getShokumuNaiyo())){
                ret = option.getLabel();
                break;
            }
        }
        return ret;
    }
    
    /**
     * �������e�敪�擾
     * @return the sknNaiyoKbnDisp
     */
    public String getSknNaiyoKbnDisp() {
        String ret = "";
        if(BmaUtility.isNullOrEmpty(getSknNaiyoKbn())){
            return ret;
        }
        for (Option option : getSknNaiyoList()) {
            if(option.getValue().equals(getSknNaiyoKbn())){
                ret = option.getLabel();
                break;
            }
        }
        return ret;
    }
    }

