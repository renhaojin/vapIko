package jp.co.nii.bma.business.service.moshikomi;

import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import jp.co.nii.bma.business.domain.MeishoKanri;
import jp.co.nii.bma.business.domain.Saiban;
import jp.co.nii.bma.business.service.common.SaibanService;
import jp.co.nii.bma.business.rto.MskGazoJoho;
import jp.co.nii.bma.business.rto.RrkMskJoho;
import jp.co.nii.bma.business.service.common.BmaConstants;
import jp.co.nii.bma.business.service.common.BmaLogger;
import jp.co.nii.bma.business.service.common.BmaValidator;
import jp.co.nii.bma.presentation.common.BmaText;
import jp.co.nii.bma.utility.BmaUtility;
import jp.co.nii.sew.business.service.AbstractService;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_SUCCESS;
import jp.co.nii.sew.presentation.Messages;
import jp.co.nii.sew.presentation.RequestTransferObject;
import jp.co.nii.sew.utility.PropertyUtility;
import org.apache.commons.fileupload.FileItem;

/**
 * <p>
 * �^�C�g��: �\�����ӎ�����ʃT�[�r�X</p>
 * <p>
 * ����: �\�����ӎ�����ʃT�[�r�X</p>
 * <p>
 * ���쌠: Copyright (c) 2020</p>
 * <p>
 * ��Ж�: ���{���Y�Ɗ������</p>
 */
public class MskGazoSelectService extends AbstractService {

    /**
     * DB�ڑ��̃f�[�^�\�[�X
     */
    private static String DATA_SOURCE_NAME;
    /**
     * ���O
     */
    BmaLogger log = (BmaLogger) BmaLogger.getLogger(this.getClass().getName());
    /**
     * �Ɩ��R�[�h
     */
    private static final String BUSINESS_CODE = PropertyUtility.getProperty("business_code");
    /**
     * ���׃e�X�g���[�h
     */
    private static final String STRESS_MODE = PropertyUtility.getProperty(BUSINESS_CODE + "stress_mode");

    /**
     * �R���X�g���N�^
     */
    public MskGazoSelectService() {
        super();
        /* DB�ڑ����̃��[�U�[������ */
        DATA_SOURCE_NAME = BmaConstants.DS_REGISTRANT;
    }

    /**
     * �T�[�r�X�N���X�̎��s���\�b�h
     *
     * @param rto ���N�G�X�g��񂩂�擾����rto
     * @param rtoInSession �Z�b�V�������rto
     * @return foward��
     * @throws Exception ��O
     */
    @Override
    public String doService(RequestTransferObject rto, RequestTransferObject rtoInSession)
            throws Exception {
        MskGazoJoho inRequest = (MskGazoJoho) rto;
        MskGazoJoho inSession = (MskGazoJoho) rtoInSession;
        String processName = "";
        /*�G���[���b�Z�[�W������*/
        inSession.setErrors(new Messages());
        try {
            // �摜�A�b�v���[�h��
            if (!BmaUtility.isNullOrEmpty(inRequest.getGazoUpd())) {
                processName = "MskGazoSelectUpload";
                log.Start(processName);
                 Messages errors = new Messages();
                // �t�@�C�������̏ꍇ
                if (inRequest.getFileItem() == null || BmaUtility.isNullOrEmpty(inRequest.getFileItem().getName())) {
                    String groupCode = "fileItem";
                    String itemName = "�摜�t�@�C��";
                    BmaValidator.addMessage(errors, groupCode, BmaText.E00003, itemName);
                    inSession.setErrors(errors);
                    return FWD_NM_RELOAD;
                }
                // �t�@�C�����擾
                inSession.setUploadCheck("");
                String fileName = "";
                File file = new File(fileName);
                if (BmaUtility.isNullOrEmpty(inSession.getRrkFlg())) {
                    List<MskGazoJoho> shomeishoList;
                    List<MskGazoJoho> jknSikakuList;
                    List<MskGazoJoho> menjoList;
                    shomeishoList = inSession.getShomeishoList();
                    jknSikakuList = inSession.getJknSikakuList();
                    menjoList = inSession.getMenjoList();
                    // PATH���t���Ă���̃t�@�C���̂ݔ��f����
                    int index = fileName.indexOf("\\");
                    // IE��������
                    if (index > 0 && !file.exists()) {
                        /* �e�h�k�d���݂��Ă��܂���̎��G���[*/
                        BmaValidator.addMessage(errors, "fileItem", "{0}�͑��݂��Ă��܂���B", "�t�@�C��");
                        inSession.setErrors(errors);
                        return FWD_NM_RELOAD;
                    }

                    /* �ʐ^���ۑ� */
                    if (uploadFile(inRequest, inSession)) {
                        switch (inRequest.getGazoKbn()) {
                            case BmaConstants.GAZO_KBN_KAO_IMG:
                                shomeishoList.get(0).setShomeishoruiUpdStatus(BmaConstants.GAZO_UPD_STATUS_SUMI);
                                shomeishoList.get(0).setGazoIdx(inSession.getGazoIdx());
                                break;
                            case BmaConstants.GAZO_KBN_NENREI_IMG:
                                shomeishoList.get(1).setShomeishoruiUpdStatus(BmaConstants.GAZO_UPD_STATUS_SUMI);
                                shomeishoList.get(1).setGazoIdx(inSession.getGazoIdx());
                                break;
                            case BmaConstants.GAZO_KBN_SHIKAKU_IMG:
                                jknSikakuList.get(0).setJknsikakuUpdStatus(BmaConstants.GAZO_UPD_STATUS_SUMI);
                                jknSikakuList.get(0).setGazoIdx(inSession.getGazoIdx());
                                break;
                            case BmaConstants.GAZO_KBN_MENJO_IMG:
                                menjoList.get(0).setMenjoUpdStatus(BmaConstants.GAZO_UPD_STATUS_SUMI);
                                menjoList.get(0).setGazoIdx(inSession.getGazoIdx());
                                break;
                            default:
                                break;
                        }
                        inSession.setShomeishoList(shomeishoList);
                        inSession.setJknSikakuList(jknSikakuList);
                        inSession.setMenjoList(menjoList);
                        BmaValidator.addMessage(errors, "fileItem", "�摜�̉��o�^���������܂����I", "fileItem");
                        inSession.setErrors(errors);
                        inSession.setGazoUpdFlg("1");
                        inSession.setUpdCheck("1");
                        // �����̏ꍇ
                        if (BmaConstants.SKN_KBN.equals(inRequest.getSknKsuKbn())) {
                            // �A�b�v���[�h���ׂĐ������ǂ�������
                            if ((!BmaConstants.GAZO_UPD_STATUS_SUMI.equals(inSession.getShomeishoList().get(0).getShomeishoruiUpdStatus()) && !BmaUtility.isNullOrEmpty(inSession.getKaoImg()))
                                    || (!BmaConstants.GAZO_UPD_STATUS_SUMI.equals(inSession.getShomeishoList().get(1).getShomeishoruiUpdStatus()) && !BmaUtility.isNullOrEmpty(inSession.getNenreiImg()))
                                    || (!BmaConstants.GAZO_UPD_STATUS_SUMI.equals(inSession.getJknSikakuList().get(0).getJknsikakuUpdStatus()) && !BmaUtility.isNullOrEmpty(inSession.getShikakuImg()))
                                    || (!BmaConstants.GAZO_UPD_STATUS_SUMI.equals(inSession.getMenjoList().get(0).getMenjoUpdStatus()) && !BmaUtility.isNullOrEmpty(inSession.getMenjyoImg()))) {
                            } else {
                                // ����
                                inSession.setGazoUpdNext("1");
                            }
                        } else {
                            // �A�b�v���[�h���ׂĐ������ǂ�������
                            if ((!BmaConstants.GAZO_UPD_STATUS_SUMI.equals(inSession.getShomeishoList().get(0).getShomeishoruiUpdStatus()) && !BmaUtility.isNullOrEmpty(inSession.getKaoImg()))) {
                            } else {
                                // ����
                                inSession.setGazoUpdNext("1");
                            }
                        }
                        List<String> gazoIdxs = inSession.getGazoIdxs();
                        if (!gazoIdxs.contains(inSession.getGazoIdx())) {
                            gazoIdxs.add(inSession.getGazoIdx());
                        }
                        inSession.setGazoIdxs(gazoIdxs);
                    } else {
                        // ����
                        inSession.setGazoUpdNext("");
                        // �摜IDX�폜
                        List<String> gazoIdxs = inSession.getGazoIdxs();
                        gazoIdxs.remove(inSession.getGazoIdx());
                        inSession.setGazoIdxs(gazoIdxs);
                        inSession.setGazoIdx("");
                    }
                } else { // �����̏ꍇ
                    List<RrkMskJoho> shomeishoList;
                    List<RrkMskJoho> jknSikakuList;
                    List<RrkMskJoho> menjoList;
                    shomeishoList = inRequest.getRrkShomeishoList();
                    jknSikakuList = inRequest.getRrkJknSikakuList();
                    menjoList = inRequest.getRrkMenjoList();
                    // PATH���t���Ă���̃t�@�C���̂ݔ��f����
                    int index = fileName.indexOf("\\");
                    // IE��������
                    if (index > 0 && !file.exists()) {
                        /* �e�h�k�d���݂��Ă��܂���̎��G���[*/
                        BmaValidator.addMessage(errors, "fileItem", "{0}�͑��݂��Ă��܂���B", "�t�@�C��");
                        inSession.setErrors(errors);
                        return FWD_NM_RELOAD;
                    }
                    /* �ʐ^���ۑ� */
                    if (uploadFile(inRequest, inSession)) {
                        switch (inRequest.getGazoKbn()) {
                            case BmaConstants.GAZO_KBN_KAO_IMG:
                                shomeishoList.get(0).setShomeishoruiUpdStatus(BmaConstants.GAZO_UPD_STATUS_SUMI);
                                shomeishoList.get(0).setGazoIdx(inSession.getGazoIdx());
                                break;
                            case BmaConstants.GAZO_KBN_NENREI_IMG:
                                shomeishoList.get(1).setShomeishoruiUpdStatus(BmaConstants.GAZO_UPD_STATUS_SUMI);
                                shomeishoList.get(1).setGazoIdx(inSession.getGazoIdx());
                                break;
                            case BmaConstants.GAZO_KBN_SHIKAKU_IMG:
                                jknSikakuList.get(0).setJknsikakuUpdStatus(BmaConstants.GAZO_UPD_STATUS_SUMI);
                                jknSikakuList.get(0).setGazoIdx(inSession.getGazoIdx());
                                break;
                            case BmaConstants.GAZO_KBN_MENJO_IMG:
                                menjoList.get(0).setMenjoUpdStatus(BmaConstants.GAZO_UPD_STATUS_SUMI);
                                menjoList.get(0).setGazoIdx(inSession.getGazoIdx());
                                break;
                            default:
                                break;
                        }
                        inSession.setRrkShomeishoList(shomeishoList);
                        inSession.setRrkJknSikakuList(jknSikakuList);
                        inSession.setRrkMenjoList(menjoList);
                        BmaValidator.addMessage(errors, "fileItem", "�摜�̉��o�^���������܂����I", "fileItem");
                        inSession.setErrors(errors);
                        
                        List<String> gazoIdxs = inSession.getGazoIdxs();
                        if (!gazoIdxs.contains(inSession.getGazoIdx())) {
                            gazoIdxs.add(inSession.getGazoIdx());
                        }
                        inSession.setGazoIdxs(gazoIdxs);
                    } else {
                        // �摜IDX�폜
                        List<String> gazoIdxs = inSession.getGazoIdxs();
                        gazoIdxs.remove(inSession.getGazoIdx());
                        inSession.setGazoIdxs(gazoIdxs);
                        inSession.setGazoIdx("");
                   }
                }
                
                inSession.setGazoKbn(inRequest.getGazoKbn());
                inSession.setFileKbn(BmaConstants.FILE_KBN_GAZO_CONFIRM);
//                inSession.setGazoIdx(inRequest.getGazoIdx());
                return FWD_NM_RELOAD;
                // �A�b�v���[�h��ʊJ����
            } else if (!BmaUtility.isNullOrEmpty(inRequest.getGazoKbn())) {
                processName = "MskGazoSelect";
                log.Start(processName);
                inSession.setErrors(new Messages());
                MeishoKanri meishoKanri = new MeishoKanri(BmaConstants.DS_REGISTRANT);
                meishoKanri = meishoKanri.find(BmaConstants.GAZO_KBN, inRequest.getGazoKbn());
                inSession.setGazoShubetsu(meishoKanri.getHanyoChi());
                inSession.setGazoKbn(inRequest.getGazoKbn());
                inSession.setGazoIdx(inRequest.getGazoIdx());
                inSession.setFileKbn(BmaConstants.FILE_KBN_GAZO_CONFIRM);
                if (!BmaUtility.isNullOrEmpty(inRequest.getGazoUpdFlg())) {
                    inSession.setGazoUpdFlg(inRequest.getGazoUpdFlg());
                }

                // �����t���O�ۑ�
                if (!BmaUtility.isNullOrEmpty(inRequest.getRrkFlg())) {
                    inSession.setRrkFlg(inRequest.getRrkFlg());
                }
                return FWD_NM_SUCCESS;
            } else {
                /*�ُ�J��*/
                log.IllegalFWD();
                return FWD_NM_SESSION;
            }
        } catch (Exception e) {
            throw e;
        } finally {
            log.End(processName);
        }
    }

    /**
     * �ʐ^�t�@�C���A�b�v���[�h����
     *
     * @param inRequest
     * @param inSession
     * @return true:�A�b�v���[�h���� false:�A�b�v���[�h�t�@�C����
     */
    private boolean uploadFile(MskGazoJoho inRequest, MskGazoJoho inSession) throws Exception {
        Messages errors = new Messages();
        String groupCode = "fileItem";
        String itemName = "�摜�t�@�C��";

        //�t�@�C���A�b�v���[�h FileItem�g�p
        if (inRequest.getFileItem() != null && !BmaUtility.isNullOrEmpty(inRequest.getFileItem().getName())) {
            FileItem item = inRequest.getFileItem();
            /* �t�@�C�����擾 */
            String fileName = inRequest.getFileItem().getName();
            // �����Ɛ\���𕪂���
            String orgPath = BmaConstants.RRK_FLG.equals(inSession.getRrkFlg()) ? BmaConstants.PHOTO_UPLOAD_PATH_KAKUTEI : BmaConstants.PHOTO_UPLOAD_PATH_TEMP;

            String strNam = "";
            switch (inRequest.getGazoKbn()) {
                case BmaConstants.GAZO_KBN_KAO_IMG:
                    String gazoIdx = null;
                    if (!inSession.getShomeishoList().isEmpty()) {
                        gazoIdx = inSession.getShomeishoList().get(0).getGazoIdx();
                        if (BmaUtility.isNullOrEmpty(gazoIdx)) {
                            Saiban saiban = new SaibanService(DATA_SOURCE_NAME).getSaibanAndUpdate(BmaConstants.SAIBAN_GAZOIDX, inRequest.getMoshikomishaId());
                            inSession.setGazoIdx(saiban.getGenzaiNo());
                        } else {
                            inSession.setGazoIdx(gazoIdx);
                        }
                    } else {
                        gazoIdx = inRequest.getRrkShomeishoList().get(0).getGazoIdx();
                        if (BmaUtility.isNullOrEmpty(gazoIdx)) {
                            Saiban saiban = new SaibanService(DATA_SOURCE_NAME).getSaibanAndUpdate(BmaConstants.SAIBAN_GAZOIDX, inSession.getMoshikomishaId());
                            inSession.setGazoIdx(saiban.getGenzaiNo());
                        } else {
                            inSession.setGazoIdx(gazoIdx);
                        }
                    }
                    break;
                case BmaConstants.GAZO_KBN_NENREI_IMG:
                    if (!inSession.getShomeishoList().isEmpty()) {
                        gazoIdx = inSession.getShomeishoList().get(1).getGazoIdx();
                        if (BmaUtility.isNullOrEmpty(gazoIdx)) {
                            Saiban saiban = new SaibanService(DATA_SOURCE_NAME).getSaibanAndUpdate(BmaConstants.SAIBAN_GAZOIDX, inSession.getMoshikomishaId());
                            inSession.setGazoIdx(saiban.getGenzaiNo());
                        } else {
                            inSession.setGazoIdx(gazoIdx);
                        }
                    } else {
                        gazoIdx = inRequest.getRrkShomeishoList().get(1).getGazoIdx();
                        if (BmaUtility.isNullOrEmpty(gazoIdx)) {
                            Saiban saiban = new SaibanService(DATA_SOURCE_NAME).getSaibanAndUpdate(BmaConstants.SAIBAN_GAZOIDX, inSession.getMoshikomishaId());
                            inSession.setGazoIdx(saiban.getGenzaiNo());
                        } else {
                            inSession.setGazoIdx(gazoIdx);
                        }
                    }
                    break;
                case BmaConstants.GAZO_KBN_SHIKAKU_IMG:
                    if (!inSession.getShomeishoList().isEmpty()) {
                        gazoIdx = inSession.getJknSikakuList().get(0).getGazoIdx();
                        if (BmaUtility.isNullOrEmpty(gazoIdx)) {
                            Saiban saiban = new SaibanService(DATA_SOURCE_NAME).getSaibanAndUpdate(BmaConstants.SAIBAN_GAZOIDX, inSession.getMoshikomishaId());
                            inSession.setGazoIdx(saiban.getGenzaiNo());
                        } else {
                            inSession.setGazoIdx(gazoIdx);
                        }
                    } else {
                        gazoIdx = inRequest.getRrkJknSikakuList().get(0).getGazoIdx();
                        if (BmaUtility.isNullOrEmpty(gazoIdx)) {
                            Saiban saiban = new SaibanService(DATA_SOURCE_NAME).getSaibanAndUpdate(BmaConstants.SAIBAN_GAZOIDX, inSession.getMoshikomishaId());
                            inSession.setGazoIdx(saiban.getGenzaiNo());
                        } else {
                            inSession.setGazoIdx(gazoIdx);
                        }
                    }
                    break;
                case BmaConstants.GAZO_KBN_MENJO_IMG:
                    if (!inSession.getShomeishoList().isEmpty()) {
                        gazoIdx = inSession.getMenjoList().get(0).getGazoIdx();
                        if (BmaUtility.isNullOrEmpty(gazoIdx)) {
                            Saiban saiban = new SaibanService(DATA_SOURCE_NAME).getSaibanAndUpdate(BmaConstants.SAIBAN_GAZOIDX, inSession.getMoshikomishaId());
                            inSession.setGazoIdx(saiban.getGenzaiNo());
                        } else {
                            inSession.setGazoIdx(gazoIdx);
                        }
                    } else {
                        gazoIdx = inRequest.getRrkMenjoList().get(0).getGazoIdx();
                        if (BmaUtility.isNullOrEmpty(gazoIdx)) {
                            Saiban saiban = new SaibanService(DATA_SOURCE_NAME).getSaibanAndUpdate(BmaConstants.SAIBAN_GAZOIDX, inSession.getMoshikomishaId());
                            inSession.setGazoIdx(saiban.getGenzaiNo());
                        } else {
                            inSession.setGazoIdx(gazoIdx);
                        }
                    }
                    break;
                default:
                    break;
            }
            strNam = inSession.getGazoIdx() + ".jpeg";
            /* �g���q�`�F�b�N */
            if (!BmaValidator.validateFileExtension(fileName, BmaConstants.PHOTO_FILE_EXTENSIONS, errors, groupCode, "JPEG")) {
                inSession.setErrors(errors);
                return false;
            }

            /* �t�@�C���T�C�Y�`�F�b�N */
            if (!BmaValidator.validateFileSize(item.getSize(),
                    BmaConstants.PHOTO_UPLOAD_MAX_FILE_SIZE, errors, groupCode, itemName)) {
                /* ����l���I�[�o�[�����ꍇ�G���[ */
                inSession.setErrors(errors);
                return false;
            }
            String path = orgPath + strNam;

            File file = new File(orgPath);
            if (!file.exists()) {
                /* PATH���݂��Ă��܂���̎��G���[*/
                BmaValidator.addMessage(errors, "fileItem", BmaText.E00045, "�ۑ��t�H���_");
                inSession.setErrors(errors);
                return false;
            }

            FileItem objFi = inRequest.getFileItem();

            try {
                /*���[�U�C���f�b�N�X���ݎ�*/
                if (strNam != null && !strNam.equals("")) {

                    /*�������Ƀt�@�C�������݂����ꍇ�͍폜*/
                    if (new File(orgPath + strNam).exists()) {
                        Files.delete((Paths.get(orgPath + strNam)));
                    }

                    objFi.write(new File(orgPath + strNam));
                    boolean retCheck = isImage(inSession, item, orgPath, strNam);
                    if (!retCheck) {
                        Files.delete((Paths.get(orgPath + strNam)));
                        // �X�e�[�^�X�𖢃A�b�v���[�h�ɐݒ�
                        setStatus(inRequest, inSession);
                        return false;
                    } else {
                        // �摜�ʐ^�ƔN��m�F���ނ̏ꍇ�̂݃`�F�b�N
                        if (BmaConstants.GAZO_KBN_KAO_IMG.equals(inRequest.getGazoKbn()) || BmaConstants.GAZO_KBN_NENREI_IMG.equals(inRequest.getGazoKbn())) {
                            /* �摜�̃T�C�Y�`�F�b�N */
                            if (!BmaValidator.validateImgSize(path, Integer.parseInt(BmaConstants.PHOTO_PIXEL_WIDTH),
                                    Integer.parseInt(BmaConstants.PHOTO_PIXEL_HEIGHT), errors, groupCode, itemName)) {
                                /* ����l���I�[�o�[�����ꍇ�G���[ */
                                Files.delete((Paths.get(orgPath + strNam)));
                                inSession.setErrors(errors);
                                // �X�e�[�^�X�𖢃A�b�v���[�h�ɐݒ�
                                setStatus(inRequest, inSession);
                                return false;
                            }
                        }
                    }
                } else {
                    BmaValidator.validateRequired("", errors, groupCode, itemName);
                    inSession.setErrors(errors);
                    return false;
                }
            } catch (Exception e) {
                /*���O�o�͓�*/
                log.warn("�摜�̃A�b�v���[�h�Ɏ��s���܂����B", e);
                throw e;
            } finally {
                objFi.delete();
                inRequest.setFileItem(null);
            }

            BmaValidator.addMessage(errors, "fileItem", "�摜�@�C���A�b�v���[�h���������܂����B", "");
            inSession.setErrors(errors);

            return true;
        } else {
            BmaValidator.validateRequired("", errors, groupCode, itemName);
            inSession.setErrors(errors);
            return false;
        }
    }

    public static boolean isImage(MskGazoJoho inSession, FileItem image, String orgPath, String strNam) throws IOException {
        Messages errors = new Messages();
        //DataInputStream dataInStream = null;
        // RGB���[�h������
        byte[] header = new byte[20];
        int readByte = 0, totalByte = 0;
        try ( // From *.jpg
                DataInputStream dataInStream
                = new DataInputStream(
                        new BufferedInputStream(
                                new FileInputStream(orgPath + strNam)));) {
            readByte = dataInStream.read(header);
            // RGB���[�h������@JPEG�t�@�C���擪�W�o�C�g��FF D8 FF E0�ł��邱��
            if ((header[0] & 0xFF) == 0xFF
                    && (header[1] & 0xFF) == 0xD8
                    && (header[2] & 0xFF) == 0xFF
                    && (header[3] & 0xFF) == 0xE0) {
            } else {
                /* RGB���[�h�łȂ����G���[*/
                BmaValidator.addMessage(errors, "fileItem", "JPEG�`�����ł�RGB���[�h�̃t�@�C�����g�p���Ă��������B", orgPath);
                inSession.setErrors(errors);
                return false;
            }
            return true;
        }
    }

    // �A�b�v���[�h����������p���X�g
    public static <T> List<T> uploadFinishedList(List<T> shomeishoList, List<T> jknSikakuList, List<T> menjoList) {
        List<T> gazoList = new ArrayList<>();
        gazoList.addAll(shomeishoList);
        gazoList.addAll(jknSikakuList);
        gazoList.addAll(menjoList);
        return gazoList;
    }

    // �t�@�C���폜���A�X�e�[�^�X�𖢃A�b�v���[�h�ɐݒ�
    private void setStatus(MskGazoJoho inRequest, MskGazoJoho inSession) {
        // �t�@�C���폜���A�X�e�[�^�X�͖��A�b�v���[�h�ɕύX
        switch (inRequest.getGazoKbn()) {
            case BmaConstants.GAZO_KBN_KAO_IMG:
                if (BmaConstants.RRK_FLG.equals(inSession.getRrkFlg())) {
                    inSession.setRrkShomeishoList(inRequest.getRrkShomeishoList());
                    inSession.getRrkShomeishoList().get(0).setShomeishoruiUpdStatus(BmaConstants.GAZO_UPD_STATUS_MI);
                    inSession.getRrkShomeishoList().get(0).setGazoIdx("");
                } else {
                    inSession.getShomeishoList().get(0).setShomeishoruiUpdStatus(BmaConstants.GAZO_UPD_STATUS_MI);
                    inSession.getShomeishoList().get(0).setGazoIdx("");
                }
                break;
            case BmaConstants.GAZO_KBN_NENREI_IMG:
                if (BmaConstants.RRK_FLG.equals(inSession.getRrkFlg())) {
                    inSession.setRrkShomeishoList(inRequest.getRrkShomeishoList());
                    inSession.getRrkShomeishoList().get(1).setShomeishoruiUpdStatus(BmaConstants.GAZO_UPD_STATUS_MI);
                    inSession.getRrkShomeishoList().get(1).setGazoIdx("");
                } else {
                    inSession.getShomeishoList().get(1).setShomeishoruiUpdStatus(BmaConstants.GAZO_UPD_STATUS_MI);
                    inSession.getShomeishoList().get(1).setGazoIdx("");
                }
                break;
            case BmaConstants.GAZO_KBN_SHIKAKU_IMG:
                inSession.setShikakuShomeiShorui(BmaConstants.GAZO_UPD_STATUS_MI);
                if (BmaConstants.RRK_FLG.equals(inSession.getRrkFlg())) {
                    inSession.setRrkJknSikakuList(inRequest.getRrkJknSikakuList());
                    inSession.getRrkJknSikakuList().get(0).setJknsikakuUpdStatus(BmaConstants.GAZO_UPD_STATUS_MI);
                    inSession.getRrkJknSikakuList().get(0).setGazoIdx("");
                } else {
                    inSession.getJknSikakuList().get(0).setJknsikakuUpdStatus(BmaConstants.GAZO_UPD_STATUS_MI);
                    inSession.getJknSikakuList().get(0).setGazoIdx("");
                }
                break;
            case BmaConstants.GAZO_KBN_MENJO_IMG:
                inSession.setMenjoShomeiShorui(BmaConstants.GAZO_UPD_STATUS_MI);
                if (BmaConstants.RRK_FLG.equals(inSession.getRrkFlg())) {
                    inSession.setRrkMenjoList(inRequest.getRrkMenjoList());
                    inSession.getRrkMenjoList().get(0).setMenjoUpdStatus(BmaConstants.GAZO_UPD_STATUS_MI);
                    inSession.getRrkMenjoList().get(0).setGazoIdx("");
                } else {
                    inSession.getMenjoList().get(0).setMenjoUpdStatus(BmaConstants.GAZO_UPD_STATUS_MI);
                    inSession.getMenjoList().get(0).setGazoIdx("");
                }
                break;
            default:
                break;
        }
    }
}
