package jp.co.nii.bma.integration;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import jp.co.nii.bma.business.domain.KessaiDao;
import jp.co.nii.bma.business.domain.MeishoKanriDao;
import jp.co.nii.bma.business.domain.MoshikomiDao;
import jp.co.nii.bma.business.domain.ShiyoKaijoDao;
import jp.co.nii.bma.business.domain.SknksuMstDao;
import jp.co.nii.bma.business.domain.TorokushaDao;
import jp.co.nii.bma.business.service.common.BmaConstants;
import jp.co.nii.sew.common.LogGenerate;
import static jp.co.nii.sew.integration.AbstractDao.getSchemaName;
import jp.co.nii.sew.integration.SQLStateSQLExceptionTranslater;

/**
 * ���� DAO�����N���X
 * @author DB�Ǘ��c�[��
 */
public class KessaiDaoImpl extends GeneratedKessaiDaoImpl implements KessaiDao {

    /**
     * �C���X�^���X�𐶐�����B
     * @param datasource �f�[�^�\�[�X��
     */
    public KessaiDaoImpl(String datasource) {
        super(datasource);
    }

    /**
     * ���\�����[���p�p�����[�^���擾
     * 
     * @param nendo �\���N�x
     * @param uketsukeNo ��t�ԍ�
     * @param sknksuKbn �����u�K��敪
     * 
     */
    @Override
    public Map<String, String> kessaiJohoForMail(String nendo, String uketsukeNo, String sknksuKbn){
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = "";
        Map<String, String> kessaiParamMap = new HashMap<>();

        try {
            con = getConnection();
            sql = "SELECT DISTINCT "
                    + " sknksu.SKN_KSU_NAME AS SKN_KSU_NAME"
                    + ", " + getSQLForDecryptByUTF8("SHIMEI")
                    + ", " + " kessai.UKETSUKE_NO AS UKETSUKE_NO"
                    + ", " + " sknShikenNaiyo.HANYO_CHI AS SHIKEN_NAIYO"
                    + ", " + " sknKaisaichi.HANYO_CHI AS KIBO_CHIKU"
                    + ", " + " kessaiHoho.HANYO_CHI AS KESSAI_HOHO"
                    + ", " + " kessai.KESSAI_KINGAKU_TOTAL AS KESSAI_KINGAKU_TOTAL"
                    + ", " + " convenience.HANYO_CHI AS KESSAI_CONVENIENCE"
                    + ", " + " kessai.KESSAI_CONVENIENCE_HARAIKOMI_NO AS CONVENIENCE_HARAIKOMI_NO"
                    + ", " + " kessai.KESSAI_SHUNO_KIKAN_NO AS PAYEASY_SHUNO_KIKAN_NO"
                    + ", " + " kessai.KESSAI_OKYAKUSAMA_NO AS PAYEASY_OKYAKUSAMA_NO"
                    + ", " + " kessai.KESSAI_KAKUNIN_NO AS PAYEASY_KAKUNIN_NO"
                    + ", " + " kessai.KESSAI_KIGEN_BI AS KESSAI_KIGEN_BI"
                    + ", " + " moshikomi.KOJIN_DANTAI_KBN ";            
            if (BmaConstants.KSU_KBN.equals(sknksuKbn)) {
                sql += ", " + " ksuShiyoKaijo.KAIJO_NAME AS KAIJO_NAME";
            }
            
            sql += " FROM " + getSchemaName() + "." + KessaiDao.TABLE_NAME + " AS kessai"
                    + " INNER JOIN " + getSchemaName() + "." + MoshikomiDao.TABLE_NAME + " as moshikomi"
                    + " ON " + "kessai.NENDO  =  moshikomi.NENDO "
                    + " AND " + "kessai.UKETSUKE_NO  =  moshikomi.UKETSUKE_NO "
                    + " INNER JOIN " + getSchemaName() + "." + TorokushaDao.TABLE_NAME + " AS torokusha"
                    + " ON "
                    + " CASE " 
                    + "   WHEN moshikomi.kojin_dantai_kbn = '1' then moshikomi.moshikomisha_id "
                    + "   WHEN moshikomi.kojin_dantai_kbn = '2' then moshikomi.toroku_user_id "
                    + " END = TOROKUSHA.moshikomisha_id "
                    + " INNER JOIN " + getSchemaName() + "." + SknksuMstDao.TABLE_NAME + " AS sknksu"
                    + " ON " + "moshikomi.SKN_KSU_CODE  =  sknksu.SKN_KSU_CODE "
                    + " AND " + "moshikomi.SHUBETSU_CODE  =  sknksu.SHUBETSU_CODE "
                    + " AND " + "moshikomi.KAISU_CODE  =  sknksu.KAISU_CODE "
                    + " LEFT JOIN " + getSchemaName() + "." + MeishoKanriDao.TABLE_NAME + " AS sknShikenNaiyo"
                    + " ON " + "moshikomi.SHIKEN_NAIYO_KBN  =  sknShikenNaiyo.HANYO_CODE "
                    + " AND " + "sknShikenNaiyo.GROUP_CODE =  'SHIKEN_NAIYO_KBN' "
                    + " LEFT JOIN " + getSchemaName() + "." + MeishoKanriDao.TABLE_NAME + " AS sknKaisaichi"
                    + " ON " + "moshikomi.KIBO_KAISAICHI_CODE  =  sknKaisaichi.HANYO_CODE "
                    + " AND " + "sknKaisaichi.GROUP_CODE =  'KAISAICHI_CODE' "
                    + " LEFT JOIN " + getSchemaName() + "." + MeishoKanriDao.TABLE_NAME + " AS kessaiHoho"
                    + " ON " + "kessai.KESSAI_HOHO_KBN  =  kessaiHoho.HANYO_CODE "
                    + " AND " + "kessaiHoho.GROUP_CODE =  'KESSAI_HOHO_KBN' "
                    + " LEFT JOIN " + getSchemaName() + "." + MeishoKanriDao.TABLE_NAME + " AS convenience"
                    + " ON " + "kessai.KESSAI_CONVENIENCE_SHUBETSU  =  convenience.HANYO_CODE "
                    + " AND " + "convenience.GROUP_CODE =  'KESSAI_CONVENIENCE_SHUBETSU' ";
            if (BmaConstants.KSU_KBN.equals(sknksuKbn)) {
                sql +=  " LEFT JOIN " + getSchemaName() + "." + ShiyoKaijoDao.TABLE_NAME + " AS ksuShiyoKaijo"
                        + " ON " + "ksuShiyoKaijo.NENDO  =  moshikomi.NENDO "
                        + " AND " + "ksuShiyoKaijo.SKN_KSU_CODE  =  moshikomi.SKN_KSU_CODE "
                        + " AND " + "ksuShiyoKaijo.SHUBETSU_CODE  =  moshikomi.SHUBETSU_CODE "
                        + " AND " + "ksuShiyoKaijo.KAISU_CODE  =  moshikomi.KAISU_CODE "
                        + " AND " + "ksuShiyoKaijo.KAIJO_SHIKEN_KBN  =  '0' "
                        + " AND " + "ksuShiyoKaijo.KAIJO_ID  =  moshikomi.KAIJO_ID1 "
                        + " AND " + "ksuShiyoKaijo.KAISAICHI_CODE  =  moshikomi.KAISAICHI_CODE1 "
                        + " AND " + "ksuShiyoKaijo.KAIJO_CODE  =  moshikomi.KAIJO_CODE1 ";
            }
            
            sql += " WHERE"
                    + " kessai.NENDO = ?"
                    + " AND kessai.UKETSUKE_NO = ?"
                    + " AND moshikomi.RONRI_SAKUJO_FLG = '0'"
                    + " AND torokusha.RONRI_SAKUJO_FLG = '0'";

            stmt = con.prepareStatement(sql);

            int i = 1;
            stmt.setString(i++, nendo);
            stmt.setString(i++, uketsukeNo);

            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();

            while (rs.next()) {
                // �����u�K����
                kessaiParamMap.put("SKN_KSU_NAME", rs.getString("SKN_KSU_NAME"));
                kessaiParamMap.put("SHIMEI", rs.getString("SHIMEI"));
                kessaiParamMap.put("UKETSUKE_NO", rs.getString("UKETSUKE_NO"));
                kessaiParamMap.put("SHIKEN_NAIYO", rs.getString("SHIKEN_NAIYO"));
                kessaiParamMap.put("KIBO_CHIKU", rs.getString("KIBO_CHIKU"));
                // ���Ϗ��
                kessaiParamMap.put("KESSAI_HOHO", rs.getString("KESSAI_HOHO"));
                kessaiParamMap.put("KESSAI_KINGAKU_TOTAL", rs.getString("KESSAI_KINGAKU_TOTAL"));
                // �R���r�j����
                kessaiParamMap.put("KESSAI_CONVENIENCE", rs.getString("KESSAI_CONVENIENCE"));
                kessaiParamMap.put("CONVENIENCE_HARAIKOMI_NO", rs.getString("CONVENIENCE_HARAIKOMI_NO"));
                // �y�C�W�[����
                kessaiParamMap.put("PAYEASY_SHUNO_KIKAN_NO", rs.getString("PAYEASY_SHUNO_KIKAN_NO"));
                kessaiParamMap.put("PAYEASY_OKYAKUSAMA_NO", rs.getString("PAYEASY_OKYAKUSAMA_NO"));
                kessaiParamMap.put("PAYEASY_KAKUNIN_NO", rs.getString("PAYEASY_KAKUNIN_NO"));
                kessaiParamMap.put("KESSAI_KIGEN_BI", rs.getString("KESSAI_KIGEN_BI"));
                kessaiParamMap.put("KOJIN_DANTAI_KBN", rs.getString("KOJIN_DANTAI_KBN"));
                if (BmaConstants.KSU_KBN.equals(sknksuKbn)) {
                    kessaiParamMap.put("KAIJO_NAME", rs.getString("KAIJO_NAME"));
                }
            }

        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return kessaiParamMap;

    }
}
