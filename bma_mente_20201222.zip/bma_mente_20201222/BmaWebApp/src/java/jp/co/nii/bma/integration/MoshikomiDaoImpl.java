package jp.co.nii.bma.integration;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import jp.co.nii.bma.business.domain.HoyuShikakuMstDao;
import jp.co.nii.bma.business.domain.KessaiDao;
import jp.co.nii.bma.business.domain.MeishoKanriDao;
import jp.co.nii.bma.business.domain.Moshikomi;
import jp.co.nii.bma.business.domain.MoshikomiDao;
import jp.co.nii.bma.business.domain.SknksuMstDao;
import jp.co.nii.bma.business.domain.TorokushaDao;
import jp.co.nii.bma.business.rto.MskJoho;
import jp.co.nii.bma.business.rto.MskKessaiJoho;
import jp.co.nii.bma.business.rto.RrkMskJoho;
import jp.co.nii.bma.business.service.common.BmaConstants;
import jp.co.nii.sew.common.LogGenerate;
import jp.co.nii.sew.integration.SQLStateSQLExceptionTranslater;

/**
 * �\�� DAO�����N���X
 *
 * @author DB�Ǘ��c�[��
 */
public class MoshikomiDaoImpl extends GeneratedMoshikomiDaoImpl implements MoshikomiDao {

    /**
     * �C���X�^���X�𐶐�����B
     *
     * @param datasource �f�[�^�\�[�X��
     */
    public MoshikomiDaoImpl(String datasource) {
        super(datasource);
    }

    /**
     * ��������B<br>
     * �����L�[�Ƃ��Ď�L�[���w�肷��B
     *
     * @param moshikomiId �\���h�c
     * @return ���������f�[�^�i���̃N���X�̃C���X�^���X�j<br>
     * �Y������f�[�^�����݂��Ȃ��ꍇ��null��Ԃ��B
     */
    @Override
    public Moshikomi findByMoshikomiId(String moshikomiId) {
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = "";
        Moshikomi bo = new Moshikomi();
        try {
            con = getConnection();
            sql = "SELECT " + FIELDS_DECRYPT
                    + " FROM " + getSchemaName() + "." + TABLE_NAME
                    + " WHERE"
                    + " MOSHIKOMISHA_ID = ?"
                    + " AND RONRI_SAKUJO_FLG = ?"
                    + " ORDER BY MOSHIKOMISHA_ID DESC"
                    + " LIMIT 1 ";

            stmt = con.prepareStatement(sql);
            int i = 1;
            stmt.setString(i++, moshikomiId);
            stmt.setString(i++, BmaConstants.FLG_OFF);

            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();
            if (rs.next()) {
                setBoFromResultSet(bo, rs);
            } else {
                bo = null;
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return bo;
    }

    /**
     * �c�̐\������ ����������B
     *
     * @param search
     * @return ���������f�[�^�i�c�̐\������ ���X�g�j<br>
     */
    @Override
    public List<RrkMskJoho> findListGroup(RrkMskJoho search) {
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = "";
        List<RrkMskJoho> moshikomiRreki = new ArrayList<>();

        List<String> param = new ArrayList<String>();
        try {
            con = getConnection();
            sql = "SELECT "
                    + "count(*) as CNT"
                    + ",max(mc.UKETSUKE_NO) AS UKETSUKE_NO"
                    + ",max(mc.NENDO) AS NENDO"
                    + "  , max(mc.UNYO_JOKYO_KBN) UNYO_JOKYO_KBN  "
                    + "  , max(sm.SKN_KSU_NAME) AS SKN_KSU_NAM "
                    + "  , max(mc.GOHI_JOKYO_KBN) AS GOHI_JOKYO_KBN "
                    + "  , max(mc.SHIKEN_NAIYO_KBN) AS SHIKEN_NAIYO_KBN "
                    + "  , max(mc.SKN_KSU_CODE) AS SKN_KSU_CODE "
                    + "  , mc.TOROKU_USER_ID AS TOROKU_USER_ID "
                    + "  , mc.KARI_UKETSUKE_BI AS KARI_UKETSUKE_BI"
                    + "  , mc.KARI_UKETSUKE_TIME AS KARI_UKETSUKE_TIME"
                    + "  , max(sm.SKN_KSU_KBN) AS SKN_KSU_KBN"
                    + "  , max(sm.SHUBETSU_CODE) AS SHUBETSU_CODE"
                    + "  , max(sm.KAISU_CODE) AS KAISU_CODE"
                    + "  , max(sm.SKN_KSU_NAME) AS SKN_KSU_NAM"
                    + "  , max(m_uny.HANYO_CODE) AS HANYO_CODE  "
                    + "  , max(m_goh.HANYO_CHI) AS GOUHINM  "
                    + "  , max(m_uny_hyo.HANYO_CODE) AS UNYOUNM "
                    + " FROM " + getSchemaName() + "." + MoshikomiDao.TABLE_NAME + " AS mc"
                    + " INNER JOIN " + getSchemaName() + "." + SknksuMstDao.TABLE_NAME + " AS sm"
                    + " ON " + "mc.SKN_KSU_CODE  =  sm.SKN_KSU_CODE "
                    + " AND " + "mc.SHUBETSU_CODE  =  sm.SHUBETSU_CODE "
                    + " AND " + "mc.KAISU_CODE  =  sm.KAISU_CODE "
                    + " LEFT JOIN " + getSchemaName() + "." + MeishoKanriDao.TABLE_NAME + " AS m_uny"
                    + " ON " + "mc.UNYO_JOKYO_KBN  =  m_uny.HANYO_CODE "
                    + " AND " + "m_uny.GROUP_CODE =  'UNYO_JOKYO_KBN' "
                    + " LEFT JOIN " + getSchemaName() + "." + MeishoKanriDao.TABLE_NAME + " AS m_goh"
                    + " ON " + "mc.GOHI_JOKYO_KBN  =  m_goh.HANYO_CODE "
                    + " AND " + "m_goh.GROUP_CODE =  'GOHI_JOKYO_KBN' "                    
                    + " LEFT JOIN " + getSchemaName() + "." + MeishoKanriDao.TABLE_NAME + " AS m_uny_hyo"
                    + " ON " + "m_uny.HANYO_CHI  =  m_uny_hyo.HANYO_CHI"
                    + " AND " + "m_uny_hyo.GROUP_CODE =  'UNYO_JOKYO_HYOJI_KBN' "
                    + " WHERE"
                    + " mc.TOROKU_USER_ID = ?"
                    + " AND mc.RONRI_SAKUJO_FLG = ?"
                    + " AND mc.kari_uketsuke_bi <>''"
                    + " AND mc.kari_uketsuke_time <>''"
                    + " GROUP BY  "
                    + "  mc.TOROKU_USER_ID"
                    + "  , mc.KARI_UKETSUKE_BI  "
                    + "  , mc.KARI_UKETSUKE_TIME"
                    + "  ,sm.skn_ksu_code"
                    + "  , sm.shubetsu_code  "
                    + "  ,sm.kaisu_code"
                    + " ORDER BY  "
                    + "  NENDO DESC ";

            stmt = con.prepareStatement(sql);

            param.add(search.getMoshikomishaId());
            param.add(BmaConstants.FLG_OFF);

            stmt = con.prepareStatement(sql);
            int i = 1;
            for (String pm : param) {
                stmt.setString(i++, pm);
            }
            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();

            while (rs.next()) {
                RrkMskJoho detail = new RrkMskJoho();
                detail.setNendo(rs.getString("NENDO"));
                detail.setCount(rs.getString("CNT"));
                detail.setTorokuUserId(rs.getString("TOROKU_USER_ID"));
                detail.setUketsukeNo(rs.getString("UKETSUKE_NO"));

                // �����u�K��敪	
                detail.setSknKsuKbn(rs.getString("SKN_KSU_KBN"));
                detail.setShubetsuCode(rs.getString("SHUBETSU_CODE"));
                detail.setKaisuCode(rs.getString("KAISU_CODE"));

                detail.setSknksuName(rs.getString("SKN_KSU_NAM"));

                detail.setSknKsuCode(rs.getString("SKN_KSU_CODE"));
                detail.setMoshikomiFinishBi(rs.getString("KARI_UKETSUKE_BI"));
                detail.setMoshikomiFinishTime(rs.getString("KARI_UKETSUKE_TIME"));

                detail.setUnyoJokyoKbn(rs.getString("UNYO_JOKYO_KBN"));

                detail.setHanyoCode(rs.getString("HANYO_CODE"));
                detail.setGohinm(rs.getString("GOUHINM"));
                detail.setUnyounm(rs.getString("UNYOUNM"));
                
                detail.setUnyouList(search.getUnyouList());
                moshikomiRreki.add(detail);
            }

        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return moshikomiRreki;

    }

    /**
     * �\���l���̃��X�g�𒊏o�B
     *
     * @param torokuUserId,kariUketsukeBi,kariUketsukeTime,kbn
     * @return ���������f�[�^�i�\���l�� ���X�g�j<br>
     */
    @Override
    public RrkMskJoho findByTorokuUserIdFinishBi(RrkMskJoho inRequest, String kariUketsukeBi, String kariUketsukeTime, String kbn) {
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = "";
        
        RrkMskJoho detail = new RrkMskJoho();
        String torokuUserId = inRequest.getMoshikomishaId();
        // �����u�K��R�[�h
        String sknKsuCode = inRequest.getSknKsuCode();
        // ��ʃR�[�h								
        String shubetsuCode = inRequest.getShubetsuCode();
        // �񐔃R�[�h								
        String kaisuCode = inRequest.getKaisuCode();
        try {
            con = getConnection();

            if (kbn.isEmpty()) {
                sql = "SELECT " + " count(NENDO) AS count "
                        + " FROM " + getSchemaName() + "." + MoshikomiDao.TABLE_NAME + " AS mc"
                        + " INNER JOIN " + getSchemaName() + "." + SknksuMstDao.TABLE_NAME + " AS sm"
                        + " ON " + "mc.SKN_KSU_CODE  =  sm.SKN_KSU_CODE "
                        + " AND " + "mc.SHUBETSU_CODE  =  sm.SHUBETSU_CODE "
                        + " AND " + "mc.KAISU_CODE  =  sm.KAISU_CODE "
                        + " WHERE "
                        + "  mc.TOROKU_USER_ID= ?"
                        + "  AND mc.KARI_UKETSUKE_BI = ?"
                        + "  AND mc.KARI_UKETSUKE_TIME= ?"
                        + "  AND mc.RONRI_SAKUJO_FLG = ?"
                        + "  AND sm.SKN_KSU_CODE = ?"
                        + "  AND sm.SHUBETSU_CODE = ?"
                        + "  AND sm.KAISU_CODE = ?";
                stmt = con.prepareStatement(sql);
                int i = 1;
                stmt.setString(i++, torokuUserId);
                stmt.setString(i++, kariUketsukeBi);
                stmt.setString(i++, kariUketsukeTime);
                stmt.setString(i++, BmaConstants.FLG_OFF);
                stmt.setString(i++, sknKsuCode);
                stmt.setString(i++, shubetsuCode);
                stmt.setString(i++, kaisuCode);
            }
            if (BmaConstants.MOSHIKOMI_JOKYO_KBN_FUBI.equals(kbn) || BmaConstants.MOSHIKOMI_JOKYO_KBN_MOSHIKOMI_KANRYO.equals(kbn)) {
                sql = "SELECT " + " count(NENDO) AS count "
                        + " FROM " + getSchemaName() + "." + MoshikomiDao.TABLE_NAME + " AS mc"
                        + " INNER JOIN " + getSchemaName() + "." + SknksuMstDao.TABLE_NAME + " AS sm"
                        + " ON " + "mc.SKN_KSU_CODE  =  sm.SKN_KSU_CODE "
                        + " AND " + "mc.SHUBETSU_CODE  =  sm.SHUBETSU_CODE "
                        + " AND " + "mc.KAISU_CODE  =  sm.KAISU_CODE "
                        + " WHERE "
                        + "  mc.TOROKU_USER_ID= ?"
                        + "  AND mc.KARI_UKETSUKE_BI = ?"
                        + "  AND mc.KARI_UKETSUKE_TIME= ?"
                        + "  AND mc.MOSHIKOMI_JOKYO_KBN= ?"
                        + "  AND mc.RONRI_SAKUJO_FLG = ?";
                stmt = con.prepareStatement(sql);
                int i = 1;
                stmt.setString(i++, torokuUserId);
                stmt.setString(i++, kariUketsukeBi);
                stmt.setString(i++, kariUketsukeTime);
                stmt.setString(i++, kbn);
                stmt.setString(i++, BmaConstants.FLG_OFF);
            } else if (BmaConstants.GOHI_JOKYO_KBN_GOKAKU.equals(kbn) || BmaConstants.GOHI_JOKYO_KBN_ICHIBU_JITSUGI.equals(kbn)
                    || BmaConstants.GOHI_JOKYO_KBN_ICHIBU_GAKKA.equals(kbn)) {

                sql = "SELECT " + " count(NENDO) AS count "
                        + " FROM " + getSchemaName() + "." + MoshikomiDao.TABLE_NAME + " AS mc"
                        + " INNER JOIN " + getSchemaName() + "." + SknksuMstDao.TABLE_NAME + " AS sm"
                        + " ON " + "mc.SKN_KSU_CODE  =  sm.SKN_KSU_CODE "
                        + " AND " + "mc.SHUBETSU_CODE  =  sm.SHUBETSU_CODE "
                        + " AND " + "mc.KAISU_CODE  =  sm.KAISU_CODE "
                        + " WHERE "
                        + "  mc.TOROKU_USER_ID= ?"
                        + "  AND mc.KARI_UKETSUKE_BI = ?"
                        + "  AND mc.KARI_UKETSUKE_TIME= ?"
                        + "  AND mc.GOHI_JOKYO_KBN= ?"
                        + "  AND mc.RONRI_SAKUJO_FLG = ?";
                stmt = con.prepareStatement(sql);
                int i = 1;
                stmt.setString(i++, torokuUserId);
                stmt.setString(i++, kariUketsukeBi);
                stmt.setString(i++, kariUketsukeTime);
                stmt.setString(i++, kbn);
                stmt.setString(i++, BmaConstants.FLG_OFF);
            }

            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();
            if (rs.next()) {
                detail.setCount(rs.getString("count"));
            }

        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return detail;
    }

    /**
     * ��t�ԍ��̃��X�g�𒊏o�B
     *
     * @param search
     * @return ���������f�[�^�i��t�ԍ� ���X�g�j<br>
     */
    @Override
    public List<String> SearchOutIndex(RrkMskJoho search) {

        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = "";

        List<String> param = new ArrayList<String>();
        List<String> ret = new ArrayList<String>();
        try {
            con = getConnection();
            sql = "SELECT "
                    + "UKETSUKE_NO AS OUT_INDEX"
                    + " FROM " + getSchemaName() + "." + TABLE_NAME
                    + " WHERE"
                    + " NENDO = ?"
                    + " AND RONRI_SAKUJO_FLG = ?";
            param.add(search.getNendo());
            param.add(BmaConstants.FLG_OFF);

            /* ORDER�� */
            sql += "ORDER BY UKETSUKE_NO DESC";

            stmt = con.prepareStatement(sql);
            int i = 1;
            for (String pm : param) {
                stmt.setString(i++, pm);
            }

            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();
            while (rs.next()) {
                ret.add(rs.getString("OUT_INDEX"));
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return ret;
    }

    /**
     * ��t�ԍ��̃��X�g�𒊏o�B
     *
     * @param search
     * @return ���������f�[�^�i��t�ԍ� ���X�g�j<br>
     */
    @Override
    public List<String> SearchOutIndexGroup(RrkMskJoho search) {

        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = "";

        List<String> param = new ArrayList<String>();
        List<String> ret = new ArrayList<String>();
        try {
            con = getConnection();
            sql = "SELECT "
                    + "mc.UKETSUKE_NO AS OUT_INDEX"
                    + " FROM " + getSchemaName() + "." + MoshikomiDao.TABLE_NAME + " AS mc"
                    + " INNER JOIN " + getSchemaName() + "." + SknksuMstDao.TABLE_NAME + " AS sm"
                    + " ON " + "mc.SKN_KSU_CODE  =  sm.SKN_KSU_CODE "
                    + " AND " + "mc.SHUBETSU_CODE  =  sm.SHUBETSU_CODE "
                    + " AND " + "mc.KAISU_CODE  =  sm.KAISU_CODE "
                    + " INNER JOIN " + getSchemaName() + "." + TorokushaDao.TABLE_NAME + " AS tou"
                    + " ON " + "mc.MOSHIKOMISHA_ID  =  tou.MOSHIKOMISHA_ID "
                    + " WHERE"
                    + " NENDO = ?"
                    + " AND mc.RONRI_SAKUJO_FLG = ?"
                    + " AND mc.toroku_user_id = ?"
                    + " AND mc.KARI_UKETSUKE_BI = ?"
                    + " AND mc.KARI_UKETSUKE_TIME = ?"
                    + " AND mc.SKN_KSU_CODE = ?"
                    + " AND mc.SHUBETSU_CODE = ?"
                    + " AND mc.KAISU_CODE = ?";
            param.add(search.getNendo());
            param.add(BmaConstants.FLG_OFF);
            param.add(search.getMoshikomishaId());
            param.add(search.getKariUketsukeBi());
            param.add(search.getKariUketsukeTime());
            param.add(search.getSknKsuCode());
            param.add(search.getShubetsuCode());
            param.add(search.getKaisuCode());

            /* ORDER�� */
            sql += "ORDER BY UKETSUKE_NO DESC";

            stmt = con.prepareStatement(sql);
            int i = 1;
            for (String pm : param) {
                stmt.setString(i++, pm);
            }

            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();
            while (rs.next()) {
                ret.add(rs.getString("OUT_INDEX"));
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return ret;
    }

    /**
     * ���X�g��������t�ԍ��̃f�[�^�𒊏o�B
     *
     * @param search
     * @return ���������f�[�^�i�\�� ���X�g�j<br>
     */
    @Override
    public List<RrkMskJoho> findListMoshikomiGroup(RrkMskJoho search) {

        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = "";
        List<RrkMskJoho> moshikomiRreki = new ArrayList<>();
        List<String> test = new ArrayList<>();
        test = search.getDispKeyList();
        List<String> param = new ArrayList<>();

        try {
            con = getConnection();
            sql = "SELECT "
                    + "mc.NENDO AS NENDO,"
                    + "mc.UKETSUKE_NO AS UKETSUKE_NO,"
                    + "mc.SHIKEN_NAIYO_KBN AS SHIKEN_NAIYO_KBN,"
                    + "mc.MOSHIKOMISHA_ID AS MOSHIKOMISHA_ID,"
                    + "mc.SKN_KSU_CODE AS SKN_KSU_CODE,"
                    + "mc.UNYO_JOKYO_KBN AS UNYO_JOKYO_KBN,"
                    + "mc.GOHI_JOKYO_KBN AS GOHI_JOKYO_KBN,"
                    + "mc.JUKEN_JUKO_NO AS JUKEN_JUKO_NO,"
                    + "mc.SHUBETSU_CODE AS SHUBETSU_CODE,"
                    + "mc.MOSHIKOMI_JOKYO_KBN AS MOSHIKOMI_JOKYO_KBN,"
                    + "sm.SKN_KSU_KBN AS SKN_KSU_KBN,"
                    + "sm.SHUBETSU_CODE AS SHUBETSU_CODE,"
                    + "sm.KAISU_CODE AS KAISU_CODE,"
                    + "sm.SKN_KSU_NAME AS SKN_KSU_NAM,"
                    + "convert_from(bma.decrypt( tou.SHIMEI , '\\x506a363457356672'::bytea, 'aes'::text), 'UTF8'::name) AS SHIMEI,"
                    + "convert_from(bma.decrypt( tou.FURIGANA , '\\x506a363457356672'::bytea, 'aes'::text), 'UTF8'::name) AS FURIGANA,"
                    + "m_mos.HANYO_CHI AS MOSHINM,"
                    + "m_goh.HANYO_CHI AS GOUHINM "
                    + " FROM " + getSchemaName() + "." + MoshikomiDao.TABLE_NAME + " AS mc"
                    + " INNER JOIN " + getSchemaName() + "." + SknksuMstDao.TABLE_NAME + " AS sm"
                    + " ON " + "mc.SKN_KSU_CODE  =  sm.SKN_KSU_CODE "
                    + " AND " + "mc.SHUBETSU_CODE  =  sm.SHUBETSU_CODE "
                    + " AND " + "mc.KAISU_CODE  =  sm.KAISU_CODE "
                    + " INNER JOIN " + getSchemaName() + "." + TorokushaDao.TABLE_NAME + " AS tou"
                    + " ON " + "mc.MOSHIKOMISHA_ID  =  tou.MOSHIKOMISHA_ID "
                    + " LEFT JOIN " + getSchemaName() + "." + MeishoKanriDao.TABLE_NAME + " AS m_mos"
                    + " ON " + "mc.MOSHIKOMI_JOKYO_KBN  =  m_mos.HANYO_CODE "
                    + " AND " + "m_mos.GROUP_CODE =  'MOSHIKOMI_JOKYO_KBN' "
                    + " LEFT JOIN " + getSchemaName() + "." + MeishoKanriDao.TABLE_NAME + " AS m_goh"
                    + " ON " + "mc.GOHI_JOKYO_KBN  =  m_goh.HANYO_CODE "
                    + " AND " + "m_goh.GROUP_CODE =  'GOHI_JOKYO_KBN' "
                    + " WHERE"
                    + " NENDO = ?"
                    + " AND mc.RONRI_SAKUJO_FLG = ?"
                    + " AND mc.toroku_user_id = ?"
                    + " AND mc.KARI_UKETSUKE_BI = ?"
                    + " AND mc.KARI_UKETSUKE_TIME = ?"
                    + " AND mc.SKN_KSU_CODE = ?"
                    + " AND mc.SHUBETSU_CODE = ?"
                    + " AND mc.KAISU_CODE = ?";
            param.add(search.getNendo());
            param.add(BmaConstants.FLG_OFF);
            param.add(search.getMoshikomishaId());
            param.add(search.getKariUketsukeBi());
            param.add(search.getKariUketsukeTime());
            param.add(search.getSknKsuCode());
            param.add(search.getShubetsuCode());
            param.add(search.getKaisuCode());

            /*���������ǉ�*/
            sql += " AND  UKETSUKE_NO IN (";
            boolean isFirst = true;

            for (String no : test) {
                if (!isFirst) {
                    sql += ",";
                } else {
                    isFirst = false;
                }
                sql += "?";
                param.add(no);
            }
            sql += ")";

            /* ORDER�� */
            sql += " ORDER BY mc.NENDO DESC, sm.SKN_KSU_KBN, mc.SKN_KSU_CODE, mc.SHUBETSU_CODE, sm.KAISU_CODE ASC ";

            /* ����������l���Z�b�g */
            stmt = con.prepareStatement(sql);
            int i = 1;
            for (String pm : param) {
                stmt.setString(i++, pm);
            }

            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();

            while (rs.next()) {
                RrkMskJoho detail = new RrkMskJoho();

                detail.setNendo(rs.getString("NENDO"));
                detail.setUketsukeNo(rs.getString("UKETSUKE_NO"));
                detail.setMoshikomishaId(rs.getString("MOSHIKOMISHA_ID"));

                detail.setShikenNaiyoKbn(rs.getString("SHIKEN_NAIYO_KBN"));
                // �����u�K��敪	
                detail.setSknKsuKbn(rs.getString("SKN_KSU_KBN"));
                detail.setShubetsuCode(rs.getString("SHUBETSU_CODE"));
                detail.setKaisuCode(rs.getString("KAISU_CODE"));

                detail.setSknksuName(rs.getString("SKN_KSU_NAM"));

                detail.setJukenJukoNo(rs.getString("JUKEN_JUKO_NO"));

                detail.setShimei(rs.getString("SHIMEI"));
                detail.setFurigana(rs.getString("FURIGANA"));
                detail.setSknKsuCode(rs.getString("SKN_KSU_CODE"));

                detail.setUnyoJokyoKbn(rs.getString("UNYO_JOKYO_KBN"));
                detail.setMoshikomiJokyoKbn(rs.getString("MOSHIKOMI_JOKYO_KBN"));
                detail.setGohiJokyoKbn(rs.getString("GOHI_JOKYO_KBN"));

                detail.setMoshinm(rs.getString("MOSHINM"));
                detail.setGohinm(rs.getString("GOUHINM"));

                moshikomiRreki.add(detail);
            }

        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return moshikomiRreki;
    }

    /**
     * �\������ ����������B
     *
     * @param search
     * @return ���������f�[�^�i�\������ ���X�g�j<br>
     */
    @Override
    public List<RrkMskJoho> findList(RrkMskJoho search) {
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = "";
        List<RrkMskJoho> moshikomiRreki = new ArrayList<>();

        List<String> param = new ArrayList<String>();
        try {
            con = getConnection();
            sql = "SELECT "
                    + "mc.NENDO AS NENDO,"
                    + "mc.UKETSUKE_NO AS UKETSUKE_NO,"
                    + "mc.SHIKEN_NAIYO_KBN AS SHIKEN_NAIYO_KBN,"
                    + "mc.MOSHIKOMISHA_ID AS MOSHIKOMISHA_ID,"
                    + "mc.SKN_KSU_CODE AS SKN_KSU_CODE,"
                    + "mc.UNYO_JOKYO_KBN AS UNYO_JOKYO_KBN,"
                    + "mc.GOHI_JOKYO_KBN AS GOHI_JOKYO_KBN,"
                    + "mc.JUKEN_JUKO_NO AS JUKEN_JUKO_NO,"
                    + "mc.SHUBETSU_CODE AS SHUBETSU_CODE,"
                    + "sm.SKN_KSU_KBN AS SKN_KSU_KBN,"
                    + "sm.SHUBETSU_CODE AS SHUBETSU_CODE,"
                    + "sm.KAISU_CODE AS KAISU_CODE,"
                    + "sm.SKN_KSU_NAME AS SKN_KSU_NAM,"
                    + "convert_from(bma.decrypt( tou.SHIMEI , '\\x506a363457356672'::bytea, 'aes'::text), 'UTF8'::name) AS SHIMEI,"
                    + "convert_from(bma.decrypt( tou.FURIGANA , '\\x506a363457356672'::bytea, 'aes'::text), 'UTF8'::name) AS FURIGANA,"
                    + "m_uny.HANYO_CHI AS UNYOUNM,"
                    + "m_goh.HANYO_CHI AS GOUHINM "
                    + " FROM " + getSchemaName() + "." + MoshikomiDao.TABLE_NAME + " AS mc"
                    + " INNER JOIN " + getSchemaName() + "." + SknksuMstDao.TABLE_NAME + " AS sm"
                    + " ON " + "mc.SKN_KSU_CODE  =  sm.SKN_KSU_CODE "
                    + " AND " + "mc.SHUBETSU_CODE  =  sm.SHUBETSU_CODE "
                    + " AND " + "mc.KAISU_CODE  =  sm.KAISU_CODE "
                    + " INNER JOIN " + getSchemaName() + "." + TorokushaDao.TABLE_NAME + " AS tou"
                    + " ON " + "mc.MOSHIKOMISHA_ID  =  tou.MOSHIKOMISHA_ID "
                    + " LEFT JOIN " + getSchemaName() + "." + KessaiDao.TABLE_NAME + " AS ks"
                    + " ON " + "mc.NENDO = ks.NENDO"
                    + " AND " + "mc.UKETSUKE_NO = ks.UKETSUKE_NO"
                    + " LEFT JOIN " + getSchemaName() + "." + MeishoKanriDao.TABLE_NAME + " AS m_uny"
                    + " ON " + "mc.UNYO_JOKYO_KBN  =  m_uny.HANYO_CODE "
                    + " AND " + "m_uny.GROUP_CODE =  'UNYO_JOKYO_KBN' "
                    + " LEFT JOIN " + getSchemaName() + "." + MeishoKanriDao.TABLE_NAME + " AS m_goh"
                    + " ON " + "mc.GOHI_JOKYO_KBN  =  m_goh.HANYO_CODE "
                    + " AND " + "m_goh.GROUP_CODE =  'GOHI_JOKYO_KBN' "
                    + " WHERE"
                    + " mc.MOSHIKOMISHA_ID = ?"
                    + " AND mc.RONRI_SAKUJO_FLG = ?"
                    + " ORDER BY mc.NENDO DESC, sm.SKN_KSU_KBN, mc.SKN_KSU_CODE, mc.SHUBETSU_CODE, sm.KAISU_CODE ASC ";

            param.add(search.getMoshikomishaId());
            param.add(BmaConstants.FLG_OFF);

            stmt = con.prepareStatement(sql);
            int i = 1;
            for (String pm : param) {
                stmt.setString(i++, pm);
            }

            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();

            while (rs.next()) {
                RrkMskJoho detail = new RrkMskJoho();

                detail.setNendo(rs.getString("NENDO"));
                detail.setUketsukeNo(rs.getString("UKETSUKE_NO"));
                detail.setMoshikomishaId(rs.getString("MOSHIKOMISHA_ID"));

                detail.setShikenNaiyoKbn(rs.getString("SHIKEN_NAIYO_KBN"));
                // �����u�K��敪	
                detail.setSknKsuKbn(rs.getString("SKN_KSU_KBN"));
                detail.setShubetsuCode(rs.getString("SHUBETSU_CODE"));
                detail.setKaisuCode(rs.getString("KAISU_CODE"));

                detail.setSknksuName(rs.getString("SKN_KSU_NAM"));

                detail.setJukenJukoNo(rs.getString("JUKEN_JUKO_NO"));

                detail.setShimei(rs.getString("SHIMEI"));
                detail.setSknKsuCode(rs.getString("SKN_KSU_CODE"));

                detail.setUnyoJokyoKbn(rs.getString("UNYO_JOKYO_KBN"));
                detail.setGohiJokyoKbn(rs.getString("GOHI_JOKYO_KBN"));

                detail.setUnyounm(rs.getString("UNYOUNM"));
                detail.setGohinm(rs.getString("GOUHINM"));

                moshikomiRreki.add(detail);
            }

        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return moshikomiRreki;
    }

    /**
     * ���ς��������Ă���ꍇ�Ɏ�t�ԍ����擾����<br>
     *
     * @param moshikomishaId �\����ID
     * @param nendo �N�x
     * @param sknksuCode �����u�K��R�[�h
     * @param shubetsuCode ��ʃR�[�h
     * @param kaisuCode �񐔃R�[�h
     * @return ���ϊ����F��t�ԍ��@�������Fnull<br>
     */
    public String findUketsukeNoEndKessai(String moshikomishaId, String nendo, String sknksuCode, String shubetsuCode, String kaisuCode) {
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = "";
        String uketsukeNo = "";
        try {
            con = getConnection();
            sql = "SELECT "
                    + " mc.UKETSUKE_NO AS UKETSUKE_NO"
                    + " FROM " + getSchemaName() + "." + MoshikomiDao.TABLE_NAME + " AS mc"
                    + " LEFT JOIN " + getSchemaName() + "." + KessaiDao.TABLE_NAME + " AS ks"
                    + " ON " + "mc.NENDO = ks.NENDO"
                    + " AND " + "mc.UKETSUKE_NO = ks.UKETSUKE_NO"
                    + " WHERE"
                    + " mc.MOSHIKOMISHA_ID = ?"
                    + " AND mc.NENDO = ?"
                    + " AND mc.SKN_KSU_CODE = ?"
                    + " AND mc.SHUBETSU_CODE = ?"
                    + " AND mc.KAISU_CODE = ?"
                    + " AND mc.RONRI_SAKUJO_FLG = ?"
                    + " AND ks.KESSAI_JOKYO_KBN = ?"
                    + " AND ks.RONRI_SAKUJO_FLG = ?"
                    + " ORDER BY mc.UKETSUKE_NO DESC"
                    + " LIMIT 1";

            stmt = con.prepareStatement(sql);
            int i = 1;
            stmt.setString(i++, moshikomishaId);
            stmt.setString(i++, nendo);
            stmt.setString(i++, sknksuCode);
            stmt.setString(i++, shubetsuCode);
            stmt.setString(i++, kaisuCode);
            stmt.setString(i++, BmaConstants.FLG_OFF);
            stmt.setString(i++, BmaConstants.KESSAI_JOKYO_KBN_FINISH);
            stmt.setString(i++, BmaConstants.FLG_OFF);

            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();
            if (rs.next()) {
                uketsukeNo = rs.getString("UKETSUKE_NO");
            } else {
                uketsukeNo = null;
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return uketsukeNo;
    }

    /**
     * �l�����擾����B(�c��_�\����񎎌��m�F��ʗp)<br>
     *
     * @param bean �\�����bean
     * @return �\�����bean<br>
     */
    @Override
    public MskKessaiJoho getNinzuSknKessai(MskKessaiJoho bean) {
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = "";
        try {
            con = getConnection();
            sql = "select "
                    + " TOROKU_USER_ID"
                    + " ,TOROKU_DATE"
                    + " ,TOROKU_TIME"
                    + " ,count(*) as ninzu"
                    + " ,sum(case when SHIKEN_NAIYO_KBN='01' and GENMEN_FLG='0'then 1 else 0 end) as gakaJitsugiGenmenNasi"
                    + " ,sum(case when SHIKEN_NAIYO_KBN='01' and GENMEN_FLG='1'then 1 else 0 end) as gakaJitsugiGenmen"
                    + " ,sum(case when SHIKEN_NAIYO_KBN='04' then 1 else 0 end) as gakaOnly"
                    + " ,sum(case when SHIKEN_NAIYO_KBN='05' and GENMEN_FLG='0'then 1 else 0 end) as jitsugiOnlyGenmenNasi"
                    + " ,sum(case when SHIKEN_NAIYO_KBN='05' and GENMEN_FLG='1'then 1 else 0 end) as jitsugiOnlyGenmen"
                    + " ,sum(case when SHIKEN_NAIYO_KBN='02' and GENMEN_FLG='0'then 1 else 0 end) as gakaMenjoGenmenNasi"
                    + " ,sum(case when SHIKEN_NAIYO_KBN='02' and GENMEN_FLG='1'then 1 else 0 end) as gakaMenjoGenmen"
                    + " ,sum(case when SHIKEN_NAIYO_KBN='03' then 1 else 0 end) as jitsugiMenjo"
                    + " from bma.MOSHIKOMI"
                    + " where TOROKU_USER_ID = ?"
                    + " and TOROKU_DATE = ?"
                    + " and TOROKU_TIME = ?"
                    + " and NENDO = ?"
                    + " and skn_ksu_code = ?"
                    + " and shubetsu_code = ?"
                    + " and kaisu_code = ?"
                    + " and RONRI_SAKUJO_FLG = ?"
                    + " GROUP BY TOROKU_DATE,TOROKU_TIME,TOROKU_USER_ID"
                    + " ORDER BY TOROKU_DATE DESC,TOROKU_TIME ASC"
                    + " LIMIT 1";

            stmt = con.prepareStatement(sql);
            int i = 1;
            stmt.setString(i++, bean.getTorokuUserId());
            stmt.setString(i++, bean.getTorokuDate());
            stmt.setString(i++, bean.getTorokuTime());
            stmt.setString(i++, bean.getNendo());
            stmt.setString(i++, bean.getSknKsuCode());
            stmt.setString(i++, bean.getShubetsuCode());
            stmt.setString(i++, bean.getKaisuCode());
            stmt.setString(i++, BmaConstants.FLG_OFF);

            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();
            if (rs.next()) {
                bean.setTorokuUserId(rs.getString("TOROKU_USER_ID"));
                bean.setTorokuDate(rs.getString("TOROKU_DATE"));
                bean.setTorokuTime(rs.getString("TOROKU_TIME"));
                bean.setNinzu(rs.getInt("ninzu"));
                bean.setGakaJitsugiGenmenNasiNinzu(rs.getInt("gakaJitsugiGenmenNasi"));
                bean.setGakaJitsugiGenmenNinzu(rs.getInt("gakaJitsugiGenmen"));
                bean.setGakaOnlyNinzu(rs.getInt("gakaOnly"));
                bean.setJitsugiOnlyGenmenNasiNinzu(rs.getInt("jitsugiOnlyGenmenNasi"));
                bean.setJitsugiOnlyGenmenNinzu(rs.getInt("jitsugiOnlyGenmen"));
                bean.setGakaMenjoGenmenNasiNinzu(rs.getInt("gakaMenjoGenmenNasi"));
                bean.setGakaMenjoGenmenNinzu(rs.getInt("gakaMenjoGenmen"));
                bean.setJitsugiMenjoNinzu(rs.getInt("jitsugiMenjo"));
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return bean;
    }

    /**
     * �l�����擾����B(�c��_�\�����u�K��m�F��ʗp)<br>
     *
     * @param bean �\�����bean
     * @return �\�����bean<br>
     */
    @Override
    public MskKessaiJoho getNinzuKsuKessai(MskKessaiJoho bean) {
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = "";
        try {
            con = getConnection();
            sql = "select "
                    + " msk.TOROKU_USER_ID"
                    + " ,msk.TOROKU_DATE"
                    + " ,msk.TOROKU_TIME"
                    + " ,count(*) AS ninzu"
                    + " ,count(*) - sum(case when hsk.muryo_zan_count > '0' then 1 else 0 end) AS moshikomisha"
                    + " ,sum(case when hsk.muryo_zan_count > '0' then 1 else 0 end) AS kyuseido"
                    + " FROM " + getSchemaName() + "." + MoshikomiDao.TABLE_NAME + " AS msk"
                    + " LEFT JOIN " + getSchemaName() + "." + HoyuShikakuMstDao.TABLE_NAME + " AS hsk"
                    + " ON hsk.MOSHIKOMISHA_ID = msk.MOSHIKOMISHA_ID"
                    + " where msk.TOROKU_USER_ID = ?"
                    + " and msk.TOROKU_DATE = ?"
                    + " and msk.TOROKU_TIME = ?"
                    + " and msk.NENDO = ?"
                    + " and msk.SKN_KSU_CODE = ?"
                    + " and msk.SHUBETSU_CODE = ?"
                    + " and msk.KAISU_CODE = ?"
                    + " and msk.RONRI_SAKUJO_FLG = ?"
                    + " GROUP BY msk.TOROKU_DATE, msk.TOROKU_TIME, msk.TOROKU_USER_ID"
                    + " ORDER BY msk.TOROKU_DATE DESC, msk.TOROKU_TIME ASC"
                    + " LIMIT 1";

            stmt = con.prepareStatement(sql);
            int i = 1;
            stmt.setString(i++, bean.getTorokuUserId());
            stmt.setString(i++, bean.getTorokuDate());
            stmt.setString(i++, bean.getTorokuTime());
            stmt.setString(i++, bean.getNendo());
            stmt.setString(i++, bean.getSknKsuCode());
            stmt.setString(i++, bean.getShubetsuCode());
            stmt.setString(i++, bean.getKaisuCode());
            stmt.setString(i++, BmaConstants.FLG_OFF);

            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();
            if (rs.next()) {
                bean.setTorokuUserId(rs.getString("TOROKU_USER_ID"));
                bean.setTorokuDate(rs.getString("TOROKU_DATE"));
                bean.setTorokuTime(rs.getString("TOROKU_TIME"));
                bean.setNinzu(rs.getInt("ninzu"));
                bean.setMoshikomishaNinzu(rs.getInt("moshikomisha"));
                bean.setKyuseidoNinzu(rs.getInt("kyuseido"));
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return bean;
    }

    /**
     * ��������B<br>
     * �����L�[�Ƃ��Ď�L�[���w�肷��B
     *
     * @param bo
     * @return ���������f�[�^�i���̃N���X�̃C���X�^���X�j<br>
     * �Y������f�[�^�����݂��Ȃ��ꍇ��null��Ԃ��B
     */
    @Override
    public Moshikomi findByTorokuDate(MskKessaiJoho bo) {
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = "";
        Moshikomi moshikomi = new Moshikomi();
        try {
            con = getConnection();
            sql = "SELECT " + FIELDS_DECRYPT
                    + " FROM " + getSchemaName() + "." + TABLE_NAME
                    + " WHERE"
                    + " TOROKU_USER_ID = ?"
                    + " AND TOROKU_DATE = ?"
                    + " AND TOROKU_TIME = ?"
                    + " AND RONRI_SAKUJO_FLG = ?"
                    + " ORDER BY UKETSUKE_NO ASC"
                    + " LIMIT 1 ";

            stmt = con.prepareStatement(sql);
            int i = 1;
            stmt.setString(i++, bo.getTorokuUserId());
            stmt.setString(i++, bo.getTorokuDate());
            stmt.setString(i++, bo.getTorokuTime());
            stmt.setString(i++, BmaConstants.FLG_OFF);

            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();
            if (rs.next()) {
                setBoFromResultSet(moshikomi, rs);
            } else {
                bo = null;
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return moshikomi;
    }

    /**
     * �\���l���̃��X�g�𒊏o�B
     *
     * @param torokuUserId,kariUketsukeBi,kariUketsukeTime,kbn
     * @return ���������f�[�^�i�\���l�� ���X�g�j<br>
     */
    @Override
    public RrkMskJoho findByTorokuUserIdFinishBiFugokaku(String torokuUserId, String kariUketsukeBi, String kariUketsukeTime, String kbn) {
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = "";
        RrkMskJoho detail = new RrkMskJoho();

        try {
            con = getConnection();

            sql = "SELECT " + " count(NENDO) AS count "
                    + " FROM " + getSchemaName() + "." + MoshikomiDao.TABLE_NAME + " AS mc"
                    + " INNER JOIN " + getSchemaName() + "." + SknksuMstDao.TABLE_NAME + " AS sm"
                    + " ON " + "mc.SKN_KSU_CODE  =  sm.SKN_KSU_CODE "
                    + " AND " + "mc.SHUBETSU_CODE  =  sm.SHUBETSU_CODE "
                    + " AND " + "mc.KAISU_CODE  =  sm.KAISU_CODE "
                    + " WHERE "
                    + "  mc.TOROKU_USER_ID= ?"
                    + "  AND mc.KARI_UKETSUKE_BI = ?"
                    + "  AND mc.KARI_UKETSUKE_TIME= ?"
                    + "  AND mc.GOHI_JOKYO_KBN= ?"
                    + "  AND mc.RONRI_SAKUJO_FLG = ?";
            stmt = con.prepareStatement(sql);
            int i = 1;
            stmt.setString(i++, torokuUserId);
            stmt.setString(i++, kariUketsukeBi);
            stmt.setString(i++, kariUketsukeTime);
            stmt.setString(i++, kbn);
            stmt.setString(i++, BmaConstants.FLG_OFF);

            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();
            if (rs.next()) {
                detail.setCount(rs.getString("count"));
            }

        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return detail;
    }

    /**
     * �o�^���[�U�[ID�����Ƃɒc�̐\�������������擾����B(�c�́E2�d�\���`�F�b�N�p)
     *
     * @param torokuUser �\���S���ҏ��
     * @return ������������
     */
    @Override
    public String getCountByTorokuUserId(Moshikomi torokuUser) {
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = "";
        String count = "0";

        try {
            con = getConnection();

            sql = "SELECT " + " count(NENDO) AS count "
                    + " FROM " + getSchemaName() + "." + MoshikomiDao.TABLE_NAME + " AS mc"
                    + " INNER JOIN " + getSchemaName() + "." + SknksuMstDao.TABLE_NAME + " AS sm"
                    + " ON " + "mc.SKN_KSU_CODE  =  sm.SKN_KSU_CODE "
                    + " AND " + "mc.SHUBETSU_CODE  =  sm.SHUBETSU_CODE "
                    + " AND " + "mc.KAISU_CODE  =  sm.KAISU_CODE "
                    + " WHERE "
                    + "  mc.TOROKU_USER_ID= ?"
                    + "  AND mc.NENDO = ?"
                    + "  AND mc.SKN_KSU_CODE = ?"
                    + "  AND mc.SHUBETSU_CODE= ?"
                    + "  AND mc.KAISU_CODE= ?"
                    + "  AND mc.KOJIN_DANTAI_KBN= ?"
                    + "  AND mc.RONRI_SAKUJO_FLG = ?";
            stmt = con.prepareStatement(sql);
            int i = 1;
            stmt.setString(i++, torokuUser.getTorokuUserId());
            stmt.setString(i++, torokuUser.getNendo());
            stmt.setString(i++, torokuUser.getSknKsuCode());
            stmt.setString(i++, torokuUser.getShubetsuCode());
            stmt.setString(i++, torokuUser.getKaisuCode());
            stmt.setString(i++, torokuUser.getKojinDantaiKbn());
            stmt.setString(i++, BmaConstants.FLG_OFF);

            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();
            if (rs.next()) {
                count = rs.getString("count");
            }

        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return count;
    }

    /**
     * �o�^���[�U�[ID�����Ƃɒc�̐\���������X�g���擾����B(�c�́E���ϊ֌W�o�^�X�V�p)
     *
     * @param moshikomiFirst �c�̃A�b�v���[�h1����
     * @return �ꊇ�A�b�v���[�h�����\���҃��X�g
     */
    @Override
    public List<Moshikomi> getMoshikomiByTorokuUserId(Moshikomi moshikomiFirst) {
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = "";
        Moshikomi result;
        List<Moshikomi> moshikomiList = new ArrayList<>();

        try {
            con = getConnection();

            sql = "SELECT " + FIELDS_DECRYPT
                    + " FROM " + getSchemaName() + "." + MoshikomiDao.TABLE_NAME + " AS mc"
                    + " WHERE "
                    + "  mc.TOROKU_USER_ID= ?"
                    + "  AND mc.TOROKU_DATE = ?"
                    + "  AND mc.TOROKU_TIME = ?"
                    + "  AND mc.NENDO = ?"
                    + "  AND mc.SKN_KSU_CODE = ?"
                    + "  AND mc.SHUBETSU_CODE= ?"
                    + "  AND mc.KAISU_CODE= ?"
                    + "  AND mc.KOJIN_DANTAI_KBN= ?"
                    + "  AND mc.RONRI_SAKUJO_FLG = ?";
            stmt = con.prepareStatement(sql);
            int i = 1;
            stmt.setString(i++, moshikomiFirst.getTorokuUserId());
            stmt.setString(i++, moshikomiFirst.getTorokuDate());
            stmt.setString(i++, moshikomiFirst.getTorokuTime());
            stmt.setString(i++, moshikomiFirst.getNendo());
            stmt.setString(i++, moshikomiFirst.getSknKsuCode());
            stmt.setString(i++, moshikomiFirst.getShubetsuCode());
            stmt.setString(i++, moshikomiFirst.getKaisuCode());
            stmt.setString(i++, moshikomiFirst.getKojinDantaiKbn());
            stmt.setString(i++, BmaConstants.FLG_OFF);

            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();
            while (rs.next()) {
                result = new Moshikomi();
                setBoFromResultSet(result, rs);
                moshikomiList.add(result);
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return moshikomiList;
    }

}
