package jp.co.nii.bma.business.service.moshikomi;

import java.util.List;
import java.util.Map;
import jp.co.nii.bma.business.domain.Gazo;
import jp.co.nii.bma.business.domain.HoyuShikakuMst;
import jp.co.nii.bma.business.domain.MSkkMnjKanri;
import jp.co.nii.bma.business.domain.Moshikomi;
import jp.co.nii.bma.business.domain.ShiyoKaijo;
import jp.co.nii.bma.business.domain.Shokureki;
import jp.co.nii.bma.business.domain.Torokusha;
import jp.co.nii.bma.business.rto.MskJoho;
import jp.co.nii.bma.business.service.common.BmaConstants;
import jp.co.nii.bma.business.service.common.BmaLogger;
import jp.co.nii.bma.business.service.common.BmaValidator;
import jp.co.nii.bma.utility.BmaUtility;
import jp.co.nii.sew.business.SystemTime;
import jp.co.nii.sew.business.service.AbstractService;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_NEXT;
import jp.co.nii.sew.presentation.Messages;
import jp.co.nii.sew.presentation.RequestTransferObject;
import jp.co.nii.sew.utility.PropertyUtility;
import org.apache.commons.beanutils.BeanUtils;

/**
 * <p>
 * �^�C�g��: �\��������</p>
 * <p>
 * ����: �\�������̓T�[�r�X</p>
 * <p>
 * ���쌠: Copyright (c) 2016</p>
 * <p>
 * ��Ж�: ���{���Y�Ɗ������</p>
 */
public class MskJohoInputGroupService extends AbstractService {

    /**
     * DB�ڑ��̃f�[�^�\�[�X
     */
    private static String DATA_SOURCE_NAME;
    /**
     * ���O
     */
    BmaLogger log = (BmaLogger) BmaLogger.getLogger(this.getClass().getName());
    /**
     * �Ɩ��R�[�h
     */
    private static final String BUSINESS_CODE = PropertyUtility.getProperty("business_code");
    /**
     * ���׃e�X�g���[�h
     */
    private static final String STRESS_MODE = PropertyUtility.getProperty(BUSINESS_CODE + "stress_mode");
    /**
     * �ꎞ�ۑ��p�t�H���[�h��
     */
    private static final String FWD_NM_SAVE = "save";
    /**
     * �o�^���^�[���l ����
     */
    private static final String REGISTER_RETURN_SUCCESS = "1";
    /**
     * �o�^���^�[���l ���s(��ꂪ����I�[�o�[)
     */
    private static final String REGISTER_RETURN_FAILURE_TEIIN = "2";
    /**
     * �o�^���^�[���l ���s(�G���[)
     */
    private static final String REGISTER_RETURN_FAILURE_ERROR = "9";
    /* �V�X�e���������擾 */
    SystemTime sysTime = new SystemTime();

    /**
     * �R���X�g���N�^
     */
    public MskJohoInputGroupService() {
        super();
        /* DB�ڑ����̃��[�U�[������ */
        DATA_SOURCE_NAME = BmaConstants.DS_REGISTRANT;
    }

    /**
     * �T�[�r�X�N���X�̎��s���\�b�h
     *
     * @param rto ���N�G�X�g��񂩂�擾����rto
     * @param rtoInSession �Z�b�V�������rto
     * @return foward��
     * @throws Exception ��O
     */
    @Override
    public String doService(RequestTransferObject rto, RequestTransferObject rtoInSession) throws Exception {

        MskJoho inRequest = (MskJoho) rto;
        MskJoho inSession = (MskJoho) rtoInSession;
        String processName = "";

        /*�G���[���b�Z�[�W������*/
        inSession.setErrors(new Messages());
        try {
            if (!BmaUtility.isNullOrEmpty(inSession.getGazoUpdNext())) {
                /*�{�^��������*/
                processName = "MskJohoInput";
                log.Start(processName);

                //�N�x
                inSession.setSknKsuCode(inRequest.getSknKsuCode());
                inSession.setShubetsuCode(inRequest.getShubetsuCode());
                inSession.setKaisuCode(inRequest.getKaisuCode());
                inSession.setSknKsuKbn(inRequest.getSknKsuKbn());
                inSession.setTorokuUserId(inRequest.getTorokuUserId());
                inSession.setTorokuDate(inRequest.getTorokuDate());
                inSession.setTorokuTime(inRequest.getTorokuTime());
                inSession.setNendo(inRequest.getNendo());
                //�\���m�F�����̏ꍇ
                if (BmaConstants.SKN_KBN.equals(inSession.getSknKsuKbn())) {
                    //�l�����擾
                    countNinzuSkn(inRequest, inSession);
                }

                //�\���m�F�u�K��̏ꍇ
                if (BmaConstants.KSU_KBN.equals(inSession.getSknKsuKbn())) {
                    //�l�����擾
                    countNinzuKsu(inRequest, inSession);
                }
                inSession.setGazoUpdNext("");
                return FWD_NM_SUCCESS;
            } else if (!BmaUtility.isNullOrEmpty(inRequest.getMskKakutei())) {
                /*�u���ρv�{�^��������*/
                processName = "";
                log.Start(processName);
                String let;

                // DB�o�^
                Moshikomi moshikomi = new Moshikomi(DATA_SOURCE_NAME);
                MSkkMnjKanri mSkkMnjKanri = new MSkkMnjKanri(DATA_SOURCE_NAME);
                Torokusha torokusha = new Torokusha(DATA_SOURCE_NAME);
                HoyuShikakuMst hoyuShikakuMst = new HoyuShikakuMst(DATA_SOURCE_NAME);
                Gazo gazo = new Gazo(DATA_SOURCE_NAME);
                Shokureki shokureki = new Shokureki(DATA_SOURCE_NAME);
                ShiyoKaijo shiyoKaijo = new ShiyoKaijo(DATA_SOURCE_NAME);
                ShiyoKaijo shiyoKaijoMoto = new ShiyoKaijo(DATA_SOURCE_NAME);

                List<Moshikomi> moshikomiListForInsert = inRequest.getMoshikomiListForInsert();
                List<MSkkMnjKanri> mSkkMnjKanriListForInsert = inRequest.getMSkkMnjKanriListForInsert();
                List<Torokusha> torokushaListForInsert = inRequest.getTorokushaListForInsert();
                List<Gazo> gazoListForInsert = inRequest.getGazoListForInsert();
                List<Shokureki> shokurekiListForInsert = inRequest.getShokurekiListForInsert();
                Map<String, HoyuShikakuMst> hoyuShikakuMstMapForUpdate = inRequest.getHoyuShikakuMstMapForUpdate();
                try {
                    /* �g�����U�N�V�����擾&�J�n */
                    getTransaction();
                    beginTransaction();

                    // ��{���o�^
                    if (BmaConstants.KSU_KBN.equals(inSession.getSknKsuKbn())) {
                        for (int i = 0; i < moshikomiListForInsert.size(); ++i) {
                            shiyoKaijo = new ShiyoKaijo(DATA_SOURCE_NAME);
                            shiyoKaijoMoto = new ShiyoKaijo(DATA_SOURCE_NAME);
                            // �\�����
                            BeanUtils.copyProperties(moshikomi, moshikomiListForInsert.get(i));
                            // �g�p��� ����]�`�F�b�N
                            shiyoKaijoMoto = shiyoKaijoMoto.findKaijo(inSession.getNendo(), inSession.getSknKsuCode(), inSession.getShubetsuCode(), inSession.getKaisuCode()
                                                                      , moshikomi.getKaijoId1(), "0");
                            if (Integer.parseInt(shiyoKaijoMoto.getGenzaiNinzu()) < Integer.parseInt(shiyoKaijoMoto.getTeiin())){
                                // ����]�œo�^
                                BeanUtils.copyProperties(shiyoKaijo, shiyoKaijoMoto);
                                CSVshiyokaijoUpd(shiyoKaijo, inSession);
                                shiyoKaijo.update();
                                // �\�����ɃZ�b�g
                                moshikomi.setKaijoId1(moshikomi.getKaijoId1());
                                moshikomi.setKaijoId2("");
                            } else {
                                shiyoKaijoMoto = new ShiyoKaijo(DATA_SOURCE_NAME);
                                // �g�p��� ����]�`�F�b�N
                                shiyoKaijoMoto = shiyoKaijoMoto.findKaijo(inSession.getNendo(), inSession.getSknKsuCode(), inSession.getShubetsuCode(), inSession.getKaisuCode()
                                                                          , moshikomi.getKaijoId2(), "0");
                                if (Integer.parseInt(shiyoKaijoMoto.getGenzaiNinzu()) < Integer.parseInt(shiyoKaijoMoto.getTeiin())) {
                                    // ����]�œo�^
                                    BeanUtils.copyProperties(shiyoKaijo, shiyoKaijoMoto);
                                    CSVshiyokaijoUpd(shiyoKaijo, inSession);
                                    shiyoKaijo.update();
                                    // �\�����ɃZ�b�g
                                    moshikomi.setKaijoId1(moshikomi.getKaijoId2());
                                    moshikomi.setKaijoId2("");
                                } else {
                                    // �����̏ꍇ
                                    // ���[���o�b�N
                                    rollbackTransaction();
                                    Messages errors = new Messages();
                                    BmaValidator.addMessage(errors, "shiyoKaijoCrowded", "�I����������]�Ƒ���]�̉��͖����ƂȂ��Ă���\��������܂��B���I����͉�ʂɖ߂��āA�I���������Ă��������B");
                                    inSession.setErrors(errors);
                                    /*�G���[���������ꍇ�͊m�F��ʍĕ\��*/
                                    return FWD_NM_RELOAD;
                                }
                            }
                            // �\������o�^����
                            moshikomi.create();
                            // �\�����i�Ə��Ǘ���o�^����
                            BeanUtils.copyProperties(mSkkMnjKanri, mSkkMnjKanriListForInsert.get(i));
                            mSkkMnjKanri.create();
                            // �o�^�҂�o�^����
                            BeanUtils.copyProperties(torokusha, torokushaListForInsert.get(i));
                            torokusha.create();
                            if ((BmaConstants.SKN_KSU_CODE_IP.equals(inSession.getSknKsuCode()) && BmaConstants.SHUBETSU_CODE_FOLLOW_UP.equals(inSession.getShubetsuCode()))
                                    || (BmaConstants.SKN_KSU_CODE_HC.equals(inSession.getSknKsuCode()) && BmaConstants.SHUBETSU_CODE_SAIKSU.equals(inSession.getShubetsuCode()))) {
                                // �ۗL���i�}�X�^�̐\����ID���X�V����
                                BeanUtils.copyProperties(hoyuShikakuMst, hoyuShikakuMstMapForUpdate.get(moshikomi.getMoshikomishaId()));
                                hoyuShikakuMst.updateWithMoshikomishaId(hoyuShikakuMst, moshikomi.getMoshikomishaId());
                            }
                        }
                    } else {
                        for (int i = 0; i < moshikomiListForInsert.size(); ++i) {
                            // �\������o�^����
                            BeanUtils.copyProperties(moshikomi, moshikomiListForInsert.get(i));
                            // �␳�˗��敪
                            gazo.setHoseiIraiKbn(BmaConstants.HOSEI_IRAI_KBN_1);
                            moshikomi.create();
                            // �\�����i�Ə��Ǘ���o�^����
                            BeanUtils.copyProperties(mSkkMnjKanri, mSkkMnjKanriListForInsert.get(i));
                            mSkkMnjKanri.create();
                            // �o�^�҂�o�^����
                            BeanUtils.copyProperties(torokusha, torokushaListForInsert.get(i));
                            torokusha.create();
                        }
                    }
                    // �摜��񂪂���ꍇ�A�o�^����
                    if (gazoListForInsert.size() > 0) {
                        for (int i = 0; i < gazoListForInsert.size(); ++i) {
                            // �摜��o�^����
                            BeanUtils.copyProperties(gazo, gazoListForInsert.get(i));
                            // �␳�˗��敪
                            gazo.setHoseiIraiKbn(BmaConstants.HOSEI_IRAI_KBN_1);
                            // �␳�˗����[�����M�t���O
                            gazo.setHoseiIraiMailSoshinFlg(BmaConstants.FLG_OFF);
                            gazo.create();
                        }
                    }
                    // �E����񂪂���ꍇ�A�o�^����
                    if (shokurekiListForInsert.size() > 0) {
                        for (int i = 0; i < shokurekiListForInsert.size(); ++i) {
                            // �E����o�^����
                            BeanUtils.copyProperties(shokureki, shokurekiListForInsert.get(i));
                            shokureki.create();
                        }
                    }
                    // �R�~�b�g
                    commitTransaction();
                } catch (Exception ex) {
                    ex.printStackTrace();
                    // ���[���o�b�N
                    rollbackTransaction();
                    return FWD_NM_EXCEPTION;
                }

                inSession.setKessaiSelectFlag("kessaiHoho");
                /*�G���[���������ꍇ�͌���������ʍĕ\��*/
                if (inSession.getSknKsuCode().equals(BmaConstants.SKN_KSU_CODE_IP) && inSession.getShubetsuCode().equals(BmaConstants.SHUBETSU_CODE_FOLLOW_UP)) {
                    // �\���ґS���������\�̏ꍇ�A���ϊ�����ʂ�
                    if (inRequest.getHoyuShikakuMstMuryo().size() == moshikomiListForInsert.size()) {
                        inSession.setMenjoCheck("allMenjo");
                        let = "menjo";
                    } else {
                        let = FWD_NM_NEXT;
                    }
                } else {
                    let = FWD_NM_NEXT;
                }
                return let;
            } else if (!BmaUtility.isNullOrEmpty(inRequest.getMskKakuninBack())) {
                /*�{�^��������*/
                processName = "";
                log.Start(processName);

                return FWD_NM_BACK;
            } else {
                /* �ُ�ȑJ�� */
                log.IllegalFWD();
                return FWD_NM_SESSION;
            }
        } catch (Exception ex) {
            throw ex;
        } finally {
            log.End(processName);
        }
    }

    /**
     * �g�p�����X�V����i���ݐl��+1�j
     *
     * @param bo
     * @param inSession
     */
    public void CSVshiyokaijoUpd(ShiyoKaijo bo, MskJoho inSession) throws Exception {
        int genzaiNinzu = Integer.parseInt(bo.getGenzaiNinzu());
        bo.setGenzaiNinzu(String.valueOf(genzaiNinzu+1));
        bo.setKoshinKbn("U");
        bo.setKoshinDate(inSession.getTorokuDate());
        bo.setKoshinTime(inSession.getTorokuTime());
        bo.setKoshinUserId(inSession.getMoshikomishaId());
        bo.setRonriSakujoFlg("0");
    }

    /**
     * ��ʕ\���p�Ɋe�l�����v�Z����B(����)
     *
     * @param inRequest ���N�G�X�g��̓��̓f�[�^
     * @param inSession �Z�b�V������̓��̓f�[�^
     */
    private void countNinzuSkn(MskJoho inRequest, MskJoho inSession) {
        int gakaJitsugiGenmenNasi = 0;
        int gakaJitsugiGenmen = 0;
        int gakaOnly = 0;
        int jitsugiOnlyGenmenNasi = 0;
        int jitsugiOnlyGenmen = 0;
        int gakaMenjoGenmenNasi = 0;
        int gakaMenjoGenmen = 0;
        int jitsugiMenjo = 0;
        int sumNinzu = 0;
        List<Moshikomi> moshikomiListForInsert = inRequest.getMoshikomiListForInsert();
        for (Moshikomi moshikomi : moshikomiListForInsert) {
            switch (moshikomi.getShikenNaiyoKbn()) {
                case BmaConstants.SKN_NAIYO_KBN_GAKKA_JITSUGI:
                    if (BmaConstants.FLG_ON.equals(moshikomi.getGenmenFlg())) {
                        ++gakaJitsugiGenmen;
                    } else {
                        ++gakaJitsugiGenmenNasi;
                    }
                    break;
                case BmaConstants.SKN_NAIYO_KBN_GAKKA_MENJO:
                    if (BmaConstants.FLG_ON.equals(moshikomi.getGenmenFlg())) {
                        ++gakaMenjoGenmen;
                    } else {
                        ++gakaMenjoGenmenNasi;
                    }
                    break;
                case BmaConstants.SKN_NAIYO_KBN_JITSUGI_MENJO:
                    ++jitsugiMenjo;
                    break;
                case BmaConstants.SKN_NAIYO_KBN_GAKKA_NOMI:
                    ++gakaOnly;
                    break;
                case BmaConstants.SKN_NAIYO_KBN_JITSUGI_NOMI:
                    if (BmaConstants.FLG_ON.equals(moshikomi.getGenmenFlg())) {
                        ++jitsugiOnlyGenmen;
                    } else {
                        ++jitsugiOnlyGenmenNasi;
                    }
                    break;
                default:
                    break;
            }
        }
        inSession.setGakaJitsugiGenmenNasiNinzu(gakaJitsugiGenmenNasi);
        inSession.setGakaJitsugiGenmenNinzu(gakaJitsugiGenmen);
        inSession.setGakaOnlyNinzu(gakaOnly);
        inSession.setJitsugiOnlyGenmenNasiNinzu(jitsugiOnlyGenmenNasi);
        inSession.setJitsugiOnlyGenmenNinzu(jitsugiOnlyGenmen);
        inSession.setGakaMenjoGenmenNasiNinzu(gakaMenjoGenmenNasi);
        inSession.setGakaMenjoGenmenNinzu(gakaMenjoGenmen);
        inSession.setJitsugiMenjoNinzu(jitsugiMenjo);
        sumNinzu = gakaJitsugiGenmenNasi + gakaJitsugiGenmen + gakaOnly + jitsugiOnlyGenmenNasi
                + jitsugiOnlyGenmen + gakaMenjoGenmenNasi + gakaMenjoGenmen + jitsugiMenjo;
        inSession.setNinzu(sumNinzu);
        inSession.setSumNinzu(sumNinzu);
    }

    /**
     * ��ʕ\���p�Ɋe�l�����v�Z����B(�u�K��)
     *
     * @param inRequest ���N�G�X�g��̓��̓f�[�^
     * @param inSession �Z�b�V������̓��̓f�[�^
     */
    private void countNinzuKsu(MskJoho inRequest, MskJoho inSession) {
        int moshikomisha = 0;
        int kyuseido = 0;
        int sumNinzu = 0;
        List<Moshikomi> moshikomiListForInsert = inRequest.getMoshikomiListForInsert();
        List<HoyuShikakuMst> hoyuShikakuMstMuryo = inRequest.getHoyuShikakuMstMuryo();
        
        if (BmaConstants.SKN_KSU_CODE_IP.equals(inSession.getSknKsuCode()) && BmaConstants.SHUBETSU_CODE_FOLLOW_UP.equals(inSession.getShubetsuCode())) {
            kyuseido = hoyuShikakuMstMuryo.size();
            moshikomisha = moshikomiListForInsert.size() - kyuseido;
        } else {
            moshikomisha = moshikomiListForInsert.size();
        }
        inSession.setMoshikomishaNinzu(moshikomisha);
        inSession.setKyuseidoNinzu(kyuseido);
        sumNinzu = moshikomisha + kyuseido;
        inSession.setNinzu(sumNinzu);
        inSession.setSumNinzu(sumNinzu);
    }

}
