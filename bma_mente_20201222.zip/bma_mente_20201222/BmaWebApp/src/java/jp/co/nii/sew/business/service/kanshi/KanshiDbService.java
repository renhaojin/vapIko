package jp.co.nii.sew.business.service.kanshi;

import jp.co.nii.sew.business.domain.kanshi.Kanshi;
import jp.co.nii.sew.business.service.AbstractService;
import jp.co.nii.sew.presentation.RequestTransferObject;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * �^�C�g��: Java�Ď�DB�`�F�b�N�A�N�V����
 * ����:
 * ���쌠: Copyright (c) 2016
 * ��Ж�: ���{���Y�Ɗ������
 *
 * @author
 */
public class KanshiDbService extends AbstractService {

    /*
     * DB�ڑ��̃f�[�^�\�[�X
     */
    private static String DATA_SOURCE_NAME;
    Log log = LogFactory.getLog(this.getClass());

    @Override
    public String doService(RequestTransferObject rto, RequestTransferObject rtoInSession) throws Exception {

        String actionFW = null;

        try {
            Kanshi kanshi = new Kanshi(DATA_SOURCE_NAME);
            if (kanshi.checkDb()) {
                //DB�ڑ�����
                actionFW = FWD_NM_SUCCESS;
            } else {
                //DB�ڑ����s
                actionFW = FWD_NM_EXCEPTION;
            }

        } catch (Exception ex) {
            actionFW = FWD_NM_EXCEPTION;
        }

        return actionFW;
    }
}