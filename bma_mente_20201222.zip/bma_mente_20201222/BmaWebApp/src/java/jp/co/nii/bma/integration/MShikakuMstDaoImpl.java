package jp.co.nii.bma.integration;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import static jp.co.nii.bma.business.domain.GeneratedHoyuShikakuMstDao.TABLE_NAME;
import jp.co.nii.bma.business.domain.HoyuShikakuMstDao;
import jp.co.nii.bma.business.domain.MShikakuMstDao;
import jp.co.nii.bma.business.domain.MoshikomiDao;
import jp.co.nii.bma.business.domain.SknksuMstDao;
import jp.co.nii.bma.business.domain.TorokushaDao;
import jp.co.nii.bma.business.rto.MskSikakuJoho;
import jp.co.nii.bma.business.rto.RrkMskJoho;
import jp.co.nii.bma.business.service.common.BmaConstants;
import static jp.co.nii.bma.integration.GeneratedHoyuShikakuMstDaoImpl.FIELDS_DECRYPT;
import jp.co.nii.sew.common.LogGenerate;
import static jp.co.nii.sew.integration.AbstractDao.getSchemaName;
import jp.co.nii.sew.integration.SQLStateSQLExceptionTranslater;
import jp.co.nii.sew.utility.DateUtility;

/**
 * �\�����i�}�X�^ DAO�����N���X
 * @author DB�Ǘ��c�[��
 */
public class MShikakuMstDaoImpl extends GeneratedMShikakuMstDaoImpl implements MShikakuMstDao {

    /**
     * �C���X�^���X�𐶐�����B
     * @param datasource �f�[�^�\�[�X��
     */
    public MShikakuMstDaoImpl(String datasource) {
        super(datasource);
    }
    
    /**
     * ���i�o���N������������B<br>
     * @param bean ���i���Z�b�V����
     * @return ���i�o���N�����X�g<br>
     */
    @Override
    public List<String> getSskKeikenNenList(MskSikakuJoho bean){
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = "";
        List<String> list = new ArrayList<String>();
        try {
            con = getConnection();
            sql = "SELECT " + FIELDS_DECRYPT
                    + " FROM " + getSchemaName() + "." + TABLE_NAME
                    + " WHERE"
                    + " SKN_KSU_CODE = ?"
                    + " AND SHUBETSU_CODE = ?"
                    + " AND KAISU_CODE = ?"
                    + " AND SHIKAKU_CODE = ?"
                    + " AND RONRI_SAKUJO_FLG = ?";

            stmt = con.prepareStatement(sql);
            int i = 1;
            stmt.setString(i++, bean.getSknKsuCode());
            stmt.setString(i++, bean.getShubetsuCode());
            stmt.setString(i++, bean.getKaisuCode());
            stmt.setString(i++, bean.getShikakuCode());
            stmt.setString(i++, BmaConstants.FLG_OFF);

            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();
            if (rs.next()) {
                try {
                    list.add(rs.getString("SSK_KEIKEN_NEN1"));
                    list.add(rs.getString("SSK_KEIKEN_NEN2"));
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return list;
    }
}
