package jp.co.nii.bma.business.rto;

import java.util.ArrayList;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import static jp.co.nii.bma.business.rto.MskSknJoho.dateToWeek;
import jp.co.nii.sew.presentation.AbstractRequestTransferObject;
import jp.co.nii.sew.presentation.Messages;

/**
 * �^�C�g��: TOP��� ����: TOP���RTO ���쌠: Copyright (c) 2020 ��Ж�: ���{���Y�Ɗ������
 */
public class MskKsuJoho extends AbstractRequestTransferObject {

    private Messages errors;
    private String kaisaichi;
    private String count;

    MskKsuJoho(String kaisaichi, String kaijoName) {
        this.kaisaichi = kaisaichi;
        this.kaijoName = kaijoName;
    }
    private String nendo;
    private String kaisaichiCode;
    private String date_From;
    private String date_To;
    private String date_From_Dsp;
    private String date_To_Dsp;
    private String kaijoCode;
    private String kaijoId;
    private String kaijoId1st;
    private String kaijoId2nd;
    private String kaijoName;
    private String kaijoJusho;
    private String kuusekiSuu;
    private String daiichiKibo;
    private String dainiKibo;
    private String kaijosentakuBack;
    private String kaijoSentakuNext;

    private String ksuShubetsu;
    private String mskKikan;
    private String jukenryo;
    private String mosikomi;
    private String close;

    private String ksuMsk;

    private List<MskKsuJoho> ensMskJohoList;
    private List<MskKsuJoho> kaiMskJohoList;
    private List<MskKsuJoho> kiboKaijoList;

    private String ksuShuKsu;
    private String nextDoi;

    /**
     * �\���҂h�c
     */
    private String moshikomishaId;
    /**
     * �����u�K��R�[�h
     */
    private String sknKsuCode;
    /**
     * ��ʃR�[�h
     */
    private String shubetsuCode;
    /**
     * �񐔃R�[�h
     */
    private String kaisuCode;
    /**
     * �����u�K��敪
     */
    private String sknKsuKbn;
    /**
     * �����u�K�
     */
    private String sknKsuName;
    /**
     * ��ʖ�
     */
    private String shubetsuName;
    /**
     * �񐔖�
     */
    private String kaisuName;
    private String kaijoshikenkbn;

    /**
     * �t���K�i
     */
    private String furigana;
    /**
     * ���N����
     */
    private String birthday;

    public MskKsuJoho() {
        clearInfo();
    }

    private void clearInfo() {
        setErrors(new Messages());
        setMoshikomishaId("");
        setSknKsuCode("");
        setShubetsuCode("");
        setKaisuCode("");
        setSknKsuKbn("");
        setSknKsuName("");
        setShubetsuName("");
        setKaisuName("");
        setKaijoshikenkbn("");
        setFurigana("");
        setBirthday("");
        setKaisaichi("");
        setKaijoName("");
        setKuusekiSuu("");
        setDaiichiKibo("");

        setDainiKibo("");
        setKaijosentakuBack("");
        setKaijoSentakuNext("");

        setKsuShubetsu("");
        setMskKikan("");
        setJukenryo("");
        setMosikomi("");
        setClose("");
        setKsuMsk("");
        setKsuShuKsu("");
        setKaisaichiCode("");
        setDate_From("");
        setDate_To("");
        setKaijoCode("");
        setNendo("");
        setKaijoId1st("");
        setKaijoId2nd("");
        setKaijoId("");
        setEnsMskJohoList(new ArrayList<MskKsuJoho>());
        setKaiMskJohoList(new ArrayList<MskKsuJoho>());
        setKiboKaijoList(new ArrayList<MskKsuJoho>());
    }

    /**
     * @return the errors
     */
    public Messages getErrors() {
        return errors;
    }

    /**
     * @param errors the errors to set
     */
    public void setErrors(Messages errors) {
        this.errors = errors;
    }

    @Override
    public void copyFromRequest(HttpServletRequest request) {
        setKaisaichi((String) request.getAttribute("kaisaichi"));
        setKaijoName((String) request.getAttribute("chkKiyakuDoi"));
        setKuusekiSuu((String) request.getAttribute("kuusekiSuu"));
        setDaiichiKibo((String) request.getAttribute("daiichiKibo"));
        setKaisaichiCode((String) request.getAttribute("kaisaichiCode"));
        setDate_From((String) request.getAttribute("date_From"));
        setDate_To((String) request.getAttribute("date_To"));
        setKaijoCode((String) request.getAttribute("kaijoCode"));
        setDainiKibo((String) request.getAttribute("dainiKibo"));
        setKaijosentakuBack((String) request.getAttribute("kaijosentakuBack"));
        setKaijoSentakuNext((String) request.getAttribute("kaijoSentakuNext"));
        setNendo((String) request.getAttribute("nendo"));
        setKsuShubetsu((String) request.getAttribute("ksuShubetsu"));
        setMskKikan((String) request.getAttribute("mskKikan"));
        setJukenryo((String) request.getAttribute("jukenryo"));
        setMosikomi((String) request.getAttribute("mosikomi"));
        setClose((String) request.getAttribute("close"));
        setKsuMsk((String) request.getAttribute("ksuMsk"));
        setKsuShuKsu((String) request.getAttribute("ksuShuKsu"));
        setNextDoi((String) request.getAttribute("nextDoi"));

        setMoshikomishaId((String) request.getAttribute("moshikomishaId"));
        setSknKsuCode((String) request.getAttribute("sknKsuCode"));
        setShubetsuCode((String) request.getAttribute("shubetsuCode"));
        setKaisuCode((String) request.getAttribute("kaisuCode"));
        setSknKsuKbn((String) request.getAttribute("sknKsuKbn"));
        setSknKsuName((String) request.getAttribute("sknKsuName"));
        setShubetsuName((String) request.getAttribute("shubetsuName"));
        setKaisuName((String) request.getAttribute("kaisuName"));
        setKaijoshikenkbn((String) request.getAttribute("kaijoshikenkbn"));
        setFurigana((String) request.getAttribute("furigana"));
        setBirthday((String) request.getAttribute("birthday"));
        setKaijoId1st((String) request.getAttribute("kaijoId1st"));
        setKaijoId2nd((String) request.getAttribute("kaijoId2nd"));
        setKaijoId((String) request.getAttribute("kaijoId"));
        HttpSession session = request.getSession(false);
        if (session.getAttribute("MskSknJoho") != null) {
            MskSknJoho temp = (MskSknJoho) session.getAttribute("MskSknJoho");
            setSknKsuCode(temp.getSknKsuCode());
            setShubetsuCode(temp.getShubetsuCode());
            setKaisuCode(temp.getKaisuCode());
            setKaijoshikenkbn("1");
            setNendo(temp.getNendo());
        }

    }

    public void setKaisaichi(String kaisaichi) {
        this.kaisaichi = kaisaichi;
    }

    public void setKaijoName(String kaijoName) {
        this.kaijoName = kaijoName;
    }

    public void setKuusekiSuu(String kuusekiSuu) {
        this.kuusekiSuu = kuusekiSuu;
    }

    public void setDaiichiKibo(String daiichiKibo) {
        this.daiichiKibo = daiichiKibo;
    }

    public void setDainiKibo(String dainiKibo) {
        this.dainiKibo = dainiKibo;
    }

    public void setKaijosentakuBack(String kaijosentakuBack) {
        this.kaijosentakuBack = kaijosentakuBack;
    }

    public void setKaijoSentakuNext(String kaijoSentakuNext) {
        this.kaijoSentakuNext = kaijoSentakuNext;
    }

    public String getKaisaichi() {
        return kaisaichi;
    }

    public String getKaijoName() {
        return kaijoName;
    }

    public String getKuusekiSuu() {
        return kuusekiSuu;
    }

    public String getDaiichiKibo() {
        return daiichiKibo;
    }

    public String getDainiKibo() {
        return dainiKibo;
    }

    public String getKaijosentakuBack() {
        return kaijosentakuBack;
    }

    public String getKaijoSentakuNext() {
        return kaijoSentakuNext;
    }

    public List<MskKsuJoho> getKaiMskJohoList() {
        return kaiMskJohoList;
    }

    public void setKaiMskJohoList(List<MskKsuJoho> kaiMskJohoList) {
        this.kaiMskJohoList = kaiMskJohoList;
    }

    public void setEnsMskJohoList(List<MskKsuJoho> ensMskJohoList) {
        this.ensMskJohoList = ensMskJohoList;
    }

    public List<MskKsuJoho> getEnsMskJohoList() {
        return ensMskJohoList;
    }

    public void setKsuShubetsu(String ksuShubetsu) {
        this.ksuShubetsu = ksuShubetsu;
    }

    public void setMskKikan(String mskKikan) {
        this.mskKikan = mskKikan;
    }

    public void setJukenryo(String jukenryo) {
        this.jukenryo = jukenryo;
    }

    public void setMosikomi(String mosikomi) {
        this.mosikomi = mosikomi;
    }

    public void setClose(String close) {
        this.close = close;
    }

    public String getKsuShubetsu() {
        return ksuShubetsu;
    }

    public String getMskKikan() {
        return mskKikan;
    }

    public String getJukenryo() {
        return jukenryo;
    }

    public String getMosikomi() {
        return mosikomi;
    }

    public String getClose() {
        return close;
    }

    public String getKsuMsk() {
        return ksuMsk;
    }

    public void setKsuMsk(String ksuMsk) {
        this.ksuMsk = ksuMsk;
    }

    public String getKaijoJusho() {
        return kaijoJusho;
    }

    public void setKaijoJusho(String kaijoJusho) {
        this.kaijoJusho = kaijoJusho;
    }

    public String getKsuShuKsu() {
        return ksuShuKsu;
    }

    public void setKsuShuKsu(String ksuShuKsu) {
        this.ksuShuKsu = ksuShuKsu;
    }

    /**
     * @return the nextDoi
     */
    public String getNextDoi() {
        return nextDoi;
    }

    /**
     * @param nextDoi the nextDoi to set
     */
    public void setNextDoi(String nextDoi) {
        this.nextDoi = nextDoi;
    }

    /**
     * @return the moshikomishaId
     */
    public String getMoshikomishaId() {
        return moshikomishaId;
    }

    /**
     * @param moshikomishaId the moshikomishaId to set
     */
    public void setMoshikomishaId(String moshikomishaId) {
        this.moshikomishaId = moshikomishaId;
    }

    /**
     * @return the sknKsuCode
     */
    public String getSknKsuCode() {
        return sknKsuCode;
    }

    /**
     * @param sknKsuCode the sknKsuCode to set
     */
    public void setSknKsuCode(String sknKsuCode) {
        this.sknKsuCode = sknKsuCode;
    }

    /**
     * @return the shubetsuCode
     */
    public String getShubetsuCode() {
        return shubetsuCode;
    }

    /**
     * @param shubetsuCode the shubetsuCode to set
     */
    public void setShubetsuCode(String shubetsuCode) {
        this.shubetsuCode = shubetsuCode;
    }

    /**
     * @return the kaisuCode
     */
    public String getKaisuCode() {
        return kaisuCode;
    }

    /**
     * @param kaisuCode the kaisuCode to set
     */
    public void setKaisuCode(String kaisuCode) {
        this.kaisuCode = kaisuCode;
    }

    /**
     * @return the sknKsuKbn
     */
    public String getSknKsuKbn() {
        return sknKsuKbn;
    }

    /**
     * @param sknKsuKbn the sknKsuKbn to set
     */
    public void setSknKsuKbn(String sknKsuKbn) {
        this.sknKsuKbn = sknKsuKbn;
    }

    /**
     * @return the sknKsuName
     */
    public String getSknKsuName() {
        return sknKsuName;
    }

    /**
     * @param sknKsuName the sknKsuName to set
     */
    public void setSknKsuName(String sknKsuName) {
        this.sknKsuName = sknKsuName;
    }

    /**
     * @return the shubetsuName
     */
    public String getShubetsuName() {
        return shubetsuName;
    }

    /**
     * @param shubetsuName the shubetsuName to set
     */
    public void setShubetsuName(String shubetsuName) {
        this.shubetsuName = shubetsuName;
    }

    /**
     * @return the kaisuName
     */
    public String getKaisuName() {
        return kaisuName;
    }

    /**
     * @param kaisuName the kaisuName to set
     */
    public void setKaisuName(String kaisuName) {
        this.kaisuName = kaisuName;
    }

    /**
     * @return the kaijoshikenkbn
     */
    public String getKaijoshikenkbn() {
        return kaijoshikenkbn;
    }

    /**
     * @param kaijoshikenkbn the kaijoshikenkbn to set
     */
    public void setKaijoshikenkbn(String kaijoshikenkbn) {
        this.kaijoshikenkbn = kaijoshikenkbn;
    }

    public String getFurigana() {
        return furigana;
    }

    public void setFurigana(String furigana) {
        this.furigana = furigana;
    }

    public String getBirthday() {
        return birthday;
    }

    public void setBirthday(String birthday) {
        this.birthday = birthday;
    }

    /**
     * @return the kaisaichiCode
     */
    public String getKaisaichiCode() {
        return kaisaichiCode;
    }

    /**
     * @param kaisaichiCode the kaisaichiCode to set
     */
    public void setKaisaichiCode(String kaisaichiCode) {
        this.kaisaichiCode = kaisaichiCode;
    }

    /**
     * @return the date_From
     */
    public String getDate_From() {
        return date_From;
    }

    /**
     * @param date_From the date_From to set
     */
    public void setDate_From(String date_From) {
        this.date_From = date_From;
    }

    /**
     * @return the date_To
     */
    public String getDate_To() {
        return date_To;
    }

    /**
     * @param date_To the date_To to set
     */
    public void setDate_To(String date_To) {
        this.date_To = date_To;
    }

    /**
     * @return the kaijoCode
     */
    public String getKaijoCode() {
        return kaijoCode;
    }

    /**
     * @param kaijoCode the kaijoCode to set
     */
    public void setKaijoCode(String kaijoCode) {
        this.kaijoCode = kaijoCode;
    }

    /**
     * @return the count
     */
    public String getCount() {
        return count;
    }

    /**
     * @param count the count to set
     */
    public void setCount(String count) {
        this.count = count;
    }

    /**
     * @return the kiboKaijoList
     */
    public List<MskKsuJoho> getKiboKaijoList() {
        return kiboKaijoList;
    }

    /**
     * @param kiboKaijoList the kiboKaijoList to set
     */
    public void setKiboKaijoList(List<MskKsuJoho> kiboKaijoList) {
        this.kiboKaijoList = kiboKaijoList;
    }

    /**
     * @return the date_From_Dsp
     */
    public String getDate_From_Dsp() {
        if(date_From.length() == 8){
            return date_From.substring(0,4)+"�N"+date_From.substring(4,6)+"��"+date_From.substring(6)+"��"+"("+dateToWeek(date_From)+")";
        }
        return "";
    }

    /**
     * @param date_From_Dsp the date_From_Dsp to set
     */
    public void setDate_From_Dsp(String date_From_Dsp) {
        this.date_From_Dsp = date_From_Dsp;
    }

    /**
     * @return the date_To_Dsp
     */
    public String getDate_To_Dsp() {
        if(date_To.length() == 8){
            return date_To.substring(0,4)+"�N"+date_To.substring(4,6)+"��"+date_To.substring(6)+"��"+"("+dateToWeek(date_To)+")";
        }
        return "";
    }

    /**
     * @param date_To_Dsp the date_To_Dsp to set
     */
    public void setDate_To_Dsp(String date_To_Dsp) {
        this.date_To_Dsp = date_To_Dsp;
    }

    /**
     * @return the nendo
     */
    public String getNendo() {
        return nendo;
    }

    /**
     * @param nendo the nendo to set
     */
    public void setNendo(String nendo) {
        this.nendo = nendo;
    }

    /**
     * @return the kaijoId1st
     */
    public String getKaijoId1st() {
        return kaijoId1st;
    }

    /**
     * @param kaijoId1st the kaijoId1st to set
     */
    public void setKaijoId1st(String kaijoId1st) {
        this.kaijoId1st = kaijoId1st;
    }

    /**
     * @return the kaijoId2nd
     */
    public String getKaijoId2nd() {
        return kaijoId2nd;
    }

    /**
     * @param kaijoId2nd the kaijoId2nd to set
     */
    public void setKaijoId2nd(String kaijoId2nd) {
        this.kaijoId2nd = kaijoId2nd;
    }

    /**
     * @return the kaijoId
     */
    public String getKaijoId() {
        return kaijoId;
    }

    /**
     * @param kaijoId the kaijoId to set
     */
    public void setKaijoId(String kaijoId) {
        this.kaijoId = kaijoId;
    }

}
