package jp.co.nii.bma.integration;

import jp.co.nii.bma.business.domain.ShiyoKaijoDao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import jp.co.nii.bma.business.domain.MeishoKanriDao;
import jp.co.nii.bma.business.domain.ShiyoKaijo;
import jp.co.nii.bma.business.rto.MskKsuJoho;
import jp.co.nii.bma.business.service.common.BmaConstants;
import jp.co.nii.sew.common.LogGenerate;
import static jp.co.nii.sew.integration.AbstractDao.getSchemaName;
import jp.co.nii.sew.integration.SQLStateSQLExceptionTranslater;
import jp.co.nii.sew.presentation.Option;

/**
 * �g�p��� DAO�����N���X
 *
 * @author DB�Ǘ��c�[��
 */
public class ShiyoKaijoDaoImpl extends GeneratedShiyoKaijoDaoImpl implements ShiyoKaijoDao {

    /**
     * �C���X�^���X�𐶐�����B
     *
     * @param datasource �f�[�^�\�[�X��
     */
    public ShiyoKaijoDaoImpl(String datasource) {
        super(datasource);
    }

    /**
     * �����u�K��̏����擾����B
     *
     * @return ���I����񃊃X�g
     */
    @Override
    public List<MskKsuJoho> searchKaijoList(ShiyoKaijo bo) {
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = "";
        List<String> param = new ArrayList<>();
        List<MskKsuJoho> kaijoList = new ArrayList<>();
        try {
            con = getConnection();
            sql = "SELECT K1.NENDO,K1.SKN_KSU_CODE,K1.KAISAICHI_CODE,K1.SHUBETSU_CODE,K1.KAISU_CODE,"
                    + " K1.KAIJO_SHIKEN_KBN,M1.HANYO_CHI AS KAISAICHI,K1.NITTEI_FROM,K1.NITTEI_TO,"
                    + " K1.KAIJO_CODE,K1.KAIJO_ID,K1.KAIJO_NAME_RYAKU AS KAIJO_NAME,K1.JUSHO,"
                    + " TO_NUMBER(K1.TEIIN,'9999999999')-TO_NUMBER(K1.GENZAI_NINZU,'9999999999') AS KUSEKI"
                    + " FROM BMA.SHIYO_KAIJO AS K1"
                    + " LEFT JOIN BMA.MEISHO_KANRI AS M1"
                    + " ON K1.KAISAICHI_CODE = M1.HANYO_CODE"
                    + " AND M1.GROUP_CODE = 'KAISAICHI_CODE'"
                    + " WHERE K1.NENDO = ?"
                    + " AND K1.SKN_KSU_CODE = ?"
                    + " AND K1.SHUBETSU_CODE = ?"
                    + " AND K1.KAISU_CODE = ?"
                    + " AND K1.KAIJO_SHIKEN_KBN = ?"
                    + " AND K1.RONRI_SAKUJO_FLG = '0'"
                    + " ORDER BY K1.KAISAICHI_CODE ASC, K1.NITTEI_FROM ASC";
            param.add(bo.getNendo());
            param.add(bo.getSknKsuCode());
            param.add(bo.getShubetsuCode());
            param.add(bo.getKaisuCode());
            param.add(bo.getKaijoShikenKbn());

            stmt = con.prepareStatement(sql);
            int i = 1;
            for (String pm : param) {
                stmt.setString(i++, pm);
            }

            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();
            while (rs.next()) {
                MskKsuJoho mskKsuJoho = new MskKsuJoho();
                mskKsuJoho.setNendo(rs.getString("NENDO"));
                mskKsuJoho.setShubetsuCode(rs.getString("SHUBETSU_CODE"));
                mskKsuJoho.setSknKsuCode(rs.getString("SKN_KSU_CODE"));
                mskKsuJoho.setKaisuCode(rs.getString("KAISU_CODE"));
                mskKsuJoho.setKaisaichiCode(rs.getString("KAISAICHI_CODE"));
                mskKsuJoho.setKaijoshikenkbn(rs.getString("KAIJO_SHIKEN_KBN"));
                mskKsuJoho.setKaisaichi(rs.getString("KAISAICHI"));
                mskKsuJoho.setDate_From(rs.getString("NITTEI_FROM"));
                mskKsuJoho.setDate_To(rs.getString("NITTEI_TO"));
                mskKsuJoho.setKaijoCode(rs.getString("KAIJO_CODE"));
                mskKsuJoho.setKaijoName(rs.getString("KAIJO_NAME"));
                mskKsuJoho.setKaijoJusho(rs.getString("JUSHO"));
                mskKsuJoho.setKuusekiSuu(rs.getString("KUSEKI"));
                mskKsuJoho.setKaijoId(rs.getString("KAIJO_ID"));
                kaijoList.add(mskKsuJoho);
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return kaijoList;
    }

    @Override
    public ShiyoKaijo findNoKaijoId(String nendo, String sknKsuCode, String shubetsuCode, String kaisuCode, String kaijoShikenKbn, String kaisaichiCode, String kaijoCode, String NO_LOCK) {
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = "";
        ShiyoKaijo bo = new ShiyoKaijo();
        try {
            con = getConnection();
            sql = "SELECT " + FIELDS_DECRYPT
                    + " FROM " + getSchemaName() + "." + TABLE_NAME
                    + " WHERE"
                    + " NENDO = ?"
                    + " AND SKN_KSU_CODE = ?"
                    + " AND SHUBETSU_CODE = ?"
                    + " AND KAISU_CODE = ?"
                    + " AND KAIJO_SHIKEN_KBN = ?"
                    + " AND KAISAICHI_CODE = ?"
                    + " AND KAIJO_CODE = ?";

            stmt = con.prepareStatement(sql);
            int i = 1;
            stmt.setString(i++, nendo);
            stmt.setString(i++, sknKsuCode);
            stmt.setString(i++, shubetsuCode);
            stmt.setString(i++, kaisuCode);
            stmt.setString(i++, kaijoShikenKbn);
            stmt.setString(i++, kaisaichiCode);
            stmt.setString(i++, kaijoCode);

            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();
            if (rs.next()) {
                setBoFromResultSet(bo, rs);
            } else {
                bo = null;
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return bo;
    }
    
        @Override
    public ShiyoKaijo findKaijo(ShiyoKaijo bo) {
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = "";
        try {
            con = getConnection();
            sql = "SELECT " + FIELDS_DECRYPT
                    + " FROM " + getSchemaName() + "." + TABLE_NAME
                    + " WHERE"
                    + " NENDO = ?"
                    + " AND SKN_KSU_CODE = ?"
                    + " AND SHUBETSU_CODE = ?"
                    + " AND KAISU_CODE = ?"
                    + " AND KAIJO_ID = ?"
                    + " AND KAIJO_SHIKEN_KBN = ?";

            stmt = con.prepareStatement(sql);
            int i = 1;
            stmt.setString(i++, bo.getNendo());
            stmt.setString(i++, bo.getSknKsuCode());
            stmt.setString(i++, bo.getShubetsuCode());
            stmt.setString(i++, bo.getKaisuCode());
            stmt.setString(i++, bo.getKaijoId());
            stmt.setString(i++, bo.getKaijoShikenKbn());

            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();
            if (rs.next()) {
                setBoFromResultSet(bo, rs);
            } else {
                bo = null;
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return bo;
    }
    
    /**
     * �\���\�Ȋ�]�J�Òn���擾����B�i�\���E�����j
     *
     * @return ��]�J�Òn���X�g
     */
    @Override
    public List<Option> findKiboKaisaichiList(ShiyoKaijo bo) {
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = "";
        List<Option> kiboKaisaichiList = new ArrayList<>();
        try {
            con = getConnection();
            sql = "SELECT"
                    + " shiyokaijo.KAISAICHI_CODE AS KAISAICHI_CODE"
                    + " , " + " kaisaichi.HANYO_CHI AS KAISAICHI_NAME"
                    + " , " + " kaisaichi.HYOJI_JUNJO AS HYOJI_JUNJO"
                    + " FROM " + getSchemaName() + "." + TABLE_NAME + " AS shiyokaijo"
                    + " LEFT JOIN " + getSchemaName() + "." + MeishoKanriDao.TABLE_NAME + " AS kaisaichi"
                    + " ON " + " kaisaichi.GROUP_CODE = '"  + BmaConstants.KAISAICHI_CODE + "'"
                    + " AND " + " kaisaichi.HANYO_CODE = KAISAICHI_CODE"
                    + " WHERE shiyokaijo.NENDO = ?"
                    + " AND shiyokaijo.SKN_KSU_CODE = ?"
                    + " AND shiyokaijo.SHUBETSU_CODE = ?"
                    + " AND shiyokaijo.KAISU_CODE = ?"
                    + " AND shiyokaijo.RONRI_SAKUJO_FLG = '0'"
                    + " GROUP BY "
                    + " KAISAICHI_CODE"
                    + " , KAISAICHI_NAME"
                    + " , HYOJI_JUNJO"
                    + " ORDER BY to_number(HYOJI_JUNJO,'999') ASC";
            stmt = con.prepareStatement(sql);
            int i = 1;
            stmt.setString(i++, bo.getNendo());
            stmt.setString(i++, bo.getSknKsuCode());
            stmt.setString(i++, bo.getShubetsuCode());
            stmt.setString(i++, bo.getKaisuCode());

            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();
            while (rs.next()) {
                Option kaisaichi = new Option(rs.getString("KAISAICHI_CODE"),rs.getString("KAISAICHI_NAME"));
                kiboKaisaichiList.add(kaisaichi);
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return kiboKaisaichiList;
    }
}
