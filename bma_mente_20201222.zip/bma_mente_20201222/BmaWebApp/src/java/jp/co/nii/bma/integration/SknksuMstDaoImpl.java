package jp.co.nii.bma.integration;

import static com.lowagie.text.xml.simpleparser.EntitiesToSymbol.map;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import static jp.co.nii.bma.business.domain.GeneratedSknksuMstDao.TABLE_NAME;
import jp.co.nii.bma.business.domain.SknksuMst;
import jp.co.nii.bma.business.domain.SknksuMstDao;
import jp.co.nii.bma.business.rto.MskSknJoho;
import jp.co.nii.bma.business.rto.TopJoho;
import jp.co.nii.sew.business.SystemTime;
import jp.co.nii.sew.common.LogGenerate;
import static jp.co.nii.sew.integration.AbstractDao.getSchemaName;
import jp.co.nii.sew.integration.SQLStateSQLExceptionTranslater;
import jp.co.nii.sew.presentation.Option;

/**
 * �����u�K��}�X�^ DAO�����N���X
 *
 * @author DB�Ǘ��c�[��
 */
public class SknksuMstDaoImpl extends GeneratedSknksuMstDaoImpl implements SknksuMstDao {

    /**
     * �C���X�^���X�𐶐�����B
     *
     * @param datasource �f�[�^�\�[�X��
     */
    public SknksuMstDaoImpl(String datasource) {
        super(datasource);
    }

    /**
     * �����u�K��̏����擾����B
     *
     * @param joho �����u�K����
     * @return List<MskSknJoho> �����u�K���񃊃X�g
     */
    @Override
    public List<MskSknJoho> searchSknKsuList(MskSknJoho joho) {
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = "";
        List<String> param = new ArrayList<String>();
        List<MskSknJoho> ret = new ArrayList<MskSknJoho>();
        String currentDate = new SystemTime().getymd1();
        try {
            con = getConnection();
            sql = "SELECT DISTINCT "
                    + "MSK.skn_ksu_code"
                    + ",MSK.shubetsu_code"
                    + ",MSK.kaisu_code"
                    + ",MSK.skn_ksu_name"
                    + ",MSK.skn_ksu_name_ryaku"
                    + ",MSK.skn_ksu_name_nosbt"
                    + ",MSK.skn_ksu_name_nosbt_ryaku"
                    + ",MSK.shubetsu_name"
                    + ",MSK.kaisu_name"
                    + ",MSK.datestart"
                    + ",MSK.dateend"
                    + ",KOJ.nendo_sch"
                    + " FROM bma.schedulekikan_view MSK"
                    + " INNER JOIN bma.schedulekikan_view KOJ ON "
                    + " MSK.skn_ksu_code = KOJ.skn_ksu_code AND MSK.shubetsu_code = KOJ.shubetsu_code AND"
                    + " MSK.kaisu_code = KOJ.kaisu_code AND MSK.skn_ksu_kbn = KOJ.skn_ksu_kbn"
                    + " AND KOJ.schedule_code = ?"
                    + " WHERE "
                    + " MSK.schedule_code = ? AND MSK.skn_ksu_kbn = ?"
                    + " AND KOJ.datestart <= ? AND KOJ.dateend >= ?"
                    + " ORDER BY"
                    + "  MSK.skn_ksu_code ASC"
                    + "  ,MSK.shubetsu_code ASC"
                    + "  ,MSK.kaisu_code ASC";

            param.add("17");
            param.add(joho.getScheduleCode());
            param.add(joho.getSknKsuKbn());
            param.add(currentDate);
            param.add(currentDate);

            stmt = con.prepareStatement(sql);
            int i = 1;
            for (String pm : param) {
                stmt.setString(i++, pm);
            }

            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();
            while (rs.next()) {
                joho = new MskSknJoho();
                joho.setSknKsuCode(rs.getString("skn_ksu_code"));
                joho.setShubetsuCode(rs.getString("shubetsu_code"));
                joho.setKaisuCode(rs.getString("kaisu_code"));
                joho.setSknKsuName(rs.getString("skn_ksu_name"));
                joho.setSknKsuNameRyaku(rs.getString("skn_ksu_name_ryaku"));
                joho.setSknKsuNameNosbt(rs.getString("skn_ksu_name_nosbt"));
                joho.setSknKsuNameNosbtRyaku(rs.getString("skn_ksu_name_nosbt_ryaku"));
                joho.setShubetsuName(rs.getString("shubetsu_name"));
                joho.setKaisuName(rs.getString("kaisu_name"));
                joho.setMskKikanStart(rs.getString("dateStart"));
                joho.setMskKikanEnd(rs.getString("dateEnd"));
                joho.setNendo(rs.getString("nendo_sch"));

                ret.add(joho);
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return ret;
    }

    /**
     * �����u�K���烊�X�g�ƃ}�b�v���擾����
     *
     * @param sknksuKbn
     * @param list
     * @param map
     */
    @Override
    public void findBySknKsuKbn(String sknksuKbn, List<Option> list, Object object) {

        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = "";
        ArrayList<String> paramList = new ArrayList<String>();

        try {
            con = getConnection();
            sql = "SELECT SKN_KSU_CODE || SHUBETSU_CODE || KAISU_CODE AS SKN_KSU_SENTAKU_CODE,"
                    + " SKN_KSU_NAME AS SKN_KSU_NAME"
                    + " FROM " + getSchemaName() + "." + TABLE_NAME
                    + " WHERE"
                    + " SKN_KSU_KBN = ?"
                    + " AND HYOJI_FLG = '1'"
                    + " AND RONRI_SAKUJO_FLG = '0'"
                    + " ORDER BY to_number(HYOJI_JUNJO,'999')";
            paramList.add(sknksuKbn);
            stmt = con.prepareStatement(sql);

            int i = 1;
            for (String param : paramList) {
                stmt.setString(i++, param);
            }
            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();

            while (rs.next()) {
                if (list != null) {

                    list.add(new Option(rs.getString("SKN_KSU_SENTAKU_CODE"), rs.getString("SKN_KSU_NAME").replace("�@", "")));
                }
                if (map != null) {
                    map.put(rs.getString("SKN_KSU_SENTAKU_CODE"), rs.getString("SKN_KSU_NAME").replace("�@", ""));
                }
            }

        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
    }

    /**
     * �g�s�b�N�̏��1���擾����B
     *
     * @param search �g�s�b�N���1
     * @return List<TopJoho> �g�s�b�N��񃊃X�g1
     */
    @Override
    public List<TopJoho> searchTopicList1(TopJoho search) {

        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        String sql = "";
        List<String> param = new ArrayList<>();
        List<TopJoho> ret = new ArrayList<>();

        Calendar cal = Calendar.getInstance();
        // year add �{1
        cal.add(Calendar.YEAR, 1);
        Date nextYear = cal.getTime();
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
        String currentDate = dateFormat.format(nextYear);

        String currentDateNow = new SystemTime().getymd1();
        try {
            con = getConnection();
            sql = "SELECT distinct"
                    + " sch.skn_ksu_code  as skn_ksu_code"
                    + " , mei.hanyo_chi as  hanyo_chi"
                    + " FROM "
                    + " bma.schedulekikan_view sch  "
                    + " INNER JOIN bma.meisho_kanri mei  "
                    + "  ON mei.group_code = 'TOPIC_HYOJI_KBN' "
                    + "  AND mei.hanyo_code = '001'"
                    + " INNER JOIN bma.hoyu_shikaku_mst hsk   "
                    + "  ON sch.skn_ksu_code = hsk.skn_ksu_code   "
                    + "WHERE"
                    + " sch.datestart <= ?"
                    + " AND sch.dateend >= ?"
                    + " AND hsk.yuko_kigen >= ?"
                    + " AND hsk.yuko_kigen <= ?"
                    + " AND sch.skn_ksu_kbn = '2'"
                    + " AND hsk.moshikomisha_id = ?"
                    + " AND sch.schedule_code = ? ";

            param.add(currentDateNow);
            param.add(currentDateNow);
            param.add(currentDateNow);

            param.add(currentDate);
            param.add(search.getMoshikomishaId());
            //CASE WHEN �Z�b�V����.����敪 = '1' THEN '01'
            //WHEN NOT �Z�b�V����.����敪 = '1' THEN '02' END
            if ("1".equals(search.getKaiinKbn())) {
                param.add("01");
            } else {
                param.add("02");
            }

            stmt = con.prepareStatement(sql);
            int i = 1;
            for (String pm : param) {
                stmt.setString(i++, pm);
            }

            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();
            while (rs.next()) {
                TopJoho joho = new TopJoho();
                joho.setTopicName(rs.getString("hanyo_chi"));
                joho.setSknKsuCode(rs.getString("skn_ksu_code"));

                ret.add(joho);
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return ret;
    }

    /**
     * �g�s�b�N�̏��2���擾����B
     *
     * @param search �g�s�b�N���2
     * @return List<TopJoho> �g�s�b�N��񃊃X�g2
     */
    @Override
    public List<TopJoho> searchTopicList2(TopJoho search) {

        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        String sql = "";
        List<String> param = new ArrayList<>();
        List<TopJoho> ret = new ArrayList<>();

        Calendar cal = Calendar.getInstance();
        // year add �{1
        cal.add(Calendar.YEAR, 1);
        Date nextYear = cal.getTime();
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
        String currentDate = dateFormat.format(nextYear);

        String currentDateNow = new SystemTime().getymd1();
        try {
            con = getConnection();
            sql = "SELECT distinct"
                    + " sch.skn_ksu_name  as skn_ksu_name"
                    + " , mei.hanyo_chi as  hanyo_chi"
                    + " FROM "
                    + " bma.schedulekikan_view sch  "
                    + " INNER JOIN bma.meisho_kanri mei "
                    + " ON mei.group_code = 'TOPIC_HYOJI_KBN' "
                    + " AND mei.hanyo_code = '002'"
                    + " INNER JOIN bma.hoyu_shikaku_mst hsk"
                    + "  ON sch.skn_ksu_code = hsk.skn_ksu_code"
                    + " INNER JOIN bma.hoyu_menjo_mst hmn "
                    + " ON sch.skn_ksu_code = hmn.skn_ksu_code"
                    + " AND sch.shubetsu_code = hmn.shubetsu_code "
                    + " AND hmn.menjo_kbn = '1' "
                    + " WHERE "
                    + " sch.datestart <= ?"
                    + " AND sch.dateend >= ?"
                    + " AND hmn.yuko_kigen >= ?"
                    + " AND hmn.yuko_kigen <= ?"
                    + " AND sch.skn_ksu_kbn = '1'"
                    + " AND hmn.moshikomisha_id = ?"
                    + " AND sch.schedule_code = ? ";

            param.add(currentDateNow);
            param.add(currentDateNow);
            param.add(currentDateNow);
            param.add(currentDate);
            param.add(search.getMoshikomishaId());
            //CASE WHEN �Z�b�V����.����敪 = '1' THEN '01'
            //WHEN NOT �Z�b�V����.����敪 = '1' THEN '02' END
            if ("1".equals(search.getKaiinKbn())) {
                param.add("01");
            } else {
                param.add("02");
            }
            stmt = con.prepareStatement(sql);
            int i = 1;
            for (String pm : param) {
                stmt.setString(i++, pm);
            }

            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();
            while (rs.next()) {
                TopJoho joho = new TopJoho();
                joho.setTopicName(rs.getString("hanyo_chi"));
                joho.setSknKsuName(rs.getString("skn_ksu_name"));

                ret.add(joho);
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return ret;
    }

    /**
     * �g�s�b�N�̏��3���擾����B
     *
     * @param search �g�s�b�N���3
     * @return List<TopJoho> �g�s�b�N��񃊃X�g3
     */
    @Override
    public List<TopJoho> searchTopicList3(TopJoho search) {
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        String sql = "";
        List<String> param = new ArrayList<>();
        List<TopJoho> ret = new ArrayList<>();

        Calendar cal = Calendar.getInstance();
        // year add �{1
        cal.add(Calendar.YEAR, 1);
        Date nextYear = cal.getTime();
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
        String currentDate = dateFormat.format(nextYear);

        String currentDateNow = new SystemTime().getymd1();

        try {
            con = getConnection();
            sql = "SELECT distinct"
                    + " sch.skn_ksu_name  as skn_ksu_name"
                    + " , mei.hanyo_chi as  hanyo_chi"
                    + " FROM "
                    + " bma.schedulekikan_view sch  "
                    + " INNER JOIN bma.meisho_kanri mei "
                    + " ON mei.group_code = 'TOPIC_HYOJI_KBN' "
                    + " AND mei.hanyo_code = '003'"
                    + " INNER JOIN bma.hoyu_shikaku_mst hsk"
                    + "  ON sch.skn_ksu_code = hsk.skn_ksu_code"
                    + " INNER JOIN bma.hoyu_menjo_mst hmn "
                    + " ON sch.skn_ksu_code = hmn.skn_ksu_code"
                    + " AND sch.shubetsu_code = hmn.shubetsu_code "
                    + " AND hmn.menjo_kbn = '2' "
                    + " WHERE "
                    + " sch.datestart <= ?"
                    + " AND sch.dateend >= ?"
                    + " AND hmn.yuko_kigen >= ?"
                    + " AND hmn.yuko_kigen <= ?"
                    + " AND sch.skn_ksu_kbn = '1'"
                    + " AND hmn.moshikomisha_id = ?"
                    + " AND sch.schedule_code = ? ";

            param.add(currentDateNow);
            param.add(currentDateNow);
            param.add(currentDateNow);
            param.add(currentDate);
            param.add(search.getMoshikomishaId());
            //CASE WHEN �Z�b�V����.����敪 = '1' THEN '01'
            //WHEN NOT �Z�b�V����.����敪 = '1' THEN '02' END
            if ("1".equals(search.getKaiinKbn())) {
                param.add("01");
            } else {
                param.add("02");
            }
            stmt = con.prepareStatement(sql);
            int i = 1;
            for (String pm : param) {
                stmt.setString(i++, pm);
            }

            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();
            while (rs.next()) {
                TopJoho joho = new TopJoho();
                joho.setTopicName(rs.getString("hanyo_chi"));
                joho.setSknKsuName(rs.getString("skn_ksu_name"));

                ret.add(joho);
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return ret;
    }

    /**
     * �g�s�b�N�̏��4���擾����B
     *
     * @param search �g�s�b�N���4
     * @return List<TopJoho> �g�s�b�N��񃊃X�g4
     */
    @Override
    public List<TopJoho> searchTopicList4(TopJoho search) {
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        String sql = "";
        List<String> param = new ArrayList<>();
        List<TopJoho> ret = new ArrayList<>();

        String currentDate = new SystemTime().getymd1();

        try {
            con = getConnection();
            sql = "SELECT distinct"
                    + " sch.skn_ksu_name  as skn_ksu_name"
                    + " , mei.hanyo_chi as  hanyo_chi"
                    + " FROM "
                    + " bma.schedulekikan_view sch  "
                    + " INNER JOIN bma.meisho_kanri mei  "
                    + " ON mei.group_code = 'TOPIC_HYOJI_KBN'"
                    + " AND mei.hanyo_code = '004'"
                    + " INNER JOIN bma.moshikomi msk"
                    + " ON sch.skn_ksu_code = msk.skn_ksu_code  "
                    + " AND sch.shubetsu_code = msk.shubetsu_code "
                    + " AND sch.kaisu_code = msk.kaisu_code"
                    + " AND sch.nendo_sch = msk.nendo  "
                    + " INNER JOIN bma.gazo gazo  "
                    + " ON msk.uketsuke_no = gazo.uketsuke_no"
                    + " WHERE "
                    + " sch.datestart <= ?"
                    + " AND gazo.hosei_kigen_bi >= ?"
                    + " AND msk.moshikomisha_id = ?"
                    + "  AND sch.schedule_code = '20'"
                    + "  AND gazo.GAZO_HYOJI_KBN = '3'"
                    + "  AND gazo.ronri_sakujo_flg  = '0'"
                    + " GROUP BY  "
                    + " sch.skn_ksu_name  "
                    + " , mei.hanyo_chi    "
                    + " , sch.skn_ksu_code  "
                    + " , sch.shubetsu_code    "
                    + " , sch.kaisu_code  ";

            param.add(currentDate);
            param.add(currentDate);
            param.add(search.getMoshikomishaId());

            stmt = con.prepareStatement(sql);
            int i = 1;
            for (String pm : param) {
                stmt.setString(i++, pm);
            }

            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();
            while (rs.next()) {
                TopJoho joho = new TopJoho();
                joho.setTopicName(rs.getString("hanyo_chi"));
                joho.setSknKsuName(rs.getString("skn_ksu_name"));

                ret.add(joho);
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return ret;
    }

    /**
     * �g�s�b�N�̏��5���擾����B
     *
     * @param search �g�s�b�N���5
     * @return List<TopJoho> �g�s�b�N��񃊃X�g5
     */
    @Override
    public List<TopJoho> searchTopicList5(TopJoho search) {

        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        String sql = "";
        List<String> param = new ArrayList<>();
        List<TopJoho> ret = new ArrayList<>();

        String currentDate = new SystemTime().getymd1();

        try {
            con = getConnection();
            sql = "SELECT distinct"
                    + " sknksu.skn_ksu_name  as skn_ksu_name"
                    + " , mei.hanyo_chi as  hanyo_chi"
                    + " FROM "
                    + " bma.schedulekikan_view sch  "
                    + " INNER JOIN bma.sknksu_mst sknksu"
                    + " ON sknksu.skn_ksu_code = sch.skn_ksu_code "
                    + " AND sknksu.shubetsu_code = sch.shubetsu_code"
                    + " AND sknksu.kaisu_code = sch.kaisu_code  "
                    + " INNER JOIN bma.meisho_kanri mei  "
                    + " ON mei.group_code = 'TOPIC_HYOJI_KBN'"
                    + " AND mei.hanyo_code = '005'"
                    + " INNER JOIN bma.moshikomi msk"
                    + " ON sch.skn_ksu_code = msk.skn_ksu_code  "
                    + " AND sch.shubetsu_code = msk.shubetsu_code "
                    + " AND sch.kaisu_code = msk.kaisu_code"
                    + " AND sch.nendo_sch = msk.nendo  "
                    + " INNER JOIN bma.kessai kessai"
                    + " ON msk.uketsuke_no = kessai.uketsuke_no"
                    + " WHERE "
                    + " sch.datestart <= ?"
                    + " AND kessai.kessai_kigen_bi >= ?"
                    + " AND msk.moshikomisha_id = ?"
                    + "  AND kessai.kessai_jokyo_kbn = '2'"
                    + "  AND sch.schedule_code = '05'";

            param.add(currentDate);
            param.add(currentDate);
            param.add(search.getMoshikomishaId());

            stmt = con.prepareStatement(sql);
            int i = 1;
            for (String pm : param) {
                stmt.setString(i++, pm);
            }

            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();
            while (rs.next()) {
                TopJoho joho = new TopJoho();
                joho.setTopicName(rs.getString("hanyo_chi"));
                joho.setSknKsuName(rs.getString("skn_ksu_name"));

                ret.add(joho);
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return ret;
    }

    /**
     * �����u�K�R�[�h�A��ʃR�[�h�A�񐔃R�[�h���玎���u�K���̂��擾����
     *
     * @param bo
     * @return
     */
    @Override
    public SknksuMst findSknKsuNameRyaku(SknksuMst bo) {

        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql;
        ArrayList<String> paramList = new ArrayList<String>();

        try {
            con = getConnection();
            sql = "SELECT SKN_KSU_NAME_RYAKU AS SKN_KSU_NAME"
                    + " FROM " + getSchemaName() + "." + TABLE_NAME
                    + " WHERE"
                    + " SKN_KSU_CODE = ?"
                    + " AND SHUBETSU_CODE = ?"
                    + " AND KAISU_CODE = ?"
                    + " AND RONRI_SAKUJO_FLG = '0'";

            paramList.add(bo.getSknKsuCode());
            paramList.add(bo.getShubetsuCode());
            paramList.add(bo.getKaisuCode());
            stmt = con.prepareStatement(sql);

            int i = 1;
            for (String param : paramList) {
                stmt.setString(i++, param);
            }
            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();

            if (rs.next()) {
                bo.setSknKsuNameRyaku(rs.getString("SKN_KSU_NAME"));
            }

        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return bo;
    }

    /**
     * �g�s�b�N�̏��1���擾����B
     *
     * @param search �g�s�b�N���1
     * @return List<TopJoho> �g�s�b�N��񃊃X�g1
     */
    @Override
    public List<TopJoho> searchTopicListGroup1(TopJoho search) {

        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        String sql = "";
        List<String> param = new ArrayList<>();
        List<TopJoho> ret = new ArrayList<>();

        Calendar cal = Calendar.getInstance();
        // year add �{1
        cal.add(Calendar.YEAR, 1);
        Date nextYear = cal.getTime();
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
        String currentDate = dateFormat.format(nextYear);

        String currentDateNow = new SystemTime().getymd1();
        try {
            con = getConnection();
            sql = "SELECT "
                    + " sch.skn_ksu_code  as skn_ksu_code"
                    + " , mei.hanyo_chi as  hanyo_chi"
                    + " FROM "
                    + " bma.schedulekikan_view sch  "
                    + " INNER JOIN bma.meisho_kanri mei  "
                    + "  ON mei.group_code = 'TOPIC_HYOJI_KBN' "
                    + "  AND mei.hanyo_code = '001'"
                    + " INNER JOIN bma.hoyu_shikaku_mst hsk   "
                    + "  ON sch.skn_ksu_code = hsk.skn_ksu_code   "
                    + " INNER JOIN bma.moshikomi msk  "
                    + "  ON msk.moshikomisha_id = hsk.moshikomisha_id   "
                    + "WHERE"
                    + " sch.datestart <= ?"
                    + " AND sch.dateend >= ?"
                    + " AND hsk.yuko_kigen >= ?"
                    + " AND hsk.yuko_kigen <= ?"
                    + " AND sch.skn_ksu_kbn = '2'"
                    + " AND sch.schedule_code = ? "
                    + " AND msk.toroku_user_id = ? "
                    + " GROUP BY"
                    + "  sch.skn_ksu_code  "
                    + "  , mei.hanyo_chi  ";
            param.add(currentDateNow);
            param.add(currentDateNow);
            param.add(currentDateNow);

            param.add(currentDate);

            //CASE WHEN �Z�b�V����.����敪 = '1' THEN '01'
            //WHEN NOT �Z�b�V����.����敪 = '1' THEN '02' END
            if ("1".equals(search.getKaiinKbn())) {
                param.add("01");
            } else {
                param.add("02");
            }
            param.add(search.getMoshikomishaId());

            stmt = con.prepareStatement(sql);
            int i = 1;
            for (String pm : param) {
                stmt.setString(i++, pm);
            }

            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();
            while (rs.next()) {
                TopJoho joho = new TopJoho();
                joho.setTopicName(rs.getString("hanyo_chi"));
                joho.setSknKsuCode(rs.getString("skn_ksu_code"));

                ret.add(joho);
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return ret;
    }

    /**
     * �g�s�b�N�̏��2���擾����B
     *
     * @param search �g�s�b�N���2
     * @return List<TopJoho> �g�s�b�N��񃊃X�g2
     */
    @Override
    public List<TopJoho> searchTopicListGroup2(TopJoho search) {

        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        String sql = "";
        List<String> param = new ArrayList<>();
        List<TopJoho> ret = new ArrayList<>();

        Calendar cal = Calendar.getInstance();
        // year add �{1
        cal.add(Calendar.YEAR, 1);
        Date nextYear = cal.getTime();
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
        String currentDate = dateFormat.format(nextYear);

        String currentDateNow = new SystemTime().getymd1();
        try {
            con = getConnection();
            sql = "SELECT "
                    + " sch.skn_ksu_name  as skn_ksu_name"
                    + " , mei.hanyo_chi as  hanyo_chi"
                    + " FROM "
                    + " bma.schedulekikan_view sch  "
                    + " INNER JOIN bma.meisho_kanri mei "
                    + " ON mei.group_code = 'TOPIC_HYOJI_KBN' "
                    + " AND mei.hanyo_code = '002'"
                    + " INNER JOIN bma.hoyu_shikaku_mst hsk"
                    + "  ON sch.skn_ksu_code = hsk.skn_ksu_code"
                    + " INNER JOIN bma.hoyu_menjo_mst hmn "
                    + " ON sch.skn_ksu_code = hmn.skn_ksu_code"
                    + " AND sch.shubetsu_code = hmn.shubetsu_code "
                    + " AND hmn.menjo_kbn = '1' "
                    + " INNER JOIN bma.moshikomi msk  "
                    + "  ON msk.moshikomisha_id = hmn.moshikomisha_id   "
                    + " WHERE "
                    + " sch.datestart <= ?"
                    + " AND sch.dateend >= ?"
                    + " AND hmn.yuko_kigen >= ?"
                    + " AND hmn.yuko_kigen <= ?"
                    + " AND sch.skn_ksu_kbn = '1'"
                    + " AND sch.schedule_code = ? "
                    + " AND msk.toroku_user_id = ? "
                    + " GROUP BY"
                    + "  sch.skn_ksu_name    "
                    + "  ,mei.hanyo_chi  "
                    + "  ,sch.skn_ksu_code "
                    + "  , sch.shubetsu_code "
                    + "  , sch.kaisu_code  ";

            param.add(currentDateNow);
            param.add(currentDateNow);
            param.add(currentDateNow);
            param.add(currentDate);

            //CASE WHEN �Z�b�V����.����敪 = '1' THEN '01'
            //WHEN NOT �Z�b�V����.����敪 = '1' THEN '02' END
            if ("1".equals(search.getKaiinKbn())) {
                param.add("01");
            } else {
                param.add("02");
            }
            param.add(search.getMoshikomishaId());

            stmt = con.prepareStatement(sql);
            int i = 1;
            for (String pm : param) {
                stmt.setString(i++, pm);
            }

            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();
            while (rs.next()) {
                TopJoho joho = new TopJoho();
                joho.setTopicName(rs.getString("hanyo_chi"));
                joho.setSknKsuName(rs.getString("skn_ksu_name"));

                ret.add(joho);
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return ret;
    }

    /**
     * �g�s�b�N�̏��3���擾����B
     *
     * @param search �g�s�b�N���3
     * @return List<TopJoho> �g�s�b�N��񃊃X�g3
     */
    @Override
    public List<TopJoho> searchTopicListGroup3(TopJoho search) {
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        String sql = "";
        List<String> param = new ArrayList<>();
        List<TopJoho> ret = new ArrayList<>();

        Calendar cal = Calendar.getInstance();
        // year add �{1
        cal.add(Calendar.YEAR, 1);
        Date nextYear = cal.getTime();
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
        String currentDate = dateFormat.format(nextYear);

        String currentDateNow = new SystemTime().getymd1();

        try {
            con = getConnection();
            sql = "SELECT "
                    + " sch.skn_ksu_name  as skn_ksu_name"
                    + " , mei.hanyo_chi as  hanyo_chi"
                    + " FROM "
                    + " bma.schedulekikan_view sch  "
                    + " INNER JOIN bma.meisho_kanri mei "
                    + " ON mei.group_code = 'TOPIC_HYOJI_KBN' "
                    + " AND mei.hanyo_code = '003'"
                    + " INNER JOIN bma.hoyu_shikaku_mst hsk"
                    + "  ON sch.skn_ksu_code = hsk.skn_ksu_code"
                    + " INNER JOIN bma.hoyu_menjo_mst hmn "
                    + " ON sch.skn_ksu_code = hmn.skn_ksu_code"
                    + " AND sch.shubetsu_code = hmn.shubetsu_code "
                    + " AND hmn.menjo_kbn = '2' "
                    + " INNER JOIN bma.moshikomi msk  "
                    + "  ON msk.moshikomisha_id = hmn.moshikomisha_id   "
                    + " WHERE "
                    + " sch.datestart <= ?"
                    + " AND sch.dateend >= ?"
                    + " AND hmn.yuko_kigen >= ?"
                    + " AND hmn.yuko_kigen <= ?"
                    + " AND sch.skn_ksu_kbn = '1'"
                    + " AND sch.schedule_code = ? "
                    + " AND msk.toroku_user_id = ? "
                    + " GROUP BY"
                    + "  sch.skn_ksu_name    "
                    + "  ,mei.hanyo_chi  "
                    + "  ,sch.skn_ksu_code "
                    + "  , sch.shubetsu_code "
                    + "  , sch.kaisu_code  ";

            param.add(currentDateNow);
            param.add(currentDateNow);
            param.add(currentDateNow);
            param.add(currentDate);
            //CASE WHEN �Z�b�V����.����敪 = '1' THEN '01'
            //WHEN NOT �Z�b�V����.����敪 = '1' THEN '02' END
            if ("1".equals(search.getKaiinKbn())) {
                param.add("01");
            } else {
                param.add("02");
            }
            param.add(search.getMoshikomishaId());

            stmt = con.prepareStatement(sql);
            int i = 1;
            for (String pm : param) {
                stmt.setString(i++, pm);
            }

            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();
            while (rs.next()) {
                TopJoho joho = new TopJoho();
                joho.setTopicName(rs.getString("hanyo_chi"));
                joho.setSknKsuName(rs.getString("skn_ksu_name"));

                ret.add(joho);
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return ret;
    }

    /**
     * �g�s�b�N�̏��4���擾����B
     *
     * @param search �g�s�b�N���4
     * @return List<TopJoho> �g�s�b�N��񃊃X�g4
     */
    @Override
    public List<TopJoho> searchTopicListGroup4(TopJoho search) {
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        String sql = "";
        List<String> param = new ArrayList<>();
        List<TopJoho> ret = new ArrayList<>();

        String currentDate = new SystemTime().getymd1();

        try {
            con = getConnection();
            sql = "SELECT "
                    + " sch.skn_ksu_name  as skn_ksu_name"
                    + " , mei.hanyo_chi as  hanyo_chi"
                    + " FROM "
                    + " bma.schedulekikan_view sch  "
                    + " INNER JOIN bma.meisho_kanri mei  "
                    + " ON mei.group_code = 'TOPIC_HYOJI_KBN'"
                    + " AND mei.hanyo_code = '004'"
                    + " INNER JOIN bma.moshikomi msk"
                    + " ON sch.skn_ksu_code = msk.skn_ksu_code  "
                    + " AND sch.shubetsu_code = msk.shubetsu_code "
                    + " AND sch.kaisu_code = msk.kaisu_code"
                    + " AND sch.nendo_sch = msk.nendo  "
                    + " INNER JOIN bma.gazo gazo  "
                    + " ON msk.uketsuke_no = gazo.uketsuke_no"
                    + " WHERE "
                    + " sch.datestart <= ?"
                    + " AND gazo.hosei_kigen_bi >= ?"
                    + "  AND sch.schedule_code = '20'"
                    + "  AND gazo.GAZO_HYOJI_KBN = '3'"
                    + "  AND gazo.ronri_sakujo_flg  = '0'"
                    + " AND msk.toroku_user_id = ? "
                    + " GROUP BY  "
                    + " sch.skn_ksu_name  "
                    + " , mei.hanyo_chi    "
                    + " , sch.skn_ksu_code  "
                    + " , sch.shubetsu_code    "
                    + " , sch.kaisu_code  ";

            param.add(currentDate);
            param.add(currentDate);

            param.add(search.getMoshikomishaId());
            stmt = con.prepareStatement(sql);
            int i = 1;
            for (String pm : param) {
                stmt.setString(i++, pm);
            }
            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();
            while (rs.next()) {
                TopJoho joho = new TopJoho();
                joho.setTopicName(rs.getString("hanyo_chi"));
                joho.setSknKsuName(rs.getString("skn_ksu_name"));

                ret.add(joho);
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return ret;
    }

    /**
     * �g�s�b�N�̏��5���擾����B
     *
     * @param search �g�s�b�N���5
     * @return List<TopJoho> �g�s�b�N��񃊃X�g5
     */
    @Override
    public List<TopJoho> searchTopicListGroup5(TopJoho search) {

        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        String sql = "";
        List<String> param = new ArrayList<>();
        List<TopJoho> ret = new ArrayList<>();

        String currentDate = new SystemTime().getymd1();

        try {
            con = getConnection();
            sql = "SELECT "
                    + " sknksu.skn_ksu_name  as skn_ksu_name"
                    + " , mei.hanyo_chi as  hanyo_chi"
                    + " FROM "
                    + " bma.schedulekikan_view sch  "
                    + " INNER JOIN bma.sknksu_mst sknksu"
                    + " ON sknksu.skn_ksu_code = sch.skn_ksu_code "
                    + " AND sknksu.shubetsu_code = sch.shubetsu_code"
                    + " AND sknksu.kaisu_code = sch.kaisu_code  "
                    + " INNER JOIN bma.meisho_kanri mei  "
                    + " ON mei.group_code = 'TOPIC_HYOJI_KBN'"
                    + " AND mei.hanyo_code = '005'"
                    + " INNER JOIN bma.moshikomi msk"
                    + " ON sch.skn_ksu_code = msk.skn_ksu_code  "
                    + " AND sch.shubetsu_code = msk.shubetsu_code "
                    + " AND sch.kaisu_code = msk.kaisu_code"
                    + " AND sch.nendo_sch = msk.nendo  "
                    + " INNER JOIN bma.kessai kessai"
                    + " ON msk.uketsuke_no = kessai.uketsuke_no"
                    + " WHERE "
                    + " sch.datestart <= ?"
                    + " AND kessai.kessai_kigen_bi >= ?"
                    + "  AND kessai.kessai_jokyo_kbn = '2'"
                    + "  AND sch.schedule_code = '05'"
                    + " AND msk.toroku_user_id = ? ";

            param.add(currentDate);
            param.add(currentDate);

            param.add(search.getMoshikomishaId());
            stmt = con.prepareStatement(sql);
            int i = 1;
            for (String pm : param) {
                stmt.setString(i++, pm);
            }

            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();
            while (rs.next()) {
                TopJoho joho = new TopJoho();
                joho.setTopicName(rs.getString("hanyo_chi"));
                joho.setSknKsuName(rs.getString("skn_ksu_name"));

                ret.add(joho);
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return ret;
    }

}
