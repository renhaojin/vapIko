package jp.co.nii.bma.integration;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import jp.co.nii.bma.business.domain.Ryokin;
import jp.co.nii.bma.business.domain.RyokinDao;
import jp.co.nii.sew.common.LogGenerate;
import jp.co.nii.sew.integration.SQLStateSQLExceptionTranslater;

/**
 * ���� DAO�����N���X
 * @author DB�Ǘ��c�[��
 */
public class RyokinDaoImpl extends GeneratedRyokinDaoImpl implements RyokinDao {

    /**
     * �C���X�^���X�𐶐�����B
     * @param datasource �f�[�^�\�[�X��
     */
    public RyokinDaoImpl(String datasource) {
        super(datasource);
    }
    
    /**
     * �������擾����
     * @param bo
     * @return 
     */
    @Override
    public String findByRyokinKbn(Ryokin bo) {

        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql;
        ArrayList<String> paramList = new ArrayList<>();
        String kingaku = null;
        try {
            con = getConnection();
            sql = "SELECT " + FIELDS_DECRYPT
                    + " FROM " + getSchemaName() + "." + TABLE_NAME
                    + " WHERE"
                    + " SKN_KSU_CODE = ?"
                    + " AND SHUBETSU_CODE = ?"
                    + " AND RYOKIN_KBN = ?"
                    + " AND RONRI_SAKUJO_FLG = '0'";

            paramList.add(bo.getSknKsuCode());
            paramList.add(bo.getShubetsuCode());
            paramList.add(bo.getRyokinKbn());
            stmt = con.prepareStatement(sql);

            int i = 1;
            for (String param : paramList) {
                stmt.setString(i++, param);
            }
            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();
            while (rs.next()) {
               kingaku = rs.getString("RYOKIN");
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return kingaku;
    }
}
