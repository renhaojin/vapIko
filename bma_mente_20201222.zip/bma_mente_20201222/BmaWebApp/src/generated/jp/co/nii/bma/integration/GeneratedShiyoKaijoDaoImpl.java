package jp.co.nii.bma.integration;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import jp.co.nii.sew.business.domain.NoSuchDataException;
import jp.co.nii.sew.common.LogGenerate;
import jp.co.nii.sew.integration.AbstractDao;
import jp.co.nii.sew.integration.SQLStateSQLExceptionTranslater;

import jp.co.nii.bma.business.domain.GeneratedShiyoKaijo;
import jp.co.nii.bma.business.domain.GeneratedShiyoKaijoDao;

/**
 * �������ꂽ �g�p��� DAO�����N���X<br>
 * table-design-ver 8
 * @author DB�Ǘ��c�[��
 */
abstract class GeneratedShiyoKaijoDaoImpl extends AbstractDao implements GeneratedShiyoKaijoDao {

    /**
     * �e�[�u���J�������̃J���}��؂蕶����B<br>
     * SQL���̍쐬�ɗp����B
     */
    protected static final String FIELDS = "NENDO"
            + ",SKN_KSU_CODE"
            + ",SHUBETSU_CODE"
            + ",KAISU_CODE"
            + ",KAIJO_ID"
            + ",KAIJO_SHIKEN_KBN"
            + ",KAISAICHI_CODE"
            + ",KAIJO_CODE"
            + ",KAIJO_NAME"
            + ",KAIJO_NAME_RYAKU"
            + ",YUBIN_NO"
            + ",JUSHO"
            + ",TANTOSHA_CODE"
            + ",NITTEI_FROM"
            + ",NITTEI_TO"
            + ",TEIIN"
            + ",GENZAI_NINZU"
            + ",BIKO_KAIJO"
            + ",BIKO_TANTO"
            + ",KAISAICHI_CODE_KAIJO_MST"
            + ",KOSHIN_KBN"
            + ",TOROKU_DATE"
            + ",TOROKU_TIME"
            + ",TOROKU_USER_ID"
            + ",KOSHIN_DATE"
            + ",KOSHIN_TIME"
            + ",KOSHIN_USER_ID"
            + ",RONRI_SAKUJO_FLG";

    /**
     * �e�[�u���J�������̃J���}��؂蕶����B<br>
     *  �Í����Ώۍ��ڂ𕡍�����SQL���̍쐬�ɗp����B
     */
    protected static final String FIELDS_DECRYPT = "NENDO"
            + "," + "SKN_KSU_CODE"
            + "," + "SHUBETSU_CODE"
            + "," + "KAISU_CODE"
            + "," + "KAIJO_ID"
            + "," + "KAIJO_SHIKEN_KBN"
            + "," + "KAISAICHI_CODE"
            + "," + "KAIJO_CODE"
            + "," + "KAIJO_NAME"
            + "," + "KAIJO_NAME_RYAKU"
            + "," + "YUBIN_NO"
            + "," + "JUSHO"
            + "," + "TANTOSHA_CODE"
            + "," + "NITTEI_FROM"
            + "," + "NITTEI_TO"
            + "," + "TEIIN"
            + "," + "GENZAI_NINZU"
            + "," + "BIKO_KAIJO"
            + "," + "BIKO_TANTO"
            + "," + "KAISAICHI_CODE_KAIJO_MST"
            + "," + "KOSHIN_KBN"
            + "," + "TOROKU_DATE"
            + "," + "TOROKU_TIME"
            + "," + "TOROKU_USER_ID"
            + "," + "KOSHIN_DATE"
            + "," + "KOSHIN_TIME"
            + "," + "KOSHIN_USER_ID"
            + "," + "RONRI_SAKUJO_FLG";

    /**
     * �C���X�^���X�𐶐�����B<br>
     * �f�[�^�\�[�X������
     * @param datasource �f�[�^�\�[�X��
     */
    public GeneratedShiyoKaijoDaoImpl(String datasource) {
        super(datasource);
    }

    /* (non-Javadoc)
     * @see jp.co.nii.bma.business.domain.GeneratedShiyoKaijoDao#create(jp.co.nii.bma.business.domain.GeneratedShiyoKaijo)
     */
    @Override
    public void create(GeneratedShiyoKaijo bo) {
        Connection con = null;
        PreparedStatement stmt = null;
        String sql = "";
        try {
            con = getConnection();
            sql = "INSERT INTO " + getSchemaName() + "." + TABLE_NAME + " ( "
                    + FIELDS
                    + " ) VALUES ("
                    + " ?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + " )";

            stmt = con.prepareStatement(sql);
            int i = 1;
            stmt.setString(i++, bo.getNendo());
            stmt.setString(i++, bo.getSknKsuCode());
            stmt.setString(i++, bo.getShubetsuCode());
            stmt.setString(i++, bo.getKaisuCode());
            stmt.setString(i++, bo.getKaijoId());
            stmt.setString(i++, bo.getKaijoShikenKbn());
            stmt.setString(i++, bo.getKaisaichiCode());
            stmt.setString(i++, bo.getKaijoCode());
            stmt.setString(i++, bo.getKaijoName());
            stmt.setString(i++, bo.getKaijoNameRyaku());
            stmt.setString(i++, bo.getYubinNo());
            stmt.setString(i++, bo.getJusho());
            stmt.setString(i++, bo.getTantoshaCode());
            stmt.setString(i++, bo.getNitteiFrom());
            stmt.setString(i++, bo.getNitteiTo());
            stmt.setString(i++, bo.getTeiin());
            stmt.setString(i++, bo.getGenzaiNinzu());
            stmt.setString(i++, bo.getBikoKaijo());
            stmt.setString(i++, bo.getBikoTanto());
            stmt.setString(i++, bo.getKaisaichiCodeKaijoMst());
            stmt.setString(i++, bo.getKoshinKbn());
            stmt.setString(i++, bo.getTorokuDate());
            stmt.setString(i++, bo.getTorokuTime());
            stmt.setString(i++, bo.getTorokuUserId());
            stmt.setString(i++, bo.getKoshinDate());
            stmt.setString(i++, bo.getKoshinTime());
            stmt.setString(i++, bo.getKoshinUserId());
            stmt.setString(i++, bo.getRonriSakujoFlg());

            LogGenerate.debugOutput(getSql(stmt));
            stmt.executeUpdate();
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt);
        }
    }

    /* (non-Javadoc)
     * @see jp.co.nii.bma.business.domain.GeneratedShiyoKaijoDao#find(jp.co.nii.bma.business.domain.GeneratedShiyoKaijo, java.lang.String)
     */
    @Override
    public GeneratedShiyoKaijo find(GeneratedShiyoKaijo bo, String lockMode) {
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs =null;
        String sql = "";
        try {
            con = getConnection();
            sql = "SELECT " + FIELDS_DECRYPT
                    + " FROM " + getSchemaName() + "." + TABLE_NAME
                    + " WHERE"
                    + " NENDO = ?"
                    + " AND SKN_KSU_CODE = ?"
                    + " AND SHUBETSU_CODE = ?"
                    + " AND KAISU_CODE = ?"
                    + " AND KAIJO_ID = ?"
                    + " AND KAIJO_SHIKEN_KBN = ?"
                    + " AND KAISAICHI_CODE = ?"
                    + " AND KAIJO_CODE = ?";

            stmt = con.prepareStatement(sql + lockMode);
            int i = 1;
            stmt.setString(i++, bo.getNendo());
            stmt.setString(i++, bo.getSknKsuCode());
            stmt.setString(i++, bo.getShubetsuCode());
            stmt.setString(i++, bo.getKaisuCode());
            stmt.setString(i++, bo.getKaijoId());
            stmt.setString(i++, bo.getKaijoShikenKbn());
            stmt.setString(i++, bo.getKaisaichiCode());
            stmt.setString(i++, bo.getKaijoCode());

            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();
            if (rs.next()) {
                setBoFromResultSet(bo, rs);
            } else {
                bo = null;
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return bo;
    }

    /* (non-Javadoc)
     * @see jp.co.nii.bma.business.domain.GeneratedShiyoKaijoDao#update(jp.co.nii.bma.business.domain.GeneratedShiyoKaijo)
     */
    @Override
    public void update(GeneratedShiyoKaijo bo) {
        Connection con = null;
        PreparedStatement stmt = null;
        String sql = "";
        try {
            con = getConnection();
            sql = "UPDATE " + getSchemaName() + "." + TABLE_NAME + " SET"
                    + " KAIJO_NAME = ?"
                    + ",KAIJO_NAME_RYAKU = ?"
                    + ",YUBIN_NO = ?"
                    + ",JUSHO = ?"
                    + ",TANTOSHA_CODE = ?"
                    + ",NITTEI_FROM = ?"
                    + ",NITTEI_TO = ?"
                    + ",TEIIN = ?"
                    + ",GENZAI_NINZU = ?"
                    + ",BIKO_KAIJO = ?"
                    + ",BIKO_TANTO = ?"
                    + ",KAISAICHI_CODE_KAIJO_MST = ?"
                    + ",KOSHIN_KBN = ?"
                    + ",TOROKU_DATE = ?"
                    + ",TOROKU_TIME = ?"
                    + ",TOROKU_USER_ID = ?"
                    + ",KOSHIN_DATE = ?"
                    + ",KOSHIN_TIME = ?"
                    + ",KOSHIN_USER_ID = ?"
                    + ",RONRI_SAKUJO_FLG = ?"
                    + " WHERE"
                    + " NENDO = ?"
                    + " AND SKN_KSU_CODE = ?"
                    + " AND SHUBETSU_CODE = ?"
                    + " AND KAISU_CODE = ?"
                    + " AND KAIJO_ID = ?"
                    + " AND KAIJO_SHIKEN_KBN = ?"
                    + " AND KAISAICHI_CODE = ?"
                    + " AND KAIJO_CODE = ?";

            stmt = con.prepareStatement(sql);
            int i = 1;
            stmt.setString(i++, bo.getKaijoName());
            stmt.setString(i++, bo.getKaijoNameRyaku());
            stmt.setString(i++, bo.getYubinNo());
            stmt.setString(i++, bo.getJusho());
            stmt.setString(i++, bo.getTantoshaCode());
            stmt.setString(i++, bo.getNitteiFrom());
            stmt.setString(i++, bo.getNitteiTo());
            stmt.setString(i++, bo.getTeiin());
            stmt.setString(i++, bo.getGenzaiNinzu());
            stmt.setString(i++, bo.getBikoKaijo());
            stmt.setString(i++, bo.getBikoTanto());
            stmt.setString(i++, bo.getKaisaichiCodeKaijoMst());
            stmt.setString(i++, bo.getKoshinKbn());
            stmt.setString(i++, bo.getTorokuDate());
            stmt.setString(i++, bo.getTorokuTime());
            stmt.setString(i++, bo.getTorokuUserId());
            stmt.setString(i++, bo.getKoshinDate());
            stmt.setString(i++, bo.getKoshinTime());
            stmt.setString(i++, bo.getKoshinUserId());
            stmt.setString(i++, bo.getRonriSakujoFlg());

            stmt.setString(i++, bo.getNendo());
            stmt.setString(i++, bo.getSknKsuCode());
            stmt.setString(i++, bo.getShubetsuCode());
            stmt.setString(i++, bo.getKaisuCode());
            stmt.setString(i++, bo.getKaijoId());
            stmt.setString(i++, bo.getKaijoShikenKbn());
            stmt.setString(i++, bo.getKaisaichiCode());
            stmt.setString(i++, bo.getKaijoCode());

            LogGenerate.debugOutput(getSql(stmt));
            if (stmt.executeUpdate() == 0) {
                throw new NoSuchDataException(getSql(stmt));
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt);
        }
    }

    /* (non-Javadoc)
     * @see jp.co.nii.bma.business.domain.GeneratedShiyoKaijoDao#remove(jp.co.nii.bma.business.domain.GeneratedShiyoKaijo)
     */
    @Override
    public void remove(GeneratedShiyoKaijo bo) {
        Connection con = null;
        PreparedStatement stmt = null;
        String sql = "";
        try {
            con = getConnection();
            sql = "DELETE FROM " + getSchemaName() + "." + TABLE_NAME
                    + " WHERE"
                    + " NENDO = ?"
                    + " AND SKN_KSU_CODE = ?"
                    + " AND SHUBETSU_CODE = ?"
                    + " AND KAISU_CODE = ?"
                    + " AND KAIJO_ID = ?"
                    + " AND KAIJO_SHIKEN_KBN = ?"
                    + " AND KAISAICHI_CODE = ?"
                    + " AND KAIJO_CODE = ?";

            stmt = con.prepareStatement(sql);
            int i = 1;
            stmt.setString(i++, bo.getNendo());
            stmt.setString(i++, bo.getSknKsuCode());
            stmt.setString(i++, bo.getShubetsuCode());
            stmt.setString(i++, bo.getKaisuCode());
            stmt.setString(i++, bo.getKaijoId());
            stmt.setString(i++, bo.getKaijoShikenKbn());
            stmt.setString(i++, bo.getKaisaichiCode());
            stmt.setString(i++, bo.getKaijoCode());

            LogGenerate.debugOutput(getSql(stmt));
            if (stmt.executeUpdate() == 0) {
                throw new NoSuchDataException(getSql(stmt));
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt);
        }
    }

    /**
     * �������ʂł���ResultSet��BusinessObject�֋l�ߑւ���B<br>
     * ���O�����F������bo��rs��null�łȂ����ƁB
     * 
     * @param bo BusinessObject�̃C���X�^���X
     * @param rs �������ʂ�ResultSet
     */
    protected void setBoFromResultSet(GeneratedShiyoKaijo bo, ResultSet rs) {
        try {
            bo.setNendo(rs.getString("NENDO"));
            bo.setSknKsuCode(rs.getString("SKN_KSU_CODE"));
            bo.setShubetsuCode(rs.getString("SHUBETSU_CODE"));
            bo.setKaisuCode(rs.getString("KAISU_CODE"));
            bo.setKaijoId(rs.getString("KAIJO_ID"));
            bo.setKaijoShikenKbn(rs.getString("KAIJO_SHIKEN_KBN"));
            bo.setKaisaichiCode(rs.getString("KAISAICHI_CODE"));
            bo.setKaijoCode(rs.getString("KAIJO_CODE"));
            bo.setKaijoName(rs.getString("KAIJO_NAME"));
            bo.setKaijoNameRyaku(rs.getString("KAIJO_NAME_RYAKU"));
            bo.setYubinNo(rs.getString("YUBIN_NO"));
            bo.setJusho(rs.getString("JUSHO"));
            bo.setTantoshaCode(rs.getString("TANTOSHA_CODE"));
            bo.setNitteiFrom(rs.getString("NITTEI_FROM"));
            bo.setNitteiTo(rs.getString("NITTEI_TO"));
            bo.setTeiin(rs.getString("TEIIN"));
            bo.setGenzaiNinzu(rs.getString("GENZAI_NINZU"));
            bo.setBikoKaijo(rs.getString("BIKO_KAIJO"));
            bo.setBikoTanto(rs.getString("BIKO_TANTO"));
            bo.setKaisaichiCodeKaijoMst(rs.getString("KAISAICHI_CODE_KAIJO_MST"));
            bo.setKoshinKbn(rs.getString("KOSHIN_KBN"));
            bo.setTorokuDate(rs.getString("TOROKU_DATE"));
            bo.setTorokuTime(rs.getString("TOROKU_TIME"));
            bo.setTorokuUserId(rs.getString("TOROKU_USER_ID"));
            bo.setKoshinDate(rs.getString("KOSHIN_DATE"));
            bo.setKoshinTime(rs.getString("KOSHIN_TIME"));
            bo.setKoshinUserId(rs.getString("KOSHIN_USER_ID"));
            bo.setRonriSakujoFlg(rs.getString("RONRI_SAKUJO_FLG"));
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(null, ex);
        }
    }
}
