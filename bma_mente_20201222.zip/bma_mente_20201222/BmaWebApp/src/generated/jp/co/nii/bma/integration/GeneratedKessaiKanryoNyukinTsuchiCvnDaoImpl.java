//package jp.co.nii.bma.integration;
//
//import java.sql.Connection;
//import java.sql.PreparedStatement;
//import java.sql.ResultSet;
//import java.sql.SQLException;
//
//import jp.co.nii.sew.business.domain.NoSuchDataException;
//import jp.co.nii.sew.common.LogGenerate;
//import jp.co.nii.sew.integration.AbstractDao;
//import jp.co.nii.sew.integration.SQLStateSQLExceptionTranslater;
//
//import jp.co.nii.bma.business.domain.GeneratedKessaiKanryoNyukinTsuchiCvn;
//import jp.co.nii.bma.business.domain.GeneratedKessaiKanryoNyukinTsuchiCvnDao;
//
///**
// * �������ꂽ ���ϊ��������ʒm�i�R���r�j�j DAO�����N���X<br>
// * table-design-ver 4
// * @author DB�Ǘ��c�[��
// */
//abstract class GeneratedKessaiKanryoNyukinTsuchiCvnDaoImpl extends AbstractDao implements GeneratedKessaiKanryoNyukinTsuchiCvnDao {
//
//    /**
//     * �e�[�u���J�������̃J���}��؂蕶����B<br>
//     * SQL���̍쐬�ɗp����B
//     */
//    protected static final String FIELDS = "NEN"
//            + ",TSUCHI_NO"
//            + ",NYUKIN_BI"
//            + ",NYUKIN_TIME"
//            + ",IP_CODE"
//            + ",TORIHIKI_CODE"
//            + ",KINGAKU"
//            + ",KESSAI_HOHO"
//            + ",MISE_CODE"
//            + ",HUKA_JOHO"
//            + ",RONRI_SAKUJO_FLG"
//            + ",SHORI_KBN"
//            + ",TOROKU_DATE"
//            + ",TOROKU_TIME"
//            + ",TOROKU_USER_ID"
//            + ",TOROKU_PROGRAM_ID"
//            + ",KOSHIN_DATE"
//            + ",KOSHIN_TIME"
//            + ",KOSHIN_USER_ID"
//            + ",KOSHIN_PROGRAM_ID";
//
//    /**
//     * �e�[�u���J�������̃J���}��؂蕶����B<br>
//     *  �Í����Ώۍ��ڂ𕡍�����SQL���̍쐬�ɗp����B
//     */
//    protected static final String FIELDS_DECRYPT = "NEN"
//            + "," + "TSUCHI_NO"
//            + "," + "NYUKIN_BI"
//            + "," + "NYUKIN_TIME"
//            + "," + "IP_CODE"
//            + "," + "TORIHIKI_CODE"
//            + "," + "KINGAKU"
//            + "," + "KESSAI_HOHO"
//            + "," + "MISE_CODE"
//            + "," + "HUKA_JOHO"
//            + "," + "RONRI_SAKUJO_FLG"
//            + "," + "SHORI_KBN"
//            + "," + "TOROKU_DATE"
//            + "," + "TOROKU_TIME"
//            + "," + "TOROKU_USER_ID"
//            + "," + "TOROKU_PROGRAM_ID"
//            + "," + "KOSHIN_DATE"
//            + "," + "KOSHIN_TIME"
//            + "," + "KOSHIN_USER_ID"
//            + "," + "KOSHIN_PROGRAM_ID";
//
//    /**
//     * �C���X�^���X�𐶐�����B<br>
//     * �f�[�^�\�[�X������
//     * @param datasource �f�[�^�\�[�X��
//     */
//    public GeneratedKessaiKanryoNyukinTsuchiCvnDaoImpl(String datasource) {
//        super(datasource);
//    }
//
//    /* (non-Javadoc)
//     * @see jp.co.nii.bma.business.domain.GeneratedKessaiKanryoNyukinTsuchiCvnDao#create(jp.co.nii.bma.business.domain.GeneratedKessaiKanryoNyukinTsuchiCvn)
//     */
//    @Override
//    public void create(GeneratedKessaiKanryoNyukinTsuchiCvn bo) {
//        Connection con = null;
//        PreparedStatement stmt = null;
//        String sql = "";
//        try {
//            con = getConnection();
//            sql = "INSERT INTO " + getSchemaName() + "." + TABLE_NAME + " ( "
//                    + FIELDS
//                    + " ) VALUES ("
//                    + " ?"
//                    + ",?"
//                    + ",?"
//                    + ",?"
//                    + ",?"
//                    + ",?"
//                    + ",?"
//                    + ",?"
//                    + ",?"
//                    + ",?"
//                    + ",?"
//                    + ",?"
//                    + ",?"
//                    + ",?"
//                    + ",?"
//                    + ",?"
//                    + ",?"
//                    + ",?"
//                    + ",?"
//                    + ",?"
//                    + " )";
//
//            stmt = con.prepareStatement(sql);
//            int i = 1;
//            stmt.setString(i++, bo.getNen());
//            stmt.setString(i++, bo.getTsuchiNo());
//            stmt.setString(i++, bo.getNyukinBi());
//            stmt.setString(i++, bo.getNyukinTime());
//            stmt.setString(i++, bo.getIpCode());
//            stmt.setString(i++, bo.getTorihikiCode());
//            stmt.setString(i++, bo.getKingaku());
//            stmt.setString(i++, bo.getKessaiHoho());
//            stmt.setString(i++, bo.getMiseCode());
//            stmt.setString(i++, bo.getHukaJoho());
//            stmt.setString(i++, bo.getRonriSakujoFlg());
//            stmt.setString(i++, bo.getShoriKbn());
//            stmt.setString(i++, bo.getTorokuDate());
//            stmt.setString(i++, bo.getTorokuTime());
//            stmt.setString(i++, bo.getTorokuUserId());
//            stmt.setString(i++, bo.getTorokuProgramId());
//            stmt.setString(i++, bo.getKoshinDate());
//            stmt.setString(i++, bo.getKoshinTime());
//            stmt.setString(i++, bo.getKoshinUserId());
//            stmt.setString(i++, bo.getKoshinProgramId());
//
//            LogGenerate.debugOutput(getSql(stmt));
//            stmt.executeUpdate();
//        } catch (SQLException ex) {
//            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
//        } finally {
//            close(con, stmt);
//        }
//    }
//
//    /* (non-Javadoc)
//     * @see jp.co.nii.bma.business.domain.GeneratedKessaiKanryoNyukinTsuchiCvnDao#find(jp.co.nii.bma.business.domain.GeneratedKessaiKanryoNyukinTsuchiCvn, java.lang.String)
//     */
//    @Override
//    public GeneratedKessaiKanryoNyukinTsuchiCvn find(GeneratedKessaiKanryoNyukinTsuchiCvn bo, String lockMode) {
//        Connection con = null;
//        PreparedStatement stmt = null;
//        ResultSet rs =null;
//        String sql = "";
//        try {
//            con = getConnection();
//            sql = "SELECT " + FIELDS_DECRYPT
//                    + " FROM " + getSchemaName() + "." + TABLE_NAME
//                    + " WHERE"
//                    + " NEN = ?"
//                    + " AND TORIHIKI_CODE = ?";
//
//            stmt = con.prepareStatement(sql + lockMode);
//            int i = 1;
//            stmt.setString(i++, bo.getNen());
//            stmt.setString(i++, bo.getTorihikiCode());
//
//            LogGenerate.debugOutput(getSql(stmt));
//            rs = stmt.executeQuery();
//            if (rs.next()) {
//                setBoFromResultSet(bo, rs);
//            } else {
//                bo = null;
//            }
//        } catch (SQLException ex) {
//            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
//        } finally {
//            close(con, stmt, rs);
//        }
//        return bo;
//    }
//
//    /* (non-Javadoc)
//     * @see jp.co.nii.bma.business.domain.GeneratedKessaiKanryoNyukinTsuchiCvnDao#update(jp.co.nii.bma.business.domain.GeneratedKessaiKanryoNyukinTsuchiCvn)
//     */
//    @Override
//    public void update(GeneratedKessaiKanryoNyukinTsuchiCvn bo) {
//        Connection con = null;
//        PreparedStatement stmt = null;
//        String sql = "";
//        try {
//            con = getConnection();
//            sql = "UPDATE " + getSchemaName() + "." + TABLE_NAME + " SET"
//                    + " TSUCHI_NO = ?"
//                    + ",NYUKIN_BI = ?"
//                    + ",NYUKIN_TIME = ?"
//                    + ",IP_CODE = ?"
//                    + ",KINGAKU = ?"
//                    + ",KESSAI_HOHO = ?"
//                    + ",MISE_CODE = ?"
//                    + ",HUKA_JOHO = ?"
//                    + ",RONRI_SAKUJO_FLG = ?"
//                    + ",SHORI_KBN = ?"
//                    + ",TOROKU_DATE = ?"
//                    + ",TOROKU_TIME = ?"
//                    + ",TOROKU_USER_ID = ?"
//                    + ",TOROKU_PROGRAM_ID = ?"
//                    + ",KOSHIN_DATE = ?"
//                    + ",KOSHIN_TIME = ?"
//                    + ",KOSHIN_USER_ID = ?"
//                    + ",KOSHIN_PROGRAM_ID = ?"
//                    + " WHERE"
//                    + " NEN = ?"
//                    + " AND TORIHIKI_CODE = ?";
//
//            stmt = con.prepareStatement(sql);
//            int i = 1;
//            stmt.setString(i++, bo.getTsuchiNo());
//            stmt.setString(i++, bo.getNyukinBi());
//            stmt.setString(i++, bo.getNyukinTime());
//            stmt.setString(i++, bo.getIpCode());
//            stmt.setString(i++, bo.getKingaku());
//            stmt.setString(i++, bo.getKessaiHoho());
//            stmt.setString(i++, bo.getMiseCode());
//            stmt.setString(i++, bo.getHukaJoho());
//            stmt.setString(i++, bo.getRonriSakujoFlg());
//            stmt.setString(i++, bo.getShoriKbn());
//            stmt.setString(i++, bo.getTorokuDate());
//            stmt.setString(i++, bo.getTorokuTime());
//            stmt.setString(i++, bo.getTorokuUserId());
//            stmt.setString(i++, bo.getTorokuProgramId());
//            stmt.setString(i++, bo.getKoshinDate());
//            stmt.setString(i++, bo.getKoshinTime());
//            stmt.setString(i++, bo.getKoshinUserId());
//            stmt.setString(i++, bo.getKoshinProgramId());
//
//            stmt.setString(i++, bo.getNen());
//            stmt.setString(i++, bo.getTorihikiCode());
//
//            LogGenerate.debugOutput(getSql(stmt));
//            if (stmt.executeUpdate() == 0) {
//                throw new NoSuchDataException(getSql(stmt));
//            }
//        } catch (SQLException ex) {
//            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
//        } finally {
//            close(con, stmt);
//        }
//    }
//
//    /* (non-Javadoc)
//     * @see jp.co.nii.bma.business.domain.GeneratedKessaiKanryoNyukinTsuchiCvnDao#remove(jp.co.nii.bma.business.domain.GeneratedKessaiKanryoNyukinTsuchiCvn)
//     */
//    @Override
//    public void remove(GeneratedKessaiKanryoNyukinTsuchiCvn bo) {
//        Connection con = null;
//        PreparedStatement stmt = null;
//        String sql = "";
//        try {
//            con = getConnection();
//            sql = "DELETE FROM " + getSchemaName() + "." + TABLE_NAME
//                    + " WHERE"
//                    + " NEN = ?"
//                    + " AND TORIHIKI_CODE = ?";
//
//            stmt = con.prepareStatement(sql);
//            int i = 1;
//            stmt.setString(i++, bo.getNen());
//            stmt.setString(i++, bo.getTorihikiCode());
//
//            LogGenerate.debugOutput(getSql(stmt));
//            if (stmt.executeUpdate() == 0) {
//                throw new NoSuchDataException(getSql(stmt));
//            }
//        } catch (SQLException ex) {
//            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
//        } finally {
//            close(con, stmt);
//        }
//    }
//
//    /**
//     * �������ʂł���ResultSet��BusinessObject�֋l�ߑւ���B<br>
//     * ���O�����F������bo��rs��null�łȂ����ƁB
//     * 
//     * @param bo BusinessObject�̃C���X�^���X
//     * @param rs �������ʂ�ResultSet
//     */
//    protected void setBoFromResultSet(GeneratedKessaiKanryoNyukinTsuchiCvn bo, ResultSet rs) {
//        try {
//            bo.setNen(rs.getString("NEN"));
//            bo.setTsuchiNo(rs.getString("TSUCHI_NO"));
//            bo.setNyukinBi(rs.getString("NYUKIN_BI"));
//            bo.setNyukinTime(rs.getString("NYUKIN_TIME"));
//            bo.setIpCode(rs.getString("IP_CODE"));
//            bo.setTorihikiCode(rs.getString("TORIHIKI_CODE"));
//            bo.setKingaku(rs.getString("KINGAKU"));
//            bo.setKessaiHoho(rs.getString("KESSAI_HOHO"));
//            bo.setMiseCode(rs.getString("MISE_CODE"));
//            bo.setHukaJoho(rs.getString("HUKA_JOHO"));
//            bo.setRonriSakujoFlg(rs.getString("RONRI_SAKUJO_FLG"));
//            bo.setShoriKbn(rs.getString("SHORI_KBN"));
//            bo.setTorokuDate(rs.getString("TOROKU_DATE"));
//            bo.setTorokuTime(rs.getString("TOROKU_TIME"));
//            bo.setTorokuUserId(rs.getString("TOROKU_USER_ID"));
//            bo.setTorokuProgramId(rs.getString("TOROKU_PROGRAM_ID"));
//            bo.setKoshinDate(rs.getString("KOSHIN_DATE"));
//            bo.setKoshinTime(rs.getString("KOSHIN_TIME"));
//            bo.setKoshinUserId(rs.getString("KOSHIN_USER_ID"));
//            bo.setKoshinProgramId(rs.getString("KOSHIN_PROGRAM_ID"));
//        } catch (SQLException ex) {
//            throw new SQLStateSQLExceptionTranslater().translate(null, ex);
//        }
//    }
//}
