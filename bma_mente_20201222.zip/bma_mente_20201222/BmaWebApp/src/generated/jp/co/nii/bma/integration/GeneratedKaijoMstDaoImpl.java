package jp.co.nii.bma.integration;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import jp.co.nii.sew.business.domain.NoSuchDataException;
import jp.co.nii.sew.common.LogGenerate;
import jp.co.nii.sew.integration.AbstractDao;
import jp.co.nii.sew.integration.SQLStateSQLExceptionTranslater;

import jp.co.nii.bma.business.domain.GeneratedKaijoMst;
import jp.co.nii.bma.business.domain.GeneratedKaijoMstDao;

/**
 * �������ꂽ ���}�X�^ DAO�����N���X<br>
 * table-design-ver 1
 * @author DB�Ǘ��c�[��
 */
abstract class GeneratedKaijoMstDaoImpl extends AbstractDao implements GeneratedKaijoMstDao {

    /**
     * �e�[�u���J�������̃J���}��؂蕶����B<br>
     * SQL���̍쐬�ɗp����B
     */
    protected static final String FIELDS = "KAISAICHI_CODE"
            + ",KAIJO_CODE"
            + ",KAIJO_NAME"
            + ",KAIJO_NAME_RYAKU"
            + ",YUBIN_NO"
            + ",JUSHO"
            + ",TEIIN"
            + ",KAIJO_HENKO_FLG"
            + ",CHUSHAJO_FLG"
            + ",CHIZU_DATA"
            + ",BIKO"
            + ",KOSHIN_KBN"
            + ",TOROKU_DATE"
            + ",TOROKU_TIME"
            + ",TOROKU_USER_ID"
            + ",KOSHIN_DATE"
            + ",KOSHIN_TIME"
            + ",KOSHIN_USER_ID"
            + ",RONRI_SAKUJO_FLG";

    /**
     * �e�[�u���J�������̃J���}��؂蕶����B<br>
     *  �Í����Ώۍ��ڂ𕡍�����SQL���̍쐬�ɗp����B
     */
    protected static final String FIELDS_DECRYPT = "KAISAICHI_CODE"
            + "," + "KAIJO_CODE"
            + "," + "KAIJO_NAME"
            + "," + "KAIJO_NAME_RYAKU"
            + "," + "YUBIN_NO"
            + "," + "JUSHO"
            + "," + "TEIIN"
            + "," + "KAIJO_HENKO_FLG"
            + "," + "CHUSHAJO_FLG"
            + "," + "CHIZU_DATA"
            + "," + "BIKO"
            + "," + "KOSHIN_KBN"
            + "," + "TOROKU_DATE"
            + "," + "TOROKU_TIME"
            + "," + "TOROKU_USER_ID"
            + "," + "KOSHIN_DATE"
            + "," + "KOSHIN_TIME"
            + "," + "KOSHIN_USER_ID"
            + "," + "RONRI_SAKUJO_FLG";

    /**
     * �C���X�^���X�𐶐�����B<br>
     * �f�[�^�\�[�X������
     * @param datasource �f�[�^�\�[�X��
     */
    public GeneratedKaijoMstDaoImpl(String datasource) {
        super(datasource);
    }

    /* (non-Javadoc)
     * @see jp.co.nii.bma.business.domain.GeneratedKaijoMstDao#create(jp.co.nii.bma.business.domain.GeneratedKaijoMst)
     */
    @Override
    public void create(GeneratedKaijoMst bo) {
        Connection con = null;
        PreparedStatement stmt = null;
        String sql = "";
        try {
            con = getConnection();
            sql = "INSERT INTO " + getSchemaName() + "." + TABLE_NAME + " ( "
                    + FIELDS
                    + " ) VALUES ("
                    + " ?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + " )";

            stmt = con.prepareStatement(sql);
            int i = 1;
            stmt.setString(i++, bo.getKaisaichiCode());
            stmt.setString(i++, bo.getKaijoCode());
            stmt.setString(i++, bo.getKaijoName());
            stmt.setString(i++, bo.getKaijoNameRyaku());
            stmt.setString(i++, bo.getYubinNo());
            stmt.setString(i++, bo.getJusho());
            stmt.setString(i++, bo.getTeiin());
            stmt.setString(i++, bo.getKaijoHenkoFlg());
            stmt.setString(i++, bo.getChushajoFlg());
            stmt.setString(i++, bo.getChizuData());
            stmt.setString(i++, bo.getBiko());
            stmt.setString(i++, bo.getKoshinKbn());
            stmt.setString(i++, bo.getTorokuDate());
            stmt.setString(i++, bo.getTorokuTime());
            stmt.setString(i++, bo.getTorokuUserId());
            stmt.setString(i++, bo.getKoshinDate());
            stmt.setString(i++, bo.getKoshinTime());
            stmt.setString(i++, bo.getKoshinUserId());
            stmt.setString(i++, bo.getRonriSakujoFlg());

            LogGenerate.debugOutput(getSql(stmt));
            stmt.executeUpdate();
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt);
        }
    }

    /* (non-Javadoc)
     * @see jp.co.nii.bma.business.domain.GeneratedKaijoMstDao#find(jp.co.nii.bma.business.domain.GeneratedKaijoMst, java.lang.String)
     */
    @Override
    public GeneratedKaijoMst find(GeneratedKaijoMst bo, String lockMode) {
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs =null;
        String sql = "";
        try {
            con = getConnection();
            sql = "SELECT " + FIELDS_DECRYPT
                    + " FROM " + getSchemaName() + "." + TABLE_NAME
                    + " WHERE"
                    + " KAISAICHI_CODE = ?"
                    + " AND KAIJO_CODE = ?";

            stmt = con.prepareStatement(sql + lockMode);
            int i = 1;
            stmt.setString(i++, bo.getKaisaichiCode());
            stmt.setString(i++, bo.getKaijoCode());

            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();
            if (rs.next()) {
                setBoFromResultSet(bo, rs);
            } else {
                bo = null;
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return bo;
    }

    /* (non-Javadoc)
     * @see jp.co.nii.bma.business.domain.GeneratedKaijoMstDao#update(jp.co.nii.bma.business.domain.GeneratedKaijoMst)
     */
    @Override
    public void update(GeneratedKaijoMst bo) {
        Connection con = null;
        PreparedStatement stmt = null;
        String sql = "";
        try {
            con = getConnection();
            sql = "UPDATE " + getSchemaName() + "." + TABLE_NAME + " SET"
                    + " KAIJO_NAME = ?"
                    + ",KAIJO_NAME_RYAKU = ?"
                    + ",YUBIN_NO = ?"
                    + ",JUSHO = ?"
                    + ",TEIIN = ?"
                    + ",KAIJO_HENKO_FLG = ?"
                    + ",CHUSHAJO_FLG = ?"
                    + ",CHIZU_DATA = ?"
                    + ",BIKO = ?"
                    + ",KOSHIN_KBN = ?"
                    + ",TOROKU_DATE = ?"
                    + ",TOROKU_TIME = ?"
                    + ",TOROKU_USER_ID = ?"
                    + ",KOSHIN_DATE = ?"
                    + ",KOSHIN_TIME = ?"
                    + ",KOSHIN_USER_ID = ?"
                    + ",RONRI_SAKUJO_FLG = ?"
                    + " WHERE"
                    + " KAISAICHI_CODE = ?"
                    + " AND KAIJO_CODE = ?";

            stmt = con.prepareStatement(sql);
            int i = 1;
            stmt.setString(i++, bo.getKaijoName());
            stmt.setString(i++, bo.getKaijoNameRyaku());
            stmt.setString(i++, bo.getYubinNo());
            stmt.setString(i++, bo.getJusho());
            stmt.setString(i++, bo.getTeiin());
            stmt.setString(i++, bo.getKaijoHenkoFlg());
            stmt.setString(i++, bo.getChushajoFlg());
            stmt.setString(i++, bo.getChizuData());
            stmt.setString(i++, bo.getBiko());
            stmt.setString(i++, bo.getKoshinKbn());
            stmt.setString(i++, bo.getTorokuDate());
            stmt.setString(i++, bo.getTorokuTime());
            stmt.setString(i++, bo.getTorokuUserId());
            stmt.setString(i++, bo.getKoshinDate());
            stmt.setString(i++, bo.getKoshinTime());
            stmt.setString(i++, bo.getKoshinUserId());
            stmt.setString(i++, bo.getRonriSakujoFlg());

            stmt.setString(i++, bo.getKaisaichiCode());
            stmt.setString(i++, bo.getKaijoCode());

            LogGenerate.debugOutput(getSql(stmt));
            if (stmt.executeUpdate() == 0) {
                throw new NoSuchDataException(getSql(stmt));
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt);
        }
    }

    /* (non-Javadoc)
     * @see jp.co.nii.bma.business.domain.GeneratedKaijoMstDao#remove(jp.co.nii.bma.business.domain.GeneratedKaijoMst)
     */
    @Override
    public void remove(GeneratedKaijoMst bo) {
        Connection con = null;
        PreparedStatement stmt = null;
        String sql = "";
        try {
            con = getConnection();
            sql = "DELETE FROM " + getSchemaName() + "." + TABLE_NAME
                    + " WHERE"
                    + " KAISAICHI_CODE = ?"
                    + " AND KAIJO_CODE = ?";

            stmt = con.prepareStatement(sql);
            int i = 1;
            stmt.setString(i++, bo.getKaisaichiCode());
            stmt.setString(i++, bo.getKaijoCode());

            LogGenerate.debugOutput(getSql(stmt));
            if (stmt.executeUpdate() == 0) {
                throw new NoSuchDataException(getSql(stmt));
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt);
        }
    }

    /**
     * �������ʂł���ResultSet��BusinessObject�֋l�ߑւ���B<br>
     * ���O�����F������bo��rs��null�łȂ����ƁB
     * 
     * @param bo BusinessObject�̃C���X�^���X
     * @param rs �������ʂ�ResultSet
     */
    protected void setBoFromResultSet(GeneratedKaijoMst bo, ResultSet rs) {
        try {
            bo.setKaisaichiCode(rs.getString("KAISAICHI_CODE"));
            bo.setKaijoCode(rs.getString("KAIJO_CODE"));
            bo.setKaijoName(rs.getString("KAIJO_NAME"));
            bo.setKaijoNameRyaku(rs.getString("KAIJO_NAME_RYAKU"));
            bo.setYubinNo(rs.getString("YUBIN_NO"));
            bo.setJusho(rs.getString("JUSHO"));
            bo.setTeiin(rs.getString("TEIIN"));
            bo.setKaijoHenkoFlg(rs.getString("KAIJO_HENKO_FLG"));
            bo.setChushajoFlg(rs.getString("CHUSHAJO_FLG"));
            bo.setChizuData(rs.getString("CHIZU_DATA"));
            bo.setBiko(rs.getString("BIKO"));
            bo.setKoshinKbn(rs.getString("KOSHIN_KBN"));
            bo.setTorokuDate(rs.getString("TOROKU_DATE"));
            bo.setTorokuTime(rs.getString("TOROKU_TIME"));
            bo.setTorokuUserId(rs.getString("TOROKU_USER_ID"));
            bo.setKoshinDate(rs.getString("KOSHIN_DATE"));
            bo.setKoshinTime(rs.getString("KOSHIN_TIME"));
            bo.setKoshinUserId(rs.getString("KOSHIN_USER_ID"));
            bo.setRonriSakujoFlg(rs.getString("RONRI_SAKUJO_FLG"));
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(null, ex);
        }
    }
}
