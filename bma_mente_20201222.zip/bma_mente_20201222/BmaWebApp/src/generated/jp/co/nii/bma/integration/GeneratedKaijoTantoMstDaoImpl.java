package jp.co.nii.bma.integration;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import jp.co.nii.sew.business.domain.NoSuchDataException;
import jp.co.nii.sew.common.LogGenerate;
import jp.co.nii.sew.integration.AbstractDao;
import jp.co.nii.sew.integration.SQLStateSQLExceptionTranslater;

import jp.co.nii.bma.business.domain.GeneratedKaijoTantoMst;
import jp.co.nii.bma.business.domain.GeneratedKaijoTantoMstDao;

/**
 * �������ꂽ ���S���҃}�X�^ DAO�����N���X<br>
 * table-design-ver 4
 * @author DB�Ǘ��c�[��
 */
abstract class GeneratedKaijoTantoMstDaoImpl extends AbstractDao implements GeneratedKaijoTantoMstDao {

    /**
     * �e�[�u���J�������̃J���}��؂蕶����B<br>
     * SQL���̍쐬�ɗp����B
     */
    protected static final String FIELDS = "KAISAICHI_CODE"
            + ",KAIJO_CODE"
            + ",TANTOSHA_CODE"
            + ",TANTOSHA"
            + ",TANTO_BUSHO"
            + ",TEL_NO"
            + ",FAX_NO"
            + ",TANTOSHA_MAIL_ADDRESS"
            + ",BIKO"
            + ",KOSHIN_KBN"
            + ",TOROKU_DATE"
            + ",TOROKU_TIME"
            + ",TOROKU_USER_ID"
            + ",KOSHIN_DATE"
            + ",KOSHIN_TIME"
            + ",KOSHIN_USER_ID"
            + ",RONRI_SAKUJO_FLG";

    /**
     * �e�[�u���J�������̃J���}��؂蕶����B<br>
     *  �Í����Ώۍ��ڂ𕡍�����SQL���̍쐬�ɗp����B
     */
    protected static final String FIELDS_DECRYPT = "KAISAICHI_CODE"
            + "," + "KAIJO_CODE"
            + "," + "TANTOSHA_CODE"
            + "," + getSQLForDecryptByUTF8("TANTOSHA")
            + "," + getSQLForDecryptByUTF8("TANTO_BUSHO")
            + "," + getSQLForDecryptByUTF8("TEL_NO")
            + "," + getSQLForDecryptByUTF8("FAX_NO")
            + "," + getSQLForDecryptByUTF8("TANTOSHA_MAIL_ADDRESS")
            + "," + "BIKO"
            + "," + "KOSHIN_KBN"
            + "," + "TOROKU_DATE"
            + "," + "TOROKU_TIME"
            + "," + "TOROKU_USER_ID"
            + "," + "KOSHIN_DATE"
            + "," + "KOSHIN_TIME"
            + "," + "KOSHIN_USER_ID"
            + "," + "RONRI_SAKUJO_FLG";

    /**
     * �C���X�^���X�𐶐�����B<br>
     * �f�[�^�\�[�X������
     * @param datasource �f�[�^�\�[�X��
     */
    public GeneratedKaijoTantoMstDaoImpl(String datasource) {
        super(datasource);
    }

    /* (non-Javadoc)
     * @see jp.co.nii.bma.business.domain.GeneratedKaijoTantoMstDao#create(jp.co.nii.bma.business.domain.GeneratedKaijoTantoMst)
     */
    @Override
    public void create(GeneratedKaijoTantoMst bo) {
        Connection con = null;
        PreparedStatement stmt = null;
        String sql = "";
        try {
            con = getConnection();
            sql = "INSERT INTO " + getSchemaName() + "." + TABLE_NAME + " ( "
                    + FIELDS
                    + " ) VALUES ("
                    + " ?"
                    + ",?"
                    + ",?"
                    + "," + getSQLForEncryptByUTF8("?")
                    + "," + getSQLForEncryptByUTF8("?")
                    + "," + getSQLForEncryptByUTF8("?")
                    + "," + getSQLForEncryptByUTF8("?")
                    + "," + getSQLForEncryptByUTF8("?")
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + " )";

            stmt = con.prepareStatement(sql);
            int i = 1;
            stmt.setString(i++, bo.getKaisaichiCode());
            stmt.setString(i++, bo.getKaijoCode());
            stmt.setString(i++, bo.getTantoshaCode());
            stmt.setString(i++, bo.getTantosha());
            stmt.setString(i++, bo.getTantoBusho());
            stmt.setString(i++, bo.getTelNo());
            stmt.setString(i++, bo.getFaxNo());
            stmt.setString(i++, bo.getTantoshaMailAddress());
            stmt.setString(i++, bo.getBiko());
            stmt.setString(i++, bo.getKoshinKbn());
            stmt.setString(i++, bo.getTorokuDate());
            stmt.setString(i++, bo.getTorokuTime());
            stmt.setString(i++, bo.getTorokuUserId());
            stmt.setString(i++, bo.getKoshinDate());
            stmt.setString(i++, bo.getKoshinTime());
            stmt.setString(i++, bo.getKoshinUserId());
            stmt.setString(i++, bo.getRonriSakujoFlg());

            LogGenerate.debugOutput(getSql(stmt));
            stmt.executeUpdate();
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt);
        }
    }

    /* (non-Javadoc)
     * @see jp.co.nii.bma.business.domain.GeneratedKaijoTantoMstDao#find(jp.co.nii.bma.business.domain.GeneratedKaijoTantoMst, java.lang.String)
     */
    @Override
    public GeneratedKaijoTantoMst find(GeneratedKaijoTantoMst bo, String lockMode) {
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs =null;
        String sql = "";
        try {
            con = getConnection();
            sql = "SELECT " + FIELDS_DECRYPT
                    + " FROM " + getSchemaName() + "." + TABLE_NAME
                    + " WHERE"
                    + " KAISAICHI_CODE = ?"
                    + " AND KAIJO_CODE = ?"
                    + " AND TANTOSHA_CODE = ?";

            stmt = con.prepareStatement(sql + lockMode);
            int i = 1;
            stmt.setString(i++, bo.getKaisaichiCode());
            stmt.setString(i++, bo.getKaijoCode());
            stmt.setString(i++, bo.getTantoshaCode());

            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();
            if (rs.next()) {
                setBoFromResultSet(bo, rs);
            } else {
                bo = null;
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return bo;
    }

    /* (non-Javadoc)
     * @see jp.co.nii.bma.business.domain.GeneratedKaijoTantoMstDao#update(jp.co.nii.bma.business.domain.GeneratedKaijoTantoMst)
     */
    @Override
    public void update(GeneratedKaijoTantoMst bo) {
        Connection con = null;
        PreparedStatement stmt = null;
        String sql = "";
        try {
            con = getConnection();
            sql = "UPDATE " + getSchemaName() + "." + TABLE_NAME + " SET"
                    + " TANTOSHA = " + getSQLForEncryptByUTF8("?")
                    + ",TANTO_BUSHO = " + getSQLForEncryptByUTF8("?")
                    + ",TEL_NO = " + getSQLForEncryptByUTF8("?")
                    + ",FAX_NO = " + getSQLForEncryptByUTF8("?")
                    + ",TANTOSHA_MAIL_ADDRESS = " + getSQLForEncryptByUTF8("?")
                    + ",BIKO = ?"
                    + ",KOSHIN_KBN = ?"
                    + ",TOROKU_DATE = ?"
                    + ",TOROKU_TIME = ?"
                    + ",TOROKU_USER_ID = ?"
                    + ",KOSHIN_DATE = ?"
                    + ",KOSHIN_TIME = ?"
                    + ",KOSHIN_USER_ID = ?"
                    + ",RONRI_SAKUJO_FLG = ?"
                    + " WHERE"
                    + " KAISAICHI_CODE = ?"
                    + " AND KAIJO_CODE = ?"
                    + " AND TANTOSHA_CODE = ?";

            stmt = con.prepareStatement(sql);
            int i = 1;
            stmt.setString(i++, bo.getTantosha());
            stmt.setString(i++, bo.getTantoBusho());
            stmt.setString(i++, bo.getTelNo());
            stmt.setString(i++, bo.getFaxNo());
            stmt.setString(i++, bo.getTantoshaMailAddress());
            stmt.setString(i++, bo.getBiko());
            stmt.setString(i++, bo.getKoshinKbn());
            stmt.setString(i++, bo.getTorokuDate());
            stmt.setString(i++, bo.getTorokuTime());
            stmt.setString(i++, bo.getTorokuUserId());
            stmt.setString(i++, bo.getKoshinDate());
            stmt.setString(i++, bo.getKoshinTime());
            stmt.setString(i++, bo.getKoshinUserId());
            stmt.setString(i++, bo.getRonriSakujoFlg());

            stmt.setString(i++, bo.getKaisaichiCode());
            stmt.setString(i++, bo.getKaijoCode());
            stmt.setString(i++, bo.getTantoshaCode());

            LogGenerate.debugOutput(getSql(stmt));
            if (stmt.executeUpdate() == 0) {
                throw new NoSuchDataException(getSql(stmt));
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt);
        }
    }

    /* (non-Javadoc)
     * @see jp.co.nii.bma.business.domain.GeneratedKaijoTantoMstDao#remove(jp.co.nii.bma.business.domain.GeneratedKaijoTantoMst)
     */
    @Override
    public void remove(GeneratedKaijoTantoMst bo) {
        Connection con = null;
        PreparedStatement stmt = null;
        String sql = "";
        try {
            con = getConnection();
            sql = "DELETE FROM " + getSchemaName() + "." + TABLE_NAME
                    + " WHERE"
                    + " KAISAICHI_CODE = ?"
                    + " AND KAIJO_CODE = ?"
                    + " AND TANTOSHA_CODE = ?";

            stmt = con.prepareStatement(sql);
            int i = 1;
            stmt.setString(i++, bo.getKaisaichiCode());
            stmt.setString(i++, bo.getKaijoCode());
            stmt.setString(i++, bo.getTantoshaCode());

            LogGenerate.debugOutput(getSql(stmt));
            if (stmt.executeUpdate() == 0) {
                throw new NoSuchDataException(getSql(stmt));
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt);
        }
    }

    /**
     * �������ʂł���ResultSet��BusinessObject�֋l�ߑւ���B<br>
     * ���O�����F������bo��rs��null�łȂ����ƁB
     * 
     * @param bo BusinessObject�̃C���X�^���X
     * @param rs �������ʂ�ResultSet
     */
    protected void setBoFromResultSet(GeneratedKaijoTantoMst bo, ResultSet rs) {
        try {
            bo.setKaisaichiCode(rs.getString("KAISAICHI_CODE"));
            bo.setKaijoCode(rs.getString("KAIJO_CODE"));
            bo.setTantoshaCode(rs.getString("TANTOSHA_CODE"));
            bo.setTantosha(rs.getString("TANTOSHA"));
            bo.setTantoBusho(rs.getString("TANTO_BUSHO"));
            bo.setTelNo(rs.getString("TEL_NO"));
            bo.setFaxNo(rs.getString("FAX_NO"));
            bo.setTantoshaMailAddress(rs.getString("TANTOSHA_MAIL_ADDRESS"));
            bo.setBiko(rs.getString("BIKO"));
            bo.setKoshinKbn(rs.getString("KOSHIN_KBN"));
            bo.setTorokuDate(rs.getString("TOROKU_DATE"));
            bo.setTorokuTime(rs.getString("TOROKU_TIME"));
            bo.setTorokuUserId(rs.getString("TOROKU_USER_ID"));
            bo.setKoshinDate(rs.getString("KOSHIN_DATE"));
            bo.setKoshinTime(rs.getString("KOSHIN_TIME"));
            bo.setKoshinUserId(rs.getString("KOSHIN_USER_ID"));
            bo.setRonriSakujoFlg(rs.getString("RONRI_SAKUJO_FLG"));
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(null, ex);
        }
    }
}
