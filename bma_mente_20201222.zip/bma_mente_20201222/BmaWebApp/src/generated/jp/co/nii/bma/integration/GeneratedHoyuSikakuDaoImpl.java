//package jp.co.nii.bma.integration;
//
//import java.sql.Connection;
//import java.sql.PreparedStatement;
//import java.sql.ResultSet;
//import java.sql.SQLException;
//
//import jp.co.nii.sew.business.domain.NoSuchDataException;
//import jp.co.nii.sew.common.LogGenerate;
//import jp.co.nii.sew.integration.AbstractDao;
//import jp.co.nii.sew.integration.SQLStateSQLExceptionTranslater;
//
//import jp.co.nii.bma.business.domain.GeneratedHoyuSikaku;
//import jp.co.nii.bma.business.domain.GeneratedHoyuSikakuDao;
//
///**
// * �������ꂽ �ۗL���i DAO�����N���X<br>
// * table-design-ver 1
// * @author DB�Ǘ��c�[��
// */
//abstract class GeneratedHoyuSikakuDaoImpl extends AbstractDao implements GeneratedHoyuSikakuDao {
//
//    /**
//     * �e�[�u���J�������̃J���}��؂蕶����B<br>
//     * SQL���̍쐬�ɗp����B
//     */
//    protected static final String FIELDS = "MOSHIKOMISHA_ID"
//            + ",SHIKAKU_CODE"
//            + ",GOKAKU_NO"
//            + ",GOKAKU_NENGETSU"
//            + ",SHUTOKU_NENGETSU"
//            + ",KOSHIN_KBN"
//            + ",TOROKU_DATE"
//            + ",TOROKU_TIME"
//            + ",TOROKU_USER_ID"
//            + ",KOSHIN_DATE"
//            + ",KOSHIN_TIME"
//            + ",KOSHIN_USER_ID"
//            + ",RONRI_SAKUJO_FLG";
//
//    /**
//     * �e�[�u���J�������̃J���}��؂蕶����B<br>
//     *  �Í����Ώۍ��ڂ𕡍�����SQL���̍쐬�ɗp����B
//     */
//    protected static final String FIELDS_DECRYPT = "MOSHIKOMISHA_ID"
//            + "," + "SHIKAKU_CODE"
//            + "," + "GOKAKU_NO"
//            + "," + "GOKAKU_NENGETSU"
//            + "," + "SHUTOKU_NENGETSU"
//            + "," + "KOSHIN_KBN"
//            + "," + "TOROKU_DATE"
//            + "," + "TOROKU_TIME"
//            + "," + "TOROKU_USER_ID"
//            + "," + "KOSHIN_DATE"
//            + "," + "KOSHIN_TIME"
//            + "," + "KOSHIN_USER_ID"
//            + "," + "RONRI_SAKUJO_FLG";
//
//    /**
//     * �C���X�^���X�𐶐�����B<br>
//     * �f�[�^�\�[�X������
//     * @param datasource �f�[�^�\�[�X��
//     */
//    public GeneratedHoyuSikakuDaoImpl(String datasource) {
//        super(datasource);
//    }
//
//    /* (non-Javadoc)
//     * @see jp.co.nii.bma.business.domain.GeneratedHoyuSikakuDao#create(jp.co.nii.bma.business.domain.GeneratedHoyuSikaku)
//     */
//    @Override
//    public void create(GeneratedHoyuSikaku bo) {
//        Connection con = null;
//        PreparedStatement stmt = null;
//        String sql = "";
//        try {
//            con = getConnection();
//            sql = "INSERT INTO " + getSchemaName() + "." + TABLE_NAME + " ( "
//                    + FIELDS
//                    + " ) VALUES ("
//                    + " ?"
//                    + ",?"
//                    + ",?"
//                    + ",?"
//                    + ",?"
//                    + ",?"
//                    + ",?"
//                    + ",?"
//                    + ",?"
//                    + ",?"
//                    + ",?"
//                    + ",?"
//                    + ",?"
//                    + " )";
//
//            stmt = con.prepareStatement(sql);
//            int i = 1;
//            stmt.setString(i++, bo.getMoshikomishaId());
//            stmt.setString(i++, bo.getShikakuCode());
//            stmt.setString(i++, bo.getGokakuNo());
//            stmt.setString(i++, bo.getGokakuNengetsu());
//            stmt.setString(i++, bo.getShutokuNengetsu());
//            stmt.setString(i++, bo.getKoshinKbn());
//            stmt.setString(i++, bo.getTorokuDate());
//            stmt.setString(i++, bo.getTorokuTime());
//            stmt.setString(i++, bo.getTorokuUserId());
//            stmt.setString(i++, bo.getKoshinDate());
//            stmt.setString(i++, bo.getKoshinTime());
//            stmt.setString(i++, bo.getKoshinUserId());
//            stmt.setString(i++, bo.getRonriSakujoFlg());
//
//            LogGenerate.debugOutput(getSql(stmt));
//            stmt.executeUpdate();
//        } catch (SQLException ex) {
//            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
//        } finally {
//            close(con, stmt);
//        }
//    }
//
//    /* (non-Javadoc)
//     * @see jp.co.nii.bma.business.domain.GeneratedHoyuSikakuDao#find(jp.co.nii.bma.business.domain.GeneratedHoyuSikaku, java.lang.String)
//     */
//    @Override
//    public GeneratedHoyuSikaku find(GeneratedHoyuSikaku bo, String lockMode) {
//        Connection con = null;
//        PreparedStatement stmt = null;
//        ResultSet rs =null;
//        String sql = "";
//        try {
//            con = getConnection();
//            sql = "SELECT " + FIELDS_DECRYPT
//                    + " FROM " + getSchemaName() + "." + TABLE_NAME
//                    + " WHERE"
//                    + " MOSHIKOMISHA_ID = ?"
//                    + " AND SHIKAKU_CODE = ?";
//
//            stmt = con.prepareStatement(sql + lockMode);
//            int i = 1;
//            stmt.setString(i++, bo.getMoshikomishaId());
//            stmt.setString(i++, bo.getShikakuCode());
//
//            LogGenerate.debugOutput(getSql(stmt));
//            rs = stmt.executeQuery();
//            if (rs.next()) {
//                setBoFromResultSet(bo, rs);
//            } else {
//                bo = null;
//            }
//        } catch (SQLException ex) {
//            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
//        } finally {
//            close(con, stmt, rs);
//        }
//        return bo;
//    }
//
//    /* (non-Javadoc)
//     * @see jp.co.nii.bma.business.domain.GeneratedHoyuSikakuDao#update(jp.co.nii.bma.business.domain.GeneratedHoyuSikaku)
//     */
//    @Override
//    public void update(GeneratedHoyuSikaku bo) {
//        Connection con = null;
//        PreparedStatement stmt = null;
//        String sql = "";
//        try {
//            con = getConnection();
//            sql = "UPDATE " + getSchemaName() + "." + TABLE_NAME + " SET"
//                    + " GOKAKU_NO = ?"
//                    + ",GOKAKU_NENGETSU = ?"
//                    + ",SHUTOKU_NENGETSU = ?"
//                    + ",KOSHIN_KBN = ?"
//                    + ",TOROKU_DATE = ?"
//                    + ",TOROKU_TIME = ?"
//                    + ",TOROKU_USER_ID = ?"
//                    + ",KOSHIN_DATE = ?"
//                    + ",KOSHIN_TIME = ?"
//                    + ",KOSHIN_USER_ID = ?"
//                    + ",RONRI_SAKUJO_FLG = ?"
//                    + " WHERE"
//                    + " MOSHIKOMISHA_ID = ?"
//                    + " AND SHIKAKU_CODE = ?";
//
//            stmt = con.prepareStatement(sql);
//            int i = 1;
//            stmt.setString(i++, bo.getGokakuNo());
//            stmt.setString(i++, bo.getGokakuNengetsu());
//            stmt.setString(i++, bo.getShutokuNengetsu());
//            stmt.setString(i++, bo.getKoshinKbn());
//            stmt.setString(i++, bo.getTorokuDate());
//            stmt.setString(i++, bo.getTorokuTime());
//            stmt.setString(i++, bo.getTorokuUserId());
//            stmt.setString(i++, bo.getKoshinDate());
//            stmt.setString(i++, bo.getKoshinTime());
//            stmt.setString(i++, bo.getKoshinUserId());
//            stmt.setString(i++, bo.getRonriSakujoFlg());
//
//            stmt.setString(i++, bo.getMoshikomishaId());
//            stmt.setString(i++, bo.getShikakuCode());
//
//            LogGenerate.debugOutput(getSql(stmt));
//            if (stmt.executeUpdate() == 0) {
//                throw new NoSuchDataException(getSql(stmt));
//            }
//        } catch (SQLException ex) {
//            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
//        } finally {
//            close(con, stmt);
//        }
//    }
//
//    /* (non-Javadoc)
//     * @see jp.co.nii.bma.business.domain.GeneratedHoyuSikakuDao#remove(jp.co.nii.bma.business.domain.GeneratedHoyuSikaku)
//     */
//    @Override
//    public void remove(GeneratedHoyuSikaku bo) {
//        Connection con = null;
//        PreparedStatement stmt = null;
//        String sql = "";
//        try {
//            con = getConnection();
//            sql = "DELETE FROM " + getSchemaName() + "." + TABLE_NAME
//                    + " WHERE"
//                    + " MOSHIKOMISHA_ID = ?"
//                    + " AND SHIKAKU_CODE = ?";
//
//            stmt = con.prepareStatement(sql);
//            int i = 1;
//            stmt.setString(i++, bo.getMoshikomishaId());
//            stmt.setString(i++, bo.getShikakuCode());
//
//            LogGenerate.debugOutput(getSql(stmt));
//            if (stmt.executeUpdate() == 0) {
//                throw new NoSuchDataException(getSql(stmt));
//            }
//        } catch (SQLException ex) {
//            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
//        } finally {
//            close(con, stmt);
//        }
//    }
//
//    /**
//     * �������ʂł���ResultSet��BusinessObject�֋l�ߑւ���B<br>
//     * ���O�����F������bo��rs��null�łȂ����ƁB
//     * 
//     * @param bo BusinessObject�̃C���X�^���X
//     * @param rs �������ʂ�ResultSet
//     */
//    protected void setBoFromResultSet(GeneratedHoyuSikaku bo, ResultSet rs) {
//        try {
//            bo.setMoshikomishaId(rs.getString("MOSHIKOMISHA_ID"));
//            bo.setShikakuCode(rs.getString("SHIKAKU_CODE"));
//            bo.setGokakuNo(rs.getString("GOKAKU_NO"));
//            bo.setGokakuNengetsu(rs.getString("GOKAKU_NENGETSU"));
//            bo.setShutokuNengetsu(rs.getString("SHUTOKU_NENGETSU"));
//            bo.setKoshinKbn(rs.getString("KOSHIN_KBN"));
//            bo.setTorokuDate(rs.getString("TOROKU_DATE"));
//            bo.setTorokuTime(rs.getString("TOROKU_TIME"));
//            bo.setTorokuUserId(rs.getString("TOROKU_USER_ID"));
//            bo.setKoshinDate(rs.getString("KOSHIN_DATE"));
//            bo.setKoshinTime(rs.getString("KOSHIN_TIME"));
//            bo.setKoshinUserId(rs.getString("KOSHIN_USER_ID"));
//            bo.setRonriSakujoFlg(rs.getString("RONRI_SAKUJO_FLG"));
//        } catch (SQLException ex) {
//            throw new SQLStateSQLExceptionTranslater().translate(null, ex);
//        }
//    }
//}
