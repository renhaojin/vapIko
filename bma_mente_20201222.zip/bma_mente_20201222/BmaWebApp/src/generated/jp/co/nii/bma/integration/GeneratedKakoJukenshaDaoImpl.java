//package jp.co.nii.bma.integration;
//
//import java.sql.Connection;
//import java.sql.PreparedStatement;
//import java.sql.ResultSet;
//import java.sql.SQLException;
//
//import jp.co.nii.sew.business.domain.NoSuchDataException;
//import jp.co.nii.sew.common.LogGenerate;
//import jp.co.nii.sew.integration.AbstractDao;
//import jp.co.nii.sew.integration.SQLStateSQLExceptionTranslater;
//
//import jp.co.nii.bma.business.domain.GeneratedKakoJukensha;
//import jp.co.nii.bma.business.domain.GeneratedKakoJukenshaDao;
//
///**
// * �������ꂽ �ߋ��󌱎� DAO�����N���X<br>
// * table-design-ver 1
// * @author DB�Ǘ��c�[��
// */
//abstract class GeneratedKakoJukenshaDaoImpl extends AbstractDao implements GeneratedKakoJukenshaDao {
//
//    /**
//     * �e�[�u���J�������̃J���}��؂蕶����B<br>
//     * SQL���̍쐬�ɗp����B
//     */
//    protected static final String FIELDS = "KAKO_JUKEN_NEN"
//            + ",KAKO_JUKEN_NO"
//            + ",KOJIN_JOHO_KAHI_KBN"
//            + ",SHIMEI_SEI_KANA"
//            + ",SHIMEI_MEI_KANA"
//            + ",BIRTHDAY"
//            + ",GAKKA_GOKAKU_NEN"
//            + ",GAKKA_GOKAKUJI_JUKEN_NO"
//            + ",JUKEN_SHIKAKU_JOHO_FLG"
//            + ",RONRI_SAKUJO_FLG"
//            + ",SHORI_KBN"
//            + ",TOROKU_DATE"
//            + ",TOROKU_TIME"
//            + ",TOROKU_USER_ID"
//            + ",TOROKU_PROGRAM_ID"
//            + ",KOSHIN_DATE"
//            + ",KOSHIN_TIME"
//            + ",KOSHIN_USER_ID"
//            + ",KOSHIN_PROGRAM_ID";
//
//    /**
//     * �e�[�u���J�������̃J���}��؂蕶����B<br>
//     *  �Í����Ώۍ��ڂ𕡍�����SQL���̍쐬�ɗp����B
//     */
//    protected static final String FIELDS_DECRYPT = "KAKO_JUKEN_NEN"
//            + "," + "KAKO_JUKEN_NO"
//            + "," + "KOJIN_JOHO_KAHI_KBN"
//            + "," + "SHIMEI_SEI_KANA"
//            + "," + "SHIMEI_MEI_KANA"
//            + "," + "BIRTHDAY"
//            + "," + "GAKKA_GOKAKU_NEN"
//            + "," + "GAKKA_GOKAKUJI_JUKEN_NO"
//            + "," + "JUKEN_SHIKAKU_JOHO_FLG"
//            + "," + "RONRI_SAKUJO_FLG"
//            + "," + "SHORI_KBN"
//            + "," + "TOROKU_DATE"
//            + "," + "TOROKU_TIME"
//            + "," + "TOROKU_USER_ID"
//            + "," + "TOROKU_PROGRAM_ID"
//            + "," + "KOSHIN_DATE"
//            + "," + "KOSHIN_TIME"
//            + "," + "KOSHIN_USER_ID"
//            + "," + "KOSHIN_PROGRAM_ID";
//
//    /**
//     * �C���X�^���X�𐶐�����B<br>
//     * �f�[�^�\�[�X������
//     * @param datasource �f�[�^�\�[�X��
//     */
//    public GeneratedKakoJukenshaDaoImpl(String datasource) {
//        super(datasource);
//    }
//
//    /* (non-Javadoc)
//     * @see jp.co.nii.bma.business.domain.GeneratedKakoJukenshaDao#create(jp.co.nii.bma.business.domain.GeneratedKakoJukensha)
//     */
//    @Override
//    public void create(GeneratedKakoJukensha bo) {
//        Connection con = null;
//        PreparedStatement stmt = null;
//        String sql = "";
//        try {
//            con = getConnection();
//            sql = "INSERT INTO " + getSchemaName() + "." + TABLE_NAME + " ( "
//                    + FIELDS
//                    + " ) VALUES ("
//                    + " ?"
//                    + ",?"
//                    + ",?"
//                    + ",?"
//                    + ",?"
//                    + ",?"
//                    + ",?"
//                    + ",?"
//                    + ",?"
//                    + ",?"
//                    + ",?"
//                    + ",?"
//                    + ",?"
//                    + ",?"
//                    + ",?"
//                    + ",?"
//                    + ",?"
//                    + ",?"
//                    + ",?"
//                    + " )";
//
//            stmt = con.prepareStatement(sql);
//            int i = 1;
//            stmt.setString(i++, bo.getKakoJukenNen());
//            stmt.setString(i++, bo.getKakoJukenNo());
//            stmt.setString(i++, bo.getKojinJohoKahiKbn());
//            stmt.setString(i++, bo.getShimeiSeiKana());
//            stmt.setString(i++, bo.getShimeiMeiKana());
//            stmt.setString(i++, bo.getBirthday());
//            stmt.setString(i++, bo.getGakkaGokakuNen());
//            stmt.setString(i++, bo.getGakkaGokakujiJukenNo());
//            stmt.setString(i++, bo.getJukenShikakuJohoFlg());
//            stmt.setString(i++, bo.getRonriSakujoFlg());
//            stmt.setString(i++, bo.getShoriKbn());
//            stmt.setString(i++, bo.getTorokuDate());
//            stmt.setString(i++, bo.getTorokuTime());
//            stmt.setString(i++, bo.getTorokuUserId());
//            stmt.setString(i++, bo.getTorokuProgramId());
//            stmt.setString(i++, bo.getKoshinDate());
//            stmt.setString(i++, bo.getKoshinTime());
//            stmt.setString(i++, bo.getKoshinUserId());
//            stmt.setString(i++, bo.getKoshinProgramId());
//
//            LogGenerate.debugOutput(getSql(stmt));
//            stmt.executeUpdate();
//        } catch (SQLException ex) {
//            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
//        } finally {
//            close(con, stmt);
//        }
//    }
//
//    /* (non-Javadoc)
//     * @see jp.co.nii.bma.business.domain.GeneratedKakoJukenshaDao#find(jp.co.nii.bma.business.domain.GeneratedKakoJukensha, java.lang.String)
//     */
//    @Override
//    public GeneratedKakoJukensha find(GeneratedKakoJukensha bo, String lockMode) {
//        Connection con = null;
//        PreparedStatement stmt = null;
//        ResultSet rs =null;
//        String sql = "";
//        try {
//            con = getConnection();
//            sql = "SELECT " + FIELDS_DECRYPT
//                    + " FROM " + getSchemaName() + "." + TABLE_NAME
//                    + " WHERE"
//                    + " KAKO_JUKEN_NEN = ?"
//                    + " AND KAKO_JUKEN_NO = ?";
//
//            stmt = con.prepareStatement(sql + lockMode);
//            int i = 1;
//            stmt.setString(i++, bo.getKakoJukenNen());
//            stmt.setString(i++, bo.getKakoJukenNo());
//
//            LogGenerate.debugOutput(getSql(stmt));
//            rs = stmt.executeQuery();
//            if (rs.next()) {
//                setBoFromResultSet(bo, rs);
//            } else {
//                bo = null;
//            }
//        } catch (SQLException ex) {
//            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
//        } finally {
//            close(con, stmt, rs);
//        }
//        return bo;
//    }
//
//    /* (non-Javadoc)
//     * @see jp.co.nii.bma.business.domain.GeneratedKakoJukenshaDao#update(jp.co.nii.bma.business.domain.GeneratedKakoJukensha)
//     */
//    @Override
//    public void update(GeneratedKakoJukensha bo) {
//        Connection con = null;
//        PreparedStatement stmt = null;
//        String sql = "";
//        try {
//            con = getConnection();
//            sql = "UPDATE " + getSchemaName() + "." + TABLE_NAME + " SET"
//                    + " KOJIN_JOHO_KAHI_KBN = ?"
//                    + ",SHIMEI_SEI_KANA = ?"
//                    + ",SHIMEI_MEI_KANA = ?"
//                    + ",BIRTHDAY = ?"
//                    + ",GAKKA_GOKAKU_NEN = ?"
//                    + ",GAKKA_GOKAKUJI_JUKEN_NO = ?"
//                    + ",JUKEN_SHIKAKU_JOHO_FLG = ?"
//                    + ",RONRI_SAKUJO_FLG = ?"
//                    + ",SHORI_KBN = ?"
//                    + ",TOROKU_DATE = ?"
//                    + ",TOROKU_TIME = ?"
//                    + ",TOROKU_USER_ID = ?"
//                    + ",TOROKU_PROGRAM_ID = ?"
//                    + ",KOSHIN_DATE = ?"
//                    + ",KOSHIN_TIME = ?"
//                    + ",KOSHIN_USER_ID = ?"
//                    + ",KOSHIN_PROGRAM_ID = ?"
//                    + " WHERE"
//                    + " KAKO_JUKEN_NEN = ?"
//                    + " AND KAKO_JUKEN_NO = ?";
//
//            stmt = con.prepareStatement(sql);
//            int i = 1;
//            stmt.setString(i++, bo.getKojinJohoKahiKbn());
//            stmt.setString(i++, bo.getShimeiSeiKana());
//            stmt.setString(i++, bo.getShimeiMeiKana());
//            stmt.setString(i++, bo.getBirthday());
//            stmt.setString(i++, bo.getGakkaGokakuNen());
//            stmt.setString(i++, bo.getGakkaGokakujiJukenNo());
//            stmt.setString(i++, bo.getJukenShikakuJohoFlg());
//            stmt.setString(i++, bo.getRonriSakujoFlg());
//            stmt.setString(i++, bo.getShoriKbn());
//            stmt.setString(i++, bo.getTorokuDate());
//            stmt.setString(i++, bo.getTorokuTime());
//            stmt.setString(i++, bo.getTorokuUserId());
//            stmt.setString(i++, bo.getTorokuProgramId());
//            stmt.setString(i++, bo.getKoshinDate());
//            stmt.setString(i++, bo.getKoshinTime());
//            stmt.setString(i++, bo.getKoshinUserId());
//            stmt.setString(i++, bo.getKoshinProgramId());
//
//            stmt.setString(i++, bo.getKakoJukenNen());
//            stmt.setString(i++, bo.getKakoJukenNo());
//
//            LogGenerate.debugOutput(getSql(stmt));
//            if (stmt.executeUpdate() == 0) {
//                throw new NoSuchDataException(getSql(stmt));
//            }
//        } catch (SQLException ex) {
//            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
//        } finally {
//            close(con, stmt);
//        }
//    }
//
//    /* (non-Javadoc)
//     * @see jp.co.nii.bma.business.domain.GeneratedKakoJukenshaDao#remove(jp.co.nii.bma.business.domain.GeneratedKakoJukensha)
//     */
//    @Override
//    public void remove(GeneratedKakoJukensha bo) {
//        Connection con = null;
//        PreparedStatement stmt = null;
//        String sql = "";
//        try {
//            con = getConnection();
//            sql = "DELETE FROM " + getSchemaName() + "." + TABLE_NAME
//                    + " WHERE"
//                    + " KAKO_JUKEN_NEN = ?"
//                    + " AND KAKO_JUKEN_NO = ?";
//
//            stmt = con.prepareStatement(sql);
//            int i = 1;
//            stmt.setString(i++, bo.getKakoJukenNen());
//            stmt.setString(i++, bo.getKakoJukenNo());
//
//            LogGenerate.debugOutput(getSql(stmt));
//            if (stmt.executeUpdate() == 0) {
//                throw new NoSuchDataException(getSql(stmt));
//            }
//        } catch (SQLException ex) {
//            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
//        } finally {
//            close(con, stmt);
//        }
//    }
//
//    /**
//     * �������ʂł���ResultSet��BusinessObject�֋l�ߑւ���B<br>
//     * ���O�����F������bo��rs��null�łȂ����ƁB
//     * 
//     * @param bo BusinessObject�̃C���X�^���X
//     * @param rs �������ʂ�ResultSet
//     */
//    protected void setBoFromResultSet(GeneratedKakoJukensha bo, ResultSet rs) {
//        try {
//            bo.setKakoJukenNen(rs.getString("KAKO_JUKEN_NEN"));
//            bo.setKakoJukenNo(rs.getString("KAKO_JUKEN_NO"));
//            bo.setKojinJohoKahiKbn(rs.getString("KOJIN_JOHO_KAHI_KBN"));
//            bo.setShimeiSeiKana(rs.getString("SHIMEI_SEI_KANA"));
//            bo.setShimeiMeiKana(rs.getString("SHIMEI_MEI_KANA"));
//            bo.setBirthday(rs.getString("BIRTHDAY"));
//            bo.setGakkaGokakuNen(rs.getString("GAKKA_GOKAKU_NEN"));
//            bo.setGakkaGokakujiJukenNo(rs.getString("GAKKA_GOKAKUJI_JUKEN_NO"));
//            bo.setJukenShikakuJohoFlg(rs.getString("JUKEN_SHIKAKU_JOHO_FLG"));
//            bo.setRonriSakujoFlg(rs.getString("RONRI_SAKUJO_FLG"));
//            bo.setShoriKbn(rs.getString("SHORI_KBN"));
//            bo.setTorokuDate(rs.getString("TOROKU_DATE"));
//            bo.setTorokuTime(rs.getString("TOROKU_TIME"));
//            bo.setTorokuUserId(rs.getString("TOROKU_USER_ID"));
//            bo.setTorokuProgramId(rs.getString("TOROKU_PROGRAM_ID"));
//            bo.setKoshinDate(rs.getString("KOSHIN_DATE"));
//            bo.setKoshinTime(rs.getString("KOSHIN_TIME"));
//            bo.setKoshinUserId(rs.getString("KOSHIN_USER_ID"));
//            bo.setKoshinProgramId(rs.getString("KOSHIN_PROGRAM_ID"));
//        } catch (SQLException ex) {
//            throw new SQLStateSQLExceptionTranslater().translate(null, ex);
//        }
//    }
//}
