//package jp.co.nii.bma.integration;
//
//import java.sql.Connection;
//import java.sql.PreparedStatement;
//import java.sql.ResultSet;
//import java.sql.SQLException;
//
//import jp.co.nii.sew.business.domain.NoSuchDataException;
//import jp.co.nii.sew.common.LogGenerate;
//import jp.co.nii.sew.integration.AbstractDao;
//import jp.co.nii.sew.integration.SQLStateSQLExceptionTranslater;
//
//import jp.co.nii.bma.business.domain.GeneratedMoshikomisha;
//import jp.co.nii.bma.business.domain.GeneratedMoshikomishaDao;
//
///**
// * �������ꂽ �\���� DAO�����N���X<br>
// * table-design-ver 5
// * @author DB�Ǘ��c�[��
// */
//abstract class GeneratedMoshikomishaDaoImpl extends AbstractDao implements GeneratedMoshikomishaDao {
//
//    /**
//     * �e�[�u���J�������̃J���}��؂蕶����B<br>
//     * SQL���̍쐬�ɗp����B
//     */
//    protected static final String FIELDS = "NEN"
//            + ",USER_ID"
//            + ",MAIL_ADDRESS"
//            + ",PASSWD"
//            + ",SHIMEI_SEI_KANJI"
//            + ",SHIMEI_MEI_KANJI"
//            + ",SHIMEI_SEI_KANA"
//            + ",SHIMEI_MEI_KANA"
//            + ",BIRTHDAY"
//            + ",SEX_CODE"
//            + ",HONSEKICHI_CODE"
//            + ",YUBIN_NO"
//            + ",TODOFUKEN_CODE"
//            + ",SHIKUCHOSON_NAME"
//            + ",MANSION_APARTMENT_NAME"
//            + ",TEL_NO"
//            + ",KINKYU_RENRAKUSAKI_TEL_NO"
//            + ",KINMUSAKI_UMU_FLG"
//            + ",KINMUSAKI_MEISHO"
//            + ",KINMUSAKI_BUKA_NAME"
//            + ",KINMUSAKI_YUBIN_NO"
//            + ",KINMUSAKI_TODOFUKEN_CODE"
//            + ",KINMUSAKI_SHIKUCHOSON_NAME"
//            + ",KINMUSAKI_BUILDING_MANSION_APARTMENT_NAME"
//            + ",KINMUSAKI_TEL_NO"
//            + ",KINMUSAKI_GENBA_TEL_NO"
//            + ",JUKENHYO_SOFUSAKI_UMU_FLG"
//            + ",JUKENHYO_SOFUSAKI_YUBIN_NO"
//            + ",JUKENHYO_SOFUSAKI_TODOFUKEN_CODE"
//            + ",JUKENHYO_SOFUSAKI_SHIKUCHOSON_NAME"
//            + ",JUKENHYO_SOFUSAKI_BUILDING_MANSION_APARTMENT_NAME"
//            + ",PASSWD_QUESTION_CODE"
//            + ",PASSWD_ANSWER"
//            + ",RONRI_SAKUJO_FLG"
//            + ",SHORI_KBN"
//            + ",TOROKU_DATE"
//            + ",TOROKU_TIME"
//            + ",TOROKU_USER_ID"
//            + ",TOROKU_PROGRAM_ID"
//            + ",KOSHIN_DATE"
//            + ",KOSHIN_TIME"
//            + ",KOSHIN_USER_ID"
//            + ",KOSHIN_PROGRAM_ID";
//
//    /**
//     * �e�[�u���J�������̃J���}��؂蕶����B<br>
//     *  �Í����Ώۍ��ڂ𕡍�����SQL���̍쐬�ɗp����B
//     */
//    protected static final String FIELDS_DECRYPT = "NEN"
//            + "," + "USER_ID"
//            + "," + getSQLForDecryptByUTF8("MAIL_ADDRESS")
//            + "," + getSQLForDecryptByUTF8("PASSWD")
//            + "," + getSQLForDecryptByUTF8("SHIMEI_SEI_KANJI")
//            + "," + getSQLForDecryptByUTF8("SHIMEI_MEI_KANJI")
//            + "," + getSQLForDecryptByUTF8("SHIMEI_SEI_KANA")
//            + "," + getSQLForDecryptByUTF8("SHIMEI_MEI_KANA")
//            + "," + getSQLForDecryptByUTF8("BIRTHDAY")
//            + "," + getSQLForDecryptByUTF8("SEX_CODE")
//            + "," + getSQLForDecryptByUTF8("HONSEKICHI_CODE")
//            + "," + getSQLForDecryptByUTF8("YUBIN_NO")
//            + "," + getSQLForDecryptByUTF8("TODOFUKEN_CODE")
//            + "," + getSQLForDecryptByUTF8("SHIKUCHOSON_NAME")
//            + "," + getSQLForDecryptByUTF8("MANSION_APARTMENT_NAME")
//            + "," + getSQLForDecryptByUTF8("TEL_NO")
//            + "," + getSQLForDecryptByUTF8("KINKYU_RENRAKUSAKI_TEL_NO")
//            + "," + "KINMUSAKI_UMU_FLG"
//            + "," + getSQLForDecryptByUTF8("KINMUSAKI_MEISHO")
//            + "," + getSQLForDecryptByUTF8("KINMUSAKI_BUKA_NAME")
//            + "," + getSQLForDecryptByUTF8("KINMUSAKI_YUBIN_NO")
//            + "," + getSQLForDecryptByUTF8("KINMUSAKI_TODOFUKEN_CODE")
//            + "," + getSQLForDecryptByUTF8("KINMUSAKI_SHIKUCHOSON_NAME")
//            + "," + getSQLForDecryptByUTF8("KINMUSAKI_BUILDING_MANSION_APARTMENT_NAME")
//            + "," + getSQLForDecryptByUTF8("KINMUSAKI_TEL_NO")
//            + "," + getSQLForDecryptByUTF8("KINMUSAKI_GENBA_TEL_NO")
//            + "," + "JUKENHYO_SOFUSAKI_UMU_FLG"
//            + "," + getSQLForDecryptByUTF8("JUKENHYO_SOFUSAKI_YUBIN_NO")
//            + "," + getSQLForDecryptByUTF8("JUKENHYO_SOFUSAKI_TODOFUKEN_CODE")
//            + "," + getSQLForDecryptByUTF8("JUKENHYO_SOFUSAKI_SHIKUCHOSON_NAME")
//            + "," + getSQLForDecryptByUTF8("JUKENHYO_SOFUSAKI_BUILDING_MANSION_APARTMENT_NAME")
//            + "," + getSQLForDecryptByUTF8("PASSWD_QUESTION_CODE")
//            + "," + getSQLForDecryptByUTF8("PASSWD_ANSWER")
//            + "," + "RONRI_SAKUJO_FLG"
//            + "," + "SHORI_KBN"
//            + "," + "TOROKU_DATE"
//            + "," + "TOROKU_TIME"
//            + "," + "TOROKU_USER_ID"
//            + "," + "TOROKU_PROGRAM_ID"
//            + "," + "KOSHIN_DATE"
//            + "," + "KOSHIN_TIME"
//            + "," + "KOSHIN_USER_ID"
//            + "," + "KOSHIN_PROGRAM_ID";
//
//    /**
//     * �C���X�^���X�𐶐�����B<br>
//     * �f�[�^�\�[�X������
//     * @param datasource �f�[�^�\�[�X��
//     */
//    public GeneratedMoshikomishaDaoImpl(String datasource) {
//        super(datasource);
//    }
//
//    /* (non-Javadoc)
//     * @see jp.co.nii.bma.business.domain.GeneratedMoshikomishaDao#create(jp.co.nii.bma.business.domain.GeneratedMoshikomisha)
//     */
//    @Override
//    public void create(GeneratedMoshikomisha bo) {
//        Connection con = null;
//        PreparedStatement stmt = null;
//        String sql = "";
//        try {
//            con = getConnection();
//            sql = "INSERT INTO " + getSchemaName() + "." + TABLE_NAME + " ( "
//                    + FIELDS
//                    + " ) VALUES ("
//                    + " ?"
//                    + ",?"
//                    + "," + getSQLForEncryptByUTF8("?")
//                    + "," + getSQLForEncryptByUTF8("?")
//                    + "," + getSQLForEncryptByUTF8("?")
//                    + "," + getSQLForEncryptByUTF8("?")
//                    + "," + getSQLForEncryptByUTF8("?")
//                    + "," + getSQLForEncryptByUTF8("?")
//                    + "," + getSQLForEncryptByUTF8("?")
//                    + "," + getSQLForEncryptByUTF8("?")
//                    + "," + getSQLForEncryptByUTF8("?")
//                    + "," + getSQLForEncryptByUTF8("?")
//                    + "," + getSQLForEncryptByUTF8("?")
//                    + "," + getSQLForEncryptByUTF8("?")
//                    + "," + getSQLForEncryptByUTF8("?")
//                    + "," + getSQLForEncryptByUTF8("?")
//                    + "," + getSQLForEncryptByUTF8("?")
//                    + ",?"
//                    + "," + getSQLForEncryptByUTF8("?")
//                    + "," + getSQLForEncryptByUTF8("?")
//                    + "," + getSQLForEncryptByUTF8("?")
//                    + "," + getSQLForEncryptByUTF8("?")
//                    + "," + getSQLForEncryptByUTF8("?")
//                    + "," + getSQLForEncryptByUTF8("?")
//                    + "," + getSQLForEncryptByUTF8("?")
//                    + "," + getSQLForEncryptByUTF8("?")
//                    + ",?"
//                    + "," + getSQLForEncryptByUTF8("?")
//                    + "," + getSQLForEncryptByUTF8("?")
//                    + "," + getSQLForEncryptByUTF8("?")
//                    + "," + getSQLForEncryptByUTF8("?")
//                    + "," + getSQLForEncryptByUTF8("?")
//                    + "," + getSQLForEncryptByUTF8("?")
//                    + ",?"
//                    + ",?"
//                    + ",?"
//                    + ",?"
//                    + ",?"
//                    + ",?"
//                    + ",?"
//                    + ",?"
//                    + ",?"
//                    + ",?"
//                    + " )";
//
//            stmt = con.prepareStatement(sql);
//            int i = 1;
//            stmt.setString(i++, bo.getNen());
//            stmt.setString(i++, bo.getUserId());
//            stmt.setString(i++, bo.getMailAddress());
//            stmt.setString(i++, bo.getPasswd());
//            stmt.setString(i++, bo.getShimeiSeiKanji());
//            stmt.setString(i++, bo.getShimeiMeiKanji());
//            stmt.setString(i++, bo.getShimeiSeiKana());
//            stmt.setString(i++, bo.getShimeiMeiKana());
//            stmt.setString(i++, bo.getBirthday());
//            stmt.setString(i++, bo.getSexCode());
//            stmt.setString(i++, bo.getHonsekichiCode());
//            stmt.setString(i++, bo.getYubinNo());
//            stmt.setString(i++, bo.getTodofukenCode());
//            stmt.setString(i++, bo.getShikuchosonName());
//            stmt.setString(i++, bo.getMansionApartmentName());
//            stmt.setString(i++, bo.getTelNo());
//            stmt.setString(i++, bo.getKinkyuRenrakusakiTelNo());
//            stmt.setString(i++, bo.getKinmusakiUmuFlg());
//            stmt.setString(i++, bo.getKinmusakiMeisho());
//            stmt.setString(i++, bo.getKinmusakiBukaName());
//            stmt.setString(i++, bo.getKinmusakiYubinNo());
//            stmt.setString(i++, bo.getKinmusakiTodofukenCode());
//            stmt.setString(i++, bo.getKinmusakiShikuchosonName());
//            stmt.setString(i++, bo.getKinmusakiBuildingMansionApartmentName());
//            stmt.setString(i++, bo.getKinmusakiTelNo());
//            stmt.setString(i++, bo.getKinmusakiGenbaTelNo());
//            stmt.setString(i++, bo.getJukenhyoSofusakiUmuFlg());
//            stmt.setString(i++, bo.getJukenhyoSofusakiYubinNo());
//            stmt.setString(i++, bo.getJukenhyoSofusakiTodofukenCode());
//            stmt.setString(i++, bo.getJukenhyoSofusakiShikuchosonName());
//            stmt.setString(i++, bo.getJukenhyoSofusakiBuildingMansionApartmentName());
//            stmt.setString(i++, bo.getPasswdQuestionCode());
//            stmt.setString(i++, bo.getPasswdAnswer());
//            stmt.setString(i++, bo.getRonriSakujoFlg());
//            stmt.setString(i++, bo.getShoriKbn());
//            stmt.setString(i++, bo.getTorokuDate());
//            stmt.setString(i++, bo.getTorokuTime());
//            stmt.setString(i++, bo.getTorokuUserId());
//            stmt.setString(i++, bo.getTorokuProgramId());
//            stmt.setString(i++, bo.getKoshinDate());
//            stmt.setString(i++, bo.getKoshinTime());
//            stmt.setString(i++, bo.getKoshinUserId());
//            stmt.setString(i++, bo.getKoshinProgramId());
//
//            LogGenerate.debugOutput(getSql(stmt));
//            stmt.executeUpdate();
//        } catch (SQLException ex) {
//            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
//        } finally {
//            close(con, stmt);
//        }
//    }
//
//    /* (non-Javadoc)
//     * @see jp.co.nii.bma.business.domain.GeneratedMoshikomishaDao#find(jp.co.nii.bma.business.domain.GeneratedMoshikomisha, java.lang.String)
//     */
//    @Override
//    public GeneratedMoshikomisha find(GeneratedMoshikomisha bo, String lockMode) {
//        Connection con = null;
//        PreparedStatement stmt = null;
//        ResultSet rs =null;
//        String sql = "";
//        try {
//            con = getConnection();
//            sql = "SELECT " + FIELDS_DECRYPT
//                    + " FROM " + getSchemaName() + "." + TABLE_NAME
//                    + " WHERE"
//                    + " NEN = ?"
//                    + " AND USER_ID = ?";
//
//            stmt = con.prepareStatement(sql + lockMode);
//            int i = 1;
//            stmt.setString(i++, bo.getNen());
//            stmt.setString(i++, bo.getUserId());
//
//            LogGenerate.debugOutput(getSql(stmt));
//            rs = stmt.executeQuery();
//            if (rs.next()) {
//                setBoFromResultSet(bo, rs);
//            } else {
//                bo = null;
//            }
//        } catch (SQLException ex) {
//            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
//        } finally {
//            close(con, stmt, rs);
//        }
//        return bo;
//    }
//
//    /* (non-Javadoc)
//     * @see jp.co.nii.bma.business.domain.GeneratedMoshikomishaDao#update(jp.co.nii.bma.business.domain.GeneratedMoshikomisha)
//     */
//    @Override
//    public void update(GeneratedMoshikomisha bo) {
//        Connection con = null;
//        PreparedStatement stmt = null;
//        String sql = "";
//        try {
//            con = getConnection();
//            sql = "UPDATE " + getSchemaName() + "." + TABLE_NAME + " SET"
//                    + " MAIL_ADDRESS = " + getSQLForEncryptByUTF8("?")
//                    + ",PASSWD = " + getSQLForEncryptByUTF8("?")
//                    + ",SHIMEI_SEI_KANJI = " + getSQLForEncryptByUTF8("?")
//                    + ",SHIMEI_MEI_KANJI = " + getSQLForEncryptByUTF8("?")
//                    + ",SHIMEI_SEI_KANA = " + getSQLForEncryptByUTF8("?")
//                    + ",SHIMEI_MEI_KANA = " + getSQLForEncryptByUTF8("?")
//                    + ",BIRTHDAY = " + getSQLForEncryptByUTF8("?")
//                    + ",SEX_CODE = " + getSQLForEncryptByUTF8("?")
//                    + ",HONSEKICHI_CODE = " + getSQLForEncryptByUTF8("?")
//                    + ",YUBIN_NO = " + getSQLForEncryptByUTF8("?")
//                    + ",TODOFUKEN_CODE = " + getSQLForEncryptByUTF8("?")
//                    + ",SHIKUCHOSON_NAME = " + getSQLForEncryptByUTF8("?")
//                    + ",MANSION_APARTMENT_NAME = " + getSQLForEncryptByUTF8("?")
//                    + ",TEL_NO = " + getSQLForEncryptByUTF8("?")
//                    + ",KINKYU_RENRAKUSAKI_TEL_NO = " + getSQLForEncryptByUTF8("?")
//                    + ",KINMUSAKI_UMU_FLG = ?"
//                    + ",KINMUSAKI_MEISHO = " + getSQLForEncryptByUTF8("?")
//                    + ",KINMUSAKI_BUKA_NAME = " + getSQLForEncryptByUTF8("?")
//                    + ",KINMUSAKI_YUBIN_NO = " + getSQLForEncryptByUTF8("?")
//                    + ",KINMUSAKI_TODOFUKEN_CODE = " + getSQLForEncryptByUTF8("?")
//                    + ",KINMUSAKI_SHIKUCHOSON_NAME = " + getSQLForEncryptByUTF8("?")
//                    + ",KINMUSAKI_BUILDING_MANSION_APARTMENT_NAME = " + getSQLForEncryptByUTF8("?")
//                    + ",KINMUSAKI_TEL_NO = " + getSQLForEncryptByUTF8("?")
//                    + ",KINMUSAKI_GENBA_TEL_NO = " + getSQLForEncryptByUTF8("?")
//                    + ",JUKENHYO_SOFUSAKI_UMU_FLG = ?"
//                    + ",JUKENHYO_SOFUSAKI_YUBIN_NO = " + getSQLForEncryptByUTF8("?")
//                    + ",JUKENHYO_SOFUSAKI_TODOFUKEN_CODE = " + getSQLForEncryptByUTF8("?")
//                    + ",JUKENHYO_SOFUSAKI_SHIKUCHOSON_NAME = " + getSQLForEncryptByUTF8("?")
//                    + ",JUKENHYO_SOFUSAKI_BUILDING_MANSION_APARTMENT_NAME = " + getSQLForEncryptByUTF8("?")
//                    + ",PASSWD_QUESTION_CODE = " + getSQLForEncryptByUTF8("?")
//                    + ",PASSWD_ANSWER = " + getSQLForEncryptByUTF8("?")
//                    + ",RONRI_SAKUJO_FLG = ?"
//                    + ",SHORI_KBN = ?"
//                    + ",TOROKU_DATE = ?"
//                    + ",TOROKU_TIME = ?"
//                    + ",TOROKU_USER_ID = ?"
//                    + ",TOROKU_PROGRAM_ID = ?"
//                    + ",KOSHIN_DATE = ?"
//                    + ",KOSHIN_TIME = ?"
//                    + ",KOSHIN_USER_ID = ?"
//                    + ",KOSHIN_PROGRAM_ID = ?"
//                    + " WHERE"
//                    + " NEN = ?"
//                    + " AND USER_ID = ?";
//
//            stmt = con.prepareStatement(sql);
//            int i = 1;
//            stmt.setString(i++, bo.getMailAddress());
//            stmt.setString(i++, bo.getPasswd());
//            stmt.setString(i++, bo.getShimeiSeiKanji());
//            stmt.setString(i++, bo.getShimeiMeiKanji());
//            stmt.setString(i++, bo.getShimeiSeiKana());
//            stmt.setString(i++, bo.getShimeiMeiKana());
//            stmt.setString(i++, bo.getBirthday());
//            stmt.setString(i++, bo.getSexCode());
//            stmt.setString(i++, bo.getHonsekichiCode());
//            stmt.setString(i++, bo.getYubinNo());
//            stmt.setString(i++, bo.getTodofukenCode());
//            stmt.setString(i++, bo.getShikuchosonName());
//            stmt.setString(i++, bo.getMansionApartmentName());
//            stmt.setString(i++, bo.getTelNo());
//            stmt.setString(i++, bo.getKinkyuRenrakusakiTelNo());
//            stmt.setString(i++, bo.getKinmusakiUmuFlg());
//            stmt.setString(i++, bo.getKinmusakiMeisho());
//            stmt.setString(i++, bo.getKinmusakiBukaName());
//            stmt.setString(i++, bo.getKinmusakiYubinNo());
//            stmt.setString(i++, bo.getKinmusakiTodofukenCode());
//            stmt.setString(i++, bo.getKinmusakiShikuchosonName());
//            stmt.setString(i++, bo.getKinmusakiBuildingMansionApartmentName());
//            stmt.setString(i++, bo.getKinmusakiTelNo());
//            stmt.setString(i++, bo.getKinmusakiGenbaTelNo());
//            stmt.setString(i++, bo.getJukenhyoSofusakiUmuFlg());
//            stmt.setString(i++, bo.getJukenhyoSofusakiYubinNo());
//            stmt.setString(i++, bo.getJukenhyoSofusakiTodofukenCode());
//            stmt.setString(i++, bo.getJukenhyoSofusakiShikuchosonName());
//            stmt.setString(i++, bo.getJukenhyoSofusakiBuildingMansionApartmentName());
//            stmt.setString(i++, bo.getPasswdQuestionCode());
//            stmt.setString(i++, bo.getPasswdAnswer());
//            stmt.setString(i++, bo.getRonriSakujoFlg());
//            stmt.setString(i++, bo.getShoriKbn());
//            stmt.setString(i++, bo.getTorokuDate());
//            stmt.setString(i++, bo.getTorokuTime());
//            stmt.setString(i++, bo.getTorokuUserId());
//            stmt.setString(i++, bo.getTorokuProgramId());
//            stmt.setString(i++, bo.getKoshinDate());
//            stmt.setString(i++, bo.getKoshinTime());
//            stmt.setString(i++, bo.getKoshinUserId());
//            stmt.setString(i++, bo.getKoshinProgramId());
//
//            stmt.setString(i++, bo.getNen());
//            stmt.setString(i++, bo.getUserId());
//
//            LogGenerate.debugOutput(getSql(stmt));
//            if (stmt.executeUpdate() == 0) {
//                throw new NoSuchDataException(getSql(stmt));
//            }
//        } catch (SQLException ex) {
//            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
//        } finally {
//            close(con, stmt);
//        }
//    }
//
//    /* (non-Javadoc)
//     * @see jp.co.nii.bma.business.domain.GeneratedMoshikomishaDao#remove(jp.co.nii.bma.business.domain.GeneratedMoshikomisha)
//     */
//    @Override
//    public void remove(GeneratedMoshikomisha bo) {
//        Connection con = null;
//        PreparedStatement stmt = null;
//        String sql = "";
//        try {
//            con = getConnection();
//            sql = "DELETE FROM " + getSchemaName() + "." + TABLE_NAME
//                    + " WHERE"
//                    + " NEN = ?"
//                    + " AND USER_ID = ?";
//
//            stmt = con.prepareStatement(sql);
//            int i = 1;
//            stmt.setString(i++, bo.getNen());
//            stmt.setString(i++, bo.getUserId());
//
//            LogGenerate.debugOutput(getSql(stmt));
//            if (stmt.executeUpdate() == 0) {
//                throw new NoSuchDataException(getSql(stmt));
//            }
//        } catch (SQLException ex) {
//            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
//        } finally {
//            close(con, stmt);
//        }
//    }
//
//    /**
//     * �������ʂł���ResultSet��BusinessObject�֋l�ߑւ���B<br>
//     * ���O�����F������bo��rs��null�łȂ����ƁB
//     * 
//     * @param bo BusinessObject�̃C���X�^���X
//     * @param rs �������ʂ�ResultSet
//     */
//    protected void setBoFromResultSet(GeneratedMoshikomisha bo, ResultSet rs) {
//        try {
//            bo.setNen(rs.getString("NEN"));
//            bo.setUserId(rs.getString("USER_ID"));
//            bo.setMailAddress(rs.getString("MAIL_ADDRESS"));
//            bo.setPasswd(rs.getString("PASSWD"));
//            bo.setShimeiSeiKanji(rs.getString("SHIMEI_SEI_KANJI"));
//            bo.setShimeiMeiKanji(rs.getString("SHIMEI_MEI_KANJI"));
//            bo.setShimeiSeiKana(rs.getString("SHIMEI_SEI_KANA"));
//            bo.setShimeiMeiKana(rs.getString("SHIMEI_MEI_KANA"));
//            bo.setBirthday(rs.getString("BIRTHDAY"));
//            bo.setSexCode(rs.getString("SEX_CODE"));
//            bo.setHonsekichiCode(rs.getString("HONSEKICHI_CODE"));
//            bo.setYubinNo(rs.getString("YUBIN_NO"));
//            bo.setTodofukenCode(rs.getString("TODOFUKEN_CODE"));
//            bo.setShikuchosonName(rs.getString("SHIKUCHOSON_NAME"));
//            bo.setMansionApartmentName(rs.getString("MANSION_APARTMENT_NAME"));
//            bo.setTelNo(rs.getString("TEL_NO"));
//            bo.setKinkyuRenrakusakiTelNo(rs.getString("KINKYU_RENRAKUSAKI_TEL_NO"));
//            bo.setKinmusakiUmuFlg(rs.getString("KINMUSAKI_UMU_FLG"));
//            bo.setKinmusakiMeisho(rs.getString("KINMUSAKI_MEISHO"));
//            bo.setKinmusakiBukaName(rs.getString("KINMUSAKI_BUKA_NAME"));
//            bo.setKinmusakiYubinNo(rs.getString("KINMUSAKI_YUBIN_NO"));
//            bo.setKinmusakiTodofukenCode(rs.getString("KINMUSAKI_TODOFUKEN_CODE"));
//            bo.setKinmusakiShikuchosonName(rs.getString("KINMUSAKI_SHIKUCHOSON_NAME"));
//            bo.setKinmusakiBuildingMansionApartmentName(rs.getString("KINMUSAKI_BUILDING_MANSION_APARTMENT_NAME"));
//            bo.setKinmusakiTelNo(rs.getString("KINMUSAKI_TEL_NO"));
//            bo.setKinmusakiGenbaTelNo(rs.getString("KINMUSAKI_GENBA_TEL_NO"));
//            bo.setJukenhyoSofusakiUmuFlg(rs.getString("JUKENHYO_SOFUSAKI_UMU_FLG"));
//            bo.setJukenhyoSofusakiYubinNo(rs.getString("JUKENHYO_SOFUSAKI_YUBIN_NO"));
//            bo.setJukenhyoSofusakiTodofukenCode(rs.getString("JUKENHYO_SOFUSAKI_TODOFUKEN_CODE"));
//            bo.setJukenhyoSofusakiShikuchosonName(rs.getString("JUKENHYO_SOFUSAKI_SHIKUCHOSON_NAME"));
//            bo.setJukenhyoSofusakiBuildingMansionApartmentName(rs.getString("JUKENHYO_SOFUSAKI_BUILDING_MANSION_APARTMENT_NAME"));
//            bo.setPasswdQuestionCode(rs.getString("PASSWD_QUESTION_CODE"));
//            bo.setPasswdAnswer(rs.getString("PASSWD_ANSWER"));
//            bo.setRonriSakujoFlg(rs.getString("RONRI_SAKUJO_FLG"));
//            bo.setShoriKbn(rs.getString("SHORI_KBN"));
//            bo.setTorokuDate(rs.getString("TOROKU_DATE"));
//            bo.setTorokuTime(rs.getString("TOROKU_TIME"));
//            bo.setTorokuUserId(rs.getString("TOROKU_USER_ID"));
//            bo.setTorokuProgramId(rs.getString("TOROKU_PROGRAM_ID"));
//            bo.setKoshinDate(rs.getString("KOSHIN_DATE"));
//            bo.setKoshinTime(rs.getString("KOSHIN_TIME"));
//            bo.setKoshinUserId(rs.getString("KOSHIN_USER_ID"));
//            bo.setKoshinProgramId(rs.getString("KOSHIN_PROGRAM_ID"));
//        } catch (SQLException ex) {
//            throw new SQLStateSQLExceptionTranslater().translate(null, ex);
//        }
//    }
//}
