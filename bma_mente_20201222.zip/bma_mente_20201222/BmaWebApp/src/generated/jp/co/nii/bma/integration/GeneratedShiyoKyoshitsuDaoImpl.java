//package jp.co.nii.bma.integration;
//
//import java.sql.Connection;
//import java.sql.PreparedStatement;
//import java.sql.ResultSet;
//import java.sql.SQLException;
//
//import jp.co.nii.sew.business.domain.NoSuchDataException;
//import jp.co.nii.sew.common.LogGenerate;
//import jp.co.nii.sew.integration.AbstractDao;
//import jp.co.nii.sew.integration.SQLStateSQLExceptionTranslater;
//
//import jp.co.nii.bma.business.domain.GeneratedShiyoKyoshitsu;
//import jp.co.nii.bma.business.domain.GeneratedShiyoKyoshitsuDao;
//
///**
// * �������ꂽ �g�p���� DAO�����N���X<br>
// * table-design-ver 2
// * @author DB�Ǘ��c�[��
// */
//abstract class GeneratedShiyoKyoshitsuDaoImpl extends AbstractDao implements GeneratedShiyoKyoshitsuDao {
//
//    /**
//     * �e�[�u���J�������̃J���}��؂蕶����B<br>
//     * SQL���̍쐬�ɗp����B
//     */
//    protected static final String FIELDS = "NENDO"
//            + ",KAIJO_CODE"
//            + ",KYOSHITSU_CODE"
//            + ",SHIYO_KBN"
//            + ",JUKENSHA_SU"
//            + ",BIKO_KYOSHITSU"
//            + ",KOSHIN_KBN"
//            + ",TOROKU_DATE"
//            + ",TOROKU_TIME"
//            + ",TOROKU_USER_ID"
//            + ",KOSHIN_DATE"
//            + ",KOSHIN_TIME"
//            + ",KOSHIN_USER_ID"
//            + ",RONRI_SAKUJO_FLG";
//
//    /**
//     * �e�[�u���J�������̃J���}��؂蕶����B<br>
//     *  �Í����Ώۍ��ڂ𕡍�����SQL���̍쐬�ɗp����B
//     */
//    protected static final String FIELDS_DECRYPT = "NENDO"
//            + "," + "KAIJO_CODE"
//            + "," + "KYOSHITSU_CODE"
//            + "," + "SHIYO_KBN"
//            + "," + "JUKENSHA_SU"
//            + "," + "BIKO_KYOSHITSU"
//            + "," + "KOSHIN_KBN"
//            + "," + "TOROKU_DATE"
//            + "," + "TOROKU_TIME"
//            + "," + "TOROKU_USER_ID"
//            + "," + "KOSHIN_DATE"
//            + "," + "KOSHIN_TIME"
//            + "," + "KOSHIN_USER_ID"
//            + "," + "RONRI_SAKUJO_FLG";
//
//    /**
//     * �C���X�^���X�𐶐�����B<br>
//     * �f�[�^�\�[�X������
//     * @param datasource �f�[�^�\�[�X��
//     */
//    public GeneratedShiyoKyoshitsuDaoImpl(String datasource) {
//        super(datasource);
//    }
//
//    /* (non-Javadoc)
//     * @see jp.co.nii.bma.business.domain.GeneratedShiyoKyoshitsuDao#create(jp.co.nii.bma.business.domain.GeneratedShiyoKyoshitsu)
//     */
//    @Override
//    public void create(GeneratedShiyoKyoshitsu bo) {
//        Connection con = null;
//        PreparedStatement stmt = null;
//        String sql = "";
//        try {
//            con = getConnection();
//            sql = "INSERT INTO " + getSchemaName() + "." + TABLE_NAME + " ( "
//                    + FIELDS
//                    + " ) VALUES ("
//                    + " ?"
//                    + ",?"
//                    + ",?"
//                    + ",?"
//                    + ",?"
//                    + ",?"
//                    + ",?"
//                    + ",?"
//                    + ",?"
//                    + ",?"
//                    + ",?"
//                    + ",?"
//                    + ",?"
//                    + ",?"
//                    + " )";
//
//            stmt = con.prepareStatement(sql);
//            int i = 1;
//            stmt.setString(i++, bo.getNendo());
//            stmt.setString(i++, bo.getKaijoCode());
//            stmt.setString(i++, bo.getKyoshitsuCode());
//            stmt.setString(i++, bo.getShiyoKbn());
//            stmt.setString(i++, bo.getJukenshaSu());
//            stmt.setString(i++, bo.getBikoKyoshitsu());
//            stmt.setString(i++, bo.getKoshinKbn());
//            stmt.setString(i++, bo.getTorokuDate());
//            stmt.setString(i++, bo.getTorokuTime());
//            stmt.setString(i++, bo.getTorokuUserId());
//            stmt.setString(i++, bo.getKoshinDate());
//            stmt.setString(i++, bo.getKoshinTime());
//            stmt.setString(i++, bo.getKoshinUserId());
//            stmt.setString(i++, bo.getRonriSakujoFlg());
//
//            LogGenerate.debugOutput(getSql(stmt));
//            stmt.executeUpdate();
//        } catch (SQLException ex) {
//            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
//        } finally {
//            close(con, stmt);
//        }
//    }
//
//    /* (non-Javadoc)
//     * @see jp.co.nii.bma.business.domain.GeneratedShiyoKyoshitsuDao#find(jp.co.nii.bma.business.domain.GeneratedShiyoKyoshitsu, java.lang.String)
//     */
//    @Override
//    public GeneratedShiyoKyoshitsu find(GeneratedShiyoKyoshitsu bo, String lockMode) {
//        Connection con = null;
//        PreparedStatement stmt = null;
//        ResultSet rs =null;
//        String sql = "";
//        try {
//            con = getConnection();
//            sql = "SELECT " + FIELDS_DECRYPT
//                    + " FROM " + getSchemaName() + "." + TABLE_NAME
//                    + " WHERE"
//                    + " NENDO = ?"
//                    + " AND KAIJO_CODE = ?"
//                    + " AND KYOSHITSU_CODE = ?";
//
//            stmt = con.prepareStatement(sql + lockMode);
//            int i = 1;
//            stmt.setString(i++, bo.getNendo());
//            stmt.setString(i++, bo.getKaijoCode());
//            stmt.setString(i++, bo.getKyoshitsuCode());
//
//            LogGenerate.debugOutput(getSql(stmt));
//            rs = stmt.executeQuery();
//            if (rs.next()) {
//                setBoFromResultSet(bo, rs);
//            } else {
//                bo = null;
//            }
//        } catch (SQLException ex) {
//            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
//        } finally {
//            close(con, stmt, rs);
//        }
//        return bo;
//    }
//
//    /* (non-Javadoc)
//     * @see jp.co.nii.bma.business.domain.GeneratedShiyoKyoshitsuDao#update(jp.co.nii.bma.business.domain.GeneratedShiyoKyoshitsu)
//     */
//    @Override
//    public void update(GeneratedShiyoKyoshitsu bo) {
//        Connection con = null;
//        PreparedStatement stmt = null;
//        String sql = "";
//        try {
//            con = getConnection();
//            sql = "UPDATE " + getSchemaName() + "." + TABLE_NAME + " SET"
//                    + " SHIYO_KBN = ?"
//                    + ",JUKENSHA_SU = ?"
//                    + ",BIKO_KYOSHITSU = ?"
//                    + ",KOSHIN_KBN = ?"
//                    + ",TOROKU_DATE = ?"
//                    + ",TOROKU_TIME = ?"
//                    + ",TOROKU_USER_ID = ?"
//                    + ",KOSHIN_DATE = ?"
//                    + ",KOSHIN_TIME = ?"
//                    + ",KOSHIN_USER_ID = ?"
//                    + ",RONRI_SAKUJO_FLG = ?"
//                    + " WHERE"
//                    + " NENDO = ?"
//                    + " AND KAIJO_CODE = ?"
//                    + " AND KYOSHITSU_CODE = ?";
//
//            stmt = con.prepareStatement(sql);
//            int i = 1;
//            stmt.setString(i++, bo.getShiyoKbn());
//            stmt.setString(i++, bo.getJukenshaSu());
//            stmt.setString(i++, bo.getBikoKyoshitsu());
//            stmt.setString(i++, bo.getKoshinKbn());
//            stmt.setString(i++, bo.getTorokuDate());
//            stmt.setString(i++, bo.getTorokuTime());
//            stmt.setString(i++, bo.getTorokuUserId());
//            stmt.setString(i++, bo.getKoshinDate());
//            stmt.setString(i++, bo.getKoshinTime());
//            stmt.setString(i++, bo.getKoshinUserId());
//            stmt.setString(i++, bo.getRonriSakujoFlg());
//
//            stmt.setString(i++, bo.getNendo());
//            stmt.setString(i++, bo.getKaijoCode());
//            stmt.setString(i++, bo.getKyoshitsuCode());
//
//            LogGenerate.debugOutput(getSql(stmt));
//            if (stmt.executeUpdate() == 0) {
//                throw new NoSuchDataException(getSql(stmt));
//            }
//        } catch (SQLException ex) {
//            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
//        } finally {
//            close(con, stmt);
//        }
//    }
//
//    /* (non-Javadoc)
//     * @see jp.co.nii.bma.business.domain.GeneratedShiyoKyoshitsuDao#remove(jp.co.nii.bma.business.domain.GeneratedShiyoKyoshitsu)
//     */
//    @Override
//    public void remove(GeneratedShiyoKyoshitsu bo) {
//        Connection con = null;
//        PreparedStatement stmt = null;
//        String sql = "";
//        try {
//            con = getConnection();
//            sql = "DELETE FROM " + getSchemaName() + "." + TABLE_NAME
//                    + " WHERE"
//                    + " NENDO = ?"
//                    + " AND KAIJO_CODE = ?"
//                    + " AND KYOSHITSU_CODE = ?";
//
//            stmt = con.prepareStatement(sql);
//            int i = 1;
//            stmt.setString(i++, bo.getNendo());
//            stmt.setString(i++, bo.getKaijoCode());
//            stmt.setString(i++, bo.getKyoshitsuCode());
//
//            LogGenerate.debugOutput(getSql(stmt));
//            if (stmt.executeUpdate() == 0) {
//                throw new NoSuchDataException(getSql(stmt));
//            }
//        } catch (SQLException ex) {
//            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
//        } finally {
//            close(con, stmt);
//        }
//    }
//
//    /**
//     * �������ʂł���ResultSet��BusinessObject�֋l�ߑւ���B<br>
//     * ���O�����F������bo��rs��null�łȂ����ƁB
//     * 
//     * @param bo BusinessObject�̃C���X�^���X
//     * @param rs �������ʂ�ResultSet
//     */
//    protected void setBoFromResultSet(GeneratedShiyoKyoshitsu bo, ResultSet rs) {
//        try {
//            bo.setNendo(rs.getString("NENDO"));
//            bo.setKaijoCode(rs.getString("KAIJO_CODE"));
//            bo.setKyoshitsuCode(rs.getString("KYOSHITSU_CODE"));
//            bo.setShiyoKbn(rs.getString("SHIYO_KBN"));
//            bo.setJukenshaSu(rs.getString("JUKENSHA_SU"));
//            bo.setBikoKyoshitsu(rs.getString("BIKO_KYOSHITSU"));
//            bo.setKoshinKbn(rs.getString("KOSHIN_KBN"));
//            bo.setTorokuDate(rs.getString("TOROKU_DATE"));
//            bo.setTorokuTime(rs.getString("TOROKU_TIME"));
//            bo.setTorokuUserId(rs.getString("TOROKU_USER_ID"));
//            bo.setKoshinDate(rs.getString("KOSHIN_DATE"));
//            bo.setKoshinTime(rs.getString("KOSHIN_TIME"));
//            bo.setKoshinUserId(rs.getString("KOSHIN_USER_ID"));
//            bo.setRonriSakujoFlg(rs.getString("RONRI_SAKUJO_FLG"));
//        } catch (SQLException ex) {
//            throw new SQLStateSQLExceptionTranslater().translate(null, ex);
//        }
//    }
//}
