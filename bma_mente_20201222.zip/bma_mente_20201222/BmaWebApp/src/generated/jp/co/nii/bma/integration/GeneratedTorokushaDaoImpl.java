package jp.co.nii.bma.integration;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import jp.co.nii.sew.business.domain.NoSuchDataException;
import jp.co.nii.sew.common.LogGenerate;
import jp.co.nii.sew.integration.AbstractDao;
import jp.co.nii.sew.integration.SQLStateSQLExceptionTranslater;

import jp.co.nii.bma.business.domain.GeneratedTorokusha;
import jp.co.nii.bma.business.domain.GeneratedTorokushaDao;

/**
 * �������ꂽ �o�^�� DAO�����N���X<br>
 * table-design-ver 8
 * @author DB�Ǘ��c�[��
 */
abstract class GeneratedTorokushaDaoImpl extends AbstractDao implements GeneratedTorokushaDao {

    /**
     * �e�[�u���J�������̃J���}��؂蕶����B<br>
     * SQL���̍쐬�ɗp����B
     */
    protected static final String FIELDS = "MOSHIKOMISHA_ID"
            + ",KAIIN_ID"
            + ",KAIIN_KBN"
            + ",LOGIN_KBN"
            + ",KENGEN_KBN"
            + ",SHIMEI"
            + ",FURIGANA"
            + ",BIRTHDAY"
            + ",SEX"
            + ",YUBIN_NO"
            + ",TODOFUKEN_CODE"
            + ",JUSHO_1"
            + ",JUSHO_2"
            + ",TATEMONO"
            + ",TEL_NO"
            + ",FAX_NO"
            + ",MAIL_ADDRESS"
            + ",KUNI_ID"
            + ",KUNIMEI_JPN"
            + ",KUNIMEI_ENG"
            + ",ZAIRYU_CARD_NO"
            + ",KINMUSAKI_NAME"
            + ",KINMUSAKI_YUBIN_NO"
            + ",KINMUSAKI_TODOFUKEN_CODE"
            + ",KINMUSAKI_JUSHO_1"
            + ",KINMUSAKI_JUSHO_2"
            + ",KINMUSAKI_TATEMONO"
            + ",KINMUSAKI_TEL_NO"
            + ",KINMUSAKI_FAX_NO"
            + ",KIGYO_CODE"
            + ",KIGYO_HP_URL"
            + ",KYOKAI_NAME"
            + ",GAIJI_FLG"
            + ",GAIJI_SHOSAI"
            + ",KEKKAKU_FLG"
            + ",BIKO"
            + ",KOSHIN_KBN"
            + ",TOROKU_DATE"
            + ",TOROKU_TIME"
            + ",TOROKU_USER_ID"
            + ",KOSHIN_DATE"
            + ",KOSHIN_TIME"
            + ",KOSHIN_USER_ID"
            + ",RONRI_SAKUJO_FLG";

    /**
     * �e�[�u���J�������̃J���}��؂蕶����B<br>
     *  �Í����Ώۍ��ڂ𕡍�����SQL���̍쐬�ɗp����B
     */
    protected static final String FIELDS_DECRYPT = "MOSHIKOMISHA_ID"
            + "," + "KAIIN_ID"
            + "," + getSQLForDecryptByUTF8("KAIIN_KBN")
            + "," + getSQLForDecryptByUTF8("LOGIN_KBN")
            + "," + getSQLForDecryptByUTF8("KENGEN_KBN")
            + "," + getSQLForDecryptByUTF8("SHIMEI")
            + "," + getSQLForDecryptByUTF8("FURIGANA")
            + "," + getSQLForDecryptByUTF8("BIRTHDAY")
            + "," + getSQLForDecryptByUTF8("SEX")
            + "," + getSQLForDecryptByUTF8("YUBIN_NO")
            + "," + getSQLForDecryptByUTF8("TODOFUKEN_CODE")
            + "," + getSQLForDecryptByUTF8("JUSHO_1")
            + "," + getSQLForDecryptByUTF8("JUSHO_2")
            + "," + getSQLForDecryptByUTF8("TATEMONO")
            + "," + getSQLForDecryptByUTF8("TEL_NO")
            + "," + getSQLForDecryptByUTF8("FAX_NO")
            + "," + getSQLForDecryptByUTF8("MAIL_ADDRESS")
            + "," + getSQLForDecryptByUTF8("KUNI_ID")
            + "," + getSQLForDecryptByUTF8("KUNIMEI_JPN")
            + "," + getSQLForDecryptByUTF8("KUNIMEI_ENG")
            + "," + getSQLForDecryptByUTF8("ZAIRYU_CARD_NO")
            + "," + getSQLForDecryptByUTF8("KINMUSAKI_NAME")
            + "," + getSQLForDecryptByUTF8("KINMUSAKI_YUBIN_NO")
            + "," + getSQLForDecryptByUTF8("KINMUSAKI_TODOFUKEN_CODE")
            + "," + getSQLForDecryptByUTF8("KINMUSAKI_JUSHO_1")
            + "," + getSQLForDecryptByUTF8("KINMUSAKI_JUSHO_2")
            + "," + getSQLForDecryptByUTF8("KINMUSAKI_TATEMONO")
            + "," + getSQLForDecryptByUTF8("KINMUSAKI_TEL_NO")
            + "," + getSQLForDecryptByUTF8("KINMUSAKI_FAX_NO")
            + "," + getSQLForDecryptByUTF8("KIGYO_CODE")
            + "," + getSQLForDecryptByUTF8("KIGYO_HP_URL")
            + "," + getSQLForDecryptByUTF8("KYOKAI_NAME")
            + "," + "GAIJI_FLG"
            + "," + "GAIJI_SHOSAI"
            + "," + "KEKKAKU_FLG"
            + "," + "BIKO"
            + "," + "KOSHIN_KBN"
            + "," + "TOROKU_DATE"
            + "," + "TOROKU_TIME"
            + "," + "TOROKU_USER_ID"
            + "," + "KOSHIN_DATE"
            + "," + "KOSHIN_TIME"
            + "," + "KOSHIN_USER_ID"
            + "," + "RONRI_SAKUJO_FLG";

    /**
     * �C���X�^���X�𐶐�����B<br>
     * �f�[�^�\�[�X������
     * @param datasource �f�[�^�\�[�X��
     */
    public GeneratedTorokushaDaoImpl(String datasource) {
        super(datasource);
    }

    /* (non-Javadoc)
     * @see jp.co.nii.bma.business.domain.GeneratedTorokushaDao#create(jp.co.nii.bma.business.domain.GeneratedTorokusha)
     */
    @Override
    public void create(GeneratedTorokusha bo) {
        Connection con = null;
        PreparedStatement stmt = null;
        String sql = "";
        try {
            con = getConnection();
            sql = "INSERT INTO " + getSchemaName() + "." + TABLE_NAME + " ( "
                    + FIELDS
                    + " ) VALUES ("
                    + " ?"
                    + ",?"
                    + "," + getSQLForEncryptByUTF8("?")
                    + "," + getSQLForEncryptByUTF8("?")
                    + "," + getSQLForEncryptByUTF8("?")
                    + "," + getSQLForEncryptByUTF8("?")
                    + "," + getSQLForEncryptByUTF8("?")
                    + "," + getSQLForEncryptByUTF8("?")
                    + "," + getSQLForEncryptByUTF8("?")
                    + "," + getSQLForEncryptByUTF8("?")
                    + "," + getSQLForEncryptByUTF8("?")
                    + "," + getSQLForEncryptByUTF8("?")
                    + "," + getSQLForEncryptByUTF8("?")
                    + "," + getSQLForEncryptByUTF8("?")
                    + "," + getSQLForEncryptByUTF8("?")
                    + "," + getSQLForEncryptByUTF8("?")
                    + "," + getSQLForEncryptByUTF8("?")
                    + "," + getSQLForEncryptByUTF8("?")
                    + "," + getSQLForEncryptByUTF8("?")
                    + "," + getSQLForEncryptByUTF8("?")
                    + "," + getSQLForEncryptByUTF8("?")
                    + "," + getSQLForEncryptByUTF8("?")
                    + "," + getSQLForEncryptByUTF8("?")
                    + "," + getSQLForEncryptByUTF8("?")
                    + "," + getSQLForEncryptByUTF8("?")
                    + "," + getSQLForEncryptByUTF8("?")
                    + "," + getSQLForEncryptByUTF8("?")
                    + "," + getSQLForEncryptByUTF8("?")
                    + "," + getSQLForEncryptByUTF8("?")
                    + "," + getSQLForEncryptByUTF8("?")
                    + "," + getSQLForEncryptByUTF8("?")
                    + "," + getSQLForEncryptByUTF8("?")
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + " )";

            stmt = con.prepareStatement(sql);
            int i = 1;
            stmt.setString(i++, bo.getMoshikomishaId());
            stmt.setString(i++, bo.getKaiinId());
            stmt.setString(i++, bo.getKaiinKbn());
            stmt.setString(i++, bo.getLoginKbn());
            stmt.setString(i++, bo.getKengenKbn());
            stmt.setString(i++, bo.getShimei());
            stmt.setString(i++, bo.getFurigana());
            stmt.setString(i++, bo.getBirthday());
            stmt.setString(i++, bo.getSex());
            stmt.setString(i++, bo.getYubinNo());
            stmt.setString(i++, bo.getTodofukenCode());
            stmt.setString(i++, bo.getJusho1());
            stmt.setString(i++, bo.getJusho2());
            stmt.setString(i++, bo.getTatemono());
            stmt.setString(i++, bo.getTelNo());
            stmt.setString(i++, bo.getFaxNo());
            stmt.setString(i++, bo.getMailAddress());
            stmt.setString(i++, bo.getKuniId());
            stmt.setString(i++, bo.getKunimeiJpn());
            stmt.setString(i++, bo.getKunimeiEng());
            stmt.setString(i++, bo.getZairyuCardNo());
            stmt.setString(i++, bo.getKinmusakiName());
            stmt.setString(i++, bo.getKinmusakiYubinNo());
            stmt.setString(i++, bo.getKinmusakiTodofukenCode());
            stmt.setString(i++, bo.getKinmusakiJusho1());
            stmt.setString(i++, bo.getKinmusakiJusho2());
            stmt.setString(i++, bo.getKinmusakiTatemono());
            stmt.setString(i++, bo.getKinmusakiTelNo());
            stmt.setString(i++, bo.getKinmusakiFaxNo());
            stmt.setString(i++, bo.getKigyoCode());
            stmt.setString(i++, bo.getKigyoHpUrl());
            stmt.setString(i++, bo.getKyokaiName());
            stmt.setString(i++, bo.getGaijiFlg());
            stmt.setString(i++, bo.getGaijiShosai());
            stmt.setString(i++, bo.getKekkakuFlg());
            stmt.setString(i++, bo.getBiko());
            stmt.setString(i++, bo.getKoshinKbn());
            stmt.setString(i++, bo.getTorokuDate());
            stmt.setString(i++, bo.getTorokuTime());
            stmt.setString(i++, bo.getTorokuUserId());
            stmt.setString(i++, bo.getKoshinDate());
            stmt.setString(i++, bo.getKoshinTime());
            stmt.setString(i++, bo.getKoshinUserId());
            stmt.setString(i++, bo.getRonriSakujoFlg());

            LogGenerate.debugOutput(getSql(stmt));
            stmt.executeUpdate();
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt);
        }
    }

    /* (non-Javadoc)
     * @see jp.co.nii.bma.business.domain.GeneratedTorokushaDao#find(jp.co.nii.bma.business.domain.GeneratedTorokusha, java.lang.String)
     */
    @Override
    public GeneratedTorokusha find(GeneratedTorokusha bo, String lockMode) {
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs =null;
        String sql = "";
        try {
            con = getConnection();
            sql = "SELECT " + FIELDS_DECRYPT
                    + " FROM " + getSchemaName() + "." + TABLE_NAME
                    + " WHERE"
                    + " MOSHIKOMISHA_ID = ?";

            stmt = con.prepareStatement(sql + lockMode);
            int i = 1;
            stmt.setString(i++, bo.getMoshikomishaId());

            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();
            if (rs.next()) {
                setBoFromResultSet(bo, rs);
            } else {
                bo = null;
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return bo;
    }

    /* (non-Javadoc)
     * @see jp.co.nii.bma.business.domain.GeneratedTorokushaDao#update(jp.co.nii.bma.business.domain.GeneratedTorokusha)
     */
    @Override
    public void update(GeneratedTorokusha bo) {
        Connection con = null;
        PreparedStatement stmt = null;
        String sql = "";
        try {
            con = getConnection();
            sql = "UPDATE " + getSchemaName() + "." + TABLE_NAME + " SET"
                    + " KAIIN_ID = ?"
                    + ",KAIIN_KBN = " + getSQLForEncryptByUTF8("?")
                    + ",LOGIN_KBN = " + getSQLForEncryptByUTF8("?")
                    + ",KENGEN_KBN = " + getSQLForEncryptByUTF8("?")
                    + ",SHIMEI = " + getSQLForEncryptByUTF8("?")
                    + ",FURIGANA = " + getSQLForEncryptByUTF8("?")
                    + ",BIRTHDAY = " + getSQLForEncryptByUTF8("?")
                    + ",SEX = " + getSQLForEncryptByUTF8("?")
                    + ",YUBIN_NO = " + getSQLForEncryptByUTF8("?")
                    + ",TODOFUKEN_CODE = " + getSQLForEncryptByUTF8("?")
                    + ",JUSHO_1 = " + getSQLForEncryptByUTF8("?")
                    + ",JUSHO_2 = " + getSQLForEncryptByUTF8("?")
                    + ",TATEMONO = " + getSQLForEncryptByUTF8("?")
                    + ",TEL_NO = " + getSQLForEncryptByUTF8("?")
                    + ",FAX_NO = " + getSQLForEncryptByUTF8("?")
                    + ",MAIL_ADDRESS = " + getSQLForEncryptByUTF8("?")
                    + ",KUNI_ID = " + getSQLForEncryptByUTF8("?")
                    + ",KUNIMEI_JPN = " + getSQLForEncryptByUTF8("?")
                    + ",KUNIMEI_ENG = " + getSQLForEncryptByUTF8("?")
                    + ",ZAIRYU_CARD_NO = " + getSQLForEncryptByUTF8("?")
                    + ",KINMUSAKI_NAME = " + getSQLForEncryptByUTF8("?")
                    + ",KINMUSAKI_YUBIN_NO = " + getSQLForEncryptByUTF8("?")
                    + ",KINMUSAKI_TODOFUKEN_CODE = " + getSQLForEncryptByUTF8("?")
                    + ",KINMUSAKI_JUSHO_1 = " + getSQLForEncryptByUTF8("?")
                    + ",KINMUSAKI_JUSHO_2 = " + getSQLForEncryptByUTF8("?")
                    + ",KINMUSAKI_TATEMONO = " + getSQLForEncryptByUTF8("?")
                    + ",KINMUSAKI_TEL_NO = " + getSQLForEncryptByUTF8("?")
                    + ",KINMUSAKI_FAX_NO = " + getSQLForEncryptByUTF8("?")
                    + ",KIGYO_CODE = " + getSQLForEncryptByUTF8("?")
                    + ",KIGYO_HP_URL = " + getSQLForEncryptByUTF8("?")
                    + ",KYOKAI_NAME = " + getSQLForEncryptByUTF8("?")
                    + ",GAIJI_FLG = ?"
                    + ",GAIJI_SHOSAI = ?"
                    + ",KEKKAKU_FLG = ?"
                    + ",BIKO = ?"
                    + ",KOSHIN_KBN = ?"
                    + ",TOROKU_DATE = ?"
                    + ",TOROKU_TIME = ?"
                    + ",TOROKU_USER_ID = ?"
                    + ",KOSHIN_DATE = ?"
                    + ",KOSHIN_TIME = ?"
                    + ",KOSHIN_USER_ID = ?"
                    + ",RONRI_SAKUJO_FLG = ?"
                    + " WHERE"
                    + " MOSHIKOMISHA_ID = ?";

            stmt = con.prepareStatement(sql);
            int i = 1;
            stmt.setString(i++, bo.getKaiinId());
            stmt.setString(i++, bo.getKaiinKbn());
            stmt.setString(i++, bo.getLoginKbn());
            stmt.setString(i++, bo.getKengenKbn());
            stmt.setString(i++, bo.getShimei());
            stmt.setString(i++, bo.getFurigana());
            stmt.setString(i++, bo.getBirthday());
            stmt.setString(i++, bo.getSex());
            stmt.setString(i++, bo.getYubinNo());
            stmt.setString(i++, bo.getTodofukenCode());
            stmt.setString(i++, bo.getJusho1());
            stmt.setString(i++, bo.getJusho2());
            stmt.setString(i++, bo.getTatemono());
            stmt.setString(i++, bo.getTelNo());
            stmt.setString(i++, bo.getFaxNo());
            stmt.setString(i++, bo.getMailAddress());
            stmt.setString(i++, bo.getKuniId());
            stmt.setString(i++, bo.getKunimeiJpn());
            stmt.setString(i++, bo.getKunimeiEng());
            stmt.setString(i++, bo.getZairyuCardNo());
            stmt.setString(i++, bo.getKinmusakiName());
            stmt.setString(i++, bo.getKinmusakiYubinNo());
            stmt.setString(i++, bo.getKinmusakiTodofukenCode());
            stmt.setString(i++, bo.getKinmusakiJusho1());
            stmt.setString(i++, bo.getKinmusakiJusho2());
            stmt.setString(i++, bo.getKinmusakiTatemono());
            stmt.setString(i++, bo.getKinmusakiTelNo());
            stmt.setString(i++, bo.getKinmusakiFaxNo());
            stmt.setString(i++, bo.getKigyoCode());
            stmt.setString(i++, bo.getKigyoHpUrl());
            stmt.setString(i++, bo.getKyokaiName());
            stmt.setString(i++, bo.getGaijiFlg());
            stmt.setString(i++, bo.getGaijiShosai());
            stmt.setString(i++, bo.getKekkakuFlg());
            stmt.setString(i++, bo.getBiko());
            stmt.setString(i++, bo.getKoshinKbn());
            stmt.setString(i++, bo.getTorokuDate());
            stmt.setString(i++, bo.getTorokuTime());
            stmt.setString(i++, bo.getTorokuUserId());
            stmt.setString(i++, bo.getKoshinDate());
            stmt.setString(i++, bo.getKoshinTime());
            stmt.setString(i++, bo.getKoshinUserId());
            stmt.setString(i++, bo.getRonriSakujoFlg());

            stmt.setString(i++, bo.getMoshikomishaId());

            LogGenerate.debugOutput(getSql(stmt));
            if (stmt.executeUpdate() == 0) {
                throw new NoSuchDataException(getSql(stmt));
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt);
        }
    }

    /* (non-Javadoc)
     * @see jp.co.nii.bma.business.domain.GeneratedTorokushaDao#remove(jp.co.nii.bma.business.domain.GeneratedTorokusha)
     */
    @Override
    public void remove(GeneratedTorokusha bo) {
        Connection con = null;
        PreparedStatement stmt = null;
        String sql = "";
        try {
            con = getConnection();
            sql = "DELETE FROM " + getSchemaName() + "." + TABLE_NAME
                    + " WHERE"
                    + " MOSHIKOMISHA_ID = ?";

            stmt = con.prepareStatement(sql);
            int i = 1;
            stmt.setString(i++, bo.getMoshikomishaId());

            LogGenerate.debugOutput(getSql(stmt));
            if (stmt.executeUpdate() == 0) {
                throw new NoSuchDataException(getSql(stmt));
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt);
        }
    }

    /**
     * �������ʂł���ResultSet��BusinessObject�֋l�ߑւ���B<br>
     * ���O�����F������bo��rs��null�łȂ����ƁB
     * 
     * @param bo BusinessObject�̃C���X�^���X
     * @param rs �������ʂ�ResultSet
     */
    protected void setBoFromResultSet(GeneratedTorokusha bo, ResultSet rs) {
        try {
            bo.setMoshikomishaId(rs.getString("MOSHIKOMISHA_ID"));
            bo.setKaiinId(rs.getString("KAIIN_ID"));
            bo.setKaiinKbn(rs.getString("KAIIN_KBN"));
            bo.setLoginKbn(rs.getString("LOGIN_KBN"));
            bo.setKengenKbn(rs.getString("KENGEN_KBN"));
            bo.setShimei(rs.getString("SHIMEI"));
            bo.setFurigana(rs.getString("FURIGANA"));
            bo.setBirthday(rs.getString("BIRTHDAY"));
            bo.setSex(rs.getString("SEX"));
            bo.setYubinNo(rs.getString("YUBIN_NO"));
            bo.setTodofukenCode(rs.getString("TODOFUKEN_CODE"));
            bo.setJusho1(rs.getString("JUSHO_1"));
            bo.setJusho2(rs.getString("JUSHO_2"));
            bo.setTatemono(rs.getString("TATEMONO"));
            bo.setTelNo(rs.getString("TEL_NO"));
            bo.setFaxNo(rs.getString("FAX_NO"));
            bo.setMailAddress(rs.getString("MAIL_ADDRESS"));
            bo.setKuniId(rs.getString("KUNI_ID"));
            bo.setKunimeiJpn(rs.getString("KUNIMEI_JPN"));
            bo.setKunimeiEng(rs.getString("KUNIMEI_ENG"));
            bo.setZairyuCardNo(rs.getString("ZAIRYU_CARD_NO"));
            bo.setKinmusakiName(rs.getString("KINMUSAKI_NAME"));
            bo.setKinmusakiYubinNo(rs.getString("KINMUSAKI_YUBIN_NO"));
            bo.setKinmusakiTodofukenCode(rs.getString("KINMUSAKI_TODOFUKEN_CODE"));
            bo.setKinmusakiJusho1(rs.getString("KINMUSAKI_JUSHO_1"));
            bo.setKinmusakiJusho2(rs.getString("KINMUSAKI_JUSHO_2"));
            bo.setKinmusakiTatemono(rs.getString("KINMUSAKI_TATEMONO"));
            bo.setKinmusakiTelNo(rs.getString("KINMUSAKI_TEL_NO"));
            bo.setKinmusakiFaxNo(rs.getString("KINMUSAKI_FAX_NO"));
            bo.setKigyoCode(rs.getString("KIGYO_CODE"));
            bo.setKigyoHpUrl(rs.getString("KIGYO_HP_URL"));
            bo.setKyokaiName(rs.getString("KYOKAI_NAME"));
            bo.setGaijiFlg(rs.getString("GAIJI_FLG"));
            bo.setGaijiShosai(rs.getString("GAIJI_SHOSAI"));
            bo.setKekkakuFlg(rs.getString("KEKKAKU_FLG"));
            bo.setBiko(rs.getString("BIKO"));
            bo.setKoshinKbn(rs.getString("KOSHIN_KBN"));
            bo.setTorokuDate(rs.getString("TOROKU_DATE"));
            bo.setTorokuTime(rs.getString("TOROKU_TIME"));
            bo.setTorokuUserId(rs.getString("TOROKU_USER_ID"));
            bo.setKoshinDate(rs.getString("KOSHIN_DATE"));
            bo.setKoshinTime(rs.getString("KOSHIN_TIME"));
            bo.setKoshinUserId(rs.getString("KOSHIN_USER_ID"));
            bo.setRonriSakujoFlg(rs.getString("RONRI_SAKUJO_FLG"));
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(null, ex);
        }
    }
}
