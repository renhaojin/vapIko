//package jp.co.nii.bma.integration;
//
//import java.sql.Connection;
//import java.sql.PreparedStatement;
//import java.sql.ResultSet;
//import java.sql.SQLException;
//
//import jp.co.nii.sew.business.domain.NoSuchDataException;
//import jp.co.nii.sew.common.LogGenerate;
//import jp.co.nii.sew.integration.AbstractDao;
//import jp.co.nii.sew.integration.SQLStateSQLExceptionTranslater;
//
//import jp.co.nii.bma.business.domain.GeneratedJukenNo;
//import jp.co.nii.bma.business.domain.GeneratedJukenNoDao;
//
///**
// * �������ꂽ �󌱔ԍ� DAO�����N���X<br>
// * table-design-ver 7
// * @author DB�Ǘ��c�[��
// */
//abstract class GeneratedJukenNoDaoImpl extends AbstractDao implements GeneratedJukenNoDao {
//
//    /**
//     * �e�[�u���J�������̃J���}��؂蕶����B<br>
//     * SQL���̍쐬�ɗp����B
//     */
//    protected static final String FIELDS = "NEN"
//            + ",SEQ"
//            + ",JUKEN_NO"
//            + ",TODOFUKEN_CODE"
//            + ",JUKEN_KBN"
//            + ",SHIYO_FLG"
//            + ",RONRI_SAKUJO_FLG"
//            + ",SHORI_KBN"
//            + ",TOROKU_DATE"
//            + ",TOROKU_TIME"
//            + ",TOROKU_USER_ID"
//            + ",TOROKU_PROGRAM_ID"
//            + ",KOSHIN_DATE"
//            + ",KOSHIN_TIME"
//            + ",KOSHIN_USER_ID"
//            + ",KOSHIN_PROGRAM_ID";
//
//    /**
//     * �e�[�u���J�������̃J���}��؂蕶����B<br>
//     *  �Í����Ώۍ��ڂ𕡍�����SQL���̍쐬�ɗp����B
//     */
//    protected static final String FIELDS_DECRYPT = "NEN"
//            + "," + "SEQ"
//            + "," + "JUKEN_NO"
//            + "," + "TODOFUKEN_CODE"
//            + "," + "JUKEN_KBN"
//            + "," + "SHIYO_FLG"
//            + "," + "RONRI_SAKUJO_FLG"
//            + "," + "SHORI_KBN"
//            + "," + "TOROKU_DATE"
//            + "," + "TOROKU_TIME"
//            + "," + "TOROKU_USER_ID"
//            + "," + "TOROKU_PROGRAM_ID"
//            + "," + "KOSHIN_DATE"
//            + "," + "KOSHIN_TIME"
//            + "," + "KOSHIN_USER_ID"
//            + "," + "KOSHIN_PROGRAM_ID";
//
//    /**
//     * �C���X�^���X�𐶐�����B<br>
//     * �f�[�^�\�[�X������
//     * @param datasource �f�[�^�\�[�X��
//     */
//    public GeneratedJukenNoDaoImpl(String datasource) {
//        super(datasource);
//    }
//
//    /* (non-Javadoc)
//     * @see jp.co.nii.bma.business.domain.GeneratedJukenNoDao#create(jp.co.nii.bma.business.domain.GeneratedJukenNo)
//     */
//    @Override
//    public void create(GeneratedJukenNo bo) {
//        Connection con = null;
//        PreparedStatement stmt = null;
//        String sql = "";
//        try {
//            con = getConnection();
//            sql = "INSERT INTO " + getSchemaName() + "." + TABLE_NAME + " ( "
//                    + FIELDS
//                    + " ) VALUES ("
//                    + " ?"
//                    + ",?"
//                    + ",?"
//                    + ",?"
//                    + ",?"
//                    + ",?"
//                    + ",?"
//                    + ",?"
//                    + ",?"
//                    + ",?"
//                    + ",?"
//                    + ",?"
//                    + ",?"
//                    + ",?"
//                    + ",?"
//                    + ",?"
//                    + " )";
//
//            stmt = con.prepareStatement(sql);
//            int i = 1;
//            stmt.setString(i++, bo.getNen());
//            stmt.setString(i++, bo.getSeq());
//            stmt.setString(i++, bo.getJukenNo());
//            stmt.setString(i++, bo.getTodofukenCode());
//            stmt.setString(i++, bo.getJukenKbn());
//            stmt.setString(i++, bo.getShiyoFlg());
//            stmt.setString(i++, bo.getRonriSakujoFlg());
//            stmt.setString(i++, bo.getShoriKbn());
//            stmt.setString(i++, bo.getTorokuDate());
//            stmt.setString(i++, bo.getTorokuTime());
//            stmt.setString(i++, bo.getTorokuUserId());
//            stmt.setString(i++, bo.getTorokuProgramId());
//            stmt.setString(i++, bo.getKoshinDate());
//            stmt.setString(i++, bo.getKoshinTime());
//            stmt.setString(i++, bo.getKoshinUserId());
//            stmt.setString(i++, bo.getKoshinProgramId());
//
//            LogGenerate.debugOutput(getSql(stmt));
//            stmt.executeUpdate();
//        } catch (SQLException ex) {
//            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
//        } finally {
//            close(con, stmt);
//        }
//    }
//
//    /* (non-Javadoc)
//     * @see jp.co.nii.bma.business.domain.GeneratedJukenNoDao#find(jp.co.nii.bma.business.domain.GeneratedJukenNo, java.lang.String)
//     */
//    @Override
//    public GeneratedJukenNo find(GeneratedJukenNo bo, String lockMode) {
//        Connection con = null;
//        PreparedStatement stmt = null;
//        ResultSet rs =null;
//        String sql = "";
//        try {
//            con = getConnection();
//            sql = "SELECT " + FIELDS_DECRYPT
//                    + " FROM " + getSchemaName() + "." + TABLE_NAME
//                    + " WHERE"
//                    + " NEN = ?"
//                    + " AND JUKEN_NO = ?";
//
//            stmt = con.prepareStatement(sql + lockMode);
//            int i = 1;
//            stmt.setString(i++, bo.getNen());
//            stmt.setString(i++, bo.getJukenNo());
//
//            LogGenerate.debugOutput(getSql(stmt));
//            rs = stmt.executeQuery();
//            if (rs.next()) {
//                setBoFromResultSet(bo, rs);
//            } else {
//                bo = null;
//            }
//        } catch (SQLException ex) {
//            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
//        } finally {
//            close(con, stmt, rs);
//        }
//        return bo;
//    }
//
//    /* (non-Javadoc)
//     * @see jp.co.nii.bma.business.domain.GeneratedJukenNoDao#update(jp.co.nii.bma.business.domain.GeneratedJukenNo)
//     */
//    @Override
//    public void update(GeneratedJukenNo bo) {
//        Connection con = null;
//        PreparedStatement stmt = null;
//        String sql = "";
//        try {
//            con = getConnection();
//            sql = "UPDATE " + getSchemaName() + "." + TABLE_NAME + " SET"
//                    + " SEQ = ?"
//                    + ",TODOFUKEN_CODE = ?"
//                    + ",JUKEN_KBN = ?"
//                    + ",SHIYO_FLG = ?"
//                    + ",RONRI_SAKUJO_FLG = ?"
//                    + ",SHORI_KBN = ?"
//                    + ",TOROKU_DATE = ?"
//                    + ",TOROKU_TIME = ?"
//                    + ",TOROKU_USER_ID = ?"
//                    + ",TOROKU_PROGRAM_ID = ?"
//                    + ",KOSHIN_DATE = ?"
//                    + ",KOSHIN_TIME = ?"
//                    + ",KOSHIN_USER_ID = ?"
//                    + ",KOSHIN_PROGRAM_ID = ?"
//                    + " WHERE"
//                    + " NEN = ?"
//                    + " AND JUKEN_NO = ?";
//
//            stmt = con.prepareStatement(sql);
//            int i = 1;
//            stmt.setString(i++, bo.getSeq());
//            stmt.setString(i++, bo.getTodofukenCode());
//            stmt.setString(i++, bo.getJukenKbn());
//            stmt.setString(i++, bo.getShiyoFlg());
//            stmt.setString(i++, bo.getRonriSakujoFlg());
//            stmt.setString(i++, bo.getShoriKbn());
//            stmt.setString(i++, bo.getTorokuDate());
//            stmt.setString(i++, bo.getTorokuTime());
//            stmt.setString(i++, bo.getTorokuUserId());
//            stmt.setString(i++, bo.getTorokuProgramId());
//            stmt.setString(i++, bo.getKoshinDate());
//            stmt.setString(i++, bo.getKoshinTime());
//            stmt.setString(i++, bo.getKoshinUserId());
//            stmt.setString(i++, bo.getKoshinProgramId());
//
//            stmt.setString(i++, bo.getNen());
//            stmt.setString(i++, bo.getJukenNo());
//
//            LogGenerate.debugOutput(getSql(stmt));
//            if (stmt.executeUpdate() == 0) {
//                throw new NoSuchDataException(getSql(stmt));
//            }
//        } catch (SQLException ex) {
//            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
//        } finally {
//            close(con, stmt);
//        }
//    }
//
//    /* (non-Javadoc)
//     * @see jp.co.nii.bma.business.domain.GeneratedJukenNoDao#remove(jp.co.nii.bma.business.domain.GeneratedJukenNo)
//     */
//    @Override
//    public void remove(GeneratedJukenNo bo) {
//        Connection con = null;
//        PreparedStatement stmt = null;
//        String sql = "";
//        try {
//            con = getConnection();
//            sql = "DELETE FROM " + getSchemaName() + "." + TABLE_NAME
//                    + " WHERE"
//                    + " NEN = ?"
//                    + " AND JUKEN_NO = ?";
//
//            stmt = con.prepareStatement(sql);
//            int i = 1;
//            stmt.setString(i++, bo.getNen());
//            stmt.setString(i++, bo.getJukenNo());
//
//            LogGenerate.debugOutput(getSql(stmt));
//            if (stmt.executeUpdate() == 0) {
//                throw new NoSuchDataException(getSql(stmt));
//            }
//        } catch (SQLException ex) {
//            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
//        } finally {
//            close(con, stmt);
//        }
//    }
//
//    /**
//     * �������ʂł���ResultSet��BusinessObject�֋l�ߑւ���B<br>
//     * ���O�����F������bo��rs��null�łȂ����ƁB
//     * 
//     * @param bo BusinessObject�̃C���X�^���X
//     * @param rs �������ʂ�ResultSet
//     */
//    protected void setBoFromResultSet(GeneratedJukenNo bo, ResultSet rs) {
//        try {
//            bo.setNen(rs.getString("NEN"));
//            bo.setSeq(rs.getString("SEQ"));
//            bo.setJukenNo(rs.getString("JUKEN_NO"));
//            bo.setTodofukenCode(rs.getString("TODOFUKEN_CODE"));
//            bo.setJukenKbn(rs.getString("JUKEN_KBN"));
//            bo.setShiyoFlg(rs.getString("SHIYO_FLG"));
//            bo.setRonriSakujoFlg(rs.getString("RONRI_SAKUJO_FLG"));
//            bo.setShoriKbn(rs.getString("SHORI_KBN"));
//            bo.setTorokuDate(rs.getString("TOROKU_DATE"));
//            bo.setTorokuTime(rs.getString("TOROKU_TIME"));
//            bo.setTorokuUserId(rs.getString("TOROKU_USER_ID"));
//            bo.setTorokuProgramId(rs.getString("TOROKU_PROGRAM_ID"));
//            bo.setKoshinDate(rs.getString("KOSHIN_DATE"));
//            bo.setKoshinTime(rs.getString("KOSHIN_TIME"));
//            bo.setKoshinUserId(rs.getString("KOSHIN_USER_ID"));
//            bo.setKoshinProgramId(rs.getString("KOSHIN_PROGRAM_ID"));
//        } catch (SQLException ex) {
//            throw new SQLStateSQLExceptionTranslater().translate(null, ex);
//        }
//    }
//}
