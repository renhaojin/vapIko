package jp.co.nii.mock;

/**
 * 企業情報取得API　レスポンス（正常時）
 * 
 * サンプル
kyokai_name = null

 * 
 * @author n-machida
 */
class GetCompanyDataResponse {

//    private int member_id;
//    private String member_name;
//    private String member_kana;
//    private int birth_date;
//    private String country;
//    private int zip_code;
//    private String address;
//    private int tel;
//    private int fax;
//    private String email;
//    private String agreement_datetime;
//    private String member_entry_kbn;
//    
//    // blank
    private String company_code;
    // nullable
//    private String company_name;
//    private String company_kana;
//    private int company_zip_code;
//    private String company_address;
//    private int company_tel;
//    private int company_fax;
//    private String company_member_kbn;
    private String kyokai_name;
    private String url;
//    private String authority;
//    private String corp_kbn;
//    private String migration_flg;

    /**
     * @return the company_code
     */
    public String getCompany_code() {
        return company_code;
    }

    /**
     * @param company_code the company_code to set
     */
    public void setCompany_code(String company_code) {
        this.company_code = company_code;
    }

    /**
     * @return the kyokai_name
     */
    public String getKyokai_name() {
        return kyokai_name;
    }

    /**
     * @param kyokai_name the kyokai_name to set
     */
    public void setKyokai_name(String kyokai_name) {
        this.kyokai_name = kyokai_name;
    }

    /**
     * @return the url
     */
    public String getUrl() {
        return url;
    }

    /**
     * @param url the url to set
     */
    public void setUrl(String url) {
        this.url = url;
    }


}
