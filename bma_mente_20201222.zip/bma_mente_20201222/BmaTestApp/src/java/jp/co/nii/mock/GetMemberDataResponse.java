package jp.co.nii.mock;

/**
 * 会員情報取得API　レスポンス（正常時）
 * 
 * サンプル
member_id = 1724
member_name = 町田 NIIsent223456789032345678904234567890５234567890六234567890７234567890８234567890九234567890
member_kana = ｴﾇｱｲｱｲ ﾏﾁﾀﾞ
birth_date = 19000101
country = アメリカ合衆国
zip_code = 1500002
address = 東京都渋谷区渋谷３－１－４日本情報産業ビル
tel = 0334096301
fax = 0334090158
email = n-machida@nii-sys.net
agreement_datetime = 2020-06-10T15:26:27
company_code = 
company_name = null
company_kana = null
company_zip_code = null
company_address = null
company_tel = null
company_fax = null
company_member_kbn = null
kyokai_name = null
authority = null  
corp_kbn = 99
migration_flg = 0
member_entry_kbn = 0

 * 
 * @author n-machida
 */
class GetMemberDataResponse {

    private int member_id;
    private String member_name;
    private String member_kana;
    private String birth_date;
    private String country;
    private String zip_code;
    private String address;
    private String tel;
    private String fax;
    private String email;
    private String agreement_datetime;
    private String member_entry_kbn;
    
    // blank
    private String company_code;
    // nullable
    private String company_name;
    private String company_kana;
    private String company_zip_code;
    private String company_address;
    private String company_tel;
    private String company_fax;
    private String company_member_kbn;
    private String kyokai_name;
    private String authority;
    private String corp_kbn;
    private String migration_flg;

    /**
     * @return the member_id
     */
    public int getMember_id() {
        return member_id;
    }

    /**
     * @param aMember_id the member_id to set
     */
    public void setMember_id(int aMember_id) {
        member_id = aMember_id;
    }

    /**
     * @return the member_name
     */
    public String getMember_name() {
        return member_name;
    }

    /**
     * @param aMember_name the member_name to set
     */
    public void setMember_name(String aMember_name) {
        member_name = aMember_name;
    }

    /**
     * @return the member_kana
     */
    public String getMember_kana() {
        return member_kana;
    }

    /**
     * @param aMember_kana the member_kana to set
     */
    public void setMember_kana(String aMember_kana) {
        member_kana = aMember_kana;
    }

    /**
     * @return the birth_date
     */
    public String getBirth_date() {
        return birth_date;
    }

    /**
     * @param aBirth_date the birth_date to set
     */
    public void setBirth_date(String aBirth_date) {
        birth_date = aBirth_date;
    }

    /**
     * @return the country
     */
    public String getCountry() {
        return country;
    }

    /**
     * @param aCountry the country to set
     */
    public void setCountry(String aCountry) {
        country = aCountry;
    }

    /**
     * @return the zip_code
     */
    public String getZip_code() {
        return zip_code;
    }

    /**
     * @param aZip_code the zip_code to set
     */
    public void setZip_code(String aZip_code) {
        zip_code = aZip_code;
    }

    /**
     * @return the address
     */
    public String getAddress() {
        return address;
    }

    /**
     * @param aAddress the address to set
     */
    public void setAddress(String aAddress) {
        address = aAddress;
    }

    /**
     * @return the tel
     */
    public String getTel() {
        return tel;
    }

    /**
     * @param aTel the tel to set
     */
    public void setTel(String aTel) {
        tel = aTel;
    }

    /**
     * @return the fax
     */
    public String getFax() {
        return fax;
    }

    /**
     * @param aFax the fax to set
     */
    public void setFax(String aFax) {
        fax = aFax;
    }

    /**
     * @return the email
     */
    public String getEmail() {
        return email;
    }

    /**
     * @param aEmail the email to set
     */
    public void setEmail(String aEmail) {
        email = aEmail;
    }

    /**
     * @return the agreement_datetime
     */
    public String getAgreement_datetime() {
        return agreement_datetime;
    }

    /**
     * @param aAgreement_datetime the agreement_datetime to set
     */
    public void setAgreement_datetime(String aAgreement_datetime) {
        agreement_datetime = aAgreement_datetime;
    }

    /**
     * @return the company_code
     */
    public String getCompany_code() {
        return company_code;
    }

    /**
     * @param aCompany_code the company_code to set
     */
    public void setCompany_code(String aCompany_code) {
        company_code = aCompany_code;
    }

    /**
     * @return the company_name
     */
    public String getCompany_name() {
        return company_name;
    }

    /**
     * @param aCompany_name the company_name to set
     */
    public void setCompany_name(String aCompany_name) {
        company_name = aCompany_name;
    }

    /**
     * @return the company_kana
     */
    public String getCompany_kana() {
        return company_kana;
    }

    /**
     * @param aCompany_kana the company_kana to set
     */
    public void setCompany_kana(String aCompany_kana) {
        company_kana = aCompany_kana;
    }

    /**
     * @return the company_zip_code
     */
    public String getCompany_zip_code() {
        return company_zip_code;
    }

    /**
     * @param aCompany_zip_code the company_zip_code to set
     */
    public void setCompany_zip_code(String aCompany_zip_code) {
        company_zip_code = aCompany_zip_code;
    }

    /**
     * @return the company_address
     */
    public String getCompany_address() {
        return company_address;
    }

    /**
     * @param aCompany_address the company_address to set
     */
    public void setCompany_address(String aCompany_address) {
        company_address = aCompany_address;
    }

    /**
     * @return the company_tel
     */
    public String getCompany_tel() {
        return company_tel;
    }

    /**
     * @param aCompany_tel the company_tel to set
     */
    public void setCompany_tel(String aCompany_tel) {
        company_tel = aCompany_tel;
    }

    /**
     * @return the company_fax
     */
    public String getCompany_fax() {
        return company_fax;
    }

    /**
     * @param aCompany_fax the company_fax to set
     */
    public void setCompany_fax(String aCompany_fax) {
        company_fax = aCompany_fax;
    }

    /**
     * @return the company_member_kbn
     */
    public String getCompany_member_kbn() {
        return company_member_kbn;
    }

    /**
     * @param aCompany_member_kbn the company_member_kbn to set
     */
    public void setCompany_member_kbn(String aCompany_member_kbn) {
        company_member_kbn = aCompany_member_kbn;
    }

    /**
     * @return the kyokai_name
     */
    public String getKyokai_name() {
        return kyokai_name;
    }

    /**
     * @param aKyokai_name the kyokai_name to set
     */
    public void setKyokai_name(String aKyokai_name) {
        kyokai_name = aKyokai_name;
    }

    /**
     * @return the authority
     */
    public String getAuthority() {
        return authority;
    }

    /**
     * @param aAuthority the authority to set
     */
    public void setAuthority(String aAuthority) {
        authority = aAuthority;
    }

    /**
     * @return the corp_kbn
     */
    public String getCorp_kbn() {
        return corp_kbn;
    }

    /**
     * @param aCorp_kbn the corp_kbn to set
     */
    public void setCorp_kbn(String aCorp_kbn) {
        corp_kbn = aCorp_kbn;
    }

    /**
     * @return the migration_flg
     */
    public String getMigration_flg() {
        return migration_flg;
    }

    /**
     * @param aMigration_flg the migration_flg to set
     */
    public void setMigration_flg(String aMigration_flg) {
        migration_flg = aMigration_flg;
    }

    /**
     * @return the member_entry_kbn
     */
    public String getMember_entry_kbn() {
        return member_entry_kbn;
    }

    /**
     * @param member_entry_kbn the member_entry_kbn to set
     */
    public void setMember_entry_kbn(String member_entry_kbn) {
        this.member_entry_kbn = member_entry_kbn;
    }

}
