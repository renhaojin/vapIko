package jp.co.nii.mock;

/**
 * エラーレスポンス
 * @author n-machida
 */
class ErrorResponse {

    private String error_code = null;
    private String error_description = null;
    private String error_message = null;    

    /**
     * @return the error_code
     */
    public String getError_code() {
        return error_code;
    }

    /**
     * @param error_code the error_code to set
     */
    public void setError_code(String error_code) {
        this.error_code = error_code;
    }

    /**
     * @return the error_description
     */
    public String getError_description() {
        return error_description;
    }

    /**
     * @param error_description the error_description to set
     */
    public void setError_description(String error_description) {
        this.error_description = error_description;
    }

    /**
     * @return the error_message
     */
    public String getError_message() {
        return error_message;
    }

    /**
     * @param error_message the error_message to set
     */
    public void setError_message(String error_message) {
        this.error_message = error_message;
    }
    
}
