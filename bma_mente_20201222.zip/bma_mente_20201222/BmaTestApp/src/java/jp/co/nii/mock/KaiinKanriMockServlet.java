package jp.co.nii.mock;

import com.google.gson.Gson;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * 会員管理システムのモック
 *
 * @author n-machida
 */
public class KaiinKanriMockServlet extends HttpServlet {

    private static final String STRING_AND = "&";
    private static final String EQUAL = "=";
    private static final String QUESTION_MARK = "?";

    private final Gson gson = new Gson();

    Log log = LogFactory.getLog(this.getClass());

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        log.info(request.getRequestURI());

        response.setContentType("text/html;charset=UTF-8");

        if ("/jbma_personal/api/authorize".equalsIgnoreCase(request.getRequestURI())) {

            // 常に認可成功として
            // セッションIDをstateにセットして
            String sessionIdInCookie = "";
            Cookie[] cookies = request.getCookies();
            if (cookies == null) {
                sessionIdInCookie = "new cookie";

            } else {
                for (Cookie cookie : cookies) {
                    if ("JSESSIONID".equals(cookie.getName())) {
                        sessionIdInCookie = cookie.getValue();
                    }
                }
            }

            //申込か管理かrefererを見て自動対応
            log.info("referer=" + request.getHeader("referer") + "なので");
            String contextPath = "";
            if (request.getHeader("referer").indexOf("/mgr/") > 0) {
                contextPath = "http://localhost:8080/mgr";
            } else {
                contextPath = "http://localhost:8080";
            }
// 管理へ           
//                contextPath = "http://localhost:8080/mgr";

            
            // 受講・資格管理システムへリダイレクト
            response.sendRedirect(contextPath + "/authorized.cgi" + QUESTION_MARK
                    + OAuthConstants.CODE + EQUAL + "codeValue01234567890123456789012345678ed" + STRING_AND
                    + OAuthConstants.STATE + EQUAL + sessionIdInCookie
            );

        } else if ("/jbma_personal/api/get-access-token".equalsIgnoreCase(request.getRequestURI())) {

            /*
            // エラーはここで設定 /////////////////////////////////////////////
            ErrorResponse res = new ErrorResponse();
            res.setError_code("E001-0001");
            res.setError_description("不正な形式のリクエストです。");
            res.setError_message("ああああああああああああああああ");
             */
            // 正常レスポンス　アクセストークンはここで設定
            GetAccessTokenResponse res = new GetAccessTokenResponse(
                    "accessTokenKeyValue0123456789012345678ed"
            );

            // JSON形式にしてレスポンスを返す
            String gatJsonString = this.gson.toJson(res);
            PrintWriter out = response.getWriter();
            response.setContentType("application/json");
            response.setCharacterEncoding("UTF-8");
            out.print(gatJsonString);
            out.flush();

        } else if ("/jbma_personal/api/get-member-data".equalsIgnoreCase(request.getRequestURI())) {

            /*
            // エラーはここで設定 /////////////////////////////////////////////
            ErrorResponse res = new ErrorResponse();
            res.setError_code("E001-0001");
            res.setError_description("不正な形式のリクエストです。");
            res.setError_message("");
             */
            // 会員情報はここで設定 /////////////////////////////////////////////
            GetMemberDataResponse res = new GetMemberDataResponse();
            res.setMember_id(2099234278); // 個人
//            res.setMember_id(12345); // 個人 IP 無料
            
//            res.setMember_id(2000000299); // 団体
//            res.setMember_id(2000000567); // 管理
            res.setMember_name("金　太郎"); // 200
            res.setMember_kana("ス　ス"); // 200
            res.setBirth_date("20000101");
            res.setCountry("日本国"); // 200
            res.setZip_code("0010001");
            res.setAddress("東京都　渋谷区 渋谷　3-1-4　アルス渋谷八幡601"); // 200
            res.setTel("0334096301"); // int上限10桁
            res.setFax("0334090158"); // int上限10桁
            res.setEmail("j-kin@test-sys.net"); // 80
            res.setAgreement_datetime("1999-12-31T23:59:59");
            res.setCompany_code("ABCdef7890"); // 10
            res.setCompany_name("日本清掃産業株式会社"); // 200
            res.setCompany_kana("ﾆｯﾎﾟﾝｾｲｿｳｻﾝｷﾞｮｳｶﾌﾞｼｷｶﾞｲｼｬ"); // 200
            res.setCompany_zip_code("1040053");
            res.setCompany_address("東京都　江東区 晴海 1-2-3"); // 200
            res.setCompany_tel("0332345678");
            res.setCompany_fax("0342346678");
            res.setCompany_member_kbn("0"); // 0:企業会員
            res.setKyokai_name("東京ビルメンテナンス協会"); // 100
            res.setAuthority("03"); // 03：地区（都道府県）協会
            res.setCorp_kbn("00"); // 00：正会員
            res.setMigration_flg("1"); // 1：移行ユーザー
            res.setMember_entry_kbn("0"); // 申込区分　0：個人申込　1：団体申込　9：協会ユーザー

            // JSON形式にしてレスポンスを返す
            String gatJsonString = this.gson.toJson(res);
            PrintWriter out = response.getWriter();
            response.setContentType("application/json");
            response.setCharacterEncoding("UTF-8");
            out.print(gatJsonString);
            out.flush();

        } else if ("/jbma_personal/api/get-company-data".equalsIgnoreCase(request.getRequestURI())) {

            /*
            // エラーはここで設定 /////////////////////////////////////////////
            ErrorResponse res = new ErrorResponse();
            res.setError_code("E001-0001");
            res.setError_description("不正な形式のリクエストです。");
            res.setError_message("");
             */
            // 企業情報はここで設定 /////////////////////////////////////////////
            GetCompanyDataResponse res = new GetCompanyDataResponse();
            res.setKyokai_name("山形ビルメンテナンス協会34567890123456789012345678901234567890"
                    + "123456789012345678901234567890123456789012345678ed"); // 100
            res.setUrl("https://6url.com7890123456789012345678901234567890"
                    + "12345678901234567890123456789012345678901234567890"
                    + "12345678901234567890123456789012345678901234567890"
                    + "123456789012345678901234567890123456789012345678ed"); // 200

            // JSON形式にしてレスポンスを返す
            String gatJsonString = this.gson.toJson(res);
            PrintWriter out = response.getWriter();
            response.setContentType("application/json");
            response.setCharacterEncoding("UTF-8");
            out.print(gatJsonString);
            out.flush();

        } else {
            log.error("不正なURIが指定されました。" + request.getRequestURI());
            // do nothing
        }

    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
