package jp.co.nii.bma.integration;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import jp.co.nii.sew.business.domain.NoSuchDataException;
import jp.co.nii.sew.common.LogGenerate;
import jp.co.nii.sew.integration.AbstractDao;
import jp.co.nii.sew.integration.SQLStateSQLExceptionTranslater;

import jp.co.nii.bma.business.domain.GeneratedKaiinKanriTsushinLog;
import jp.co.nii.bma.business.domain.GeneratedKaiinKanriTsushinLogDao;

/**
 * �������ꂽ ����Ǘ��ʐM���O DAO�����N���X<br>
 * table-design-ver 1
 * @author DB�Ǘ��c�[��
 */
abstract class GeneratedKaiinKanriTsushinLogDaoImpl extends AbstractDao implements GeneratedKaiinKanriTsushinLogDao {

    /**
     * �e�[�u���J�������̃J���}��؂蕶����B<br>
     * SQL���̍쐬�ɗp����B
     */
    protected static final String FIELDS = "TSUSHIN_TIMESTAMP"
            + ",TSUSHIN_SHUBETSU"
            + ",TSUSHIN_HOUKOU"
            + ",MESSAGE_ID"
            + ",MESSAGE_KENSAKU_KEYWORD"
            + ",MESSAGE";

    /**
     * �e�[�u���J�������̃J���}��؂蕶����B<br>
     *  �Í����Ώۍ��ڂ𕡍�����SQL���̍쐬�ɗp����B
     */
    protected static final String FIELDS_DECRYPT = "TSUSHIN_TIMESTAMP"
            + "," + "TSUSHIN_SHUBETSU"
            + "," + "TSUSHIN_HOUKOU"
            + "," + getSQLForDecryptByUTF8("MESSAGE_ID")
            + "," + getSQLForDecryptByUTF8("MESSAGE_KENSAKU_KEYWORD")
            + "," + getSQLForDecryptByUTF8("MESSAGE");

    /**
     * �C���X�^���X�𐶐�����B<br>
     * �f�[�^�\�[�X������
     * @param datasource �f�[�^�\�[�X��
     */
    public GeneratedKaiinKanriTsushinLogDaoImpl(String datasource) {
        super(datasource);
    }

    /* (non-Javadoc)
     * @see jp.co.nii.bma.business.domain.GeneratedKaiinKanriTsushinLogDao#create(jp.co.nii.bma.business.domain.GeneratedKaiinKanriTsushinLog)
     */
    @Override
    public void create(GeneratedKaiinKanriTsushinLog bo) {
        Connection con = null;
        PreparedStatement stmt = null;
        String sql = "";
        try {
            con = getConnection();
            sql = "INSERT INTO " + getSchemaName() + "." + TABLE_NAME + " ( "
                    + FIELDS
                    + " ) VALUES ("
                    + " ?"
                    + ",?"
                    + ",?"
                    + "," + getSQLForEncryptByUTF8("?")
                    + "," + getSQLForEncryptByUTF8("?")
                    + "," + getSQLForEncryptByUTF8("?")
                    + " )";

            stmt = con.prepareStatement(sql);
            int i = 1;
            stmt.setString(i++, bo.getTsushinTimestamp());
            stmt.setString(i++, bo.getTsushinShubetsu());
            stmt.setString(i++, bo.getTsushinHoukou());
            stmt.setString(i++, bo.getMessageId());
            stmt.setString(i++, bo.getMessageKensakuKeyword());
            stmt.setString(i++, bo.getMessage());

            LogGenerate.debugOutput(getSql(stmt));
            stmt.executeUpdate();
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt);
        }
    }

    /* (non-Javadoc)
     * @see jp.co.nii.bma.business.domain.GeneratedKaiinKanriTsushinLogDao#find(jp.co.nii.bma.business.domain.GeneratedKaiinKanriTsushinLog, java.lang.String)
     */
    @Override
    public GeneratedKaiinKanriTsushinLog find(GeneratedKaiinKanriTsushinLog bo, String lockMode) {
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs =null;
        String sql = "";
        try {
            con = getConnection();
            sql = "SELECT " + FIELDS_DECRYPT
                    + " FROM " + getSchemaName() + "." + TABLE_NAME
                    + " WHERE"
                    + " TSUSHIN_TIMESTAMP = ?"
                    + " AND TSUSHIN_SHUBETSU = ?"
                    + " AND TSUSHIN_HOUKOU = ?"
                    + " AND MESSAGE_ID = " + getSQLForEncryptByUTF8("?");

            stmt = con.prepareStatement(sql + lockMode);
            int i = 1;
            stmt.setString(i++, bo.getTsushinTimestamp());
            stmt.setString(i++, bo.getTsushinShubetsu());
            stmt.setString(i++, bo.getTsushinHoukou());
            stmt.setString(i++, bo.getMessageId());

            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();
            if (rs.next()) {
                setBoFromResultSet(bo, rs);
            } else {
                bo = null;
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return bo;
    }

    /* (non-Javadoc)
     * @see jp.co.nii.bma.business.domain.GeneratedKaiinKanriTsushinLogDao#update(jp.co.nii.bma.business.domain.GeneratedKaiinKanriTsushinLog)
     */
    @Override
    public void update(GeneratedKaiinKanriTsushinLog bo) {
        Connection con = null;
        PreparedStatement stmt = null;
        String sql = "";
        try {
            con = getConnection();
            sql = "UPDATE " + getSchemaName() + "." + TABLE_NAME + " SET"
                    + " MESSAGE_KENSAKU_KEYWORD = " + getSQLForEncryptByUTF8("?")
                    + ",MESSAGE = " + getSQLForEncryptByUTF8("?")
                    + " WHERE"
                    + " TSUSHIN_TIMESTAMP = ?"
                    + " AND TSUSHIN_SHUBETSU = ?"
                    + " AND TSUSHIN_HOUKOU = ?"
                    + " AND MESSAGE_ID = " + getSQLForEncryptByUTF8("?");

            stmt = con.prepareStatement(sql);
            int i = 1;
            stmt.setString(i++, bo.getMessageKensakuKeyword());
            stmt.setString(i++, bo.getMessage());

            stmt.setString(i++, bo.getTsushinTimestamp());
            stmt.setString(i++, bo.getTsushinShubetsu());
            stmt.setString(i++, bo.getTsushinHoukou());
            stmt.setString(i++, bo.getMessageId());

            LogGenerate.debugOutput(getSql(stmt));
            if (stmt.executeUpdate() == 0) {
                throw new NoSuchDataException(getSql(stmt));
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt);
        }
    }

    /* (non-Javadoc)
     * @see jp.co.nii.bma.business.domain.GeneratedKaiinKanriTsushinLogDao#remove(jp.co.nii.bma.business.domain.GeneratedKaiinKanriTsushinLog)
     */
    @Override
    public void remove(GeneratedKaiinKanriTsushinLog bo) {
        Connection con = null;
        PreparedStatement stmt = null;
        String sql = "";
        try {
            con = getConnection();
            sql = "DELETE FROM " + getSchemaName() + "." + TABLE_NAME
                    + " WHERE"
                    + " TSUSHIN_TIMESTAMP = ?"
                    + " AND TSUSHIN_SHUBETSU = ?"
                    + " AND TSUSHIN_HOUKOU = ?"
                    + " AND MESSAGE_ID = " + getSQLForEncryptByUTF8("?");

            stmt = con.prepareStatement(sql);
            int i = 1;
            stmt.setString(i++, bo.getTsushinTimestamp());
            stmt.setString(i++, bo.getTsushinShubetsu());
            stmt.setString(i++, bo.getTsushinHoukou());
            stmt.setString(i++, bo.getMessageId());

            LogGenerate.debugOutput(getSql(stmt));
            if (stmt.executeUpdate() == 0) {
                throw new NoSuchDataException(getSql(stmt));
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt);
        }
    }

    /**
     * �������ʂł���ResultSet��BusinessObject�֋l�ߑւ���B<br>
     * ���O�����F������bo��rs��null�łȂ����ƁB
     * 
     * @param bo BusinessObject�̃C���X�^���X
     * @param rs �������ʂ�ResultSet
     */
    protected void setBoFromResultSet(GeneratedKaiinKanriTsushinLog bo, ResultSet rs) {
        try {
            bo.setTsushinTimestamp(rs.getString("TSUSHIN_TIMESTAMP"));
            bo.setTsushinShubetsu(rs.getString("TSUSHIN_SHUBETSU"));
            bo.setTsushinHoukou(rs.getString("TSUSHIN_HOUKOU"));
            bo.setMessageId(rs.getString("MESSAGE_ID"));
            bo.setMessageKensakuKeyword(rs.getString("MESSAGE_KENSAKU_KEYWORD"));
            bo.setMessage(rs.getString("MESSAGE"));
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(null, ex);
        }
    }
}
