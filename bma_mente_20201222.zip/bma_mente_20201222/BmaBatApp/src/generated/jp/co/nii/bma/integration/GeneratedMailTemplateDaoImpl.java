package jp.co.nii.bma.integration;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import jp.co.nii.sew.business.domain.NoSuchDataException;
import jp.co.nii.sew.common.LogGenerate;
import jp.co.nii.sew.integration.AbstractDao;
import jp.co.nii.sew.integration.SQLStateSQLExceptionTranslater;

import jp.co.nii.bma.business.domain.GeneratedMailTemplate;
import jp.co.nii.bma.business.domain.GeneratedMailTemplateDao;

/**
 * �������ꂽ ���[���e���v���[�g DAO�����N���X<br>
 * table-design-ver 2
 * @author DB�Ǘ��c�[��
 */
abstract class GeneratedMailTemplateDaoImpl extends AbstractDao implements GeneratedMailTemplateDao {

    /**
     * �e�[�u���J�������̃J���}��؂蕶����B<br>
     * SQL���̍쐬�ɗp����B
     */
    protected static final String FIELDS = "MAIL_TEMPLATE_IDX"
            + ",MAIL_TEMPLATE_NAME"
            + ",MAIL_KENMEI"
            + ",MAIL_HONBUN"
            + ",MAIL_FOOTER"
            + ",SHIYO_FLG"
            + ",MAIL_PARAM_01"
            + ",MAIL_PARAM_02"
            + ",MAIL_PARAM_03"
            + ",MAIL_PARAM_04"
            + ",MAIL_PARAM_05"
            + ",MAIL_PARAM_06"
            + ",MAIL_PARAM_07"
            + ",MAIL_PARAM_08"
            + ",MAIL_PARAM_09"
            + ",MAIL_PARAM_10"
            + ",MAIL_PARAM_11"
            + ",MAIL_PARAM_12"
            + ",MAIL_PARAM_13"
            + ",MAIL_PARAM_14"
            + ",MAIL_PARAM_15"
            + ",MAIL_PARAM_16"
            + ",MAIL_PARAM_17"
            + ",MAIL_PARAM_18"
            + ",MAIL_PARAM_19"
            + ",MAIL_PARAM_20"
            + ",MAIL_PARAM_21"
            + ",MAIL_PARAM_22"
            + ",MAIL_PARAM_23"
            + ",MAIL_PARAM_24"
            + ",MAIL_PARAM_25"
            + ",MAIL_PARAM_26"
            + ",MAIL_PARAM_27"
            + ",MAIL_PARAM_28"
            + ",MAIL_PARAM_29"
            + ",MAIL_PARAM_30"
            + ",MAIL_PARAM_31"
            + ",MAIL_PARAM_32"
            + ",MAIL_PARAM_33"
            + ",MAIL_PARAM_34"
            + ",MAIL_PARAM_35"
            + ",MAIL_PARAM_36"
            + ",MAIL_PARAM_37"
            + ",MAIL_PARAM_38"
            + ",MAIL_PARAM_39"
            + ",MAIL_PARAM_40"
            + ",MAIL_PARAM_41"
            + ",MAIL_PARAM_42"
            + ",MAIL_PARAM_43"
            + ",MAIL_PARAM_44"
            + ",MAIL_PARAM_45"
            + ",MAIL_PARAM_46"
            + ",MAIL_PARAM_47"
            + ",MAIL_PARAM_48"
            + ",MAIL_PARAM_49"
            + ",MAIL_PARAM_50"
            + ",KOSHIN_KBN"
            + ",TOROKU_DATE"
            + ",TOROKU_TIME"
            + ",TOROKU_USER_ID"
            + ",KOSHIN_DATE"
            + ",KOSHIN_TIME"
            + ",KOSHIN_USER_ID"
            + ",RONRI_SAKUJO_FLG";

    /**
     * �e�[�u���J�������̃J���}��؂蕶����B<br>
     *  �Í����Ώۍ��ڂ𕡍�����SQL���̍쐬�ɗp����B
     */
    protected static final String FIELDS_DECRYPT = "MAIL_TEMPLATE_IDX"
            + "," + "MAIL_TEMPLATE_NAME"
            + "," + "MAIL_KENMEI"
            + "," + "MAIL_HONBUN"
            + "," + "MAIL_FOOTER"
            + "," + "SHIYO_FLG"
            + "," + "MAIL_PARAM_01"
            + "," + "MAIL_PARAM_02"
            + "," + "MAIL_PARAM_03"
            + "," + "MAIL_PARAM_04"
            + "," + "MAIL_PARAM_05"
            + "," + "MAIL_PARAM_06"
            + "," + "MAIL_PARAM_07"
            + "," + "MAIL_PARAM_08"
            + "," + "MAIL_PARAM_09"
            + "," + "MAIL_PARAM_10"
            + "," + "MAIL_PARAM_11"
            + "," + "MAIL_PARAM_12"
            + "," + "MAIL_PARAM_13"
            + "," + "MAIL_PARAM_14"
            + "," + "MAIL_PARAM_15"
            + "," + "MAIL_PARAM_16"
            + "," + "MAIL_PARAM_17"
            + "," + "MAIL_PARAM_18"
            + "," + "MAIL_PARAM_19"
            + "," + "MAIL_PARAM_20"
            + "," + "MAIL_PARAM_21"
            + "," + "MAIL_PARAM_22"
            + "," + "MAIL_PARAM_23"
            + "," + "MAIL_PARAM_24"
            + "," + "MAIL_PARAM_25"
            + "," + "MAIL_PARAM_26"
            + "," + "MAIL_PARAM_27"
            + "," + "MAIL_PARAM_28"
            + "," + "MAIL_PARAM_29"
            + "," + "MAIL_PARAM_30"
            + "," + "MAIL_PARAM_31"
            + "," + "MAIL_PARAM_32"
            + "," + "MAIL_PARAM_33"
            + "," + "MAIL_PARAM_34"
            + "," + "MAIL_PARAM_35"
            + "," + "MAIL_PARAM_36"
            + "," + "MAIL_PARAM_37"
            + "," + "MAIL_PARAM_38"
            + "," + "MAIL_PARAM_39"
            + "," + "MAIL_PARAM_40"
            + "," + "MAIL_PARAM_41"
            + "," + "MAIL_PARAM_42"
            + "," + "MAIL_PARAM_43"
            + "," + "MAIL_PARAM_44"
            + "," + "MAIL_PARAM_45"
            + "," + "MAIL_PARAM_46"
            + "," + "MAIL_PARAM_47"
            + "," + "MAIL_PARAM_48"
            + "," + "MAIL_PARAM_49"
            + "," + "MAIL_PARAM_50"
            + "," + "KOSHIN_KBN"
            + "," + "TOROKU_DATE"
            + "," + "TOROKU_TIME"
            + "," + "TOROKU_USER_ID"
            + "," + "KOSHIN_DATE"
            + "," + "KOSHIN_TIME"
            + "," + "KOSHIN_USER_ID"
            + "," + "RONRI_SAKUJO_FLG";

    /**
     * �C���X�^���X�𐶐�����B<br>
     * �f�[�^�\�[�X������
     * @param datasource �f�[�^�\�[�X��
     */
    public GeneratedMailTemplateDaoImpl(String datasource) {
        super(datasource);
    }

    /* (non-Javadoc)
     * @see jp.co.nii.bma.business.domain.GeneratedMailTemplateDao#create(jp.co.nii.bma.business.domain.GeneratedMailTemplate)
     */
    @Override
    public void create(GeneratedMailTemplate bo) {
        Connection con = null;
        PreparedStatement stmt = null;
        String sql = "";
        try {
            con = getConnection();
            sql = "INSERT INTO " + getSchemaName() + "." + TABLE_NAME + " ( "
                    + FIELDS
                    + " ) VALUES ("
                    + " ?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + " )";

            stmt = con.prepareStatement(sql);
            int i = 1;
            stmt.setString(i++, bo.getMailTemplateIdx());
            stmt.setString(i++, bo.getMailTemplateName());
            stmt.setString(i++, bo.getMailKenmei());
            stmt.setString(i++, bo.getMailHonbun());
            stmt.setString(i++, bo.getMailFooter());
            stmt.setString(i++, bo.getShiyoFlg());
            stmt.setString(i++, bo.getMailParam01());
            stmt.setString(i++, bo.getMailParam02());
            stmt.setString(i++, bo.getMailParam03());
            stmt.setString(i++, bo.getMailParam04());
            stmt.setString(i++, bo.getMailParam05());
            stmt.setString(i++, bo.getMailParam06());
            stmt.setString(i++, bo.getMailParam07());
            stmt.setString(i++, bo.getMailParam08());
            stmt.setString(i++, bo.getMailParam09());
            stmt.setString(i++, bo.getMailParam10());
            stmt.setString(i++, bo.getMailParam11());
            stmt.setString(i++, bo.getMailParam12());
            stmt.setString(i++, bo.getMailParam13());
            stmt.setString(i++, bo.getMailParam14());
            stmt.setString(i++, bo.getMailParam15());
            stmt.setString(i++, bo.getMailParam16());
            stmt.setString(i++, bo.getMailParam17());
            stmt.setString(i++, bo.getMailParam18());
            stmt.setString(i++, bo.getMailParam19());
            stmt.setString(i++, bo.getMailParam20());
            stmt.setString(i++, bo.getMailParam21());
            stmt.setString(i++, bo.getMailParam22());
            stmt.setString(i++, bo.getMailParam23());
            stmt.setString(i++, bo.getMailParam24());
            stmt.setString(i++, bo.getMailParam25());
            stmt.setString(i++, bo.getMailParam26());
            stmt.setString(i++, bo.getMailParam27());
            stmt.setString(i++, bo.getMailParam28());
            stmt.setString(i++, bo.getMailParam29());
            stmt.setString(i++, bo.getMailParam30());
            stmt.setString(i++, bo.getMailParam31());
            stmt.setString(i++, bo.getMailParam32());
            stmt.setString(i++, bo.getMailParam33());
            stmt.setString(i++, bo.getMailParam34());
            stmt.setString(i++, bo.getMailParam35());
            stmt.setString(i++, bo.getMailParam36());
            stmt.setString(i++, bo.getMailParam37());
            stmt.setString(i++, bo.getMailParam38());
            stmt.setString(i++, bo.getMailParam39());
            stmt.setString(i++, bo.getMailParam40());
            stmt.setString(i++, bo.getMailParam41());
            stmt.setString(i++, bo.getMailParam42());
            stmt.setString(i++, bo.getMailParam43());
            stmt.setString(i++, bo.getMailParam44());
            stmt.setString(i++, bo.getMailParam45());
            stmt.setString(i++, bo.getMailParam46());
            stmt.setString(i++, bo.getMailParam47());
            stmt.setString(i++, bo.getMailParam48());
            stmt.setString(i++, bo.getMailParam49());
            stmt.setString(i++, bo.getMailParam50());
            stmt.setString(i++, bo.getKoshinKbn());
            stmt.setString(i++, bo.getTorokuDate());
            stmt.setString(i++, bo.getTorokuTime());
            stmt.setString(i++, bo.getTorokuUserId());
            stmt.setString(i++, bo.getKoshinDate());
            stmt.setString(i++, bo.getKoshinTime());
            stmt.setString(i++, bo.getKoshinUserId());
            stmt.setString(i++, bo.getRonriSakujoFlg());

            LogGenerate.debugOutput(getSql(stmt));
            stmt.executeUpdate();
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt);
        }
    }

    /* (non-Javadoc)
     * @see jp.co.nii.bma.business.domain.GeneratedMailTemplateDao#find(jp.co.nii.bma.business.domain.GeneratedMailTemplate, java.lang.String)
     */
    @Override
    public GeneratedMailTemplate find(GeneratedMailTemplate bo, String lockMode) {
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs =null;
        String sql = "";
        try {
            con = getConnection();
            sql = "SELECT " + FIELDS_DECRYPT
                    + " FROM " + getSchemaName() + "." + TABLE_NAME
                    + " WHERE"
                    + " MAIL_TEMPLATE_IDX = ?";

            stmt = con.prepareStatement(sql + lockMode);
            int i = 1;
            stmt.setString(i++, bo.getMailTemplateIdx());

            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();
            if (rs.next()) {
                setBoFromResultSet(bo, rs);
            } else {
                bo = null;
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return bo;
    }

    /* (non-Javadoc)
     * @see jp.co.nii.bma.business.domain.GeneratedMailTemplateDao#update(jp.co.nii.bma.business.domain.GeneratedMailTemplate)
     */
    @Override
    public void update(GeneratedMailTemplate bo) {
        Connection con = null;
        PreparedStatement stmt = null;
        String sql = "";
        try {
            con = getConnection();
            sql = "UPDATE " + getSchemaName() + "." + TABLE_NAME + " SET"
                    + " MAIL_TEMPLATE_NAME = ?"
                    + ",MAIL_KENMEI = ?"
                    + ",MAIL_HONBUN = ?"
                    + ",MAIL_FOOTER = ?"
                    + ",SHIYO_FLG = ?"
                    + ",MAIL_PARAM_01 = ?"
                    + ",MAIL_PARAM_02 = ?"
                    + ",MAIL_PARAM_03 = ?"
                    + ",MAIL_PARAM_04 = ?"
                    + ",MAIL_PARAM_05 = ?"
                    + ",MAIL_PARAM_06 = ?"
                    + ",MAIL_PARAM_07 = ?"
                    + ",MAIL_PARAM_08 = ?"
                    + ",MAIL_PARAM_09 = ?"
                    + ",MAIL_PARAM_10 = ?"
                    + ",MAIL_PARAM_11 = ?"
                    + ",MAIL_PARAM_12 = ?"
                    + ",MAIL_PARAM_13 = ?"
                    + ",MAIL_PARAM_14 = ?"
                    + ",MAIL_PARAM_15 = ?"
                    + ",MAIL_PARAM_16 = ?"
                    + ",MAIL_PARAM_17 = ?"
                    + ",MAIL_PARAM_18 = ?"
                    + ",MAIL_PARAM_19 = ?"
                    + ",MAIL_PARAM_20 = ?"
                    + ",MAIL_PARAM_21 = ?"
                    + ",MAIL_PARAM_22 = ?"
                    + ",MAIL_PARAM_23 = ?"
                    + ",MAIL_PARAM_24 = ?"
                    + ",MAIL_PARAM_25 = ?"
                    + ",MAIL_PARAM_26 = ?"
                    + ",MAIL_PARAM_27 = ?"
                    + ",MAIL_PARAM_28 = ?"
                    + ",MAIL_PARAM_29 = ?"
                    + ",MAIL_PARAM_30 = ?"
                    + ",MAIL_PARAM_31 = ?"
                    + ",MAIL_PARAM_32 = ?"
                    + ",MAIL_PARAM_33 = ?"
                    + ",MAIL_PARAM_34 = ?"
                    + ",MAIL_PARAM_35 = ?"
                    + ",MAIL_PARAM_36 = ?"
                    + ",MAIL_PARAM_37 = ?"
                    + ",MAIL_PARAM_38 = ?"
                    + ",MAIL_PARAM_39 = ?"
                    + ",MAIL_PARAM_40 = ?"
                    + ",MAIL_PARAM_41 = ?"
                    + ",MAIL_PARAM_42 = ?"
                    + ",MAIL_PARAM_43 = ?"
                    + ",MAIL_PARAM_44 = ?"
                    + ",MAIL_PARAM_45 = ?"
                    + ",MAIL_PARAM_46 = ?"
                    + ",MAIL_PARAM_47 = ?"
                    + ",MAIL_PARAM_48 = ?"
                    + ",MAIL_PARAM_49 = ?"
                    + ",MAIL_PARAM_50 = ?"
                    + ",KOSHIN_KBN = ?"
                    + ",TOROKU_DATE = ?"
                    + ",TOROKU_TIME = ?"
                    + ",TOROKU_USER_ID = ?"
                    + ",KOSHIN_DATE = ?"
                    + ",KOSHIN_TIME = ?"
                    + ",KOSHIN_USER_ID = ?"
                    + ",RONRI_SAKUJO_FLG = ?"
                    + " WHERE"
                    + " MAIL_TEMPLATE_IDX = ?";

            stmt = con.prepareStatement(sql);
            int i = 1;
            stmt.setString(i++, bo.getMailTemplateName());
            stmt.setString(i++, bo.getMailKenmei());
            stmt.setString(i++, bo.getMailHonbun());
            stmt.setString(i++, bo.getMailFooter());
            stmt.setString(i++, bo.getShiyoFlg());
            stmt.setString(i++, bo.getMailParam01());
            stmt.setString(i++, bo.getMailParam02());
            stmt.setString(i++, bo.getMailParam03());
            stmt.setString(i++, bo.getMailParam04());
            stmt.setString(i++, bo.getMailParam05());
            stmt.setString(i++, bo.getMailParam06());
            stmt.setString(i++, bo.getMailParam07());
            stmt.setString(i++, bo.getMailParam08());
            stmt.setString(i++, bo.getMailParam09());
            stmt.setString(i++, bo.getMailParam10());
            stmt.setString(i++, bo.getMailParam11());
            stmt.setString(i++, bo.getMailParam12());
            stmt.setString(i++, bo.getMailParam13());
            stmt.setString(i++, bo.getMailParam14());
            stmt.setString(i++, bo.getMailParam15());
            stmt.setString(i++, bo.getMailParam16());
            stmt.setString(i++, bo.getMailParam17());
            stmt.setString(i++, bo.getMailParam18());
            stmt.setString(i++, bo.getMailParam19());
            stmt.setString(i++, bo.getMailParam20());
            stmt.setString(i++, bo.getMailParam21());
            stmt.setString(i++, bo.getMailParam22());
            stmt.setString(i++, bo.getMailParam23());
            stmt.setString(i++, bo.getMailParam24());
            stmt.setString(i++, bo.getMailParam25());
            stmt.setString(i++, bo.getMailParam26());
            stmt.setString(i++, bo.getMailParam27());
            stmt.setString(i++, bo.getMailParam28());
            stmt.setString(i++, bo.getMailParam29());
            stmt.setString(i++, bo.getMailParam30());
            stmt.setString(i++, bo.getMailParam31());
            stmt.setString(i++, bo.getMailParam32());
            stmt.setString(i++, bo.getMailParam33());
            stmt.setString(i++, bo.getMailParam34());
            stmt.setString(i++, bo.getMailParam35());
            stmt.setString(i++, bo.getMailParam36());
            stmt.setString(i++, bo.getMailParam37());
            stmt.setString(i++, bo.getMailParam38());
            stmt.setString(i++, bo.getMailParam39());
            stmt.setString(i++, bo.getMailParam40());
            stmt.setString(i++, bo.getMailParam41());
            stmt.setString(i++, bo.getMailParam42());
            stmt.setString(i++, bo.getMailParam43());
            stmt.setString(i++, bo.getMailParam44());
            stmt.setString(i++, bo.getMailParam45());
            stmt.setString(i++, bo.getMailParam46());
            stmt.setString(i++, bo.getMailParam47());
            stmt.setString(i++, bo.getMailParam48());
            stmt.setString(i++, bo.getMailParam49());
            stmt.setString(i++, bo.getMailParam50());
            stmt.setString(i++, bo.getKoshinKbn());
            stmt.setString(i++, bo.getTorokuDate());
            stmt.setString(i++, bo.getTorokuTime());
            stmt.setString(i++, bo.getTorokuUserId());
            stmt.setString(i++, bo.getKoshinDate());
            stmt.setString(i++, bo.getKoshinTime());
            stmt.setString(i++, bo.getKoshinUserId());
            stmt.setString(i++, bo.getRonriSakujoFlg());

            stmt.setString(i++, bo.getMailTemplateIdx());

            LogGenerate.debugOutput(getSql(stmt));
            if (stmt.executeUpdate() == 0) {
                throw new NoSuchDataException(getSql(stmt));
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt);
        }
    }

    /* (non-Javadoc)
     * @see jp.co.nii.bma.business.domain.GeneratedMailTemplateDao#remove(jp.co.nii.bma.business.domain.GeneratedMailTemplate)
     */
    @Override
    public void remove(GeneratedMailTemplate bo) {
        Connection con = null;
        PreparedStatement stmt = null;
        String sql = "";
        try {
            con = getConnection();
            sql = "DELETE FROM " + getSchemaName() + "." + TABLE_NAME
                    + " WHERE"
                    + " MAIL_TEMPLATE_IDX = ?";

            stmt = con.prepareStatement(sql);
            int i = 1;
            stmt.setString(i++, bo.getMailTemplateIdx());

            LogGenerate.debugOutput(getSql(stmt));
            if (stmt.executeUpdate() == 0) {
                throw new NoSuchDataException(getSql(stmt));
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt);
        }
    }

    /**
     * �������ʂł���ResultSet��BusinessObject�֋l�ߑւ���B<br>
     * ���O�����F������bo��rs��null�łȂ����ƁB
     * 
     * @param bo BusinessObject�̃C���X�^���X
     * @param rs �������ʂ�ResultSet
     */
    protected void setBoFromResultSet(GeneratedMailTemplate bo, ResultSet rs) {
        try {
            bo.setMailTemplateIdx(rs.getString("MAIL_TEMPLATE_IDX"));
            bo.setMailTemplateName(rs.getString("MAIL_TEMPLATE_NAME"));
            bo.setMailKenmei(rs.getString("MAIL_KENMEI"));
            bo.setMailHonbun(rs.getString("MAIL_HONBUN"));
            bo.setMailFooter(rs.getString("MAIL_FOOTER"));
            bo.setShiyoFlg(rs.getString("SHIYO_FLG"));
            bo.setMailParam01(rs.getString("MAIL_PARAM_01"));
            bo.setMailParam02(rs.getString("MAIL_PARAM_02"));
            bo.setMailParam03(rs.getString("MAIL_PARAM_03"));
            bo.setMailParam04(rs.getString("MAIL_PARAM_04"));
            bo.setMailParam05(rs.getString("MAIL_PARAM_05"));
            bo.setMailParam06(rs.getString("MAIL_PARAM_06"));
            bo.setMailParam07(rs.getString("MAIL_PARAM_07"));
            bo.setMailParam08(rs.getString("MAIL_PARAM_08"));
            bo.setMailParam09(rs.getString("MAIL_PARAM_09"));
            bo.setMailParam10(rs.getString("MAIL_PARAM_10"));
            bo.setMailParam11(rs.getString("MAIL_PARAM_11"));
            bo.setMailParam12(rs.getString("MAIL_PARAM_12"));
            bo.setMailParam13(rs.getString("MAIL_PARAM_13"));
            bo.setMailParam14(rs.getString("MAIL_PARAM_14"));
            bo.setMailParam15(rs.getString("MAIL_PARAM_15"));
            bo.setMailParam16(rs.getString("MAIL_PARAM_16"));
            bo.setMailParam17(rs.getString("MAIL_PARAM_17"));
            bo.setMailParam18(rs.getString("MAIL_PARAM_18"));
            bo.setMailParam19(rs.getString("MAIL_PARAM_19"));
            bo.setMailParam20(rs.getString("MAIL_PARAM_20"));
            bo.setMailParam21(rs.getString("MAIL_PARAM_21"));
            bo.setMailParam22(rs.getString("MAIL_PARAM_22"));
            bo.setMailParam23(rs.getString("MAIL_PARAM_23"));
            bo.setMailParam24(rs.getString("MAIL_PARAM_24"));
            bo.setMailParam25(rs.getString("MAIL_PARAM_25"));
            bo.setMailParam26(rs.getString("MAIL_PARAM_26"));
            bo.setMailParam27(rs.getString("MAIL_PARAM_27"));
            bo.setMailParam28(rs.getString("MAIL_PARAM_28"));
            bo.setMailParam29(rs.getString("MAIL_PARAM_29"));
            bo.setMailParam30(rs.getString("MAIL_PARAM_30"));
            bo.setMailParam31(rs.getString("MAIL_PARAM_31"));
            bo.setMailParam32(rs.getString("MAIL_PARAM_32"));
            bo.setMailParam33(rs.getString("MAIL_PARAM_33"));
            bo.setMailParam34(rs.getString("MAIL_PARAM_34"));
            bo.setMailParam35(rs.getString("MAIL_PARAM_35"));
            bo.setMailParam36(rs.getString("MAIL_PARAM_36"));
            bo.setMailParam37(rs.getString("MAIL_PARAM_37"));
            bo.setMailParam38(rs.getString("MAIL_PARAM_38"));
            bo.setMailParam39(rs.getString("MAIL_PARAM_39"));
            bo.setMailParam40(rs.getString("MAIL_PARAM_40"));
            bo.setMailParam41(rs.getString("MAIL_PARAM_41"));
            bo.setMailParam42(rs.getString("MAIL_PARAM_42"));
            bo.setMailParam43(rs.getString("MAIL_PARAM_43"));
            bo.setMailParam44(rs.getString("MAIL_PARAM_44"));
            bo.setMailParam45(rs.getString("MAIL_PARAM_45"));
            bo.setMailParam46(rs.getString("MAIL_PARAM_46"));
            bo.setMailParam47(rs.getString("MAIL_PARAM_47"));
            bo.setMailParam48(rs.getString("MAIL_PARAM_48"));
            bo.setMailParam49(rs.getString("MAIL_PARAM_49"));
            bo.setMailParam50(rs.getString("MAIL_PARAM_50"));
            bo.setKoshinKbn(rs.getString("KOSHIN_KBN"));
            bo.setTorokuDate(rs.getString("TOROKU_DATE"));
            bo.setTorokuTime(rs.getString("TOROKU_TIME"));
            bo.setTorokuUserId(rs.getString("TOROKU_USER_ID"));
            bo.setKoshinDate(rs.getString("KOSHIN_DATE"));
            bo.setKoshinTime(rs.getString("KOSHIN_TIME"));
            bo.setKoshinUserId(rs.getString("KOSHIN_USER_ID"));
            bo.setRonriSakujoFlg(rs.getString("RONRI_SAKUJO_FLG"));
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(null, ex);
        }
    }
}
