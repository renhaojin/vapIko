package jp.co.nii.bma.integration;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import jp.co.nii.sew.business.domain.NoSuchDataException;
import jp.co.nii.sew.common.LogGenerate;
import jp.co.nii.sew.integration.AbstractDao;
import jp.co.nii.sew.integration.SQLStateSQLExceptionTranslater;

import jp.co.nii.bma.business.domain.GeneratedMoshikomi;
import jp.co.nii.bma.business.domain.GeneratedMoshikomiDao;

/**
 * �������ꂽ �\�� DAO�����N���X<br>
 * table-design-ver 14
 * @author DB�Ǘ��c�[��
 */
abstract class GeneratedMoshikomiDaoImpl extends AbstractDao implements GeneratedMoshikomiDao {

    /**
     * �e�[�u���J�������̃J���}��؂蕶����B<br>
     * SQL���̍쐬�ɗp����B
     */
    protected static final String FIELDS = "MOSHIKOMISHA_ID"
            + ",NENDO"
            + ",SKN_KSU_CODE"
            + ",SHUBETSU_CODE"
            + ",KAISU_CODE"
            + ",KIBO_KAISAICHI_CODE"
            + ",KAIJO_ID1"
            + ",KAISAICHI_CODE1"
            + ",KAIJO_CODE1"
            + ",KYOSHITSU_CODE1"
            + ",KAIJO_ID2"
            + ",KAISAICHI_CODE2"
            + ",KAIJO_CODE2"
            + ",KYOSHITSU_CODE2"
            + ",MOSHIKOMI_KBN"
            + ",KOJIN_DANTAI_KBN"
            + ",KAIIN_SHINSEI_FLG"
            + ",MOSHIKOMI_JOKYO_KBN"
            + ",UNYO_JOKYO_KBN"
            + ",GOHI_JOKYO_KBN"
            + ",SHOMEN_UKETSUKE_NO"
            + ",UKETSUKE_NO"
            + ",JUKEN_JUKO_NO"
            + ",SHIKEN_NAIYO_KBN"
            + ",SOFU_SAKI_KBN"
            + ",HAIRYO_FLG"
            + ",HAIRYO_NAIYO"
            + ",GENMEN_FLG"
            + ",NENREI"
            + ",KARI_UKETSUKE_BI"
            + ",KARI_UKETSUKE_TIME"
            + ",MOSHIKOMI_TOROKU_DATE"
            + ",MOSHIKOMI_TOROKU_TIME"
            + ",MOSHIKOMI_FINISH_BI"
            + ",MOSHIKOMI_FINISH_TIME"
            + ",HOSEI_IRAI_KBN"
            + ",KANRI_MEMO"
            + ",KOSHIN_KBN"
            + ",TOROKU_DATE"
            + ",TOROKU_TIME"
            + ",TOROKU_USER_ID"
            + ",KOSHIN_DATE"
            + ",KOSHIN_TIME"
            + ",KOSHIN_USER_ID"
            + ",RONRI_SAKUJO_FLG";

    /**
     * �e�[�u���J�������̃J���}��؂蕶����B<br>
     *  �Í����Ώۍ��ڂ𕡍�����SQL���̍쐬�ɗp����B
     */
    protected static final String FIELDS_DECRYPT = "MOSHIKOMISHA_ID"
            + "," + "NENDO"
            + "," + "SKN_KSU_CODE"
            + "," + "SHUBETSU_CODE"
            + "," + "KAISU_CODE"
            + "," + "KIBO_KAISAICHI_CODE"
            + "," + "KAIJO_ID1"
            + "," + "KAISAICHI_CODE1"
            + "," + "KAIJO_CODE1"
            + "," + "KYOSHITSU_CODE1"
            + "," + "KAIJO_ID2"
            + "," + "KAISAICHI_CODE2"
            + "," + "KAIJO_CODE2"
            + "," + "KYOSHITSU_CODE2"
            + "," + "MOSHIKOMI_KBN"
            + "," + "KOJIN_DANTAI_KBN"
            + "," + "KAIIN_SHINSEI_FLG"
            + "," + "MOSHIKOMI_JOKYO_KBN"
            + "," + "UNYO_JOKYO_KBN"
            + "," + "GOHI_JOKYO_KBN"
            + "," + "SHOMEN_UKETSUKE_NO"
            + "," + "UKETSUKE_NO"
            + "," + "JUKEN_JUKO_NO"
            + "," + "SHIKEN_NAIYO_KBN"
            + "," + "SOFU_SAKI_KBN"
            + "," + "HAIRYO_FLG"
            + "," + "HAIRYO_NAIYO"
            + "," + "GENMEN_FLG"
            + "," + "NENREI"
            + "," + "KARI_UKETSUKE_BI"
            + "," + "KARI_UKETSUKE_TIME"
            + "," + "MOSHIKOMI_TOROKU_DATE"
            + "," + "MOSHIKOMI_TOROKU_TIME"
            + "," + "MOSHIKOMI_FINISH_BI"
            + "," + "MOSHIKOMI_FINISH_TIME"
            + "," + "HOSEI_IRAI_KBN"
            + "," + "KANRI_MEMO"
            + "," + "KOSHIN_KBN"
            + "," + "TOROKU_DATE"
            + "," + "TOROKU_TIME"
            + "," + "TOROKU_USER_ID"
            + "," + "KOSHIN_DATE"
            + "," + "KOSHIN_TIME"
            + "," + "KOSHIN_USER_ID"
            + "," + "RONRI_SAKUJO_FLG";

    /**
     * �C���X�^���X�𐶐�����B<br>
     * �f�[�^�\�[�X������
     * @param datasource �f�[�^�\�[�X��
     */
    public GeneratedMoshikomiDaoImpl(String datasource) {
        super(datasource);
    }

    /* (non-Javadoc)
     * @see jp.co.nii.bma.business.domain.GeneratedMoshikomiDao#create(jp.co.nii.bma.business.domain.GeneratedMoshikomi)
     */
    @Override
    public void create(GeneratedMoshikomi bo) {
        Connection con = null;
        PreparedStatement stmt = null;
        String sql = "";
        try {
            con = getConnection();
            sql = "INSERT INTO " + getSchemaName() + "." + TABLE_NAME + " ( "
                    + FIELDS
                    + " ) VALUES ("
                    + " ?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + " )";

            stmt = con.prepareStatement(sql);
            int i = 1;
            stmt.setString(i++, bo.getMoshikomishaId());
            stmt.setString(i++, bo.getNendo());
            stmt.setString(i++, bo.getSknKsuCode());
            stmt.setString(i++, bo.getShubetsuCode());
            stmt.setString(i++, bo.getKaisuCode());
            stmt.setString(i++, bo.getKiboKaisaichiCode());
            stmt.setString(i++, bo.getKaijoId1());
            stmt.setString(i++, bo.getKaisaichiCode1());
            stmt.setString(i++, bo.getKaijoCode1());
            stmt.setString(i++, bo.getKyoshitsuCode1());
            stmt.setString(i++, bo.getKaijoId2());
            stmt.setString(i++, bo.getKaisaichiCode2());
            stmt.setString(i++, bo.getKaijoCode2());
            stmt.setString(i++, bo.getKyoshitsuCode2());
            stmt.setString(i++, bo.getMoshikomiKbn());
            stmt.setString(i++, bo.getKojinDantaiKbn());
            stmt.setString(i++, bo.getKaiinShinseiFlg());
            stmt.setString(i++, bo.getMoshikomiJokyoKbn());
            stmt.setString(i++, bo.getUnyoJokyoKbn());
            stmt.setString(i++, bo.getGohiJokyoKbn());
            stmt.setString(i++, bo.getShomenUketsukeNo());
            stmt.setString(i++, bo.getUketsukeNo());
            stmt.setString(i++, bo.getJukenJukoNo());
            stmt.setString(i++, bo.getShikenNaiyoKbn());
            stmt.setString(i++, bo.getSofuSakiKbn());
            stmt.setString(i++, bo.getHairyoFlg());
            stmt.setString(i++, bo.getHairyoNaiyo());
            stmt.setString(i++, bo.getGenmenFlg());
            stmt.setString(i++, bo.getNenrei());
            stmt.setString(i++, bo.getKariUketsukeBi());
            stmt.setString(i++, bo.getKariUketsukeTime());
            stmt.setString(i++, bo.getMoshikomiTorokuDate());
            stmt.setString(i++, bo.getMoshikomiTorokuTime());
            stmt.setString(i++, bo.getMoshikomiFinishBi());
            stmt.setString(i++, bo.getMoshikomiFinishTime());
            stmt.setString(i++, bo.getHoseiIraiKbn());
            stmt.setString(i++, bo.getKanriMemo());
            stmt.setString(i++, bo.getKoshinKbn());
            stmt.setString(i++, bo.getTorokuDate());
            stmt.setString(i++, bo.getTorokuTime());
            stmt.setString(i++, bo.getTorokuUserId());
            stmt.setString(i++, bo.getKoshinDate());
            stmt.setString(i++, bo.getKoshinTime());
            stmt.setString(i++, bo.getKoshinUserId());
            stmt.setString(i++, bo.getRonriSakujoFlg());

            LogGenerate.debugOutput(getSql(stmt));
            stmt.executeUpdate();
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt);
        }
    }

    /* (non-Javadoc)
     * @see jp.co.nii.bma.business.domain.GeneratedMoshikomiDao#find(jp.co.nii.bma.business.domain.GeneratedMoshikomi, java.lang.String)
     */
    @Override
    public GeneratedMoshikomi find(GeneratedMoshikomi bo, String lockMode) {
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs =null;
        String sql = "";
        try {
            con = getConnection();
            sql = "SELECT " + FIELDS_DECRYPT
                    + " FROM " + getSchemaName() + "." + TABLE_NAME
                    + " WHERE"
                    + " NENDO = ?"
                    + " AND UKETSUKE_NO = ?";

            stmt = con.prepareStatement(sql + lockMode);
            int i = 1;
            stmt.setString(i++, bo.getNendo());
            stmt.setString(i++, bo.getUketsukeNo());

            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();
            if (rs.next()) {
                setBoFromResultSet(bo, rs);
            } else {
                bo = null;
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return bo;
    }

    /* (non-Javadoc)
     * @see jp.co.nii.bma.business.domain.GeneratedMoshikomiDao#update(jp.co.nii.bma.business.domain.GeneratedMoshikomi)
     */
    @Override
    public void update(GeneratedMoshikomi bo) {
        Connection con = null;
        PreparedStatement stmt = null;
        String sql = "";
        try {
            con = getConnection();
            sql = "UPDATE " + getSchemaName() + "." + TABLE_NAME + " SET"
                    + " MOSHIKOMISHA_ID = ?"
                    + ",SKN_KSU_CODE = ?"
                    + ",SHUBETSU_CODE = ?"
                    + ",KAISU_CODE = ?"
                    + ",KIBO_KAISAICHI_CODE = ?"
                    + ",KAIJO_ID1 = ?"
                    + ",KAISAICHI_CODE1 = ?"
                    + ",KAIJO_CODE1 = ?"
                    + ",KYOSHITSU_CODE1 = ?"
                    + ",KAIJO_ID2 = ?"
                    + ",KAISAICHI_CODE2 = ?"
                    + ",KAIJO_CODE2 = ?"
                    + ",KYOSHITSU_CODE2 = ?"
                    + ",MOSHIKOMI_KBN = ?"
                    + ",KOJIN_DANTAI_KBN = ?"
                    + ",KAIIN_SHINSEI_FLG = ?"
                    + ",MOSHIKOMI_JOKYO_KBN = ?"
                    + ",UNYO_JOKYO_KBN = ?"
                    + ",GOHI_JOKYO_KBN = ?"
                    + ",SHOMEN_UKETSUKE_NO = ?"
                    + ",JUKEN_JUKO_NO = ?"
                    + ",SHIKEN_NAIYO_KBN = ?"
                    + ",SOFU_SAKI_KBN = ?"
                    + ",HAIRYO_FLG = ?"
                    + ",HAIRYO_NAIYO = ?"
                    + ",GENMEN_FLG = ?"
                    + ",NENREI = ?"
                    + ",KARI_UKETSUKE_BI = ?"
                    + ",KARI_UKETSUKE_TIME = ?"
                    + ",MOSHIKOMI_TOROKU_DATE = ?"
                    + ",MOSHIKOMI_TOROKU_TIME = ?"
                    + ",MOSHIKOMI_FINISH_BI = ?"
                    + ",MOSHIKOMI_FINISH_TIME = ?"
                    + ",HOSEI_IRAI_KBN = ?"
                    + ",KANRI_MEMO = ?"
                    + ",KOSHIN_KBN = ?"
                    + ",TOROKU_DATE = ?"
                    + ",TOROKU_TIME = ?"
                    + ",TOROKU_USER_ID = ?"
                    + ",KOSHIN_DATE = ?"
                    + ",KOSHIN_TIME = ?"
                    + ",KOSHIN_USER_ID = ?"
                    + ",RONRI_SAKUJO_FLG = ?"
                    + " WHERE"
                    + " NENDO = ?"
                    + " AND UKETSUKE_NO = ?";

            stmt = con.prepareStatement(sql);
            int i = 1;
            stmt.setString(i++, bo.getMoshikomishaId());
            stmt.setString(i++, bo.getSknKsuCode());
            stmt.setString(i++, bo.getShubetsuCode());
            stmt.setString(i++, bo.getKaisuCode());
            stmt.setString(i++, bo.getKiboKaisaichiCode());
            stmt.setString(i++, bo.getKaijoId1());
            stmt.setString(i++, bo.getKaisaichiCode1());
            stmt.setString(i++, bo.getKaijoCode1());
            stmt.setString(i++, bo.getKyoshitsuCode1());
            stmt.setString(i++, bo.getKaijoId2());
            stmt.setString(i++, bo.getKaisaichiCode2());
            stmt.setString(i++, bo.getKaijoCode2());
            stmt.setString(i++, bo.getKyoshitsuCode2());
            stmt.setString(i++, bo.getMoshikomiKbn());
            stmt.setString(i++, bo.getKojinDantaiKbn());
            stmt.setString(i++, bo.getKaiinShinseiFlg());
            stmt.setString(i++, bo.getMoshikomiJokyoKbn());
            stmt.setString(i++, bo.getUnyoJokyoKbn());
            stmt.setString(i++, bo.getGohiJokyoKbn());
            stmt.setString(i++, bo.getShomenUketsukeNo());
            stmt.setString(i++, bo.getJukenJukoNo());
            stmt.setString(i++, bo.getShikenNaiyoKbn());
            stmt.setString(i++, bo.getSofuSakiKbn());
            stmt.setString(i++, bo.getHairyoFlg());
            stmt.setString(i++, bo.getHairyoNaiyo());
            stmt.setString(i++, bo.getGenmenFlg());
            stmt.setString(i++, bo.getNenrei());
            stmt.setString(i++, bo.getKariUketsukeBi());
            stmt.setString(i++, bo.getKariUketsukeTime());
            stmt.setString(i++, bo.getMoshikomiTorokuDate());
            stmt.setString(i++, bo.getMoshikomiTorokuTime());
            stmt.setString(i++, bo.getMoshikomiFinishBi());
            stmt.setString(i++, bo.getMoshikomiFinishTime());
            stmt.setString(i++, bo.getHoseiIraiKbn());
            stmt.setString(i++, bo.getKanriMemo());
            stmt.setString(i++, bo.getKoshinKbn());
            stmt.setString(i++, bo.getTorokuDate());
            stmt.setString(i++, bo.getTorokuTime());
            stmt.setString(i++, bo.getTorokuUserId());
            stmt.setString(i++, bo.getKoshinDate());
            stmt.setString(i++, bo.getKoshinTime());
            stmt.setString(i++, bo.getKoshinUserId());
            stmt.setString(i++, bo.getRonriSakujoFlg());

            stmt.setString(i++, bo.getNendo());
            stmt.setString(i++, bo.getUketsukeNo());

            LogGenerate.debugOutput(getSql(stmt));
            if (stmt.executeUpdate() == 0) {
                throw new NoSuchDataException(getSql(stmt));
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt);
        }
    }

    /* (non-Javadoc)
     * @see jp.co.nii.bma.business.domain.GeneratedMoshikomiDao#remove(jp.co.nii.bma.business.domain.GeneratedMoshikomi)
     */
    @Override
    public void remove(GeneratedMoshikomi bo) {
        Connection con = null;
        PreparedStatement stmt = null;
        String sql = "";
        try {
            con = getConnection();
            sql = "DELETE FROM " + getSchemaName() + "." + TABLE_NAME
                    + " WHERE"
                    + " NENDO = ?"
                    + " AND UKETSUKE_NO = ?";

            stmt = con.prepareStatement(sql);
            int i = 1;
            stmt.setString(i++, bo.getNendo());
            stmt.setString(i++, bo.getUketsukeNo());

            LogGenerate.debugOutput(getSql(stmt));
            if (stmt.executeUpdate() == 0) {
                throw new NoSuchDataException(getSql(stmt));
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt);
        }
    }

    /**
     * �������ʂł���ResultSet��BusinessObject�֋l�ߑւ���B<br>
     * ���O�����F������bo��rs��null�łȂ����ƁB
     * 
     * @param bo BusinessObject�̃C���X�^���X
     * @param rs �������ʂ�ResultSet
     */
    protected void setBoFromResultSet(GeneratedMoshikomi bo, ResultSet rs) {
        try {
            bo.setMoshikomishaId(rs.getString("MOSHIKOMISHA_ID"));
            bo.setNendo(rs.getString("NENDO"));
            bo.setSknKsuCode(rs.getString("SKN_KSU_CODE"));
            bo.setShubetsuCode(rs.getString("SHUBETSU_CODE"));
            bo.setKaisuCode(rs.getString("KAISU_CODE"));
            bo.setKiboKaisaichiCode(rs.getString("KIBO_KAISAICHI_CODE"));
            bo.setKaijoId1(rs.getString("KAIJO_ID1"));
            bo.setKaisaichiCode1(rs.getString("KAISAICHI_CODE1"));
            bo.setKaijoCode1(rs.getString("KAIJO_CODE1"));
            bo.setKyoshitsuCode1(rs.getString("KYOSHITSU_CODE1"));
            bo.setKaijoId2(rs.getString("KAIJO_ID2"));
            bo.setKaisaichiCode2(rs.getString("KAISAICHI_CODE2"));
            bo.setKaijoCode2(rs.getString("KAIJO_CODE2"));
            bo.setKyoshitsuCode2(rs.getString("KYOSHITSU_CODE2"));
            bo.setMoshikomiKbn(rs.getString("MOSHIKOMI_KBN"));
            bo.setKojinDantaiKbn(rs.getString("KOJIN_DANTAI_KBN"));
            bo.setKaiinShinseiFlg(rs.getString("KAIIN_SHINSEI_FLG"));
            bo.setMoshikomiJokyoKbn(rs.getString("MOSHIKOMI_JOKYO_KBN"));
            bo.setUnyoJokyoKbn(rs.getString("UNYO_JOKYO_KBN"));
            bo.setGohiJokyoKbn(rs.getString("GOHI_JOKYO_KBN"));
            bo.setShomenUketsukeNo(rs.getString("SHOMEN_UKETSUKE_NO"));
            bo.setUketsukeNo(rs.getString("UKETSUKE_NO"));
            bo.setJukenJukoNo(rs.getString("JUKEN_JUKO_NO"));
            bo.setShikenNaiyoKbn(rs.getString("SHIKEN_NAIYO_KBN"));
            bo.setSofuSakiKbn(rs.getString("SOFU_SAKI_KBN"));
            bo.setHairyoFlg(rs.getString("HAIRYO_FLG"));
            bo.setHairyoNaiyo(rs.getString("HAIRYO_NAIYO"));
            bo.setGenmenFlg(rs.getString("GENMEN_FLG"));
            bo.setNenrei(rs.getString("NENREI"));
            bo.setKariUketsukeBi(rs.getString("KARI_UKETSUKE_BI"));
            bo.setKariUketsukeTime(rs.getString("KARI_UKETSUKE_TIME"));
            bo.setMoshikomiTorokuDate(rs.getString("MOSHIKOMI_TOROKU_DATE"));
            bo.setMoshikomiTorokuTime(rs.getString("MOSHIKOMI_TOROKU_TIME"));
            bo.setMoshikomiFinishBi(rs.getString("MOSHIKOMI_FINISH_BI"));
            bo.setMoshikomiFinishTime(rs.getString("MOSHIKOMI_FINISH_TIME"));
            bo.setHoseiIraiKbn(rs.getString("HOSEI_IRAI_KBN"));
            bo.setKanriMemo(rs.getString("KANRI_MEMO"));
            bo.setKoshinKbn(rs.getString("KOSHIN_KBN"));
            bo.setTorokuDate(rs.getString("TOROKU_DATE"));
            bo.setTorokuTime(rs.getString("TOROKU_TIME"));
            bo.setTorokuUserId(rs.getString("TOROKU_USER_ID"));
            bo.setKoshinDate(rs.getString("KOSHIN_DATE"));
            bo.setKoshinTime(rs.getString("KOSHIN_TIME"));
            bo.setKoshinUserId(rs.getString("KOSHIN_USER_ID"));
            bo.setRonriSakujoFlg(rs.getString("RONRI_SAKUJO_FLG"));
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(null, ex);
        }
    }
}
