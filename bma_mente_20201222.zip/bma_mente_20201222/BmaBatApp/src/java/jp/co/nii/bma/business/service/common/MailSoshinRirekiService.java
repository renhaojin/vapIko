/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.nii.bma.business.service.common;

import java.lang.reflect.Field;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import jp.co.nii.bma.business.domain.MailSoshinRireki;
import jp.co.nii.bma.business.domain.MailTemplate;
import jp.co.nii.bma.business.domain.Saiban;
import jp.co.nii.bma.business.service.SaibanService;

/**
 *
 * @author nii19049
 */
public class MailSoshinRirekiService {
    
    /**
     * DB�ڑ��̃f�[�^�\�[�X
     */
    private static String DATA_SOURCE_NAME;
    
    public void mailSoshinTrk(MailSoshinRireki bo, Boolean mailSoshinResult, MailTemplate mailTemplate, List<String> paramList) throws Exception {
        Date date = new Date();
        BmaMailSendService mailSendService = new BmaMailSendService();
        SimpleDateFormat dt = new SimpleDateFormat("yyyyMMdd");
        SimpleDateFormat tm = new SimpleDateFormat("HHmmss");
        String koshinDate = dt.format(date);
        String koshinTime = tm.format(date);
        Saiban saiban = new SaibanService(DATA_SOURCE_NAME).getSaibanAndUpdate(BmaConstants.SAIBAN_SENDMAILRIREKI_IDX, BmaConstants.BATCH_USER);
        bo.setMailSoshinRirekiIdx(saiban.getGenzaiNo());
        mailSendService.formatReplaceList(paramList);
        bo.setMailKenmei(mailSendService.createMailKenmei(mailTemplate, paramList));
        bo.setMailHonbun(mailSendService.createMailHonbun(mailTemplate, paramList));
        bo.setMailFooter(mailSendService.createMailFooter(mailTemplate, paramList));
        bo.setMailSoshinKensu("1");
        if (mailSoshinResult) {
            bo.setMailSoshinJokyoKbn("1");
        } else {
            bo.setMailSoshinJokyoKbn("2");
        }
        setMailParameter(bo, paramList);
        bo.setKoshinKbn("I");
        bo.setTorokuDate(koshinDate);
        bo.setTorokuTime(koshinTime);
        bo.setTorokuUserId(BmaConstants.BATCH_USER);
        bo.setKoshinDate("");
        bo.setKoshinTime("");
        bo.setKoshinUserId("");
        bo.setRonriSakujoFlg("0");
    }

    /**
     * ���[���p�����[�^�ݒ�
     * 
     * @param insMailSoshinRireki
     * @param mailParamList
     */
    private void setMailParameter(MailSoshinRireki insMailSoshinRireki, List<String> mailParamList) throws IllegalArgumentException, NoSuchFieldException, SecurityException, IllegalAccessException {
        for (int i = 0; i < mailParamList.size(); i++) {
            // ���[���p�����[�^�ݒ�
            Field field = insMailSoshinRireki.getClass().getSuperclass().getDeclaredField("mailParam" + String.format("%02d", i + 1));
            // private�ϐ��ւ̃A�N�Z�X����������
            field.setAccessible(true);
            // private�ϐ��ɒl��ݒ�
            field.set(insMailSoshinRireki, mailParamList.get(i) == null ? "" : mailParamList.get(i));
        }
    }
}
