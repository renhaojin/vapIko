package jp.co.nii.bma.business.service.common;


public class KessaiTokusokuException extends Exception
{

    public KessaiTokusokuException()
    {
    }

    public KessaiTokusokuException(String message)
    {
        super(message);
    }

    public KessaiTokusokuException(String message, Throwable cause)
    {
        super(message, cause);
    }

    public KessaiTokusokuException(Throwable cause)
    {
        super(cause);
    }

    public String getMessages()
    {
        StringBuilder buffer = new StringBuilder(256);
        String LN = System.getProperty("line.separator");
        for(Throwable t = this; null != t; t = t.getCause())
        {
            String msg = t.getMessage();
            if(null != msg)
                buffer.append(msg).append(LN);
        }

        return buffer.toString();
    }
}
