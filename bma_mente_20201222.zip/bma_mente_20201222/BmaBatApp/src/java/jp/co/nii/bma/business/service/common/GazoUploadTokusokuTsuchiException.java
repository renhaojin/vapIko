package jp.co.nii.bma.business.service.common;

/**
 *
 * @author nii19049
 */
public class GazoUploadTokusokuTsuchiException extends Exception {
    public GazoUploadTokusokuTsuchiException()
    {
    }

    public GazoUploadTokusokuTsuchiException(String message)
    {
        super(message);
    }

    public GazoUploadTokusokuTsuchiException(String message, Throwable cause)
    {
        super(message, cause);
    }

    public GazoUploadTokusokuTsuchiException(Throwable cause)
    {
        super(cause);
    }

    public String getMessages()
    {
        StringBuilder buffer = new StringBuilder(256);
        String LN = System.getProperty("line.separator");
        for(Throwable t = this; null != t; t = t.getCause())
        {
            String msg = t.getMessage();
            if(null != msg)
                buffer.append(msg).append(LN);
        }

        return buffer.toString();
    }
}
