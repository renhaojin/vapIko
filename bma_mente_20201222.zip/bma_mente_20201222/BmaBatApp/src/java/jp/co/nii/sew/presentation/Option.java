package jp.co.nii.sew.presentation;

import java.io.Serializable;

/**
 *
 * @author n-machida
 */
public class Option implements Serializable {

    private String value;
    private String label;

    public Option(String value, String label) {
        this.value = value;
        this.label = label;
    }

    /**
     * @return the value
     */
    public String getValue() {
        return value;
    }

    /**
     * @return the label
     */
    public String getLabel() {
        return label;
    }
}
