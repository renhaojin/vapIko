package jp.co.nii.bma.business.rto;

/**
 * �^�C�g��: �摜�s�����ʒm�i�l�j ���쌠: Copyright (c) 2020 ��Ж�: ���{���Y�Ɗ������
 */
public class GazoFubiTokusokuTsuchiJoho {
    private String sknKsuName;
    private String gazoKbn;
    private String shimei;
    private String uketsukeNo;
    private String hoseiIraiCode1;
    private String hoseiIraiCode2;
    private String hoseiIraiCode3;
    private String hoseiKigenBi;
    private String mailAddress;
    private String gazoIdx;
    private String moshikomishaId;

    /**
     * @return the sknKsuName
     */
    public String getSknKsuName() {
        return sknKsuName;
    }

    /**
     * @param sknKsuName the sknKsuName to set
     */
    public void setSknKsuName(String sknKsuName) {
        this.sknKsuName = sknKsuName;
    }

    /**
     * @return the gazoKbn
     */
    public String getGazoKbn() {
        return gazoKbn;
    }

    /**
     * @param gazoKbn the gazoKbn to set
     */
    public void setGazoKbn(String gazoKbn) {
        this.gazoKbn = gazoKbn;
    }

    /**
     * �R���X�g���N�^
     */
    public GazoFubiTokusokuTsuchiJoho() {
        clearInfo();
    }

    /**
     * @return the mailAddress
     */
    public String getMailAddress() {
        return mailAddress;
    }

    /**
     * @param mailAddress the mailAddress to set
     */
    public void setMailAddress(String mailAddress) {
        this.mailAddress = mailAddress;
    }

    /**
     * @return the gazoIdx
     */
    public String getGazoIdx() {
        return gazoIdx;
    }

    /**
     * @param gazoIdx the gazoIdx to set
     */
    public void setGazoIdx(String gazoIdx) {
        this.gazoIdx = gazoIdx;
    }

    /**
     * @return the shimei
     */
    public String getShimei() {
        return shimei;
    }

    /**
     * @param shimei the shimei to set
     */
    public void setShimei(String shimei) {
        this.shimei = shimei;
    }

    /**
     * @return the uketsukeNo
     */
    public String getUketsukeNo() {
        return uketsukeNo;
    }

    /**
     * @param uketsukeNo the uketsukeNo to set
     */
    public void setUketsukeNo(String uketsukeNo) {
        this.uketsukeNo = uketsukeNo;
    }

    /**
     * @return the hoseiIraiCode1
     */
    public String getHoseiIraiCode1() {
        return hoseiIraiCode1;
    }

    /**
     * @param hoseiIraiCode1 the hoseiIraiCode1 to set
     */
    public void setHoseiIraiCode1(String hoseiIraiCode1) {
        this.hoseiIraiCode1 = hoseiIraiCode1;
    }

    /**
     * @return the hoseiIraiCode2
     */
    public String getHoseiIraiCode2() {
        return hoseiIraiCode2;
    }

    /**
     * @param hoseiIraiCode2 the hoseiIraiCode2 to set
     */
    public void setHoseiIraiCode2(String hoseiIraiCode2) {
        this.hoseiIraiCode2 = hoseiIraiCode2;
    }

    /**
     * @return the hoseiIraiCode3
     */
    public String getHoseiIraiCode3() {
        return hoseiIraiCode3;
    }

    /**
     * @param hoseiIraiCode3 the hoseiIraiCode3 to set
     */
    public void setHoseiIraiCode3(String hoseiIraiCode3) {
        this.hoseiIraiCode3 = hoseiIraiCode3;
    }

    /**
     * @return the hoseiKigenBi
     */
    public String getHoseiKigenBi() {
        return hoseiKigenBi;
    }

    /**
     * @param hoseiKigenBi the hoseiKigenBi to set
     */
    public void setHoseiKigenBi(String hoseiKigenBi) {
        this.hoseiKigenBi = hoseiKigenBi;
    }

    /**
     * @return the moshikomishaId
     */
    public String getMoshikomishaId() {
        return moshikomishaId;
    }

    /**
     * @param moshikomishaId the moshikomishaId to set
     */
    public void setMoshikomishaId(String moshikomishaId) {
        this.moshikomishaId = moshikomishaId;
    }
 
    /**
     * ���������\�b�h
     */
    private void clearInfo() {
        setSknKsuName("");
        setGazoKbn("");
        setShimei("");
        setUketsukeNo("");
        setHoseiIraiCode1("");
        setHoseiIraiCode2("");
        setHoseiIraiCode3("");
        setHoseiKigenBi("");
        setMailAddress("");
        setGazoIdx("");
        setMoshikomishaId("");
    }
}
