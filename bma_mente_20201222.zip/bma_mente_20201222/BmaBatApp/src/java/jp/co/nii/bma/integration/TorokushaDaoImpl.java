package jp.co.nii.bma.integration;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import jp.co.nii.bma.business.domain.GeneratedTorokusha;
import static jp.co.nii.bma.business.domain.GeneratedTorokushaDao.TABLE_NAME;
import jp.co.nii.bma.business.domain.Torokusha;
import jp.co.nii.bma.business.domain.TorokushaDao;
import jp.co.nii.sew.business.domain.NoSuchDataException;
import jp.co.nii.sew.common.LogGenerate;
import static jp.co.nii.sew.integration.AbstractDao.getSchemaName;
import jp.co.nii.sew.integration.SQLStateSQLExceptionTranslater;

/**
 * �o�^�� DAO�����N���X
 * @author DB�Ǘ��c�[��
 */
public class TorokushaDaoImpl extends GeneratedTorokushaDaoImpl implements TorokushaDao {

    /**
     * �C���X�^���X�𐶐�����B
     * @param datasource �f�[�^�\�[�X��
     */
    public TorokushaDaoImpl(String datasource) {
        super(datasource);
    }
    
    /**
     * 1���X�V���s���B���[�J���g�����U�N�V�����p
     * 
     * @param bo �X�V���e���l�߂�BusinessObject
     * @return Connection
     */
    @Override
    public Connection update(Torokusha bo) {
        Connection con = null;
        PreparedStatement stmt = null;
        String sql = "";
        try {
            con = getConnection();
            sql = "UPDATE " + getSchemaName() + "." + TABLE_NAME + " SET"
                    + " KAIIN_ID = ?"
                    + ",KAIIN_KBN = " + getSQLForEncryptByUTF8("?")
                    + ",LOGIN_KBN = " + getSQLForEncryptByUTF8("?")
                    + ",KENGEN_KBN = " + getSQLForEncryptByUTF8("?")
                    + ",SHIMEI = " + getSQLForEncryptByUTF8("?")
                    + ",FURIGANA = " + getSQLForEncryptByUTF8("?")
                    + ",BIRTHDAY = " + getSQLForEncryptByUTF8("?")
                    + ",SEX = " + getSQLForEncryptByUTF8("?")
                    + ",YUBIN_NO = " + getSQLForEncryptByUTF8("?")
                    + ",TODOFUKEN_CODE = " + getSQLForEncryptByUTF8("?")
                    + ",JUSHO_1 = " + getSQLForEncryptByUTF8("?")
                    + ",JUSHO_2 = " + getSQLForEncryptByUTF8("?")
                    + ",TATEMONO = " + getSQLForEncryptByUTF8("?")
                    + ",TEL_NO = " + getSQLForEncryptByUTF8("?")
                    + ",FAX_NO = " + getSQLForEncryptByUTF8("?")
                    + ",MAIL_ADDRESS = " + getSQLForEncryptByUTF8("?")
                    + ",KUNI_ID = " + getSQLForEncryptByUTF8("?")
                    + ",KUNIMEI_JPN = " + getSQLForEncryptByUTF8("?")
                    + ",KUNIMEI_ENG = " + getSQLForEncryptByUTF8("?")
                    + ",ZAIRYU_CARD_NO = " + getSQLForEncryptByUTF8("?")
                    + ",KINMUSAKI_NAME = " + getSQLForEncryptByUTF8("?")
                    + ",KINMUSAKI_YUBIN_NO = " + getSQLForEncryptByUTF8("?")
                    + ",KINMUSAKI_TODOFUKEN_CODE = " + getSQLForEncryptByUTF8("?")
                    + ",KINMUSAKI_JUSHO_1 = " + getSQLForEncryptByUTF8("?")
                    + ",KINMUSAKI_JUSHO_2 = " + getSQLForEncryptByUTF8("?")
                    + ",KINMUSAKI_TATEMONO = " + getSQLForEncryptByUTF8("?")
                    + ",KINMUSAKI_TEL_NO = " + getSQLForEncryptByUTF8("?")
                    + ",KINMUSAKI_FAX_NO = " + getSQLForEncryptByUTF8("?")
                    + ",KIGYO_CODE = " + getSQLForEncryptByUTF8("?")
                    + ",KIGYO_HP_URL = " + getSQLForEncryptByUTF8("?")
                    + ",KYOKAI_NAME = " + getSQLForEncryptByUTF8("?")
                    + ",GAIJI_FLG = ?"
                    + ",GAIJI_SHOSAI = ?"
                    + ",KEKKAKU_FLG = ?"
                    + ",BIKO = ?"
                    + ",KOSHIN_KBN = ?"
                    + ",TOROKU_DATE = ?"
                    + ",TOROKU_TIME = ?"
                    + ",TOROKU_USER_ID = ?"
                    + ",KOSHIN_DATE = ?"
                    + ",KOSHIN_TIME = ?"
                    + ",KOSHIN_USER_ID = ?"
                    + ",RONRI_SAKUJO_FLG = ?"
                    + " WHERE"
                    + " MOSHIKOMISHA_ID = ?";

            stmt = con.prepareStatement(sql);
            int i = 1;
            stmt.setString(i++, bo.getKaiinId());
            stmt.setString(i++, bo.getKaiinKbn());
            stmt.setString(i++, bo.getLoginKbn());
            stmt.setString(i++, bo.getKengenKbn());
            stmt.setString(i++, bo.getShimei());
            stmt.setString(i++, bo.getFurigana());
            stmt.setString(i++, bo.getBirthday());
            stmt.setString(i++, bo.getSex());
            stmt.setString(i++, bo.getYubinNo());
            stmt.setString(i++, bo.getTodofukenCode());
            stmt.setString(i++, bo.getJusho1());
            stmt.setString(i++, bo.getJusho2());
            stmt.setString(i++, bo.getTatemono());
            stmt.setString(i++, bo.getTelNo());
            stmt.setString(i++, bo.getFaxNo());
            stmt.setString(i++, bo.getMailAddress());
            stmt.setString(i++, bo.getKuniId());
            stmt.setString(i++, bo.getKunimeiJpn());
            stmt.setString(i++, bo.getKunimeiEng());
            stmt.setString(i++, bo.getZairyuCardNo());
            stmt.setString(i++, bo.getKinmusakiName());
            stmt.setString(i++, bo.getKinmusakiYubinNo());
            stmt.setString(i++, bo.getKinmusakiTodofukenCode());
            stmt.setString(i++, bo.getKinmusakiJusho1());
            stmt.setString(i++, bo.getKinmusakiJusho2());
            stmt.setString(i++, bo.getKinmusakiTatemono());
            stmt.setString(i++, bo.getKinmusakiTelNo());
            stmt.setString(i++, bo.getKinmusakiFaxNo());
            stmt.setString(i++, bo.getKigyoCode());
            stmt.setString(i++, bo.getKigyoHpUrl());
//            stmt.setString(i++, bo.getKyokaiCode());
            stmt.setString(i++, bo.getKyokaiName());
            stmt.setString(i++, bo.getGaijiFlg());
            stmt.setString(i++, bo.getGaijiShosai());
            stmt.setString(i++, bo.getKekkakuFlg());
            stmt.setString(i++, bo.getBiko());
            stmt.setString(i++, bo.getKoshinKbn());
            stmt.setString(i++, bo.getTorokuDate());
            stmt.setString(i++, bo.getTorokuTime());
            stmt.setString(i++, bo.getTorokuUserId());
            stmt.setString(i++, bo.getKoshinDate());
            stmt.setString(i++, bo.getKoshinTime());
            stmt.setString(i++, bo.getKoshinUserId());
            stmt.setString(i++, bo.getRonriSakujoFlg());

            stmt.setString(i++, bo.getMoshikomishaId());

            LogGenerate.debugOutput(getSql(stmt));
            if (stmt.executeUpdate() == 0) {
                throw new NoSuchDataException(getSql(stmt));
            }
            
        } catch (SQLException ex) {
            try {
                con.close();
            } catch (SQLException ex1) {
                Logger.getLogger(MoshikomiDaoImpl.class.getName()).log(Level.SEVERE, null, ex1);
            }
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            if (stmt != null) {
                try {
                    stmt.close();
                } catch (SQLException e) {
                    LogGenerate.infoOutput("PreparedStatement��Close�ŃG���[�����������B");
                }
            }
        }
        return con;
    }

}
