package jp.co.nii.bma.integration;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import static jp.co.nii.bma.business.domain.GeneratedHoyuShikakuMstDao.TABLE_NAME;
import jp.co.nii.bma.business.domain.HoyuShikakuMstDao;
import jp.co.nii.bma.business.service.common.BmaConstants;
import jp.co.nii.sew.business.SystemTime;
import jp.co.nii.sew.business.domain.NoSuchDataException;
import jp.co.nii.sew.business.service.transaction.TransactionUtility;
import jp.co.nii.sew.common.LogGenerate;
import jp.co.nii.sew.integration.SQLStateSQLExceptionTranslater;
import jp.co.nii.sew.utility.DateUtility;

/**
 * �ۗL���i�}�X�^ DAO�����N���X
 * @author DB�Ǘ��c�[��
 */
public class HoyuShikakuMstDaoImpl extends GeneratedHoyuShikakuMstDaoImpl implements HoyuShikakuMstDao {

    /**
     * �C���X�^���X�𐶐�����B
     * @param datasource �f�[�^�\�[�X��
     */
    public HoyuShikakuMstDaoImpl(String datasource) {
        super(datasource);
    }
    
    /**
     * �L�������؂�Ώێ҂��X�V����B<br>
     * @return �X�V�����L�������؂�ΏێҌ���<br>
     */
    @Override
    public int updateKigenKireTaishosha() {
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs =null;
        String sql = "";
        String currentDate = DateUtility.convertDateToYyyyMMdd(new Date());
        int ret = 0;
        try {
            con = getConnection();
            sql = "SELECT MOSHIKOMISHA_ID"
                    + " FROM " + getSchemaName() + "." + TABLE_NAME
                    + " WHERE"
                    + " YUKO_KIGEN < ?"
                    + " AND RONRI_SAKUJO_FLG = ?";
            
            stmt = con.prepareStatement(sql + TransactionUtility.LOCK_WAIT);
            int i = 1;
            stmt.setString(i++, currentDate);
            stmt.setString(i++, BmaConstants.FLG_OFF);

            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();
            String date = new SystemTime().getymd1();
            String time = new SystemTime().gethms1();
            
            if (rs.next()) {
                sql = "UPDATE " + getSchemaName() + "." + TABLE_NAME + " SET"
                        + " RONRI_SAKUJO_FLG = ?"
                        + ",KOSHIN_KBN = ?"
                        + ",KOSHIN_DATE = ?"
                        + ",KOSHIN_TIME = ?"
                        + ",KOSHIN_USER_ID = ?"
                        + " WHERE"
                        + " YUKO_KIGEN < ?"
                        + " AND RONRI_SAKUJO_FLG = ?";
                stmt = con.prepareStatement(sql);
                i = 1;
                stmt.setString(i++, BmaConstants.FLG_ON);
                stmt.setString(i++, BmaConstants.KOSHIN_KBN_UPDATE);
                stmt.setString(i++, date);
                stmt.setString(i++, time);
                stmt.setString(i++, BmaConstants.BATCH_USER);
                stmt.setString(i++, currentDate);
                stmt.setString(i++, BmaConstants.FLG_OFF);

                LogGenerate.debugOutput(getSql(stmt));
                if ((ret = stmt.executeUpdate()) == 0) {
                    throw new NoSuchDataException(getSql(stmt));
                }
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return ret;
    }
}