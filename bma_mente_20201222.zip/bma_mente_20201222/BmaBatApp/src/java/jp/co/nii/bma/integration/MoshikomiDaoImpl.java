package jp.co.nii.bma.integration;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import jp.co.nii.bma.business.domain.GeneratedMoshikomi;
import static jp.co.nii.bma.business.domain.GeneratedMoshikomiDao.TABLE_NAME;
import jp.co.nii.bma.business.domain.KessaiDao;
import jp.co.nii.bma.business.domain.Moshikomi;
import jp.co.nii.bma.business.domain.MoshikomiDao;
import jp.co.nii.bma.business.domain.Schedule;
import jp.co.nii.bma.business.rto.KaijoReleaseJoho;
import jp.co.nii.bma.business.service.common.BmaConstants;
import static jp.co.nii.bma.integration.GeneratedGazoDaoImpl.FIELDS_DECRYPT;
import static jp.co.nii.bma.integration.GeneratedMoshikomiDaoImpl.FIELDS_DECRYPT;
import jp.co.nii.sew.business.domain.NoSuchDataException;
import jp.co.nii.sew.business.service.transaction.TransactionUtility;
import jp.co.nii.sew.common.LogGenerate;
import static jp.co.nii.sew.integration.AbstractDao.getSchemaName;
import jp.co.nii.sew.integration.SQLStateSQLExceptionTranslater;

/**
 * �\�� DAO�����N���X
 *
 * @author DB�Ǘ��c�[��
 */
public class MoshikomiDaoImpl extends GeneratedMoshikomiDaoImpl implements MoshikomiDao {

    /**
     * �C���X�^���X�𐶐�����B
     *
     * @param datasource �f�[�^�\�[�X��
     */
    public MoshikomiDaoImpl(String datasource) {
        super(datasource);
    }

    /**
     * ��������B �����L�[�Ƃ��ăp�����[�^���w�肷��B�p�����[�^�̃X�P�W���[���� �N�x, �����u�K��R�[�h, ��ʃR�[�h, �񐔃R�[�h�Ō�������B
     *
     * @param aEvent �X�P�W���[��
     *
     * @return ��������Moshikomi��List<br>
     * �Y������f�[�^�����݂��Ȃ��ꍇ��null��List��Ԃ��B
     */
    @Override
    public List<Moshikomi> findBySchedule(Schedule aEvent) {
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = "";
        List<Moshikomi> resultList = new ArrayList();
        try {
            con = getConnection();
            sql = "SELECT "
                    + "DISTINCT MOSHIKOMISHA_ID"
                    + " FROM " + getSchemaName() + "." + TABLE_NAME
                    + " WHERE"
                    + " NENDO = ?"
                    + " AND SKN_KSU_CODE = ?"
                    + " AND SHUBETSU_CODE = ?"
                    + " AND KAISU_CODE = ?"
                    + " ORDER BY MOSHIKOMISHA_ID";

            stmt = con.prepareStatement(sql + TransactionUtility.NO_LOCK);
            int i = 1;
            stmt.setString(i++, aEvent.getNendo());
            stmt.setString(i++, aEvent.getSknKsuCode());
            stmt.setString(i++, aEvent.getShubetsuCode());
            stmt.setString(i++, aEvent.getKaisuCode());

            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();

            while (rs.next()) {
                Moshikomi bo = new Moshikomi();
                setBoFromResultSetKeyOnly(bo, rs);
                resultList.add(bo);
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return resultList;
    }
    
    /**
     * ��������B �����L�[�Ƃ��ăp�����[�^���w�肷��B�p�����[�^�̃X�P�W���[���� �N�x, �����u�K��R�[�h, ��ʃR�[�h, �񐔃R�[�h�Ō�������B
     *
     * @param aEvent �X�P�W���[��
     *
     * @return ��������Moshikomi��List<br>
     * �Y������f�[�^�����݂��Ȃ��ꍇ��null��List��Ԃ��B
     */
    @Override
    public List<Moshikomi> findByScheduleAll(Schedule aEvent) {
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = "";
        List<Moshikomi> resultList = new ArrayList();
        try {
            con = getConnection();
            sql = "SELECT " +  FIELDS_DECRYPT
                    + " FROM " + getSchemaName() + "." + TABLE_NAME
                    + " WHERE "
                    + " NENDO = ?"
                    + " AND SKN_KSU_CODE = ?"
                    + " AND SHUBETSU_CODE = ?"
                    + " AND KAISU_CODE = ?";
 
            stmt = con.prepareStatement(sql + TransactionUtility.LOCK_WAIT);
            int i = 1;
            stmt.setString(i++, aEvent.getNendo());
            stmt.setString(i++, aEvent.getSknKsuCode());
            stmt.setString(i++, aEvent.getShubetsuCode());
            stmt.setString(i++, aEvent.getKaisuCode());

            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();

            while (rs.next()) {
                Moshikomi bo = new Moshikomi();
                setBoFromResultSet(bo, rs);
                resultList.add(bo);
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return resultList;
    }
    
    /**
     * ��ꃊ���[�X�Ώۃ��X�g���擾����B
     *
     * @return ��������Moshikomi��List<br>
     * �Y������f�[�^�����݂��Ȃ��ꍇ��null��List��Ԃ��B
     */
    @Override
    public List<KaijoReleaseJoho> searchKaijoRelease() {
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = "";
        List<KaijoReleaseJoho> resultList = new ArrayList();
        try {
            con = getConnection();
            sql = "SELECT DISTINCT "
                    + " moshikomi.NENDO"
                    + ", moshikomi.UKETSUKE_NO"
                    + ", moshikomi.SKN_KSU_CODE"
                    + ", moshikomi.SHUBETSU_CODE"
                    + ", moshikomi.KAISU_CODE"
                    + ", moshikomi.KAIJO_ID1 AS KAIJO_ID"
                    + ", moshikomi.KAISAICHI_CODE1 AS KAISAICHI_CODE"
                    + ", moshikomi.KAIJO_CODE1 AS KAIJO_CODE"
                    + " FROM " + getSchemaName() + "." + TABLE_NAME + " AS moshikomi"
                    + " INNER JOIN " + getSchemaName() + "." + KessaiDao.TABLE_NAME + " AS kessai"
                    + " ON moshikomi.NENDO = kessai.NENDO"
                    + " AND moshikomi.UKETSUKE_NO = kessai.UKETSUKE_NO"
                    + " AND moshikomi.RONRI_SAKUJO_FLG = ?"
                    + " AND kessai.RONRI_SAKUJO_FLG = ?"
                    + " WHERE "
                    + " to_date(kessai.KESSAI_KIGEN_BI, 'YYYYMMDD') < CURRENT_DATE"
                    + " AND kessai.KESSAI_JOKYO_KBN = ?"
                    + " AND moshikomi.SKN_KSU_CODE IN ('HC', 'IP')";
 
//            stmt = con.prepareStatement(sql + TransactionUtility.LOCK_WAIT);
            stmt = con.prepareStatement(sql);
            int i = 1;
            stmt.setString(i++, BmaConstants.FLG_OFF);
            stmt.setString(i++, BmaConstants.FLG_OFF);
            stmt.setString(i++, BmaConstants.KESSAI_JOKYO_KBN_MI_KESSAI);

            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();

            while (rs.next()) {
                KaijoReleaseJoho bo = new KaijoReleaseJoho();
                bo.setNendo(rs.getString("NENDO"));
                bo.setUketsukeNo(rs.getString("UKETSUKE_NO"));
                bo.setSknKsuCode(rs.getString("SKN_KSU_CODE"));
                bo.setShubetsuCode(rs.getString("SHUBETSU_CODE"));
                bo.setKaisuCode(rs.getString("KAISU_CODE"));
                bo.setKaijoId(rs.getString("KAIJO_ID"));
                bo.setKaisaichiCode(rs.getString("KAISAICHI_CODE"));
                bo.setKaijoCode(rs.getString("KAIJO_CODE"));
                resultList.add(bo);
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return resultList;
    }
    
    /**
     * ���ψُ�Ď��Ώۃ��X�g���擾����B
     *
     * @return ��������Moshikomi��List<br>
     * �Y������f�[�^�����݂��Ȃ��ꍇ��null��List��Ԃ��B
     */
    @Override
    public List<Moshikomi> searchKessaiAbnormal() {
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = "";
        List<Moshikomi> resultList = new ArrayList();
        try {
            con = getConnection();
            sql = "SELECT "
                    + " kessai.UKETSUKE_NO AS UKETSUKE_NO_NULL"
                    + ", moshikomi.MOSHIKOMISHA_ID AS MOSHIKOMISHA_ID"
                    + ", moshikomi.NENDO AS NENDO"
                    + ", moshikomi.UKETSUKE_NO AS UKETSUKE_NO"
                    + " FROM " + getSchemaName() + "." + TABLE_NAME + " AS moshikomi"
                    + " LEFT JOIN " + getSchemaName() + "." + KessaiDao.TABLE_NAME + " AS kessai"
                    + " ON moshikomi.NENDO = kessai.NENDO"
                    + " AND moshikomi.UKETSUKE_NO = kessai.UKETSUKE_NO"
                    + " AND moshikomi.RONRI_SAKUJO_FLG = ?"
                    + " AND kessai.RONRI_SAKUJO_FLG = ?"
                    + " WHERE "
                    + " kessai.UKETSUKE_NO IS NULL";
 
            stmt = con.prepareStatement(sql + TransactionUtility.NO_LOCK);
            int i = 1;
            stmt.setString(i++, BmaConstants.FLG_OFF);
            stmt.setString(i++, BmaConstants.FLG_OFF);

            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();

            while (rs.next()) {
                Moshikomi bo = new Moshikomi();
                bo.setMoshikomishaId(rs.getString("MOSHIKOMISHA_ID"));
                bo.setNendo(rs.getString("NENDO"));
                bo.setUketsukeNo(rs.getString("UKETSUKE_NO"));
                resultList.add(bo);
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return resultList;
    }

    /**
     * 1���X�V���s���B���[�J���g�����U�N�V�����p
     *
     * @param bo �X�V���e���l�߂�BusinessObject
     * @return Connection
     */
    @Override
    public Connection update(Moshikomi bo) {
        Connection con = null;
        PreparedStatement stmt = null;
        String sql = "";
        try {
            con = getConnection();
            sql = "UPDATE " + getSchemaName() + "." + TABLE_NAME + " SET"
                    + " MOSHIKOMISHA_ID = ?"
                    + ",SKN_KSU_CODE = ?"
                    + ",SHUBETSU_CODE = ?"
                    + ",KAISU_CODE = ?"
                    + ",KIBO_KAISAICHI_CODE = ?"
                    + ",KAIJO_ID1 = ?"
                    + ",KAISAICHI_CODE1 = ?"
                    + ",KAIJO_CODE1 = ?"
                    + ",KYOSHITSU_CODE1 = ?"
                    + ",KAIJO_ID2 = ?"
                    + ",KAISAICHI_CODE2 = ?"
                    + ",KAIJO_CODE2 = ?"
                    + ",KYOSHITSU_CODE2 = ?"
                    + ",MOSHIKOMI_KBN = ?"
                    + ",KOJIN_DANTAI_KBN = ?"
                    + ",KAIIN_SHINSEI_FLG = ?"
                    + ",MOSHIKOMI_JOKYO_KBN = ?"
                    + ",UNYO_JOKYO_KBN = ?"
                    + ",GOHI_JOKYO_KBN = ?"
                    + ",SHOMEN_UKETSUKE_NO = ?"
                    + ",JUKEN_JUKO_NO = ?"
                    + ",SHIKEN_NAIYO_KBN = ?"
                    + ",SOFU_SAKI_KBN = ?"
                    + ",HAIRYO_FLG = ?"
                    + ",HAIRYO_NAIYO = ?"
                    + ",GENMEN_FLG = ?"
                    + ",NENREI = ?"
                    + ",KARI_UKETSUKE_BI = ?"
                    + ",KARI_UKETSUKE_TIME = ?"
                    + ",MOSHIKOMI_TOROKU_DATE = ?"
                    + ",MOSHIKOMI_TOROKU_TIME = ?"
                    + ",MOSHIKOMI_FINISH_BI = ?"
                    + ",MOSHIKOMI_FINISH_TIME = ?"
                    + ",HOSEI_IRAI_KBN = ?"
                    + ",KANRI_MEMO = ?"
                    + ",KOSHIN_KBN = ?"
                    + ",TOROKU_DATE = ?"
                    + ",TOROKU_TIME = ?"
                    + ",TOROKU_USER_ID = ?"
                    + ",KOSHIN_DATE = ?"
                    + ",KOSHIN_TIME = ?"
                    + ",KOSHIN_USER_ID = ?"
                    + ",RONRI_SAKUJO_FLG = ?"
                    + " WHERE"
                    + " NENDO = ?"
                    + " AND UKETSUKE_NO = ?";

            stmt = con.prepareStatement(sql);
            int i = 1;
            stmt.setString(i++, bo.getMoshikomishaId());
            stmt.setString(i++, bo.getSknKsuCode());
            stmt.setString(i++, bo.getShubetsuCode());
            stmt.setString(i++, bo.getKaisuCode());
            stmt.setString(i++, bo.getKiboKaisaichiCode());
            stmt.setString(i++, bo.getKaijoId1());
            stmt.setString(i++, bo.getKaisaichiCode1());
            stmt.setString(i++, bo.getKaijoCode1());
            stmt.setString(i++, bo.getKyoshitsuCode1());
            stmt.setString(i++, bo.getKaijoId2());
            stmt.setString(i++, bo.getKaisaichiCode2());
            stmt.setString(i++, bo.getKaijoCode2());
            stmt.setString(i++, bo.getKyoshitsuCode2());
            stmt.setString(i++, bo.getMoshikomiKbn());
            stmt.setString(i++, bo.getKojinDantaiKbn());
            stmt.setString(i++, bo.getKaiinShinseiFlg());
            stmt.setString(i++, bo.getMoshikomiJokyoKbn());
            stmt.setString(i++, bo.getUnyoJokyoKbn());
            stmt.setString(i++, bo.getGohiJokyoKbn());
            stmt.setString(i++, bo.getShomenUketsukeNo());
            stmt.setString(i++, bo.getJukenJukoNo());
            stmt.setString(i++, bo.getShikenNaiyoKbn());
            stmt.setString(i++, bo.getSofuSakiKbn());
            stmt.setString(i++, bo.getHairyoFlg());
            stmt.setString(i++, bo.getHairyoNaiyo());
            stmt.setString(i++, bo.getGenmenFlg());
            stmt.setString(i++, bo.getNenrei());
            stmt.setString(i++, bo.getKariUketsukeBi());
            stmt.setString(i++, bo.getKariUketsukeTime());
            stmt.setString(i++, bo.getMoshikomiTorokuDate());
            stmt.setString(i++, bo.getMoshikomiTorokuTime());
            stmt.setString(i++, bo.getMoshikomiFinishBi());
            stmt.setString(i++, bo.getMoshikomiFinishTime());
            stmt.setString(i++, bo.getHoseiIraiKbn());
            stmt.setString(i++, bo.getKanriMemo());
            stmt.setString(i++, bo.getKoshinKbn());
            stmt.setString(i++, bo.getTorokuDate());
            stmt.setString(i++, bo.getTorokuTime());
            stmt.setString(i++, bo.getTorokuUserId());
            stmt.setString(i++, bo.getKoshinDate());
            stmt.setString(i++, bo.getKoshinTime());
            stmt.setString(i++, bo.getKoshinUserId());
            stmt.setString(i++, bo.getRonriSakujoFlg());

            stmt.setString(i++, bo.getNendo());
            stmt.setString(i++, bo.getUketsukeNo());

            LogGenerate.debugOutput(getSql(stmt));
            if (stmt.executeUpdate() == 0) {
                throw new NoSuchDataException(getSql(stmt));
            }

        } catch (SQLException ex) {
            Logger.getLogger(MoshikomiDaoImpl.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            close(con, stmt);
        }
        return con;
    }

    /**
     * �������ʂł���ResultSet��BusinessObject�֋l�ߑւ���B<br>
     * ���O�����F������bo��rs��null�łȂ����ƁB
     * 
     * @param bo BusinessObject�̃C���X�^���X
     * @param rs �������ʂ�ResultSet
     */
    protected void setBoFromResultSetKeyOnly(GeneratedMoshikomi bo, ResultSet rs) {
        try {
            bo.setMoshikomishaId(rs.getString("MOSHIKOMISHA_ID"));
//            bo.setNendo(rs.getString("NENDO"));
//            bo.setSknKsuCode(rs.getString("SKN_KSU_CODE"));
//            bo.setShubetsuCode(rs.getString("SHUBETSU_CODE"));
//            bo.setKaisuCode(rs.getString("KAISU_CODE"));
//            bo.setKiboKaisaichiCode(rs.getString("KIBO_KAISAICHI_CODE"));
//            bo.setKaijoId1(rs.getString("KAIJO_ID1"));
//            bo.setKaisaichiCode1(rs.getString("KAISAICHI_CODE1"));
//            bo.setKaijoCode1(rs.getString("KAIJO_CODE1"));
//            bo.setKyoshitsuCode1(rs.getString("KYOSHITSU_CODE1"));
//            bo.setKaijoId2(rs.getString("KAIJO_ID2"));
//            bo.setKaisaichiCode2(rs.getString("KAISAICHI_CODE2"));
//            bo.setKaijoCode2(rs.getString("KAIJO_CODE2"));
//            bo.setKyoshitsuCode2(rs.getString("KYOSHITSU_CODE2"));
//            bo.setMoshikomiKbn(rs.getString("MOSHIKOMI_KBN"));
//            bo.setKojinDantaiKbn(rs.getString("KOJIN_DANTAI_KBN"));
//            bo.setKaiinShinseiFlg(rs.getString("KAIIN_SHINSEI_FLG"));
//            bo.setMoshikomiJokyoKbn(rs.getString("MOSHIKOMI_JOKYO_KBN"));
//            bo.setUnyoJokyoKbn(rs.getString("UNYO_JOKYO_KBN"));
//            bo.setGohiJokyoKbn(rs.getString("GOHI_JOKYO_KBN"));
//            bo.setShomenUketsukeNo(rs.getString("SHOMEN_UKETSUKE_NO"));
//            bo.setUketsukeNo(rs.getString("UKETSUKE_NO"));
//            bo.setJukenJukoNo(rs.getString("JUKEN_JUKO_NO"));
//            bo.setShikenNaiyoKbn(rs.getString("SHIKEN_NAIYO_KBN"));
//            bo.setSofuSakiKbn(rs.getString("SOFU_SAKI_KBN"));
//            bo.setHairyoFlg(rs.getString("HAIRYO_FLG"));
//            bo.setHairyoNaiyo(rs.getString("HAIRYO_NAIYO"));
//            bo.setGenmenFlg(rs.getString("GENMEN_FLG"));
//            bo.setNenrei(rs.getString("NENREI"));
//            bo.setKariUketsukeBi(rs.getString("KARI_UKETSUKE_BI"));
//            bo.setKariUketsukeTime(rs.getString("KARI_UKETSUKE_TIME"));
//            bo.setMoshikomiTorokuDate(rs.getString("MOSHIKOMI_TOROKU_DATE"));
//            bo.setMoshikomiTorokuTime(rs.getString("MOSHIKOMI_TOROKU_TIME"));
//            bo.setMoshikomiFinishBi(rs.getString("MOSHIKOMI_FINISH_BI"));
//            bo.setMoshikomiFinishTime(rs.getString("MOSHIKOMI_FINISH_TIME"));
//            bo.setHoseiIraiKbn(rs.getString("HOSEI_IRAI_KBN"));
//            bo.setKanriMemo(rs.getString("KANRI_MEMO"));
//            bo.setKoshinKbn(rs.getString("KOSHIN_KBN"));
//            bo.setTorokuDate(rs.getString("TOROKU_DATE"));
//            bo.setTorokuTime(rs.getString("TOROKU_TIME"));
//            bo.setTorokuUserId(rs.getString("TOROKU_USER_ID"));
//            bo.setKoshinDate(rs.getString("KOSHIN_DATE"));
//            bo.setKoshinTime(rs.getString("KOSHIN_TIME"));
//            bo.setKoshinUserId(rs.getString("KOSHIN_USER_ID"));
//            bo.setRonriSakujoFlg(rs.getString("RONRI_SAKUJO_FLG"));
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(null, ex);
        }
    }
    
    /**
     * �������ʂł���ResultSet��BusinessObject�֋l�ߑւ���B<br>
     * ���O�����F������bo��rs��null�łȂ����ƁB
     *
     * @param bo BusinessObject�̃C���X�^���X
     * @param rs �������ʂ�ResultSet
     */
    protected void setBoFromResultSet(GeneratedMoshikomi bo, ResultSet rs) {
        try {
            bo.setMoshikomishaId(rs.getString("MOSHIKOMISHA_ID"));
            bo.setNendo(rs.getString("NENDO"));
            bo.setSknKsuCode(rs.getString("SKN_KSU_CODE"));
            bo.setShubetsuCode(rs.getString("SHUBETSU_CODE"));
            bo.setKaisuCode(rs.getString("KAISU_CODE"));
            bo.setKiboKaisaichiCode(rs.getString("KIBO_KAISAICHI_CODE"));
            bo.setKaijoId1(rs.getString("KAIJO_ID1"));
            bo.setKaisaichiCode1(rs.getString("KAISAICHI_CODE1"));
            bo.setKaijoCode1(rs.getString("KAIJO_CODE1"));
            bo.setKyoshitsuCode1(rs.getString("KYOSHITSU_CODE1"));
            bo.setKaijoId2(rs.getString("KAIJO_ID2"));
            bo.setKaisaichiCode2(rs.getString("KAISAICHI_CODE2"));
            bo.setKaijoCode2(rs.getString("KAIJO_CODE2"));
            bo.setKyoshitsuCode2(rs.getString("KYOSHITSU_CODE2"));
            bo.setMoshikomiKbn(rs.getString("MOSHIKOMI_KBN"));
            bo.setKojinDantaiKbn(rs.getString("KOJIN_DANTAI_KBN"));
            bo.setKaiinShinseiFlg(rs.getString("KAIIN_SHINSEI_FLG"));
            bo.setMoshikomiJokyoKbn(rs.getString("MOSHIKOMI_JOKYO_KBN"));
            bo.setUnyoJokyoKbn(rs.getString("UNYO_JOKYO_KBN"));
            bo.setGohiJokyoKbn(rs.getString("GOHI_JOKYO_KBN"));
            bo.setShomenUketsukeNo(rs.getString("SHOMEN_UKETSUKE_NO"));
            bo.setUketsukeNo(rs.getString("UKETSUKE_NO"));
            bo.setJukenJukoNo(rs.getString("JUKEN_JUKO_NO"));
            bo.setShikenNaiyoKbn(rs.getString("SHIKEN_NAIYO_KBN"));
            bo.setSofuSakiKbn(rs.getString("SOFU_SAKI_KBN"));
            bo.setHairyoFlg(rs.getString("HAIRYO_FLG"));
            bo.setHairyoNaiyo(rs.getString("HAIRYO_NAIYO"));
            bo.setGenmenFlg(rs.getString("GENMEN_FLG"));
            bo.setNenrei(rs.getString("NENREI"));
            bo.setKariUketsukeBi(rs.getString("KARI_UKETSUKE_BI"));
            bo.setKariUketsukeTime(rs.getString("KARI_UKETSUKE_TIME"));
            bo.setMoshikomiTorokuDate(rs.getString("MOSHIKOMI_TOROKU_DATE"));
            bo.setMoshikomiTorokuTime(rs.getString("MOSHIKOMI_TOROKU_TIME"));
            bo.setMoshikomiFinishBi(rs.getString("MOSHIKOMI_FINISH_BI"));
            bo.setMoshikomiFinishTime(rs.getString("MOSHIKOMI_FINISH_TIME"));
            bo.setHoseiIraiKbn(rs.getString("HOSEI_IRAI_KBN"));
            bo.setKanriMemo(rs.getString("KANRI_MEMO"));
            bo.setKoshinKbn(rs.getString("KOSHIN_KBN"));
            bo.setTorokuDate(rs.getString("TOROKU_DATE"));
            bo.setTorokuTime(rs.getString("TOROKU_TIME"));
            bo.setTorokuUserId(rs.getString("TOROKU_USER_ID"));
            bo.setKoshinDate(rs.getString("KOSHIN_DATE"));
            bo.setKoshinTime(rs.getString("KOSHIN_TIME"));
            bo.setKoshinUserId(rs.getString("KOSHIN_USER_ID"));
            bo.setRonriSakujoFlg(rs.getString("RONRI_SAKUJO_FLG"));
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(null, ex);
        }
    }
}
