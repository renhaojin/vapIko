package jp.co.nii.bma.presentation.common;


/**
 * ����<br>
 *
 * @author NII
 */
public class BmaText {

}
