package jp.co.nii.sew.integration;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import jp.co.nii.sew.business.domain.ViewConfig;
import jp.co.nii.sew.business.domain.ViewConfigDao;
import jp.co.nii.sew.common.LogGenerate;

/**
 * �r���[�ݒ� DAO�����N���X
 * @author DB�Ǘ��c�[��
 */
public class ViewConfigDaoImpl extends GeneratedViewConfigDaoImpl implements ViewConfigDao {

    /**
     * �C���X�^���X�𐶐�����B
     * @param datasource �f�[�^�\�[�X��
     */
    public ViewConfigDaoImpl(String datasource) {
        super(datasource);
    }
    
    @Override
    public ArrayList<ViewConfig> findList(String requestUrl, String lockMode) {
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs =null;
        String sql = "";
        ArrayList<ViewConfig> list = new ArrayList();
        
        try {
            con = getConnection();
            sql = "SELECT " + FIELDS
                    + " FROM " + getSchemaName() + "." + TABLE_NAME
                    + " WHERE"
                    + " REQUEST_URL = ?";
                    
            stmt = con.prepareStatement(sql + lockMode);
            int i = 1;
            stmt.setString(i++, requestUrl);
            
            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();
            while (rs.next()) {
                ViewConfig oBo = new ViewConfig();
                setBoFromResultSet(oBo, rs);
                list.add(oBo);
            }
            
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return list;
    }
}
