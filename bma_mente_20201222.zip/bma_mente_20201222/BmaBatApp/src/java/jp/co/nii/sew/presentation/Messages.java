package jp.co.nii.sew.presentation;

import java.io.Serializable;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * ���b�Z�[�W���X�g�̃}�b�v
 *
 * @author n-machida
 */
public class Messages implements Serializable{

    private Map<String, Message> messages = new LinkedHashMap<String, Message>();

    // �S�̂ɂ��Ẵ��\�b�h ///////////////////////////////////////////////////
    public Map getMessages() {
        return messages;
    }

    /**
     * @param messages the messages to set
     */
    public void setMessages(Map<String, Message> messages) {
        this.messages = messages;
    }

//    public Iterator getMessagesIterator(){
//        return messages.entrySet().iterator();
//    }

    public boolean isEmpty() {
        return getMessages().isEmpty();
    }

    public int getMessagesSize() {
        return getMessages().size();
    }
    
    public void clearMessages() {
        getMessages().clear();
    }

    // Map�̗v�f�ɑ΂��郁�\�b�h ////////////////////////////////////////////////
    public void put(String key, Message message) {
        getMessages().put(key, message);
    }

    public Message get(String key) {
        return (Message) getMessages().get(key);
    }
    
// ���X�g�Ł@�{�c�� /////////////////////////////////////////////////////////////
//    ArrayList<Message> messages = new ArrayList<Message>();
//    
//    public void add(int i, Message message) {
//        messages.add(i, message);
//    }
//
//    public Message get(int i) {
//        if(messages.size() < i){
//            return null;
//        } else {
//            return messages.get(i);
//        }
//    }
}
