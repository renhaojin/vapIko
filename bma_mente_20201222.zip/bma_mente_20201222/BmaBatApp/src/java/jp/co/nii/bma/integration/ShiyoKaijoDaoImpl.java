package jp.co.nii.bma.integration;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import jp.co.nii.bma.business.domain.ShiyoKaijo;
import jp.co.nii.bma.business.domain.ShiyoKaijoDao;
import jp.co.nii.sew.common.LogGenerate;
import jp.co.nii.sew.integration.SQLStateSQLExceptionTranslater;

/**
 * �g�p��� DAO�����N���X
 * @author DB�Ǘ��c�[��
 */
public class ShiyoKaijoDaoImpl extends GeneratedShiyoKaijoDaoImpl implements ShiyoKaijoDao {

    /**
     * �C���X�^���X�𐶐�����B
     * @param datasource �f�[�^�\�[�X��
     */
    public ShiyoKaijoDaoImpl(String datasource) {
        super(datasource);
    }

    /**
     * ��ꃊ���[�X�Ώۂ̌��ݐl�����X�V����B
     *
     * @param bo
     */
    public Boolean updateKaijoRelease(ShiyoKaijo bo) {
        Connection con = null;
        PreparedStatement stmt = null;
        String sql = "";
        try {
            con = getConnection();
          
            sql = "UPDATE " + getSchemaName() + "." + TABLE_NAME + " SET"
                    + " GENZAI_NINZU = cast((to_number(GENZAI_NINZU,'99999') - 1) as  character varying)"
                    + ",KOSHIN_KBN = ?"
                    + ",KOSHIN_DATE = ?"
                    + ",KOSHIN_TIME = ?"
                    + ",KOSHIN_USER_ID = ?"
                    + " WHERE NENDO = '" + bo.getNendo() + "'"
                    + " AND   SKN_KSU_CODE = '" + bo.getSknKsuCode() + "'"
                    + " AND   SHUBETSU_CODE = '" + bo.getShubetsuCode() + "'"
                    + " AND   KAISU_CODE = '" + bo.getKaisuCode() + "'"
                    + " AND   KAIJO_ID = '" + bo.getKaijoId() + "'"
                    + " AND   KAIJO_SHIKEN_KBN = '" + bo.getKaijoShikenKbn() + "'"
                    + " AND   KAISAICHI_CODE = '" + bo.getKaisaichiCode() + "'"
                    + " AND   KAIJO_CODE = '" + bo.getKaijoCode() + "'"
                    + " AND to_number(GENZAI_NINZU,'99999') < to_number(TEIIN,'99999')";

            stmt = con.prepareStatement(sql);
            int i = 1;
            stmt.setString(i++, bo.getKoshinKbn());
            stmt.setString(i++, bo.getKoshinDate());
            stmt.setString(i++, bo.getKoshinTime());
            stmt.setString(i++, bo.getKoshinUserId());

            LogGenerate.debugOutput(getSql(stmt));
            if (stmt.executeUpdate() == 0) {
                return false;
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt);
        }
        return true;
    }
}
