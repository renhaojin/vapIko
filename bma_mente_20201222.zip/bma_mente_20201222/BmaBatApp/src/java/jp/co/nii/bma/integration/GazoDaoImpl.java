package jp.co.nii.bma.integration;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Objects;
import jp.co.nii.bma.business.rto.GazoFubiTokusokuTsuchiJoho;
import jp.co.nii.bma.business.domain.GazoDao;
import jp.co.nii.bma.business.domain.Gazo;
import jp.co.nii.bma.business.domain.MoshikomiDao;
import jp.co.nii.bma.business.domain.ScheduleDao;
import jp.co.nii.bma.business.domain.TorokushaDao;
import jp.co.nii.bma.business.rto.GazoFubiTsuchiJoho;
import jp.co.nii.bma.business.rto.GazoUploadTokusokuTsuchiJoho;
import jp.co.nii.bma.business.service.common.BmaConstants;
import jp.co.nii.sew.business.domain.NoSuchDataException;
import jp.co.nii.sew.business.service.transaction.TransactionUtility;
import jp.co.nii.sew.common.LogGenerate;
import static jp.co.nii.sew.integration.AbstractDao.getSchemaName;
import jp.co.nii.sew.integration.SQLStateSQLExceptionTranslater;

/**
 * �摜 DAO�����N���X
 *
 * @author DB�Ǘ��c�[��
 */
public class GazoDaoImpl extends GeneratedGazoDaoImpl implements GazoDao {

    /**
     * �C���X�^���X�𐶐�����B
     *
     * @param datasource �f�[�^�\�[�X��
     */
    public GazoDaoImpl(String datasource) {
        super(datasource);
    }

    /**
     * �摜�s�����ʒm���[�����M�Ώێ҈ꗗ���擾����B
     *
     * @param kojinDantaiKbn �l:1 �c�́F2
     * @return �摜�s�����ʒm���[�����M�Ώێ҃��X�g
     */
    public List<GazoFubiTokusokuTsuchiJoho> searchFubiTokusokuTsuchiTaishoshaList(String kojinDantaiKbn) {
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = "";

        List<GazoFubiTokusokuTsuchiJoho> gazofubiTokusokuTsuchiJohoList = new LinkedList<>();

        try {
            con = getConnection();
            sql = "SELECT DISTINCT "
                    + "sknksuMst.SKN_KSU_NAME"
                    + ",gazoKbnName.HANYO_CHI as GAZO_KBN"
                    + "," + getSQLForDecryptByUTF8("SHIMEI")
                    + ",gazo.UKETSUKE_NO"
                    + ",hoseiIrai1Name.HANYO_CHI as HOSEI_IRAI_CODE_1"
                    + ",hoseiIrai2Name.HANYO_CHI as HOSEI_IRAI_CODE_2"
                    + ",hoseiIrai3Name.HANYO_CHI as HOSEI_IRAI_CODE_3"
                    + ",gazo.HOSEI_KIGEN_BI"
                    + "," + getSQLForDecryptByUTF8("MAIL_ADDRESS")
                    + ",gazo.GAZO_IDX"
                    + ",torokusha.MOSHIKOMISHA_ID as MOSHIKOMISHA_ID"
                    + " FROM " + getSchemaName() + "." + GazoDao.TABLE_NAME + " AS gazo"
                    + " INNER JOIN " + getSchemaName() + "." + MoshikomiDao.TABLE_NAME + " as moshikomi"
                    + " ON " + "gazo.NENDO  =  moshikomi.NENDO "
                    + " AND " + "gazo.UKETSUKE_NO  =  moshikomi.UKETSUKE_NO "
                    + " INNER JOIN " + getSchemaName() + "." + TorokushaDao.TABLE_NAME + " AS torokusha";
            if (Objects.equals(BmaConstants.PRIVATE, kojinDantaiKbn)) {
                sql = sql + " ON " + "moshikomi.MOSHIKOMISHA_ID  =  torokusha.MOSHIKOMISHA_ID ";
            } else {
                sql = sql + " ON " + "moshikomi.TOROKU_USER_ID  =  torokusha.MOSHIKOMISHA_ID ";
            }
            sql = sql
                    + " INNER JOIN " + getSchemaName() + "." + BmaConstants.SKNKSU_MST + " as sknksuMst"
                    + " ON " + "moshikomi.SKN_KSU_CODE  =  sknksuMst.SKN_KSU_CODE "
                    + " AND " + "moshikomi.SHUBETSU_CODE  =  sknksuMst.SHUBETSU_CODE "
                    + " AND " + "moshikomi.KAISU_CODE  =  sknksuMst.KAISU_CODE "
                    + " LEFT JOIN " + getSchemaName() + "." + BmaConstants.MEISHO_KANRI + " as gazoKbnName"
                    + " ON " + "gazo.GAZO_KBN  =  gazoKbnName.HANYO_CODE "
                    + " AND " + "gazoKbnName.GROUP_CODE  =  'GAZO_KBN' "
                    + " LEFT JOIN " + getSchemaName() + "." + BmaConstants.MEISHO_KANRI + " as hoseiIrai1Name"
                    + " ON " + "gazo.HOSEI_IRAI_CODE_1  =  hoseiIrai1Name.HANYO_CODE "
                    + " AND " + "hoseiIrai1Name.GROUP_CODE  =  'HOSEI_IRAI_CODE' "
                    + " LEFT JOIN " + getSchemaName() + "." + BmaConstants.MEISHO_KANRI + " as hoseiIrai2Name"
                    + " ON " + "gazo.HOSEI_IRAI_CODE_2  =  hoseiIrai2Name.HANYO_CODE "
                    + " AND " + "hoseiIrai2Name.GROUP_CODE  =  'HOSEI_IRAI_CODE' "
                    + " LEFT JOIN " + getSchemaName() + "." + BmaConstants.MEISHO_KANRI + " as hoseiIrai3Name"
                    + " ON " + "gazo.HOSEI_IRAI_CODE_3  =  hoseiIrai3Name.HANYO_CODE "
                    + " AND " + "hoseiIrai3Name.GROUP_CODE  =  'HOSEI_IRAI_CODE' "
                    + " INNER JOIN " + getSchemaName() + "." + ScheduleDao.TABLE_NAME + " AS beforeDays1 "
                    + " ON " + "moshikomi.SKN_KSU_CODE  =  beforeDays1.SKN_KSU_CODE "
                    + " AND " + "moshikomi.SHUBETSU_CODE  =  beforeDays1.SHUBETSU_CODE "
                    + " AND " + "moshikomi.KAISU_CODE  =  beforeDays1.KAISU_CODE "
                    + " AND " + "beforeDays1.SCHEDULE_CODE  =  '" + BmaConstants.SCHEDULE_CODE_22 + "'"
                    + " AND " + "beforeDays1.SCHEDULE_KBN  =  '" + BmaConstants.SCHEDULE_KBN_NISSU + "'"
                    + " INNER JOIN " + getSchemaName() + "." + ScheduleDao.TABLE_NAME + " AS beforeDays2 "
                    + " ON " + "moshikomi.SKN_KSU_CODE  =  beforeDays2.SKN_KSU_CODE "
                    + " AND " + "moshikomi.SHUBETSU_CODE  =  beforeDays2.SHUBETSU_CODE "
                    + " AND " + "moshikomi.KAISU_CODE  =  beforeDays2.KAISU_CODE "
                    + " AND " + "beforeDays2.SCHEDULE_CODE  =  '" + BmaConstants.SCHEDULE_CODE_23 + "'"
                    + " AND " + "beforeDays2.SCHEDULE_KBN  =  '" + BmaConstants.SCHEDULE_KBN_NISSU + "'"
                    + " WHERE " + "moshikomi.KOJIN_DANTAI_KBN = ?"
                    + " AND " + "moshikomi.MOSHIKOMI_KBN = '1'"
                    + " AND " + "gazo.HOSEI_IRAI_KBN  IN  ('1', '6') "
                    + " AND " + "torokusha.RONRI_SAKUJO_FLG  = '0' "
                    + " AND " + "moshikomi.RONRI_SAKUJO_FLG  = '0' "
                    + " AND " + "gazo.RONRI_SAKUJO_FLG  = '0' "
                    + " AND " + "((to_date(gazo.HOSEI_KIGEN_BI, 'YYYYMMDD') - CURRENT_DATE) = cast(beforeDays1.NISSU as numeric) OR "
                    + "(to_date(gazo.HOSEI_KIGEN_BI, 'YYYYMMDD') - CURRENT_DATE) = cast(beforeDays2.NISSU as numeric))"
                    + " ORDER BY MOSHIKOMISHA_ID ASC, sknksuMst.SKN_KSU_NAME ASC, GAZO_KBN ASC";
            stmt = con.prepareStatement(sql);
            int i = 1;
            stmt.setString(i++, kojinDantaiKbn);

            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();

            while (rs.next()) {
                GazoFubiTokusokuTsuchiJoho gazofubiTokusokuTsuchiJoho = new GazoFubiTokusokuTsuchiJoho();
                gazofubiTokusokuTsuchiJoho.setSknKsuName(rs.getString("SKN_KSU_NAME"));
                gazofubiTokusokuTsuchiJoho.setGazoKbn(rs.getString("GAZO_KBN"));
                gazofubiTokusokuTsuchiJoho.setShimei(rs.getString("SHIMEI"));
                gazofubiTokusokuTsuchiJoho.setUketsukeNo(rs.getString("UKETSUKE_NO"));
                gazofubiTokusokuTsuchiJoho.setHoseiIraiCode1(rs.getString("HOSEI_IRAI_CODE_1"));
                gazofubiTokusokuTsuchiJoho.setHoseiIraiCode2(rs.getString("HOSEI_IRAI_CODE_2"));
                gazofubiTokusokuTsuchiJoho.setHoseiIraiCode3(rs.getString("HOSEI_IRAI_CODE_3"));
                gazofubiTokusokuTsuchiJoho.setHoseiKigenBi(rs.getString("HOSEI_KIGEN_BI"));
                gazofubiTokusokuTsuchiJoho.setGazoIdx(rs.getString("GAZO_IDX"));
                gazofubiTokusokuTsuchiJoho.setMailAddress(rs.getString("MAIL_ADDRESS"));
                gazofubiTokusokuTsuchiJoho.setMoshikomishaId(rs.getString("MOSHIKOMISHA_ID"));
                gazofubiTokusokuTsuchiJohoList.add(gazofubiTokusokuTsuchiJoho);
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return gazofubiTokusokuTsuchiJohoList;
    }

    /**
     * �␳�˗����[�����M�t���O���X�V����B
     *
     * @param bo
     */
    public void updateMailTemplate(Gazo bo) {
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = "";
        int ret;
        try {
            con = getConnection();

            //�Ώۃ��R�[�h�Ƀ��b�N��������
            sql = "SELECT GAZO_IDX"
                    + " FROM " + getSchemaName() + "." + TABLE_NAME + " AS gazo"
                    + " WHERE GAZO_IDX = '" + bo.getGazoIdx() + "'";

            stmt = con.prepareStatement(sql + TransactionUtility.LOCK_WAIT);

            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();

            if (rs.next()) {
                sql = "UPDATE " + getSchemaName() + "." + TABLE_NAME + " SET"
                        + " HOSEI_IRAI_MAIL_SOSHIN_FLG = cast((to_number(case when HOSEI_IRAI_MAIL_SOSHIN_FLG = '' then '0' else HOSEI_IRAI_MAIL_SOSHIN_FLG end,'999') + 1) as  character varying)"
                        + ",KOSHIN_KBN = ?"
                        + ",KOSHIN_DATE = ?"
                        + ",KOSHIN_TIME = ?"
                        + ",KOSHIN_USER_ID = ?"
                        + " WHERE GAZO_IDX = '" + bo.getGazoIdx() + "'";

                stmt = con.prepareStatement(sql);
                int i = 1;
                stmt.setString(i++, bo.getKoshinKbn());
                stmt.setString(i++, bo.getKoshinDate());
                stmt.setString(i++, bo.getKoshinTime());
                stmt.setString(i++, bo.getKoshinUserId());

                LogGenerate.debugOutput(getSql(stmt));
                if (stmt.executeUpdate() == 0) {
                    throw new NoSuchDataException(getSql(stmt));
                }
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
    }

    @Override
    public List<Gazo> findByNendoUke(String nendo, String uketsukeNo) {
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = "";

        List<Gazo> ret = new ArrayList<>();
        try {
            con = getConnection();
            sql = "SELECT " + FIELDS_DECRYPT
                    + " FROM " + getSchemaName() + "." + TABLE_NAME
                    + " WHERE"
                    + " NENDO = ?"
                    + " AND UKETSUKE_NO = ?"
                    + " ORDER BY gazo_kbn";
            stmt = con.prepareStatement(sql);
            int i = 1;
            stmt.setString(i++, nendo);
            stmt.setString(i++, uketsukeNo);

            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();
            while (rs.next()) {
                Gazo bo = new Gazo();
                setBoFromResultSet(bo, rs);
                ret.add(bo);
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return ret;
    }

    /**
     * �摜�A�b�v���[�h���ʒm���[�����M�Ώێ҈ꗗ���擾����B
     *
     * @param kojinDantaiKbn �c�́F2
     * @return �摜a�A�b�v���[�h���ʒm���[�����M�Ώێ҃��X�g
     */
    public List<GazoUploadTokusokuTsuchiJoho> searchUploadTokusokuTsuchiTaishoshaList(String kojinDantaiKbn) {
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = "";

        List<GazoUploadTokusokuTsuchiJoho> gazoUploadTokusokuTsuchiJohoList = new LinkedList<>();

        try {
            con = getConnection();
            sql = "SELECT DISTINCT "
                    + "sknksuMst.SKN_KSU_NAME"
                    + ",gazoKbnName.HANYO_CHI as GAZO_KBN"
                    + "," + getSQLForDecryptByUTF8("SHIMEI")
                    + "," + getSQLForDecryptByUTF8("MAIL_ADDRESS")
                    + ",gazo.GAZO_IDX"
                    + ",torokusha.MOSHIKOMISHA_ID as MOSHIKOMISHA_ID"
                    + " FROM " + getSchemaName() + "." + GazoDao.TABLE_NAME + " AS gazo"
                    + " INNER JOIN " + getSchemaName() + "." + MoshikomiDao.TABLE_NAME + " as moshikomi"
                    + " ON " + "gazo.NENDO  =  moshikomi.NENDO "
                    + " AND " + "gazo.UKETSUKE_NO  =  moshikomi.UKETSUKE_NO "
                    + " INNER JOIN " + getSchemaName() + "." + TorokushaDao.TABLE_NAME + " AS torokusha";

            sql = sql + " ON " + "moshikomi.TOROKU_USER_ID  =  torokusha.MOSHIKOMISHA_ID ";

            sql = sql
                    + " INNER JOIN " + getSchemaName() + "." + BmaConstants.SKNKSU_MST + " as sknksuMst"
                    + " ON " + "moshikomi.SKN_KSU_CODE  =  sknksuMst.SKN_KSU_CODE "
                    + " AND " + "moshikomi.SHUBETSU_CODE  =  sknksuMst.SHUBETSU_CODE "
                    + " AND " + "moshikomi.KAISU_CODE  =  sknksuMst.KAISU_CODE "
                    + " LEFT JOIN " + getSchemaName() + "." + BmaConstants.MEISHO_KANRI + " as gazoKbnName"
                    + " ON " + "gazo.GAZO_KBN  =  gazoKbnName.HANYO_CODE "
                    + " AND " + "gazoKbnName.GROUP_CODE  =  'GAZO_KBN' "
                    + " INNER JOIN " + getSchemaName() + "." + ScheduleDao.TABLE_NAME + " AS beforeDays1 "
                    + " ON " + "moshikomi.SKN_KSU_CODE  =  beforeDays1.SKN_KSU_CODE "
                    + " AND " + "moshikomi.SHUBETSU_CODE  =  beforeDays1.SHUBETSU_CODE "
                    + " AND " + "moshikomi.KAISU_CODE  =  beforeDays1.KAISU_CODE "
                    + " AND " + "beforeDays1.SCHEDULE_CODE  =  '" + BmaConstants.SCHEDULE_CODE_22 + "'"
                    + " AND " + "beforeDays1.SCHEDULE_KBN  =  '" + BmaConstants.SCHEDULE_KBN_NISSU + "'"
                    + " INNER JOIN " + getSchemaName() + "." + ScheduleDao.TABLE_NAME + " AS beforeDays2 "
                    + " ON " + "moshikomi.SKN_KSU_CODE  =  beforeDays2.SKN_KSU_CODE "
                    + " AND " + "moshikomi.SHUBETSU_CODE  =  beforeDays2.SHUBETSU_CODE "
                    + " AND " + "moshikomi.KAISU_CODE  =  beforeDays2.KAISU_CODE "
                    + " AND " + "beforeDays2.SCHEDULE_CODE  =  '" + BmaConstants.SCHEDULE_CODE_23 + "'"
                    + " AND " + "beforeDays2.SCHEDULE_KBN  =  '" + BmaConstants.SCHEDULE_KBN_NISSU + "'"
                    + " WHERE " + "moshikomi.KOJIN_DANTAI_KBN = ?"
                    + " AND " + "moshikomi.MOSHIKOMI_KBN = '1'"
                    + " AND " + "gazo.HOSEI_IRAI_KBN = '1' "
                    + " AND " + "torokusha.RONRI_SAKUJO_FLG  = '0' "
                    + " AND " + "moshikomi.RONRI_SAKUJO_FLG  = '0' "
                    + " AND " + "gazo.RONRI_SAKUJO_FLG  = '0' "
                    + " AND " + "(CURRENT_DATE - (to_date(moshikomi.TOROKU_DATE, 'YYYYMMDD')) = cast(beforeDays1.NISSU as numeric) OR "
                    + "(CURRENT_DATE - (to_date(moshikomi.TOROKU_DATE, 'YYYYMMDD')) = cast(beforeDays2.NISSU as numeric)))"
                    + " ORDER BY MOSHIKOMISHA_ID ASC, sknksuMst.SKN_KSU_NAME ASC, GAZO_KBN ASC";
            stmt = con.prepareStatement(sql);
            int i = 1;
            stmt.setString(i++, BmaConstants.GROUP);

            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();

            while (rs.next()) {
                GazoUploadTokusokuTsuchiJoho gazouploadTokusokuTsuchiJoho = new GazoUploadTokusokuTsuchiJoho();
                gazouploadTokusokuTsuchiJoho.setSknKsuName(rs.getString("SKN_KSU_NAME"));
                gazouploadTokusokuTsuchiJoho.setGazoKbn(rs.getString("GAZO_KBN"));
                gazouploadTokusokuTsuchiJoho.setShimei(rs.getString("SHIMEI"));
                gazouploadTokusokuTsuchiJoho.setGazoIdx(rs.getString("GAZO_IDX"));
                gazouploadTokusokuTsuchiJoho.setMailAddress(rs.getString("MAIL_ADDRESS"));
                gazouploadTokusokuTsuchiJoho.setMoshikomishaId(rs.getString("MOSHIKOMISHA_ID"));
                gazoUploadTokusokuTsuchiJohoList.add(gazouploadTokusokuTsuchiJoho);
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return gazoUploadTokusokuTsuchiJohoList;
    }

    /**
     * �摜�s���ʒm���[�����M�Ώێ҈ꗗ���擾����B
     *
     * @param kojinDantaiKbn �l:1 �c�́F2
     * @return �摜�s���ʒm���[�����M�Ώێ҃��X�g
     */
    public List<GazoFubiTsuchiJoho> searchFubiTsuchiTaishoshaList(String kojinDantaiKbn) {
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = "";

        List<GazoFubiTsuchiJoho> gazofubiTsuchiJohoList = new ArrayList<>();

        try {
            con = getConnection();
            sql = "SELECT DISTINCT "
                    + "sknksuMst.SKN_KSU_NAME"
                    + ",gazoKbnName.HANYO_CHI as GAZO_KBN"
                    + "," + getSQLForDecryptByUTF8("SHIMEI")
                    + ",gazo.UKETSUKE_NO"
                    + ",hoseiIrai1Name.HANYO_CHI as HOSEI_IRAI_CODE_1"
                    + ",hoseiIrai2Name.HANYO_CHI as HOSEI_IRAI_CODE_2"
                    + ",hoseiIrai3Name.HANYO_CHI as HOSEI_IRAI_CODE_3"
                    + ",gazo.HOSEI_KIGEN_BI"
                    + "," + getSQLForDecryptByUTF8("MAIL_ADDRESS")
                    + ",gazo.GAZO_IDX"
                    + ",torokusha.MOSHIKOMISHA_ID as MOSHIKOMISHA_ID"
                    + " FROM " + getSchemaName() + "." + GazoDao.TABLE_NAME + " AS gazo"
                    + " INNER JOIN " + getSchemaName() + "." + MoshikomiDao.TABLE_NAME + " as moshikomi"
                    + " ON " + "gazo.NENDO  =  moshikomi.NENDO "
                    + " AND " + "gazo.UKETSUKE_NO  =  moshikomi.UKETSUKE_NO "
                    + " INNER JOIN " + getSchemaName() + "." + TorokushaDao.TABLE_NAME + " AS torokusha";
            if (Objects.equals(BmaConstants.PRIVATE, kojinDantaiKbn)) {
                sql = sql + " ON " + "moshikomi.MOSHIKOMISHA_ID  =  torokusha.MOSHIKOMISHA_ID ";
            } else {
                sql = sql + " ON " + "moshikomi.TOROKU_USER_ID  =  torokusha.MOSHIKOMISHA_ID ";
            }
            sql = sql
                    + " INNER JOIN " + getSchemaName() + "." + BmaConstants.SKNKSU_MST + " as sknksuMst"
                    + " ON " + "moshikomi.SKN_KSU_CODE  =  sknksuMst.SKN_KSU_CODE "
                    + " AND " + "moshikomi.SHUBETSU_CODE  =  sknksuMst.SHUBETSU_CODE "
                    + " AND " + "moshikomi.KAISU_CODE  =  sknksuMst.KAISU_CODE "
                    + " LEFT JOIN " + getSchemaName() + "." + BmaConstants.MEISHO_KANRI + " as gazoKbnName"
                    + " ON " + "gazo.GAZO_KBN  =  gazoKbnName.HANYO_CODE "
                    + " AND " + "gazoKbnName.GROUP_CODE  =  'GAZO_KBN' "
                    + " LEFT JOIN " + getSchemaName() + "." + BmaConstants.MEISHO_KANRI + " as hoseiIrai1Name"
                    + " ON " + "gazo.HOSEI_IRAI_CODE_1  =  hoseiIrai1Name.HANYO_CODE "
                    + " AND " + "hoseiIrai1Name.GROUP_CODE  =  'HOSEI_IRAI_CODE' "
                    + " LEFT JOIN " + getSchemaName() + "." + BmaConstants.MEISHO_KANRI + " as hoseiIrai2Name"
                    + " ON " + "gazo.HOSEI_IRAI_CODE_2  =  hoseiIrai2Name.HANYO_CODE "
                    + " AND " + "hoseiIrai2Name.GROUP_CODE  =  'HOSEI_IRAI_CODE' "
                    + " LEFT JOIN " + getSchemaName() + "." + BmaConstants.MEISHO_KANRI + " as hoseiIrai3Name"
                    + " ON " + "gazo.HOSEI_IRAI_CODE_3  =  hoseiIrai3Name.HANYO_CODE "
                    + " AND " + "hoseiIrai3Name.GROUP_CODE  =  'HOSEI_IRAI_CODE' "
                    + " WHERE " + "moshikomi.KOJIN_DANTAI_KBN = ?"
                    + " AND " + "moshikomi.MOSHIKOMI_KBN = '1'"
                    + " AND " + "gazo.HOSEI_IRAI_KBN = '5' "
                    + " AND " + "torokusha.RONRI_SAKUJO_FLG  = '0' "
                    + " AND " + "moshikomi.RONRI_SAKUJO_FLG  = '0' "
                    + " AND " + "gazo.RONRI_SAKUJO_FLG  = '0' "
                    + " AND " + "(CURRENT_DATE - to_date(gazo.HOSEI_IRAI_BI, 'YYYYMMDD') = 1) "
                    + " ORDER BY MOSHIKOMISHA_ID ASC, sknksuMst.SKN_KSU_NAME ASC, GAZO_KBN ASC";
            stmt = con.prepareStatement(sql);
            int i = 1;
            stmt.setString(i++, kojinDantaiKbn);

            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();

            while (rs.next()) {
                GazoFubiTsuchiJoho gazofubiTsuchiJoho = new GazoFubiTsuchiJoho();
                gazofubiTsuchiJoho.setSknKsuName(rs.getString("SKN_KSU_NAME"));
                gazofubiTsuchiJoho.setGazoKbn(rs.getString("GAZO_KBN"));
                gazofubiTsuchiJoho.setShimei(rs.getString("SHIMEI"));
                gazofubiTsuchiJoho.setUketsukeNo(rs.getString("UKETSUKE_NO"));
                gazofubiTsuchiJoho.setHoseiIraiCode1(rs.getString("HOSEI_IRAI_CODE_1"));
                gazofubiTsuchiJoho.setHoseiIraiCode2(rs.getString("HOSEI_IRAI_CODE_2"));
                gazofubiTsuchiJoho.setHoseiIraiCode3(rs.getString("HOSEI_IRAI_CODE_3"));
                gazofubiTsuchiJoho.setHoseiKigenBi(rs.getString("HOSEI_KIGEN_BI"));
                gazofubiTsuchiJoho.setGazoIdx(rs.getString("GAZO_IDX"));
                gazofubiTsuchiJoho.setMailAddress(rs.getString("MAIL_ADDRESS"));
                gazofubiTsuchiJoho.setMoshikomishaId(rs.getString("MOSHIKOMISHA_ID"));
                gazofubiTsuchiJohoList.add(gazofubiTsuchiJoho);
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return gazofubiTsuchiJohoList;
    }

    /**
     * �摜�s���ʒm�𑗐M�����Ώۂ̉摜���X�V����B
     *
     * @param bo
     */
    public Boolean updateForFubiTsuchi(Gazo bo) {
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = "";
        Boolean result = false;
        try {
            con = getConnection();

            //�Ώۃ��R�[�h�Ƀ��b�N��������
            sql = "SELECT GAZO_IDX"
                    + " FROM " + getSchemaName() + "." + TABLE_NAME + " AS gazo"
                    + " WHERE GAZO_IDX = '" + bo.getGazoIdx() + "'";

            stmt = con.prepareStatement(sql + TransactionUtility.LOCK_WAIT);

            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();

            if (rs.next()) {
                sql = "UPDATE " + getSchemaName() + "." + TABLE_NAME + " SET"
                        + " HOSEI_IRAI_KBN = ?"
                        + ",GAZO_HYOJI_KBN = ?"
                        + ",HOSEI_IRAI_MAIL_SOSHIN_FLG = cast((to_number(HOSEI_IRAI_MAIL_SOSHIN_FLG,'999') + 1) as  character varying)"
                        + ",KOSHIN_KBN = ?"
                        + ",KOSHIN_DATE = ?"
                        + ",KOSHIN_TIME = ?"
                        + ",KOSHIN_USER_ID = ?"
                        + " WHERE GAZO_IDX = '" + bo.getGazoIdx() + "'";

                stmt = con.prepareStatement(sql);
                int i = 1;
                stmt.setString(i++, bo.getHoseiIraiKbn());
                stmt.setString(i++, bo.getGazoHyojiKbn());
                stmt.setString(i++, bo.getKoshinKbn());
                stmt.setString(i++, bo.getKoshinDate());
                stmt.setString(i++, bo.getKoshinTime());
                stmt.setString(i++, bo.getKoshinUserId());

                LogGenerate.debugOutput(getSql(stmt));
                if (stmt.executeUpdate() == 0) {
                    throw new NoSuchDataException(getSql(stmt));
                } else {
                    result =true;
                }
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return result;
    }
}
