package jp.co.nii.bma.integration;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import jp.co.nii.bma.business.domain.Schedule;
import jp.co.nii.bma.business.domain.ScheduleDao;
import jp.co.nii.bma.business.service.common.BmaConstants;
import jp.co.nii.sew.business.service.transaction.TransactionUtility;
import jp.co.nii.sew.common.LogGenerate;
import jp.co.nii.sew.integration.SQLStateSQLExceptionTranslater;

/**
 * �X�P�W���[�� DAO�����N���X
 *
 * @author DB�Ǘ��c�[��
 */
public class ScheduleDaoImpl extends GeneratedScheduleDaoImpl implements ScheduleDao {

    /**
     * �C���X�^���X�𐶐�����B
     *
     * @param datasource �f�[�^�\�[�X��
     */
    public ScheduleDaoImpl(String datasource) {
        super(datasource);
    }

    /**
     * ������擾�i���i���_�a�@�y�V�z��ʁj�B<br>
     *
     * @param nendo �N�x
     * @param sknKsuCode �����u�K��R�[�h
     * @param shubetsuCode ��ʃR�[�h
     * @param scheduleCode �X�P�W���[���R�[�h
     * @param scheduleKbn �X�P�W���[���敪
     * @return �����������<br>
     */
    public String getKijunbi(String nendo, String sknKsuCode, String shubetsuCode, String kaisuCode, String scheduleCode, String scheduleKbn) {
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = "";
        String date = "";
        try {
            con = getConnection();
            sql = "SELECT " + FIELDS_DECRYPT
                    + " FROM " + getSchemaName() + "." + TABLE_NAME
                    + " WHERE"
                    + "  NENDO = ?"
                    + " AND SKN_KSU_CODE = ?"
                    + " AND SHUBETSU_CODE = ?"
                    + " AND KAISU_CODE = ?"
                    + " AND RONRI_SAKUJO_FLG = ?"
                    + " AND SCHEDULE_CODE = ?"
                    + " AND SCHEDULE_KBN = ?";

            stmt = con.prepareStatement(sql);
            int i = 1;
            stmt.setString(i++, nendo);
            stmt.setString(i++, sknKsuCode);
            stmt.setString(i++, shubetsuCode);
            stmt.setString(i++, kaisuCode);
            stmt.setString(i++, BmaConstants.FLG_OFF);
            stmt.setString(i++, scheduleCode);
            stmt.setString(i++, scheduleKbn);

            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();
            if (rs.next()) {
                date = rs.getString("DATE");
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return date;
    }

    /**
     * �Ώۃf�[�^���폜�B<br>
     *
     * @param tableId �e�[�u��ID
     * @param nendo �N�x
     * @param sknKsuCode �����u�K��R�[�h
     * @param shubetsuCode ��ʃR�[�h
     * @param kaisuCode �񐔃R�[�h
     * @return ���o�����A�폜����
     */
    public int[] deleteTaishoData(String tableId, String nendo, String sknKsuCode, String shubetsuCode, String kaisuCode) {
        Connection con = null;
        PreparedStatement stmtForSelect = null;
        PreparedStatement stmtForDelete = null;
        Statement stmtForCommand = null;
        ResultSet rs = null;
        String sql = "";
        int[] ret = new int[2];
        try {
            con = getConnection();
            sql = "SELECT NENDO "
                    + " FROM " + getSchemaName() + "." + tableId
                    + " WHERE"
                    + "  NENDO = ?"
                    + " AND SKN_KSU_CODE = ?"
                    + " AND SHUBETSU_CODE = ?"
                    + " AND KAISU_CODE = ?"
                    + " AND RONRI_SAKUJO_FLG = ?"
                    + " FOR UPDATE ";
            stmtForSelect = con.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE,
                    ResultSet.CONCUR_READ_ONLY);
            int i = 1;
            stmtForSelect.setString(i++, nendo);
            stmtForSelect.setString(i++, sknKsuCode);
            stmtForSelect.setString(i++, shubetsuCode);
            stmtForSelect.setString(i++, kaisuCode);
            stmtForSelect.setString(i++, BmaConstants.FLG_OFF);

            LogGenerate.debugOutput(getSql(stmtForSelect));
            rs = stmtForSelect.executeQuery();
            if (rs.next()) {
                rs.last();
                ret[0] = rs.getRow();
            }

            // tsv�t�@�C���ɏo��
            // �R�}���h�擾
// TODO db�N���C�A���g����
//            String exportTable = PropertyUtility.getProperty(BUSINESS_CODE + "export_table");
//            // �p�X�擾
//            String exportPath = PropertyUtility.getProperty(BUSINESS_CODE + "export_path");
//            // SQL�R�}���h�쐬
//            String sqlCommand = MessageFormat.format(exportTable, tableId, exportPath);
//            stmtForCommand = con.createStatement();
//            LogGenerate.debugOutput(getSql(stmtForCommand));
//            stmtForCommand.executeQuery(sqlCommand);
            // �Ώۃf�[�^���폜
            sql = "DELETE  "
                    + " FROM " + getSchemaName() + "." + tableId
                    + " WHERE"
                    + "  NENDO = ?"
                    + " AND SKN_KSU_CODE = ?"
                    + " AND SHUBETSU_CODE = ?"
                    + " AND KAISU_CODE = ?"
                    + " AND RONRI_SAKUJO_FLG = ?";
            stmtForDelete = con.prepareStatement(sql);
            i = 1;
            stmtForDelete.setString(i++, nendo);
            stmtForDelete.setString(i++, sknKsuCode);
            stmtForDelete.setString(i++, shubetsuCode);
            stmtForDelete.setString(i++, kaisuCode);
            stmtForDelete.setString(i++, BmaConstants.FLG_OFF);

            LogGenerate.debugOutput(getSql(stmtForDelete));
            ret[1] = stmtForDelete.executeUpdate();
            return ret;
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmtForSelect), ex);
        } finally {
            close(con, stmtForSelect, rs);
            close(con, stmtForDelete, rs);
            if (stmtForCommand != null) {
                try {
                    stmtForCommand.close();
                } catch (SQLException ex) {
                    throw new SQLStateSQLExceptionTranslater().translate(getSql(stmtForCommand), ex);
                }
            }
        }
    }

    @Override
    public List<Schedule> findByScheduleAndDate(String scheduleCode, String scheduleKbn, String date) {

        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = "";
        List<Schedule> resultList = new ArrayList<>();
        
        try {
            con = getConnection();
            sql = "SELECT " + FIELDS_DECRYPT
                    + " FROM " + getSchemaName() + "." + TABLE_NAME
                    + " WHERE"
                    + " SCHEDULE_CODE = ?"
                    + " AND SCHEDULE_KBN = ?"
                    + " AND DATE = ?";

            stmt = con.prepareStatement(sql + TransactionUtility.NO_LOCK);
            int i = 1;
            stmt.setString(i++, scheduleCode);
            stmt.setString(i++, scheduleKbn);
            stmt.setString(i++, date);

            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();

            while (rs.next()) {
                Schedule bo = new Schedule();
                setBoFromResultSet(bo, rs);
                resultList.add(bo);
            }

        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return resultList;
    }
    
    @Override
    public List<Schedule> findByScheduleCodeAndKbn(String scheduleCode, String scheduleKbn, String dateTime) {

        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = "";
        List<Schedule> resultList = new ArrayList<>();
        
        try {
            con = getConnection();
            sql = "SELECT " + FIELDS_DECRYPT
                    + " FROM " + getSchemaName() + "." + TABLE_NAME
                    + " WHERE DATE !='' "
                    + " AND DATE || TIME <= ?"
                    + " AND SCHEDULE_CODE = ?"
                    + " AND SCHEDULE_KBN = ?";
 
            stmt = con.prepareStatement(sql + TransactionUtility.NO_LOCK);
            int i = 1;
            stmt.setString(i++, dateTime);
            stmt.setString(i++, scheduleCode);
            stmt.setString(i++, scheduleKbn);

            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();

            while (rs.next()) {
                Schedule bo = new Schedule();
                setBoFromResultSet(bo, rs);
                resultList.add(bo);
            }

        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return resultList;
    }
}
