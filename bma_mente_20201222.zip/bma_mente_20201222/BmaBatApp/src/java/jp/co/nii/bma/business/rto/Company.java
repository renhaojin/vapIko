package jp.co.nii.bma.business.rto;

/**
 * ��Ə��
 *
 * @author n-machida
 */
public class Company {

    /**
     * ��ƃR�[�h
     */
    private String companyCode;

    /**
     * �������
     */
    private String kyokai_name;

    /**
     * URL
     */
    private String url;

    /**
     * ��ƃR�[�h
     *
     * @return the companyCode
     */
    public String getCompanyCode() {
        return companyCode;
    }

    /**
     * ��ƃR�[�h
     *
     * @param companyCode the companyCode to set
     */
    public void setCompanyCode(String companyCode) {
        this.companyCode = companyCode;
    }

    /**
     * �������
     *
     * @return the kyokai_name
     */
    public String getKyokai_name() {
        return kyokai_name;
    }

    /**
     * �������
     *
     * @param kyokai_name the kyokai_name to set
     */
    public void setKyokai_name(String kyokai_name) {
        this.kyokai_name = kyokai_name;
    }

    /**
     * URL
     *
     * @return the url
     */
    public String getUrl() {
        return url;
    }

    /**
     * URL
     *
     * @param url the url to set
     */
    public void setUrl(String url) {
        this.url = url;
    }

}
