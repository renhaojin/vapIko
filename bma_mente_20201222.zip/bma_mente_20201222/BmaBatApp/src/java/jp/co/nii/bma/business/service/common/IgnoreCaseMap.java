package jp.co.nii.bma.business.service.common;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class IgnoreCaseMap extends HashMap
{
   //���O�o�͗p
    Log log = LogFactory.getLog(this.getClass());

    public IgnoreCaseMap()
    {
    }

    public IgnoreCaseMap(Map src)
    {
        this();
        other(src);
    }

    public Object put(Object key, Object value)
    {
        return super.put(toLowerKey(key), value);
    }

    public Object get(Object key)
    {
        ensure(key);
        return super.get(toLowerKey(key));
    }

    public boolean containsKey(Object key)
    {
        return super.containsKey(toLowerKey(key));
    }

    public Object remove(Object key)
    {
        return super.remove(toLowerKey(key));
    }

    private void other(Map src)
    {
        Set entrySet = src.entrySet();
        java.util.Map.Entry entry;
        for(Iterator it = entrySet.iterator(); it.hasNext(); put(entry.getKey(), entry.getValue()))
            entry = (java.util.Map.Entry)it.next();

    }

    private void ensure(Object key)
    {
        if(!containsKey(key))
            log.debug("ensure : key[  ] error");
    }

    private String toLowerKey(Object key)
    {
        if(null == key)
            return null;
        else
            return key.toString().toLowerCase();
    }

}
