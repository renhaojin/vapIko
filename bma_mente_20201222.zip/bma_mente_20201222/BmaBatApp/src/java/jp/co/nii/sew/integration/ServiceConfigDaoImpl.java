package jp.co.nii.sew.integration;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import jp.co.nii.sew.business.domain.ServiceConfig;
import jp.co.nii.sew.business.domain.ServiceConfigDao;
import jp.co.nii.sew.common.LogGenerate;

/**
 * �T�[�r�X�ݒ� DAO�����N���X
 * @author DB�Ǘ��c�[��
 */
public class ServiceConfigDaoImpl extends GeneratedServiceConfigDaoImpl implements ServiceConfigDao {

    /**
     * �C���X�^���X�𐶐�����B
     * @param datasource �f�[�^�\�[�X��
     */
    public ServiceConfigDaoImpl(String datasource) {
        super(datasource);
    }
    
    @Override
    public ArrayList<ServiceConfig> findListAll(String lockMode) {
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs =null;
        String sql = "";
        ArrayList<ServiceConfig> list = new ArrayList();

        try {
            con = getConnection();
            sql = "SELECT " + FIELDS
                    + " FROM " + getSchemaName() + "." + TABLE_NAME;
            stmt = con.prepareStatement(sql + lockMode);

            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();
            while (rs.next()) {
                ServiceConfig bo = new ServiceConfig();
                setBoFromResultSet(bo, rs);
                list.add(bo);
            }
            
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return list;
    }
}
