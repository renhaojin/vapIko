package jp.co.nii.bma.utility;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import org.apache.log4j.Logger;
/**
 * Bean�̔�r
 * @author ouen04
 */
public class BmaBeanCompare {
    
    /**
     * log
     */
    private static Logger logger = Logger.getLogger(BmaBeanCompare.class);

    public BmaBeanCompare() {
    }

    /**
     * Bean�̔�r
     * @param source �O
     * @param target ��
     * @return
     */
    public static boolean domainEquals(Object source, Object target) {
        if (source == null || target == null) {
            return false;
        }
        return classOfSrc(source, target, true);
    }
    
     /**
     * beanObject
     * @param source
     * @param target
     * @param result
     * @return
     */
    private static boolean classOfSrc(Object source, Object target, boolean result) {
        Class<?> srcClass = source.getClass();
        Field[] fields = srcClass.getDeclaredFields();
        for (Field field : fields) {
            String nameKey = field.getName();
            if (target instanceof Map) {
                HashMap<String, String> tarMap = new HashMap<String, String>();
                tarMap = (HashMap) target;
                String srcValue = getClassValue(source, nameKey) == null ? "" : getClassValue(source, nameKey).toString();
                if(tarMap.get(nameKey)==null){
                    result = false;
                    break;
                }
                if (!tarMap.get(nameKey).equals(srcValue)) {
                    result = false;
                    break;
                }
            } else {
                String srcValue = getClassValue(source, nameKey) == null ? "" : getClassValue(source, nameKey).toString();
                String tarValue = getClassValue(target, nameKey) == null ? "" : getClassValue(target, nameKey).toString();
                if (!srcValue.equals(tarValue)) {
                    result = false;
                    break;
                }
            }
        }
        return result;
    }
    
    public static Object getClassValue(Object obj, String fieldName) {
        if (obj == null) {
            return null;
        }
        try {
            Class beanClass = obj.getClass();
            Method[] ms = beanClass.getMethods();
            for (int i = 0; i < ms.length; i++) {
                // ��get()
                if (!ms[i].getName().startsWith("get")) {
                    continue;
                }
                Object objValue = null;
                try {
                    objValue = ms[i].invoke(obj, new Object[] {});
                } catch (Exception e) {
                     logger.info("Bean�̔�r�G���[�F" + e.toString());
                    continue;
                }
                if (objValue == null) {
                    continue;
                }
                if (ms[i].getName().toUpperCase().equals(fieldName.toUpperCase())
                        || ms[i].getName().substring(3).toUpperCase().equals(fieldName.toUpperCase())) {
                    return objValue;
                } else if (fieldName.toUpperCase().equals("SID")
                        && (ms[i].getName().toUpperCase().equals("ID") 
                        || ms[i].getName().substring(3).toUpperCase().equals("ID"))) {
                    return objValue;
                }
            }
        } catch (Exception e) {
        }
        return null;
    }

}
