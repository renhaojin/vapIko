package jp.co.nii.bma.business.service;

/**
 * �J�E���^�[
 * @author n-machida
 */
class Counters {
    
    public int inRecordCount = 0;
    public int normalRecordCount = 0;
    public int errorRecordCount = 0;
    public int exceptionRecordCount = 0;
    public int outRecordCount = 0;    
    
}
