package jp.co.nii.bma.business.service;

import java.util.List;
import jp.co.nii.bma.business.domain.Kessai;
import jp.co.nii.bma.business.domain.KessaiDao;
import jp.co.nii.bma.business.domain.MoshikomiDao;
import jp.co.nii.bma.business.domain.ShiyoKaijo;
import jp.co.nii.bma.business.domain.ShiyoKaijoDao;
import jp.co.nii.bma.business.rto.KaijoReleaseJoho;
import jp.co.nii.bma.business.service.common.BmaConstants;
import jp.co.nii.bma.integration.KessaiDaoImpl;
import jp.co.nii.bma.integration.MoshikomiDaoImpl;
import jp.co.nii.bma.integration.ShiyoKaijoDaoImpl;
import jp.co.nii.sew.business.SystemTime;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * <p>
 * �^�C�g��: ��ꃊ���[�X�T�[�r�X</p>
 * <p>
 * ����: ��ꃊ���[�X�T�[�r�X�̎����N���X</p>
 * <p>
 * ���쌠: Copyright (c) 2020</p>
 * <p>
 * ��Ж�: ���{���Y�Ɗ������</p>
 *
 * @author NII
 */
public class KaijoReleaseService {

    Log log = LogFactory.getLog(this.getClass());

    /**
     * DB�ڑ��̃f�[�^�\�[�X
     */
    private static String DATA_SOURCE_NAME;

    /**
     * ��ꃊ���[�X�̍X�V���s��
     *
     */
    public boolean updateKaijoRelease() {
        // �J�n���O
        log.info("Start, updateKaijoRelease ");
        
        boolean ret = true;
        int okForKessai = 0;
        int ngForKessai = 0;
        int okForShiyoKaijo = 0;
        int ngForShiyoKaijo = 0;
        
        MoshikomiDao moshikomi = new MoshikomiDaoImpl(DATA_SOURCE_NAME);
        KessaiDao kessai = new KessaiDaoImpl(DATA_SOURCE_NAME);
        ShiyoKaijoDao shiyoKaijo = new ShiyoKaijoDaoImpl(DATA_SOURCE_NAME);
        
        try {
            /* �X�V�Ώی��� */
            List<KaijoReleaseJoho> listForRelease = moshikomi.searchKaijoRelease();
            for (KaijoReleaseJoho kaijoRelease : listForRelease) {
                // ���ς��X�V
                Kessai updKessai = setUpdKessaiJoho(kaijoRelease);
                boolean kessaiUpdate = kessai.updateRonriSakujoFlg(updKessai);
                if (kessaiUpdate) {
                    ++okForKessai;
                } else {
                    ++ngForKessai;
                }

                // �g�p�����X�V
                ShiyoKaijo updShiyoKaijo = setUpdShiyoKaijo(kaijoRelease);
                boolean shiyoKaijoUpdate = shiyoKaijo.updateKaijoRelease(updShiyoKaijo);
                if (shiyoKaijoUpdate) {
                    ++okForShiyoKaijo;
                } else {
                    ++ngForShiyoKaijo;
                }
            }
        } catch (Exception e) {
            log.error("End, updateKaijoRelease ", e);
            ret = false;
        } finally {
            log.info("���ύX�V�����F " + okForKessai);
            log.info("���ϖ��X�V�����F " + ngForKessai);
            log.info("�g�p���X�V�����F " + okForShiyoKaijo);
            log.info("�g�p��ꖢ�X�V�����F " + ngForShiyoKaijo);
        }

        // �I�����O
        log.info("End, updateKaijoRelease ");
        return ret;
    }

    /**
     * �X�V���錈�Ϗ����Z�b�g����
     *
     * @param kaijoRelease �X�V�Ώۃ��R�[�h
     */
    public Kessai setUpdKessaiJoho(KaijoReleaseJoho kaijoRelease) {
        /*�ϐ�������*/
        Kessai result = new Kessai();
        /*���ݓ����擾*/
        SystemTime sysTime = new SystemTime();
        
        result.setNendo(kaijoRelease.getNendo());
        result.setUketsukeNo(kaijoRelease.getUketsukeNo());
        result.setKoshinKbn(BmaConstants.KOSHIN_KBN_UPDATE);
        result.setKoshinDate(sysTime.getymd1());
        result.setKoshinTime(sysTime.gethms1());
        result.setKoshinUserId(BmaConstants.BATCH_USER);
        
        return result;
    }

    /**
     * �X�V����g�p�������Z�b�g����
     *
     * @param kaijoRelease �X�V�Ώۃ��R�[�h
     */
    public ShiyoKaijo setUpdShiyoKaijo(KaijoReleaseJoho kaijoRelease) {
        /*�ϐ�������*/
        ShiyoKaijo result = new ShiyoKaijo();
        /*���ݓ����擾*/
        SystemTime sysTime = new SystemTime();
        
        result.setNendo(kaijoRelease.getNendo());
        result.setSknKsuCode(kaijoRelease.getSknKsuCode());
        result.setShubetsuCode(kaijoRelease.getShubetsuCode());
        result.setKaisuCode(kaijoRelease.getKaisuCode());
        result.setKaijoId(kaijoRelease.getKaijoId());
        result.setKaijoShikenKbn("0");
        result.setKaisaichiCode(kaijoRelease.getKaisaichiCode());
        result.setKaijoCode(kaijoRelease.getKaijoCode());
        result.setKoshinKbn(BmaConstants.KOSHIN_KBN_UPDATE);
        result.setKoshinDate(sysTime.getymd1());
        result.setKoshinTime(sysTime.gethms1());
        result.setKoshinUserId(BmaConstants.BATCH_USER);
        
        return result;
    }
}
