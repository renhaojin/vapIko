package jp.co.nii.bma.business.rto;

/**
 * �^�C�g��: ���ϓ���� ���쌠: Copyright (c) 2020 ��Ж�: ���{���Y�Ɗ������
 */
public class KessaiTokusokuJoho {

    private String sknKsuName;
    private String shimei;
    private String uketsukeNo;
    private String kessaiKigenBi;
    private String kessaiHohoKbnCode;
    private String kessaiHohoKbn;
    private String kessaiKingakuTotal;
    private String kessaiConvenienceShubetsu;
    private String kessaiConvenienceHaraikomiNo;

    private String kessaiShunoKikanNo;
    private String kessaiOkyakusamaNo;
    private String kessaiKakuninNo;

    private String mailAddress;
    private String nendo;
    private String moshikomishaId;

    /**
     * �R���X�g���N�^
     */
    public KessaiTokusokuJoho() {
        clearInfo();
    }

    /**
     * ���������\�b�h
     */
    private void clearInfo() {
        setSknKsuName("");
        setShimei("");
        setUketsukeNo("");
        setKessaiKigenBi("");
        setKessaiHohoKbnCode("");
        setKessaiHohoKbn("");
        setKessaiKingakuTotal("");
        setKessaiConvenienceShubetsu("");
        setKessaiConvenienceHaraikomiNo("");
        setMailAddress("");
        setNendo("");
        setKessaiShunoKikanNo("");
        setKessaiOkyakusamaNo("");
        setKessaiKakuninNo("");
        setMoshikomishaId("");
    }

    /**
     * @return the sknKsuName
     */
    public String getSknKsuName() {
        return sknKsuName;
    }

    /**
     * @param sknKsuName the sknKsuName to set
     */
    public void setSknKsuName(String sknKsuName) {
        this.sknKsuName = sknKsuName;
    }

    /**
     * @return the shimei
     */
    public String getShimei() {
        return shimei;
    }

    /**
     * @param shimei the shimei to set
     */
    public void setShimei(String shimei) {
        this.shimei = shimei;
    }

    /**
     * @return the uketsukeNo
     */
    public String getUketsukeNo() {
        return uketsukeNo;
    }

    /**
     * @param uketsukeNo the uketsukeNo to set
     */
    public void setUketsukeNo(String uketsukeNo) {
        this.uketsukeNo = uketsukeNo;
    }

    /**
     * @return the kessaiKigenBi
     */
    public String getKessaiKigenBi() {
        return kessaiKigenBi;
    }

    /**
     * @param kessaiKigenBi the kessaiKigenBi to set
     */
    public void setKessaiKigenBi(String kessaiKigenBi) {
        this.kessaiKigenBi = kessaiKigenBi;
    }

    /**
     * @return the kessaiHohoKbnCode
     */
    public String getKessaiHohoKbnCode() {
        return kessaiHohoKbnCode;
    }

    /**
     * @param kessaiHohoKbnCode the kessaiHohoKbnCode to set
     */
    public void setKessaiHohoKbnCode(String kessaiHohoKbnCode) {
        this.kessaiHohoKbnCode = kessaiHohoKbnCode;
    }

    /**
     * @return the kessaiHohoKbn
     */
    public String getKessaiHohoKbn() {
        return kessaiHohoKbn;
    }

    /**
     * @param kessaiHohoKbn the kessaiHohoKbn to set
     */
    public void setKessaiHohoKbn(String kessaiHohoKbn) {
        this.kessaiHohoKbn = kessaiHohoKbn;
    }

    /**
     * @return the kessaiKingakuTotal
     */
    public String getKessaiKingakuTotal() {
        return kessaiKingakuTotal;
    }

    /**
     * @param kessaiKingakuTotal the kessaiKingakuTotal to set
     */
    public void setKessaiKingakuTotal(String kessaiKingakuTotal) {
        this.kessaiKingakuTotal = kessaiKingakuTotal;
    }

    /**
     * @return the kessaiConvenienceShubetsu
     */
    public String getKessaiConvenienceShubetsu() {
        return kessaiConvenienceShubetsu;
    }

    /**
     * @param kessaiConvenienceShubetsu the kessaiConvenienceShubetsu to set
     */
    public void setKessaiConvenienceShubetsu(String kessaiConvenienceShubetsu) {
        this.kessaiConvenienceShubetsu = kessaiConvenienceShubetsu;
    }

    /**
     * @return the kessaiConvenienceHaraikomiNo
     */
    public String getKessaiConvenienceHaraikomiNo() {
        return kessaiConvenienceHaraikomiNo;
    }

    /**
     * @param kessaiConvenienceHaraikomiNo the kessaiConvenienceHaraikomiNo to
     * set
     */
    public void setKessaiConvenienceHaraikomiNo(String kessaiConvenienceHaraikomiNo) {
        this.kessaiConvenienceHaraikomiNo = kessaiConvenienceHaraikomiNo;
    }

    /**
     * @return the kessaiShunoKikanNo
     */
    public String getKessaiShunoKikanNo() {
        return kessaiShunoKikanNo;
    }

    /**
     * @param kessaiShunoKikanNo the kessaiShunoKikanNo to set
     */
    public void setKessaiShunoKikanNo(String kessaiShunoKikanNo) {
        this.kessaiShunoKikanNo = kessaiShunoKikanNo;
    }

    /**
     * @return the kessaiOkyakusamaNo
     */
    public String getKessaiOkyakusamaNo() {
        return kessaiOkyakusamaNo;
    }

    /**
     * @param kessaiOkyakusamaNo the kessaiOkyakusamaNo to set
     */
    public void setKessaiOkyakusamaNo(String kessaiOkyakusamaNo) {
        this.kessaiOkyakusamaNo = kessaiOkyakusamaNo;
    }

    /**
     * @return the kessaiKakuninNo
     */
    public String getKessaiKakuninNo() {
        return kessaiKakuninNo;
    }

    /**
     * @param kessaiKakuninNo the kessaiKakuninNo to set
     */
    public void setKessaiKakuninNo(String kessaiKakuninNo) {
        this.kessaiKakuninNo = kessaiKakuninNo;
    }

    /**
     * @return the mailAddress
     */
    public String getMailAddress() {
        return mailAddress;
    }

    /**
     * @param mailAddress the mailAddress to set
     */
    public void setMailAddress(String mailAddress) {
        this.mailAddress = mailAddress;
    }

    /**
     * @return the nendo
     */
    public String getNendo() {
        return nendo;
    }

    /**
     * @param nendo the nendo to set
     */
    public void setNendo(String nendo) {
        this.nendo = nendo;
    }

    /**
     * @return the moshikomishaId
     */
    public String getMoshikomishaId() {
        return moshikomishaId;
    }

    /**
     * @param moshikomishaId the moshikomishaId to set
     */
    public void setMoshikomishaId(String moshikomishaId) {
        this.moshikomishaId = moshikomishaId;
    }

}
