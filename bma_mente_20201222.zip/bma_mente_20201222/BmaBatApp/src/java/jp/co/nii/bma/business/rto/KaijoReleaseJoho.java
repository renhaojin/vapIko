package jp.co.nii.bma.business.rto;

/**
 *
 * @author nii19042
 */
public class KaijoReleaseJoho {

    // �N�x
    private String nendo;
    // ��t�ԍ�
    private String uketsukeNo;
    // �����u�K��R�[�h
    private String sknKsuCode;
    // ��ʃR�[�h
    private String shubetsuCode;
    // �񐔃R�[�h
    private String kaisuCode;
    // ���ID1
    private String kaijoId;
    // �J�Òn�R�[�h1
    private String kaisaichiCode;
    // ���R�[�h1
    private String kaijoCode;
    
    /**
     * �R���X�g���N�^
     */
    public KaijoReleaseJoho() {
        clearInfo();
    }
    
    /**
     * ���������\�b�h
     */
    public void clearInfo() {
        setNendo("");
        setUketsukeNo("");
        setSknKsuCode("");
        setShubetsuCode("");
        setKaisuCode("");
        setKaijoId("");
        setKaisaichiCode("");
        setKaijoCode("");
    }

    /**
     * @return the nendo
     */
    public String getNendo() {
        return nendo;
    }

    /**
     * @param nendo the nendo to set
     */
    public void setNendo(String nendo) {
        this.nendo = nendo;
    }

    /**
     * @return the uketsukeNo
     */
    public String getUketsukeNo() {
        return uketsukeNo;
    }

    /**
     * @param uketsukeNo the uketsukeNo to set
     */
    public void setUketsukeNo(String uketsukeNo) {
        this.uketsukeNo = uketsukeNo;
    }

    /**
     * @return the sknKsuCode
     */
    public String getSknKsuCode() {
        return sknKsuCode;
    }

    /**
     * @param sknKsuCode the sknKsuCode to set
     */
    public void setSknKsuCode(String sknKsuCode) {
        this.sknKsuCode = sknKsuCode;
    }

    /**
     * @return the shubetsuCode
     */
    public String getShubetsuCode() {
        return shubetsuCode;
    }

    /**
     * @param shubetsuCode the shubetsuCode to set
     */
    public void setShubetsuCode(String shubetsuCode) {
        this.shubetsuCode = shubetsuCode;
    }

    /**
     * @return the kaisuCode
     */
    public String getKaisuCode() {
        return kaisuCode;
    }

    /**
     * @param kaisuCode the kaisuCode to set
     */
    public void setKaisuCode(String kaisuCode) {
        this.kaisuCode = kaisuCode;
    }

    /**
     * @return the kaijoId
     */
    public String getKaijoId() {
        return kaijoId;
    }

    /**
     * @param kaijoId the kaijoId to set
     */
    public void setKaijoId(String kaijoId) {
        this.kaijoId = kaijoId;
    }

    /**
     * @return the kaisaichiCode
     */
    public String getKaisaichiCode() {
        return kaisaichiCode;
    }

    /**
     * @param kaisaichiCode the kaisaichiCode to set
     */
    public void setKaisaichiCode(String kaisaichiCode) {
        this.kaisaichiCode = kaisaichiCode;
    }

    /**
     * @return the kaijoCode
     */
    public String getKaijoCode() {
        return kaijoCode;
    }

    /**
     * @param kaijoCode the kaijoCode to set
     */
    public void setKaijoCode(String kaijoCode) {
        this.kaijoCode = kaijoCode;
    }
}
