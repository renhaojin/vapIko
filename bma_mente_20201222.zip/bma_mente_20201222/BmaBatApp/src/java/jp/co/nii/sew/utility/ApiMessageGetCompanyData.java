package jp.co.nii.sew.utility;

/**
 *
 * @author n-machida
 */
public class ApiMessageGetCompanyData {

    private String userId;
    private String userSecret;
    private String resourceServerUrl;

    private String companyCode;

    public String getResourceServerUrl() {
        return resourceServerUrl;
    }

    public void setResourceServerUrl(String resourceServerUrl) {
        this.resourceServerUrl = resourceServerUrl;
    }

    /**
     * @return the userId
     */
    public String getUserId() {
        return userId;
    }

    /**
     * @param userId the userId to set
     */
    public void setUserId(String userId) {
        this.userId = userId;
    }

    /**
     * @return the userSecret
     */
    public String getUserSecret() {
        return userSecret;
    }

    /**
     * @param userSecret the userSecret to set
     */
    public void setUserSecret(String userSecret) {
        this.userSecret = userSecret;
    }

    /**
     * @return the companyCode
     */
    public String getCompanyCode() {
        return companyCode;
    }

    /**
     * @param companyCode the companyCode to set
     */
    public void setCompanyCode(String companyCode) {
        this.companyCode = companyCode;
    }

    /**
     * ����Ǘ��ʐM���O�e�[�u���̃��b�Z�[�W�p�������Ԃ��B
     *
     * @return the vaues of properties
     */
    public String getMessageString() {
        return "userid=" + userId
                + ", usersecret=" + userSecret
                + ", company_code=" + companyCode;
    }
}
