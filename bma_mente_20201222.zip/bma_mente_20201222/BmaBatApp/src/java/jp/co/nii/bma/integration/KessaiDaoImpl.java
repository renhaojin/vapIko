package jp.co.nii.bma.integration;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import jp.co.nii.bma.business.domain.Kessai;
import jp.co.nii.bma.business.domain.KessaiDao;
import jp.co.nii.bma.business.domain.MoshikomiDao;
import jp.co.nii.bma.business.domain.ScheduleDao;
import jp.co.nii.bma.business.domain.TorokushaDao;
import jp.co.nii.bma.business.rto.KessaiTokusokuJoho;
import jp.co.nii.bma.business.service.common.BmaConstants;
import jp.co.nii.sew.business.domain.NoSuchDataException;
import jp.co.nii.sew.business.service.transaction.TransactionUtility;
import jp.co.nii.sew.common.LogGenerate;
import static jp.co.nii.sew.integration.AbstractDao.getSchemaName;
import jp.co.nii.sew.integration.SQLStateSQLExceptionTranslater;

/**
 * ���� DAO�����N���X
 *
 * @author DB�Ǘ��c�[��
 */
public class KessaiDaoImpl extends GeneratedKessaiDaoImpl implements KessaiDao {

    /**
     * �C���X�^���X�𐶐�����B
     *
     * @param datasource �f�[�^�\�[�X��
     */
    public KessaiDaoImpl(String datasource) {
        super(datasource);
    }

    /**
     * ���ϓ����[�����M�Ώێ҈ꗗ���擾����B
     *
     * @param kojinDantaiKbn �l:1 �c�́F2
     * @return ���ϓ����[�����M�Ώێ҃��X�g
     */
    public List<KessaiTokusokuJoho> searchKessaiTokusokuTaishoshaList(String kojinDantaiKbn) {
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = "";
        List<KessaiTokusokuJoho> kessaiTokusokuJohoList = new ArrayList<>();

        try {
            con = getConnection();
            sql = "SELECT DISTINCT "
                    + "sknksuMst.SKN_KSU_NAME"
                    + "," + getSQLForDecryptByUTF8("SHIMEI")
                    + ",kessai.UKETSUKE_NO"
                    + ",kessai.KESSAI_KIGEN_BI"
                    + ",kessai.KESSAI_HOHO_KBN as KESSAI_HOHO_KBN_CODE"
                    + ",kessaiHohoKbnName.HANYO_CHI as KESSAI_HOHO_KBN"
                    + ",kessai.KESSAI_KINGAKU_TOTAL"
                    + ",kessaiCvsShubetsuName.HANYO_CHI as KESSAI_CONVENIENCE_SHUBETSU"
                    + ",kessai.KESSAI_CONVENIENCE_HARAIKOMI_NO"
                    + ",kessai.KESSAI_SHUNO_KIKAN_NO"
                    + ",kessai.KESSAI_OKYAKUSAMA_NO"
                    + ",kessai.KESSAI_KAKUNIN_NO"
                    + "," + getSQLForDecryptByUTF8("MAIL_ADDRESS")
                    + ",kessai.NENDO"
                    + ",torokusha.MOSHIKOMISHA_ID as MOSHIKOMISHA_ID"
                    + " FROM " + getSchemaName() + "." + KessaiDao.TABLE_NAME + " AS kessai"
                    + " INNER JOIN " + getSchemaName() + "." + MoshikomiDao.TABLE_NAME + " as moshikomi"
                    + " ON " + "kessai.NENDO  =  moshikomi.NENDO "
                    + " AND " + "kessai.UKETSUKE_NO  =  moshikomi.UKETSUKE_NO "
                    + " INNER JOIN " + getSchemaName() + "." + TorokushaDao.TABLE_NAME + " AS torokusha";
            if (Objects.equals(BmaConstants.PRIVATE, kojinDantaiKbn)) {
                sql = sql + " ON " + "moshikomi.MOSHIKOMISHA_ID  =  torokusha.MOSHIKOMISHA_ID ";
            } else {
                sql = sql + " ON " + "moshikomi.TOROKU_USER_ID  =  torokusha.MOSHIKOMISHA_ID ";
            }
            sql = sql
                    + " INNER JOIN " + getSchemaName() + "." + BmaConstants.SKNKSU_MST + " as sknksuMst"
                    + " ON " + "moshikomi.SKN_KSU_CODE  =  sknksuMst.SKN_KSU_CODE "
                    + " AND " + "moshikomi.SHUBETSU_CODE  =  sknksuMst.SHUBETSU_CODE "
                    + " AND " + "moshikomi.KAISU_CODE  =  sknksuMst.KAISU_CODE "
                    + " LEFT JOIN " + getSchemaName() + "." + BmaConstants.MEISHO_KANRI + " as kessaiHohoKbnName"
                    + " ON " + "kessai.KESSAI_HOHO_KBN  =  kessaiHohoKbnName.HANYO_CODE "
                    + " AND " + "kessaiHohoKbnName.GROUP_CODE  =  'KESSAI_HOHO_KBN' "
                    + " LEFT JOIN " + getSchemaName() + "." + BmaConstants.MEISHO_KANRI + " as kessaiCvsShubetsuName"
                    + " ON " + "kessai.KESSAI_CONVENIENCE_SHUBETSU  =  kessaiCvsShubetsuName.HANYO_CODE "
                    + " AND " + "kessaiCvsShubetsuName.GROUP_CODE  =  'KESSAI_CONVENIENCE_SHUBETSU' "
                    + " INNER JOIN " + getSchemaName() + "." + ScheduleDao.TABLE_NAME + " AS beforeDays1 "
                    + " ON " + "moshikomi.SKN_KSU_CODE  =  beforeDays1.SKN_KSU_CODE "
                    + " AND " + "moshikomi.SHUBETSU_CODE  =  beforeDays1.SHUBETSU_CODE "
                    + " AND " + "moshikomi.KAISU_CODE  =  beforeDays1.KAISU_CODE "
                    + " AND " + "beforeDays1.SCHEDULE_CODE  =  '" + BmaConstants.SCHEDULE_CODE_22 + "'"
                    + " AND " + "beforeDays1.SCHEDULE_KBN  =  '" + BmaConstants.SCHEDULE_KBN_NISSU + "'"
                    + " INNER JOIN " + getSchemaName() + "." + ScheduleDao.TABLE_NAME + " AS beforeDays2 "
                    + " ON " + "moshikomi.SKN_KSU_CODE  =  beforeDays2.SKN_KSU_CODE "
                    + " AND " + "moshikomi.SHUBETSU_CODE  =  beforeDays2.SHUBETSU_CODE "
                    + " AND " + "moshikomi.KAISU_CODE  =  beforeDays2.KAISU_CODE "
                    + " AND " + "beforeDays2.SCHEDULE_CODE  =  '" + BmaConstants.SCHEDULE_CODE_23 + "'"
                    + " AND " + "beforeDays2.SCHEDULE_KBN  =  '" + BmaConstants.SCHEDULE_KBN_NISSU + "'"
                    + " WHERE " + "moshikomi.KOJIN_DANTAI_KBN = ?"
                    + " AND " + "moshikomi.MOSHIKOMI_KBN = '1'"
                    + " AND " + "kessai.KESSAI_JOKYO_KBN = '2'"
                    + " AND " + "kessai.KESSAI_HOHO_KBN IN ('2', '3') "
                    + " AND " + "torokusha.RONRI_SAKUJO_FLG  = '0' "
                    + " AND " + "moshikomi.RONRI_SAKUJO_FLG  = '0' "
                    + " AND " + "kessai.RONRI_SAKUJO_FLG  = '0' "
                    + " AND " + "((to_date(kessai.KESSAI_KIGEN_BI, 'YYYYMMDD') - CURRENT_DATE) = cast(beforeDays1.NISSU as numeric) OR "
                    + "(to_date(kessai.KESSAI_KIGEN_BI, 'YYYYMMDD') - CURRENT_DATE) = cast(beforeDays2.NISSU as numeric))";
            stmt = con.prepareStatement(sql);
            int i = 1;
            stmt.setString(i++, kojinDantaiKbn);
            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();

            while (rs.next()) {
                KessaiTokusokuJoho kessaiTokusokuJoho = new KessaiTokusokuJoho();
                kessaiTokusokuJoho.setSknKsuName(rs.getString("SKN_KSU_NAME"));
                kessaiTokusokuJoho.setShimei(rs.getString("SHIMEI"));
                kessaiTokusokuJoho.setUketsukeNo(rs.getString("UKETSUKE_NO"));
                kessaiTokusokuJoho.setKessaiKigenBi(rs.getString("KESSAI_KIGEN_BI"));
                kessaiTokusokuJoho.setKessaiHohoKbnCode(rs.getString("KESSAI_HOHO_KBN_CODE"));
                kessaiTokusokuJoho.setKessaiHohoKbn(rs.getString("KESSAI_HOHO_KBN"));
                kessaiTokusokuJoho.setKessaiKingakuTotal(rs.getString("KESSAI_KINGAKU_TOTAL"));

                kessaiTokusokuJoho.setKessaiConvenienceShubetsu(rs.getString("KESSAI_CONVENIENCE_SHUBETSU"));
                kessaiTokusokuJoho.setKessaiConvenienceHaraikomiNo(rs.getString("KESSAI_CONVENIENCE_HARAIKOMI_NO"));

                kessaiTokusokuJoho.setKessaiShunoKikanNo(rs.getString("KESSAI_SHUNO_KIKAN_NO"));
                kessaiTokusokuJoho.setKessaiOkyakusamaNo(rs.getString("KESSAI_OKYAKUSAMA_NO"));
                kessaiTokusokuJoho.setKessaiKakuninNo(rs.getString("KESSAI_KAKUNIN_NO"));

                kessaiTokusokuJoho.setMailAddress(rs.getString("MAIL_ADDRESS"));
                kessaiTokusokuJoho.setNendo(rs.getString("NENDO"));
                kessaiTokusokuJoho.setMoshikomishaId(rs.getString("MOSHIKOMISHA_ID"));

                kessaiTokusokuJohoList.add(kessaiTokusokuJoho);
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return kessaiTokusokuJohoList;
    }

    /**
     * ���ϓ����[�����M�t���O���X�V����B
     *
     * @param bo
     */
    public void updateKessai(Kessai bo) {
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = "";
        int ret;
        try {
            con = getConnection();
            //�Ώۃ��R�[�h�Ƀ��b�N��������
            sql = "SELECT KESSAI"
                    + " FROM " + getSchemaName() + "." + TABLE_NAME + " AS kessai"
                    + " WHERE NENDO = '" + bo.getNendo() + "'"
                    + " AND   UKETSUKE_NO = '" + bo.getUketsukeNo() + "'";

            stmt = con.prepareStatement(sql + TransactionUtility.LOCK_WAIT);

            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();

            if (rs.next()) {
                sql = "UPDATE " + getSchemaName() + "." + TABLE_NAME + " SET"
                        + " KESSAI_TOKUSOKU_MAIL_SOSHIN_FLG = cast((to_number(KESSAI_TOKUSOKU_MAIL_SOSHIN_FLG,'999') + 1) as  character varying)"
                        + ",KOSHIN_KBN = ?"
                        + ",KOSHIN_DATE = ?"
                        + ",KOSHIN_TIME = ?"
                        + ",KOSHIN_USER_ID = ?"
                        + " WHERE NENDO = '" + bo.getNendo() + "'"
                        + " AND   UKETSUKE_NO = '" + bo.getUketsukeNo() + "'";

                stmt = con.prepareStatement(sql);
                int i = 1;
                stmt.setString(i++, bo.getKoshinKbn());
                stmt.setString(i++, bo.getKoshinDate());
                stmt.setString(i++, bo.getKoshinTime());
                stmt.setString(i++, bo.getKoshinUserId());

                LogGenerate.debugOutput(getSql(stmt));
                if (stmt.executeUpdate() == 0) {
                    throw new NoSuchDataException(getSql(stmt));
                }
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
    }

    /**
     * ��ꃊ���[�X�Ώۂ�_���폜����B
     *
     * @param bo
     */
    public Boolean updateRonriSakujoFlg(Kessai bo) {
        Connection con = null;
        PreparedStatement stmt = null;
        String sql = "";
        try {
            con = getConnection();
          
            sql = "UPDATE " + getSchemaName() + "." + TABLE_NAME + " SET"
                    + " RONRI_SAKUJO_FLG = ?"
                    + ",KOSHIN_KBN = ?"
                    + ",KOSHIN_DATE = ?"
                    + ",KOSHIN_TIME = ?"
                    + ",KOSHIN_USER_ID = ?"
                    + " WHERE NENDO = '" + bo.getNendo() + "'"
                    + " AND   UKETSUKE_NO = '" + bo.getUketsukeNo() + "'";

            stmt = con.prepareStatement(sql);
            int i = 1;
            stmt.setString(i++, BmaConstants.FLG_ON);
            stmt.setString(i++, bo.getKoshinKbn());
            stmt.setString(i++, bo.getKoshinDate());
            stmt.setString(i++, bo.getKoshinTime());
            stmt.setString(i++, bo.getKoshinUserId());

            LogGenerate.debugOutput(getSql(stmt));
            if (stmt.executeUpdate() == 0) {
                return false;
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt);
        }
        return true;
    }
}
