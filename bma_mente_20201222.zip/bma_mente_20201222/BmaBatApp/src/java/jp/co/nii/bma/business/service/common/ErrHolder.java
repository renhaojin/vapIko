package jp.co.nii.bma.business.service.common;

import java.io.Serializable;

public class ErrHolder
    implements Serializable
{
    private String errCode;
    private String errInfo;

    public ErrHolder()
    {
    }
    
    public String getErrCode()
    {
        return errCode;
    }

    public String getErrInfo()
    {
        return errInfo;
    }

    public void setErrCode(String errCode)
    {
        this.errCode = errCode;
    }

    public void setErrInfo(String errInfo)
    {
        this.errInfo = errInfo;
    }

}