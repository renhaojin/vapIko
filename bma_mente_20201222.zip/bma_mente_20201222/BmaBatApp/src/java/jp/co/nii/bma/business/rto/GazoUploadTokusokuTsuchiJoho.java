package jp.co.nii.bma.business.rto;

/**
 *
 * �^�C�g��: �摜�A�b�v���[�h���ʒm�i�c�́j ���쌠: Copyright (c) 2020 ��Ж�: ���{���Y�Ɗ������
 */
public class GazoUploadTokusokuTsuchiJoho {
    private String sknKsuName;
    private String gazoKbn;
    private String shimei;
    private String mailAddress;
    private String gazoIdx;
    private String moshikomishaId;
    private String soshinFlg;

    /**
     * @return the sknKsuName
     */
    public String getSknKsuName() {
        return sknKsuName;
    }

    /**
     * @param sknKsuName the sknKsuName to set
     */
    public void setSknKsuName(String sknKsuName) {
        this.sknKsuName = sknKsuName;
    }

    /**
     * @return the gazoKbn
     */
    public String getGazoKbn() {
        return gazoKbn;
    }

    /**
     * @param gazoKbn the gazoKbn to set
     */
    public void setGazoKbn(String gazoKbn) {
        this.gazoKbn = gazoKbn;
    }

    /**
     * @return the shimei
     */
    public String getShimei() {
        return shimei;
    }

    /**
     * @param shimei the shimei to set
     */
    public void setShimei(String shimei) {
        this.shimei = shimei;
    }

    /**
     * @return the mailAddress
     */
    public String getMailAddress() {
        return mailAddress;
    }

    /**
     * @param mailAddress the mailAddress to set
     */
    public void setMailAddress(String mailAddress) {
        this.mailAddress = mailAddress;
    }

    /**
     * @return the gazoIdx
     */
    public String getGazoIdx() {
        return gazoIdx;
    }

    /**
     * @param gazoIdx the gazoIdx to set
     */
    public void setGazoIdx(String gazoIdx) {
        this.gazoIdx = gazoIdx;
    }

    /**
     * @return the moshikomishaId
     */
    public String getMoshikomishaId() {
        return moshikomishaId;
    }

    /**
     * @param moshikomishaId the moshikomishaId to set
     */
    public void setMoshikomishaId(String moshikomishaId) {
        this.moshikomishaId = moshikomishaId;
    }
    
    /**
     * ���������\�b�h
     */
    private void clearInfo() {
        setSknKsuName("");
        setGazoKbn("");
        setShimei("");
        setMailAddress("");
        setGazoIdx("");
        setMoshikomishaId("");
        setSoshinFlg("");
    }

    /**
     * @return the soshinFlg
     */
    public String getSoshinFlg() {
        return soshinFlg;
    }

    /**
     * @param soshinFlg the soshinFlg to set
     */
    public void setSoshinFlg(String soshinFlg) {
        this.soshinFlg = soshinFlg;
    }
}
