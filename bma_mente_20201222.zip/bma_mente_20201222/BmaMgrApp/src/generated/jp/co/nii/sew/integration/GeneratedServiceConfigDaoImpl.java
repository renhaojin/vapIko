package jp.co.nii.sew.integration;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import jp.co.nii.sew.business.domain.NoSuchDataException;
import jp.co.nii.sew.common.LogGenerate;
import jp.co.nii.sew.integration.AbstractDao;
import jp.co.nii.sew.integration.SQLStateSQLExceptionTranslater;

import jp.co.nii.sew.business.domain.GeneratedServiceConfig;
import jp.co.nii.sew.business.domain.GeneratedServiceConfigDao;

/**
 * �������ꂽ �T�[�r�X�ݒ� DAO�����N���X<br>
 * table-design-ver 1
 * @author DB�Ǘ��c�[��
 */
abstract class GeneratedServiceConfigDaoImpl extends AbstractConfigDao implements GeneratedServiceConfigDao {

    /**
     * �e�[�u���J�������̃J���}��؂蕶����B<br>
     * SQL���̍쐬�ɗp����B
     */
    protected static final String FIELDS = "REQUEST_URL"
            + ",SERVICE"
            + ",TRANSFER_OBJECT"
            + ",SESSION_MODE"
            + ",TRANSACTION_TOKEN_MODE"
            + ",KOSHIN_KBN"
            + ",TOROKU_DATE"
            + ",TOROKU_TIME"
            + ",TOROKU_USER_ID"
            + ",KOSHIN_DATE"
            + ",KOSHIN_TIME"
            + ",KOSHIN_USER_ID"
            + ",RONRI_SAKUJO_FLG";

    /**
     * �e�[�u���J�������̃J���}��؂蕶����B<br>
     *  �Í����Ώۍ��ڂ𕡍�����SQL���̍쐬�ɗp����B
     */
    protected static final String FIELDS_DECRYPT = "REQUEST_URL"
            + "," + "SERVICE"
            + "," + "TRANSFER_OBJECT"
            + "," + "SESSION_MODE"
            + "," + "TRANSACTION_TOKEN_MODE"
            + "," + "KOSHIN_KBN"
            + "," + "TOROKU_DATE"
            + "," + "TOROKU_TIME"
            + "," + "TOROKU_USER_ID"
            + "," + "KOSHIN_DATE"
            + "," + "KOSHIN_TIME"
            + "," + "KOSHIN_USER_ID"
            + "," + "RONRI_SAKUJO_FLG";

    /**
     * �C���X�^���X�𐶐�����B<br>
     * �f�[�^�\�[�X������
     * @param datasource �f�[�^�\�[�X��
     */
    public GeneratedServiceConfigDaoImpl(String datasource) {
        super(datasource);
    }

    /* (non-Javadoc)
     * @see jp.co.nii.bma.business.domain.GeneratedServiceConfigDao#create(jp.co.nii.bma.business.domain.GeneratedServiceConfig)
     */
    @Override
    public void create(GeneratedServiceConfig bo) {
        Connection con = null;
        PreparedStatement stmt = null;
        String sql = "";
        try {
            con = getConnection();
            sql = "INSERT INTO " + getSchemaName() + "." + TABLE_NAME + " ( "
                    + FIELDS
                    + " ) VALUES ("
                    + " ?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + " )";

            stmt = con.prepareStatement(sql);
            int i = 1;
            stmt.setString(i++, bo.getRequestUrl());
            stmt.setString(i++, bo.getService());
            stmt.setString(i++, bo.getTransferObject());
            stmt.setString(i++, bo.getSessionMode());
            stmt.setString(i++, bo.getTransactionTokenMode());
            stmt.setString(i++, bo.getKoshinKbn());
            stmt.setString(i++, bo.getTorokuDate());
            stmt.setString(i++, bo.getTorokuTime());
            stmt.setString(i++, bo.getTorokuUserId());
            stmt.setString(i++, bo.getKoshinDate());
            stmt.setString(i++, bo.getKoshinTime());
            stmt.setString(i++, bo.getKoshinUserId());
            stmt.setString(i++, bo.getRonriSakujoFlg());

            LogGenerate.debugOutput(getSql(stmt));
            stmt.executeUpdate();
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt);
        }
    }

    /* (non-Javadoc)
     * @see jp.co.nii.bma.business.domain.GeneratedServiceConfigDao#find(jp.co.nii.bma.business.domain.GeneratedServiceConfig, java.lang.String)
     */
    @Override
    public GeneratedServiceConfig find(GeneratedServiceConfig bo, String lockMode) {
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs =null;
        String sql = "";
        try {
            con = getConnection();
            sql = "SELECT " + FIELDS_DECRYPT
                    + " FROM " + getSchemaName() + "." + TABLE_NAME
                    + " WHERE"
                    + " REQUEST_URL = ?";

            stmt = con.prepareStatement(sql + lockMode);
            int i = 1;
            stmt.setString(i++, bo.getRequestUrl());

            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();
            if (rs.next()) {
                setBoFromResultSet(bo, rs);
            } else {
                bo = null;
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return bo;
    }

    /* (non-Javadoc)
     * @see jp.co.nii.bma.business.domain.GeneratedServiceConfigDao#update(jp.co.nii.bma.business.domain.GeneratedServiceConfig)
     */
    @Override
    public void update(GeneratedServiceConfig bo) {
        Connection con = null;
        PreparedStatement stmt = null;
        String sql = "";
        try {
            con = getConnection();
            sql = "UPDATE " + getSchemaName() + "." + TABLE_NAME + " SET"
                    + " SERVICE = ?"
                    + ",TRANSFER_OBJECT = ?"
                    + ",SESSION_MODE = ?"
                    + ",TRANSACTION_TOKEN_MODE = ?"
                    + ",KOSHIN_KBN = ?"
                    + ",TOROKU_DATE = ?"
                    + ",TOROKU_TIME = ?"
                    + ",TOROKU_USER_ID = ?"
                    + ",KOSHIN_DATE = ?"
                    + ",KOSHIN_TIME = ?"
                    + ",KOSHIN_USER_ID = ?"
                    + ",RONRI_SAKUJO_FLG = ?"
                    + " WHERE"
                    + " REQUEST_URL = ?";

            stmt = con.prepareStatement(sql);
            int i = 1;
            stmt.setString(i++, bo.getService());
            stmt.setString(i++, bo.getTransferObject());
            stmt.setString(i++, bo.getSessionMode());
            stmt.setString(i++, bo.getTransactionTokenMode());
            stmt.setString(i++, bo.getKoshinKbn());
            stmt.setString(i++, bo.getTorokuDate());
            stmt.setString(i++, bo.getTorokuTime());
            stmt.setString(i++, bo.getTorokuUserId());
            stmt.setString(i++, bo.getKoshinDate());
            stmt.setString(i++, bo.getKoshinTime());
            stmt.setString(i++, bo.getKoshinUserId());
            stmt.setString(i++, bo.getRonriSakujoFlg());

            stmt.setString(i++, bo.getRequestUrl());

            LogGenerate.debugOutput(getSql(stmt));
            if (stmt.executeUpdate() == 0) {
                throw new NoSuchDataException(getSql(stmt));
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt);
        }
    }

    /* (non-Javadoc)
     * @see jp.co.nii.bma.business.domain.GeneratedServiceConfigDao#remove(jp.co.nii.bma.business.domain.GeneratedServiceConfig)
     */
    @Override
    public void remove(GeneratedServiceConfig bo) {
        Connection con = null;
        PreparedStatement stmt = null;
        String sql = "";
        try {
            con = getConnection();
            sql = "DELETE FROM " + getSchemaName() + "." + TABLE_NAME
                    + " WHERE"
                    + " REQUEST_URL = ?";

            stmt = con.prepareStatement(sql);
            int i = 1;
            stmt.setString(i++, bo.getRequestUrl());

            LogGenerate.debugOutput(getSql(stmt));
            if (stmt.executeUpdate() == 0) {
                throw new NoSuchDataException(getSql(stmt));
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt);
        }
    }

    /**
     * �������ʂł���ResultSet��BusinessObject�֋l�ߑւ���B<br>
     * ���O�����F������bo��rs��null�łȂ����ƁB
     *
     * @param bo BusinessObject�̃C���X�^���X
     * @param rs �������ʂ�ResultSet
     */
    protected void setBoFromResultSet(GeneratedServiceConfig bo, ResultSet rs) {
        try {
            bo.setRequestUrl(rs.getString("REQUEST_URL"));
            bo.setService(rs.getString("SERVICE"));
            bo.setTransferObject(rs.getString("TRANSFER_OBJECT"));
            bo.setSessionMode(rs.getString("SESSION_MODE"));
            bo.setTransactionTokenMode(rs.getString("TRANSACTION_TOKEN_MODE"));
            bo.setKoshinKbn(rs.getString("KOSHIN_KBN"));
            bo.setTorokuDate(rs.getString("TOROKU_DATE"));
            bo.setTorokuTime(rs.getString("TOROKU_TIME"));
            bo.setTorokuUserId(rs.getString("TOROKU_USER_ID"));
            bo.setKoshinDate(rs.getString("KOSHIN_DATE"));
            bo.setKoshinTime(rs.getString("KOSHIN_TIME"));
            bo.setKoshinUserId(rs.getString("KOSHIN_USER_ID"));
            bo.setRonriSakujoFlg(rs.getString("RONRI_SAKUJO_FLG"));
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(null, ex);
        }
    }
}
