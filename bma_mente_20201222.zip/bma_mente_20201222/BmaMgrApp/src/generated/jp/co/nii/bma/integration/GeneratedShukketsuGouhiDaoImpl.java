//package jp.co.nii.bma.integration;
//
//import java.sql.Connection;
//import java.sql.PreparedStatement;
//import java.sql.ResultSet;
//import java.sql.SQLException;
//
//import jp.co.nii.sew.business.domain.NoSuchDataException;
//import jp.co.nii.sew.common.LogGenerate;
//import jp.co.nii.sew.integration.AbstractDao;
//import jp.co.nii.sew.integration.SQLStateSQLExceptionTranslater;
//
//import jp.co.nii.bma.business.domain.GeneratedShukketsuGouhi;
//import jp.co.nii.bma.business.domain.GeneratedShukketsuGouhiDao;
//
///**
// * �������ꂽ �o������ DAO�����N���X<br>
// * table-design-ver 2
// * @author DB�Ǘ��c�[��
// */
//abstract class GeneratedShukketsuGouhiDaoImpl extends AbstractDao implements GeneratedShukketsuGouhiDao {
//
//    /**
//     * �e�[�u���J�������̃J���}��؂蕶����B<br>
//     * SQL���̍쐬�ɗp����B
//     */
//    protected static final String FIELDS = "UKETSUKE_NO"
//            + ",NITTEI"
//            + ",KAMOKU_CODE"
//            + ",JITEI_CODE"
//            + ",SHUKKETSU_KBN"
//            + ",GOUHI_KBN"
//            + ",TENSU"
//            + ",KAISHI_DATE"
//            + ",KAISHI_TIME"
//            + ",KANRYO_DATE"
//            + ",KANRYO_TIME"
//            + ",TOKUSOKU_MAIL_SOSHIN_KBN"
//            + ",KOSHIN_KBN"
//            + ",TOROKU_DATE"
//            + ",TOROKU_TIME"
//            + ",TOROKU_USER_ID"
//            + ",KOSHIN_DATE"
//            + ",KOSHIN_TIME"
//            + ",KOSHIN_USER_ID"
//            + ",RONRI_SAKUJO_FLG";
//
//    /**
//     * �e�[�u���J�������̃J���}��؂蕶����B<br>
//     *  �Í����Ώۍ��ڂ𕡍�����SQL���̍쐬�ɗp����B
//     */
//    protected static final String FIELDS_DECRYPT = "UKETSUKE_NO"
//            + "," + "NITTEI"
//            + "," + "KAMOKU_CODE"
//            + "," + "JITEI_CODE"
//            + "," + "SHUKKETSU_KBN"
//            + "," + "GOUHI_KBN"
//            + "," + "TENSU"
//            + "," + "KAISHI_DATE"
//            + "," + "KAISHI_TIME"
//            + "," + "KANRYO_DATE"
//            + "," + "KANRYO_TIME"
//            + "," + "TOKUSOKU_MAIL_SOSHIN_KBN"
//            + "," + "KOSHIN_KBN"
//            + "," + "TOROKU_DATE"
//            + "," + "TOROKU_TIME"
//            + "," + "TOROKU_USER_ID"
//            + "," + "KOSHIN_DATE"
//            + "," + "KOSHIN_TIME"
//            + "," + "KOSHIN_USER_ID"
//            + "," + "RONRI_SAKUJO_FLG";
//
//    /**
//     * �C���X�^���X�𐶐�����B<br>
//     * �f�[�^�\�[�X������
//     * @param datasource �f�[�^�\�[�X��
//     */
//    public GeneratedShukketsuGouhiDaoImpl(String datasource) {
//        super(datasource);
//    }
//
//    /* (non-Javadoc)
//     * @see jp.co.nii.bma.business.domain.GeneratedShukketsuGouhiDao#create(jp.co.nii.bma.business.domain.GeneratedShukketsuGouhi)
//     */
//    @Override
//    public void create(GeneratedShukketsuGouhi bo) {
//        Connection con = null;
//        PreparedStatement stmt = null;
//        String sql = "";
//        try {
//            con = getConnection();
//            sql = "INSERT INTO " + getSchemaName() + "." + TABLE_NAME + " ( "
//                    + FIELDS
//                    + " ) VALUES ("
//                    + " ?"
//                    + ",?"
//                    + ",?"
//                    + ",?"
//                    + ",?"
//                    + ",?"
//                    + ",?"
//                    + ",?"
//                    + ",?"
//                    + ",?"
//                    + ",?"
//                    + ",?"
//                    + ",?"
//                    + ",?"
//                    + ",?"
//                    + ",?"
//                    + ",?"
//                    + ",?"
//                    + ",?"
//                    + ",?"
//                    + " )";
//
//            stmt = con.prepareStatement(sql);
//            int i = 1;
//            stmt.setString(i++, bo.getUketsukeNo());
//            stmt.setString(i++, bo.getNittei());
//            stmt.setString(i++, bo.getKamokuCode());
//            stmt.setString(i++, bo.getJiteiCode());
//            stmt.setString(i++, bo.getShukketsuKbn());
//            stmt.setString(i++, bo.getGouhiKbn());
//            stmt.setString(i++, bo.getTensu());
//            stmt.setString(i++, bo.getKaishiDate());
//            stmt.setString(i++, bo.getKaishiTime());
//            stmt.setString(i++, bo.getKanryoDate());
//            stmt.setString(i++, bo.getKanryoTime());
//            stmt.setString(i++, bo.getTokusokuMailSoshinKbn());
//            stmt.setString(i++, bo.getKoshinKbn());
//            stmt.setString(i++, bo.getTorokuDate());
//            stmt.setString(i++, bo.getTorokuTime());
//            stmt.setString(i++, bo.getTorokuUserId());
//            stmt.setString(i++, bo.getKoshinDate());
//            stmt.setString(i++, bo.getKoshinTime());
//            stmt.setString(i++, bo.getKoshinUserId());
//            stmt.setString(i++, bo.getRonriSakujoFlg());
//
//            LogGenerate.debugOutput(getSql(stmt));
//            stmt.executeUpdate();
//        } catch (SQLException ex) {
//            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
//        } finally {
//            close(con, stmt);
//        }
//    }
//
//    /* (non-Javadoc)
//     * @see jp.co.nii.bma.business.domain.GeneratedShukketsuGouhiDao#find(jp.co.nii.bma.business.domain.GeneratedShukketsuGouhi, java.lang.String)
//     */
//    @Override
//    public GeneratedShukketsuGouhi find(GeneratedShukketsuGouhi bo, String lockMode) {
//        Connection con = null;
//        PreparedStatement stmt = null;
//        ResultSet rs =null;
//        String sql = "";
//        try {
//            con = getConnection();
//            sql = "SELECT " + FIELDS_DECRYPT
//                    + " FROM " + getSchemaName() + "." + TABLE_NAME
//                    + " WHERE"
//                    + " UKETSUKE_NO = ?"
//                    + " AND NITTEI = ?"
//                    + " AND KAMOKU_CODE = ?"
//                    + " AND JITEI_CODE = ?";
//
//            stmt = con.prepareStatement(sql + lockMode);
//            int i = 1;
//            stmt.setString(i++, bo.getUketsukeNo());
//            stmt.setString(i++, bo.getNittei());
//            stmt.setString(i++, bo.getKamokuCode());
//            stmt.setString(i++, bo.getJiteiCode());
//
//            LogGenerate.debugOutput(getSql(stmt));
//            rs = stmt.executeQuery();
//            if (rs.next()) {
//                setBoFromResultSet(bo, rs);
//            } else {
//                bo = null;
//            }
//        } catch (SQLException ex) {
//            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
//        } finally {
//            close(con, stmt, rs);
//        }
//        return bo;
//    }
//
//    /* (non-Javadoc)
//     * @see jp.co.nii.bma.business.domain.GeneratedShukketsuGouhiDao#update(jp.co.nii.bma.business.domain.GeneratedShukketsuGouhi)
//     */
//    @Override
//    public void update(GeneratedShukketsuGouhi bo) {
//        Connection con = null;
//        PreparedStatement stmt = null;
//        String sql = "";
//        try {
//            con = getConnection();
//            sql = "UPDATE " + getSchemaName() + "." + TABLE_NAME + " SET"
//                    + " SHUKKETSU_KBN = ?"
//                    + ",GOUHI_KBN = ?"
//                    + ",TENSU = ?"
//                    + ",KAISHI_DATE = ?"
//                    + ",KAISHI_TIME = ?"
//                    + ",KANRYO_DATE = ?"
//                    + ",KANRYO_TIME = ?"
//                    + ",TOKUSOKU_MAIL_SOSHIN_KBN = ?"
//                    + ",KOSHIN_KBN = ?"
//                    + ",TOROKU_DATE = ?"
//                    + ",TOROKU_TIME = ?"
//                    + ",TOROKU_USER_ID = ?"
//                    + ",KOSHIN_DATE = ?"
//                    + ",KOSHIN_TIME = ?"
//                    + ",KOSHIN_USER_ID = ?"
//                    + ",RONRI_SAKUJO_FLG = ?"
//                    + " WHERE"
//                    + " UKETSUKE_NO = ?"
//                    + " AND NITTEI = ?"
//                    + " AND KAMOKU_CODE = ?"
//                    + " AND JITEI_CODE = ?";
//
//            stmt = con.prepareStatement(sql);
//            int i = 1;
//            stmt.setString(i++, bo.getShukketsuKbn());
//            stmt.setString(i++, bo.getGouhiKbn());
//            stmt.setString(i++, bo.getTensu());
//            stmt.setString(i++, bo.getKaishiDate());
//            stmt.setString(i++, bo.getKaishiTime());
//            stmt.setString(i++, bo.getKanryoDate());
//            stmt.setString(i++, bo.getKanryoTime());
//            stmt.setString(i++, bo.getTokusokuMailSoshinKbn());
//            stmt.setString(i++, bo.getKoshinKbn());
//            stmt.setString(i++, bo.getTorokuDate());
//            stmt.setString(i++, bo.getTorokuTime());
//            stmt.setString(i++, bo.getTorokuUserId());
//            stmt.setString(i++, bo.getKoshinDate());
//            stmt.setString(i++, bo.getKoshinTime());
//            stmt.setString(i++, bo.getKoshinUserId());
//            stmt.setString(i++, bo.getRonriSakujoFlg());
//
//            stmt.setString(i++, bo.getUketsukeNo());
//            stmt.setString(i++, bo.getNittei());
//            stmt.setString(i++, bo.getKamokuCode());
//            stmt.setString(i++, bo.getJiteiCode());
//
//            LogGenerate.debugOutput(getSql(stmt));
//            if (stmt.executeUpdate() == 0) {
//                throw new NoSuchDataException(getSql(stmt));
//            }
//        } catch (SQLException ex) {
//            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
//        } finally {
//            close(con, stmt);
//        }
//    }
//
//    /* (non-Javadoc)
//     * @see jp.co.nii.bma.business.domain.GeneratedShukketsuGouhiDao#remove(jp.co.nii.bma.business.domain.GeneratedShukketsuGouhi)
//     */
//    @Override
//    public void remove(GeneratedShukketsuGouhi bo) {
//        Connection con = null;
//        PreparedStatement stmt = null;
//        String sql = "";
//        try {
//            con = getConnection();
//            sql = "DELETE FROM " + getSchemaName() + "." + TABLE_NAME
//                    + " WHERE"
//                    + " UKETSUKE_NO = ?"
//                    + " AND NITTEI = ?"
//                    + " AND KAMOKU_CODE = ?"
//                    + " AND JITEI_CODE = ?";
//
//            stmt = con.prepareStatement(sql);
//            int i = 1;
//            stmt.setString(i++, bo.getUketsukeNo());
//            stmt.setString(i++, bo.getNittei());
//            stmt.setString(i++, bo.getKamokuCode());
//            stmt.setString(i++, bo.getJiteiCode());
//
//            LogGenerate.debugOutput(getSql(stmt));
//            if (stmt.executeUpdate() == 0) {
//                throw new NoSuchDataException(getSql(stmt));
//            }
//        } catch (SQLException ex) {
//            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
//        } finally {
//            close(con, stmt);
//        }
//    }
//
//    /**
//     * �������ʂł���ResultSet��BusinessObject�֋l�ߑւ���B<br>
//     * ���O�����F������bo��rs��null�łȂ����ƁB
//     * 
//     * @param bo BusinessObject�̃C���X�^���X
//     * @param rs �������ʂ�ResultSet
//     */
//    protected void setBoFromResultSet(GeneratedShukketsuGouhi bo, ResultSet rs) {
//        try {
//            bo.setUketsukeNo(rs.getString("UKETSUKE_NO"));
//            bo.setNittei(rs.getString("NITTEI"));
//            bo.setKamokuCode(rs.getString("KAMOKU_CODE"));
//            bo.setJiteiCode(rs.getString("JITEI_CODE"));
//            bo.setShukketsuKbn(rs.getString("SHUKKETSU_KBN"));
//            bo.setGouhiKbn(rs.getString("GOUHI_KBN"));
//            bo.setTensu(rs.getString("TENSU"));
//            bo.setKaishiDate(rs.getString("KAISHI_DATE"));
//            bo.setKaishiTime(rs.getString("KAISHI_TIME"));
//            bo.setKanryoDate(rs.getString("KANRYO_DATE"));
//            bo.setKanryoTime(rs.getString("KANRYO_TIME"));
//            bo.setTokusokuMailSoshinKbn(rs.getString("TOKUSOKU_MAIL_SOSHIN_KBN"));
//            bo.setKoshinKbn(rs.getString("KOSHIN_KBN"));
//            bo.setTorokuDate(rs.getString("TOROKU_DATE"));
//            bo.setTorokuTime(rs.getString("TOROKU_TIME"));
//            bo.setTorokuUserId(rs.getString("TOROKU_USER_ID"));
//            bo.setKoshinDate(rs.getString("KOSHIN_DATE"));
//            bo.setKoshinTime(rs.getString("KOSHIN_TIME"));
//            bo.setKoshinUserId(rs.getString("KOSHIN_USER_ID"));
//            bo.setRonriSakujoFlg(rs.getString("RONRI_SAKUJO_FLG"));
//        } catch (SQLException ex) {
//            throw new SQLStateSQLExceptionTranslater().translate(null, ex);
//        }
//    }
//}
