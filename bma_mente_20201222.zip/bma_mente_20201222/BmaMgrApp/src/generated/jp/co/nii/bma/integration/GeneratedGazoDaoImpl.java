package jp.co.nii.bma.integration;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import jp.co.nii.sew.business.domain.NoSuchDataException;
import jp.co.nii.sew.common.LogGenerate;
import jp.co.nii.sew.integration.AbstractDao;
import jp.co.nii.sew.integration.SQLStateSQLExceptionTranslater;

import jp.co.nii.bma.business.domain.GeneratedGazo;
import jp.co.nii.bma.business.domain.GeneratedGazoDao;

/**
 * �������ꂽ �摜 DAO�����N���X<br>
 * table-design-ver 5
 * @author DB�Ǘ��c�[��
 */
abstract class GeneratedGazoDaoImpl extends AbstractDao implements GeneratedGazoDao {

    /**
     * �e�[�u���J�������̃J���}��؂蕶����B<br>
     * SQL���̍쐬�ɗp����B
     */
    protected static final String FIELDS = "GAZO_IDX"
            + ",NENDO"
            + ",UKETSUKE_NO"
            + ",GAZO_KBN"
            + ",SEQ"
            + ",HOSEI_IRAI_KBN"
            + ",GAZO_HYOJI_KBN"
            + ",HOSEI_IRAI_BI"
            + ",HOSEI_IRAI_TIME"
            + ",HOSEI_IRAI_CODE_1"
            + ",HOSEI_IRAI_CODE_2"
            + ",HOSEI_IRAI_CODE_3"
            + ",HOSEI_TAIO_BI"
            + ",HOSEI_TAIO_TIME"
            + ",HOSEI_FINISH_BI"
            + ",HOSEI_FINISH_TIME"
            + ",HOSEI_IRAI_MAIL_SOSHIN_FLG"
            + ",HOSEI_KIGEN_BI"
            + ",KOSHIN_KBN"
            + ",TOROKU_DATE"
            + ",TOROKU_TIME"
            + ",TOROKU_USER_ID"
            + ",KOSHIN_DATE"
            + ",KOSHIN_TIME"
            + ",KOSHIN_USER_ID"
            + ",RONRI_SAKUJO_FLG";

    /**
     * �e�[�u���J�������̃J���}��؂蕶����B<br>
     *  �Í����Ώۍ��ڂ𕡍�����SQL���̍쐬�ɗp����B
     */
    protected static final String FIELDS_DECRYPT = "GAZO_IDX"
            + "," + "NENDO"
            + "," + "UKETSUKE_NO"
            + "," + "GAZO_KBN"
            + "," + "SEQ"
            + "," + "HOSEI_IRAI_KBN"
            + "," + "GAZO_HYOJI_KBN"
            + "," + "HOSEI_IRAI_BI"
            + "," + "HOSEI_IRAI_TIME"
            + "," + "HOSEI_IRAI_CODE_1"
            + "," + "HOSEI_IRAI_CODE_2"
            + "," + "HOSEI_IRAI_CODE_3"
            + "," + "HOSEI_TAIO_BI"
            + "," + "HOSEI_TAIO_TIME"
            + "," + "HOSEI_FINISH_BI"
            + "," + "HOSEI_FINISH_TIME"
            + "," + "HOSEI_IRAI_MAIL_SOSHIN_FLG"
            + "," + "HOSEI_KIGEN_BI"
            + "," + "KOSHIN_KBN"
            + "," + "TOROKU_DATE"
            + "," + "TOROKU_TIME"
            + "," + "TOROKU_USER_ID"
            + "," + "KOSHIN_DATE"
            + "," + "KOSHIN_TIME"
            + "," + "KOSHIN_USER_ID"
            + "," + "RONRI_SAKUJO_FLG";

    /**
     * �C���X�^���X�𐶐�����B<br>
     * �f�[�^�\�[�X������
     * @param datasource �f�[�^�\�[�X��
     */
    public GeneratedGazoDaoImpl(String datasource) {
        super(datasource);
    }

    /* (non-Javadoc)
     * @see jp.co.nii.bma.business.domain.GeneratedGazoDao#create(jp.co.nii.bma.business.domain.GeneratedGazo)
     */
    @Override
    public void create(GeneratedGazo bo) {
        Connection con = null;
        PreparedStatement stmt = null;
        String sql = "";
        try {
            con = getConnection();
            sql = "INSERT INTO " + getSchemaName() + "." + TABLE_NAME + " ( "
                    + FIELDS
                    + " ) VALUES ("
                    + " ?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + " )";

            stmt = con.prepareStatement(sql);
            int i = 1;
            stmt.setString(i++, bo.getGazoIdx());
            stmt.setString(i++, bo.getNendo());
            stmt.setString(i++, bo.getUketsukeNo());
            stmt.setString(i++, bo.getGazoKbn());
            stmt.setString(i++, bo.getSeq());
            stmt.setString(i++, bo.getHoseiIraiKbn());
            stmt.setString(i++, bo.getGazoHyojiKbn());
            stmt.setString(i++, bo.getHoseiIraiBi());
            stmt.setString(i++, bo.getHoseiIraiTime());
            stmt.setString(i++, bo.getHoseiIraiCode1());
            stmt.setString(i++, bo.getHoseiIraiCode2());
            stmt.setString(i++, bo.getHoseiIraiCode3());
            stmt.setString(i++, bo.getHoseiTaioBi());
            stmt.setString(i++, bo.getHoseiTaioTime());
            stmt.setString(i++, bo.getHoseiFinishBi());
            stmt.setString(i++, bo.getHoseiFinishTime());
            stmt.setString(i++, bo.getHoseiIraiMailSoshinFlg());
            stmt.setString(i++, bo.getHoseiKigenBi());
            stmt.setString(i++, bo.getKoshinKbn());
            stmt.setString(i++, bo.getTorokuDate());
            stmt.setString(i++, bo.getTorokuTime());
            stmt.setString(i++, bo.getTorokuUserId());
            stmt.setString(i++, bo.getKoshinDate());
            stmt.setString(i++, bo.getKoshinTime());
            stmt.setString(i++, bo.getKoshinUserId());
            stmt.setString(i++, bo.getRonriSakujoFlg());

            LogGenerate.debugOutput(getSql(stmt));
            stmt.executeUpdate();
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt);
        }
    }

    /* (non-Javadoc)
     * @see jp.co.nii.bma.business.domain.GeneratedGazoDao#find(jp.co.nii.bma.business.domain.GeneratedGazo, java.lang.String)
     */
    @Override
    public GeneratedGazo find(GeneratedGazo bo, String lockMode) {
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs =null;
        String sql = "";
        try {
            con = getConnection();
            sql = "SELECT " + FIELDS_DECRYPT
                    + " FROM " + getSchemaName() + "." + TABLE_NAME
                    + " WHERE"
                    + " NENDO = ?"
                    + " AND UKETSUKE_NO = ?"
                    + " AND GAZO_KBN = ?"
                    + " AND SEQ = ?";

            stmt = con.prepareStatement(sql + lockMode);
            int i = 1;
            stmt.setString(i++, bo.getNendo());
            stmt.setString(i++, bo.getUketsukeNo());
            stmt.setString(i++, bo.getGazoKbn());
            stmt.setString(i++, bo.getSeq());

            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();
            if (rs.next()) {
                setBoFromResultSet(bo, rs);
            } else {
                bo = null;
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return bo;
    }

    /* (non-Javadoc)
     * @see jp.co.nii.bma.business.domain.GeneratedGazoDao#update(jp.co.nii.bma.business.domain.GeneratedGazo)
     */
    @Override
    public void update(GeneratedGazo bo) {
        Connection con = null;
        PreparedStatement stmt = null;
        String sql = "";
        try {
            con = getConnection();
            sql = "UPDATE " + getSchemaName() + "." + TABLE_NAME + " SET"
                    + " GAZO_IDX = ?"
                    + ",HOSEI_IRAI_KBN = ?"
                    + ",GAZO_HYOJI_KBN = ?"
                    + ",HOSEI_IRAI_BI = ?"
                    + ",HOSEI_IRAI_TIME = ?"
                    + ",HOSEI_IRAI_CODE_1 = ?"
                    + ",HOSEI_IRAI_CODE_2 = ?"
                    + ",HOSEI_IRAI_CODE_3 = ?"
                    + ",HOSEI_TAIO_BI = ?"
                    + ",HOSEI_TAIO_TIME = ?"
                    + ",HOSEI_FINISH_BI = ?"
                    + ",HOSEI_FINISH_TIME = ?"
                    + ",HOSEI_IRAI_MAIL_SOSHIN_FLG = ?"
                    + ",HOSEI_KIGEN_BI = ?"
                    + ",KOSHIN_KBN = ?"
                    + ",TOROKU_DATE = ?"
                    + ",TOROKU_TIME = ?"
                    + ",TOROKU_USER_ID = ?"
                    + ",KOSHIN_DATE = ?"
                    + ",KOSHIN_TIME = ?"
                    + ",KOSHIN_USER_ID = ?"
                    + ",RONRI_SAKUJO_FLG = ?"
                    + " WHERE"
                    + " NENDO = ?"
                    + " AND UKETSUKE_NO = ?"
                    + " AND GAZO_KBN = ?"
                    + " AND SEQ = ?";

            stmt = con.prepareStatement(sql);
            int i = 1;
            stmt.setString(i++, bo.getGazoIdx());
            stmt.setString(i++, bo.getHoseiIraiKbn());
            stmt.setString(i++, bo.getGazoHyojiKbn());
            stmt.setString(i++, bo.getHoseiIraiBi());
            stmt.setString(i++, bo.getHoseiIraiTime());
            stmt.setString(i++, bo.getHoseiIraiCode1());
            stmt.setString(i++, bo.getHoseiIraiCode2());
            stmt.setString(i++, bo.getHoseiIraiCode3());
            stmt.setString(i++, bo.getHoseiTaioBi());
            stmt.setString(i++, bo.getHoseiTaioTime());
            stmt.setString(i++, bo.getHoseiFinishBi());
            stmt.setString(i++, bo.getHoseiFinishTime());
            stmt.setString(i++, bo.getHoseiIraiMailSoshinFlg());
            stmt.setString(i++, bo.getHoseiKigenBi());
            stmt.setString(i++, bo.getKoshinKbn());
            stmt.setString(i++, bo.getTorokuDate());
            stmt.setString(i++, bo.getTorokuTime());
            stmt.setString(i++, bo.getTorokuUserId());
            stmt.setString(i++, bo.getKoshinDate());
            stmt.setString(i++, bo.getKoshinTime());
            stmt.setString(i++, bo.getKoshinUserId());
            stmt.setString(i++, bo.getRonriSakujoFlg());

            stmt.setString(i++, bo.getNendo());
            stmt.setString(i++, bo.getUketsukeNo());
            stmt.setString(i++, bo.getGazoKbn());
            stmt.setString(i++, bo.getSeq());

            LogGenerate.debugOutput(getSql(stmt));
            if (stmt.executeUpdate() == 0) {
                throw new NoSuchDataException(getSql(stmt));
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt);
        }
    }

    /* (non-Javadoc)
     * @see jp.co.nii.bma.business.domain.GeneratedGazoDao#remove(jp.co.nii.bma.business.domain.GeneratedGazo)
     */
    @Override
    public void remove(GeneratedGazo bo) {
        Connection con = null;
        PreparedStatement stmt = null;
        String sql = "";
        try {
            con = getConnection();
            sql = "DELETE FROM " + getSchemaName() + "." + TABLE_NAME
                    + " WHERE"
                    + " NENDO = ?"
                    + " AND UKETSUKE_NO = ?"
                    + " AND GAZO_KBN = ?"
                    + " AND SEQ = ?";

            stmt = con.prepareStatement(sql);
            int i = 1;
            stmt.setString(i++, bo.getNendo());
            stmt.setString(i++, bo.getUketsukeNo());
            stmt.setString(i++, bo.getGazoKbn());
            stmt.setString(i++, bo.getSeq());

            LogGenerate.debugOutput(getSql(stmt));
            if (stmt.executeUpdate() == 0) {
                throw new NoSuchDataException(getSql(stmt));
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt);
        }
    }

    /**
     * �������ʂł���ResultSet��BusinessObject�֋l�ߑւ���B<br>
     * ���O�����F������bo��rs��null�łȂ����ƁB
     * 
     * @param bo BusinessObject�̃C���X�^���X
     * @param rs �������ʂ�ResultSet
     */
    protected void setBoFromResultSet(GeneratedGazo bo, ResultSet rs) {
        try {
            bo.setGazoIdx(rs.getString("GAZO_IDX"));
            bo.setNendo(rs.getString("NENDO"));
            bo.setUketsukeNo(rs.getString("UKETSUKE_NO"));
            bo.setGazoKbn(rs.getString("GAZO_KBN"));
            bo.setSeq(rs.getString("SEQ"));
            bo.setHoseiIraiKbn(rs.getString("HOSEI_IRAI_KBN"));
            bo.setGazoHyojiKbn(rs.getString("GAZO_HYOJI_KBN"));
            bo.setHoseiIraiBi(rs.getString("HOSEI_IRAI_BI"));
            bo.setHoseiIraiTime(rs.getString("HOSEI_IRAI_TIME"));
            bo.setHoseiIraiCode1(rs.getString("HOSEI_IRAI_CODE_1"));
            bo.setHoseiIraiCode2(rs.getString("HOSEI_IRAI_CODE_2"));
            bo.setHoseiIraiCode3(rs.getString("HOSEI_IRAI_CODE_3"));
            bo.setHoseiTaioBi(rs.getString("HOSEI_TAIO_BI"));
            bo.setHoseiTaioTime(rs.getString("HOSEI_TAIO_TIME"));
            bo.setHoseiFinishBi(rs.getString("HOSEI_FINISH_BI"));
            bo.setHoseiFinishTime(rs.getString("HOSEI_FINISH_TIME"));
            bo.setHoseiIraiMailSoshinFlg(rs.getString("HOSEI_IRAI_MAIL_SOSHIN_FLG"));
            bo.setHoseiKigenBi(rs.getString("HOSEI_KIGEN_BI"));
            bo.setKoshinKbn(rs.getString("KOSHIN_KBN"));
            bo.setTorokuDate(rs.getString("TOROKU_DATE"));
            bo.setTorokuTime(rs.getString("TOROKU_TIME"));
            bo.setTorokuUserId(rs.getString("TOROKU_USER_ID"));
            bo.setKoshinDate(rs.getString("KOSHIN_DATE"));
            bo.setKoshinTime(rs.getString("KOSHIN_TIME"));
            bo.setKoshinUserId(rs.getString("KOSHIN_USER_ID"));
            bo.setRonriSakujoFlg(rs.getString("RONRI_SAKUJO_FLG"));
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(null, ex);
        }
    }
}
