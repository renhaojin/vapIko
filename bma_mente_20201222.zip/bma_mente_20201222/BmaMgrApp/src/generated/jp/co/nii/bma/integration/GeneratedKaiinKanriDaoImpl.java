package jp.co.nii.bma.integration;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import jp.co.nii.sew.business.domain.NoSuchDataException;
import jp.co.nii.sew.common.LogGenerate;
import jp.co.nii.sew.integration.AbstractDao;
import jp.co.nii.sew.integration.SQLStateSQLExceptionTranslater;

import jp.co.nii.bma.business.domain.GeneratedKaiinKanri;
import jp.co.nii.bma.business.domain.GeneratedKaiinKanriDao;

/**
 * �������ꂽ ����Ǘ� DAO�����N���X<br>
 * table-design-ver 1
 * @author DB�Ǘ��c�[��
 */
abstract class GeneratedKaiinKanriDaoImpl extends AbstractDao implements GeneratedKaiinKanriDao {

    /**
     * �e�[�u���J�������̃J���}��؂蕶����B<br>
     * SQL���̍쐬�ɗp����B
     */
    protected static final String FIELDS = "KAIIN_ID"
            + ",KAIIN_KBN"
            + ",LOGIN_KBN"
            + ",SHIMEI"
            + ",FURIGANA"
            + ",BIRTHDAY"
            + ",YUBIN_NO"
            + ",TODOFUKEN_CODE"
            + ",JUSHO_1"
            + ",JUSHO_2"
            + ",TATEMONO"
            + ",TEL_NO"
            + ",FAX_NO"
            + ",MAIL_ADDRESS"
            + ",KUNI_ID"
            + ",KUNIMEI_JPN"
            + ",KUNIMEI_ENG"
            + ",KIGYO_CODE"
            + ",KIGYO_HP_URL"
            + ",KYOKAI_CODE"
            + ",KYOKAI_NAME"
            + ",KOSHIN_KBN"
            + ",TOROKU_DATE"
            + ",TOROKU_TIME"
            + ",TOROKU_USER_ID"
            + ",KOSHIN_DATE"
            + ",KOSHIN_TIME"
            + ",KOSHIN_USER_ID"
            + ",RONRI_SAKUJO_FLG";

    /**
     * �e�[�u���J�������̃J���}��؂蕶����B<br>
     *  �Í����Ώۍ��ڂ𕡍�����SQL���̍쐬�ɗp����B
     */
    protected static final String FIELDS_DECRYPT = "KAIIN_ID"
            + "," + getSQLForDecryptByUTF8("KAIIN_KBN")
            + "," + getSQLForDecryptByUTF8("LOGIN_KBN")
            + "," + getSQLForDecryptByUTF8("SHIMEI")
            + "," + getSQLForDecryptByUTF8("FURIGANA")
            + "," + getSQLForDecryptByUTF8("BIRTHDAY")
            + "," + getSQLForDecryptByUTF8("YUBIN_NO")
            + "," + getSQLForDecryptByUTF8("TODOFUKEN_CODE")
            + "," + getSQLForDecryptByUTF8("JUSHO_1")
            + "," + getSQLForDecryptByUTF8("JUSHO_2")
            + "," + getSQLForDecryptByUTF8("TATEMONO")
            + "," + getSQLForDecryptByUTF8("TEL_NO")
            + "," + getSQLForDecryptByUTF8("FAX_NO")
            + "," + getSQLForDecryptByUTF8("MAIL_ADDRESS")
            + "," + getSQLForDecryptByUTF8("KUNI_ID")
            + "," + getSQLForDecryptByUTF8("KUNIMEI_JPN")
            + "," + getSQLForDecryptByUTF8("KUNIMEI_ENG")
            + "," + getSQLForDecryptByUTF8("KIGYO_CODE")
            + "," + getSQLForDecryptByUTF8("KIGYO_HP_URL")
            + "," + getSQLForDecryptByUTF8("KYOKAI_CODE")
            + "," + getSQLForDecryptByUTF8("KYOKAI_NAME")
            + "," + "KOSHIN_KBN"
            + "," + "TOROKU_DATE"
            + "," + "TOROKU_TIME"
            + "," + "TOROKU_USER_ID"
            + "," + "KOSHIN_DATE"
            + "," + "KOSHIN_TIME"
            + "," + "KOSHIN_USER_ID"
            + "," + "RONRI_SAKUJO_FLG";

    /**
     * �C���X�^���X�𐶐�����B<br>
     * �f�[�^�\�[�X������
     * @param datasource �f�[�^�\�[�X��
     */
    public GeneratedKaiinKanriDaoImpl(String datasource) {
        super(datasource);
    }

    /* (non-Javadoc)
     * @see jp.co.nii.bma.business.domain.GeneratedKaiinKanriDao#create(jp.co.nii.bma.business.domain.GeneratedKaiinKanri)
     */
    @Override
    public void create(GeneratedKaiinKanri bo) {
        Connection con = null;
        PreparedStatement stmt = null;
        String sql = "";
        try {
            con = getConnection();
            sql = "INSERT INTO " + getSchemaName() + "." + TABLE_NAME + " ( "
                    + FIELDS
                    + " ) VALUES ("
                    + " ?"
                    + "," + getSQLForEncryptByUTF8("?")
                    + "," + getSQLForEncryptByUTF8("?")
                    + "," + getSQLForEncryptByUTF8("?")
                    + "," + getSQLForEncryptByUTF8("?")
                    + "," + getSQLForEncryptByUTF8("?")
                    + "," + getSQLForEncryptByUTF8("?")
                    + "," + getSQLForEncryptByUTF8("?")
                    + "," + getSQLForEncryptByUTF8("?")
                    + "," + getSQLForEncryptByUTF8("?")
                    + "," + getSQLForEncryptByUTF8("?")
                    + "," + getSQLForEncryptByUTF8("?")
                    + "," + getSQLForEncryptByUTF8("?")
                    + "," + getSQLForEncryptByUTF8("?")
                    + "," + getSQLForEncryptByUTF8("?")
                    + "," + getSQLForEncryptByUTF8("?")
                    + "," + getSQLForEncryptByUTF8("?")
                    + "," + getSQLForEncryptByUTF8("?")
                    + "," + getSQLForEncryptByUTF8("?")
                    + "," + getSQLForEncryptByUTF8("?")
                    + "," + getSQLForEncryptByUTF8("?")
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + " )";

            stmt = con.prepareStatement(sql);
            int i = 1;
            stmt.setString(i++, bo.getKaiinId());
            stmt.setString(i++, bo.getKaiinKbn());
            stmt.setString(i++, bo.getLoginKbn());
            stmt.setString(i++, bo.getShimei());
            stmt.setString(i++, bo.getFurigana());
            stmt.setString(i++, bo.getBirthday());
            stmt.setString(i++, bo.getYubinNo());
            stmt.setString(i++, bo.getTodofukenCode());
            stmt.setString(i++, bo.getJusho1());
            stmt.setString(i++, bo.getJusho2());
            stmt.setString(i++, bo.getTatemono());
            stmt.setString(i++, bo.getTelNo());
            stmt.setString(i++, bo.getFaxNo());
            stmt.setString(i++, bo.getMailAddress());
            stmt.setString(i++, bo.getKuniId());
            stmt.setString(i++, bo.getKunimeiJpn());
            stmt.setString(i++, bo.getKunimeiEng());
            stmt.setString(i++, bo.getKigyoCode());
            stmt.setString(i++, bo.getKigyoHpUrl());
            stmt.setString(i++, bo.getKyokaiCode());
            stmt.setString(i++, bo.getKyokaiName());
            stmt.setString(i++, bo.getKoshinKbn());
            stmt.setString(i++, bo.getTorokuDate());
            stmt.setString(i++, bo.getTorokuTime());
            stmt.setString(i++, bo.getTorokuUserId());
            stmt.setString(i++, bo.getKoshinDate());
            stmt.setString(i++, bo.getKoshinTime());
            stmt.setString(i++, bo.getKoshinUserId());
            stmt.setString(i++, bo.getRonriSakujoFlg());

            LogGenerate.debugOutput(getSql(stmt));
            stmt.executeUpdate();
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt);
        }
    }

    /* (non-Javadoc)
     * @see jp.co.nii.bma.business.domain.GeneratedKaiinKanriDao#find(jp.co.nii.bma.business.domain.GeneratedKaiinKanri, java.lang.String)
     */
    @Override
    public GeneratedKaiinKanri find(GeneratedKaiinKanri bo, String lockMode) {
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs =null;
        String sql = "";
        try {
            con = getConnection();
            sql = "SELECT " + FIELDS_DECRYPT
                    + " FROM " + getSchemaName() + "." + TABLE_NAME
                    + " WHERE"
                    + " KAIIN_ID = ?";

            stmt = con.prepareStatement(sql + lockMode);
            int i = 1;
            stmt.setString(i++, bo.getKaiinId());

            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();
            if (rs.next()) {
                setBoFromResultSet(bo, rs);
            } else {
                bo = null;
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return bo;
    }

    /* (non-Javadoc)
     * @see jp.co.nii.bma.business.domain.GeneratedKaiinKanriDao#update(jp.co.nii.bma.business.domain.GeneratedKaiinKanri)
     */
    @Override
    public void update(GeneratedKaiinKanri bo) {
        Connection con = null;
        PreparedStatement stmt = null;
        String sql = "";
        try {
            con = getConnection();
            sql = "UPDATE " + getSchemaName() + "." + TABLE_NAME + " SET"
                    + " KAIIN_KBN = " + getSQLForEncryptByUTF8("?")
                    + ",LOGIN_KBN = " + getSQLForEncryptByUTF8("?")
                    + ",SHIMEI = " + getSQLForEncryptByUTF8("?")
                    + ",FURIGANA = " + getSQLForEncryptByUTF8("?")
                    + ",BIRTHDAY = " + getSQLForEncryptByUTF8("?")
                    + ",YUBIN_NO = " + getSQLForEncryptByUTF8("?")
                    + ",TODOFUKEN_CODE = " + getSQLForEncryptByUTF8("?")
                    + ",JUSHO_1 = " + getSQLForEncryptByUTF8("?")
                    + ",JUSHO_2 = " + getSQLForEncryptByUTF8("?")
                    + ",TATEMONO = " + getSQLForEncryptByUTF8("?")
                    + ",TEL_NO = " + getSQLForEncryptByUTF8("?")
                    + ",FAX_NO = " + getSQLForEncryptByUTF8("?")
                    + ",MAIL_ADDRESS = " + getSQLForEncryptByUTF8("?")
                    + ",KUNI_ID = " + getSQLForEncryptByUTF8("?")
                    + ",KUNIMEI_JPN = " + getSQLForEncryptByUTF8("?")
                    + ",KUNIMEI_ENG = " + getSQLForEncryptByUTF8("?")
                    + ",KIGYO_CODE = " + getSQLForEncryptByUTF8("?")
                    + ",KIGYO_HP_URL = " + getSQLForEncryptByUTF8("?")
                    + ",KYOKAI_CODE = " + getSQLForEncryptByUTF8("?")
                    + ",KYOKAI_NAME = " + getSQLForEncryptByUTF8("?")
                    + ",KOSHIN_KBN = ?"
                    + ",TOROKU_DATE = ?"
                    + ",TOROKU_TIME = ?"
                    + ",TOROKU_USER_ID = ?"
                    + ",KOSHIN_DATE = ?"
                    + ",KOSHIN_TIME = ?"
                    + ",KOSHIN_USER_ID = ?"
                    + ",RONRI_SAKUJO_FLG = ?"
                    + " WHERE"
                    + " KAIIN_ID = ?";

            stmt = con.prepareStatement(sql);
            int i = 1;
            stmt.setString(i++, bo.getKaiinKbn());
            stmt.setString(i++, bo.getLoginKbn());
            stmt.setString(i++, bo.getShimei());
            stmt.setString(i++, bo.getFurigana());
            stmt.setString(i++, bo.getBirthday());
            stmt.setString(i++, bo.getYubinNo());
            stmt.setString(i++, bo.getTodofukenCode());
            stmt.setString(i++, bo.getJusho1());
            stmt.setString(i++, bo.getJusho2());
            stmt.setString(i++, bo.getTatemono());
            stmt.setString(i++, bo.getTelNo());
            stmt.setString(i++, bo.getFaxNo());
            stmt.setString(i++, bo.getMailAddress());
            stmt.setString(i++, bo.getKuniId());
            stmt.setString(i++, bo.getKunimeiJpn());
            stmt.setString(i++, bo.getKunimeiEng());
            stmt.setString(i++, bo.getKigyoCode());
            stmt.setString(i++, bo.getKigyoHpUrl());
            stmt.setString(i++, bo.getKyokaiCode());
            stmt.setString(i++, bo.getKyokaiName());
            stmt.setString(i++, bo.getKoshinKbn());
            stmt.setString(i++, bo.getTorokuDate());
            stmt.setString(i++, bo.getTorokuTime());
            stmt.setString(i++, bo.getTorokuUserId());
            stmt.setString(i++, bo.getKoshinDate());
            stmt.setString(i++, bo.getKoshinTime());
            stmt.setString(i++, bo.getKoshinUserId());
            stmt.setString(i++, bo.getRonriSakujoFlg());

            stmt.setString(i++, bo.getKaiinId());

            LogGenerate.debugOutput(getSql(stmt));
            if (stmt.executeUpdate() == 0) {
                throw new NoSuchDataException(getSql(stmt));
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt);
        }
    }

    /* (non-Javadoc)
     * @see jp.co.nii.bma.business.domain.GeneratedKaiinKanriDao#remove(jp.co.nii.bma.business.domain.GeneratedKaiinKanri)
     */
    @Override
    public void remove(GeneratedKaiinKanri bo) {
        Connection con = null;
        PreparedStatement stmt = null;
        String sql = "";
        try {
            con = getConnection();
            sql = "DELETE FROM " + getSchemaName() + "." + TABLE_NAME
                    + " WHERE"
                    + " KAIIN_ID = ?";

            stmt = con.prepareStatement(sql);
            int i = 1;
            stmt.setString(i++, bo.getKaiinId());

            LogGenerate.debugOutput(getSql(stmt));
            if (stmt.executeUpdate() == 0) {
                throw new NoSuchDataException(getSql(stmt));
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt);
        }
    }

    /**
     * �������ʂł���ResultSet��BusinessObject�֋l�ߑւ���B<br>
     * ���O�����F������bo��rs��null�łȂ����ƁB
     * 
     * @param bo BusinessObject�̃C���X�^���X
     * @param rs �������ʂ�ResultSet
     */
    protected void setBoFromResultSet(GeneratedKaiinKanri bo, ResultSet rs) {
        try {
            bo.setKaiinId(rs.getString("KAIIN_ID"));
            bo.setKaiinKbn(rs.getString("KAIIN_KBN"));
            bo.setLoginKbn(rs.getString("LOGIN_KBN"));
            bo.setShimei(rs.getString("SHIMEI"));
            bo.setFurigana(rs.getString("FURIGANA"));
            bo.setBirthday(rs.getString("BIRTHDAY"));
            bo.setYubinNo(rs.getString("YUBIN_NO"));
            bo.setTodofukenCode(rs.getString("TODOFUKEN_CODE"));
            bo.setJusho1(rs.getString("JUSHO_1"));
            bo.setJusho2(rs.getString("JUSHO_2"));
            bo.setTatemono(rs.getString("TATEMONO"));
            bo.setTelNo(rs.getString("TEL_NO"));
            bo.setFaxNo(rs.getString("FAX_NO"));
            bo.setMailAddress(rs.getString("MAIL_ADDRESS"));
            bo.setKuniId(rs.getString("KUNI_ID"));
            bo.setKunimeiJpn(rs.getString("KUNIMEI_JPN"));
            bo.setKunimeiEng(rs.getString("KUNIMEI_ENG"));
            bo.setKigyoCode(rs.getString("KIGYO_CODE"));
            bo.setKigyoHpUrl(rs.getString("KIGYO_HP_URL"));
            bo.setKyokaiCode(rs.getString("KYOKAI_CODE"));
            bo.setKyokaiName(rs.getString("KYOKAI_NAME"));
            bo.setKoshinKbn(rs.getString("KOSHIN_KBN"));
            bo.setTorokuDate(rs.getString("TOROKU_DATE"));
            bo.setTorokuTime(rs.getString("TOROKU_TIME"));
            bo.setTorokuUserId(rs.getString("TOROKU_USER_ID"));
            bo.setKoshinDate(rs.getString("KOSHIN_DATE"));
            bo.setKoshinTime(rs.getString("KOSHIN_TIME"));
            bo.setKoshinUserId(rs.getString("KOSHIN_USER_ID"));
            bo.setRonriSakujoFlg(rs.getString("RONRI_SAKUJO_FLG"));
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(null, ex);
        }
    }
}
