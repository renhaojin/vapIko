package jp.co.nii.bma.integration;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import jp.co.nii.sew.business.domain.NoSuchDataException;
import jp.co.nii.sew.common.LogGenerate;
import jp.co.nii.sew.integration.AbstractDao;
import jp.co.nii.sew.integration.SQLStateSQLExceptionTranslater;

import jp.co.nii.bma.business.domain.GeneratedKessaiYokyu;
import jp.co.nii.bma.business.domain.GeneratedKessaiYokyuDao;

/**
 * �������ꂽ ���ϗv�� DAO�����N���X<br>
 * table-design-ver 3
 * @author DB�Ǘ��c�[��
 */
abstract class GeneratedKessaiYokyuDaoImpl extends AbstractDao implements GeneratedKessaiYokyuDao {

    /**
     * �e�[�u���J�������̃J���}��؂蕶����B<br>
     * SQL���̍쐬�ɗp����B
     */
    protected static final String FIELDS = "TORIHIKI_CODE_NAIBU"
            + ",SHOHIN_NAME_1"
            + ",KINGAKU_1"
            + ",SHOHIN_NAME_2"
            + ",KINGAKU_2"
            + ",SHOHIN_NAME_3"
            + ",KINGAKU_3"
            + ",SHOHIN_NAME_4"
            + ",KINGAKU_4"
            + ",SHOHIN_NAME_5"
            + ",KINGAKU_5"
            + ",SHOHIN_NAME_6"
            + ",KINGAKU_6"
            + ",HUKA_JOHO"
            + ",KESSAI_HOHO_STORE"
            + ",FINISH_URL"
            + ",MODORI_URL"
            + ",BUYER_KANJI_SHIMEI_SEI"
            + ",BUYER_KANJI_SHIMEI_MEI"
            + ",BUYER_KANA_SHIMEI_SEI"
            + ",BUYER_KANA_SHIMEI_MEI"
            + ",BUYER_ZIP_NUM_1"
            + ",BUYER_ZIP_NUM_2"
            + ",BUYER_TEL_NO"
            + ",BUYER_JUSHO_1"
            + ",BUYER_JUSHO_2"
            + ",BUYER_MAIL_ADDRESS"
            + ",SHIHARAI_KIGEN"
            + ",UCHIZEI_GAKU"
            + ",USER_ID"
            + ",HYOJI_LANGUAGE"
            + ",KESSAI_KAKUTEI"
            + ",TSUKI_GAKU_KINGAKU"
            + ",TSUKI_GAKU_KAKUTEI"
            + ",NEXT_KESSAI_BI"
            + ",TSUKI_GAKU_KESSAI_BI"
            + ",HUKA_JOHO_GETSUGAKUKESSAIJI"
            + ",KAKUTEI_BI"
            + ",KOSHIN_KBN"
            + ",TOROKU_DATE"
            + ",TOROKU_TIME"
            + ",TOROKU_USER_ID"
            + ",KOSHIN_DATE"
            + ",KOSHIN_TIME"
            + ",KOSHIN_USER_ID"
            + ",RONRI_SAKUJO_FLG";

    /**
     * �e�[�u���J�������̃J���}��؂蕶����B<br>
     *  �Í����Ώۍ��ڂ𕡍�����SQL���̍쐬�ɗp����B
     */
    protected static final String FIELDS_DECRYPT = "TORIHIKI_CODE_NAIBU"
            + "," + "SHOHIN_NAME_1"
            + "," + "KINGAKU_1"
            + "," + "SHOHIN_NAME_2"
            + "," + "KINGAKU_2"
            + "," + "SHOHIN_NAME_3"
            + "," + "KINGAKU_3"
            + "," + "SHOHIN_NAME_4"
            + "," + "KINGAKU_4"
            + "," + "SHOHIN_NAME_5"
            + "," + "KINGAKU_5"
            + "," + "SHOHIN_NAME_6"
            + "," + "KINGAKU_6"
            + "," + "HUKA_JOHO"
            + "," + "KESSAI_HOHO_STORE"
            + "," + "FINISH_URL"
            + "," + "MODORI_URL"
            + "," + getSQLForDecryptByUTF8("BUYER_KANJI_SHIMEI_SEI")
            + "," + getSQLForDecryptByUTF8("BUYER_KANJI_SHIMEI_MEI")
            + "," + getSQLForDecryptByUTF8("BUYER_KANA_SHIMEI_SEI")
            + "," + getSQLForDecryptByUTF8("BUYER_KANA_SHIMEI_MEI")
            + "," + getSQLForDecryptByUTF8("BUYER_ZIP_NUM_1")
            + "," + getSQLForDecryptByUTF8("BUYER_ZIP_NUM_2")
            + "," + getSQLForDecryptByUTF8("BUYER_TEL_NO")
            + "," + getSQLForDecryptByUTF8("BUYER_JUSHO_1")
            + "," + getSQLForDecryptByUTF8("BUYER_JUSHO_2")
            + "," + getSQLForDecryptByUTF8("BUYER_MAIL_ADDRESS")
            + "," + "SHIHARAI_KIGEN"
            + "," + "UCHIZEI_GAKU"
            + "," + "USER_ID"
            + "," + "HYOJI_LANGUAGE"
            + "," + "KESSAI_KAKUTEI"
            + "," + "TSUKI_GAKU_KINGAKU"
            + "," + "TSUKI_GAKU_KAKUTEI"
            + "," + "NEXT_KESSAI_BI"
            + "," + "TSUKI_GAKU_KESSAI_BI"
            + "," + "HUKA_JOHO_GETSUGAKUKESSAIJI"
            + "," + "KAKUTEI_BI"
            + "," + "KOSHIN_KBN"
            + "," + "TOROKU_DATE"
            + "," + "TOROKU_TIME"
            + "," + "TOROKU_USER_ID"
            + "," + "KOSHIN_DATE"
            + "," + "KOSHIN_TIME"
            + "," + "KOSHIN_USER_ID"
            + "," + "RONRI_SAKUJO_FLG";

    /**
     * �C���X�^���X�𐶐�����B<br>
     * �f�[�^�\�[�X������
     * @param datasource �f�[�^�\�[�X��
     */
    public GeneratedKessaiYokyuDaoImpl(String datasource) {
        super(datasource);
    }

    /* (non-Javadoc)
     * @see jp.co.nii.bma.business.domain.GeneratedKessaiYokyuDao#create(jp.co.nii.bma.business.domain.GeneratedKessaiYokyu)
     */
    @Override
    public void create(GeneratedKessaiYokyu bo) {
        Connection con = null;
        PreparedStatement stmt = null;
        String sql = "";
        try {
            con = getConnection();
            sql = "INSERT INTO " + getSchemaName() + "." + TABLE_NAME + " ( "
                    + FIELDS
                    + " ) VALUES ("
                    + " ?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + "," + getSQLForEncryptByUTF8("?")
                    + "," + getSQLForEncryptByUTF8("?")
                    + "," + getSQLForEncryptByUTF8("?")
                    + "," + getSQLForEncryptByUTF8("?")
                    + "," + getSQLForEncryptByUTF8("?")
                    + "," + getSQLForEncryptByUTF8("?")
                    + "," + getSQLForEncryptByUTF8("?")
                    + "," + getSQLForEncryptByUTF8("?")
                    + "," + getSQLForEncryptByUTF8("?")
                    + "," + getSQLForEncryptByUTF8("?")
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + " )";

            stmt = con.prepareStatement(sql);
            int i = 1;
            stmt.setString(i++, bo.getTorihikiCodeNaibu());
            stmt.setString(i++, bo.getShohinName1());
            stmt.setString(i++, bo.getKingaku1());
            stmt.setString(i++, bo.getShohinName2());
            stmt.setString(i++, bo.getKingaku2());
            stmt.setString(i++, bo.getShohinName3());
            stmt.setString(i++, bo.getKingaku3());
            stmt.setString(i++, bo.getShohinName4());
            stmt.setString(i++, bo.getKingaku4());
            stmt.setString(i++, bo.getShohinName5());
            stmt.setString(i++, bo.getKingaku5());
            stmt.setString(i++, bo.getShohinName6());
            stmt.setString(i++, bo.getKingaku6());
            stmt.setString(i++, bo.getHukaJoho());
            stmt.setString(i++, bo.getKessaiHohoStore());
            stmt.setString(i++, bo.getFinishUrl());
            stmt.setString(i++, bo.getModoriUrl());
            stmt.setString(i++, bo.getBuyerKanjiShimeiSei());
            stmt.setString(i++, bo.getBuyerKanjiShimeiMei());
            stmt.setString(i++, bo.getBuyerKanaShimeiSei());
            stmt.setString(i++, bo.getBuyerKanaShimeiMei());
            stmt.setString(i++, bo.getBuyerZipNum1());
            stmt.setString(i++, bo.getBuyerZipNum2());
            stmt.setString(i++, bo.getBuyerTelNo());
            stmt.setString(i++, bo.getBuyerJusho1());
            stmt.setString(i++, bo.getBuyerJusho2());
            stmt.setString(i++, bo.getBuyerMailAddress());
            stmt.setString(i++, bo.getShiharaiKigen());
            stmt.setString(i++, bo.getUchizeiGaku());
            stmt.setString(i++, bo.getUserId());
            stmt.setString(i++, bo.getHyojiLanguage());
            stmt.setString(i++, bo.getKessaiKakutei());
            stmt.setString(i++, bo.getTsukiGakuKingaku());
            stmt.setString(i++, bo.getTsukiGakuKakutei());
            stmt.setString(i++, bo.getNextKessaiBi());
            stmt.setString(i++, bo.getTsukiGakuKessaiBi());
            stmt.setString(i++, bo.getHukaJohoGetsugakukessaiji());
            stmt.setString(i++, bo.getKakuteiBi());
            stmt.setString(i++, bo.getKoshinKbn());
            stmt.setString(i++, bo.getTorokuDate());
            stmt.setString(i++, bo.getTorokuTime());
            stmt.setString(i++, bo.getTorokuUserId());
            stmt.setString(i++, bo.getKoshinDate());
            stmt.setString(i++, bo.getKoshinTime());
            stmt.setString(i++, bo.getKoshinUserId());
            stmt.setString(i++, bo.getRonriSakujoFlg());

            LogGenerate.debugOutput(getSql(stmt));
            stmt.executeUpdate();
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt);
        }
    }

    /* (non-Javadoc)
     * @see jp.co.nii.bma.business.domain.GeneratedKessaiYokyuDao#find(jp.co.nii.bma.business.domain.GeneratedKessaiYokyu, java.lang.String)
     */
    @Override
    public GeneratedKessaiYokyu find(GeneratedKessaiYokyu bo, String lockMode) {
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs =null;
        String sql = "";
        try {
            con = getConnection();
            sql = "SELECT " + FIELDS_DECRYPT
                    + " FROM " + getSchemaName() + "." + TABLE_NAME
                    + " WHERE"
                    + " TORIHIKI_CODE_NAIBU = ?";

            stmt = con.prepareStatement(sql + lockMode);
            int i = 1;
            stmt.setString(i++, bo.getTorihikiCodeNaibu());

            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();
            if (rs.next()) {
                setBoFromResultSet(bo, rs);
            } else {
                bo = null;
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return bo;
    }

    /* (non-Javadoc)
     * @see jp.co.nii.bma.business.domain.GeneratedKessaiYokyuDao#update(jp.co.nii.bma.business.domain.GeneratedKessaiYokyu)
     */
    @Override
    public void update(GeneratedKessaiYokyu bo) {
        Connection con = null;
        PreparedStatement stmt = null;
        String sql = "";
        try {
            con = getConnection();
            sql = "UPDATE " + getSchemaName() + "." + TABLE_NAME + " SET"
                    + " SHOHIN_NAME_1 = ?"
                    + ",KINGAKU_1 = ?"
                    + ",SHOHIN_NAME_2 = ?"
                    + ",KINGAKU_2 = ?"
                    + ",SHOHIN_NAME_3 = ?"
                    + ",KINGAKU_3 = ?"
                    + ",SHOHIN_NAME_4 = ?"
                    + ",KINGAKU_4 = ?"
                    + ",SHOHIN_NAME_5 = ?"
                    + ",KINGAKU_5 = ?"
                    + ",SHOHIN_NAME_6 = ?"
                    + ",KINGAKU_6 = ?"
                    + ",HUKA_JOHO = ?"
                    + ",KESSAI_HOHO_STORE = ?"
                    + ",FINISH_URL = ?"
                    + ",MODORI_URL = ?"
                    + ",BUYER_KANJI_SHIMEI_SEI = " + getSQLForEncryptByUTF8("?")
                    + ",BUYER_KANJI_SHIMEI_MEI = " + getSQLForEncryptByUTF8("?")
                    + ",BUYER_KANA_SHIMEI_SEI = " + getSQLForEncryptByUTF8("?")
                    + ",BUYER_KANA_SHIMEI_MEI = " + getSQLForEncryptByUTF8("?")
                    + ",BUYER_ZIP_NUM_1 = " + getSQLForEncryptByUTF8("?")
                    + ",BUYER_ZIP_NUM_2 = " + getSQLForEncryptByUTF8("?")
                    + ",BUYER_TEL_NO = " + getSQLForEncryptByUTF8("?")
                    + ",BUYER_JUSHO_1 = " + getSQLForEncryptByUTF8("?")
                    + ",BUYER_JUSHO_2 = " + getSQLForEncryptByUTF8("?")
                    + ",BUYER_MAIL_ADDRESS = " + getSQLForEncryptByUTF8("?")
                    + ",SHIHARAI_KIGEN = ?"
                    + ",UCHIZEI_GAKU = ?"
                    + ",USER_ID = ?"
                    + ",HYOJI_LANGUAGE = ?"
                    + ",KESSAI_KAKUTEI = ?"
                    + ",TSUKI_GAKU_KINGAKU = ?"
                    + ",TSUKI_GAKU_KAKUTEI = ?"
                    + ",NEXT_KESSAI_BI = ?"
                    + ",TSUKI_GAKU_KESSAI_BI = ?"
                    + ",HUKA_JOHO_GETSUGAKUKESSAIJI = ?"
                    + ",KAKUTEI_BI = ?"
                    + ",KOSHIN_KBN = ?"
                    + ",TOROKU_DATE = ?"
                    + ",TOROKU_TIME = ?"
                    + ",TOROKU_USER_ID = ?"
                    + ",KOSHIN_DATE = ?"
                    + ",KOSHIN_TIME = ?"
                    + ",KOSHIN_USER_ID = ?"
                    + ",RONRI_SAKUJO_FLG = ?"
                    + " WHERE"
                    + " TORIHIKI_CODE_NAIBU = ?";

            stmt = con.prepareStatement(sql);
            int i = 1;
            stmt.setString(i++, bo.getShohinName1());
            stmt.setString(i++, bo.getKingaku1());
            stmt.setString(i++, bo.getShohinName2());
            stmt.setString(i++, bo.getKingaku2());
            stmt.setString(i++, bo.getShohinName3());
            stmt.setString(i++, bo.getKingaku3());
            stmt.setString(i++, bo.getShohinName4());
            stmt.setString(i++, bo.getKingaku4());
            stmt.setString(i++, bo.getShohinName5());
            stmt.setString(i++, bo.getKingaku5());
            stmt.setString(i++, bo.getShohinName6());
            stmt.setString(i++, bo.getKingaku6());
            stmt.setString(i++, bo.getHukaJoho());
            stmt.setString(i++, bo.getKessaiHohoStore());
            stmt.setString(i++, bo.getFinishUrl());
            stmt.setString(i++, bo.getModoriUrl());
            stmt.setString(i++, bo.getBuyerKanjiShimeiSei());
            stmt.setString(i++, bo.getBuyerKanjiShimeiMei());
            stmt.setString(i++, bo.getBuyerKanaShimeiSei());
            stmt.setString(i++, bo.getBuyerKanaShimeiMei());
            stmt.setString(i++, bo.getBuyerZipNum1());
            stmt.setString(i++, bo.getBuyerZipNum2());
            stmt.setString(i++, bo.getBuyerTelNo());
            stmt.setString(i++, bo.getBuyerJusho1());
            stmt.setString(i++, bo.getBuyerJusho2());
            stmt.setString(i++, bo.getBuyerMailAddress());
            stmt.setString(i++, bo.getShiharaiKigen());
            stmt.setString(i++, bo.getUchizeiGaku());
            stmt.setString(i++, bo.getUserId());
            stmt.setString(i++, bo.getHyojiLanguage());
            stmt.setString(i++, bo.getKessaiKakutei());
            stmt.setString(i++, bo.getTsukiGakuKingaku());
            stmt.setString(i++, bo.getTsukiGakuKakutei());
            stmt.setString(i++, bo.getNextKessaiBi());
            stmt.setString(i++, bo.getTsukiGakuKessaiBi());
            stmt.setString(i++, bo.getHukaJohoGetsugakukessaiji());
            stmt.setString(i++, bo.getKakuteiBi());
            stmt.setString(i++, bo.getKoshinKbn());
            stmt.setString(i++, bo.getTorokuDate());
            stmt.setString(i++, bo.getTorokuTime());
            stmt.setString(i++, bo.getTorokuUserId());
            stmt.setString(i++, bo.getKoshinDate());
            stmt.setString(i++, bo.getKoshinTime());
            stmt.setString(i++, bo.getKoshinUserId());
            stmt.setString(i++, bo.getRonriSakujoFlg());

            stmt.setString(i++, bo.getTorihikiCodeNaibu());

            LogGenerate.debugOutput(getSql(stmt));
            if (stmt.executeUpdate() == 0) {
                throw new NoSuchDataException(getSql(stmt));
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt);
        }
    }

    /* (non-Javadoc)
     * @see jp.co.nii.bma.business.domain.GeneratedKessaiYokyuDao#remove(jp.co.nii.bma.business.domain.GeneratedKessaiYokyu)
     */
    @Override
    public void remove(GeneratedKessaiYokyu bo) {
        Connection con = null;
        PreparedStatement stmt = null;
        String sql = "";
        try {
            con = getConnection();
            sql = "DELETE FROM " + getSchemaName() + "." + TABLE_NAME
                    + " WHERE"
                    + " TORIHIKI_CODE_NAIBU = ?";

            stmt = con.prepareStatement(sql);
            int i = 1;
            stmt.setString(i++, bo.getTorihikiCodeNaibu());

            LogGenerate.debugOutput(getSql(stmt));
            if (stmt.executeUpdate() == 0) {
                throw new NoSuchDataException(getSql(stmt));
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt);
        }
    }

    /**
     * �������ʂł���ResultSet��BusinessObject�֋l�ߑւ���B<br>
     * ���O�����F������bo��rs��null�łȂ����ƁB
     * 
     * @param bo BusinessObject�̃C���X�^���X
     * @param rs �������ʂ�ResultSet
     */
    protected void setBoFromResultSet(GeneratedKessaiYokyu bo, ResultSet rs) {
        try {
            bo.setTorihikiCodeNaibu(rs.getString("TORIHIKI_CODE_NAIBU"));
            bo.setShohinName1(rs.getString("SHOHIN_NAME_1"));
            bo.setKingaku1(rs.getString("KINGAKU_1"));
            bo.setShohinName2(rs.getString("SHOHIN_NAME_2"));
            bo.setKingaku2(rs.getString("KINGAKU_2"));
            bo.setShohinName3(rs.getString("SHOHIN_NAME_3"));
            bo.setKingaku3(rs.getString("KINGAKU_3"));
            bo.setShohinName4(rs.getString("SHOHIN_NAME_4"));
            bo.setKingaku4(rs.getString("KINGAKU_4"));
            bo.setShohinName5(rs.getString("SHOHIN_NAME_5"));
            bo.setKingaku5(rs.getString("KINGAKU_5"));
            bo.setShohinName6(rs.getString("SHOHIN_NAME_6"));
            bo.setKingaku6(rs.getString("KINGAKU_6"));
            bo.setHukaJoho(rs.getString("HUKA_JOHO"));
            bo.setKessaiHohoStore(rs.getString("KESSAI_HOHO_STORE"));
            bo.setFinishUrl(rs.getString("FINISH_URL"));
            bo.setModoriUrl(rs.getString("MODORI_URL"));
            bo.setBuyerKanjiShimeiSei(rs.getString("BUYER_KANJI_SHIMEI_SEI"));
            bo.setBuyerKanjiShimeiMei(rs.getString("BUYER_KANJI_SHIMEI_MEI"));
            bo.setBuyerKanaShimeiSei(rs.getString("BUYER_KANA_SHIMEI_SEI"));
            bo.setBuyerKanaShimeiMei(rs.getString("BUYER_KANA_SHIMEI_MEI"));
            bo.setBuyerZipNum1(rs.getString("BUYER_ZIP_NUM_1"));
            bo.setBuyerZipNum2(rs.getString("BUYER_ZIP_NUM_2"));
            bo.setBuyerTelNo(rs.getString("BUYER_TEL_NO"));
            bo.setBuyerJusho1(rs.getString("BUYER_JUSHO_1"));
            bo.setBuyerJusho2(rs.getString("BUYER_JUSHO_2"));
            bo.setBuyerMailAddress(rs.getString("BUYER_MAIL_ADDRESS"));
            bo.setShiharaiKigen(rs.getString("SHIHARAI_KIGEN"));
            bo.setUchizeiGaku(rs.getString("UCHIZEI_GAKU"));
            bo.setUserId(rs.getString("USER_ID"));
            bo.setHyojiLanguage(rs.getString("HYOJI_LANGUAGE"));
            bo.setKessaiKakutei(rs.getString("KESSAI_KAKUTEI"));
            bo.setTsukiGakuKingaku(rs.getString("TSUKI_GAKU_KINGAKU"));
            bo.setTsukiGakuKakutei(rs.getString("TSUKI_GAKU_KAKUTEI"));
            bo.setNextKessaiBi(rs.getString("NEXT_KESSAI_BI"));
            bo.setTsukiGakuKessaiBi(rs.getString("TSUKI_GAKU_KESSAI_BI"));
            bo.setHukaJohoGetsugakukessaiji(rs.getString("HUKA_JOHO_GETSUGAKUKESSAIJI"));
            bo.setKakuteiBi(rs.getString("KAKUTEI_BI"));
            bo.setKoshinKbn(rs.getString("KOSHIN_KBN"));
            bo.setTorokuDate(rs.getString("TOROKU_DATE"));
            bo.setTorokuTime(rs.getString("TOROKU_TIME"));
            bo.setTorokuUserId(rs.getString("TOROKU_USER_ID"));
            bo.setKoshinDate(rs.getString("KOSHIN_DATE"));
            bo.setKoshinTime(rs.getString("KOSHIN_TIME"));
            bo.setKoshinUserId(rs.getString("KOSHIN_USER_ID"));
            bo.setRonriSakujoFlg(rs.getString("RONRI_SAKUJO_FLG"));
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(null, ex);
        }
    }
}
