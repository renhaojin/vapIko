package jp.co.nii.bma.integration;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import jp.co.nii.sew.business.domain.NoSuchDataException;
import jp.co.nii.sew.common.LogGenerate;
import jp.co.nii.sew.integration.AbstractDao;
import jp.co.nii.sew.integration.SQLStateSQLExceptionTranslater;

import jp.co.nii.bma.business.domain.GeneratedKessai;
import jp.co.nii.bma.business.domain.GeneratedKessaiDao;

/**
 * �������ꂽ ���� DAO�����N���X<br>
 * table-design-ver 6
 * @author DB�Ǘ��c�[��
 */
abstract class GeneratedKessaiDaoImpl extends AbstractDao implements GeneratedKessaiDao {

    /**
     * �e�[�u���J�������̃J���}��؂蕶����B<br>
     * SQL���̍쐬�ɗp����B
     */
    protected static final String FIELDS = "NENDO"
            + ",UKETSUKE_NO"
            + ",KESSAI_JOKYO_KBN"
            + ",KESSAI_HOHO_KBN"
            + ",IP_CODE"
            + ",TORIHIKI_CODE"
            + ",KESSAI_CONVENIENCE_SHUBETSU"
            + ",KESSAI_CONVENIENCE_HARAIKOMI_NO"
            + ",KESSAI_SHUNO_KIKAN_NO"
            + ",KESSAI_OKYAKUSAMA_NO"
            + ",KESSAI_KAKUNIN_NO"
            + ",KESSAI_HARAIKOMIHYO_URL"
            + ",NYUKIN_BI"
            + ",NYUKIN_TIME"
            + ",KESSAI_KIGEN_BI"
            + ",KESSAI_KINGAKU"
            + ",KESSAI_TESURYO"
            + ",KESSAI_KINGAKU_TOTAL"
            + ",KESSAI_TOKUSOKU_MAIL_SOSHIN_FLG"
            + ",KOSHIN_KBN"
            + ",TOROKU_DATE"
            + ",TOROKU_TIME"
            + ",TOROKU_USER_ID"
            + ",KOSHIN_DATE"
            + ",KOSHIN_TIME"
            + ",KOSHIN_USER_ID"
            + ",RONRI_SAKUJO_FLG";

    /**
     * �e�[�u���J�������̃J���}��؂蕶����B<br>
     *  �Í����Ώۍ��ڂ𕡍�����SQL���̍쐬�ɗp����B
     */
    protected static final String FIELDS_DECRYPT = "NENDO"
            + "," + "UKETSUKE_NO"
            + "," + "KESSAI_JOKYO_KBN"
            + "," + "KESSAI_HOHO_KBN"
            + "," + "IP_CODE"
            + "," + "TORIHIKI_CODE"
            + "," + "KESSAI_CONVENIENCE_SHUBETSU"
            + "," + "KESSAI_CONVENIENCE_HARAIKOMI_NO"
            + "," + "KESSAI_SHUNO_KIKAN_NO"
            + "," + "KESSAI_OKYAKUSAMA_NO"
            + "," + "KESSAI_KAKUNIN_NO"
            + "," + "KESSAI_HARAIKOMIHYO_URL"
            + "," + "NYUKIN_BI"
            + "," + "NYUKIN_TIME"
            + "," + "KESSAI_KIGEN_BI"
            + "," + "KESSAI_KINGAKU"
            + "," + "KESSAI_TESURYO"
            + "," + "KESSAI_KINGAKU_TOTAL"
            + "," + "KESSAI_TOKUSOKU_MAIL_SOSHIN_FLG"
            + "," + "KOSHIN_KBN"
            + "," + "TOROKU_DATE"
            + "," + "TOROKU_TIME"
            + "," + "TOROKU_USER_ID"
            + "," + "KOSHIN_DATE"
            + "," + "KOSHIN_TIME"
            + "," + "KOSHIN_USER_ID"
            + "," + "RONRI_SAKUJO_FLG";

    /**
     * �C���X�^���X�𐶐�����B<br>
     * �f�[�^�\�[�X������
     * @param datasource �f�[�^�\�[�X��
     */
    public GeneratedKessaiDaoImpl(String datasource) {
        super(datasource);
    }

    /* (non-Javadoc)
     * @see jp.co.nii.bma.business.domain.GeneratedKessaiDao#create(jp.co.nii.bma.business.domain.GeneratedKessai)
     */
    @Override
    public void create(GeneratedKessai bo) {
        Connection con = null;
        PreparedStatement stmt = null;
        String sql = "";
        try {
            con = getConnection();
            sql = "INSERT INTO " + getSchemaName() + "." + TABLE_NAME + " ( "
                    + FIELDS
                    + " ) VALUES ("
                    + " ?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + ",?"
                    + " )";

            stmt = con.prepareStatement(sql);
            int i = 1;
            stmt.setString(i++, bo.getNendo());
            stmt.setString(i++, bo.getUketsukeNo());
            stmt.setString(i++, bo.getKessaiJokyoKbn());
            stmt.setString(i++, bo.getKessaiHohoKbn());
            stmt.setString(i++, bo.getIpCode());
            stmt.setString(i++, bo.getTorihikiCode());
            stmt.setString(i++, bo.getKessaiConvenienceShubetsu());
            stmt.setString(i++, bo.getKessaiConvenienceHaraikomiNo());
            stmt.setString(i++, bo.getKessaiShunoKikanNo());
            stmt.setString(i++, bo.getKessaiOkyakusamaNo());
            stmt.setString(i++, bo.getKessaiKakuninNo());
            stmt.setString(i++, bo.getKessaiHaraikomihyoUrl());
            stmt.setString(i++, bo.getNyukinBi());
            stmt.setString(i++, bo.getNyukinTime());
            stmt.setString(i++, bo.getKessaiKigenBi());
            stmt.setString(i++, bo.getKessaiKingaku());
            stmt.setString(i++, bo.getKessaiTesuryo());
            stmt.setString(i++, bo.getKessaiKingakuTotal());
            stmt.setString(i++, bo.getKessaiTokusokuMailSoshinFlg());
            stmt.setString(i++, bo.getKoshinKbn());
            stmt.setString(i++, bo.getTorokuDate());
            stmt.setString(i++, bo.getTorokuTime());
            stmt.setString(i++, bo.getTorokuUserId());
            stmt.setString(i++, bo.getKoshinDate());
            stmt.setString(i++, bo.getKoshinTime());
            stmt.setString(i++, bo.getKoshinUserId());
            stmt.setString(i++, bo.getRonriSakujoFlg());

            LogGenerate.debugOutput(getSql(stmt));
            stmt.executeUpdate();
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt);
        }
    }

    /* (non-Javadoc)
     * @see jp.co.nii.bma.business.domain.GeneratedKessaiDao#find(jp.co.nii.bma.business.domain.GeneratedKessai, java.lang.String)
     */
    @Override
    public GeneratedKessai find(GeneratedKessai bo, String lockMode) {
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs =null;
        String sql = "";
        try {
            con = getConnection();
            sql = "SELECT " + FIELDS_DECRYPT
                    + " FROM " + getSchemaName() + "." + TABLE_NAME
                    + " WHERE"
                    + " NENDO = ?"
                    + " AND UKETSUKE_NO = ?";

            stmt = con.prepareStatement(sql + lockMode);
            int i = 1;
            stmt.setString(i++, bo.getNendo());
            stmt.setString(i++, bo.getUketsukeNo());

            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();
            if (rs.next()) {
                setBoFromResultSet(bo, rs);
            } else {
                bo = null;
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return bo;
    }

    /* (non-Javadoc)
     * @see jp.co.nii.bma.business.domain.GeneratedKessaiDao#update(jp.co.nii.bma.business.domain.GeneratedKessai)
     */
    @Override
    public void update(GeneratedKessai bo) {
        Connection con = null;
        PreparedStatement stmt = null;
        String sql = "";
        try {
            con = getConnection();
            sql = "UPDATE " + getSchemaName() + "." + TABLE_NAME + " SET"
                    + " KESSAI_JOKYO_KBN = ?"
                    + ",KESSAI_HOHO_KBN = ?"
                    + ",IP_CODE = ?"
                    + ",TORIHIKI_CODE = ?"
                    + ",KESSAI_CONVENIENCE_SHUBETSU = ?"
                    + ",KESSAI_CONVENIENCE_HARAIKOMI_NO = ?"
                    + ",KESSAI_SHUNO_KIKAN_NO = ?"
                    + ",KESSAI_OKYAKUSAMA_NO = ?"
                    + ",KESSAI_KAKUNIN_NO = ?"
                    + ",KESSAI_HARAIKOMIHYO_URL = ?"
                    + ",NYUKIN_BI = ?"
                    + ",NYUKIN_TIME = ?"
                    + ",KESSAI_KIGEN_BI = ?"
                    + ",KESSAI_KINGAKU = ?"
                    + ",KESSAI_TESURYO = ?"
                    + ",KESSAI_KINGAKU_TOTAL = ?"
                    + ",KESSAI_TOKUSOKU_MAIL_SOSHIN_FLG = ?"
                    + ",KOSHIN_KBN = ?"
                    + ",TOROKU_DATE = ?"
                    + ",TOROKU_TIME = ?"
                    + ",TOROKU_USER_ID = ?"
                    + ",KOSHIN_DATE = ?"
                    + ",KOSHIN_TIME = ?"
                    + ",KOSHIN_USER_ID = ?"
                    + ",RONRI_SAKUJO_FLG = ?"
                    + " WHERE"
                    + " NENDO = ?"
                    + " AND UKETSUKE_NO = ?";

            stmt = con.prepareStatement(sql);
            int i = 1;
            stmt.setString(i++, bo.getKessaiJokyoKbn());
            stmt.setString(i++, bo.getKessaiHohoKbn());
            stmt.setString(i++, bo.getIpCode());
            stmt.setString(i++, bo.getTorihikiCode());
            stmt.setString(i++, bo.getKessaiConvenienceShubetsu());
            stmt.setString(i++, bo.getKessaiConvenienceHaraikomiNo());
            stmt.setString(i++, bo.getKessaiShunoKikanNo());
            stmt.setString(i++, bo.getKessaiOkyakusamaNo());
            stmt.setString(i++, bo.getKessaiKakuninNo());
            stmt.setString(i++, bo.getKessaiHaraikomihyoUrl());
            stmt.setString(i++, bo.getNyukinBi());
            stmt.setString(i++, bo.getNyukinTime());
            stmt.setString(i++, bo.getKessaiKigenBi());
            stmt.setString(i++, bo.getKessaiKingaku());
            stmt.setString(i++, bo.getKessaiTesuryo());
            stmt.setString(i++, bo.getKessaiKingakuTotal());
            stmt.setString(i++, bo.getKessaiTokusokuMailSoshinFlg());
            stmt.setString(i++, bo.getKoshinKbn());
            stmt.setString(i++, bo.getTorokuDate());
            stmt.setString(i++, bo.getTorokuTime());
            stmt.setString(i++, bo.getTorokuUserId());
            stmt.setString(i++, bo.getKoshinDate());
            stmt.setString(i++, bo.getKoshinTime());
            stmt.setString(i++, bo.getKoshinUserId());
            stmt.setString(i++, bo.getRonriSakujoFlg());

            stmt.setString(i++, bo.getNendo());
            stmt.setString(i++, bo.getUketsukeNo());

            LogGenerate.debugOutput(getSql(stmt));
            if (stmt.executeUpdate() == 0) {
                throw new NoSuchDataException(getSql(stmt));
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt);
        }
    }

    /* (non-Javadoc)
     * @see jp.co.nii.bma.business.domain.GeneratedKessaiDao#remove(jp.co.nii.bma.business.domain.GeneratedKessai)
     */
    @Override
    public void remove(GeneratedKessai bo) {
        Connection con = null;
        PreparedStatement stmt = null;
        String sql = "";
        try {
            con = getConnection();
            sql = "DELETE FROM " + getSchemaName() + "." + TABLE_NAME
                    + " WHERE"
                    + " NENDO = ?"
                    + " AND UKETSUKE_NO = ?";

            stmt = con.prepareStatement(sql);
            int i = 1;
            stmt.setString(i++, bo.getNendo());
            stmt.setString(i++, bo.getUketsukeNo());

            LogGenerate.debugOutput(getSql(stmt));
            if (stmt.executeUpdate() == 0) {
                throw new NoSuchDataException(getSql(stmt));
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt);
        }
    }

    /**
     * �������ʂł���ResultSet��BusinessObject�֋l�ߑւ���B<br>
     * ���O�����F������bo��rs��null�łȂ����ƁB
     * 
     * @param bo BusinessObject�̃C���X�^���X
     * @param rs �������ʂ�ResultSet
     */
    protected void setBoFromResultSet(GeneratedKessai bo, ResultSet rs) {
        try {
            bo.setNendo(rs.getString("NENDO"));
            bo.setUketsukeNo(rs.getString("UKETSUKE_NO"));
            bo.setKessaiJokyoKbn(rs.getString("KESSAI_JOKYO_KBN"));
            bo.setKessaiHohoKbn(rs.getString("KESSAI_HOHO_KBN"));
            bo.setIpCode(rs.getString("IP_CODE"));
            bo.setTorihikiCode(rs.getString("TORIHIKI_CODE"));
            bo.setKessaiConvenienceShubetsu(rs.getString("KESSAI_CONVENIENCE_SHUBETSU"));
            bo.setKessaiConvenienceHaraikomiNo(rs.getString("KESSAI_CONVENIENCE_HARAIKOMI_NO"));
            bo.setKessaiShunoKikanNo(rs.getString("KESSAI_SHUNO_KIKAN_NO"));
            bo.setKessaiOkyakusamaNo(rs.getString("KESSAI_OKYAKUSAMA_NO"));
            bo.setKessaiKakuninNo(rs.getString("KESSAI_KAKUNIN_NO"));
            bo.setKessaiHaraikomihyoUrl(rs.getString("KESSAI_HARAIKOMIHYO_URL"));
            bo.setNyukinBi(rs.getString("NYUKIN_BI"));
            bo.setNyukinTime(rs.getString("NYUKIN_TIME"));
            bo.setKessaiKigenBi(rs.getString("KESSAI_KIGEN_BI"));
            bo.setKessaiKingaku(rs.getString("KESSAI_KINGAKU"));
            bo.setKessaiTesuryo(rs.getString("KESSAI_TESURYO"));
            bo.setKessaiKingakuTotal(rs.getString("KESSAI_KINGAKU_TOTAL"));
            bo.setKessaiTokusokuMailSoshinFlg(rs.getString("KESSAI_TOKUSOKU_MAIL_SOSHIN_FLG"));
            bo.setKoshinKbn(rs.getString("KOSHIN_KBN"));
            bo.setTorokuDate(rs.getString("TOROKU_DATE"));
            bo.setTorokuTime(rs.getString("TOROKU_TIME"));
            bo.setTorokuUserId(rs.getString("TOROKU_USER_ID"));
            bo.setKoshinDate(rs.getString("KOSHIN_DATE"));
            bo.setKoshinTime(rs.getString("KOSHIN_TIME"));
            bo.setKoshinUserId(rs.getString("KOSHIN_USER_ID"));
            bo.setRonriSakujoFlg(rs.getString("RONRI_SAKUJO_FLG"));
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(null, ex);
        }
    }
}
