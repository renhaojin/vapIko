package jp.co.nii.bma.integration;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import jp.co.nii.bma.business.domain.KaijoTantoMst;
import jp.co.nii.bma.business.domain.KaijoTantoMstDao;
import jp.co.nii.sew.common.LogGenerate;
import static jp.co.nii.sew.integration.AbstractDao.getSchemaName;
import jp.co.nii.sew.integration.SQLStateSQLExceptionTranslater;
import jp.co.nii.sew.presentation.Option;

/**
 * ���S���҃}�X�^ DAO�����N���X
 * @author DB�Ǘ��c�[��
 */
public class KaijoTantoMstDaoImpl extends GeneratedKaijoTantoMstDaoImpl implements KaijoTantoMstDao {

    /**
     * �C���X�^���X�𐶐�����B
     * @param datasource �f�[�^�\�[�X��
     */
    public KaijoTantoMstDaoImpl(String datasource) {
        super(datasource);
    }

    /**
     * �����J�Òn���S���҂��擾����B
     * @param kaisaichiCodes �J�Òn�R�[�h
     */

    @Override
    public List<KaijoTantoMst> findAllByKaisaichi(String[] kaisaichiCodes) {

        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = "";
        List<String> param = new ArrayList<>();
        List<KaijoTantoMst> tantoByKaisaichiList = new ArrayList<>();

        try {
            con = getConnection();
            sql = "SELECT "
                    + "tanto.KAISAICHI_CODE AS KAISAICHI_CODE"
                    + ", " + "tanto.KAIJO_CODE AS KAIJO_CODE"
                    + ", " + "tanto.TANTOSHA_CODE AS TANTOSHA_CODE"
                    + ", " + "convert_from(bma.decrypt( tanto.TANTOSHA , 'Pj64W5fr'::bytea, 'aes'::text), 'UTF8'::name) AS TANTOSHA"
                    + ", " + "convert_from(bma.decrypt( tanto.TANTO_BUSHO , 'Pj64W5fr'::bytea, 'aes'::text), 'UTF8'::name) AS TANTO_BUSHO"
                    + ", " + "convert_from(bma.decrypt( tanto.TEL_NO , 'Pj64W5fr'::bytea, 'aes'::text), 'UTF8'::name) AS TEL_NO"
                    + ", " + "convert_from(bma.decrypt( tanto.FAX_NO , 'Pj64W5fr'::bytea, 'aes'::text), 'UTF8'::name) AS FAX_NO"
                    + ", " + "convert_from(bma.decrypt( tanto.TANTOSHA_MAIL_ADDRESS , 'Pj64W5fr'::bytea, 'aes'::text), 'UTF8'::name) AS TANTOSHA_MAIL_ADDRESS"
                    + ", " + "tanto.BIKO AS BIKO"
                    + " FROM " + getSchemaName() + "." + KaijoTantoMstDao.TABLE_NAME + " AS tanto"
                    + " WHERE " + "tanto.KAISAICHI_CODE IN ( ";

            for (int i=0; i < kaisaichiCodes.length; i++) {
                if (i > 0) {
                    sql += ", ";
                }
                sql += "?";
            }
            sql += " )";
            sql +=  " AND " + "tanto.RONRI_SAKUJO_FLG = '0'"
                    + " ORDER BY tanto.KAISAICHI_CODE ASC , tanto.KAIJO_CODE ASC , tanto.TANTOSHA_CODE ASC";

            stmt = con.prepareStatement(sql);
            
            for (int i=0 ; i < kaisaichiCodes.length; i++) {
                param.add(kaisaichiCodes[i]);
            }
            int j = 1;
            for (String kaisaichi : param) {
                stmt.setString(j++, kaisaichi);
            }

            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();

            while (rs.next()) {
                KaijoTantoMst detail = new KaijoTantoMst();
                detail.setKaisaichiCode(rs.getString("KAISAICHI_CODE"));
                detail.setKaijoCode(rs.getString("KAIJO_CODE"));
                detail.setTantoshaCode(rs.getString("TANTOSHA_CODE"));
                detail.setTantosha(rs.getString("TANTOSHA"));
                detail.setTantoBusho(rs.getString("TANTO_BUSHO"));
                detail.setTelNo(rs.getString("TEL_NO"));
                detail.setFaxNo(rs.getString("FAX_NO"));
                detail.setTantoshaMailAddress(rs.getString("TANTOSHA_MAIL_ADDRESS"));
                detail.setBiko(rs.getString("BIKO"));

                tantoByKaisaichiList.add(detail);
            }

        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return tantoByKaisaichiList;
    }

    /**
     * �J�Òn�R�[�h�E���R�[�h�����ƂɁA�����̉��S���҃R�[�h���擾����B
     * @param kaisaichiCode �J�Òn�R�[�h
     * @param kaijoCode ���R�[�h
     */

    @Override
    public String findLastTantoshaCode(String kaisaichiCode, String kaijoCode) {

        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = "";
        String lastTantoCode = null;

        try {
            con = getConnection();
            sql = "SELECT "
                    + "MAX(tanto.TANTOSHA_CODE) AS TANTOSHA_CODE"
                    + " FROM " + getSchemaName() + "." + KaijoTantoMstDao.TABLE_NAME + " AS tanto"
                    + " WHERE " + "tanto.KAISAICHI_CODE = ?"
                    + " AND " + "tanto.KAIJO_CODE = ?"
                    + " AND " + "tanto.RONRI_SAKUJO_FLG = '0'";

            stmt = con.prepareStatement(sql);
            int i = 1;
            stmt.setString(i++, kaisaichiCode);
            stmt.setString(i++, kaijoCode);
            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();
            
            if (rs.next()) {
                lastTantoCode = rs.getString("TANTOSHA_CODE");
            } else {
                lastTantoCode = null;
            }

        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return lastTantoCode;
    }
    
    /**
     * �J�Òn�R�[�h�Ɖ��R�[�h������S���҂��擾����B
     * @param kaisaichi �J�Òn�R�[�h
     * @param kaijo ���R�[�h
     * @param list ��������
     */
    @Override
    public void findByOneTantosha(String kaisaichi, String kaijo, List<Option> list) {

        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql;

        try {
            con = getConnection();
            sql = "SELECT "
                    + "tantosha.KAISAICHI_CODE AS KAISAICHI_CODE"
                    + ", " + "tantosha.KAIJO_CODE AS KAIJO_CODE"
                    + ", " + "convert_from(bma.decrypt( tantosha.TANTOSHA , 'Pj64W5fr'::bytea, 'aes'::text), 'UTF8'::name) AS TANTOSHA"
                    + ", " + "tantosha.TANTOSHA_CODE AS TANTOSHA_CODE"
                    + " FROM " + getSchemaName() + "." + KaijoTantoMstDao.TABLE_NAME + " AS tantosha"
                    + " WHERE"
                    + " tantosha.KAISAICHI_CODE = ?"
                    + " AND tantosha.KAIJO_CODE = ?"
                    + " AND tantosha.RONRI_SAKUJO_FLG = '0'"
                    + " ORDER BY tantosha.KAISAICHI_CODE ASC, tantosha.KAIJO_CODE ASC";

            stmt = con.prepareStatement(sql);

            int i = 1;
            stmt.setString(i++, kaisaichi);
            stmt.setString(i++, kaijo);
            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();

            while (rs.next()) {
                if (list != null) {
                    list.add(new Option(rs.getString("TANTOSHA_CODE"), rs.getString("TANTOSHA")));
                }
            }

        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
    }
    
    /**
     * �J�Òn�R�[�h�A���R�[�h�A�S���҃R�[�h����v����S���҂��擾����B
     *
     * @param kaisaichiCode �J�Òn�R�[�h
     * @param kaijoCode ���R�[�h
     * @param tantoshaCode �S���҃R�[�h
     */
    @Override
    public String searchTantoshaName(String kaisaichiCode, String kaijoCode, String tantoshaCode) {
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = "";
        String tantoshaName = "";
        
        try {
            con = getConnection();
            sql = "SELECT "
                    + "convert_from(bma.decrypt( tantosha.TANTOSHA , 'Pj64W5fr'::bytea, 'aes'::text), 'UTF8'::name) AS TANTOSHA"
                    + " FROM " + getSchemaName() + "." + KaijoTantoMstDao.TABLE_NAME + " AS tantosha"
                    + " WHERE"
                    + " tantosha.KAISAICHI_CODE = ?"
                    + " AND tantosha.KAIJO_CODE = ?"
                    + " AND tantosha.TANTOSHA_CODE = ?"
                    + " AND tantosha.RONRI_SAKUJO_FLG = '0'"
                    + " ORDER BY tantosha.TANTOSHA_CODE ASC "
                    + " LIMIT 1 ";

            stmt = con.prepareStatement(sql);
            int i = 1;
            stmt.setString(i++, kaisaichiCode);
            stmt.setString(i++, kaijoCode);
            stmt.setString(i++, tantoshaCode);
            LogGenerate.debugOutput(getSql(stmt));

            rs = stmt.executeQuery();

            while (rs.next()) {
                // �S����
                tantoshaName = rs.getString("TANTOSHA");
            }

        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return tantoshaName;
    }
    
    @Override
    public KaijoTantoMst kaijoTantoJohoForShiyoKaijo(String kaisaichiCode, String kaijoCode, String tantoshaCode) {

        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = "";
        KaijoTantoMst tanto = new KaijoTantoMst();

        try {
            con = getConnection();
            sql = "SELECT "
                    + "km.BIKO AS BIKO"
                    + " FROM " + getSchemaName() + "." + KaijoTantoMstDao.TABLE_NAME + " AS km"
                    + " WHERE " + "km.KAISAICHI_CODE = ?"
                    + " AND " + "km.KAIJO_CODE = ?"
                    + " AND " + " km.RONRI_SAKUJO_FLG = '0'";

            stmt = con.prepareStatement(sql);
            int i = 1;
            stmt.setString(i++, kaisaichiCode);
            stmt.setString(i++, kaijoCode);
            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();

            if (rs.next()) {
                //���l
                tanto.setBiko(rs.getString("Biko"));
            } else {
                tanto = null;
            }

        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return tanto;
    }
}