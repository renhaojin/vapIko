package jp.co.nii.bma.integration;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import jp.co.nii.bma.business.domain.MailSoshinRirekiDao;
import jp.co.nii.bma.business.domain.MeishoKanriDao;
import jp.co.nii.bma.business.rto.manager.MgrMailJoho;
import jp.co.nii.bma.business.service.common.BmaConstants;
import jp.co.nii.sew.common.LogGenerate;
import static jp.co.nii.sew.integration.AbstractDao.getSchemaName;
import jp.co.nii.sew.integration.SQLStateSQLExceptionTranslater;

/**
 * ���[�����M���� DAO�����N���X
 *
 * @author DB�Ǘ��c�[��
 */
public class MailSoshinRirekiDaoImpl extends GeneratedMailSoshinRirekiDaoImpl implements MailSoshinRirekiDao {

    /**
     * �C���X�^���X�𐶐�����B
     *
     * @param datasource �f�[�^�\�[�X��
     */
    public MailSoshinRirekiDaoImpl(String datasource) {
        super(datasource);
    }

    /**
     * ��t�ԍ��̃��X�g�𒊏o�B
     *
     * @param search
     * @return ���������f�[�^�i��t�ԍ� ���X�g�j<br>
     */
    @Override
    public List<String> SearchOutIndex(MgrMailJoho search) {
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = "";

        List<String> param = new ArrayList<>();
        List<String> ret = new ArrayList<>();
        try {
            con = getConnection();
            sql = "SELECT mailRieki.MAIL_SOSHIN_RIREKI_IDX as OUT_INDEX "
                    + " FROM " + getSchemaName() + "." + TABLE_NAME + " AS mailRieki"
                    + " LEFT JOIN " + getSchemaName() + "." + MeishoKanriDao.TABLE_NAME + " AS maiStatus"
                    + " ON " + "mailRieki.MAIL_SOSHIN_JOKYO_KBN = maiStatus.HANYO_CODE "
                    + " AND " + "maiStatus.GROUP_CODE = 'MAIL_SOSHIN_JOKYO_KBN' "
                    + " WHERE"
                    + "  mailRieki.RONRI_SAKUJO_FLG = ?";
            param.add(BmaConstants.FLG_OFF);

            sql = makeSql(param, search, sql);

            /* ORDER�� */
            sql += "ORDER BY MAIL_SOSHIN_RIREKI_IDX ";

            stmt = con.prepareStatement(sql);
            int i = 1;
            for (String pm : param) {
                stmt.setString(i++, pm);
            }

            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();
            while (rs.next()) {
                ret.add(rs.getString("OUT_INDEX"));
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return ret;
    }

    /**
     * ���X�g���������[�����M����IDX�̃f�[�^�𒊏o�B
     *
     * @param search
     * @return ���������f�[�^�i�\�� ���X�g�j<br>
     */
    @Override
    public List<MgrMailJoho> findListMailSoshinRireki(MgrMailJoho search) {
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = "";

        List<MgrMailJoho> moshikomiRreki = new ArrayList<>();
        List<String> test = new ArrayList<>();

        test = search.getDispKeyList();
        List<String> param = new ArrayList<>();

        try {
            con = getConnection();
            sql = "SELECT "
                    + " mailRieki.MAIL_SOSHIN_RIREKI_IDX as MAIL_SOSHIN_RIREKI_IDX"
                    + " ,mailRieki.MAIL_KENMEI as MAIL_KENMEI"
                    + " ,mailRieki.MAIL_SOSHIN_KENSU as MAIL_SOSHIN_KENSU"
                    + ", mailRieki.MAIL_FOOTER as MAIL_FOOTER"
                    + ", mailRieki.MAIL_HONBUN as MAIL_HONBUN"
                    + " ,mailRieki.TOROKU_DATE as TOROKU_DATE"
                    + ", mailRieki.TOROKU_TIME as TOROKU_TIME"
                    + ", maiStatus.HANYO_CHI as HANYO_CHI"
                    + " FROM " + getSchemaName() + "." + TABLE_NAME + " AS mailRieki"
                    + " LEFT JOIN " + getSchemaName() + "." + MeishoKanriDao.TABLE_NAME + " AS maiStatus"
                    + " ON " + "mailRieki.MAIL_SOSHIN_JOKYO_KBN = maiStatus.HANYO_CODE "
                    + " AND " + "maiStatus.GROUP_CODE = 'MAIL_SOSHIN_JOKYO_KBN' "
                    + " WHERE"
                    + "  mailRieki.RONRI_SAKUJO_FLG = ?";
            param.add(BmaConstants.FLG_OFF);

            sql = makeSql(param, search, sql);

            /*���������ǉ�*/
            sql += " AND  MAIL_SOSHIN_RIREKI_IDX IN (";
            boolean isFirst = true;

            for (String no : test) {
                if (!isFirst) {
                    sql += ",";
                } else {
                    isFirst = false;
                }
                sql += "?";
                param.add(no);
            }
            sql += ")";

            /* ORDER�� */
            sql += " ORDER BY MAIL_SOSHIN_RIREKI_IDX ";

            /* ����������l���Z�b�g */
            stmt = con.prepareStatement(sql);
            int i = 1;
            for (String pm : param) {
                stmt.setString(i++, pm);
            }

            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();

            while (rs.next()) {
                MgrMailJoho detail = new MgrMailJoho();

                detail.setKenmeiKekka(rs.getString("MAIL_KENMEI"));

                detail.setSosinNinzu(rs.getString("MAIL_SOSHIN_KENSU"));
                
                detail.setSosinFutter(rs.getString("MAIL_FOOTER"));
                detail.setSosinHonbun(rs.getString("MAIL_HONBUN"));
                
                detail.setSoshinDate(rs.getString("TOROKU_DATE") + rs.getString("TOROKU_TIME"));

                detail.setSosinStatus(rs.getString("HANYO_CHI"));

                moshikomiRreki.add(detail);
            }

        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return moshikomiRreki;

    }

    /**
     * ����SQL�쐬<br>
     *
     * @param param �p�����[�^
     * @param search �ۗL���i�}�X�^bean
     * @return �쐬SQL�쐬<br>
     */
    private String makeSql(List<String> param, MgrMailJoho search, String sql) {

        String searchFrom = search.getMailSoshinY_From() + search.getMailSoshinM_From();
        String searchTo = search.getMailSoshinY_To() + search.getMailSoshinM_To();

        if (!searchFrom.isEmpty() && !searchTo.isEmpty()) {
            sql = sql + "and SUBSTR(mailRieki.TOROKU_DATE,1,6)  between   ? and ?";
            param.add(searchFrom);
            param.add(searchTo);
        }
        if (!search.getKenmeiJoken().isEmpty()) {
            sql = sql + "and mailRieki.MAIL_KENMEI like ?";
            param.add("%" + search.getKenmeiJoken() + "%");
        }

        if (!search.getHonbunJoken().isEmpty()) {
            sql = sql + "and mailRieki.MAIL_HONBUN like ?";
            param.add("%" + search.getHonbunJoken() + "%");
        }

        return sql;
    }
}
