package jp.co.nii.sew.presentation;

import java.io.UnsupportedEncodingException;
import javax.servlet.http.HttpServletRequest;
import org.apache.commons.fileupload.FileUploadException;

/**
 *
 * @author n-machida
 */
public interface RequestTransferObject {

    public void setAttribute(HttpServletRequest request)
            throws UnsupportedEncodingException, FileUploadException;

    public void copyFromRequest(HttpServletRequest request);
}
