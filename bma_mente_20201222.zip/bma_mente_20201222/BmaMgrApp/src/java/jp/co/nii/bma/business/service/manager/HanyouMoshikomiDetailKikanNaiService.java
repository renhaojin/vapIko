package jp.co.nii.bma.business.service.manager;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import jp.co.nii.bma.business.domain.MMenjoMst;
import jp.co.nii.bma.business.domain.MShikakuMst;
import jp.co.nii.bma.business.domain.MeishoKanri;
import jp.co.nii.bma.business.domain.ShiyoKaijo;
import jp.co.nii.bma.business.rto.manager.HanyouSearchJoho;
import jp.co.nii.bma.business.service.common.BmaConstants;
import jp.co.nii.bma.business.service.common.BmaLogger;
import jp.co.nii.bma.utility.BmaUtility;
import jp.co.nii.sew.business.service.AbstractService;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_SESSION;
import jp.co.nii.sew.presentation.Messages;
import jp.co.nii.sew.presentation.Option;
import jp.co.nii.sew.presentation.RequestTransferObject;
import jp.co.nii.sew.utility.PropertyUtility;

/**
 * <p>
 * �^�C�g��: �ėp���ԓ��ڍ׉�ʃT�[�r�X</p>
 * <p>
 * ����: �ėp���ԓ��ڍ׉�ʃT�[�r�X</p>
 * <p>
 * ���쌠: Copyright (c) 2020</p>
 * <p>
 * ��Ж�: ���{���Y�Ɗ������</p>
 */
public class HanyouMoshikomiDetailKikanNaiService extends AbstractService {

    /**
     * DB�ڑ��̃f�[�^�\�[�X
     */
    private static String DATA_SOURCE_NAME;
    /**
     * ���O
     */
    BmaLogger log = (BmaLogger) BmaLogger.getLogger(this.getClass().getName());
    /**
     * �Ɩ��R�[�h
     */
    private static final String BUSINESS_CODE = PropertyUtility.getProperty("business_code");

    /**
     * �N�x
     */
    private static final String NEN = PropertyUtility.getProperty(BUSINESS_CODE + "nen");

    /**
     * �R���X�g���N�^
     */
    public HanyouMoshikomiDetailKikanNaiService() {
        super();
        /* DB�ڑ����̃��[�U�[������ */
        DATA_SOURCE_NAME = BmaConstants.DS_REGISTRANT;
    }

    /**
     * �T�[�r�X�N���X�̎��s���\�b�h
     *
     * @param rto ���N�G�X�g��񂩂�擾����rto
     * @param rtoinSession �Z�b�V�������rto
     * @return foward��
     * @throws Exception ��O
     */
    @Override
    public String doService(RequestTransferObject rto, RequestTransferObject rtoinSession)
            throws Exception {

        HanyouSearchJoho inRequest = (HanyouSearchJoho) rto;
        HanyouSearchJoho inSession = (HanyouSearchJoho) rtoinSession;
        String processName = "";

        /*�G���[���b�Z�[�W������*/
        inSession.setErrors(new Messages());

        try {
            if (!BmaUtility.isNullOrEmpty(inRequest.getHayoBack())) {
                /*�u�߂�v�{�^��������*/
                processName = "hayoBack";
                log.Start(processName);

                return FWD_NM_BACK;
            } else if (!BmaUtility.isNullOrEmpty(inRequest.getDelete())) {
                /*�u�ύX�v�{�^��������*/
                processName = "delete";
                log.Start(processName);

                return FWD_NM_NEXT;
            } else if (!BmaUtility.isNullOrEmpty(inRequest.getTempUpdate())) {
                /*�u�ύX�v�{�^��������*/
                processName = "tempUpdate";
                log.Start(processName);

                // ��ꃊ�X�g�擾
                List<Option> list = createKaijoIdList(inSession);
                inSession.setKaijoIdList(list);

                // ��ꃊ�X�g�擾
                List<Option> alllist = createKaijoIdAllList(inSession);
                inSession.setKaijoIdAllList(alllist);

                // ���i��񃊃X�g�擾
                List<Option> shikakuList = createShikakuList(inSession);
                inSession.setShikakuList(shikakuList);

                // �Ə���񃊃X�g�擾
                List<Option> menjoList = createMenjoList(inSession);
                inSession.setMenjoList(menjoList);

                setMeishoList(inSession);
                if (inSession.getMoshikomiFinishBi().length() >= 8) {
                    inSession.setMoshikomikanryoBiYear(inSession.getMoshikomiFinishBi().substring(0, 4));
                    inSession.setMoshikomikanryoBiMonth(inSession.getMoshikomiFinishBi().substring(4, 6));
                    inSession.setMoshikomikanryoBiDay(inSession.getMoshikomiFinishBi().substring(6, 8));
                }
                List<HanyouSearchJoho> shokurekiList = inSession.getShokurekiList();
                for (int i = 0; i < shokurekiList.size(); i++) {
                    HanyouSearchJoho oneGakureki = shokurekiList.get(i);

                    if (oneGakureki.getZaisekikikanFrom().length() >= 6) {
                        oneGakureki.setZaisekikikanFromYear(oneGakureki.getZaisekikikanFrom().substring(0, 4));
                        oneGakureki.setZaisekikikanFromMonth(oneGakureki.getZaisekikikanFrom().substring(4, 6));
                    }
                    if (oneGakureki.getZaisekikikanTo().length() >= 6) {
                        oneGakureki.setZaisekikikanToYear(oneGakureki.getZaisekikikanTo().substring(0, 4));
                        oneGakureki.setZaisekikikanToMonth(oneGakureki.getZaisekikikanTo().substring(4, 6));
                    }
                }
                if (inSession.getGraduationDate().length() >= 6) {
                    inSession.setGraduationDateYear(inSession.getGraduationDate().substring(0, 4));
                    inSession.setGraduationDateMonth(inSession.getGraduationDate().substring(4, 6));
                }

                if (inSession.getKunrenSyuryonenFrom().length() >= 6) {
                    inSession.setKunrenSyuryonenFromYear(inSession.getKunrenSyuryonenFrom().substring(0, 4));
                    inSession.setKunrenSyuryonenFromMonth(inSession.getKunrenSyuryonenFrom().substring(4, 6));
                }
                if (inSession.getKunrenSyuryonenTo().length() >= 6) {
                    inSession.setKunrenSyuryonenToYear(inSession.getKunrenSyuryonenTo().substring(0, 4));
                    inSession.setKunrenSyuryonenToMonth(inSession.getKunrenSyuryonenTo().substring(4, 6));
                }
                if (inSession.getKessaiShiharaiKigenbi().length() >= 8) {
                    inSession.setKessaiShiharaiKigenbiYear(inSession.getKessaiShiharaiKigenbi().substring(0, 4));
                    inSession.setKessaiShiharaiKigenbiMonth(inSession.getKessaiShiharaiKigenbi().substring(4, 6));
                    inSession.setKessaiShiharaiKigenbiDay(inSession.getKessaiShiharaiKigenbi().substring(6, 8));
                }
                if (inSession.getKariUketsukeBi().length() >= 8) {
                    inSession.setKariUketsukeBiYear(inSession.getKariUketsukeBi().substring(0, 4));
                    inSession.setKariUketsukeBiMonth(inSession.getKariUketsukeBi().substring(4, 6));
                    inSession.setKariUketsukeBiDay(inSession.getKariUketsukeBi().substring(6, 8));
                }
                if (inSession.getNyukinBi().length() >= 8) {
                    inSession.setNyukinBiYear(inSession.getNyukinBi().substring(0, 4));
                    inSession.setNyukinBiMonth(inSession.getNyukinBi().substring(4, 6));
                    inSession.setNyukinBiDay(inSession.getNyukinBi().substring(6, 8));
                }
                return FWD_NM_UPDATE;
            } else {
                /*�ُ�J��*/
                log.IllegalFWD();
                return FWD_NM_SESSION;
            }
        } catch (Exception e) {
            throw e;
        } finally {
            log.End(processName);
        }
    }

    /**
     * ���̃��X�g���Z�b�g����B
     *
     * @param inSession
     */
    private void setMeishoList(HanyouSearchJoho inSession) {
        /* ���̊Ǘ��I�u�W�F�N�g�擾 */
        MeishoKanri meisho = new MeishoKanri(DATA_SOURCE_NAME);
        List<Option> list;

        /*�������e���X�g�擾*/
        list = new ArrayList<Option>();
        meisho.findByGroupCode(BmaConstants.SHIKEN_NAIYO_KBN, list);
        list.remove(0); // [00:�敪�Ȃ�]���폜����
        inSession.setSknNaiyoList(list);

        // ���ۏ�
        List<Option> gohiJokyoKbnList = new ArrayList<>();
        meisho.findByGroupCode("GOHI_JOKYO_KBN", gohiJokyoKbnList);
        inSession.setGohiJokyoKbnList(gohiJokyoKbnList);

        /*���ʃ��X�g�擾*/
        list = new ArrayList<>();
        meisho.findByGroupCode(BmaConstants.GENDER, list);
        inSession.setSexList(list);
        // �\�����@
        List<Option> listMoshi = new ArrayList<>();
        meisho.findByGroupCode("MOSHIKOMI_KBN", listMoshi);
        inSession.setMoshikomiKbnList(listMoshi);

        // �\���敪
        List<Option> dkList = new ArrayList<>();
        meisho.findByGroupCode("KOJIN_DANTAI_KBN", dkList);
        inSession.setKojinDantaiKbnList(dkList);

        //�\����
        List<Option> jokyoKbnList = new ArrayList<>();
        meisho.findByGroupCode("MOSHIKOMI_JOKYO_KBN", jokyoKbnList);
        inSession.setMoshikomiJokyoKbnList(jokyoKbnList);

        // �J�Òn
        List<Option> kaisaichi = new ArrayList<>();
        meisho.findByGroupCode("KAISAICHI_CODE", kaisaichi);
        inSession.setKaisaichiCodeList(kaisaichi);

        // �z���t���O
        List<Option> hairyoFlg = new ArrayList<>();
        meisho.findByGroupCode("HAIRYO_FLG", hairyoFlg);
        inSession.setHairyoFlgList(hairyoFlg);

        /*�s���{�����X�g�擾*/
        list = new ArrayList<>();
        meisho.findByGroupCode(BmaConstants.TODOFUKEN, list);
        list.add(0, new Option("", ""));
        inSession.setTodofukenList(list);

        /*���t��敪���X�g�擾*/
        list = new ArrayList<Option>();
        meisho.findByGroupCode(BmaConstants.SOFU_SAKI_KBN, list);

        inSession.setSofusakiList(list);

        /*���N����,�N   1900~���N*/
        list = new ArrayList<>();
        /* �V�X�e�����t�i�N�j���擾 */
        int currentYear = Integer.parseInt(new SimpleDateFormat("yyyy").format(new Date()));
        for (int i = 1900; i <= currentYear; i++) {
            list.add(new Option(i >= 10 ? "" + i : "0" + i, "" + i));
        }
        inSession.setBirthYearList(list);

        /*���N����,��*/
        list = new ArrayList<>();
        for (int i = 1; i <= 12; i++) {
            list.add(new Option(i >= 10 ? "" + i : "0" + i, "" + i));
        }
        inSession.setBirthMonthList(list);
        /*���N����,��*/
        list = new ArrayList<Option>();
        for (int i = 1; i <= 31; i++) {
            list.add(new Option(i >= 10 ? "" + i : "0" + i, "" + i));
        }
        inSession.setBirthDayList(list);
    }

    /**
     * ��ꃊ�X�g�擾
     *
     * @param list
     * @param inSession
     */
    private List<Option> createKaijoIdList(HanyouSearchJoho inSession) {
        /* �ϐ������� */
        List<Option> list = new ArrayList<>();
        ShiyoKaijo shiyoKai = new ShiyoKaijo(BmaConstants.DS_REGISTRANT);

        /* �������X�g��p�� */
        shiyoKai.findKaijoIdList(list, inSession);
        return list;
    }

    /**
     * ��ꃊ�X�g�擾
     *
     * @param list
     * @param inSession
     */
    private List<Option> createKaijoIdAllList(HanyouSearchJoho inSession) {
        /* �ϐ������� */
        List<Option> list = new ArrayList<>();
        ShiyoKaijo shiyoKai = new ShiyoKaijo(BmaConstants.DS_REGISTRANT);

        /* �������X�g��p�� */
        shiyoKai.findKaijoIdAllList(list, inSession);
        return list;
    }

    /**
     * ���i��񃊃X�g�擾
     *
     * @param list
     * @param inSession
     */
    private List<Option> createShikakuList(HanyouSearchJoho inSession) {
        /* �ϐ������� */
        List<Option> list = new ArrayList<>();
        // �u�\�����i�Ə��Ǘ��v�y���i�R�[�h�z���u�\�����i�}�X�^�v�y���i�ڍׁz	
        MShikakuMst mShikakuMst = new MShikakuMst(DATA_SOURCE_NAME);

        /* �������X�g��p�� */
        mShikakuMst.findShikakuList(list, inSession);
        return list;
    }

    /**
     * ���i�Ə���񃊃X�g�擾
     *
     * @param list
     * @param inSession
     */
    private List<Option> createMenjoList(HanyouSearchJoho inSession) {
        /* �ϐ������� */
        List<Option> list = new ArrayList<>();
        MMenjoMst mMenjoMst = new MMenjoMst(DATA_SOURCE_NAME);

        /* �������X�g��p�� */
        mMenjoMst.findMenjoList(list, inSession);
        return list;
    }
}
