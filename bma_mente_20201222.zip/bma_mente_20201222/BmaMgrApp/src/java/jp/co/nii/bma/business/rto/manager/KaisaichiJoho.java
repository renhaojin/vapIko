package jp.co.nii.bma.business.rto.manager;

import java.util.List;
import javax.servlet.http.HttpServletRequest;
import jp.co.nii.sew.presentation.AbstractRequestTransferObject;

/**
 *
 * @author nii19049
 */
public class KaisaichiJoho extends AbstractRequestTransferObject {
    
    //�J�Òn�ڍ׃f�[�^
    private List<KaisaichiJoho> kaisaichiDetailList;
    private List<KaisaichiJoho> kaisaichiNameList;
    
    private String kaisaichiCode;
    private String KaisaichiName;
    private String kaijoCode;
    private String kaijoName;
    private String kaijoNameRyaku;
    private String yubinNo;
    private String jusho;
    private String teiin;
    private String kaijoHenkoFlg;
    private String chushajoFlg;
    private String chizuData;
    private String biko;
    
    //�y�[�W�J�ڗp�F�J�ڐ�y�[�W
    private int page;
    

    
    public void clearInfo() {
        setKaisaichiCode("");
        setKaisaichiName("");
        setKaijoCode("");
        setKaijoName("");
        setKaijoNameRyaku("");
        setYubinNo("");
        setJusho("");
        setTeiin("");
        setKaijoHenkoFlg("");
        setChushajoFlg("");
        setChizuData("");
        setBiko("");
        
    }
    /**
     * @return the kaisaichiCode
     */
    public String getKaisaichiCode() {
        return kaisaichiCode;
    }

    /**
     * @param kaisaichiCode the kaisaichiCode to set
     */
    public void setKaisaichiCode(String kaisaichiCode) {
        this.kaisaichiCode = kaisaichiCode;
    }

    /**
     * @return the kaisaichiName
     */
    public String getKaijoCode() {
        return kaijoCode;
    }

    /**
     * @param kaijoCode the kaisaichiName to set
     */
    public void setKaijoCode(String kaijoCode) {
        this.kaijoCode = kaijoCode;
    }

    /**
     * @return the kaisaichiList
     */
    public List<KaisaichiJoho> getKaisaichiDetailList() {
        return kaisaichiDetailList;
    }

    /**
     * @param kaisaichiDetailList the kaisaichiList to set
     */
    public void setKaisaichiDetailList(List<KaisaichiJoho> kaisaichiDetailList) {
        this.kaisaichiDetailList = kaisaichiDetailList;
    }
    
    @Override
    public void copyFromRequest(HttpServletRequest request) {
        setKaisaichiCode((String) request.getAttribute("kaisaichiCode"));
        setKaisaichiName((String) request.getAttribute("kaisaichiName"));
        setKaijoCode((String) request.getAttribute("kaijoCode"));
        setKaijoName((String) request.getAttribute("kaijoName"));
        setKaijoNameRyaku((String) request.getAttribute("kaijoNameRyaku"));
        setYubinNo((String) request.getAttribute("yubinNo"));
        setJusho((String) request.getAttribute("jusho"));
        setTeiin((String) request.getAttribute("teiin"));
        setKaijoHenkoFlg((String) request.getAttribute("kaijoHenkoFlg"));
        setChushajoFlg((String) request.getAttribute("chushajoFlg"));
        setChizuData((String) request.getAttribute("chizuData"));
        setBiko((String) request.getAttribute("biko"));
    }

    /**
     * @return the kaijoName
     */
    public String getKaijoName() {
        return kaijoName;
    }

    /**
     * @param kaijoName the kaijoName to set
     */
    public void setKaijoName(String kaijoName) {
        this.kaijoName = kaijoName;
    }

    /**
     * @return the jusho
     */
    public String getJusho() {
        return jusho;
    }

    /**
     * @param jusho the jusho to set
     */
    public void setJusho(String jusho) {
        this.jusho = jusho;
    }

    /**
     * @return the teiin
     */
    public String getTeiin() {
        return teiin;
    }

    /**
     * @param teiin the teiin to set
     */
    public void setTeiin(String teiin) {
        this.teiin = teiin;
    }

    /**
     * @return the page
     */
    public int getPage() {
        return page;
    }

    /**
     * @param page the page to set
     */
    public void setPage(int page) {
        this.page = page;
    }

    /**
     * @return the kaijoNameRyaku
     */
    public String getKaijoNameRyaku() {
        return kaijoNameRyaku;
    }

    /**
     * @param kaijoNameRyaku the kaijoNameRyaku to set
     */
    public void setKaijoNameRyaku(String kaijoNameRyaku) {
        this.kaijoNameRyaku = kaijoNameRyaku;
    }

    /**
     * @return the yubinNo
     */
    public String getYubinNo() {
        return yubinNo;
    }

    /**
     * @param yubinNo the yubinNo to set
     */
    public void setYubinNo(String yubinNo) {
        this.yubinNo = yubinNo;
    }

    /**
     * @return the kaijoHenkoFlg
     */
    public String getKaijoHenkoFlg() {
        return kaijoHenkoFlg;
    }

    /**
     * @param kaijoHenkoFlg the kaijoHenkoFlg to set
     */
    public void setKaijoHenkoFlg(String kaijoHenkoFlg) {
        this.kaijoHenkoFlg = kaijoHenkoFlg;
    }

    /**
     * @return the chushajoFlg
     */
    public String getChushajoFlg() {
        return chushajoFlg;
    }

    /**
     * @param chushajoFlg the chushajoFlg to set
     */
    public void setChushajoFlg(String chushajoFlg) {
        this.chushajoFlg = chushajoFlg;
    }

    /**
     * @return the chizuDate
     */
    public String getChizuData() {
        return chizuData;
    }

    /**
     * @param chizuData the chizuDate to set
     */
    public void setChizuData(String chizuData) {
        this.chizuData = chizuData;
    }

    /**
     * @return the biko
     */
    public String getBiko() {
        return biko;
    }

    /**
     * @param biko the biko to set
     */
    public void setBiko(String biko) {
        this.biko = biko;
    }

    /**
     * @return the KaisaichiName
     */
    public String getKaisaichiName() {
        return KaisaichiName;
    }

    /**
     * @param KaisaichiName the KaisaichiName to set
     */
    public void setKaisaichiName(String KaisaichiName) {
        this.KaisaichiName = KaisaichiName;
    }

    /**
     * @return the kaisaichiNameList
     */
    public List<KaisaichiJoho> getKaisaichiNameList() {
        return kaisaichiNameList;
    }

    /**
     * @param kaisaichiNameList the kaisaichiNameList to set
     */
    public void setKaisaichiNameList(List<KaisaichiJoho> kaisaichiNameList) {
        this.kaisaichiNameList = kaisaichiNameList;
    }
    
}
