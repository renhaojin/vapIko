package jp.co.nii.bma.business.rto.manager;

import java.util.List;

/**
 * �^�C�g��: TOP��� ����: TOP���RTO ���쌠: Copyright (c) 2020 ��Ж�: ���{���Y�Ɗ������
 */
public class HanyouSelectJoho {

    private String birthday;
    private String fax_no;
    private String furigana;
    private String gaiji_flg_nm;
    private String gaiji_shosai;
    private String genmen_nm;
    private String gohi_jokyo_nm;
    private String gokaku_bi;
    private String gokaku_no;
    private String goukaku_no_gakka;
    private String goukaku_no_jitsugi;
    private String hairyo_flg_nm;
    private String hairyo_naiyo;
    private String juken_juko_no;
    private String jusho_1;
    private String jusho_2;
    private String kaiin_kbn_nm;
    private String kaiin_shinsei_nm;
    private String kaijo_nm_1;
    private String kaijo_nm_2;
    private String kaisaichi_nm_1;
    private String kaisaichi_nm_2;
    private String kaisu_code;
    private String kanri_memo;
    private String kessai_bng;
    private String kessai_date;
    private String kessai_hoho_nm;
    private String kessai_kingaku;
    private String kessai_kingaku_total;
    private String kessai_tesuryo;
    private String kessai_time;
    private String kigyo_code;
    private String kigyo_hp_url;
    private String kinmusaki_fax_no;
    private String kinmusaki_jusho_1;
    private String kinmusaki_jusho_2;
    private String kinmusaki_tatemono;
    private String kinmusaki_tel_no;
    private String kinmusaki_todofuken_nm;
    private String kinmusaki_yubin_no;
    private String kojin_dantai_nm;
    private String kyokai_name;
    private String mail_address;
    private String moshikomi_jokyo_nm;
    private String moshikomi_nm;
    private String muryo_zan_count;
    private String nendo;
    private String nenrei;
    private String sex_nm;
    private String shiken_naiyo_nm;
    private String shimei;
    private String shubetsu_name;
    private String skn_ksu_nm;
    private String sofu_saki_nm;
    private String tatemono;
    private String tel_no;
    private String todofuken_nm;
    private String uketsuke_no;
    private String yubin_no;
    private String yuko_kigen_menjo;
    private String yuko_kigen_shikaku;

    public String getBirthday() {
        return birthday;
    }

    public void setBirthday(String birthday) {
        this.birthday = birthday;
    }

    public String getFax_no() {
        return fax_no;
    }

    public void setFax_no(String fax_no) {
        this.fax_no = fax_no;
    }

    public String getFurigana() {
        return furigana;
    }

    public void setFurigana(String furigana) {
        this.furigana = furigana;
    }

    public String getGaiji_flg_nm() {
        return gaiji_flg_nm;
    }

    public void setGaiji_flg_nm(String gaiji_flg_nm) {
        this.gaiji_flg_nm = gaiji_flg_nm;
    }

    public String getGaiji_shosai() {
        return gaiji_shosai;
    }

    public void setGaiji_shosai(String gaiji_shosai) {
        this.gaiji_shosai = gaiji_shosai;
    }

    public String getGenmen_nm() {
        return genmen_nm;
    }

    public void setGenmen_nm(String genmen_nm) {
        this.genmen_nm = genmen_nm;
    }

    public String getGohi_jokyo_nm() {
        return gohi_jokyo_nm;
    }

    public void setGohi_jokyo_nm(String gohi_jokyo_nm) {
        this.gohi_jokyo_nm = gohi_jokyo_nm;
    }

    public String getGokaku_bi() {
        return gokaku_bi;
    }

    public void setGokaku_bi(String gokaku_bi) {
        this.gokaku_bi = gokaku_bi;
    }

    public String getGokaku_no() {
        return gokaku_no;
    }

    public void setGokaku_no(String gokaku_no) {
        this.gokaku_no = gokaku_no;
    }

    public String getGoukaku_no_gakka() {
        return goukaku_no_gakka;
    }

    public void setGoukaku_no_gakka(String goukaku_no_gakka) {
        this.goukaku_no_gakka = goukaku_no_gakka;
    }

    public String getGoukaku_no_jitsugi() {
        return goukaku_no_jitsugi;
    }

    public void setGoukaku_no_jitsugi(String goukaku_no_jitsugi) {
        this.goukaku_no_jitsugi = goukaku_no_jitsugi;
    }

    public String getHairyo_flg_nm() {
        return hairyo_flg_nm;
    }

    public void setHairyo_flg_nm(String hairyo_flg_nm) {
        this.hairyo_flg_nm = hairyo_flg_nm;
    }

    public String getHairyo_naiyo() {
        return hairyo_naiyo;
    }

    public void setHairyo_naiyo(String hairyo_naiyo) {
        this.hairyo_naiyo = hairyo_naiyo;
    }

    public String getJuken_juko_no() {
        return juken_juko_no;
    }

    public void setJuken_juko_no(String juken_juko_no) {
        this.juken_juko_no = juken_juko_no;
    }

    public String getJusho_1() {
        return jusho_1;
    }

    public void setJusho_1(String jusho_1) {
        this.jusho_1 = jusho_1;
    }

    public String getJusho_2() {
        return jusho_2;
    }

    public void setJusho_2(String jusho_2) {
        this.jusho_2 = jusho_2;
    }

    public String getKaiin_kbn_nm() {
        return kaiin_kbn_nm;
    }

    public void setKaiin_kbn_nm(String kaiin_kbn_nm) {
        this.kaiin_kbn_nm = kaiin_kbn_nm;
    }

    public String getKaiin_shinsei_nm() {
        return kaiin_shinsei_nm;
    }

    public void setKaiin_shinsei_nm(String kaiin_shinsei_nm) {
        this.kaiin_shinsei_nm = kaiin_shinsei_nm;
    }

    public String getKaijo_nm_1() {
        return kaijo_nm_1;
    }

    public void setKaijo_nm_1(String kaijo_nm_1) {
        this.kaijo_nm_1 = kaijo_nm_1;
    }

    public String getKaijo_nm_2() {
        return kaijo_nm_2;
    }

    public void setKaijo_nm_2(String kaijo_nm_2) {
        this.kaijo_nm_2 = kaijo_nm_2;
    }

    public String getKaisaichi_nm_1() {
        return kaisaichi_nm_1;
    }

    public void setKaisaichi_nm_1(String kaisaichi_nm_1) {
        this.kaisaichi_nm_1 = kaisaichi_nm_1;
    }

    public String getKaisaichi_nm_2() {
        return kaisaichi_nm_2;
    }

    public void setKaisaichi_nm_2(String kaisaichi_nm_2) {
        this.kaisaichi_nm_2 = kaisaichi_nm_2;
    }

    public String getKaisu_code() {
        return kaisu_code;
    }

    public void setKaisu_code(String kaisu_code) {
        this.kaisu_code = kaisu_code;
    }

    public String getKanri_memo() {
        return kanri_memo;
    }

    public void setKanri_memo(String kanri_memo) {
        this.kanri_memo = kanri_memo;
    }

    public String getKessai_bng() {
        return kessai_bng;
    }

    public void setKessai_bng(String kessai_bng) {
        this.kessai_bng = kessai_bng;
    }

    public String getKessai_date() {
        return kessai_date;
    }

    public void setKessai_date(String kessai_date) {
        this.kessai_date = kessai_date;
    }

    public String getKessai_hoho_nm() {
        return kessai_hoho_nm;
    }

    public void setKessai_hoho_nm(String kessai_hoho_nm) {
        this.kessai_hoho_nm = kessai_hoho_nm;
    }

    public String getKessai_kingaku() {
        return kessai_kingaku;
    }

    public void setKessai_kingaku(String kessai_kingaku) {
        this.kessai_kingaku = kessai_kingaku;
    }

    public String getKessai_kingaku_total() {
        return kessai_kingaku_total;
    }

    public void setKessai_kingaku_total(String kessai_kingaku_total) {
        this.kessai_kingaku_total = kessai_kingaku_total;
    }

    public String getKessai_tesuryo() {
        return kessai_tesuryo;
    }

    public void setKessai_tesuryo(String kessai_tesuryo) {
        this.kessai_tesuryo = kessai_tesuryo;
    }

    public String getKessai_time() {
        return kessai_time;
    }

    public void setKessai_time(String kessai_time) {
        this.kessai_time = kessai_time;
    }

    public String getKigyo_code() {
        return kigyo_code;
    }

    public void setKigyo_code(String kigyo_code) {
        this.kigyo_code = kigyo_code;
    }

    public String getKigyo_hp_url() {
        return kigyo_hp_url;
    }

    public void setKigyo_hp_url(String kigyo_hp_url) {
        this.kigyo_hp_url = kigyo_hp_url;
    }

    public String getKinmusaki_fax_no() {
        return kinmusaki_fax_no;
    }

    public void setKinmusaki_fax_no(String kinmusaki_fax_no) {
        this.kinmusaki_fax_no = kinmusaki_fax_no;
    }

    public String getKinmusaki_jusho_1() {
        return kinmusaki_jusho_1;
    }

    public void setKinmusaki_jusho_1(String kinmusaki_jusho_1) {
        this.kinmusaki_jusho_1 = kinmusaki_jusho_1;
    }

    public String getKinmusaki_jusho_2() {
        return kinmusaki_jusho_2;
    }

    public void setKinmusaki_jusho_2(String kinmusaki_jusho_2) {
        this.kinmusaki_jusho_2 = kinmusaki_jusho_2;
    }

    public String getKinmusaki_tatemono() {
        return kinmusaki_tatemono;
    }

    public void setKinmusaki_tatemono(String kinmusaki_tatemono) {
        this.kinmusaki_tatemono = kinmusaki_tatemono;
    }

    public String getKinmusaki_tel_no() {
        return kinmusaki_tel_no;
    }

    public void setKinmusaki_tel_no(String kinmusaki_tel_no) {
        this.kinmusaki_tel_no = kinmusaki_tel_no;
    }

    public String getKinmusaki_todofuken_nm() {
        return kinmusaki_todofuken_nm;
    }

    public void setKinmusaki_todofuken_nm(String kinmusaki_todofuken_nm) {
        this.kinmusaki_todofuken_nm = kinmusaki_todofuken_nm;
    }

    public String getKinmusaki_yubin_no() {
        return kinmusaki_yubin_no;
    }

    public void setKinmusaki_yubin_no(String kinmusaki_yubin_no) {
        this.kinmusaki_yubin_no = kinmusaki_yubin_no;
    }

    public String getKojin_dantai_nm() {
        return kojin_dantai_nm;
    }

    public void setKojin_dantai_nm(String kojin_dantai_nm) {
        this.kojin_dantai_nm = kojin_dantai_nm;
    }

    public String getKyokai_name() {
        return kyokai_name;
    }

    public void setKyokai_name(String kyokai_name) {
        this.kyokai_name = kyokai_name;
    }

    public String getMail_address() {
        return mail_address;
    }

    public void setMail_address(String mail_address) {
        this.mail_address = mail_address;
    }

    public String getMoshikomi_jokyo_nm() {
        return moshikomi_jokyo_nm;
    }

    public void setMoshikomi_jokyo_nm(String moshikomi_jokyo_nm) {
        this.moshikomi_jokyo_nm = moshikomi_jokyo_nm;
    }

    public String getMoshikomi_nm() {
        return moshikomi_nm;
    }

    public void setMoshikomi_nm(String moshikomi_nm) {
        this.moshikomi_nm = moshikomi_nm;
    }

    public String getMuryo_zan_count() {
        return muryo_zan_count;
    }

    public void setMuryo_zan_count(String muryo_zan_count) {
        this.muryo_zan_count = muryo_zan_count;
    }

    public String getNendo() {
        return nendo;
    }

    public void setNendo(String nendo) {
        this.nendo = nendo;
    }

    public String getNenrei() {
        return nenrei;
    }

    public void setNenrei(String nenrei) {
        this.nenrei = nenrei;
    }

    public String getSex_nm() {
        return sex_nm;
    }

    public void setSex_nm(String sex_nm) {
        this.sex_nm = sex_nm;
    }

    public String getShiken_naiyo_nm() {
        return shiken_naiyo_nm;
    }

    public void setShiken_naiyo_nm(String shiken_naiyo_nm) {
        this.shiken_naiyo_nm = shiken_naiyo_nm;
    }

    public String getShimei() {
        return shimei;
    }

    public void setShimei(String shimei) {
        this.shimei = shimei;
    }

    public String getShubetsu_name() {
        return shubetsu_name;
    }

    public void setShubetsu_name(String shubetsu_name) {
        this.shubetsu_name = shubetsu_name;
    }

    public String getSkn_ksu_nm() {
        return skn_ksu_nm;
    }

    public void setSkn_ksu_nm(String skn_ksu_nm) {
        this.skn_ksu_nm = skn_ksu_nm;
    }

    public String getSofu_saki_nm() {
        return sofu_saki_nm;
    }

    public void setSofu_saki_nm(String sofu_saki_nm) {
        this.sofu_saki_nm = sofu_saki_nm;
    }

    public String getTatemono() {
        return tatemono;
    }

    public void setTatemono(String tatemono) {
        this.tatemono = tatemono;
    }

    public String getTel_no() {
        return tel_no;
    }

    public void setTel_no(String tel_no) {
        this.tel_no = tel_no;
    }

    public String getTodofuken_nm() {
        return todofuken_nm;
    }

    public void setTodofuken_nm(String todofuken_nm) {
        this.todofuken_nm = todofuken_nm;
    }

    public String getUketsuke_no() {
        return uketsuke_no;
    }

    public void setUketsuke_no(String uketsuke_no) {
        this.uketsuke_no = uketsuke_no;
    }

    public String getYubin_no() {
        return yubin_no;
    }

    public void setYubin_no(String yubin_no) {
        this.yubin_no = yubin_no;
    }

    public String getYuko_kigen_menjo() {
        return yuko_kigen_menjo;
    }

    public void setYuko_kigen_menjo(String yuko_kigen_menjo) {
        this.yuko_kigen_menjo = yuko_kigen_menjo;
    }

    public String getYuko_kigen_shikaku() {
        return yuko_kigen_shikaku;
    }

    public void setYuko_kigen_shikaku(String yuko_kigen_shikaku) {
        this.yuko_kigen_shikaku = yuko_kigen_shikaku;
    }

}
