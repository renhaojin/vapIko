package jp.co.nii.bma.business.rto.manager;

import java.util.ArrayList;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import jp.co.nii.bma.business.service.common.BmaConstants;
import jp.co.nii.bma.utility.BmaDateTimeUtility;
import jp.co.nii.sew.presentation.DownloadRTO;
import jp.co.nii.sew.presentation.Messages;
import jp.co.nii.sew.presentation.Option;
import jp.co.nii.sew.utility.StringUtility;
import org.apache.commons.fileupload.disk.DiskFileItem;

/**
 * �^�C�g��: TOP��� ����: TOP���RTO ���쌠: Copyright (c) 2020 ��Ж�: ���{���Y�Ɗ������
 */
public class MgrMailJoho extends DownloadRTO {

    private String tmpMailId;
    private String tmpName;
    private String kenName;
    private String koshinDate;
    private String tmpHonbun;
    private String tmpFutter;
    private String tmpHonbunBr;
    private String tmpFutterBr;

    /**
     * �o�^���[�U�[�h�c
     */
    private String userId;
    /**
     * �\���҂h�c
     */
    private String moshikomishaId;
    /**
     * �g�b�v��� ���[�������{�^��
     */
    private String noKanri;
    /**
     * �g�b�v��� �}�X�N�Ǘ��{�^��
     */
    private String mstKanri;

    /**
     * �g�b�v��� �e���v���[�g�쐬�E�ҏW�{�^��
     */
    private String tmpSakuseiHenshu;
    /**
     * �g�b�v��� �ꊇ���[�����M�{�^��
     */
    private String ikkatsuMailSosin;
    /**
     * �g�b�v��� ���[�����M�����{�^��
     */
    private String mailSendRireki;
    private String shinkiSakusei;
    /**
     * ���[���e���v���[�g�V�K�o�^���� �m�F�{�^��
     */
    private String tmpInpNext;
    /**
     * ���[���e���v���[�g�ڍׂɖ߂�
     */
    private String tmpInpBack;
    /**
     * ���[���e���v���[�g�V�K�o�^���� �߂�{�^�� ���[���e���v���[�g���͂ɖ߂�
     */
    private String tmpNewBack;

    /**
     * ���[���e���v���[�g�V�K�o�^�m�F �����{�^��
     */
    private String tmpInpConfilmNext;
    /**
     * ���[���e���v���[�g�V�K�o�^�m�F �����{�^��
     */
    private String tmpInpConfilmBack;
    /**
     * ���[���e���v���[�g�V�K�o�^�m���� �ꗗ�߂�{�^��
     */
    private String tmpInpKanryoBack;

    /**
     * ���[���e���v���[�g�ڍ� �폜�{�^��
     */
    private String tmpShosaiDelete;

    /**
     * ���[���e���v���[�g�ڍ� �����{�^��
     */
    private String tmpShosaiCopy;
    /**
     * ���[���e���v���[�g�ڍ� �ύX�{�^��
     */
    private String tmpShosaiUpd;
    /**
     * ���[���e���v���[�g�ڍ� �߂�{�^��
     */
    private String tmpShosaiBack;
    /**
     * ���[���e���v���[�g�ύX �߂�{�^��
     */
    private String tmpUpdBack;
    /**
     * ���[���e���v���[�g�ύX �m�F�{�^��
     */
    private String tmpUpdConfilm;
    /**
     * ���[���e���v���[�g���� �ꗗ�߂�{�^��
     */
    private String tmpUpdKanryoBack;
    /**
     * ���[���e���v���[�g�폜�m�F �߂�{�^��
     */
    private String tmpDeleteConfilmBack;

    /**
     * ���[���ڍׁ@���X�g
     */
    private List<MgrMailJoho> mailDetailList;
    /**
     * ���[�����M�ΏێҌ������ʈꗗ���X�g
     */
    private List<MgrMailJoho> mailSendlList;
    /**
     * ���[�U�[����{���ɐݒ肷�� �`�F�b�N�{�b�N�X
     */
    private String shiyoFlg;

    // ��������y���[���Ǘ��z���M�Ώێ�
    private String searchJoken;
    private String uketukeNo;
    private String simei;
    private String mailaddress;
    private String[] chkTaishoChoice;
    private DiskFileItem mskFileChoice;
    private String[] chkList;
    private String checkFlg;
    /**
     * ���[���e���v���[�g�폜�m�F �m��{�^��
     */
    private String tmpDeleteConfilmKakutei;
    ArrayList<String[]> csvDataList;
    /**
     * ���[���e���v���[�gNo
     */
    private String srcTempNo;
    /**
     * ���[���e���v���[�g���X�g
     */
    private List<Option> maillList;
    /**
     * ���M�����N���X�g
     */
    List<Option> sousinYearList;
    /**
     * ���M���������X�g
     */
    List<Option> sousinMonthList;
    /**
     * �Z�b�V�����p�\�������J�n
     */
    private int firstDisp;
    /**
     * �Z�b�V�����p�\�������ő包��
     */
    private int maxDisp;
    /**
     * �y�[�W�J�ڗp�F�J�ڐ�y�[�W
     */
    private int page;
    /**
     * �y�[�W�J�ڗp�F���ڈړ��Œ�l
     */
    private int pageBegin;
    /**
     * �y�[�W�J�ڗp�F���ڈړ��ő�l
     */
    private int pageEnd;
    /**
     * �y�[�W�J�ڗp�F�ő�y�[�W��
     */
    private int pageMax;

    /**
     * �R�}���h �y�[�W�J��
     */
    private String commandPage;
    /**
     * ��������
     */
    private List<String> dispKeyList;
    /**
     * ��������index���X�g
     */
    private List<String> searchOutIndex;

    /**
     * ���[�����M�ΏێҌ������ʈꗗ�@�߂�{�^��
     */
    private String searchKekkaListBack;
    /**
     * ���[�����M�ΏێҌ������ʈꗗ �m�F�{�^��
     */
    private String searchKekkaListConfilm;

    private String mailSoshinTaisho;
    /**
     * ���[���e���v���[�g�ύX���͊m�F �߂�{�^��
     */
    private String ikkatsuMailSoshinConfilmBack;
    /**
     * ���[���e���v���[�g�ύX���͊m�F ���M�{�^��
     */
    private String ikkatsuMailSoshin;
    /**
     * �ꊇ���[�����M�w������ �����ă��[���𑗐M�{�^��
     */
    private String tsuduketeMailSoshin;
    /**
     * �ꊇ���[�����M�Ώێ҃A�b�v���[�h �A�b�v���[�h�{�^��
     */
    private String ikkatsuMailSosinTaishoUl;

    private String lineNo;
    private String columnNo;
    private String itemName;
    private String message;
    private String errorLogFlg;
    // �G���[���X�g
    private List<MgrMailJoho> errorLog;

// ��������y���[���Ǘ��z���M����p
    private String mailSoshinY_From;
    private String mailSoshinM_From;
    private String mailSoshinY_To;
    private String mailSoshinM_To;
    private String kenmeiJoken;
    private String honbunJoken;
    private String soshinDate;
    private String kenmeiKekka;
    private String sosinNinzu;
    private String sosinStatus;
    private String sosinFutter;
    private String sosinHonbun;

    /**
     * ���M���� ���̓N���A�{�^��
     */
    private String inpClear;
    /**
     * ���M���� �����{�^��
     */
    private String search;
    /**
     * ���M�ڍ� �߂�{�^��
     */
    private String mailSoshinRrkBack;

    private String mailSoshinDate;
    private String mailSoshinNinzu;
    private String mailSoshinStatus;
    private String shosai;
    /**
     * �G���[
     */
    private Messages errors;

    //�R���X�g���N�^/������/���N�G�X�g�擾
    /**
     * �R���X�g���N�^
     */
    public MgrMailJoho() {
        clearInfo();
    }

    /**
     * ���������\�b�h
     */
    public void clearInfo() {
        setTmpMailId("");
        setTmpName("");
        setKenName("");
        setKoshinDate("");
        setTmpHonbun("");
        setTmpFutter("");
        setTmpHonbunBr("");
        setTmpFutterBr("");
        setMoshikomishaId("");
        setNoKanri("");
        setMstKanri("");
        setTmpSakuseiHenshu("");
        setIkkatsuMailSosin("");
        setMailSendRireki("");
        setShinkiSakusei("");
        setTmpInpNext("");
        setTmpInpBack("");
        setTmpInpConfilmNext("");
        setTmpInpConfilmBack("");
        setTmpInpKanryoBack("");
        setTmpShosaiDelete("");
        setTmpShosaiCopy("");
        setTmpShosaiUpd("");
        setTmpShosaiBack("");
        setTmpUpdBack("");
        setTmpUpdConfilm("");
        setTmpUpdKanryoBack("");
        setTmpDeleteConfilmBack("");
        setMailDetailList(new ArrayList<>());
        setMailSendlList(new ArrayList<>());
        setSearchJoken("");
        setUketukeNo("");
        setSimei("");
        setMailaddress("");
        setTmpDeleteConfilmKakutei("");
        setSrcTempNo("");
        setMaillList(new ArrayList<>());
        setFirstDisp(0);
        setMaxDisp(0);
        setPage(0);
        setPageBegin(0);
        setPageEnd(0);
        setPageMax(0);;
        setDispKeyList(new ArrayList<>());
        setSearchOutIndex(new ArrayList<>());
        setSearchKekkaListBack("");
        setSearchKekkaListConfilm("");
        setMailSoshinTaisho("");
        setIkkatsuMailSoshinConfilmBack("");
        setIkkatsuMailSoshin("");
        setTsuduketeMailSoshin("");
        setIkkatsuMailSosinTaishoUl("");
        setMailSoshinY_From("");
        setMailSoshinM_From("");
        setMailSoshinY_To("");
        setMailSoshinM_To("");
        setKenmeiJoken("");
        setHonbunJoken("");
        setSoshinDate("");
        setKenmeiKekka("");
        setSosinNinzu("");
        setSosinStatus("");

        setErrorLog(new ArrayList<>());
        setErrorLogFlg(BmaConstants.FLG_OFF);
        setInpClear("");
        setSearch("");
        setMailSoshinRrkBack("");
        setMailSoshinDate("");
        setMailSoshinNinzu("");
        setMailSoshinStatus("");
        setShosai("");
    }

    /**
     * ���N�G�X�g��������擾���郁�\�b�h
     *
     * @param request ���N�G�X�g
     */
    @Override
    public void copyFromRequest(HttpServletRequest request) {
        //�o�^��
        setNoKanri((String) request.getAttribute("noKanri"));
        setMstKanri((String) request.getAttribute("mstKanri"));
        setTmpSakuseiHenshu((String) request.getAttribute("tmpSakuseiHenshu"));
        setIkkatsuMailSosin((String) request.getAttribute("ikkatsuMailSosin"));
        setMailSendRireki((String) request.getAttribute("mailSendRireki"));

        setTmpInpNext((String) request.getAttribute("tmpInpNext"));
        setTmpInpBack((String) request.getAttribute("tmpInpBack"));
        setTmpNewBack((String) request.getAttribute("tmpNewBack"));

        setMailSoshinY_From((String) request.getAttribute("mailSoshinY_From"));
        setMailSoshinY_To((String) request.getAttribute("mailSoshinY_To"));
        setMailSoshinM_From((String) request.getAttribute("mailSoshinM_From"));
        setMailSoshinM_To((String) request.getAttribute("mailSoshinM_To"));

        setKenmeiJoken((String) request.getAttribute("kenmeiJoken"));
        setHonbunJoken((String) request.getAttribute("honbunJoken"));
        setCommandPage((String) request.getAttribute("commandPage"));

        setTmpInpConfilmNext((String) request.getAttribute("tmpInpConfilmNext"));
        setTmpInpConfilmBack((String) request.getAttribute("tmpInpConfilmBack"));
        setSrcTempNo((String) request.getAttribute("srcTempNo"));

        setTmpInpKanryoBack((String) request.getAttribute("tmpInpKanryoBack"));

        setTmpShosaiDelete((String) request.getAttribute("tmpShosaiDelete"));
        setTmpShosaiCopy((String) request.getAttribute("tmpShosaiCopy"));
        setTmpShosaiUpd((String) request.getAttribute("tmpShosaiUpd"));
        setTmpShosaiBack((String) request.getAttribute("tmpShosaiBack"));

        setTmpUpdBack((String) request.getAttribute("tmpUpdBack"));
        setTmpUpdConfilm((String) request.getAttribute("tmpUpdConfilm"));
        setShinkiSakusei((String) request.getAttribute("shinkiSakusei"));
        setTmpUpdKanryoBack((String) request.getAttribute("tmpUpdKanryoBack"));

        setTmpDeleteConfilmBack((String) request.getAttribute("tmpDeleteConfilmBack"));
        setTmpDeleteConfilmKakutei((String) request.getAttribute("tmpDeleteConfilmKakutei"));

        setSearchKekkaListBack((String) request.getAttribute("searchKekkaListBack"));
        setSearchKekkaListConfilm((String) request.getAttribute("searchKekkaListConfilm"));

        setIkkatsuMailSoshinConfilmBack((String) request.getAttribute("ikkatsuMailSoshinConfilmBack"));
        setIkkatsuMailSoshin((String) request.getAttribute("ikkatsuMailSoshin"));

        setTsuduketeMailSoshin((String) request.getAttribute("tsuduketeMailSoshin"));

        setIkkatsuMailSosinTaishoUl((String) request.getAttribute("ikkatsuMailSosinTaishoUl"));

        setMailSendlList((List<MgrMailJoho>) request.getAttribute("mailSendlList"));
        setShosai((String) request.getAttribute("shosai"));
        setInpClear((String) request.getAttribute("inpClear"));
        setSearch((String) request.getAttribute("search"));
        setChkTaishoChoice((String[]) request.getParameterValues("chkTaishoChoice"));
        setMailSoshinRrkBack((String) request.getAttribute("mailSoshinRrkBack"));

        setSoshinDate((String) request.getAttribute("soshinDate"));
        setKenmeiKekka((String) request.getAttribute("kenmeiKekka"));
        setSosinNinzu((String) request.getAttribute("sosinNinzu"));
        setSosinStatus((String) request.getAttribute("sosinStatus"));

        setSosinHonbun((String) request.getAttribute("sosinHonbun"));
        setSosinFutter((String) request.getAttribute("sosinFutter"));
        setTmpMailId((String) request.getAttribute("tmpMailId"));
        setKenName((String) request.getAttribute("kenName"));
        setTmpName((String) request.getAttribute("tmpName"));
        setTmpHonbun((String) request.getAttribute("tmpHonbun"));
        setTmpFutter((String) request.getAttribute("tmpFutter"));
        setShiyoFlg((String) request.getAttribute("shiyoFlg"));

        setMskFileChoice((DiskFileItem) request.getAttribute("mskFileChoice"));

        HttpSession session = request.getSession(false);
        if (session.getAttribute("MgrTopJoho") != null) {
            MgrTopJoho tmp = (MgrTopJoho) session.getAttribute("MgrTopJoho");
            setUserId(tmp.getUserId());
            setMoshikomishaId(tmp.getMoshikomishaId());
            setSimei(tmp.getSimei());
        }
    }

    public Messages getErrors() {
        return errors;
    }

    public void setErrors(Messages errors) {
        this.errors = errors;
    }

    public String getNoKanri() {
        return noKanri;
    }

    public void setNoKanri(String noKanri) {
        this.noKanri = noKanri;
    }

    public void setTmpName(String tmpName) {
        this.tmpName = tmpName;
    }

    public void setKenName(String kenName) {
        this.kenName = kenName;
    }

    public void setTmpHonbun(String tmpHonbun) {
        this.tmpHonbun = tmpHonbun;
    }

    public String getTmpHonbun() {
        return tmpHonbun;
    }

    public void setTmpFutter(String tmpFutter) {
        this.tmpFutter = tmpFutter;
    }

    public String getTmpMailIdDisp() {
        return this.tmpMailId;
    }

    public String getTmpMailId() {
        return tmpMailId;
    }

    public void setTmpMailId(String tmpMailId) {
        this.tmpMailId = tmpMailId;
    }

    public String getTmpName() {
        return tmpName;
    }

    public String getKenName() {
        return kenName;
    }

    public String getTmpFutter() {
        return tmpFutter;
    }

    public String getMstKanri() {
        return mstKanri;
    }

    public void setMstKanri(String mstKanri) {
        this.mstKanri = mstKanri;
    }

    public String getTmpSakuseiHenshu() {
        return tmpSakuseiHenshu;
    }

    public String getIkkatsuMailSosin() {
        return ikkatsuMailSosin;
    }

    public String getMailSendRireki() {
        return mailSendRireki;
    }

    public void setTmpSakuseiHenshu(String tmpSakuseiHenshu) {
        this.tmpSakuseiHenshu = tmpSakuseiHenshu;
    }

    public void setIkkatsuMailSosin(String ikkatsuMailSosin) {
        this.ikkatsuMailSosin = ikkatsuMailSosin;
    }

    public void setMailSendRireki(String mailSendRireki) {
        this.mailSendRireki = mailSendRireki;
    }

    public void setMailDetailList(List<MgrMailJoho> mailDetailList) {
        this.mailDetailList = mailDetailList;
    }

    public List<MgrMailJoho> getMailDetailList() {
        return mailDetailList;
    }

    public List<MgrMailJoho> getMailSendlList() {
        return mailSendlList;
    }

    public void setMailSendlList(List<MgrMailJoho> mailSendlList) {
        this.mailSendlList = mailSendlList;
    }

    public String getTmpInpNext() {
        return tmpInpNext;
    }

    public String getTmpInpBack() {
        return tmpInpBack;
    }

    public void setTmpInpNext(String tmpInpNext) {
        this.tmpInpNext = tmpInpNext;
    }

    public void setTmpInpBack(String tmpInpBack) {
        this.tmpInpBack = tmpInpBack;
    }

    public String getTmpInpConfilmNext() {
        return tmpInpConfilmNext;
    }

    public String getTmpInpConfilmBack() {
        return tmpInpConfilmBack;
    }

    public void setTmpInpConfilmNext(String tmpInpConfilmNext) {
        this.tmpInpConfilmNext = tmpInpConfilmNext;
    }

    public void setTmpInpConfilmBack(String tmpInpConfilmBack) {
        this.tmpInpConfilmBack = tmpInpConfilmBack;
    }

    public String getTmpInpKanryoBack() {
        return tmpInpKanryoBack;
    }

    public void setTmpInpKanryoBack(String tmpInpKanryoBack) {
        this.tmpInpKanryoBack = tmpInpKanryoBack;
    }

    public String getTmpShosaiDelete() {
        return tmpShosaiDelete;
    }

    public String getTmpShosaiCopy() {
        return tmpShosaiCopy;
    }

    public String getTmpShosaiUpd() {
        return tmpShosaiUpd;
    }

    public String getTmpShosaiBack() {
        return tmpShosaiBack;
    }

    public void setTmpShosaiDelete(String tmpShosaiDelete) {
        this.tmpShosaiDelete = tmpShosaiDelete;
    }

    public void setTmpShosaiCopy(String tmpShosaiCopy) {
        this.tmpShosaiCopy = tmpShosaiCopy;
    }

    public void setTmpShosaiUpd(String tmpShosaiUpd) {
        this.tmpShosaiUpd = tmpShosaiUpd;
    }

    public void setTmpShosaiBack(String tmpShosaiBack) {
        this.tmpShosaiBack = tmpShosaiBack;
    }

    public String getTmpUpdBack() {
        return tmpUpdBack;
    }

    public String getTmpUpdConfilm() {
        return tmpUpdConfilm;
    }

    public void setTmpUpdBack(String tmpUpdBack) {
        this.tmpUpdBack = tmpUpdBack;
    }

    public void setTmpUpdConfilm(String tmpUpdConfilm) {
        this.tmpUpdConfilm = tmpUpdConfilm;
    }

    public String getTmpUpdKanryoBack() {
        return tmpUpdKanryoBack;
    }

    public void setTmpUpdKanryoBack(String tmpUpdKanryoBack) {
        this.tmpUpdKanryoBack = tmpUpdKanryoBack;
    }

    public String getTmpDeleteConfilmBack() {
        return tmpDeleteConfilmBack;
    }

    public String getTmpDeleteConfilmKakutei() {
        return tmpDeleteConfilmKakutei;
    }

    public void setTmpDeleteConfilmBack(String tmpDeleteConfilmBack) {
        this.tmpDeleteConfilmBack = tmpDeleteConfilmBack;
    }

    public void setTmpDeleteConfilmKakutei(String tmpDeleteConfilmKakutei) {
        this.tmpDeleteConfilmKakutei = tmpDeleteConfilmKakutei;
    }

    public List<Option> getMaillList() {
        return maillList;
    }

    public void setMaillList(List<Option> maillList) {
        this.maillList = maillList;
    }

    public String getSrcTempNo() {
        return srcTempNo;
    }

    public void setSrcTempNo(String srcTempNo) {
        this.srcTempNo = srcTempNo;
    }

    /**
     * �Z�b�V�����p�\�������ő包��
     *
     * @return the page
     */
    public int getPage() {
        return page;
    }

    /**
     * �Z�b�V�����p�\�������ő包��
     *
     * @param page the page to set
     */
    public void setPage(int page) {
        this.page = page;
    }

    /**
     * �y�[�W�J�ڗp�F���ڈړ��Œ�l
     *
     * @return the pageBegin
     */
    public int getPageBegin() {
        return pageBegin;
    }

    /**
     * �y�[�W�J�ڗp�F���ڈړ��Œ�l
     *
     * @param pageBegin the pageBegin to set
     */
    public void setPageBegin(int pageBegin) {
        this.pageBegin = pageBegin;
    }

    /**
     * �y�[�W�J�ڗp�F���ڈړ��ő�l
     *
     * @return the pageEnd
     */
    public int getPageEnd() {
        return pageEnd;
    }

    /**
     * �y�[�W�J�ڗp�F���ڈړ��ő�l
     *
     * @param pageEnd the pageEnd to set
     */
    public void setPageEnd(int pageEnd) {
        this.pageEnd = pageEnd;
    }

    /**
     * �y�[�W�J�ڗp�F�ő�y�[�W��
     *
     * @return the pageMax
     */
    public int getPageMax() {
        return pageMax;
    }

    /**
     * �y�[�W�J�ڗp�F�ő�y�[�W��
     *
     * @param pageMax the pageMax to set
     */
    public void setPageMax(int pageMax) {
        this.pageMax = pageMax;
    }

    /**
     * �Z�b�V�����p�\�������J�n
     *
     * @return the firstDisp
     */
    public int getFirstDisp() {
        return firstDisp;
    }

    /**
     * �Z�b�V�����p�\�������J�n
     *
     * @param firstDisp the firstDisp to set
     */
    public void setFirstDisp(int firstDisp) {
        this.firstDisp = firstDisp;
    }

    /**
     * �Z�b�V�����p�\�������ő包��
     *
     * @return the maxDisp
     */
    public int getMaxDisp() {
        return maxDisp;
    }

    /**
     * �Z�b�V�����p�\�������ő包��
     *
     * @param maxDisp the maxDisp to set
     */
    public void setMaxDisp(int maxDisp) {
        this.maxDisp = maxDisp;
    }

    /**
     * ��������
     *
     * @return the dispKeyList
     */
    public List<String> getDispKeyList() {
        return dispKeyList;
    }

    /**
     * ��������
     *
     * @param dispKeyList the dispKeyList to set
     */
    public void setDispKeyList(List<String> dispKeyList) {
        this.dispKeyList = dispKeyList;
    }

    /**
     * ��������index���X�g
     *
     * @return the searchOutIndex
     */
    public List<String> getSearchOutIndex() {
        return searchOutIndex;
    }

    /**
     * ��������index���X�g
     *
     * @param searchOutIndex the searchOutIndex to set
     */
    public void setSearchOutIndex(List<String> searchOutIndex) {
        this.searchOutIndex = searchOutIndex;
    }

    public String getSearchJoken() {
        return searchJoken;
    }

    public String getUketukeNo() {
        return uketukeNo;
    }

    public String getSimei() {
        return simei;
    }

    public String getMailaddress() {
        return mailaddress;
    }

    public void setSearchJoken(String searchJoken) {
        this.searchJoken = searchJoken;
    }

    public void setUketukeNo(String uketukeNo) {
        this.uketukeNo = uketukeNo;
    }

    public void setSimei(String simei) {
        this.simei = simei;
    }

    public void setMailaddress(String mailaddress) {
        this.mailaddress = mailaddress;
    }

    public String getSearchKekkaListConfilm() {
        return searchKekkaListConfilm;
    }

    public void setSearchKekkaListConfilm(String searchKekkaListConfilm) {
        this.searchKekkaListConfilm = searchKekkaListConfilm;
    }

    public String getSearchKekkaListBack() {
        return searchKekkaListBack;
    }

    public void setSearchKekkaListBack(String searchKekkaListBack) {
        this.searchKekkaListBack = searchKekkaListBack;
    }

    public String getMailSoshinTaisho() {
        return mailSoshinTaisho;
    }

    public String getIkkatsuMailSoshinConfilmBack() {
        return ikkatsuMailSoshinConfilmBack;
    }

    public String getIkkatsuMailSoshin() {
        return ikkatsuMailSoshin;
    }

    public void setMailSoshinTaisho(String mailSoshinTaisho) {
        this.mailSoshinTaisho = mailSoshinTaisho;
    }

    public void setIkkatsuMailSoshinConfilmBack(String ikkatsuMailSoshinConfilmBack) {
        this.ikkatsuMailSoshinConfilmBack = ikkatsuMailSoshinConfilmBack;
    }

    public void setIkkatsuMailSoshin(String ikkatsuMailSoshin) {
        this.ikkatsuMailSoshin = ikkatsuMailSoshin;
    }

    public String getTsuduketeMailSoshin() {
        return tsuduketeMailSoshin;
    }

    public void setTsuduketeMailSoshin(String tsuduketeMailSoshin) {
        this.tsuduketeMailSoshin = tsuduketeMailSoshin;
    }

    public String getIkkatsuMailSosinTaishoUl() {
        return ikkatsuMailSosinTaishoUl;
    }

    public void setIkkatsuMailSosinTaishoUl(String ikkatsuMailSosinTaishoUl) {
        this.ikkatsuMailSosinTaishoUl = ikkatsuMailSosinTaishoUl;
    }

    public String getMailSoshinY_From() {
        return mailSoshinY_From;
    }

    public String getMailSoshinM_From() {
        return mailSoshinM_From;
    }

    public String getMailSoshinY_To() {
        return mailSoshinY_To;
    }

    public String getMailSoshinM_To() {
        return mailSoshinM_To;
    }

    public String getKenmeiJoken() {
        return kenmeiJoken;
    }

    public String getHonbunJoken() {
        return honbunJoken;
    }

    public String getInpClear() {
        return inpClear;
    }

    public String getSearch() {
        return search;
    }

    public void setMailSoshinY_From(String mailSoshinY_From) {
        this.mailSoshinY_From = mailSoshinY_From;
    }

    public void setMailSoshinM_From(String mailSoshinM_From) {
        this.mailSoshinM_From = mailSoshinM_From;
    }

    public void setMailSoshinY_To(String mailSoshinY_To) {
        this.mailSoshinY_To = mailSoshinY_To;
    }

    public void setMailSoshinM_To(String mailSoshinM_To) {
        this.mailSoshinM_To = mailSoshinM_To;
    }

    public void setKenmeiJoken(String kenmeiJoken) {
        this.kenmeiJoken = kenmeiJoken;
    }

    public void setHonbunJoken(String honbunJoken) {
        this.honbunJoken = honbunJoken;
    }

    public void setInpClear(String inpClear) {
        this.inpClear = inpClear;
    }

    public void setSearch(String search) {
        this.search = search;
    }

    public String getMailSoshinDate() {
        return mailSoshinDate;
    }

    public String getMailSoshinNinzu() {
        return mailSoshinNinzu;
    }

    public String getMailSoshinStatus() {
        return mailSoshinStatus;
    }

    public String getMailSoshinRrkBack() {
        return mailSoshinRrkBack;
    }

    public void setMailSoshinDate(String mailSoshinDate) {
        this.mailSoshinDate = mailSoshinDate;
    }

    public void setMailSoshinNinzu(String mailSoshinNinzu) {
        this.mailSoshinNinzu = mailSoshinNinzu;
    }

    public void setMailSoshinStatus(String mailSoshinStatus) {
        this.mailSoshinStatus = mailSoshinStatus;
    }

    public void setMailSoshinRrkBack(String mailSoshinRrkBack) {
        this.mailSoshinRrkBack = mailSoshinRrkBack;
    }

    /**
     *
     * @return the isCheckFlgOn
     */
    public boolean isCheckFlgOn() {
        return BmaConstants.FLG_ON.equals(this.checkFlg);
    }

    /**
     * @return the soshinDate
     */
    public String getSoshinDate() {
        return soshinDate;
    }

    /**
     * @param soshinDate the soshinDate to set
     */
    public void setSoshinDate(String soshinDate) {
        this.soshinDate = soshinDate;
    }

    /**
     * @return the kenmeiKekka
     */
    public String getKenmeiKekka() {
        return kenmeiKekka;
    }

    /**
     * @param kenmeiKekka the kenmeiKekka to set
     */
    public void setKenmeiKekka(String kenmeiKekka) {
        this.kenmeiKekka = kenmeiKekka;
    }

    /**
     * @return the sosinNinzu
     */
    public String getSosinNinzu() {
        return sosinNinzu;
    }

    /**
     * @param sosinNinzu the sosinNinzu to set
     */
    public void setSosinNinzu(String sosinNinzu) {
        this.sosinNinzu = sosinNinzu;
    }

    /**
     * @return the sosinStatus
     */
    public String getSosinStatus() {
        return sosinStatus;
    }

    /**
     * @param sosinStatus the sosinStatus to set
     */
    public void setSosinStatus(String sosinStatus) {
        this.sosinStatus = sosinStatus;
    }

    public String getKoshinDate() {
        return koshinDate;
    }

    public String getKoshinDateDisp() {
        return BmaDateTimeUtility.formatYMDHMToDateSemiString(koshinDate);
    }

    public void setKoshinDate(String koshinDate) {
        this.koshinDate = koshinDate;
    }

    public String getSoshinDateDisp() {
        return BmaDateTimeUtility.formatYMDHMToDateSemiString(soshinDate);
    }

    public String getShosai() {
        return shosai;
    }

    public void setShosai(String shosai) {
        this.shosai = shosai;
    }

    public String getShinkiSakusei() {
        return shinkiSakusei;
    }

    public void setShinkiSakusei(String shinkiSakusei) {
        this.shinkiSakusei = shinkiSakusei;
    }

    public String getMoshikomishaId() {
        return moshikomishaId;
    }

    public void setMoshikomishaId(String moshikomishaId) {
        this.moshikomishaId = moshikomishaId;
    }

    /**
     * ���[���t�b�^�[(�\���p) ���擾����B
     *
     * @return ���[���t�b�^�[(�\���p)
     */
    public String getTmpFutterDisp() {
        return StringUtility.getStringNewLineReplaceBr(this.tmpFutter);
    }

    public String getTmpHonbunBr() {
        return tmpHonbunBr;
    }

    public void setTmpHonbunBr(String tmpHonbunBr) {
        this.tmpHonbunBr = tmpHonbunBr;
    }

    public String getTmpFutterBr() {
        return tmpFutterBr;
    }

    public void setTmpFutterBr(String tmpFutterBr) {
        this.tmpFutterBr = tmpFutterBr;
    }

    public String getShiyoFlg() {
        return shiyoFlg;
    }

    public void setShiyoFlg(String shiyoFlg) {
        this.shiyoFlg = shiyoFlg;
    }

    public String getTmpNewBack() {
        return tmpNewBack;
    }

    public void setTmpNewBack(String tmpNewBack) {
        this.tmpNewBack = tmpNewBack;
    }

    public List<Option> getSousinYearList() {
        return sousinYearList;
    }

    public void setSousinYearList(List<Option> sousinYearList) {
        this.sousinYearList = sousinYearList;
    }

    public List<Option> getSousinMonthList() {
        return sousinMonthList;
    }

    public void setSousinMonthList(List<Option> sousinMonthList) {
        this.sousinMonthList = sousinMonthList;
    }

    public String getSosinFutter() {
        return sosinFutter;
    }

    public void setSosinFutter(String sosinFutter) {
        this.sosinFutter = sosinFutter;
    }

    public String getSosinHonbun() {
        return sosinHonbun;
    }

    public void setSosinHonbun(String sosinHonbun) {
        this.sosinHonbun = sosinHonbun;
    }

    public DiskFileItem getMskFileChoice() {
        return mskFileChoice;
    }

    public void setMskFileChoice(DiskFileItem mskFileChoice) {
        this.mskFileChoice = mskFileChoice;
    }

    public String getCommandPage() {
        return commandPage;
    }

    public void setCommandPage(String commandPage) {
        this.commandPage = commandPage;
    }

    public ArrayList<String[]> getCsvDataList() {
        return csvDataList;
    }

    public void setCsvDataList(ArrayList<String[]> csvDataList) {
        this.csvDataList = csvDataList;
    }

    public String[] getChkTaishoChoice() {
        return chkTaishoChoice;
    }

    public void setChkTaishoChoice(String[] chkTaishoChoice) {
        this.chkTaishoChoice = chkTaishoChoice;
    }

    public String getCheckFlg() {
        return checkFlg;
    }

    public void setCheckFlg(String checkFlg) {
        this.checkFlg = checkFlg;
    }

    public String[] getChkList() {
        return chkList;
    }

    public void setChkList(String[] chkList) {
        this.chkList = chkList;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getLineNo() {
        return lineNo;
    }

    public void setLineNo(String lineNo) {
        this.lineNo = lineNo;
    }

    public String getColumnNo() {
        return columnNo;
    }

    public void setColumnNo(String columnNo) {
        this.columnNo = columnNo;
    }

    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getErrorLogFlg() {
        return errorLogFlg;
    }

    public void setErrorLogFlg(String errorLogFlg) {
        this.errorLogFlg = errorLogFlg;
    }

    public List<MgrMailJoho> getErrorLog() {
        return errorLog;
    }

    public void setErrorLog(List<MgrMailJoho> errorLog) {
        this.errorLog = errorLog;
    }

}
