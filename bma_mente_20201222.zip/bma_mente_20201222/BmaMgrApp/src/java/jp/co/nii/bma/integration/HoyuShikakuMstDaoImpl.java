package jp.co.nii.bma.integration;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import static jp.co.nii.bma.business.domain.GeneratedHoyuShikakuMstDao.TABLE_NAME;
import static jp.co.nii.bma.business.domain.GeneratedMoshikomiDao.TABLE_NAME;
import jp.co.nii.bma.business.domain.HoyuShikakuMst;
import jp.co.nii.bma.business.domain.HoyuShikakuMstDao;
import jp.co.nii.bma.business.rto.manager.HanyouSearchJoho;
import jp.co.nii.bma.business.service.common.BmaConstants;
import static jp.co.nii.bma.integration.GeneratedHoyuShikakuMstDaoImpl.FIELDS_DECRYPT;
import jp.co.nii.sew.common.LogGenerate;
import static jp.co.nii.sew.integration.AbstractDao.getSchemaName;
import jp.co.nii.sew.integration.SQLStateSQLExceptionTranslater;

/**
 * �ۗL���i�}�X�^ DAO�����N���X
 *
 * @author DB�Ǘ��c�[��
 */
public class HoyuShikakuMstDaoImpl extends GeneratedHoyuShikakuMstDaoImpl implements HoyuShikakuMstDao {

    /**
     * �C���X�^���X�𐶐�����B
     *
     * @param datasource �f�[�^�\�[�X��
     */
    public HoyuShikakuMstDaoImpl(String datasource) {
        super(datasource);
    }

    @Override
    public HoyuShikakuMst findMuryo_Zan_Count(String moshikomishaId, String sknKsuCode, String shubetsuCode, String kaisuCode) {
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = "";
        HoyuShikakuMst bo = new HoyuShikakuMst();
        try {
            con = getConnection();
            sql = "SELECT " + FIELDS_DECRYPT
                    + " FROM " + getSchemaName() + "." + TABLE_NAME
                    + " WHERE"
                    + " MOSHIKOMISHA_ID = ?"
                    + " AND SKN_KSU_CODE = ?"
                    + " AND SHUBETSU_CODE = ?"
                    + " AND KAISU_CODE = ?"
                    + " AND RONRI_SAKUJO_FLG = ?"
                    + " ORDER BY NENDO DESC LIMIT 1";

            stmt = con.prepareStatement(sql);
            int i = 1;
            stmt.setString(i++, moshikomishaId);
            stmt.setString(i++, sknKsuCode);
            stmt.setString(i++, shubetsuCode);
            stmt.setString(i++, kaisuCode);
            stmt.setString(i++, BmaConstants.FLG_OFF);

            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();
            if (rs.next()) {
                setBoFromResultSet(bo, rs);
            } else {
                bo = null;
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return bo;
    }

    @Override
    public List<HanyouSearchJoho> searchGroupByMoshkomiId(HanyouSearchJoho inSession) {
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = "";
        ArrayList<HanyouSearchJoho> list = new ArrayList<>();
        try {
            con = getConnection();
            sql = "SELECT hoyu.KAISU_CODE AS KAISU_CODE"
                    + "  , hoyu.NENDO AS NENDO "
                    + " , hoyu.SKN_KSU_CODE AS SKN_KSU_CODE "
                    + " , hoyu.SHUBETSU_CODE AS SHUBETSU_CODE"
                    + " , sknksu.SKN_KSU_NAME AS SKN_KSU_NAME  "
                    + " , hoyu.GOKAKU_NO AS GOKAKU_NO "
                    + " , hoyu.MURYO_ZAN_COUNT AS MURYO_ZAN_COUNT "
                    + " , hoyu.YUKO_KIGEN AS YUKO_KIGEN "
                    + " FROM " + getSchemaName() + "." + TABLE_NAME + " hoyu "
                    + " INNER JOIN  " + getSchemaName() + ".SKNKSU_MST sknksu ON "
                    + "   sknksu.skn_ksu_code = hoyu.skn_ksu_code "
                    + " AND  sknksu.shubetsu_code = hoyu.shubetsu_code "
                    + " AND  sknksu.kaisu_code = hoyu.kaisu_code  "
                    + " WHERE"
                    + " hoyu.RONRI_SAKUJO_FLG = ?"
                    + " And hoyu.MOSHIKOMISHA_ID = ?"
                    + " ORDER BY  "
                    + "  NENDO DESC,SKN_KSU_CODE, SHUBETSU_CODE ";

            stmt = con.prepareStatement(sql);
            int i = 1;
            stmt.setString(i++, BmaConstants.FLG_OFF);
            stmt.setString(i++, inSession.getMoshikomishaId());

            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();
            while (rs.next()) {
                HanyouSearchJoho bo = new HanyouSearchJoho();

                bo.setSknKsuCode(rs.getString("SKN_KSU_CODE"));
                bo.setShubetsuCode(rs.getString("SHUBETSU_CODE"));
                bo.setKaisuCode(rs.getString("KAISU_CODE"));
                bo.setNendo(rs.getString("NENDO"));
                bo.setSknName(rs.getString("SKN_KSU_NAME"));

                bo.setGokakuNo(rs.getString("GOKAKU_NO"));
                bo.setMuryoZanCount(rs.getString("MURYO_ZAN_COUNT"));
                bo.setYukoKigen(rs.getString("YUKO_KIGEN"));

                list.add(bo);
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return list;

    }

    /**
     * ���i������������B<br>
     *
     * @param sknksuCode �����u�K��R�[�h
     * @param gokakuNo ���i���̍��i�ԍ�
     * @return ���i���<br>
     */
    @Override
    public HoyuShikakuMst getByGokakuNo(String sknksuCode, String gokakuNo) {
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = "";
        HoyuShikakuMst bo = new HoyuShikakuMst();
        try {
            con = getConnection();
            sql = "SELECT " + FIELDS_DECRYPT
                    + " FROM " + getSchemaName() + "." + TABLE_NAME
                    + " WHERE"
                    + " SKN_KSU_CODE = ?"
                    + " AND GOKAKU_NO = ?"
                    + " AND RONRI_SAKUJO_FLG = ?"
                    + " LIMIT 1";

            stmt = con.prepareStatement(sql);
            int i = 1;
            stmt.setString(i++, sknksuCode);
            stmt.setString(i++, gokakuNo);
            stmt.setString(i++, BmaConstants.FLG_OFF);

            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();
            if (rs.next()) {
                setBoFromResultSet(bo, rs);
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return bo;
    }

    /**
     * �ۗL���i�}�X�^ �̏����擾����B
     *
     * @param bo
     * @return �ۗL���i�}�X�^
     */
    @Override
    public HoyuShikakuMst findRonriFlg(HoyuShikakuMst bo) {
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = "";
        try {
            con = getConnection();
            sql = "SELECT " + FIELDS_DECRYPT
                    + " FROM " + getSchemaName() + "." + TABLE_NAME
                    + " WHERE"
                    + " MOSHIKOMISHA_ID = ?"
                    + " AND SKN_KSU_CODE = ?"
                    + " AND SHUBETSU_CODE = ?"
                    + " AND KAISU_CODE = ?"
                    + " AND NENDO = ?"
                    + " AND RONRI_SAKUJO_FLG = '0'";

            stmt = con.prepareStatement(sql);
            int i = 1;
            stmt.setString(i++, bo.getMoshikomishaId());
            stmt.setString(i++, bo.getSknKsuCode());
            stmt.setString(i++, bo.getShubetsuCode());
            stmt.setString(i++, bo.getKaisuCode());
            stmt.setString(i++, bo.getNendo());

            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();
            if (rs.next()) {
                setBoFromResultSet(bo, rs);
            } else {
                bo = null;
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return bo;

    }

    /**
     * �\����ID���܂߂čX�V����B�i���ʐ\���j
     * @param hoyuShikakuMst �X�Vbo
     * @param moshikomishaId �V�����\���҂h�c
     */
    @Override
    public Boolean updateWithMoshikomishaId(HoyuShikakuMst hoyuShikakuMst, String moshikomishaId) {
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = "";
        try {
            con = getConnection();
            sql = "UPDATE " + getSchemaName() + "." + TABLE_NAME + " SET "
                    + " MOSHIKOMISHA_ID = ?"
                    + " , MURYO_ZAN_COUNT = ?"
                    + " , KOSHIN_KBN = ?"
                    + " , KOSHIN_DATE = ?"
                    + " , KOSHIN_TIME = ?"
                    + " , KOSHIN_USER_ID = ?"
                    + " WHERE"
                    + " MOSHIKOMISHA_ID = ?"
                    + " AND SKN_KSU_CODE = ?"
                    + " AND SHUBETSU_CODE = ?"
                    + " AND KAISU_CODE = ?"
                    + " AND NENDO = ?"
                    + " AND RONRI_SAKUJO_FLG = ?";

            stmt = con.prepareStatement(sql);
            int i = 1;
            stmt.setString(i++, moshikomishaId);
            stmt.setString(i++, hoyuShikakuMst.getMuryoZanCount());
            stmt.setString(i++, hoyuShikakuMst.getKoshinKbn());
            stmt.setString(i++, hoyuShikakuMst.getKoshinDate());
            stmt.setString(i++, hoyuShikakuMst.getKoshinTime());
            stmt.setString(i++, hoyuShikakuMst.getKoshinUserId());

            stmt.setString(i++, hoyuShikakuMst.getMoshikomishaId());
            stmt.setString(i++, hoyuShikakuMst.getSknKsuCode());
            stmt.setString(i++, hoyuShikakuMst.getShubetsuCode());
            stmt.setString(i++, hoyuShikakuMst.getKaisuCode());
            stmt.setString(i++, hoyuShikakuMst.getNendo());
            stmt.setString(i++, BmaConstants.FLG_OFF);

            LogGenerate.debugOutput(getSql(stmt));
            if (stmt.executeUpdate() == 0) {
                return false;
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt);
        }
        return true;
    }
}
