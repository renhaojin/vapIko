package jp.co.nii.bma.business.rto.manager;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import jp.co.nii.sew.presentation.AbstractRequestTransferObject;
import jp.co.nii.sew.presentation.Messages;
import jp.co.nii.sew.presentation.Option;

/**
 * �^�C�g��: TOP��� ����: TOP���RTO ���쌠: Copyright (c) 2020 ��Ж�: ���{���Y�Ɗ������
 */
public class MstKanriScheduleJoho  extends AbstractRequestTransferObject {
    private Messages errors;
    private Map<Option,Messages> errorJohoMaps;
    private String moshikomishaId;

    /* �{�^���J�� */
    private String scheduleTable;
    // �X�P�W���[���������
    private String scheduleUpdInput;
    private String scheduleSearchResult;
    private String scheduleBack;
    // �X�P�W���[���ύX���͉��
    private String scheduleUpdNotes;
    private String scheduleUpdConf;
    private String scheduleUpdInputBack;
    // �X�P�W���[���ύX�m�F���
    private String scheduleUpdComp;
    private String scheduleUpdConfBack;
    // �X�P�W���[���ύX�������
    private String scheduleUpdCompBack;

    /* �X�P�W���[���f�[�^ */
    private String nendo;
    private String sknKsuCode;
    private String shubetsuCode;
    private String kaisuCode;
    private String scheduleCode;
    private String scheduleKbn;
    private String date;
    private String time;
    private String nissu;
    private String scheduleName;
    
    /* �����u�K��I�� */
    private String sknksuKbn;
    private String sknName;
    private String ksuName;
    private String sknksuNameRyaku;
    private List<Option> sknKbnList;
    private List<Option> ksuKbnList;
    
    private List<MstKanriScheduleJoho> scheduleSearchList;
    private String scheduleSrcListFlg;
    
    /* ��ʕ\���p�X�P�W���[�� */
    private List<MstKanriScheduleJoho> scheduleResultList;
    private List<MstKanriScheduleJoho> scheduleInputList;
    private List<MstKanriScheduleJoho> scheduleUpdateList;
    private String scheduleTitle;
    private String startYear;
    private String startMonth;
    private String startDay;
    private String startYobi;
    private String startHour;
    private String startMinute;
    private String endYear;
    private String endMonth;
    private String endDay;
    private String endYobi;
    private String endHour;
    private String endMinute;
    private String schedStEdFlg;
    private String marginFlg;
    private String timeDisabledFlg;
    private String notHandUpdateFlg;
    private String scheduleListCount;

    private String startDate;
    private String startTime;
    private String endDate;
    private String endTime;
    
    /**
     * �R���X�g���N�^
     */
    public MstKanriScheduleJoho() {
        clearInfo();
    }

    /**
     * ���������\�b�h
     */
    public void clearInfo() {
        setErrors(new Messages());
        setErrorJohoMaps(new HashMap<Option,Messages>());
        setMoshikomishaId("");
        
        setScheduleTable("");
        setScheduleUpdInput("");
        setScheduleSearchResult("");
        setScheduleBack("");
        setScheduleUpdNotes("");
        setScheduleUpdConf("");
        setScheduleUpdInputBack("");
        setScheduleUpdComp("");
        setScheduleUpdConfBack("");
        setScheduleUpdCompBack("");
        
        setNendo("");
        setSknKsuCode("");
        setShubetsuCode("");
        setKaisuCode("");
        setScheduleCode("");
        setScheduleKbn("");
        setDate("");
        setTime("");
        setNissu("");
        setScheduleName("");
        
        setSknksuKbn("1");
        setSknName("");
        setKsuName("");
        setSknksuNameRyaku("");
        setSknKbnList(new ArrayList<Option>());
        setKsuKbnList(new ArrayList<Option>());
        
        setScheduleSearchList(new LinkedList<MstKanriScheduleJoho>());
        setScheduleSrcListFlg("");
        
        setScheduleResultList(new LinkedList<MstKanriScheduleJoho>());
        setScheduleInputList(new LinkedList<MstKanriScheduleJoho>());
        setScheduleUpdateList(new LinkedList<MstKanriScheduleJoho>());
        setScheduleTitle("");
        setStartYear("");
        setStartMonth("");
        setStartDay("");
        setStartYobi("");
        setStartHour("");
        setStartMinute("");
        setEndYear("");
        setEndMonth("");
        setEndDay("");
        setEndYobi("");
        setEndHour("");
        setEndMinute("");
        setSchedStEdFlg("");
        setMarginFlg("");
        setTimeDisabledFlg("");
        setNotHandUpdateFlg("");
        setScheduleListCount("");

        setStartDate("");
        setStartTime("");
        setEndDate("");
        setEndTime("");
    }
    
    /**
     * ���N�G�X�g��������擾���郁�\�b�h
     *
     * @param request ���N�G�X�g
     */
    @Override
    public void copyFromRequest(HttpServletRequest request) {
        setScheduleTable((String) request.getAttribute("scheduleTable"));
        setScheduleUpdInput((String) request.getAttribute("scheduleUpdInput"));
        setScheduleSearchResult((String) request.getAttribute("scheduleSearchResult"));
        setScheduleBack((String) request.getAttribute("scheduleBack"));
        setScheduleUpdNotes((String) request.getAttribute("scheduleUpdNotes"));
        setScheduleUpdConf((String) request.getAttribute("scheduleUpdConf"));
        setScheduleUpdInputBack((String) request.getAttribute("scheduleUpdInputBack"));
        setScheduleUpdComp((String) request.getAttribute("scheduleUpdComp"));
        setScheduleUpdConfBack((String) request.getAttribute("scheduleUpdConfBack"));
        setScheduleUpdCompBack((String) request.getAttribute("scheduleUpdCompBack"));
        
        setNendo((String) request.getAttribute("nendo"));
        setSknKsuCode((String) request.getAttribute("sknKsuCode"));
        setShubetsuCode((String) request.getAttribute("shubetsuCode"));
        setKaisuCode((String) request.getAttribute("kaisuCode"));
        setScheduleKbn((String) request.getAttribute("scheduleKbn"));
        setDate((String) request.getAttribute("date"));
        setTime((String) request.getAttribute("time"));
        setNissu((String) request.getAttribute("nissu"));
        setScheduleName((String) request.getAttribute("scheduleName"));
        
        setSknksuKbn((String) request.getAttribute("sknksuKbn"));
        setSknName((String) request.getAttribute("sknName"));
        setKsuName((String) request.getAttribute("ksuName"));
        setSknksuNameRyaku((String) request.getAttribute("sknksuNameRyaku"));
        setSknKbnList((List<Option>) request.getAttribute("sknKbnList"));
        setKsuKbnList((List<Option>) request.getAttribute("ksuKbnList"));
        
        setScheduleSearchList((List<MstKanriScheduleJoho>) request.getAttribute("scheduleSearchList"));
        setScheduleSrcListFlg((String) request.getAttribute("scheduleSrcListFlg"));
        
        setScheduleResultList((List<MstKanriScheduleJoho>) request.getAttribute("scheduleResultList"));
        setScheduleUpdateList((List<MstKanriScheduleJoho>) request.getAttribute("scheduleUpdateList"));
        
        MstKanriScheduleJoho scheduleJoho;
        int listCount = 0;
        if(request.getAttribute("scheduleListCount") != null){
            listCount = Integer.parseInt((String) request.getAttribute("scheduleListCount"));
        }
        for (int i = 0; i < listCount; i++) {
           scheduleJoho = new MstKanriScheduleJoho();
           scheduleJoho.copyFromRequest_ScheduleInput(request, i);
           scheduleInputList.add(scheduleJoho);
        }

        setStartDate((String) request.getAttribute("startDate"));
        setStartTime((String) request.getAttribute("startTime"));
        setEndDate((String) request.getAttribute("endDate"));
        setEndTime((String) request.getAttribute("endTime"));
        
        HttpSession session = request.getSession(false);
        if (session.getAttribute("MgrTopJoho") != null) {
            MgrTopJoho tmp = (MgrTopJoho) session.getAttribute("MgrTopJoho");
            setMoshikomishaId((String) tmp.getMoshikomishaId());
        }
    }
    
    /**
     * ���N�G�X�g��������擾����
     * �X�P�W���[���ύX���͉�ʂł̓��͒l
     *
     * @param request ���N�G�X�g
     * @param idx index
     */
    public void copyFromRequest_ScheduleInput(HttpServletRequest request, int idx) {
        setScheduleCode((String) request.getAttribute("scheduleCode"+idx));
        setScheduleName((String) request.getAttribute("scheduleName"+idx));

        setScheduleTitle((String) request.getAttribute("scheduleTitle"+idx));
        setStartYear((String) request.getAttribute("startYear"+idx));
        setStartMonth((String) request.getAttribute("startMonth"+idx));
        setStartDay((String) request.getAttribute("startDay"+idx));
        setStartYobi((String) request.getAttribute("startYobi"+idx));
        setStartHour((String) request.getAttribute("startHour"+idx));
        setStartMinute((String) request.getAttribute("startMinute"+idx));
        setEndYear((String) request.getAttribute("endYear"+idx));
        setEndMonth((String) request.getAttribute("endMonth"+idx));
        setEndDay((String) request.getAttribute("endDay"+idx));
        setEndYobi((String) request.getAttribute("endYobi"+idx));
        setEndHour((String) request.getAttribute("endHour"+idx));
        setEndMinute((String) request.getAttribute("endMinute"+idx));
        setSchedStEdFlg((String) request.getAttribute("schedStEdFlg"+idx));
        setMarginFlg((String) request.getAttribute("marginFlg"+idx));
        setTimeDisabledFlg((String) request.getAttribute("timeDisabledFlg"+idx));
        setNotHandUpdateFlg((String) request.getAttribute("notHandUpdateFlg"+idx));
    }
    
    public Messages getErrors() {
        return errors;
    }

    public void setErrors(Messages errors) {
        this.errors = errors;
    }

    public Map<Option, Messages> getErrorJohoMaps() {
        return errorJohoMaps;
    }

    public void setErrorJohoMaps(Map<Option, Messages> errorJohoMaps) {
        this.errorJohoMaps = errorJohoMaps;
    }

    public String getMoshikomishaId() {
        return moshikomishaId;
    }

    public void setMoshikomishaId(String moshikomishaId) {
        this.moshikomishaId = moshikomishaId;
    }
    
    public String getScheduleTable() {
        return scheduleTable;
    }

    public void setScheduleTable(String scheduleTable) {
        this.scheduleTable = scheduleTable;
    }
    
    public String getScheduleUpdInput() {
        return scheduleUpdInput;
    }

    public void setScheduleUpdInput(String scheduleUpdInput) {
        this.scheduleUpdInput = scheduleUpdInput;
    }
    
    public String getScheduleSearchResult() {
        return scheduleSearchResult;
    }

    public void setScheduleSearchResult(String scheduleSearchResult) {
        this.scheduleSearchResult = scheduleSearchResult;
    }
    
    public String getScheduleBack() {
        return scheduleBack;
    }

    public void setScheduleBack(String scheduleBack) {
        this.scheduleBack = scheduleBack;
    }
    
    public String getScheduleUpdNotes() {
        return scheduleUpdNotes;
    }

    public void setScheduleUpdNotes(String scheduleUpdNotes) {
        this.scheduleUpdNotes = scheduleUpdNotes;
    }
    
    public String getScheduleUpdConf() {
        return scheduleUpdConf;
    }

    public void setScheduleUpdConf(String scheduleUpdConf) {
        this.scheduleUpdConf = scheduleUpdConf;
    }
    
    public String getScheduleUpdInputBack() {
        return scheduleUpdInputBack;
    }

    public void setScheduleUpdInputBack(String scheduleUpdInputBack) {
        this.scheduleUpdInputBack = scheduleUpdInputBack;
    }
    
    public String getScheduleUpdComp() {
        return scheduleUpdComp;
    }

    public void setScheduleUpdComp(String scheduleUpdComp) {
        this.scheduleUpdComp = scheduleUpdComp;
    }
    
    public String getScheduleUpdConfBack() {
        return scheduleUpdConfBack;
    }

    public void setScheduleUpdConfBack(String scheduleUpdConfBack) {
        this.scheduleUpdConfBack = scheduleUpdConfBack;
    }
    
    public String getScheduleUpdCompBack() {
        return scheduleUpdCompBack;
    }

    public void setScheduleUpdCompBack(String scheduleUpdCompBack) {
        this.scheduleUpdCompBack = scheduleUpdCompBack;
    }
    
    public String getNendo() {
        return nendo;
    }

    public void setNendo(String nendo) {
        this.nendo = nendo;
    }
    
    public String getSknKsuCode() {
        return sknKsuCode;
    }

    public void setSknKsuCode(String sknKsuCode) {
        this.sknKsuCode = sknKsuCode;
    }
    
    public String getShubetsuCode() {
        return shubetsuCode;
    }

    public void setShubetsuCode(String shubetsuCode) {
        this.shubetsuCode = shubetsuCode;
    }
    
    public String getKaisuCode() {
        return kaisuCode;
    }

    public void setKaisuCode(String kaisuCode) {
        this.kaisuCode = kaisuCode;
    }

    public String getScheduleCode() {
        return scheduleCode;
    }

    public void setScheduleCode(String scheduleCode) {
        this.scheduleCode = scheduleCode;
    }
    
    public String getScheduleKbn() {
        return scheduleKbn;
    }

    public void setScheduleKbn(String scheduleKbn) {
        this.scheduleKbn = scheduleKbn;
    }
    
    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }
    
    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }
    
    public String getNissu() {
        return nissu;
    }

    public void setNissu(String nissu) {
        this.nissu = nissu;
    }
    
    public String getScheduleName() {
        return scheduleName;
    }

    public void setScheduleName(String scheduleName) {
        this.scheduleName = scheduleName;
    }
    
    public String getSknksuKbn() {
        return sknksuKbn;
    }

    public void setSknksuKbn(String sknksuKbn) {
        this.sknksuKbn = sknksuKbn;
    }
    
    public String getSknName() {
        return sknName;
    }

    public void setSknName(String sknName) {
        this.sknName = sknName;
    }
    
    public String getKsuName() {
        return ksuName;
    }

    public void setKsuName(String ksuName) {
        this.ksuName = ksuName;
    }
    
    public String getSknksuNameRyaku() {
        return sknksuNameRyaku;
    }

    public void setSknksuNameRyaku(String sknksuNameRyaku) {
        this.sknksuNameRyaku = sknksuNameRyaku;
    }
    
    public List<Option> getSknKbnList() {
        return sknKbnList;
    }

    public void setSknKbnList(List<Option> sknKbnList) {
        this.sknKbnList = sknKbnList;
    }
    
    public List<Option> getKsuKbnList() {
        return ksuKbnList;
    }

    public void setKsuKbnList(List<Option> ksuKbnList) {
        this.ksuKbnList = ksuKbnList;
    }
    
    public List<MstKanriScheduleJoho> getScheduleSearchList() {
        return scheduleSearchList;
    }

    public void setScheduleSearchList(List<MstKanriScheduleJoho> scheduleSearchList) {
        this.scheduleSearchList = scheduleSearchList;
    }
    
    public String getScheduleSrcListFlg() {
        return scheduleSrcListFlg;
    }

    public void setScheduleSrcListFlg(String scheduleSrcListFlg) {
        this.scheduleSrcListFlg = scheduleSrcListFlg;
    }
    
    public List<MstKanriScheduleJoho> getScheduleResultList() {
        return scheduleResultList;
    }

    public void setScheduleResultList(List<MstKanriScheduleJoho> scheduleResultList) {
        this.scheduleResultList = scheduleResultList;
    }
    
    public List<MstKanriScheduleJoho> getScheduleInputList() {
        return scheduleInputList;
    }

    public void setScheduleInputList(List<MstKanriScheduleJoho> scheduleInputList) {
        this.scheduleInputList = scheduleInputList;
    }
    
    public List<MstKanriScheduleJoho> getScheduleUpdateList() {
        return scheduleUpdateList;
    }

    public void setScheduleUpdateList(List<MstKanriScheduleJoho> scheduleUpdateList) {
        this.scheduleUpdateList = scheduleUpdateList;
    }

    public String getScheduleTitle() {
        return scheduleTitle;
    }

    public void setScheduleTitle(String scheduleTitle) {
        this.scheduleTitle = scheduleTitle;
    }

    public String getStartYear() {
        return startYear;
    }

    public void setStartYear(String startYear) {
        this.startYear = startYear;
    }
    
    public String getStartMonth() {
        return startMonth;
    }

    public void setStartMonth(String startMonth) {
        this.startMonth = startMonth;
    }
    
    public String getStartDay() {
        return startDay;
    }

    public void setStartDay(String startDay) {
        this.startDay = startDay;
    }

    public String getStartYobi() {
        return startYobi;
    }

    public void setStartYobi(String startYobi) {
        this.startYobi = startYobi;
    }

    public String getStartHour() {
        return startHour;
    }

    public void setStartHour(String startHour) {
        this.startHour = startHour;
    }
    
    public String getStartMinute() {
        return startMinute;
    }

    public void setStartMinute(String startMinute) {
        this.startMinute = startMinute;
    }

    public String getEndYear() {
        return endYear;
    }

    public void setEndYear(String endYear) {
        this.endYear = endYear;
    }
    
    public String getEndMonth() {
        return endMonth;
    }

    public void setEndMonth(String endMonth) {
        this.endMonth = endMonth;
    }
    
    public String getEndDay() {
        return endDay;
    }

    public void setEndDay(String endDay) {
        this.endDay = endDay;
    }
    
    public String getEndYobi() {
        return endYobi;
    }

    public void setEndYobi(String endYobi) {
        this.endYobi = endYobi;
    }
    
    public String getEndHour() {
        return endHour;
    }

    public void setEndHour(String endHour) {
        this.endHour = endHour;
    }
    
    public String getEndMinute() {
        return endMinute;
    }

    public void setEndMinute(String endMinute) {
        this.endMinute = endMinute;
    }
    
    public String getSchedStEdFlg() {
        return schedStEdFlg;
    }

    public void setSchedStEdFlg(String schedStEdFlg) {
        this.schedStEdFlg = schedStEdFlg;
    }
    
    public String getMarginFlg() {
        return marginFlg;
    }

    public void setMarginFlg(String marginFlg) {
        this.marginFlg = marginFlg;
    }
    
    public String getTimeDisabledFlg() {
        return timeDisabledFlg;
    }

    public void setTimeDisabledFlg(String timeDisabledFlg) {
        this.timeDisabledFlg = timeDisabledFlg;
    }
    
    public String getNotHandUpdateFlg() {
        return notHandUpdateFlg;
    }

    public void setNotHandUpdateFlg(String notHandUpdateFlg) {
        this.notHandUpdateFlg = notHandUpdateFlg;
    }
    
    public String getScheduleListCount() {
        return scheduleListCount;
    }

    public void setScheduleListCount(String scheduleListCount) {
        this.scheduleListCount = scheduleListCount;
    }

    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }
    
    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }
    
    public String getEndTime() {
        return endTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }
}