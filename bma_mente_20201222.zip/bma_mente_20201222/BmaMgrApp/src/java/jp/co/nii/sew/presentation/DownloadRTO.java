package jp.co.nii.sew.presentation;

import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

/**
 * 
 * @author r-tomita
 */
public abstract class DownloadRTO extends AbstractRequestTransferObject {
    
    /**
     * ���̓X�g���[��
     */
    private InputStream input;
    
    /**
     * Header
     */
    private Map<String,String> header = new HashMap<String, String>();
    
    /**
     * ContentType
     */
    private String contentType;    

    public InputStream getInputStream() {
        return input;
    }

    public void setInputStream(InputStream input) {
        this.input = input;
    }
    
    public boolean isInputStream() {
        return (this.input != null);
    }
    
     public void closeInputStream() {
        if(this.input != null){
            try{
                this.input.close();
            }catch(IOException ioe){
            }
        }
    }
    
    public String getHeader(String key) {
        return header.get(key);
    }

    public void setHeader(String key, String value) {
        this.header.put(key, value);
    }
    
    public Set<String> getHeaderKeys(){
        return this.header.keySet();
    }
    
    public String getContentType() {
        return contentType;
    }

    public void setContentType(String contentType) {
        this.contentType = contentType;
    }
}
