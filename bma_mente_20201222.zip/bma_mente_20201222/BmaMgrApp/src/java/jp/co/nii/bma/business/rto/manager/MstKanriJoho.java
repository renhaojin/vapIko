package jp.co.nii.bma.business.rto.manager;

import java.util.ArrayList;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import jp.co.nii.sew.presentation.AbstractRequestTransferObject;
import jp.co.nii.sew.presentation.Messages;

/**
 * �^�C�g��: TOP��� ����: TOP���RTO ���쌠: Copyright (c) 2020 ��Ж�: ���{���Y�Ɗ������
 */
public class MstKanriJoho  extends AbstractRequestTransferObject {
    private Messages errors;
    
    private String mstKanri;
    private String kaijoMstTable;
    private String kaijoTantoshaMstTable;
    private String shiyoKaijoTable;
    private String scheduleTable;
    private String ryokinTable;
    
    //�R���X�g���N�^/������/���N�G�X�g�擾
    /**
     * �R���X�g���N�^
     */
    public MstKanriJoho() {
        clearInfo();
    }

    /**
     * ���������\�b�h
     */
    public void clearInfo() {
        setErrors(new Messages());
        setMstKanri("");
        setKaijoMstTable("");
        setKaijoTantoshaMstTable("");
        setShiyoKaijoTable("");
        setScheduleTable("");
        setRyokinTable("");
    }
    
    /**
     * ���N�G�X�g��������擾���郁�\�b�h
     *
     * @param request ���N�G�X�g
     */
    @Override
    public void copyFromRequest(HttpServletRequest request) {
        setMstKanri((String) request.getAttribute("mstKanri"));
        setKaijoMstTable((String) request.getAttribute("kaijoMstTable"));
        setKaijoTantoshaMstTable((String) request.getAttribute("kaijoTantoshaMstTable"));
        setShiyoKaijoTable((String) request.getAttribute("shiyoKaijoTable"));
        setScheduleTable((String) request.getAttribute("scheduleTable"));
        setRyokinTable((String) request.getAttribute("ryokinTable"));
        
    }
    
    public Messages getErrors() {
        return errors;
    }

    public void setErrors(Messages errors) {
        this.errors = errors;
    }
    
    public String getMstKanri() {
        return mstKanri;
    }

    public void setMstKanri(String mstKanri) {
        this.mstKanri = mstKanri;
    }
    
    public String getKaijoMstTable() {
        return kaijoMstTable;
    }

    public void setKaijoMstTable(String kaijoMstTable) {
        this.kaijoMstTable = kaijoMstTable;
    }
    
    public String getKaijoTantoshaMstTable() {
        return kaijoTantoshaMstTable;
    }

    public void setKaijoTantoshaMstTable(String kaijoTantoshaMstTable) {
        this.kaijoTantoshaMstTable = kaijoTantoshaMstTable;
    }
    
    public String getShiyoKaijoTable() {
        return shiyoKaijoTable;
    }

    public void setShiyoKaijoTable(String shiyoKaijoTable) {
        this.shiyoKaijoTable = shiyoKaijoTable;
    }
    
    public String getScheduleTable() {
        return scheduleTable;
    }

    public void setScheduleTable(String scheduleTable) {
        this.scheduleTable = scheduleTable;
    }
    
    public String getRyokinTable() {
        return ryokinTable;
    }

    public void setRyokinTable(String ryokinTable) {
        this.ryokinTable = ryokinTable;
    }

}
