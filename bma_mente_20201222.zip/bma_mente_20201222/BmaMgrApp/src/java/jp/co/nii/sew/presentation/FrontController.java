package jp.co.nii.sew.presentation;

import java.io.*;
import java.util.Iterator;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import jp.co.nii.sew.business.Constants;
import static jp.co.nii.sew.business.service.ApplicationService.DOWNLOAD;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_SESSION;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * �t�����g�R���g���[���[ GET��POST�̂ݏ�������
 *
 * @author n-machida
 */
public class FrontController extends HttpServlet {

    Log log = LogFactory.getLog(this.getClass());

    /**
     * Handles the HTTP
     * <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP
     * <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Processes requests for both HTTP
     * <code>GET</code> and
     * <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response) {

        try {
            // service map ��config�擾
            Config serviceConfig = getServiceConfig(request);

            // session�O����
            HttpSession session = null;
            session = preprocessSession(serviceConfig, request, session);

            // �Z�b�V�����ɂ�����Rto�̎擾
            RequestTransferObject rtoInSession = getRtoInSession(serviceConfig, session);

            // request�O����
            RequestTransferObject rto = preprocessRequest(serviceConfig, request);

            // transaction token �̏���
            String serviceResult = processTransactionToken(serviceConfig, request);

            // �Ɩ��T�[�r�X���s
            if (serviceConfig.getServiceFQCN() != null && !FWD_NM_SESSION.equals(serviceResult)) {
                ApplicationController applicationController = new ApplicationController();
                serviceResult = applicationController.execute(request, response, serviceConfig, rto, rtoInSession);
            }

            // request�㏈��
            postprocessRequest(serviceConfig, request, rto);

            // session�㏈��
            postprocessSession(serviceConfig, session, rtoInSession, request, response);

            // view����
            handleView(serviceResult, response, request, rto);

        } catch (UnsupportedEncodingException ex) {
            Logger.getLogger(FrontController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (FileUploadException ex) {
            Logger.getLogger(FrontController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(FrontController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ServletException ex) {
            Logger.getLogger(FrontController.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            // �������O�͂�����Servlet Filter �ŏo��
        }
    }

    private Config getServiceConfig(HttpServletRequest request) {
        log.debug("*** RequestURI=" + request.getRequestURI());
        log.debug("*** RequestURL=" + request.getRequestURL());
//        log.debug("*** PathInfo=" + request.getPathInfo());
//        log.debug("*** PathTranslated=" + request.getPathTranslated());

        Configs.getInstance().checkReload(); // config�ēǍ��݊m�F
        Config serviceConfig = Configs.getInstance().getConfig(request.getRequestURI());

        if (serviceConfig != null) {
            log.debug("*** RTO FQCN=" + serviceConfig.getTransferObjectFQCN());
            log.debug("*** RTO CN=" + serviceConfig.getTransferObjectCN());
        } else {
            //�v�����ꂽ���N�G�X�g�̏�񂪁AConfigs�ɑ��݂��Ȃ�(DB�ɓo�^����Ă��Ȃ�)�ꍇ
            synchronized (Configs.getInstance()) {
                //�}�b�s���O�����ēǍ��݂��Ă���\�������邽�߁A�Ď擾�����݂�
                serviceConfig = Configs.getInstance().getConfig(request.getRequestURI());
            }
            if (serviceConfig == null) {
                log.fatal(request.getRequestURI() + "�̏��Configs�ɑ��݂��܂���ł����B"
                        + "DB��service_config�ɓo�^���ꂽ�f�[�^���������Ȃ��\��������܂��B");
            }
        }

        return serviceConfig;
    }

    private HttpSession preprocessSession(Config serviceConfig, HttpServletRequest request, HttpSession session) throws IOException {
        if (Configs.SESSION_NO.equals(serviceConfig.getSessionConfig())) {
            // do nothing
        } else if (Configs.SESSION_BEGIN.equals(serviceConfig.getSessionConfig())) {
            HttpSession noNeedSession = request.getSession(false);
            if (noNeedSession != null) {
                noNeedSession.invalidate();
            }
            session = request.getSession();

        } else if (Configs.SESSION_CONTINUE.equals(serviceConfig.getSessionConfig())
                // �Z�b�V�����I���̃��N�G�X�g�ł��������͎g�p
                || Configs.SESSION_END.equals(serviceConfig.getSessionConfig())) {

            // request�Ɋ֘A�t����ꂽ�Z�b�V�����擾
            session = request.getSession(false);

            // AP�������[�ɃZ�b�V�������Ȃ����Z�b�V�����ޔ����[�h�̂Ƃ���DB����̃Z�b�V��������
            if (Constants.FLG_ON_DISP.equals(Configs.sessionSaveFlg)
                    && !Constants.DOWNLOAD_SERVLET.contains(request.getRequestURI())
                    && session == null) {
                session = new SessionHelper().restoreSession(request);
            }

        } else {
            // do nothing
        }
        return session;
    }

    private RequestTransferObject preprocessRequest(Config serviceConfig, HttpServletRequest request)
            throws UnsupportedEncodingException, FileUploadException {
        // ���N�G�X�g�f�[�^���l�ߑւ���TransferObject
        RequestTransferObject rto = RTOFactory.getRTO(serviceConfig);

        if (rto != null) {
            // �����R�[�h�ݒ�
            request.setCharacterEncoding("Windows-31J");

            // parameter����attribute��set���Amultipart/�ʏ�̂ǂ���̃��N�G�X�g��
            // �ꗥ��attribute�ɑS���ڂ����悤�ɋώ���
            rto.setAttribute(request);
            // HttpRequest����TO�ւ̋l�ߑւ�
            rto.copyFromRequest(request);
        }
        return rto;
    }

    private RequestTransferObject getRtoInSession(Config serviceConfig, HttpSession session) {
        RequestTransferObject rtoInSession = RTOFactory.getRTO(serviceConfig);
        if (Configs.SESSION_CONTINUE.equals(serviceConfig.getSessionConfig())
                // �Z�b�V�����I���̃��N�G�X�g�ł��������͎g�p
                || Configs.SESSION_END.equals(serviceConfig.getSessionConfig())) {

            if (session != null) {
                RequestTransferObject attribute = (RequestTransferObject) session.getAttribute(serviceConfig.getTransferObjectCN());
                if (attribute != null) {
                    rtoInSession = attribute;
                }
            }
        }
        return rtoInSession;
    }

    private String processTransactionToken(Config serviceConfig, HttpServletRequest request) {
        // ��ʑJ�ڂ̃`�F�b�N
        TransactionToken token = new TransactionToken();
        String serviceResult = null;
        if (TransactionToken.MODE_CHECK.equals(serviceConfig.getTransactionTokenMode()) && !token.isTokenValid(request)) {
            // �O��ʂ̃g�[�N���ƈقȂ�ꍇ�͉�ʑJ�ڕs���ŃG���[
            log.warn("�s���ȉ�ʑJ�ڂ�����܂����B session-id=" + getSessionId(request));
            serviceResult = FWD_NM_SESSION;
        }
        // �g�[�N����������
        if (TransactionToken.MODE_CREATE.equals(serviceConfig.getTransactionTokenMode())
                || TransactionToken.MODE_CHECK.equals(serviceConfig.getTransactionTokenMode())) {
            token.saveToken(request);
        }

        return serviceResult;
    }

    private void postprocessRequest(Config serviceConfig, HttpServletRequest request, RequestTransferObject rto) {
        if (serviceConfig.getTransferObjectCN() != null) {
            // �Ɩ��������TO�̃N���X����t���ă��N�G�X�g�Ɋi�[���Aview�̃w���p�[�Ƃ���
            request.setAttribute(serviceConfig.getTransferObjectCN(), rto);
        }
    }

    private void postprocessSession(Config serviceConfig, HttpSession session, RequestTransferObject rtoInSession, HttpServletRequest request, HttpServletResponse response) throws IOException {
        if ((Configs.SESSION_BEGIN.equals(serviceConfig.getSessionConfig())
                || Configs.SESSION_CONTINUE.equals(serviceConfig.getSessionConfig()))
                && session != null && request.getSession(false) != null
                && serviceConfig.getTransferObjectCN() != null) {
            session.setAttribute(serviceConfig.getTransferObjectCN(), rtoInSession);
            if (Constants.FLG_ON_DISP.equals(Configs.sessionSaveFlg)
                    && !Constants.DOWNLOAD_SERVLET.contains(request.getRequestURI())) {
                new SessionHelper().evacuateSession(request, response, serviceConfig);
            }

        } else if (Configs.SESSION_END.equals(serviceConfig.getSessionConfig())
                // �G���[���Ŋ��ɖ����ɂ���Ă��Ȃ����
                && request.getSession(false) != null) {
            session.invalidate();
            if (Constants.FLG_ON_DISP.equals(Configs.sessionSaveFlg)) {
                // �Z�b�V�����I����A��d���M���ŃZ�b�V��������������Ȃ��悤��
                // DB����Z�b�V���������폜
                new SessionHelper().deleteEvacuatedSession(request);
            }
        }

    }

    private void handleView(String serviceResult, HttpServletResponse response, HttpServletRequest request, RequestTransferObject rto) throws IOException, ServletException {
        // NOT_FWD����
        if (DOWNLOAD.equals(serviceResult)) {
            // �t�@�C���_�E�����[�h�̂Ƃ�
            buildDownloadResponse(rto, response);

        } else {
            response.setContentType("text/html; charset=Windows-31J");
            response.setHeader("X-Content-Type-Options", "nosniff");
            response.setHeader("X-Frame-Options", "SAMEORIGIN");
            response.setHeader("X-XSS-Protection", "1; mode=block");

            Config viewMapping = Configs.getInstance().getConfig(request.getRequestURI() + "-" + serviceResult);
            if (viewMapping == null) {
                //�}�b�s���O�����ēǍ��݂��Ă���\�������邽�߁A�Ď擾�����݂�
                synchronized (Configs.getInstance()) {
                    viewMapping = Configs.getInstance().getConfig(request.getRequestURI() + "-" + serviceResult);
                }
            }
            try {
                forward(viewMapping.getViewPath(), request, response);
            } catch (NullPointerException npe) {
                log.fatal(request.getRequestURI() + "��" + serviceResult + "�̏ꍇ�̏�񂪁AConfigs�ɑ��݂��܂���ł����B"
                        + "DB��view_config�ɓo�^���ꂽ�f�[�^���������Ȃ��\��������܂��B", npe);
            }
        }
    }

    private void forward(String target, HttpServletRequest request, HttpServletResponse response) throws ServletException,
                                                                                                         IOException {
        ServletContext sc = getServletContext();
        RequestDispatcher rd = sc.getRequestDispatcher(target);
        rd.forward(request, response);
    }

    private void buildDownloadResponse(RequestTransferObject rto, HttpServletResponse response) throws IOException {

        BufferedInputStream bis = null;
        OutputStream os = null;
        try {
            DownloadRTO dlRto = (DownloadRTO) rto;
            if (dlRto.isInputStream()) {
                bis = new BufferedInputStream(dlRto.getInputStream());
                os = response.getOutputStream();
                Set<String> headerKeys = dlRto.getHeaderKeys();
                if (!headerKeys.isEmpty()) {
                    Iterator<String> it = headerKeys.iterator();
                    while (it.hasNext()) {
                        String key = it.next();
                        response.setHeader(key, dlRto.getHeader(key));
                    }
                }
                if (dlRto.getContentType() != null) {
                    response.setContentType(dlRto.getContentType());
                }
                streamCopy(bis, os);
            }

        } catch (ClassCastException cce) {
            log.fatal("�_�E�����[�h�����Ɏg�p����RTO�� DownloadRTO �N���X���p�����Ă��܂���B");
            throw cce;
        } finally {
            if (bis != null) {
                bis.close();
            }
            if (os != null) {
                os.close();
            }
        }
    }

    /**
     *
     * @param input InputStream
     * @param output OutputStream
     * @return int �o�C�g��
     * @throws IOException
     */
    private int streamCopy(InputStream input, OutputStream output) throws IOException {
        byte[] buffer = new byte[4096];
        int count = 0;
        for (int n = 0; -1 != (n = input.read(buffer));) {
            output.write(buffer, 0, n);
            count += n;
        }
        return count;
    }

    private String getSessionId(HttpServletRequest request) {
        HttpSession session = request.getSession(false);
        if (session == null) {
            return null;
        } else {
            return session.getId();
        }
    }
}
