//package jp.co.nii.bma.business.service.manager;
//
//import java.io.BufferedWriter;
//import java.io.ByteArrayInputStream;
//import java.io.ByteArrayOutputStream;
//import java.io.IOException;
//import java.io.InputStream;
//import java.io.OutputStreamWriter;
//import java.net.URLEncoder;
//import java.util.List;
//import java.util.ArrayList;
//import java.util.Locale;
//import jp.co.nii.bma.business.domain.MeishoKanri;
//import jp.co.nii.bma.business.domain.Moshikomi;
//import jp.co.nii.bma.business.rto.manager.MgrMskJokyoSearch;
//import jp.co.nii.bma.business.rto.manager.MgrMskJokyoSearchList;
//import jp.co.nii.bma.business.service.common.BmaConstants;
//import jp.co.nii.bma.business.service.common.BmaValidator;
//import jp.co.nii.bma.business.service.common.BmaLogger;
//import jp.co.nii.bma.presentation.common.BmaText;
//import jp.co.nii.bma.utility.BmaUtility;
//import jp.co.nii.sew.SEWException;
//import jp.co.nii.sew.business.SystemTime;
//import jp.co.nii.sew.business.service.AbstractService;
//import jp.co.nii.sew.presentation.Messages;
//import jp.co.nii.sew.presentation.RequestTransferObject;
//import jp.co.nii.sew.utility.StringUtility;
//import jp.co.nii.sew.presentation.Option;
//
///**
// *
// * @author ouen13
// */
//public class MgrMskJokyoSearchService extends AbstractService {
//
//    /**
//     * DB�ڑ��̃f�[�^�\�[�X
//     */
//    private static String DATA_SOURCE_NAME;
//    BmaLogger log = (BmaLogger) BmaLogger.getLogger(this.getClass().getName());
//    /**
//     * ���ڂ̋�؂蕶��
//     */
//    static String KANMA = ",";
//
//    /**
//     * �R���X�g���N�^
//     */
//    public MgrMskJokyoSearchService() {
//        super();
//        //DB�ڑ����̃��[�U�[������
//        DATA_SOURCE_NAME = BmaConstants.DS_REGISTRANT;
//    }
//
//    @Override
//    public String doService(RequestTransferObject rto, RequestTransferObject rtoInSession) throws Exception {
//
//        MgrMskJokyoSearch mskInRequest = (MgrMskJokyoSearch) rto;
//        MgrMskJokyoSearch mskInSession = (MgrMskJokyoSearch) rtoInSession;
//        String processName = "";
//
//        /*�G���[���b�Z�[�W������*/
//        mskInSession.setErrors(new Messages());
//
//        //�T�C�h�o�[������
//        if (mskInRequest.getCommandSideBarInit() != null) {
//
//            // �J�n���O
//            processName = "MenuMskJokyoSearch";
//            log.Start(processName);
//
//            //�Z�b�V������������
//            mskInSession.clearInfo();
//
//            //�}�b�v�ƃ��X�g���擾
//            initFormList(mskInSession);
//
//            // �������O
//            log.End(processName);
//
//            return FWD_NM_SUCCESS;
//
//        }
//
//        //�����������͉��:�����{�^������
//        if (mskInRequest.getCommandSearch() != null) {
//            // �J�n���O
//            processName = "search";
//            log.Start(processName);
//
//            /*���͒l���Z�b�V�����ɕۑ�*/
//            setValueRequestToSession(mskInRequest, mskInSession);
//
//            //null���u�����N��
//            this.formatNullToBlank(mskInSession);
//
//            //���̓`�F�b�N
//            if (!searchValidator(mskInSession)) {
//                return FWD_NM_ERROR;
//            }
//
//            /* �W�v���f���t */
//            SystemTime now = new SystemTime();
//            String shukeihaneidate;
//            shukeihaneidate = now.getymd2() + " " + now.gethm2();
//
//            /* rto�̏����Z�b�V�����ɃZ�b�g */
//            mskInSession.setShukeiHaneiDate(shukeihaneidate);
//            /* ���я��̏����l�Z�b�g */
//            mskInSession.setSearchOrderBy("1");
//
//            ArrayList<MgrMskJokyoSearchList> resultList = new ArrayList<MgrMskJokyoSearchList>();
//
//            //�������s
//            Moshikomi bomoshikomi = new Moshikomi(DATA_SOURCE_NAME);
//
//            try {
//
//                if ("1".equals(mskInSession.getSearchHyojiTani())) {
//                    resultList = (ArrayList<MgrMskJokyoSearchList>) bomoshikomi.getMoshikomiJokyoSearchList(mskInSession);
//                } else if ("2".equals(mskInSession.getSearchHyojiTani())) {
//                    resultList = (ArrayList<MgrMskJokyoSearchList>) setZeroHourListHourly(bomoshikomi.getMoshikomiJokyoSearchListHourly(mskInSession));
//                }
//
//                if (!resultList.isEmpty()) {
//                    resultList.add(0, bomoshikomi.getMoshikomiJokyoSearchListGoukei(mskInSession));
//                }
//
//                // �������O
//                log.End(processName);
//
//            } catch (Exception e) {
//                log.error("getMoshikomiJokyoSearchList()�ŗ�O����", e);
//                throw new SEWException("�󌱐\���󋵌����ŗ�O�����������B", e);
//            }
//
//            if (resultList.isEmpty()) {
//                /*���X�g����̎��G���[*/
//                Messages errors = new Messages();
//                BmaValidator.addMessage(errors, "info", BmaText.E00022, "");
//                mskInSession.setErrors(errors);
//                return FWD_NM_ERROR;
//
//            } else {
//                mskInSession.setSearchList(resultList);
//
//                return FWD_NM_SUCCESS;
//            }
//
//        }
//
//        //�����������͉��:���̓N���A�{�^������
//        if (mskInRequest.getCommandClear() != null) {
//
//            // �J�n���O
//            processName = "clearSearchInput";
//            log.Start(processName);
//
//            //�Z�b�V������������
//            mskInSession.clearInfo();
//
//            // �������O
//            log.End(processName);
//
//            return FWD_NM_RELOAD;
//        }
//
//        //�������ʉ��:���я��{�^������
//        if (mskInRequest.getCommandOrderBy() != null) {
//
//            // �J�n���O
//            processName = "orderBy";
//            log.Start(processName);
//
//            /* ���я��l�Z�b�g */
//            mskInSession.setSearchOrderBy(mskInRequest.getSearchOrderBy());
//
//            ArrayList<MgrMskJokyoSearchList> resultList = new ArrayList<MgrMskJokyoSearchList>();
//
//            //�������s
//            Moshikomi bomoshikomi = new Moshikomi(DATA_SOURCE_NAME);
//
//            try {
//
//                if ("1".equals(mskInSession.getSearchHyojiTani())) {
//                    resultList = (ArrayList<MgrMskJokyoSearchList>) bomoshikomi.getMoshikomiJokyoSearchList(mskInSession);
//                } else if ("2".equals(mskInSession.getSearchHyojiTani())) {
//                    resultList = (ArrayList<MgrMskJokyoSearchList>) setZeroHourListHourly(bomoshikomi.getMoshikomiJokyoSearchListHourly(mskInSession));
//                }
//
//                if (!resultList.isEmpty()) {
//                    resultList.add(0, bomoshikomi.getMoshikomiJokyoSearchListGoukei(mskInSession));
//                }
//
//                log.End(processName);
//
//            } catch (Exception e) {
//                log.error("getMoshikomiJokyoSearchList()�ŗ�O����", e);
//                throw new SEWException("�󌱐\���󋵌����ŗ�O�����������B", e);
//            }
//
//            mskInSession.setSearchList(resultList);
//
//            return FWD_NM_RELOAD;
//        }
//
//        //�������ʉ��:CSV�o�̓{�^������
//        if (mskInRequest.getCommandCsvOutput() != null) {
//
//            //CSV�_�E�����[�h
//            processName = "csvDownload";
//            log.Start(processName);
//
//            String ret = createCsv(mskInRequest, mskInSession);
//
//            log.End(processName);
//
//            return ret;
//
//        }
//
//        //�������ʉ��:�������͉�ʂ֖߂�{�^������
//        if (mskInRequest.getCommandSearchListBack() != null) {
//
//            // �J�n���O
//            processName = "backSearchInput";
//            log.Start(processName);
//
//            // �������O
//            log.End(processName);
//
//            return FWD_NM_BACK;
//
//        }
//
//        // �ُ�ȑJ��
//        log.IllegalFWD();
//        return FWD_NM_SESSION;
//
//    }
//
//    /**
//     * �t�H�[���̏����\���ɕK�v�ȏ������s���B �Z���N�g�{�b�N�X���X�g�Ƃ��̃}�b�v
//     *
//     * @param requestRTO
//     */
//    private void initFormList(MgrMskJokyoSearch sessionRTO) throws Exception {
//
//        List<Option> list = new ArrayList<Option>();
//
//        /* ����N���X�g */
//        list = new ArrayList<Option>();
//        list.add(new Option(BmaConstants.NEN, BmaConstants.NEN));
//        sessionRTO.setYearDisp(list);
//
//        /* �����X�g */
//        list = new ArrayList<Option>();
//        list.add(new Option("", ""));
//
//        for (int i = 1; i <= 12; i++) {
//            list.add(new Option(i >= 10 ? "" + i : "0" + i, "" + i));
//        }
//        sessionRTO.setMonthDisp(list);
//
//        /* �����X�g */
//        list = new ArrayList<Option>();
//        list.add(new Option("", ""));
//        for (int i = 1; i <= 31; i++) {
//            list.add(new Option(i >= 10 ? "" + i : "0" + i, "" + i));
//        }
//        sessionRTO.setDayDisp(list);
//
//        /* �����X�g */
//        list = new ArrayList<Option>();
//        list.add(new Option("", ""));
//        for (int i = 0; i <= 23; i++) {
//            list.add(new Option(i >= 10 ? "" + i : "0" + i, "" + i));
//        }
//        sessionRTO.setHourDisp(list);
//
//        /* �\���P�ʃ��X�g */
//        list = new ArrayList<Option>();
//        list.add(new Option("1", "����"));
//        list.add(new Option("2", "���ԕ�"));
//        sessionRTO.setHyojiTaniDisp(list);
//
//        /* �󌱕��@���X�g */
//        list = new ArrayList<Option>();
//        list.add(new Option("", "����"));
//        list.add(new Option(BmaConstants.SHIKEN_KBN_CODE_GAKKA, "�w��"));
//        list.add(new Option(BmaConstants.SHIKEN_KBN_CODE_SEIZU, "�݌v���}"));
//        sessionRTO.setJukenHouhoDisp(list);
//
//        /* �s���{�����X�g */
//        MeishoKanri meisho = new MeishoKanri(DATA_SOURCE_NAME);
//        list = new ArrayList<Option>();
//        meisho.findByGroupCode(BmaConstants.NEN, BmaConstants.MEISHO_KANRI_GROUP_CODE_TODOFUKE, list);
//        list.add(0, new Option("", ""));
//        sessionRTO.setGenjyushoTodoufukenDisp(list);
//
//        /* ���я����X�g */
//        list = new ArrayList<Option>();
//        list.add(new Option("1", "�o�^���i�����j"));
//        list.add(new Option("2", "�o�^���i�~���j"));
//        list.add(new Option("3", "�\�����i�~���j"));
//        sessionRTO.setOrderByDisp(list);
//
//    }
//
//    /**
//     * ���̓f�[�^���Z�b�V�����f�[�^�ɃZ�b�g����B
//     *
//     * @param InputInRequest ���N�G�X�g��̓��̓f�[�^
//     * @param InputInSession �Z�b�V������̓��̓f�[�^
//     */
//    private void setValueRequestToSession(MgrMskJokyoSearch inRequest, MgrMskJokyoSearch inSession) {
//        inSession.setSearchFromMoshikomibiYear(inRequest.getSearchFromMoshikomibiYear());
//        inSession.setSearchFromMoshikomibiMonth(inRequest.getSearchFromMoshikomibiMonth());
//        inSession.setSearchFromMoshikomibiDay(inRequest.getSearchFromMoshikomibiDay());
//        inSession.setSearchFromMoshikomibiHour(inRequest.getSearchFromMoshikomibiHour());
//        inSession.setSearchToMoshikomibiYear(inRequest.getSearchToMoshikomibiYear());
//        inSession.setSearchToMoshikomibiMonth(inRequest.getSearchToMoshikomibiMonth());
//        inSession.setSearchToMoshikomibiDay(inRequest.getSearchToMoshikomibiDay());
//        inSession.setSearchToMoshikomibiHour(inRequest.getSearchToMoshikomibiHour());
//        inSession.setSearchHyojiTani(inRequest.getSearchHyojiTani());
//        inSession.setSearchCrejitKessaiFlg(inRequest.getSearchCrejitKessaiFlg());
//        inSession.setSearchConveniKessaiZumiFlg(inRequest.getSearchConveniKessaiZumiFlg());
//        inSession.setSearchConveniKessaiMachiFlg(inRequest.getSearchConveniKessaiMachiFlg());
//        inSession.setSearchKessaiMisentakuFlg(inRequest.getSearchKessaiMisentakuFlg());
//        inSession.setSearchJukenHouho(inRequest.getSearchJukenHouho());
//        inSession.setSearchGenjyushoTodoufuken(inRequest.getSearchGenjyushoTodoufuken());
//        inSession.setShikenShuruiCode(inRequest.getShikenShuruiCode());
//    }
//
//    /**
//     * NULL���u�����N��
//     *
//     * @param useRTO
//     */
//    private void formatNullToBlank(MgrMskJokyoSearch useRTO) {
//        useRTO.setSearchFromMoshikomibiYear(StringUtility.convertNullToBlank(useRTO.getSearchFromMoshikomibiYear()));
//        useRTO.setSearchFromMoshikomibiMonth(StringUtility.convertNullToBlank(useRTO.getSearchFromMoshikomibiMonth()));
//        useRTO.setSearchFromMoshikomibiDay(StringUtility.convertNullToBlank(useRTO.getSearchFromMoshikomibiDay()));
//        useRTO.setSearchFromMoshikomibiHour(StringUtility.convertNullToBlank(useRTO.getSearchFromMoshikomibiHour()));
//        useRTO.setSearchToMoshikomibiYear(StringUtility.convertNullToBlank(useRTO.getSearchToMoshikomibiYear()));
//        useRTO.setSearchToMoshikomibiMonth(StringUtility.convertNullToBlank(useRTO.getSearchToMoshikomibiMonth()));
//        useRTO.setSearchToMoshikomibiDay(StringUtility.convertNullToBlank(useRTO.getSearchToMoshikomibiDay()));
//        useRTO.setSearchToMoshikomibiHour(StringUtility.convertNullToBlank(useRTO.getSearchToMoshikomibiHour()));
//        useRTO.setSearchHyojiTani(StringUtility.convertNullToBlank(useRTO.getSearchHyojiTani()));
//        useRTO.setSearchCrejitKessaiFlg(StringUtility.convertNullToBlank(useRTO.getSearchCrejitKessaiFlg()));
//        useRTO.setSearchConveniKessaiZumiFlg(StringUtility.convertNullToBlank(useRTO.getSearchConveniKessaiZumiFlg()));
//        useRTO.setSearchConveniKessaiMachiFlg(StringUtility.convertNullToBlank(useRTO.getSearchConveniKessaiMachiFlg()));
//        useRTO.setSearchKessaiMisentakuFlg(StringUtility.convertNullToBlank(useRTO.getSearchKessaiMisentakuFlg()));
//        useRTO.setSearchJukenHouho(StringUtility.convertNullToBlank(useRTO.getSearchJukenHouho()));
//        useRTO.setSearchGenjyushoTodoufuken(StringUtility.convertNullToBlank(useRTO.getSearchGenjyushoTodoufuken()));
//    }
//
//    /**
//     * ���̓`�F�b�N
//     *
//     * @param ListRTO
//     * @return
//     * @throws Exception
//     */
//    private boolean searchValidator(MgrMskJokyoSearch searchRTO) throws Exception {
//        Messages errors = searchValidatorCaller(searchRTO);
//        if (!errors.isEmpty()) {
//            //�G���[��rto�Ɋi�[
//            searchRTO.setErrors(errors);
//            return false;
//        }
//        return true;
//    }
//
//    /**
//     * ���̓`�F�b�N�ڍ�
//     *
//     * @param mntListRTO
//     * @return
//     * @throws Exception
//     */
//    private Messages searchValidatorCaller(MgrMskJokyoSearch searchRTO) throws Exception {
//        //������
//        Messages errors = new Messages();
//        String itemName;
//        String groupCode;
//
//        //�\���P�ʁ@�K�{�`�F�b�N
//        BmaValidator.validateRequired(searchRTO.getSearchHyojiTani(), errors, "hyojiTani", "�\���P��");
//
//        /*�\����*/
//        groupCode = "mskDate";
//        itemName = "�N";
//        BmaValidator.validatePermissionSelect(searchRTO.getSearchFromMoshikomibiYear(), searchRTO.getYearDisp(), errors, groupCode, itemName);
//        BmaValidator.validatePermissionSelect(searchRTO.getSearchToMoshikomibiYear(), searchRTO.getYearDisp(), errors, groupCode, itemName);
//        itemName = "��";
//        BmaValidator.validatePermissionSelect(searchRTO.getSearchFromMoshikomibiMonth(), searchRTO.getMonthDisp(), errors, groupCode, itemName);
//        BmaValidator.validatePermissionSelect(searchRTO.getSearchToMoshikomibiMonth(), searchRTO.getMonthDisp(), errors, groupCode, itemName);
//        itemName = "��";
//        BmaValidator.validatePermissionSelect(searchRTO.getSearchFromMoshikomibiDay(), searchRTO.getDayDisp(), errors, groupCode, itemName);
//        BmaValidator.validatePermissionSelect(searchRTO.getSearchToMoshikomibiDay(), searchRTO.getDayDisp(), errors, groupCode, itemName);
//        itemName = "��";
//        BmaValidator.validatePermissionSelect(searchRTO.getSearchFromMoshikomibiHour(), searchRTO.getHourDisp(), errors, groupCode, itemName);
//        BmaValidator.validatePermissionSelect(searchRTO.getSearchToMoshikomibiHour(), searchRTO.getHourDisp(), errors, groupCode, itemName);
//
//        itemName = "�\����";
//        if (!BmaUtility.isNullOrEmpty(searchRTO.getSearchFromMoshikomibiMonth()) && !BmaUtility.isNullOrEmpty(searchRTO.getSearchFromMoshikomibiDay())) {
//            /*�J�n���������I������Ă���Ƃ����ݓ��`�F�b�N*/
//            BmaValidator.validateDate(searchRTO.getSearchFromMoshikomibiYear() + searchRTO.getSearchFromMoshikomibiMonth() + searchRTO.getSearchFromMoshikomibiDay(), errors, groupCode, itemName);
//        }
//        if (!BmaUtility.isNullOrEmpty(searchRTO.getSearchToMoshikomibiMonth()) && !BmaUtility.isNullOrEmpty(searchRTO.getSearchToMoshikomibiDay())) {
//            /*�I�����������I������Ă���Ƃ����ݓ��`�F�b�N*/
//            BmaValidator.validateDate2(searchRTO.getSearchToMoshikomibiYear() + searchRTO.getSearchToMoshikomibiMonth() + searchRTO.getSearchToMoshikomibiDay(), errors, groupCode, itemName);
//        }
//
//        /*�\�����@*/
//        itemName = "�\���P��";
//        groupCode = "hyojiTani";
//        BmaValidator.validatePermissionSelect(searchRTO.getSearchHyojiTani(), searchRTO.getHyojiTaniDisp(), errors, groupCode, itemName);
//
//        /*���ϕ��@*/
//        itemName = "���ϕ��@";
//        groupCode = "kessaiHouho";
//        BmaValidator.validatePermissionSelect(searchRTO.getSearchCrejitKessaiFlg(), new String[]{BmaConstants.FLG_ON}, errors, groupCode, itemName);
//        BmaValidator.validatePermissionSelect(searchRTO.getSearchConveniKessaiZumiFlg(), new String[]{BmaConstants.FLG_ON}, errors, groupCode, itemName);
//        BmaValidator.validatePermissionSelect(searchRTO.getSearchConveniKessaiMachiFlg(), new String[]{BmaConstants.FLG_ON}, errors, groupCode, itemName);
//        BmaValidator.validatePermissionSelect(searchRTO.getSearchKessaiMisentakuFlg(), new String[]{BmaConstants.FLG_ON}, errors, groupCode, itemName);
//
//        /*�󌱕��@*/
//        itemName = "�󌱕��@";
//        groupCode = "jukenHoho";
//        BmaValidator.validatePermissionSelect(searchRTO.getSearchJukenHouho(), searchRTO.getJukenHouhoDisp(), errors, groupCode, itemName);
//
//        /*���Z���̓s���{��*/
//        itemName = "���Z���̓s���{��";
//        groupCode = "todofuke";
//        BmaValidator.validatePermissionSelect(searchRTO.getSearchGenjyushoTodoufuken(), searchRTO.getGenjyushoTodoufukenDisp(), errors, groupCode, itemName);
//
//        return errors;
//    }
//
//    /**
//     * CSV�o��
//     *
//     * @param MgrMskJokyoJohoInRequest
//     * @param MgrMskJokyoJohoInSession
//     * @return foward��
//     */
//    private String createCsv(MgrMskJokyoSearch InRequest, MgrMskJokyoSearch InSession) throws IOException {
//
//        String shikenKbnName = "";
//
//        if (InRequest.getShikenShuruiCode().equals(BmaConstants.SHIKEN_SHURUI_CODE_IKKYU)) {
//            shikenKbnName = "�P������";
//        } else if (InRequest.getShikenShuruiCode().equals(BmaConstants.SHIKEN_SHURUI_CODE_NIKYU)) {
//            shikenKbnName = "�Q������";
//        } else if (InRequest.getShikenShuruiCode().equals(BmaConstants.SHIKEN_SHURUI_CODE_MOKUZO)) {
//            shikenKbnName = "�ؑ�����";
//        }
//
//        String fileName = shikenKbnName + (new SystemTime()).getymd1() + "_" + (new SystemTime()).gethms1() + ".csv";
//
//        // �w�b�_�[����
//        InRequest.setHeader("Content-Disposition", String.format(Locale.JAPAN, "attachment; filename*=utf-8'jp'%s", URLEncoder.encode(fileName, "utf-8")));
//        InRequest.setContentType("application/octet-stream;charset=" + BmaConstants.ENCODE_SHIFT_JIS);
//
//        // �X�g���[������
//        BufferedWriter bw = null;
//        ByteArrayOutputStream outputStream = null;
//        try {
//            outputStream = new ByteArrayOutputStream();
//            bw = new BufferedWriter(new OutputStreamWriter(outputStream, BmaConstants.ENCODE_SHIFT_JIS));
//
//            // �o�͏���
//            writeCSV(InSession, bw);
//
//        } catch (Exception e) {
//            log.error("CSV�o�͏����ŃG���[���������܂����B", e);
//            return FWD_NM_EXCEPTION;
//
//        } finally {
//            if (bw != null) {
//                bw.close();
//            }
//        }
//
//        InputStream io = new ByteArrayInputStream(outputStream.toByteArray());
//        InRequest.setInputStream(io);
//        InRequest.setHeader("Content-Type", "charset=" + BmaConstants.ENCODE_SHIFT_JIS);
//        InRequest.setContentType("text/csv; charset=" + BmaConstants.ENCODE_SHIFT_JIS);
//
//        return DOWNLOAD;
//
//    }
//
//    /**
//     * CSV�f�[�^����������
//     *
//     * @param MgrMskJokyoJohoInRequest
//     * @param bw
//     * @param isShikenkaijo
//     * @throws Exception
//     */
//    private void writeCSV(MgrMskJokyoSearch InRequest, BufferedWriter bw) throws Exception {
//
//        try {
//            //�w�b�_�[
//            bw.write("�o�^��");
//            if (InRequest.getSearchHyojiTani().equals("2")) {
//                bw.write(KANMA + "�o�^����");
//            }
//            if (BmaConstants.FLG_ON.equals(InRequest.getSearchCrejitKessaiFlg())) {
//                bw.write(KANMA + "�\���Ґ�_�N���W�b�g�J�[�h");
//            }
//            if (BmaConstants.FLG_ON.equals(InRequest.getSearchConveniKessaiZumiFlg())) {
//                bw.write(KANMA + "�\���Ґ�_�R���r�j�x����");
//            }
//            if (BmaConstants.FLG_ON.equals(InRequest.getSearchConveniKessaiMachiFlg())) {
//                bw.write(KANMA + "�\���Ґ�_�R���r�j������");
//            }
//            if (BmaConstants.FLG_ON.equals(InRequest.getSearchKessaiMisentakuFlg())) {
//                bw.write(KANMA + "�\���Ґ�_���I��");
//            }
//            bw.write(KANMA + "�\���Ґ�-���v");
//
//            //���s
//            bw.write(StringUtility.NEW_LINE);
//
//            //�P�s�����o��
//            bw.flush();
//
//            for (MgrMskJokyoSearchList list : InRequest.getSearchList()) {
//                bw.write(list.getTorokuDate());
//                if (InRequest.getSearchHyojiTani().equals("2")) {
//                    bw.write(KANMA + list.getTorokuHour());
//                }
//                if (BmaConstants.FLG_ON.equals(InRequest.getSearchCrejitKessaiFlg())) {
//                    bw.write(KANMA + list.getMoshikomiSuuCre());
//                }
//                if (BmaConstants.FLG_ON.equals(InRequest.getSearchConveniKessaiZumiFlg())) {
//                    bw.write(KANMA + list.getMoshikomiSuuCvnNyukin());
//                }
//                if (BmaConstants.FLG_ON.equals(InRequest.getSearchConveniKessaiMachiFlg())) {
//                    bw.write(KANMA + list.getMoshikomiSuuCvnMinyukin());
//                }
//                if (BmaConstants.FLG_ON.equals(InRequest.getSearchKessaiMisentakuFlg())) {
//                    bw.write(KANMA + list.getMoshikomiSuuKessaiMisentaku());
//                }
//                //���ʂ̏ꍇ�A��ꖼ�������o��
//                bw.write(KANMA + list.getMoshikomiSuu());
//                //���s
//                bw.write(StringUtility.NEW_LINE);
//            }
//
//            //��������
//            bw.flush();
//
//        } catch (Exception ioe) {
//            throw ioe;
//        }
//    }
//
//    /**
//     * ���ԕʂ̐\�������O�̎��Ԃ𖄂߂�B
//     *
//     * @param list ���ԕʏ󋵃��X�g
//     * @return �\������0�̎��Ԃ𖄂߂���̃��X�g
//     * @throws Exception ��O
//     */
//    private List<MgrMskJokyoSearchList> setZeroHourListHourly(List<MgrMskJokyoSearchList> list) throws Exception {
//        List<MgrMskJokyoSearchList> ret = new ArrayList<MgrMskJokyoSearchList>();
//        String date = "";
//        int hour = 0;
//        MgrMskJokyoSearchList temp;
//        for (MgrMskJokyoSearchList row : list) {
//            if (!row.getTorokuDate().equals(date)) {
//                /*���t���ς������,*/
//                if (!date.isEmpty()) {
//                    /*���t����o�Ȃ���(=��ڂ̗v�f�łȂ���)�O���t��23���܂Ŗ��߂�*/
//                    for (int h = hour; h < 24; h++) {
//                        temp = new MgrMskJokyoSearchList();
//                        temp.setMoshikomiSuu("0");
//                        temp.setMoshikomiSuuCre("0");
//                        temp.setMoshikomiSuuCvnNyukin("0");
//                        temp.setMoshikomiSuuCvnMinyukin("0");
//                        temp.setMoshikomiSuuKessaiMisentaku("0");
//                        temp.setTorokuDate(date);
//                        temp.setTorokuHour(h + "��");
//                        ret.add(temp);
//                    }
//                }
//                /*���t�Ǝ��Ԃ�ύX*/
//                date = row.getTorokuDate();
//                hour = 0;
//            }
//            /*�O�s�̎��Ԃ��獡�̎��Ԃ̎�O�܂ł̊Ԃ̎��Ԃ𖄂߂�*/
//            for (int h = hour; h < Integer.parseInt(row.getTorokuHour().replace("��", "")); h++) {
//                temp = new MgrMskJokyoSearchList();
//                temp.setMoshikomiSuu("0");
//                temp.setMoshikomiSuuCre("0");
//                temp.setMoshikomiSuuCvnNyukin("0");
//                temp.setMoshikomiSuuCvnMinyukin("0");
//                temp.setMoshikomiSuuKessaiMisentaku("0");
//                temp.setTorokuDate(date);
//                temp.setTorokuHour(h + "��");
//                ret.add(temp);
//            }
//            /*���̎��Ԃ̃Z�b�g*/
//            temp = new MgrMskJokyoSearchList();
//            temp.setMoshikomiSuu(row.getMoshikomiSuu());
//            temp.setMoshikomiSuuCre(row.getMoshikomiSuuCre());
//            temp.setMoshikomiSuuCvnNyukin(row.getMoshikomiSuuCvnNyukin());
//            temp.setMoshikomiSuuCvnMinyukin(row.getMoshikomiSuuCvnMinyukin());
//            temp.setMoshikomiSuuKessaiMisentaku(row.getMoshikomiSuuKessaiMisentaku());
//            temp.setTorokuDate(date);
//            temp.setTorokuHour(row.getTorokuHour());
//            ret.add(temp);
//            /*���ԍX�V*/
//            hour = Integer.parseInt(row.getTorokuHour().replace("��", "")) + 1;
//        }
//        /*�ŏI����23���܂Ŗ��߂�*/
//        for (int h = hour; h < 24; h++) {
//            temp = new MgrMskJokyoSearchList();
//            temp.setMoshikomiSuu("0");
//            temp.setMoshikomiSuuCre("0");
//            temp.setMoshikomiSuuCvnNyukin("0");
//            temp.setMoshikomiSuuCvnMinyukin("0");
//            temp.setMoshikomiSuuKessaiMisentaku("0");
//            temp.setTorokuDate(date);
//            temp.setTorokuHour(h + "��");
//            ret.add(temp);
//        }
//        return ret;
//    }
//}
