package jp.co.nii.bma.integration;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import jp.co.nii.bma.business.domain.HanyoKensakuOutMst;
import jp.co.nii.bma.business.domain.HanyoKensakuOutMstDao;
import jp.co.nii.bma.business.rto.manager.HanyouSearchJoho;
import jp.co.nii.bma.business.rto.manager.HanyouSelectJoho;
import jp.co.nii.bma.business.service.common.BmaConstants;
import jp.co.nii.sew.common.LogGenerate;
import jp.co.nii.sew.integration.SQLStateSQLExceptionTranslater;
import jp.co.nii.sew.presentation.Option;

/**
 * �ėp�����o�͍��ڃ}�X�^ DAO�����N���X
 *
 * @author DB�Ǘ��c�[��
 */
public class HanyoKensakuOutMstDaoImpl extends GeneratedHanyoKensakuOutMstDaoImpl implements HanyoKensakuOutMstDao {

    /**
     * �C���X�^���X�𐶐�����B
     *
     * @param datasource �f�[�^�\�[�X��
     */
    public HanyoKensakuOutMstDaoImpl(String datasource) {
        super(datasource);
    }

    /**
     * �ėp�����o�͍��ڃ}�X�^ �̏����擾����B
     *
     * @param list
     */
    @Override
    public void findDtlOutMstList(List<Option> list) {
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = "";

        String limit = "";

        limit = " LIMIT " + "1000";
        try {
            con = getConnection();
            sql = "SELECT " + FIELDS_DECRYPT
                    + " FROM " + getSchemaName() + "." + TABLE_NAME
                    + " WHERE " + " RONRI_SAKUJO_FLG = '0'"
                    + " ORDER BY VIW_CLM_NAME_OUT ASC "
                    + limit;

            stmt = con.prepareStatement(sql);

            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();

            while (rs.next()) {
                if (list != null) {
                    list.add(new Option(rs.getString("VIW_CLM_NAME_OUT"), rs.getString("KOMOKU_NAME")));
                }

            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
    }

    /**
     * hanYO_kensaku_all_view����ėp�����o�͍��ڂ̏����擾����B
     *
     * @param inSession
     * @return
     */
    @Override
    public List<HanyouSelectJoho> findDtlAllList(HanyouSearchJoho inSession) {
        Connection con = null;
        PreparedStatement stmt = null;
        List<String> param = new ArrayList<>();
        ResultSet rs = null;
        String sql = "";
        List<HanyouSelectJoho> hanyouList = new ArrayList<>();

        try {
            con = getConnection();
            con = getConnection();
            sql = "SELECT "
                    + "  nendo "
                    + "  , skn_ksu_nm"
                    + "  , shubetsu_name"
                    + "  , kaisu_code"
                    + "  , uketsuke_no  "
                    + "  , juken_juko_no"
                    + "  , shimei "
                    + "  , furigana  "
                    + "  , birthday  "
                    + "  , nenrei "
                    + "  , sex_nm "
                    + "  , yubin_no  "
                    + "  , todofuken_nm "
                    + "  , jusho_1"
                    + "  , jusho_2"
                    + "  , tatemono  "
                    + "  , tel_no "
                    + "  , fax_no "
                    + "  , mail_address "
                    + "  , kinmusaki_name  "
                    + "  , kinmusaki_yubin_no "
                    + "  , kinmusaki_todofuken_nm"
                    + "  , kinmusaki_jusho_1  "
                    + "  , kinmusaki_jusho_2  "
                    + "  , kinmusaki_tatemono "
                    + "  , kinmusaki_tel_no"
                    + "  , kinmusaki_fax_no"
                    + "  , sofu_saki_nm "
                    + "  , gohi_jokyo_nm"
                    + "  , gokaku_no "
                    + "  , gokaku_bi "
                    + "  , yuko_kigen_shikaku "
                    + "  , muryo_zan_count "
                    + "  , goukaku_no_gakka"
                    + "  , goukaku_no_jitsugi "
                    + "  , moshikomi_nm "
                    + "  , kojin_dantai_nm "
                    + "  , moshikomi_jokyo_nm "
                    + "  , shiken_naiyo_nm "
                    + "  , kaisaichi_nm_1  "
                    + "  , kaijo_nm_1"
                    + "  , kaisaichi_nm_2  "
                    + "  , kaijo_nm_2"
                    + "  , genmen_nm "
                    + "  , kaiin_kbn_nm "
                    + "  , kaiin_shinsei_nm"
                    + "  , kigyo_code"
                    + "  , kyokai_name  "
                    + "  , kigyo_hp_url "
                    + "  , gaiji_flg_nm "
                    + "  , gaiji_shosai "
                    + "  , hairyo_flg_nm"
                    + "  , hairyo_naiyo "
                    + "  , kessai_hoho_nm  "
                    + "  , kessai_kingaku  "
                    + "  , kessai_tesuryo  "
                    + "  , kessai_kingaku_total  "
                    + "  , kessai_bng"
                    + "  , kessai_date  "
                    + "  , kessai_time  "
                    + "  , kanri_memo"
                    + "  , hosei_irai_nm"
                    + "  , unyo_jokyo_nm"
                    + "  , yuko_kigen_menjo"
                    + "  , skn_ksu_kbn  "
                    + "  , skn_ksu_code "
                    + "  , shubetsu_code"
                    + "  , sex "
                    + "  , todofuken_code  "
                    + "  , kinmusaki_todofuken_code "
                    + "  , sofu_saki_kbn"
                    + "  , moshikomi_kbn"
                    + "  , kojin_dantai_kbn"
                    + "  , moshikomi_jokyo_kbn"
                    + "  , shiken_naiyo_kbn"
                    + "  , _genmen_flg  "
                    + "  , kaiin_kbn "
                    + "  , kaiin_shinsei_flg  "
                    + "  , gaiji_flg "
                    + "  , hairyo_flg"
                    + "  , kessai_hoho_kbn "
                    + "  , kessai_jokyo_kbn"
                    + "  , kari_uketsuke_bi"
                    + "  , moshikomi_finish_bi"
                    + "  , gohi_jokyo_kbn  "
                    + "  , kaisaichi_code1 "
                    + "  , kaijo_code1  "
                    + "  , kaisaichi_code2 "
                    + "  , kaijo_code2  "
                    + "  , hosei_irai_kbn  "
                    + "  , unyo_jokyo_kbn  "
                    + "  , moshikomisha_id "
                    + " FROM " + getSchemaName() + "." + " hanYO_kensaku_all_view"
                    + " WHERE ";

            sql = sql + inSession.getSql();
            param = inSession.getParam();
            sql = sql + " group by "
                    + " nendo"
                    + " , skn_ksu_nm  "
                    + " , shubetsu_name  "
                    + " , kaisu_code  "
                    + " , uketsuke_no "
                    + " , juken_juko_no  "
                    + " , shimei"
                    + " , furigana "
                    + " , birthday "
                    + " , nenrei"
                    + " , sex_nm"
                    + " , yubin_no "
                    + " , todofuken_nm"
                    + " , jusho_1  "
                    + " , jusho_2  "
                    + " , tatemono "
                    + " , tel_no"
                    + " , fax_no"
                    + " , mail_address"
                    + " , kinmusaki_name "
                    + " , kinmusaki_yubin_no"
                    + " , kinmusaki_todofuken_nm  "
                    + " , kinmusaki_jusho_1 "
                    + " , kinmusaki_jusho_2 "
                    + " , kinmusaki_tatemono"
                    + " , kinmusaki_tel_no  "
                    + " , kinmusaki_fax_no  "
                    + " , sofu_saki_nm"
                    + " , gohi_jokyo_nm  "
                    + " , gokaku_no"
                    + " , gokaku_bi"
                    + " , yuko_kigen_shikaku"
                    + " , muryo_zan_count"
                    + " , goukaku_no_gakka  "
                    + " , goukaku_no_jitsugi"
                    + " , moshikomi_nm"
                    + " , kojin_dantai_nm"
                    + " , moshikomi_jokyo_nm"
                    + " , shiken_naiyo_nm"
                    + " , kaisaichi_nm_1 "
                    + " , kaijo_nm_1  "
                    + " , kaisaichi_nm_2 "
                    + " , kaijo_nm_2  "
                    + " , genmen_nm"
                    + " , kaiin_kbn_nm"
                    + " , kaiin_shinsei_nm  "
                    + " , kigyo_code  "
                    + " , kyokai_name "
                    + " , kigyo_hp_url"
                    + " , gaiji_flg_nm"
                    + " , gaiji_shosai"
                    + " , hairyo_flg_nm  "
                    + " , hairyo_naiyo"
                    + " , kessai_hoho_nm "
                    + " , kessai_kingaku "
                    + " , kessai_tesuryo "
                    + " , kessai_kingaku_total "
                    + " , kessai_bng  "
                    + " , kessai_date "
                    + " , kessai_time "
                    + " , kanri_memo  "
                    + " , hosei_irai_nm  "
                    + " , unyo_jokyo_nm  "
                    + " , yuko_kigen_menjo  "
                    + " , skn_ksu_kbn "
                    + " , skn_ksu_code"
                    + " , shubetsu_code  "
                    + " , sex"
                    + " , todofuken_code "
                    + " , kinmusaki_todofuken_code"
                    + " , sofu_saki_kbn  "
                    + " , moshikomi_kbn  "
                    + " , kojin_dantai_kbn  "
                    + " , moshikomi_jokyo_kbn  "
                    + " , shiken_naiyo_kbn  "
                    + " , _genmen_flg "
                    + " , kaiin_kbn"
                    + " , kaiin_shinsei_flg "
                    + " , gaiji_flg"
                    + " , hairyo_flg  "
                    + " , kessai_hoho_kbn"
                    + " , kessai_jokyo_kbn  "
                    + " , kari_uketsuke_bi  "
                    + " , moshikomi_finish_bi  "
                    + " , gohi_jokyo_kbn "
                    + " , kaisaichi_code1"
                    + " , kaijo_code1 "
                    + " , kaisaichi_code2"
                    + " , kaijo_code2 "
                    + " , hosei_irai_kbn "
                    + " , unyo_jokyo_kbn "
                    + " , moshikomisha_id";

            stmt = con.prepareStatement(sql);
            int i = 1;
            for (String pm : param) {
                stmt.setString(i++, pm);
            }

            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();

            while (rs.next()) {
                HanyouSelectJoho detail = new HanyouSelectJoho();

                detail.setBirthday(rs.getString("BIRTHDAY") + ",BIRTHDAY");
                detail.setFax_no(rs.getString("FAX_NO") + ",FAX_NO");
                detail.setFurigana(rs.getString("FURIGANA") + ",FURIGANA");
                detail.setGaiji_flg_nm(rs.getString("GAIJI_FLG_NM") + ",GAIJI_FLG_NM");
                detail.setGaiji_shosai(rs.getString("GAIJI_SHOSAI") + ",GAIJI_SHOSAI");
                detail.setGenmen_nm(rs.getString("GENMEN_NM") + ",GENMEN_NM");
                detail.setGohi_jokyo_nm(rs.getString("GOHI_JOKYO_NM") + ",GOHI_JOKYO_NM");
                detail.setGokaku_bi(rs.getString("GOKAKU_BI") + ",GOKAKU_BI");
                detail.setGokaku_no(rs.getString("GOKAKU_NO") + ",GOKAKU_NO");
                detail.setGoukaku_no_gakka(rs.getString("GOUKAKU_NO_GAKKA") + ",GOUKAKU_NO_GAKKA");
                detail.setGoukaku_no_jitsugi(rs.getString("GOUKAKU_NO_JITSUGI") + ",GOUKAKU_NO_JITSUGI");
                detail.setHairyo_flg_nm(rs.getString("HAIRYO_FLG_NM") + ",HAIRYO_FLG_NM");
                detail.setHairyo_naiyo(rs.getString("HAIRYO_NAIYO") + ",HAIRYO_NAIYO");
                detail.setJuken_juko_no(rs.getString("JUKEN_JUKO_NO") + ",JUKEN_JUKO_NO");
                detail.setJusho_1(rs.getString("JUSHO_1") + ",JUSHO_1");
                detail.setJusho_2(rs.getString("JUSHO_2") + ",JUSHO_2");
                detail.setKaiin_kbn_nm(rs.getString("KAIIN_KBN_NM") + ",KAIIN_KBN_NM");
                detail.setKaiin_shinsei_nm(rs.getString("KAIIN_SHINSEI_NM") + ",KAIIN_SHINSEI_NM");
                detail.setKaijo_nm_1(rs.getString("KAIJO_NM_1") + ",KAIJO_NM_1");
                detail.setKaijo_nm_2(rs.getString("KAIJO_NM_2") + ",KAIJO_NM_2");
                detail.setKaisaichi_nm_1(rs.getString("KAISAICHI_NM_1") + ",KAISAICHI_NM_1");
                detail.setKaisaichi_nm_2(rs.getString("KAISAICHI_NM_2") + ",KAISAICHI_NM_2");
                detail.setKaisu_code(rs.getString("KAISU_CODE") + ",KAISU_CODE");
                detail.setKanri_memo(rs.getString("KANRI_MEMO") + ",KANRI_MEMO");
                detail.setKessai_bng(rs.getString("KESSAI_BNG") + ",KESSAI_BNG");
                detail.setKessai_date(rs.getString("KESSAI_DATE") + ",KESSAI_DATE");
                detail.setKessai_hoho_nm(rs.getString("KESSAI_HOHO_NM") + ",KESSAI_HOHO_NM");
                detail.setKessai_kingaku(rs.getString("KESSAI_KINGAKU") + ",KESSAI_KINGAKU");
                detail.setKessai_kingaku_total(rs.getString("KESSAI_KINGAKU_TOTAL") + ",KESSAI_KINGAKU_TOTAL");
                detail.setKessai_tesuryo(rs.getString("KESSAI_TESURYO") + ",KESSAI_TESURYO");
                detail.setKessai_time(rs.getString("KESSAI_TIME") + ",KESSAI_TIME");
                detail.setKigyo_code(rs.getString("KIGYO_CODE") + ",KIGYO_CODE");
                detail.setKigyo_hp_url(rs.getString("KIGYO_HP_URL") + ",KIGYO_HP_URL");
                detail.setKinmusaki_fax_no(rs.getString("KINMUSAKI_FAX_NO") + ",KINMUSAKI_FAX_NO");
                detail.setKinmusaki_jusho_1(rs.getString("KINMUSAKI_JUSHO_1") + ",KINMUSAKI_JUSHO_1");
                detail.setKinmusaki_jusho_2(rs.getString("KINMUSAKI_JUSHO_2") + ",KINMUSAKI_JUSHO_2");
                detail.setKinmusaki_tatemono(rs.getString("KINMUSAKI_TATEMONO") + ",KINMUSAKI_TATEMONO");
                detail.setKinmusaki_tel_no(rs.getString("KINMUSAKI_TEL_NO") + ",KINMUSAKI_TEL_NO");
                detail.setKinmusaki_todofuken_nm(rs.getString("KINMUSAKI_TODOFUKEN_NM") + ",KINMUSAKI_TODOFUKEN_");
                detail.setKinmusaki_yubin_no(rs.getString("KINMUSAKI_YUBIN_NO") + ",KINMUSAKI_YUBIN_NO");
                detail.setKojin_dantai_nm(rs.getString("KOJIN_DANTAI_NM") + ",KOJIN_DANTAI_NM");
                detail.setKyokai_name(rs.getString("KYOKAI_NAME") + ",KYOKAI_NAME");
                detail.setMail_address(rs.getString("MAIL_ADDRESS") + ",MAIL_ADDRESS");
                detail.setMoshikomi_jokyo_nm(rs.getString("MOSHIKOMI_JOKYO_NM") + ",MOSHIKOMI_JOKYO_NM");
                detail.setMoshikomi_nm(rs.getString("MOSHIKOMI_NM") + ",MOSHIKOMI_NM");
                detail.setMuryo_zan_count(rs.getString("MURYO_ZAN_COUNT") + ",MURYO_ZAN_COUNT");
                detail.setNendo(rs.getString("NENDO") + ",NENDO");
                detail.setNenrei(rs.getString("NENREI") + ",NENREI");
                detail.setSex_nm(rs.getString("SEX_NM") + ",SEX_NM");
                detail.setShiken_naiyo_nm(rs.getString("SHIKEN_NAIYO_NM") + ",SHIKEN_NAIYO_NM");
                detail.setShimei(rs.getString("SHIMEI") + ",SHIMEI");
                detail.setShubetsu_name(rs.getString("SHUBETSU_NAME") + ",SHUBETSU_NAME");
                detail.setSkn_ksu_nm(rs.getString("SKN_KSU_NM") + ",SKN_KSU_NM");
                detail.setSofu_saki_nm(rs.getString("SOFU_SAKI_NM") + ",SOFU_SAKI_NM");
                detail.setTatemono(rs.getString("TATEMONO") + ",TATEMONO");
                detail.setTel_no(rs.getString("TEL_NO") + ",TEL_NO");
                detail.setTodofuken_nm(rs.getString("TODOFUKEN_NM") + ",TODOFUKEN_NM");
                detail.setUketsuke_no(rs.getString("UKETSUKE_NO") + ",UKETSUKE_NO");
                detail.setYubin_no(rs.getString("YUBIN_NO") + ",YUBIN_NO");
                detail.setYuko_kigen_menjo(rs.getString("YUKO_KIGEN_MENJO") + ",YUKO_KIGEN_MENJO");
                detail.setYuko_kigen_shikaku(rs.getString("YUKO_KIGEN_SHIKAKU") + ",YUKO_KIGEN_SHIKAKU");

                hanyouList.add(detail);
            }

        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return hanyouList;
    }
}
