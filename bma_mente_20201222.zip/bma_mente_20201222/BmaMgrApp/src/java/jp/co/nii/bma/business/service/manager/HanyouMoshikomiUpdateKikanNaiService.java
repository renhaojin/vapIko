package jp.co.nii.bma.business.service.manager;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import jp.co.nii.bma.business.domain.ShiyoKaijo;
import jp.co.nii.bma.business.rto.manager.HanyouKaisaiTiJoho;
import jp.co.nii.bma.business.rto.manager.HanyouSearchJoho;
import jp.co.nii.bma.business.service.common.BmaConstants;
import jp.co.nii.bma.business.service.common.BmaLogger;
import jp.co.nii.bma.business.service.common.BmaValidator;
import jp.co.nii.bma.utility.BmaStringUtility;
import jp.co.nii.bma.utility.BmaUtility;
import jp.co.nii.sew.business.Validator;
import jp.co.nii.sew.business.service.AbstractService;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_SESSION;
import jp.co.nii.sew.presentation.Messages;
import jp.co.nii.sew.presentation.Option;
import jp.co.nii.sew.presentation.RequestTransferObject;
import jp.co.nii.sew.utility.PropertyUtility;

/**
 * <p>
 * �^�C�g��: �ėp���ԓ��X�V��ʃT�[�r�X</p>
 * <p>
 * ����: �ėp���ԓ��X�V��ʃT�[�r�X</p>
 * <p>
 * ���쌠: Copyright (c) 2020</p>
 * <p>
 * ��Ж�: ���{���Y�Ɗ������</p>
 */
public class HanyouMoshikomiUpdateKikanNaiService extends AbstractService {

    /**
     * DB�ڑ��̃f�[�^�\�[�X
     */
    private static String DATA_SOURCE_NAME;
    /**
     * ���O
     */
    BmaLogger log = (BmaLogger) BmaLogger.getLogger(this.getClass().getName());
    /**
     * �Ɩ��R�[�h
     */
    private static final String BUSINESS_CODE = PropertyUtility.getProperty("business_code");
    /**
     * ���׃e�X�g���[�h
     */
    private static final String STRESS_MODE = PropertyUtility.getProperty(BUSINESS_CODE + "stress_mode");
    /**
     * �N�x
     */
    private static final String NEN = PropertyUtility.getProperty(BUSINESS_CODE + "nen");

    /**
     * �R���X�g���N�^
     */
    public HanyouMoshikomiUpdateKikanNaiService() {
        super();
        /* DB�ڑ����̃��[�U�[������ */
        DATA_SOURCE_NAME = BmaConstants.DS_REGISTRANT;
    }

    /**
     * �T�[�r�X�N���X�̎��s���\�b�h
     *
     * @param rto ���N�G�X�g��񂩂�擾����rto
     * @param rtoinSession �Z�b�V�������rto
     * @return foward��
     * @throws Exception ��O
     */
    @Override
    public String doService(RequestTransferObject rto, RequestTransferObject rtoinSession)
            throws Exception {

        HanyouSearchJoho inRequest = (HanyouSearchJoho) rto;
        HanyouSearchJoho inSession = (HanyouSearchJoho) rtoinSession;
        String processName = "";

        /*�G���[���b�Z�[�W������*/
        inSession.setErrors(new Messages());

        try {
            if (!BmaUtility.isNullOrEmpty(inRequest.getHayoBack())) {
                /*�߂�{�^��������*/
                processName = "hayoBack";

                log.Start(processName);

                return FWD_NM_BACK;
            } else if (!BmaUtility.isNullOrEmpty(inRequest.getSearchChange1()) && "1".equals(inRequest.getSearchFlg())
                    && BmaUtility.isNullOrEmpty(inRequest.getTempSave()) && BmaUtility.isNullOrEmpty(inRequest.getDetailConfirm())) {

                /*���ID�I��*/
                processName = "searchChange1";
                log.Start(processName);

                //  ���̓f�[�^���Z�b�V�����f�[�^�ɃZ�b�g����
                setValueRequestToSession(inRequest, inSession);

                inSession.setKaijoId1(inRequest.getSearchChange1());
                String str;
                String value = inRequest.getSearchChange1();
                for (Option option : inSession.getKaijoIdAllList()) {
                    if (option.getValue().equals(value)) {
                        str = option.getLabel();

                        String[] kaijyo = str.split(",", 0);

                        inSession.setGakKaisaichiCode(kaijyo[1]);
                        inSession.setGakkaKaijo(kaijyo[3]);
                        inSession.setGakkaJusho(kaijyo[4]);
                        inSession.setGakkaDate(kaijyo[5]);
                        break;
                    }
                }

                return FWD_NM_RELOAD;
            } else if (!BmaUtility.isNullOrEmpty(inRequest.getSearchChange2()) && "2".equals(inRequest.getSearchFlg())
                    && BmaUtility.isNullOrEmpty(inRequest.getTempSave()) && BmaUtility.isNullOrEmpty(inRequest.getDetailConfirm())) {

                /*���ID�I��*/
                processName = "searchChange2";
                log.Start(processName);

                //  ���̓f�[�^���Z�b�V�����f�[�^�ɃZ�b�g����
                setValueRequestToSession(inRequest, inSession);
                inSession.setKaijoId2(inRequest.getSearchChange2());

                String str;
                String value = inRequest.getSearchChange2();
                for (Option option : inSession.getKaijoIdAllList()) {
                    if (option.getValue().equals(value)) {
                        str = option.getLabel();

                        String[] kaijyo = str.split(",", 0);

                        inSession.setJissiKaisaichiCode(kaijyo[1]);
                        inSession.setJissiKaijo(kaijyo[3]);
                        inSession.setJissiJusho(kaijyo[4]);
                        inSession.setJissiDate(kaijyo[5]);
                        break;
                    }
                }

                return FWD_NM_RELOAD;
            } else if (!BmaUtility.isNullOrEmpty(inRequest.getSearchChange())
                    && BmaUtility.isNullOrEmpty(inRequest.getTempSave()) && BmaUtility.isNullOrEmpty(inRequest.getDetailConfirm())) {

                /*���ID�I��*/
                processName = "searchChange";
                log.Start(processName);

                //  ���̓f�[�^���Z�b�V�����f�[�^�ɃZ�b�g����
                setValueRequestToSession(inRequest, inSession);
                inSession.setKaijoId(inRequest.getSearchChange());

                String str;
                String value = inRequest.getSearchChange();
                for (Option option : inSession.getKaijoIdAllList()) {
                    if (option.getValue().equals(value)) {
                        str = option.getLabel();

                        String[] kaijyo = str.split(",", 0);

                        inSession.setJissiKaisaichiCode(kaijyo[1]);
                        inSession.setJissiKaijo(kaijyo[3]);
                        inSession.setJissiJusho(kaijyo[4]);
                        inSession.setJissiDateFrom(kaijyo[5]);
                        inSession.setJissiDateTo(kaijyo[6]);
                        break;
                    }
                }

                return FWD_NM_RELOAD;
            } else if (!BmaUtility.isNullOrEmpty(inRequest.getKuusekiConfirm())) {
                /*��Ȋm�F�{�^��������*/
                processName = "kuusekiConfirm";
                log.Start(processName);

                List<HanyouKaisaiTiJoho> kaijoList = new ArrayList<>();
                List<HanyouKaisaiTiJoho> kaijoListNew = new ArrayList<>();

                ShiyoKaijo shiyoKaijo = new ShiyoKaijo(BmaConstants.DS_REGISTRANT);
                /*��ꃊ�X�g�擾*/
                String nendo = inSession.getNendo();
                String kknKsuCode = inSession.getSknKsuCode();
                String shubetsuCode = inSession.getShubetsuCode();
                String kaisuCode = inSession.getKaisuCode();

                kaijoList = shiyoKaijo.searchHanyoKaijoList(nendo, kknKsuCode,
                        shubetsuCode, kaisuCode);
                /*�J�Òn�擾*/
                Map<String, List<HanyouKaisaiTiJoho>> kaisaichi = kaijoList.stream().collect(Collectors.groupingBy(HanyouKaisaiTiJoho::getKaisaichiCode));

                /*��ꃊ�X�g����J�Òn���Ɣz��*/
                for (Map.Entry<String, List<HanyouKaisaiTiJoho>> entry : kaisaichi.entrySet()) {
                    List<HanyouKaisaiTiJoho> listGroup = entry.getValue();
                    for (HanyouKaisaiTiJoho item : listGroup) {
                        item.setCount(listGroup.size() + "");
                        kaijoListNew.add(item);
                    }
                }
                inSession.setKaiMskJohoList(kaijoListNew);

                return FWD_NM_NEXT;
            } else if (!BmaUtility.isNullOrEmpty(inRequest.getDetailConfirm())) {
                /*�m�F�{�^��������*/
                processName = "detailConfirm";
                log.Start(processName);

                inSession.setUserId(inRequest.getUserId());

                //  ���̓f�[�^���Z�b�V�����f�[�^�ɃZ�b�g����
                setValueRequestToSession(inRequest, inSession);

                /*���̓`�F�b�N*/
                boolean retCheck = ValidatorInput(inRequest, inSession);

                // ��肪�Ȃ���� true
                if (retCheck) {
                    return FWD_NM_SUCCESS;
                }
                /* �������ʈꗗ��ʕ\�� */
                return FWD_NM_RELOAD;
            } else {
                /*�ُ�J��*/
                log.IllegalFWD();
                return FWD_NM_SESSION;
            }
        } catch (Exception e) {
            throw e;
        } finally {
            log.End(processName);
        }
    }

    /**
     * ���̓f�[�^���Z�b�V�����f�[�^�ɃZ�b�g����B
     *
     * @param inRequest ���N�G�X�g��̓��̓f�[�^
     * @param inSession �Z�b�V������̓��̓f�[�^
     */
    private void setValueRequestToSession(HanyouSearchJoho inRequest, HanyouSearchJoho inSession) {

        inSession.setMoshikomikanryoBiYear(inRequest.getMoshikomikanryoBiYear());
        inSession.setMoshikomikanryoBiMonth(inRequest.getMoshikomikanryoBiMonth());
        inSession.setMoshikomikanryoBiDay(inRequest.getMoshikomikanryoBiDay());

        inSession.setGenmenFlg(inRequest.getGenmenFlg());
        inSession.setMoshikomiJokyoKbn2(inRequest.getMoshikomiJokyoKbn2());
        inSession.setHairyoFlg(inRequest.getHairyoFlg());

        inSession.setHairyoNaiyo(inRequest.getHairyoNaiyo());
        inSession.setSofuSakiKbn(inRequest.getSofuSakiKbn());

        inSession.setKaijoId1(inRequest.getSearchChange1());
        inSession.setKaijoId2(inRequest.getSearchChange2());
        inSession.setKaijoId(inRequest.getSearchChange());
        inSession.setShikakuCode(inRequest.getShikakuCode());
        inSession.setShinseiShikakuNo(inRequest.getShinseiShikakuNo());
        inSession.setMenjoCode(inRequest.getMenjoCode());
        inSession.setShinseiMenjoNo(inRequest.getShinseiMenjoNo());

        List<HanyouSearchJoho> shokurekiList = inRequest.getShokurekiList();
        List<HanyouSearchJoho> shokurekiListRtn = new ArrayList<HanyouSearchJoho>();
        for (int i = 0; i < shokurekiList.size(); i++) {
            HanyouSearchJoho oneSyokuReki = shokurekiList.get(i);

            oneSyokuReki.setYearList(inSession.getYearList());
            oneSyokuReki.setMonthList(inSession.getMonthList());
            oneSyokuReki.setShokumuNaiyoList(inSession.getShokumuNaiyoList());

            oneSyokuReki.setZaisekikikanFrom(oneSyokuReki.getZaisekikikanFromYear() + oneSyokuReki.getZaisekikikanFromMonth());
            oneSyokuReki.setZaisekikikanTo(oneSyokuReki.getZaisekikikanToYear() + oneSyokuReki.getZaisekikikanToMonth());
            shokurekiListRtn.add(oneSyokuReki);
        }
        inSession.setShokurekiList(shokurekiListRtn);

        inSession.setGakkouName(inRequest.getGakkouName());
        inSession.setGakkouGakka(inRequest.getGakkouGakka());
        inSession.setGakkouShozaichi(inRequest.getGakkouShozaichi());

        inSession.setGraduationDateYear(inRequest.getGraduationDateYear());
        inSession.setGraduationDateMonth(inRequest.getGraduationDateMonth());

        inSession.setKunrenShisetsuName(inRequest.getKunrenShisetsuName());
        inSession.setKunrenka(inRequest.getKunrenka());
        inSession.setKunrenShozaichi(inRequest.getKunrenShozaichi());

        inSession.setKunrenSyuryonenFromYear(inRequest.getKunrenSyuryonenFromYear());
        inSession.setKunrenSyuryonenFromMonth(inRequest.getKunrenSyuryonenFromMonth());
        inSession.setKunrenSyuryonenToYear(inRequest.getKunrenSyuryonenToYear());
        inSession.setKunrenSyuryonenToMonth(inRequest.getKunrenSyuryonenToMonth());

        // ���ϕ��@ �N���W�b�g���� �ڍs���T�@����
        inSession.setKessaiJokyo(inRequest.getKessaiJokyo());
        inSession.setKessaiJknjkuryo(inRequest.getKessaiJknjkuryo());
        inSession.setKessaiJimutesuryo(inRequest.getKessaiJimutesuryo());
        // ���ϕ��@  �����p�R���r�j
        inSession.setKessaiShiharaiKigenbiYear(inRequest.getKessaiShiharaiKigenbiYear());
        inSession.setKessaiShiharaiKigenbiMonth(inRequest.getKessaiShiharaiKigenbiMonth());
        inSession.setKessaiShiharaiKigenbiDay(inRequest.getKessaiShiharaiKigenbiDay());

        inSession.setNyukinBiYear(inRequest.getNyukinBiYear());
        inSession.setNyukinBiMonth(inRequest.getNyukinBiMonth());
        inSession.setNyukinBiDay(inRequest.getNyukinBiDay());

        inSession.setKariUketsukeBiYear(inRequest.getKariUketsukeBiYear());
        inSession.setKariUketsukeBiMonth(inRequest.getKariUketsukeBiMonth());
        inSession.setKariUketsukeBiDay(inRequest.getKariUketsukeBiDay());
        inSession.setKessaiConvenienceHaraikomiNo(inRequest.getKessaiConvenienceHaraikomiNo());

        inSession.setKessaiKingakuTotal(inRequest.getKessaiKingakuTotal());
        inSession.setKessaiJokyo(inRequest.getKessaiJokyo());
        inSession.setPeijiKessaiShunokikanNo(inRequest.getPeijiKessaiShunokikanNo());
        inSession.setKessaiUserNo(inRequest.getKessaiUserNo());
        inSession.setKessaiKakuninNo(inRequest.getKessaiKakuninNo());
        inSession.setKessaiJknjkuryo(inRequest.getKessaiJknjkuryo());
        inSession.setKessaiJimutesuryo(inRequest.getKessaiJimutesuryo());

        inSession.setKessaiConvenienceShubetsu(inRequest.getKessaiConvenienceShubetsu());
        inSession.setKanriMemo(inRequest.getKanriMemo());
    }

    /**
     * ���̓`�F�b�N(����)
     *
     * @param inRequest
     * @return ��肪�Ȃ���� true�A����� false
     */
    private boolean ValidatorInput(HanyouSearchJoho inRequest, HanyouSearchJoho inSession) throws Exception {
        String groupCode = "";
        String itemName = "";

        //���b�Z�[�W�i�[�p
        Messages errors = new Messages();
        inSession.setKanriMemo(BmaStringUtility.trimSpace2(inSession.getKanriMemo()));
        //���l�S�p�ϊ����s
        inSession.setKanriMemo(BmaStringUtility.convertHankakuToZenkakuBma(inSession.getKanriMemo()));

        /*�\��������*/
        groupCode = "moshikomikanryoBiDay";
        /*�N*/
        itemName = "�\���������̔N";
        // �K�{�̃`�F�b�N
        if (BmaValidator.validateRequired(inSession.getMoshikomikanryoBiYear(), errors, groupCode, itemName)) {
            BmaValidator.validateMaxLength(inSession.getMoshikomikanryoBiYear(), 4, errors, groupCode, itemName);
            BmaValidator.validatePermissionSelect(inSession.getMoshikomikanryoBiYear(), inSession.getYearList(), errors, groupCode, itemName);
        }
        /*��*/
        itemName = "�\���������̌�";
        if (BmaValidator.validateRequired(inSession.getMoshikomikanryoBiMonth(), errors, groupCode, itemName)) {
            BmaValidator.validateMaxLength(inSession.getMoshikomikanryoBiMonth(), 2, errors, groupCode, itemName);
            BmaValidator.validatePermissionSelect(inSession.getMoshikomikanryoBiMonth(), inSession.getMonthList(), errors, groupCode, itemName);
        }
        /*��*/
        itemName = "�\���������̓�";
        if (BmaValidator.validateRequired(inSession.getMoshikomikanryoBiDay(), errors, groupCode, itemName)) {
            BmaValidator.validateMaxLength(inSession.getMoshikomikanryoBiDay(), 2, errors, groupCode, itemName);
            BmaValidator.validatePermissionSelect(inSession.getMoshikomikanryoBiDay(), inSession.getDayList(), errors, groupCode, itemName);
        }

        /*�\��������*/
        itemName = "�\��������";
        if (!BmaUtility.isNullOrEmpty(inSession.getMoshikomikanryoBiDay())
                && !BmaUtility.isNullOrEmpty(inSession.getMoshikomikanryoBiMonth())
                && !BmaUtility.isNullOrEmpty(inSession.getMoshikomikanryoBiYear())) {
            /*�N�������I������Ă���Ƃ����ݓ��`�F�b�N*/
            String strMoshikomikanryoBiDay = inSession.getMoshikomikanryoBiYear() + inSession.getMoshikomikanryoBiMonth() + inSession.getMoshikomikanryoBiDay();
            if (BmaValidator.validateDate(strMoshikomikanryoBiDay, errors, groupCode, itemName)) {
                inSession.setMoshikomikanryoBiYear(strMoshikomikanryoBiDay.substring(0, 4));
                inSession.setMoshikomikanryoBiMonth(strMoshikomikanryoBiDay.substring(4, 6));
                inSession.setMoshikomikanryoBiDay(strMoshikomikanryoBiDay.substring(6, 8));
            }
        }

        itemName = "���Ɛ\��";
        groupCode = "GenmenFlg";
        // �K�{�̃`�F�b�N
        if (BmaValidator.validateSelect(inSession.getGenmenFlg(), errors, groupCode, itemName)) {
            BmaValidator.validatePermissionSelect(inSession.getGenmenFlg(), inSession.getGenmenFlgList(), errors, groupCode, itemName);
            Validator.validateMaxLength(inSession.getGenmenFlg(), 1, errors, groupCode, itemName);
        }

        itemName = "�\���󋵋敪";
        groupCode = "MoshikomiJokyoKbn2";
        if (BmaValidator.validateRequired(inSession.getMoshikomiJokyoKbn2(), errors, groupCode, itemName)) {
            BmaValidator.validatePermissionSelect(inSession.getMoshikomiJokyoKbn2(), inSession.getMoshikomiJokyoKbnList(), errors, groupCode, itemName);
            Validator.validateMaxLength(inSession.getMoshikomiJokyoKbn2(), 10, errors, groupCode, itemName);
        }

        itemName = "�z���\��";
        groupCode = "HairyoFlg";
        if (BmaValidator.validateSelect(inSession.getHairyoFlg(), errors, groupCode, itemName)) {
            BmaValidator.validatePermissionSelect(inSession.getHairyoFlg(), inSession.getHairyoFlgList(), errors, groupCode, itemName);
            Validator.validateMaxLength(inSession.getHairyoFlg(), 2, errors, groupCode, itemName);
        }

        itemName = "�z�����e";
        groupCode = "HairyoNaiyo";
        if (inSession.getHairyoNaiyo() != null) {
            if (BmaValidator.validateMaxLength(inSession.getHairyoNaiyo(), 100, errors, groupCode, itemName)) {
                BmaValidator.validateMojiCodeForBiko(inSession.getHairyoNaiyo(), errors, groupCode, itemName);
            }
        }
        itemName = "���t��";
        groupCode = "SofuSakiKbn";
        if (BmaValidator.validateRequired(inSession.getSofuSakiKbn(), errors, groupCode, itemName)) {
            BmaValidator.validatePermissionSelect(inSession.getSofuSakiKbn(), inSession.getSofusakiList(), errors, groupCode, itemName);
            Validator.validateMaxLength(inSession.getSofuSakiKbn(), 2, errors, groupCode, itemName);
        }
        String sknKsuKbn = inSession.getSknKsuKbn();
        if (BmaConstants.SKN_KBN.equals(sknKsuKbn)) {
            itemName = "���ID�i�w�Ȏ����j";
            groupCode = "KaijoId1";
            BmaValidator.validatePermissionSelect(inSession.getKaijoId1(), inSession.getKaijoIdList(), errors, groupCode, itemName);
            Validator.validateMaxLength(inSession.getKaijoId1(), 2, errors, groupCode, itemName);

            itemName = "���ID�i���Z�����j";
            groupCode = "KaijoId2";
            BmaValidator.validatePermissionSelect(inSession.getKaijoId2(), inSession.getKaijoIdList(), errors, groupCode, itemName);
            Validator.validateMaxLength(inSession.getKaijoId2(), 2, errors, groupCode, itemName);
        } else if (BmaConstants.KSU_KBN.equals(sknKsuKbn)) {
            itemName = "�J�Òn�i�w�Ȏ����j";
            groupCode = "KaijoId";

            BmaValidator.validatePermissionSelect(inSession.getKaijoId(), inSession.getKaijoIdList(), errors, groupCode, itemName);
            Validator.validateMaxLength(inSession.getKaijoId(), 2, errors, groupCode, itemName);
        }

        itemName = "���i���";
        groupCode = "ShikakuCode";
        BmaValidator.validatePermissionSelect(inSession.getShikakuCode(), inSession.getShikakuList(), errors, groupCode, itemName);
        Validator.validateMaxLength(inSession.getShikakuCode(), 4, errors, groupCode, itemName);

        itemName = "�\�����i�ԍ�";
        groupCode = "ShinseiShikakuNo";
        Validator.validateMaxLength(inSession.getShinseiShikakuNo(), 20, errors, groupCode, itemName);
        itemName = "�Ə����";
        groupCode = "MenjoCode";

        BmaValidator.validatePermissionSelect(inSession.getMenjoCode(), inSession.getMenjoList(), errors, groupCode, itemName);
        Validator.validateMaxLength(inSession.getMenjoCode(), 4, errors, groupCode, itemName);

        itemName = "�Ə��ԍ�";
        groupCode = "ShinseiMenjoNo";
        Validator.validateMaxLength(inSession.getShinseiMenjoNo(), 20, errors, groupCode, itemName);

        // �E�����
        String shokurekiKbn1 = inSession.getShokurekiKbn1();
        if (BmaConstants.SHOKUREKI_KBN1.equals(shokurekiKbn1)) {
            List<HanyouSearchJoho> shokurekiList = inSession.getShokurekiList();

            int lineCnt = 1;
            for (int i = 0; i < shokurekiList.size(); i++) {
                HanyouSearchJoho oneSyokuReki = shokurekiList.get(i);
                //�S�p�ϊ����s
                inSession.setKinmusakiKaishaName(BmaStringUtility.convertHankakuToZenkakuBma(inSession.getKinmusakiKaishaName()));

                itemName = "�E�� " + lineCnt + " �̋Ζ���y�ю��Ə�";
                groupCode = "kinmusakiKaishaName";
                if (BmaValidator.validateRequired(oneSyokuReki.getKinmusakiKaishaName(), errors, groupCode, itemName)) {
                    Validator.validateMaxLength(oneSyokuReki.getKinmusakiKaishaName(), 100, errors, groupCode, itemName);
                    BmaValidator.validateMojiCode3(oneSyokuReki.getKinmusakiKaishaName(), errors, groupCode, itemName);
                }
                //�S�p�ϊ����s
                inSession.setBushoYakushokuName(BmaStringUtility.convertHankakuToZenkakuBma(inSession.getBushoYakushokuName()));
                itemName = "�E�� " + lineCnt + " �̕�����E��";
                groupCode = "bushoYakushokuName";
                if (BmaValidator.validateRequired(oneSyokuReki.getBushoYakushokuName(), errors, groupCode, itemName)) {
                    Validator.validateMaxLength(oneSyokuReki.getBushoYakushokuName(), 100, errors, groupCode, itemName);
                    BmaValidator.validateMojiCode3(oneSyokuReki.getBushoYakushokuName(), errors, groupCode, itemName);
                }
                itemName = "�E�� " + lineCnt + " �̐E�����e";
                groupCode = "shokumuNaiyo";
                if (BmaValidator.validateRequired(oneSyokuReki.getShokumuNaiyo(), errors, groupCode, itemName)) {
                    Validator.validateMaxLength(oneSyokuReki.getShokumuNaiyo(), 2, errors, groupCode, itemName);
                    BmaValidator.validatePermissionSelect(inSession.getShokumuNaiyo(), inSession.getShokumuNaiyoList(), errors, groupCode, itemName);
                }

                //�S�p�ϊ����s
                inSession.setShozaichi(BmaStringUtility.convertHankakuToZenkakuBma(inSession.getShozaichi()));
                itemName = "�E�� " + lineCnt + " �̏��ݒn";
                groupCode = "Shozaichi";
                if (BmaValidator.validateRequired(oneSyokuReki.getShozaichi(), errors, groupCode, itemName)) {
                    Validator.validateMaxLength(oneSyokuReki.getShozaichi(), 100, errors, groupCode, itemName);
                    BmaValidator.validateMojiCode3(oneSyokuReki.getShozaichi(), errors, groupCode, itemName);
                }
                /*�N*/
                itemName = "�E�� " + lineCnt + " �̍ݐE����FROM�̔N";
                groupCode = "ZaisekikikanFromYear";
                // �K�{�̃`�F�b�N
                if (BmaValidator.validateRequired(oneSyokuReki.getZaisekikikanFromYear(), errors, groupCode, itemName)) {
                    BmaValidator.validateMaxLength(oneSyokuReki.getZaisekikikanFromYear(), 4, errors, groupCode, itemName);
                    BmaValidator.validatePermissionSelect(oneSyokuReki.getZaisekikikanFromYear(), oneSyokuReki.getYearList(), errors, groupCode, itemName);
                }
                itemName = "�E�� " + lineCnt + " �̍ݐE����FROM�̌�";
                groupCode = "zaisekikikanFromMonth";
                if (BmaValidator.validateRequired(oneSyokuReki.getZaisekikikanFromMonth(), errors, groupCode, itemName)) {
                    BmaValidator.validateMaxLength(oneSyokuReki.getZaisekikikanFromMonth(), 2, errors, groupCode, itemName);
                    BmaValidator.validatePermissionSelect(oneSyokuReki.getZaisekikikanFromMonth(), oneSyokuReki.getMonthList(), errors, groupCode, itemName);
                }
                /*�N*/
                itemName = "�E�� " + lineCnt + " �̍ݐE����TO�̔N";
                groupCode = "ZaisekikikanToYear";
                // �K�{�̃`�F�b�N
                if (BmaValidator.validateRequired(oneSyokuReki.getZaisekikikanToYear(), errors, groupCode, itemName)) {
                    BmaValidator.validateMaxLength(oneSyokuReki.getZaisekikikanToYear(), 4, errors, groupCode, itemName);
                    BmaValidator.validatePermissionSelect(oneSyokuReki.getZaisekikikanToYear(), oneSyokuReki.getYearList(), errors, groupCode, itemName);
                }
                itemName = "�E�� " + lineCnt + " �̍ݐE����TO�̌�";
                groupCode = "zaisekikikanToMonth";
                if (BmaValidator.validateRequired(oneSyokuReki.getZaisekikikanToMonth(), errors, groupCode, itemName)) {
                    BmaValidator.validateMaxLength(oneSyokuReki.getZaisekikikanToMonth(), 2, errors, groupCode, itemName);
                    BmaValidator.validatePermissionSelect(oneSyokuReki.getZaisekikikanToMonth(), oneSyokuReki.getMonthList(), errors, groupCode, itemName);
                }
                lineCnt++;
            }
        }

        // �w�����
        String shokurekiKbn3 = inSession.getShokurekiKbn3();
        if (BmaConstants.SHOKUREKI_KBN3.equals(shokurekiKbn3)) {
            //�S�p�ϊ����s
           inSession.setGakkouName(BmaStringUtility.convertHankakuToZenkakuBma(inSession.getGakkouName()));
           inSession.setGakkouGakka(BmaStringUtility.convertHankakuToZenkakuBma(inSession.getGakkouGakka()));
           inSession.setGakkouShozaichi(BmaStringUtility.convertHankakuToZenkakuBma(inSession.getGakkouShozaichi()));
            itemName = " �w�Z��";
            groupCode = "gakkouName";
            if (BmaValidator.validateRequired(inSession.getGakkouName(), errors, groupCode, itemName)) {
                Validator.validateMaxLength(inSession.getGakkouName(), 100, errors, groupCode, itemName);
                BmaValidator.validateMojiCode3(inSession.getGakkouName(), errors, groupCode, itemName);
            }

            itemName = " �w�Ȃ܂��͉ے�";
            groupCode = "GakkouGakka";
            if (BmaValidator.validateRequired(inSession.getGakkouGakka(), errors, groupCode, itemName)) {
                Validator.validateMaxLength(inSession.getGakkouGakka(), 100, errors, groupCode, itemName);
                BmaValidator.validateMojiCode3(inSession.getGakkouGakka(), errors, groupCode, itemName);
            }
            itemName = " �w�Z���ݒn";
            groupCode = "GakkouShozaichi";
            if (BmaValidator.validateRequired(inSession.getGakkouShozaichi(), errors, groupCode, itemName)) {
                Validator.validateMaxLength(inSession.getGakkouShozaichi(), 100, errors, groupCode, itemName);
                BmaValidator.validateMojiCode3(inSession.getGakkouShozaichi(), errors, groupCode, itemName);
            }

            /*�N*/
            itemName = "���ƔN�����̔N";
            groupCode = "GraduationDateYear";
            // �K�{�̃`�F�b�N
            if (BmaValidator.validateRequired(inSession.getGraduationDateYear(), errors, groupCode, itemName)) {
                BmaValidator.validateMaxLength(inSession.getGraduationDateYear(), 4, errors, groupCode, itemName);
                BmaValidator.validatePermissionSelect(inSession.getGraduationDateYear(), inSession.getYearList(), errors, groupCode, itemName);
            }
            groupCode = "GraduationDateMonth";
            itemName = "���ƔN�����̂̌�";
            if (BmaValidator.validateRequired(inSession.getGraduationDateMonth(), errors, groupCode, itemName)) {
                BmaValidator.validateMaxLength(inSession.getGraduationDateMonth(), 2, errors, groupCode, itemName);
                BmaValidator.validatePermissionSelect(inSession.getGraduationDateMonth(), inSession.getMonthList(), errors, groupCode, itemName);
            }
        }

        // �P�������
        String shokurekiKbn4 = inSession.getShokurekiKbn4();
        if (BmaConstants.SHOKUREKI_KBN4.equals(shokurekiKbn4)) {
            //�S�p�ϊ����s
           inSession.setKunrenShisetsuName(BmaStringUtility.convertHankakuToZenkakuBma(inSession.getKunrenShisetsuName()));
           inSession.setKunrenka(BmaStringUtility.convertHankakuToZenkakuBma(inSession.getKunrenka()));
           inSession.setKunrenShozaichi(BmaStringUtility.convertHankakuToZenkakuBma(inSession.getKunrenShozaichi()));
            itemName = " �P���{�ݖ�(�P����)";
            groupCode = "kunrenShisetsuName";
            if (BmaValidator.validateRequired(inSession.getKunrenShisetsuName(), errors, groupCode, itemName)) {
                Validator.validateMaxLength(inSession.getKunrenShisetsuName(), 100, errors, groupCode, itemName);
                BmaValidator.validateMojiCode3(inSession.getKunrenShisetsuName(), errors, groupCode, itemName);
            }

            itemName = " �P����";
            groupCode = "Kunrenka";
            if (BmaValidator.validateRequired(inSession.getKunrenka(), errors, groupCode, itemName)) {
                Validator.validateMaxLength(inSession.getKunrenka(), 100, errors, groupCode, itemName);
                BmaValidator.validateMojiCode3(inSession.getKunrenka(), errors, groupCode, itemName);
            }
            itemName = " �P���{�ݏ��ݒn";
            groupCode = "KunrenShozaichi";
            if (BmaValidator.validateRequired(inSession.getKunrenShozaichi(), errors, groupCode, itemName)) {
                Validator.validateMaxLength(inSession.getKunrenShozaichi(), 100, errors, groupCode, itemName);
                BmaValidator.validateMojiCode3(inSession.getKunrenShozaichi(), errors, groupCode, itemName);
            }
            /*�N*/
            groupCode = "KunrenSyuryonenFromYear";
            itemName = "�P������FROM�̔N";
            // �K�{�̃`�F�b�N
            if (BmaValidator.validateRequired(inSession.getKunrenSyuryonenFromYear(), errors, groupCode, itemName)) {
                BmaValidator.validateMaxLength(inSession.getKunrenSyuryonenFromYear(), 4, errors, groupCode, itemName);
                BmaValidator.validatePermissionSelect(inSession.getKunrenSyuryonenFromYear(), inSession.getYearList(), errors, groupCode, itemName);
            }
            groupCode = "KunrenSyuryonenFromMonth";
            itemName = "�P������FROM�̌�";
            if (BmaValidator.validateRequired(inSession.getKunrenSyuryonenFromMonth(), errors, groupCode, itemName)) {
                BmaValidator.validateMaxLength(inSession.getKunrenSyuryonenFromMonth(), 2, errors, groupCode, itemName);
                BmaValidator.validatePermissionSelect(inSession.getKunrenSyuryonenFromMonth(), inSession.getMonthList(), errors, groupCode, itemName);
            }
            /*�N*/
            itemName = "�P������TO�̔N";
            groupCode = "KunrenSyuryonenToYear";
            // �K�{�̃`�F�b�N
            if (BmaValidator.validateRequired(inSession.getKunrenSyuryonenToYear(), errors, groupCode, itemName)) {
                BmaValidator.validateMaxLength(inSession.getKunrenSyuryonenToYear(), 4, errors, groupCode, itemName);
                BmaValidator.validatePermissionSelect(inSession.getKunrenSyuryonenToYear(), inSession.getYearList(), errors, groupCode, itemName);
            }
            groupCode = "KunrenSyuryonenToMonth";
            itemName = "�P������TO�̌�";
            if (BmaValidator.validateRequired(inSession.getKunrenSyuryonenToMonth(), errors, groupCode, itemName)) {
                BmaValidator.validateMaxLength(inSession.getKunrenSyuryonenToMonth(), 2, errors, groupCode, itemName);
                BmaValidator.validatePermissionSelect(inSession.getKunrenSyuryonenToMonth(), inSession.getMonthList(), errors, groupCode, itemName);
            }
        }

        switch (inSession.getShosai()) {
            case BmaConstants.KESSAI_HOHO_KBN_CREDIT:
            case BmaConstants.KESSAI_HOHO_KBN_BENEFITS:
                // ����
                itemName = "���Ϗ�";
                groupCode = "KessaiJokyo";
                if (BmaValidator.validateRequired(inSession.getKessaiJokyo(), errors, groupCode, itemName)) {
                    BmaValidator.validatePermissionSelect(inSession.getKessaiJokyo(), inSession.getKessaiJokyoKbnList(), errors, groupCode, itemName);
                    Validator.validateMaxLength(inSession.getKessaiJokyo(), 1, errors, groupCode, itemName);
                }
                itemName = "�󌟁^��u��";
                groupCode = "KessaiJknjkuryo";
                if (BmaValidator.validateRequired(inSession.getKessaiJknjkuryo(), errors, groupCode, itemName)) {
                    BmaValidator.validateNumber(inSession.getKessaiJknjkuryo(), errors, groupCode, itemName);
                    Validator.validateMaxLength(inSession.getKessaiJknjkuryo(), 6, errors, groupCode, itemName);
                }
                itemName = "�����萔��";
                groupCode = "KessaiJimutesuryo";
                if (BmaValidator.validateRequired(inSession.getKessaiJimutesuryo(), errors, groupCode, itemName)) {
                    BmaValidator.validateNumber(inSession.getKessaiJimutesuryo(), errors, groupCode, itemName);
                    Validator.validateMaxLength(inSession.getKessaiJimutesuryo(), 6, errors, groupCode, itemName);
                }

                break;
            case BmaConstants.KESSAI_HOHO_KBN_CONVENIENCE:
                // ����
                itemName = "���Ϗ�";
                groupCode = "KessaiJokyo";
                if (BmaValidator.validateRequired(inSession.getKessaiJokyo(), errors, groupCode, itemName)) {
                    BmaValidator.validatePermissionSelect(inSession.getKessaiJokyo(), inSession.getKessaiJokyoKbnList(), errors, groupCode, itemName);
                    Validator.validateMaxLength(inSession.getKessaiJokyo(), 1, errors, groupCode, itemName);
                }

                itemName = "�����`�[�ԍ�";
                groupCode = "kKessaiConvenienceHaraikomiNo";
                if (BmaValidator.validateRequired(inSession.getKessaiConvenienceHaraikomiNo(), errors, groupCode, itemName)) {
                    Validator.validateMaxLength(inSession.getKessaiConvenienceHaraikomiNo(), 20, errors, groupCode, itemName);
                }
                itemName = "�����p�R���r�j";
                groupCode = "KessaiConvenienceShubetsu";
                // �K�{�̃`�F�b�N
                if (BmaValidator.validateRequired(inSession.getKessaiConvenienceShubetsu(), errors, groupCode, itemName)) {
                    BmaValidator.validateMaxLength(inSession.getKessaiConvenienceShubetsu(), 2, errors, groupCode, itemName);
                    BmaValidator.validatePermissionSelect(inSession.getKessaiConvenienceShubetsu(), inSession.getKessaiConvenienceShubetsuList(), errors, groupCode, itemName);
                }
                itemName = "�󌟁^��u��";
                groupCode = "KessaiJknjkuryo";
                if (BmaValidator.validateRequired(inSession.getKessaiJknjkuryo(), errors, groupCode, itemName)) {
                    BmaValidator.validateNumber(inSession.getKessaiJknjkuryo(), errors, groupCode, itemName);
                    Validator.validateMaxLength(inSession.getKessaiJknjkuryo(), 6, errors, groupCode, itemName);
                }
                itemName = "�����萔��";
                groupCode = "KessaiJimutesuryo";
                if (BmaValidator.validateRequired(inSession.getKessaiJimutesuryo(), errors, groupCode, itemName)) {
                    BmaValidator.validateNumber(inSession.getKessaiJimutesuryo(), errors, groupCode, itemName);
                    Validator.validateMaxLength(inSession.getKessaiJimutesuryo(), 6, errors, groupCode, itemName);
                }
                itemName = "���x���������̔N";
                groupCode = "KessaiShiharaiKigenbiYear";
                // �K�{�̃`�F�b�N
                if (BmaValidator.validateRequired(inSession.getKessaiShiharaiKigenbiYear(), errors, groupCode, itemName)) {
                    BmaValidator.validateMaxLength(inSession.getKessaiShiharaiKigenbiYear(), 4, errors, groupCode, itemName);
                    BmaValidator.validatePermissionSelect(inSession.getKessaiShiharaiKigenbiYear(), inSession.getYearList(), errors, groupCode, itemName);
                }
                groupCode = "KessaiShiharaiKigenbiMonth";
                itemName = "���x���������̌�";
                if (BmaValidator.validateRequired(inSession.getKessaiShiharaiKigenbiMonth(), errors, groupCode, itemName)) {
                    BmaValidator.validateMaxLength(inSession.getKessaiShiharaiKigenbiMonth(), 2, errors, groupCode, itemName);
                    BmaValidator.validatePermissionSelect(inSession.getKessaiShiharaiKigenbiMonth(), inSession.getMonthList(), errors, groupCode, itemName);
                }
                groupCode = "KessaiShiharaiKigenbiDay";
                itemName = "���x���������̓�";
                if (BmaValidator.validateRequired(inSession.getKessaiShiharaiKigenbiDay(), errors, groupCode, itemName)) {
                    BmaValidator.validateMaxLength(inSession.getKessaiShiharaiKigenbiDay(), 2, errors, groupCode, itemName);
                    BmaValidator.validatePermissionSelect(inSession.getKessaiShiharaiKigenbiDay(), inSession.getDayList(), errors, groupCode, itemName);
                }

                break;
            case BmaConstants.KESSAI_HOHO_KBN_PAGE:
                // ����
                itemName = "���Ϗ�";
                groupCode = "KessaiJokyo";
                if (BmaValidator.validateRequired(inSession.getKessaiJokyo(), errors, groupCode, itemName)) {
                    BmaValidator.validatePermissionSelect(inSession.getKessaiJokyo(), inSession.getKessaiJokyoKbnList(), errors, groupCode, itemName);
                    Validator.validateMaxLength(inSession.getKessaiJokyo(), 1, errors, groupCode, itemName);
                }
                itemName = "���[���Ԕԍ�";
                groupCode = "PeijiKessaiShunokikanNo";
                if (BmaValidator.validateRequired(inSession.getPeijiKessaiShunokikanNo(), errors, groupCode, itemName)) {
                    BmaValidator.validateNumber(inSession.getPeijiKessaiShunokikanNo(), errors, groupCode, itemName);
                    Validator.validateMaxLength(inSession.getPeijiKessaiShunokikanNo(), 5, errors, groupCode, itemName);
                }
                itemName = "���q�l�ԍ�";
                groupCode = "PeijiKessaiShunokikanNo";
                if (BmaValidator.validateRequired(inSession.getKessaiUserNo(), errors, groupCode, itemName)) {
                    BmaValidator.validateNumber(inSession.getKessaiUserNo(), errors, groupCode, itemName);
                    Validator.validateMaxLength(inSession.getKessaiUserNo(), 20, errors, groupCode, itemName);
                }

                itemName = "�m�F�ԍ�";
                groupCode = "PeijiKessaiShunokikanNo";
                if (BmaValidator.validateRequired(inSession.getKessaiKakuninNo(), errors, groupCode, itemName)) {
                    BmaValidator.validateNumber(inSession.getKessaiKakuninNo(), errors, groupCode, itemName);
                    Validator.validateMaxLength(inSession.getKessaiKakuninNo(), 6, errors, groupCode, itemName);
                }
                itemName = "�󌟁^��u��";
                groupCode = "KessaiJknjkuryo";
                if (BmaValidator.validateRequired(inSession.getKessaiJknjkuryo(), errors, groupCode, itemName)) {
                    BmaValidator.validateNumber(inSession.getKessaiJknjkuryo(), errors, groupCode, itemName);
                    Validator.validateMaxLength(inSession.getKessaiJknjkuryo(), 6, errors, groupCode, itemName);
                }
                itemName = "�����萔��";
                groupCode = "KessaiJimutesuryo";
                if (BmaValidator.validateRequired(inSession.getKessaiJimutesuryo(), errors, groupCode, itemName)) {
                    BmaValidator.validateNumber(inSession.getKessaiJimutesuryo(), errors, groupCode, itemName);
                    Validator.validateMaxLength(inSession.getKessaiJimutesuryo(), 6, errors, groupCode, itemName);
                }
                break;
            case BmaConstants.KESSAI_HOHO_KBN_POSTAL:
            case BmaConstants.KESSAI_HOHO_KBN_BANK:
                // ����
                itemName = "���Ϗ�";
                groupCode = "KessaiJokyo";
                if (BmaValidator.validateRequired(inSession.getKessaiJokyo(), errors, groupCode, itemName)) {
                    BmaValidator.validatePermissionSelect(inSession.getKessaiJokyo(), inSession.getKessaiJokyoKbnList(), errors, groupCode, itemName);
                    Validator.validateMaxLength(inSession.getKessaiJokyo(), 1, errors, groupCode, itemName);
                }
                itemName = "�����z";
                groupCode = "kessaiKingakuTotal";
                if (BmaValidator.validateRequired(inSession.getKessaiKingakuTotal(), errors, groupCode, itemName)) {
                    BmaValidator.validateNumber(inSession.getKessaiKingakuTotal(), errors, groupCode, itemName);
                    Validator.validateMaxLength(inSession.getKessaiKingakuTotal(), 6, errors, groupCode, itemName);
                }
                itemName = "�������̔N";
                groupCode = "NyukinBiYear";
                // �K�{�̃`�F�b�N
                if (BmaValidator.validateRequired(inSession.getNyukinBiYear(), errors, groupCode, itemName)) {
                    BmaValidator.validateMaxLength(inSession.getNyukinBiYear(), 4, errors, groupCode, itemName);
                    BmaValidator.validatePermissionSelect(inSession.getNyukinBiYear(), inSession.getYearList(), errors, groupCode, itemName);
                }
                groupCode = "NyukinBiMonth";
                itemName = "�������̌�";
                if (BmaValidator.validateRequired(inSession.getNyukinBiMonth(), errors, groupCode, itemName)) {
                    BmaValidator.validateMaxLength(inSession.getNyukinBiMonth(), 2, errors, groupCode, itemName);
                    BmaValidator.validatePermissionSelect(inSession.getNyukinBiMonth(), inSession.getMonthList(), errors, groupCode, itemName);
                }
                groupCode = "NyukinBiDay";
                itemName = "�������̓�";
                if (BmaValidator.validateRequired(inSession.getNyukinBiDay(), errors, groupCode, itemName)) {
                    BmaValidator.validateMaxLength(inSession.getNyukinBiDay(), 2, errors, groupCode, itemName);
                    BmaValidator.validatePermissionSelect(inSession.getNyukinBiDay(), inSession.getDayList(), errors, groupCode, itemName);
                }

                itemName = "�m�F���̔N";
                groupCode = "KariUketsukeBi";
                // �K�{�̃`�F�b�N
                if (BmaValidator.validateRequired(inSession.getKariUketsukeBiYear(), errors, groupCode, itemName)) {
                    BmaValidator.validateMaxLength(inSession.getKariUketsukeBiYear(), 4, errors, groupCode, itemName);
                    BmaValidator.validatePermissionSelect(inSession.getKariUketsukeBiYear(), inSession.getYearList(), errors, groupCode, itemName);
                }
                groupCode = "NyukinBiMonth";
                itemName = "�m�F���̌�";
                if (BmaValidator.validateRequired(inSession.getKariUketsukeBiMonth(), errors, groupCode, itemName)) {
                    BmaValidator.validateMaxLength(inSession.getKariUketsukeBiMonth(), 2, errors, groupCode, itemName);
                    BmaValidator.validatePermissionSelect(inSession.getKariUketsukeBiMonth(), inSession.getMonthList(), errors, groupCode, itemName);
                }
                groupCode = "NyukinBiDay";
                itemName = "�m�F���̓�";
                if (BmaValidator.validateRequired(inSession.getKariUketsukeBiDay(), errors, groupCode, itemName)) {
                    BmaValidator.validateMaxLength(inSession.getKariUketsukeBiDay(), 2, errors, groupCode, itemName);
                    BmaValidator.validatePermissionSelect(inSession.getKariUketsukeBiDay(), inSession.getDayList(), errors, groupCode, itemName);
                }
                break;
            default:
                break;
        }
        /* ���l */
        groupCode = "KanriMemo";
        itemName = "���l";
        if (BmaValidator.validateMaxLength(inSession.getKanriMemo(), BmaConstants.MAX_LENGTH_BIKO, errors, groupCode, itemName)) {
            BmaValidator.validateMojiCodeForBiko(inSession.getKanriMemo(), errors, groupCode, itemName);
        }

        if (!errors.isEmpty()) {
            inSession.setErrors(errors);
            return false;
        } else {
            return true;
        }
    }

}
