package jp.co.nii.bma.business.rto.manager;

import java.util.ArrayList;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import jp.co.nii.sew.presentation.AbstractRequestTransferObject;
import jp.co.nii.sew.presentation.Messages;
import jp.co.nii.sew.presentation.Option;

/**
 *
 * @author nii19049
 */
public class MstKanriKaijoMstJoho extends AbstractRequestTransferObject {
    private Messages errors;
    private String moshikomishaId;
    
    private String kaijoMstTable;
    
    //���}�X�^�������
    private String kaijoMstSearch;
    private String kaijoMstUpdateInput;
    private String kaijoMstBack;
    private String kaijoMstShinkiInput;
    private String kaijoMstDetail;

    //���}�X�^�V�K�o�^���
    private String kaijoMstYubinSearch;
    private String kaijoMstInpConf;
    private String kaijoMstInpBack;

    //���}�X�^�V�K�o�^�m�F���
    private String kaijoMstConfComp;
    private String kaijoMstConfBack;

    //���}�X�^�V�K�o�^�������
    private String kaijoMstInpCompBack;
    
    private String next;
    private String back;
    
    //���f�[�^
    private String kaisaichiCode;
    private String kaisaichiName;
    private String kaijoCode;
    private String kaijoName;
    private String kaijoNameRyaku;
    private String yubinNo;
    private String jusho;
    private String teiin;
    private String kaijoHenkoFlg;
    private String chushajoFlg;
    private String chizuData;
    private String biko;
    private String bikoDisp;

    private String yubinNoFront;
    private String yubinNoBack;
    private String teiinDisp;
    private String kaijoHenkoFlgName;
    private String chushajoFlgName;
    
    private String tmpFutter;
    private String comUmuFlg;
    private List<Option> comUmuFlgList;
    private List<Option> kaisaichiCodeList;
    private List<KaisaichiJoho> kaisaichiDetailList;
    private List<MstKanriKaijoMstJoho> kaijoMstResultList;
    private String kaijoMstSrcListFlg;
    private String[] kaisaichiSelect;
    
    /* ������ʁ@�y�[�W���� */
    private int pageMax;
    private int page;
    private int maxDisp;
    private int firstDisp;
    private int pageBegin;
    private int pageEnd;
    private String CommandPage;
    private String pageIndex;
    private List<MstKanriKaijoMstJoho> kaijoDisplayList;
    
    
    /**
     * ���������\�b�h
     */
    public void clearInfo() {
        setErrors(new Messages());
        String initKaisaichi[] = {""};
        setKaijoMstTable("");
        setMoshikomishaId("");
        //�{�^��
        setKaijoMstSearch("");
        setKaijoMstUpdateInput("");
        setKaijoMstBack("");
        setKaijoMstDetail("");
        setKaijoMstShinkiInput("");
        setKaijoMstYubinSearch("");
        setKaijoMstInpConf("");
        setKaijoMstInpBack("");
        setKaijoMstConfComp("");
        setKaijoMstConfBack("");
        setKaijoMstInpCompBack("");
        setNext("");
        setBack("");
        
        //�f�[�^
        setKaisaichiName("");
        setKaisaichiCode("");
        setKaijoCode("");
        setKaijoName("");
        setKaijoNameRyaku("");
        setYubinNo("");
        setJusho("");
        setTeiin("");
        setKaijoHenkoFlg("");
        setChushajoFlg("0");
        setChizuData("");
        setBiko("");
        setTeiinDisp("");
        setBikoDisp("");
        
        setYubinNoFront("");
        setYubinNoBack("");
        
        setTmpFutter("");
        setKaijoHenkoFlgName("");
        setChushajoFlgName("");
        setComUmuFlg("");
        setKaisaichiCodeList(new ArrayList<Option>());
        setKaijoMstResultList(new ArrayList<MstKanriKaijoMstJoho>());
        setKaijoMstSrcListFlg("");
        setKaisaichiSelect(initKaisaichi);
        
        setFirstDisp(0);
        setMaxDisp(0);
        setPage(0);
        setPageBegin(0);
        setPageEnd(0);
        setPageMax(0);
        setCommandPage("");
        setPageIndex("");
        setKaijoDisplayList(new ArrayList<MstKanriKaijoMstJoho>());
    }

    /**
     * @return the errors
     */
    public Messages getErrors() {
        return errors;
    }

    /**
     * @param errors the errors to set
     */
    public void setErrors(Messages errors) {
        this.errors = errors;
    }

    
    /**
     * @return the kaisaichiName
     */
    public String getKaisaichiName() {
        return kaisaichiName;
    }

    /**
     * @param kaisaichiName the kaisaichiName to set
     */
    public void setKaisaichiName(String kaisaichiName) {
        this.kaisaichiName = kaisaichiName;
    }

     /**
     * @return the kaijoName
     */
    public String getKaijoName() {
        return kaijoName;
    }

    /**
     * @param kaijoName the kaijoName to set
     */
    public void setKaijoName(String kaijoName) {
        this.kaijoName = kaijoName;
    }

    /**
     * @return the jusho
     */
    public String getJusho() {
        return jusho;
    }

    /**
     * @param jusho the jusho to set
     */
    public void setJusho(String jusho) {
        this.jusho = jusho;
    }

    /**
     * @return the teiin
     */
    public String getTeiin() {
        return teiin;
    }

    /**
     * @param teiin the teiin to set
     */
    public void setTeiin(String teiin) {
        this.teiin = teiin;
    }

    /**
     * @return the kaijoMstSearch
     */
    public String getKaijoMstSearch() {
        return kaijoMstSearch;
    }

    /**
     * @param kaijoMstSearch the kaijoMstSearch to set
     */
    public void setKaijoMstSearch(String kaijoMstSearch) {
        this.kaijoMstSearch = kaijoMstSearch;
    }

    /**
     * @return the kaijoMstUpdateInput
     */
    public String getKaijoMstUpdateInput() {
        return kaijoMstUpdateInput;
    }

    /**
     * @param kaijoMstUpdateInput the kaijoMstUpdateInput to set
     */
    public void setKaijoMstUpdateInput(String kaijoMstUpdateInput) {
        this.kaijoMstUpdateInput = kaijoMstUpdateInput;
    }

    /**
     * @return the kaijoMstBack
     */
    public String getKaijoMstBack() {
        return kaijoMstBack;
    }

    /**
     * @param kaijoMstBack the kaijoMstBack to set
     */
    public void setKaijoMstBack(String kaijoMstBack) {
        this.kaijoMstBack = kaijoMstBack;
    }

    /**
     * @return the kaijoMstShinkiInput
     */
    public String getKaijoMstShinkiInput() {
        return kaijoMstShinkiInput;
    }

    /**
     * @param kaijoMstShinkiInput the kaijoMstShinkiInput to set
     */
    public void setKaijoMstShinkiInput(String kaijoMstShinkiInput) {
        this.kaijoMstShinkiInput = kaijoMstShinkiInput;
    }
    
    
    @Override
    public void copyFromRequest(HttpServletRequest request) {
        setKaijoMstTable((String) request.getAttribute("kaijoMstTable"));
        //�{�^��
        setKaijoMstSearch((String) request.getAttribute("kaijoMstSearch"));
        setKaijoMstUpdateInput((String) request.getAttribute("kaijoMstUpdateInput"));
        setKaijoMstDetail((String) request.getAttribute("kaijoMstDetail"));
        setKaijoMstBack((String) request.getAttribute("kaijoMstBack"));
        setKaijoMstShinkiInput((String) request.getAttribute("kaijoMstShinkiInput"));
        setKaijoMstYubinSearch((String) request.getAttribute("kaijoMstYubinSearch"));
        setKaijoMstInpConf((String) request.getAttribute("kaijoMstInpConf"));
        setKaijoMstInpBack((String) request.getAttribute("kaijoMstInpBack"));
        setKaijoMstConfComp((String) request.getAttribute("kaijoMstConfComp"));
        setKaijoMstConfBack((String) request.getAttribute("kaijoMstConfBack"));
        setKaijoMstInpCompBack((String) request.getAttribute("kaijoMstInpCompBack"));
        setNext((String) request.getAttribute("next"));
        setBack((String) request.getAttribute("back"));
        
        //�f�[�^
        setKaisaichiName((String) request.getAttribute("kaisaichiName"));
        setKaisaichiCode((String) request.getAttribute("kaisaichiCode"));
        setKaijoCode((String) request.getAttribute("kaijoCode"));
        setKaijoName((String) request.getAttribute("kaijoName"));
        setKaijoNameRyaku((String) request.getAttribute("kaijoNameRyaku"));
        setYubinNo((String) request.getAttribute("yubinNo"));
        setJusho((String) request.getAttribute("jusho"));
        setTeiin((String) request.getAttribute("teiin"));
        setKaijoHenkoFlg((String) request.getAttribute("kaijoHenkoFlg"));
        setChushajoFlg((String) request.getAttribute("chushajoFlg"));
        setChizuData((String) request.getAttribute("chizuData"));
        setBiko((String) request.getAttribute("biko"));
        setComUmuFlg((String) request.getAttribute("comUmuFlg"));
        setKaisaichiCodeList((List<Option>) request.getAttribute("kaisaichiCodeList"));
        setKaijoMstResultList((List<MstKanriKaijoMstJoho>) request.getAttribute("kaijoMstResultList"));
        setKaijoMstSrcListFlg((String) request.getAttribute("kaijoMstSrcListFlg"));
        setKaijoHenkoFlgName((String) request.getAttribute("kaijoHenkoFlgName"));
        setChushajoFlgName((String) request.getAttribute("chushajoFlgName"));
        setKaisaichiSelect((String[]) request.getParameterValues("kaisaichiSelect"));
        setTeiinDisp((String) request.getAttribute("teiinDisp"));
        
        setYubinNoFront((String) request.getAttribute("yubinNoFront"));
        setYubinNoBack((String) request.getAttribute("yubinNoBack"));

        setCommandPage((String) request.getAttribute("commandPage"));
        setPageIndex((String) request.getAttribute("pageIndex"));

        HttpSession session = request.getSession(false);
        if (session.getAttribute("MgrTopJoho") != null) {
            MgrTopJoho tmp = (MgrTopJoho) session.getAttribute("MgrTopJoho");
            setMoshikomishaId((String) tmp.getMoshikomishaId());
        }
    }

    /**
     * @return the kaijoMstYubinSearch
     */
    public String getKaijoMstYubinSearch() {
        return kaijoMstYubinSearch;
    }

    /**
     * @param kaijoMstYubinSearch the kaijoMstYubinSearch to set
     */
    public void setKaijoMstYubinSearch(String kaijoMstYubinSearch) {
        this.kaijoMstYubinSearch = kaijoMstYubinSearch;
    }

    /**
     * @return the kaijoMstInpConf
     */
    public String getKaijoMstInpConf() {
        return kaijoMstInpConf;
    }

    /**
     * @param kaijoMstInpConf the kaijoMstInpConf to set
     */
    public void setKaijoMstInpConf(String kaijoMstInpConf) {
        this.kaijoMstInpConf = kaijoMstInpConf;
    }

    /**
     * @return the kaijoMstInpBack
     */
    public String getKaijoMstInpBack() {
        return kaijoMstInpBack;
    }

    /**
     * @param kaijoMstInpBack the kaijoMstInpBack to set
     */
    public void setKaijoMstInpBack(String kaijoMstInpBack) {
        this.kaijoMstInpBack = kaijoMstInpBack;
    }

    /**
     * @return the kaijoMstConfComp
     */
    public String getKaijoMstConfComp() {
        return kaijoMstConfComp;
    }

    /**
     * @param kaijoMstConfComp the kaijoMstConfComp to set
     */
    public void setKaijoMstConfComp(String kaijoMstConfComp) {
        this.kaijoMstConfComp = kaijoMstConfComp;
    }

    /**
     * @return the kaijoMstConfBack
     */
    public String getKaijoMstConfBack() {
        return kaijoMstConfBack;
    }

    /**
     * @param kaijoMstConfBack the kaijoMstConfBack to set
     */
    public void setKaijoMstConfBack(String kaijoMstConfBack) {
        this.kaijoMstConfBack = kaijoMstConfBack;
    }

    /**
     * @return the kaijoMstInpCompBack
     */
    public String getKaijoMstInpCompBack() {
        return kaijoMstInpCompBack;
    }

    /**
     * @param kaijoMstInpCompBack the kaijoMstInpCompBack to set
     */
    public void setKaijoMstInpCompBack(String kaijoMstInpCompBack) {
        this.kaijoMstInpCompBack = kaijoMstInpCompBack;
    }

    /**
     * @return the next
     */
    public String getNext() {
        return next;
    }

    /**
     * @param next the next to set
     */
    public void setNext(String next) {
        this.next = next;
    }

    /**
     * @return the back
     */
    public String getBack() {
        return back;
    }

    /**
     * @param back the back to set
     */
    public void setBack(String back) {
        this.back = back;
    }

    /**
     * @return the tmpFutter
     */
    public String getTmpFutter() {
        return tmpFutter;
    }

    /**
     * @param tmpFutter the tmpFutter to set
     */
    public void setTmpFutter(String tmpFutter) {
        this.tmpFutter = tmpFutter;
    }

    /**
     * @return the kaijoCode
     */
    public String getKaijoCode() {
        return kaijoCode;
    }

    /**
     * @param kaijoCode the kaijoCode to set
     */
    public void setKaijoCode(String kaijoCode) {
        this.kaijoCode = kaijoCode;
    }

    /**
     * @return the kaijoNameRyaku
     */
    public String getKaijoNameRyaku() {
        return kaijoNameRyaku;
    }

    /**
     * @param kaijoNameRyaku the kaijoNameRyaku to set
     */
    public void setKaijoNameRyaku(String kaijoNameRyaku) {
        this.kaijoNameRyaku = kaijoNameRyaku;
    }

    /**
     * @return the yubinNo
     */
    public String getYubinNo() {
        return yubinNo;
    }

    /**
     * @param yubinNo the yubinNo to set
     */
    public void setYubinNo(String yubinNo) {
        this.yubinNo = yubinNo;
    }

    /**
     * @return the kaijoHenkoFlg
     */
    public String getKaijoHenkoFlg() {
        return kaijoHenkoFlg;
    }

    /**
     * @param kaijoHenkoFlg the kaijoHenkoFlg to set
     */
    public void setKaijoHenkoFlg(String kaijoHenkoFlg) {
        this.kaijoHenkoFlg = kaijoHenkoFlg;
    }

    /**
     * @return the chushajoFlg
     */
    public String getChushajoFlg() {
        return chushajoFlg;
    }

    /**
     * @param chushajoFlg the chushajoFlg to set
     */
    public void setChushajoFlg(String chushajoFlg) {
        this.chushajoFlg = chushajoFlg;
    }

    /**
     * @return the chizuData
     */
    public String getChizuData() {
        return chizuData;
    }

    /**
     * @param chizuData the chizuData to set
     */
    public void setChizuData(String chizuData) {
        this.chizuData = chizuData;
    }

    /**
     * @return the biko
     */
    public String getBiko() {
        return biko;
    }

    /**
     * @param biko the biko to set
     */
    public void setBiko(String biko) {
        this.biko = biko;
    }

    /**
     * @return the comUmuFlg
     */
    public String getComUmuFlg() {
        return comUmuFlg;
    }

    /**
     * @param comUmuFlg the comUmuFlg to set
     */
    public void setComUmuFlg(String comUmuFlg) {
        this.comUmuFlg = comUmuFlg;
    }

    /**
     * @return the comUmuFlgList
     */
    public List<Option> getComUmuFlgList() {
        return comUmuFlgList;
    }

    /**
     * @param comUmuFlgList the comUmuFlgList to set
     */
    public void setComUmuFlgList(List<Option> comUmuFlgList) {
        this.comUmuFlgList = comUmuFlgList;
    }

    /**
     * @return the kaisaichiCodeList
     */
    public List<Option> getKaisaichiCodeList() {
        return kaisaichiCodeList;
    }

    /**
     * @param kaisaichiCodeList the kaisaichiCodeList to set
     */
    public void setKaisaichiCodeList(List<Option> kaisaichiCodeList) {
        this.kaisaichiCodeList = kaisaichiCodeList;
    }

    /**
     * @return the kaisaichiCode
     */
    public String getKaisaichiCode() {
        return kaisaichiCode;
    }

    /**
     * @param kaisaichiCode the kaisaichiCode to set
     */
    public void setKaisaichiCode(String kaisaichiCode) {
        this.kaisaichiCode = kaisaichiCode;
    }

    /**
     * @return the kaisaichiDetailList
     */
    public List<KaisaichiJoho> getKaisaichiDetailList() {
        return kaisaichiDetailList;
    }

    /**
     * @param kaisaichiDetailList the kaisaichiDetailList to set
     */
    public void setKaisaichiDetailList(List<KaisaichiJoho> kaisaichiDetailList) {
        this.kaisaichiDetailList = kaisaichiDetailList;
    }

    /**
     * @return the kaijoMstDetail
     */
    public String getKaijoMstDetail() {
        return kaijoMstDetail;
    }

    /**
     * @param kaijoMstDetail the kaijoMstDetail to set
     */
    public void setKaijoMstDetail(String kaijoMstDetail) {
        this.kaijoMstDetail = kaijoMstDetail;
    }

    /**
     * @return the kaijoMstResultList
     */
    public List<MstKanriKaijoMstJoho> getKaijoMstResultList() {
        return kaijoMstResultList;
    }

    /**
     * @param kaijoMstResultList the kaijoMstResultList to set
     */
    public void setKaijoMstResultList(List<MstKanriKaijoMstJoho> kaijoMstResultList) {
        this.kaijoMstResultList = kaijoMstResultList;
    }

    /**
     * @return the kaijoMstSrcListFlg
     */
    public String getKaijoMstSrcListFlg() {
        return kaijoMstSrcListFlg;
    }

    /**
     * @param kaijoMstSrcListFlg the kaijoMstSrcListFlg to set
     */
    public void setKaijoMstSrcListFlg(String kaijoMstSrcListFlg) {
        this.kaijoMstSrcListFlg = kaijoMstSrcListFlg;
    }

    /**
     * @return the chushajoFlgName
     */
    public String getKaijoHenkoFlgName() {
        return kaijoHenkoFlgName;
    }

    /**
     * @param chushajoFlgName the chushajoFlgName to set
     */
    public void setKaijoHenkoFlgName(String kaijoHenkoFlgName) {
        this.kaijoHenkoFlgName = kaijoHenkoFlgName;
    }

    /**
     * @return the chushajoFlgName
     */
    public String getChushajoFlgName() {
        return chushajoFlgName;
    }

    /**
     * @param chushajoFlgName the chushajoFlgName to set
     */
    public void setChushajoFlgName(String chushajoFlgName) {
        this.chushajoFlgName = chushajoFlgName;
    }

    /**
     * @return the chushajoFlgName
     */
    public String getYubinNoFront() {
        return yubinNoFront;
    }

    /**
     * @param chushajoFlgName the chushajoFlgName to set
     */
    public void setYubinNoFront(String yubinNoFront) {
        this.yubinNoFront = yubinNoFront;
    }

    /**
     * @return the chushajoFlgName
     */
    public String getYubinNoBack() {
        return yubinNoBack;
    }

    /**
     * @param chushajoFlgName the chushajoFlgName to set
     */
    public void setYubinNoBack(String yubinNoBack) {
        this.yubinNoBack = yubinNoBack;
    }

    /**
     * @return the kaisaichiSelect
     */
    public String[] getKaisaichiSelect() {
        return kaisaichiSelect;
    }

    /**
     * @param kaisaichiSelect the kaisaichiSelect to set
     */
    public void setKaisaichiSelect(String[] kaisaichiSelect) {
        this.kaisaichiSelect = kaisaichiSelect;
    }

    /**
     * @return the kaijoMstTable
     */
    public String getKaijoMstTable() {
        return kaijoMstTable;
    }

    public void setKaijoMstTable(String kaijoMstTable) {
        this.kaijoMstTable = kaijoMstTable;
    }

    /**
     * @return the teiinDisp
     */
    public String getTeiinDisp() {
        return teiinDisp;
    }

    /**
     * @param teiinDisp the teiinDisp to set
     */
    public void setTeiinDisp(String teiinDisp) {
        this.teiinDisp = teiinDisp;
    }

    /**
     * @return the bikoDisp
     */
    public String getBikoDisp() {
        return bikoDisp;
    }

    /**
     * @param bikoDisp the bikoDisp to set
     */
    public void setBikoDisp(String bikoDisp) {
        this.bikoDisp = bikoDisp;
    }

    /**
     * @return the firstDisp
     */
    public int getFirstDisp() {
        return firstDisp;
    }

    /**
     * @param firstDisp the firstDisp to set
     */
    public void setFirstDisp(int firstDisp) {
        this.firstDisp = firstDisp;
    }

    /**
     * @return the maxDisp
     */
    public int getMaxDisp() {
        return maxDisp;
    }

    /**
     * @param maxDisp the maxDisp to set
     */
    public void setMaxDisp(int maxDisp) {
        this.maxDisp = maxDisp;
    }

    /**
     * @return the page
     */
    public int getPage() {
        return page;
    }

    /**
     * @param page the page to set
     */
    public void setPage(int page) {
        this.page = page;
    }

    /**
     * @return the pageBegin
     */
    public int getPageBegin() {
        return pageBegin;
    }

    /**
     * @param pageBegin the pageBegin to set
     */
    public void setPageBegin(int pageBegin) {
        this.pageBegin = pageBegin;
    }

    /**
     * @return the pageEnd
     */
    public int getPageEnd() {
        return pageEnd;
    }

    /**
     * @param pageEnd the pageEnd to set
     */
    public void setPageEnd(int pageEnd) {
        this.pageEnd = pageEnd;
    }

    /**
     * @return the pageMax
     */
    public int getPageMax() {
        return pageMax;
    }

    /**
     * @param pageMax the pageMax to set
     */
    public void setPageMax(int pageMax) {
        this.pageMax = pageMax;
    }

    public String getCommandPage() {
        return CommandPage;
    }

    public void setCommandPage(String CommandPage) {
        this.CommandPage = CommandPage;
    }

    public String getPageIndex() {
        return pageIndex;
    }

    public void setPageIndex(String pageIndex) {
        this.pageIndex = pageIndex;
    }

    /**
     * @return the moshikomishaId
     */
    public String getMoshikomishaId() {
        return moshikomishaId;
    }

    /**
     * @param moshikomishaId the moshikomishaId to set
     */
    public void setMoshikomishaId(String moshikomishaId) {
        this.moshikomishaId = moshikomishaId;
    }

    /**
     * @return the kaijoDisplayList
     */
    public List<MstKanriKaijoMstJoho> getKaijoDisplayList() {
        return kaijoDisplayList;
    }

    /**
     * @param kaijoDisplayList the kaijoDisplayList to set
     */
    public void setKaijoDisplayList(List<MstKanriKaijoMstJoho> kaijoDisplayList) {
        this.kaijoDisplayList = kaijoDisplayList;
    }
    
}
