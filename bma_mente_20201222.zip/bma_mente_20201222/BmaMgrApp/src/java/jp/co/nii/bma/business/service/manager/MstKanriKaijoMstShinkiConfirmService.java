package jp.co.nii.bma.business.service.manager;

import jp.co.nii.bma.business.domain.KaijoMst;
import jp.co.nii.bma.business.rto.manager.MstKanriKaijoMstJoho;
import jp.co.nii.bma.business.service.common.BmaConstants;
import jp.co.nii.bma.business.service.common.BmaLogger;
import jp.co.nii.bma.business.service.common.BmaValidator;
import jp.co.nii.bma.presentation.common.BmaText;
import jp.co.nii.bma.utility.BmaStringUtility;
import jp.co.nii.bma.utility.BmaUtility;
import jp.co.nii.sew.business.SystemTime;
import jp.co.nii.sew.business.service.AbstractService;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_BACK;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_EXCEPTION;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_RELOAD;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_SESSION;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_SUCCESS;
import jp.co.nii.sew.presentation.Messages;
import jp.co.nii.sew.presentation.RequestTransferObject;
import jp.co.nii.sew.utility.PropertyUtility;

/**
 *
 * @author nii19049
 */
public class MstKanriKaijoMstShinkiConfirmService extends AbstractService {

    /**
     * DB�ڑ��̃f�[�^�\�[�X
     */
    private static String DATA_SOURCE_NAME;
    /**
     * ���O
     */
    BmaLogger log = (BmaLogger) BmaLogger.getLogger(this.getClass().getName());
    /**
     * �Ɩ��R�[�h
     */
    private static final String BUSINESS_CODE = PropertyUtility.getProperty("business_code");
    /**
     * ���׃e�X�g���[�h
     */
    private static final String STRESS_MODE = PropertyUtility.getProperty(BUSINESS_CODE + "stress_mode");

    /**
     * �R���X�g���N�^
     */
    public MstKanriKaijoMstShinkiConfirmService() {
        super();
        /* DB�ڑ����̃��[�U�[������ */
        DATA_SOURCE_NAME = BmaConstants.DS_REGISTRANT;
    }

    /**
     * �T�[�r�X�N���X�̎��s���\�b�h
     *
     * @param rto ���N�G�X�g��񂩂�擾����rto
     * @param rtoInSession �Z�b�V�������rto
     * @return foward��
     * @throws Exception ��O
     */
    @Override
    public String doService(RequestTransferObject rto, RequestTransferObject rtoInSession)
            throws Exception {

        MstKanriKaijoMstJoho inRequest = (MstKanriKaijoMstJoho) rto;
        MstKanriKaijoMstJoho inSession = (MstKanriKaijoMstJoho) rtoInSession;
        String processName = "";

        /* �G���[���b�Z�[�W������ */
        inSession.setErrors(new Messages());

        try {
            if (!BmaUtility.isNullOrEmpty(inRequest.getKaijoMstConfComp())) {
                /*�u�m��v�{�^�������� */
                processName = "MstKanriKaijoMstShinkiConfirm_Complete";
                log.Start(processName);

                /* ��L�[�擾 */
                KaijoMst kaijoMstInp = new KaijoMst(DATA_SOURCE_NAME);
                String kaisaichiCode = inSession.getKaisaichiCode();

                /* ���͒l�`�F�b�N */
                if(!validateInput(inSession)){
                    // �G���[���������ꍇ�u���}�X�^�V�K�o�^�m�F�v���Reload
                    return FWD_NM_RELOAD;
                } else {
                    try{
                    /* �g�����U�N�V�����擾&�J�n */
                    getTransaction();
                    beginTransaction();

                    // �J�Òn�R�[�h��薖���̉��f�[�^���擾
                    String lastKaijoCode = kaijoMstInp.findLastKaijoCode(kaisaichiCode);

                    // �擾�������R�[�h�����ƂɁA�o�^������R�[�h��ݒ�
                    if (!BmaUtility.isNullOrEmpty(lastKaijoCode)) {
                        int kaijoCodeInt = Integer.parseInt(lastKaijoCode) + 1;
                        String kaijoCodeStr = String.valueOf(kaijoCodeInt);

                        if (kaijoCodeStr.length() < 3) {
                            // 2���ȉ��̏ꍇ�A�O�[����ǉ����ēo�^
                            kaijoMstInp.setKaijoCode(String.format("%3s", kaijoCodeStr).replace(' ', '0'));
                        } else if (kaijoCodeStr.length() > 3) {
                            // 4���ȏ�̏ꍇ�u���}�X�^�V�K�o�^�m�F�v���Reload */
                                Messages errors = new Messages();
                                BmaValidator.addMessage(errors, "kaijoData", BmaText.E00130);
                                inSession.setErrors(errors);
                                return FWD_NM_RELOAD;
                        } else {
                            // ���̑��͖���+1�����R�[�h�ɓo�^
                            kaijoMstInp.setKaijoCode(kaijoCodeStr);
                        }
                        // null �̏ꍇ�A�擪��001��o�^
                    } else {
                        kaijoMstInp.setKaijoCode("001");
                    }

                    /* �V�X�e���������擾 */
                    SystemTime sysTime = new SystemTime();

                    /* �o�^�������}�X�^�ɃZ�b�g */
                    kaijoMstInp.setKaisaichiCode(inSession.getKaisaichiCode());
                    kaijoMstInp.setKaijoName(inSession.getKaijoName());
                    kaijoMstInp.setKaijoNameRyaku(inSession.getKaijoNameRyaku());
                    kaijoMstInp.setYubinNo(inSession.getYubinNo());
                    kaijoMstInp.setJusho(inSession.getJusho());
                    kaijoMstInp.setTeiin(inSession.getTeiin());
                    kaijoMstInp.setKaijoHenkoFlg(inSession.getKaijoHenkoFlg());
                    kaijoMstInp.setChushajoFlg(inSession.getChushajoFlg());
                    kaijoMstInp.setChizuData(inSession.getChizuData());
                    kaijoMstInp.setBiko(inSession.getBiko());

                    /* DB���ʍ��ڃZ�b�g */
                    kaijoMstInp.setKoshinKbn(BmaConstants.SHORI_KBN_INSERT);
                    kaijoMstInp.setTorokuDate(sysTime.getymd1());
                    kaijoMstInp.setTorokuTime(sysTime.gethms1());
                    kaijoMstInp.setTorokuUserId(inRequest.getMoshikomishaId());
                    kaijoMstInp.setKoshinDate("");
                    kaijoMstInp.setKoshinTime("");
                    kaijoMstInp.setKoshinUserId("");
                    kaijoMstInp.setRonriSakujoFlg(BmaConstants.FLG_OFF);

                    kaijoMstInp.create();
                    /* �R�~�b�g */
                    commitTransaction();
                }catch (Exception ex) {
                        ex.printStackTrace();
                        // ���[���o�b�N
                        rollbackTransaction();
                        return FWD_NM_SESSION;
                    }

                /* �u���}�X�^�V�K�o�^�����v��ʕ\�� */
                return FWD_NM_SUCCESS;
                }

            } else if (!BmaUtility.isNullOrEmpty(inRequest.getKaijoMstConfBack())) {
                /*�u�����v�{�^��������*/
                processName = "MstKanriKaijoMstShinkiConfirm_BackKaijoShinkiInput";
                log.Start(processName);

                /* �u���}�X�^�V�K�o�^���́v��ʕ\�� */
                return FWD_NM_BACK;

            } else {
                /*�ُ�J��*/
                log.IllegalFWD();
                return FWD_NM_SESSION;
            }
        } catch (Exception e) {
            return FWD_NM_EXCEPTION;
        } finally {
            log.End(processName);
        }
    }
    
/**
     * ���̓`�F�b�N
     *
     * @param inSession �Z�b�V����RTO
     * @return true:�G���[��
     */
    private boolean validateInput(MstKanriKaijoMstJoho inSession) {
        /* �ϐ������� */
        Messages errors = new Messages();
        String groupCode;
        String itemName;

        // �G���[�`�F�b�N�p���X�g�쐬
        String[] comUmuFlgs = {BmaConstants.FLG_ON, BmaConstants.FLG_OFF};

        /* �J�Òn�R�[�h */
        groupCode = "kaisaichiCode";
        itemName = "�J�Òn�R�[�h";
        if (BmaValidator.validateSelect(inSession.getKaisaichiCode(), errors, groupCode, itemName)) {
            BmaValidator.validatePermissionSelect(inSession.getKaisaichiCode(), inSession.getKaisaichiCodeList(), errors, groupCode, itemName);
        }

        /* ��ꖼ */
        groupCode = "kaijoName";
        itemName = "��ꖼ";
        if (BmaValidator.validateRequired(inSession.getKaijoName(), errors, groupCode, itemName)) {
            if (BmaValidator.validateMaxLength(inSession.getKaijoName(), BmaConstants.MAX_LENGTH_KAIJO_NAME, errors, groupCode, itemName)) {
                BmaValidator.validateMojiCode3(inSession.getKaijoName(), errors, groupCode, itemName);
            }
        }

        /* ��ꖼ�i���j */
        groupCode = "kaijoNameRyaku";
        itemName = "��ꖼ�i���j";
        if (BmaValidator.validateRequired(inSession.getKaijoNameRyaku(), errors, groupCode, itemName)) {
            if (BmaValidator.validateMaxLength(inSession.getKaijoNameRyaku(), BmaConstants.MAX_LENGTH_KAIJO_NAME_RYAKU, errors, groupCode, itemName)) {
                BmaValidator.validateMojiCode3(inSession.getKaijoNameRyaku(), errors, groupCode, itemName);
            }
        }

        /* �X�֔ԍ� */
        groupCode = "yubinNo";
        itemName = "�X�֔ԍ�";
        if (BmaValidator.validateRequired(inSession.getYubinNo(), errors, groupCode, itemName)) {
            if (BmaValidator.validateEqualLength(inSession.getYubinNo(), BmaConstants.EQUAL_LENGTH_YUBIN_NO, errors, groupCode, itemName)) {
                BmaValidator.validateNumber(inSession.getYubinNo(), errors, groupCode, itemName);
            }
        }

        /* �Z�� */
        groupCode = "jusho";
        itemName = "�Z��";
        if (BmaValidator.validateRequired(inSession.getJusho(), errors, groupCode, itemName)) {
            if (BmaValidator.validateMaxLength(inSession.getJusho(), BmaConstants.MAX_LENGTH_JUSHO, errors, groupCode, itemName)) {
                BmaValidator.validateMojiCode3(inSession.getJusho(), errors, groupCode, itemName);
            }
        }

        /* ��� */
        groupCode = "teiin";
        itemName = "���";
        if (BmaValidator.validateRequired(inSession.getTeiin(), errors, groupCode, itemName)) {
            if (BmaValidator.validateNumber(inSession.getTeiin(), errors, groupCode, itemName)) {
                BmaValidator.validateMaxLength(inSession.getTeiin(), BmaConstants.MAX_LENGTH_TEIIN, errors, groupCode, itemName);
            }
        }
        
        /* ���ύX�L�� */
        groupCode = "kaijoChangeFlg";
        itemName = "���ύX�L��";
        if (BmaValidator.validateSelect(inSession.getKaijoHenkoFlg(), errors, groupCode, itemName)) {
            BmaValidator.validatePermissionSelect(inSession.getKaijoHenkoFlg(), comUmuFlgs, errors, groupCode, itemName);
        }
        
        /* ���ԏ�L�� */
        groupCode = "chushajoFlg";
        itemName = "���ԏ�L��";
        if (BmaValidator.validateSelect(inSession.getChushajoFlg(), errors, groupCode, itemName)) {
            BmaValidator.validatePermissionSelect(inSession.getChushajoFlg(), comUmuFlgs, errors, groupCode, itemName);
        }
        
        /* �n�}�f�[�^ */
        groupCode = "chizuData";
        itemName = "�n�}�f�[�^";
        if (BmaValidator.validateMaxLength(inSession.getChizuData(), BmaConstants.MAX_LENGTH_CHIZU_DATA, errors, groupCode, itemName)) {
            BmaValidator.validateAlphabetOrNumber(inSession.getChizuData(), errors, groupCode, itemName);
        }

        /* ���l */
        groupCode = "biko";
        itemName = "���l";
        if (BmaValidator.validateMaxLength(inSession.getBiko(), BmaConstants.MAX_LENGTH_BIKO, errors, groupCode, itemName)) {
            BmaValidator.validateMojiCodeForBiko(inSession.getBiko(), errors, groupCode, itemName);
        }

        inSession.setErrors(errors);
        return errors.isEmpty();
    }
}