package jp.co.nii.bma.business.rto.manager;

import java.util.ArrayList;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import jp.co.nii.bma.utility.BmaDateTimeUtility;
import jp.co.nii.bma.utility.BmaStringUtility;
import jp.co.nii.bma.utility.BmaUtility;
import jp.co.nii.sew.presentation.DownloadRTO;
import jp.co.nii.sew.presentation.Messages;
import jp.co.nii.sew.presentation.Option;

/**
 * �^�C�g��: TOP��� ����: TOP���RTO ���쌠: Copyright (c) 2020 ��Ж�: ���{���Y�Ɗ������
 */
public class HanyouSearchJoho extends DownloadRTO {

    private Messages errors;

    private String gaijiFlg;
    private String gaijiShosai;
    private String sex;
    private String todofuken;
    private String kinmusakiTodofuken;
    private HanyouSearchJoho taihi;
    private String hanyouSearch;
    private String inpClear;
    private String hanyouSearchWhe;
    private String shosai;
    private String export;
    private String[] noOutputData;
    private String[] outputData;
    private String hayoBack;
    private String delete;
    private String tempSave;
    private String tempUpdate;
    private String koumokuSelect;
    private String btnKotoshi;
    private String btnKakorireki;
    private String kuusekiConfirm;
    private String kaijoShikenKbn;
    private String kaijoCode;
    private String kaijoName;
    private String kaijoJusho;

    private String detailConfirm;
    private String nendo;
    private String uketsukeNo;
    private String jukenJukoNo;
    private String shimei;
    private String furigana;
    private String sknKsuNm;
    private String unyoJokyoKbn;
    private String gohiJokyoKbnMoshi;
    private String sknName;
    private String sknNameDetail;
    private String ksuName;
    private String ksuNameDetail;
    private String sknksuKbn;
    private String ksuNo;
    private String birthYear;
    private String birthMonth;
    private String birthDay;

    private String muryoZanCount;
    private String gokakuNo;
    private String yukoKigen;
    private String gokakuBi;
    private String kariuketsukeBiFromYear;
    private String kariuketsukeBiFromMonth;
    private String kariuketsukeBiFromDay;
    private String kariuketsukeBiToYear;
    private String kariuketsukeBiToMonth;
    private String kariuketsukeBiToDay;

    private String moshikomiFinishBi;
    private String moshikomikanryoBiDay;
    private String moshikomikanryoBiMonth;
    private String moshikomikanryoBiYear;
    private String moshikomikanryoBiFromYear;
    private String moshikomikanryoBiFromMonth;
    private String moshikomikanryoBiFromDay;
    private String moshikomikanryoBiToYear;
    private String moshikomikanryoBiToMonth;
    private String moshikomikanryoBiToDay;

    private String nendoFrm;
    private String nendoTo;
    private String UserId;

    private String gokakuBiYear;
    private String gokakuBiMonth;
    private String gokakuBiDay;

    private String yukoKigenYear;
    private String yukoKigenMonth;
    private String yukoKigenDay;

    private String yukoKigenMenjoYear;
    private String yukoKigenMenjoMonth;
    private String yukoKigenMenjoDay;
    // �l���
    private String yubinNoFront;
    private String yubinNoBack;
    private String jusho1;
    private String jusho2;
    private String tatemono;
    private String telNo;
    private String faxNo;
    private String mailAddress;

    // �Ζ�����
    private String kinmusakiName;
    private String kinmusakiYubinFront;
    private String kinmusakiYubinBack;
    private String kinmusakiJusho1;
    private String kinmusakiJusho2;
    private String kinmusakiTatemono;
    private String kinmusakiTelNo;
    private String kinmusakiFaxNo;
    private String backFlag;
    private String hayoKakoBack;

    private String updateFlag;
    private String biko;
    private String kanriMemo;
    private String saveFlag;

    private String moshikomiJokyoKbn2;
    private String hairyoFlg;
    private String hairyoNaiyo;
    private String sofuSakiKbn;
    private String sql;
    private List<String> param;
    /**
     * ���O�C���敪
     */
    private String loginKbn;
    private String moshikomishaId;
    private String kyokaiName;
    private String kaiinKbn;
    private String kigyocode;
    private String bangoNyuryoku;
    private String bangoInput;
    private List<Option> shikennaiyoList;
    private String[] shikennaiyo;
    private List<Option> moshikomiKbnList;
    private String[] moshikomiKbn;
    private List<Option> moshikomiJokyoKbnList;
    private String[] moshikomiJokyoKbn;
    private List<Option> kojinDantaiKbnList;
    private String[] kojinDantaiKbn;

    private List<Option> gaijiFlgList;
    private List<Option> hairyoFlgList;
    private String[] comUmFlg;
    private List<Option> kessaiHohoList;
    private String[] kessaiHoho;
    private List<Option> kessaiJokyoKbnList;
    private String[] kessaiJokyoKbn;
    private List<Option> gohiJokyoKbnList;
    private String[] gohiJokyoKbn;
    private List<Option> hoseiIraiKbnList;
    private String[] hoseiIraiKbn;
    private List<Option> kessaiConvenienceShubetsuList;

    List<Option> sexList;
    List<Option> todofukenList;

    List<Option> birthYearList;
    List<Option> birthMonthList;
    List<Option> birthDayList;
    List<Option> bangoNyuryokuList;

    List<Option> yearList;
    List<Option> monthList;
    List<Option> dayList;

    private List<Option> ksuKbnList;
    private List<Option> sknKbnList;
    private List<Option> unyouList;
    private List<Option> koumokuTmpList;
    private List<Option> hanyoKensakuOutList;
    private List<Option> hanyoKensakuNoOutList;
    private List<Option> sofusakiList;
    private List<Option> kaisaichiCodeList;

    private List<Option> sknNaiyoList;
    private String shikenNaiyoKbn;
    private String genmenFlg;
    private List<Option> genmenFlgList;
    private String gakKaisaichiCode;
    private String gakkaKaijo;
    private String gakkaDate;
    private String gakkaJusho;
    private String jissiJusho;
    private String jissiKaijo;
    private String jissiKaisaichiCode;
    private String jissiDateFrom;
    private String jissiDateTo;
    private String jissiDate;
    //���i���
    private String shinseiShikakuNo;
    private String shinseiMenjoNo;
    private String shokurekiKbn;

    private String shokurekiKbn1;
    private String shokurekiKbn3;
    private String shokurekiKbn4;

    //�E�����
    private String kinmusakiKaishaName;
    private String bushoYakushokuName;
    private String shokumuNaiyo;
    private List<Option> shokumuNaiyoList;
    private String shozaichi;
    private String zaisekikikanFrom;
    private String zaisekikikanTo;
    private String zaisekikikanFromYear;
    private String zaisekikikanFromMonth;
    private String zaisekikikanToYear;
    private String zaisekikikanToMonth;

    private List<Option> kessaiHohoKbnList;
    //�w�����
    private String gakkouName;
    private String gakkouGakka;
    private String gakkouShozaichi;
    private String graduationDate;
    private String graduationDateYear;
    private String graduationDateMonth;

    //�P�������
    private String kunrenShisetsuName;
    private String kunrenka;
    private String kunrenShozaichi;
    private String kunrenSyuryonenFrom;
    private String kunrenSyuryonenTo;
    private String kunrenSyuryonenFromYear;
    private String kunrenSyuryonenFromMonth;
    private String kunrenSyuryonenToYear;
    private String kunrenSyuryonenToMonth;

    //���Ϗ�
    private String kessaiHohoKbn;
    private String kessaiJokyo;
    private String kessaiJknjkuryo;
    private String kessaiJimutesuryo;
    private String kessaiGokeiKingaku;
    private String kessaiShiharaiNo;
    private String kessaiShiharaiKigenbi;
    private String kessaiShiharaiKigenbiYear;
    private String kessaiShiharaiKigenbiMonth;
    private String kessaiShiharaiKigenbiDay;

    //�y�C�W�[�̏ꍇ
    private String peijiKessaiShunokikanNo;
    private String kessaiUserNo;
    private String kessaiKakuninNo;
    //�����`�[�ԍ�
    private String kessaiConvenienceHaraikomiNo;
    //�����p�R���r�j
    private String kessaiConvenienceShubetsu;
    private String nyukinBi;
    private String nyukinBiYear;
    private String nyukinBiMonth;
    private String nyukinBiDay;
    private String kariUketsukeBi;
    private String kariUketsukeBiYear;
    private String kariUketsukeBiMonth;
    private String kariUketsukeBiDay;
    private String kessaiKingakuTotal;
    // ����/��u���ʏ��

    private String banngo;
    private String yukouKiken;
    private String kaijoId;
    private String kaijoId1;
    private String kaijoId2;
    /**
     * �����e���v���[�g���X�g
     */
    private List<Option> searchTmpList;
    private List<Option> kaijoIdList;
    private List<Option> kaijoIdAllList;
    private List<Option> shikakuList;
    private String shikakuCode;

    private List<Option> menjoList;
    private String menjoCode;
    List<HanyouSearchJoho> shokurekiList;
    private String outputSelect;
    /**
     * �����e���v���[�gNo
     */
    private String srcTempNo;
    /**
     * �ėp�ڍׁ@���X�g
     */
    private List<HanyouSearchJoho> hanyouDetailList;
    /**
     * �ėp�ڍׁ@���X�g
     */
    private List<HanyouSearchJoho> hanyouAllList;
    /**
     * �\���@���X�g
     */
    List<HanyouSearchJoho> moshikomiDetailList;
    /**
     * �ۗL���i�@���X�g
     */
    List<HanyouSearchJoho> hoyoSikakuDetailList;
    List<HanyouKaisaiTiJoho> kaiMskJohoList;
    List<HanyouGazouJoho> gazouList;

    /**
     * �Z�b�V�����p�\�������J�n
     */
    private int firstDisp;
    /**
     * �Z�b�V�����p�\�������ő包��
     */
    private int maxDisp;
    /**
     * �y�[�W�J�ڗp�F�J�ڐ�y�[�W
     */
    private int page;
    /**
     * �y�[�W�J�ڗp�F���ڈړ��Œ�l
     */
    private int pageBegin;
    /**
     * �y�[�W�J�ڗp�F���ڈړ��ő�l
     */
    private int pageEnd;
    /**
     * �y�[�W�J�ڗp�F�ő�y�[�W��
     */
    private int pageMax;

    /**
     * �R�}���h �y�[�W�J��
     */
    private String commandPage;
    /**
     * ��������
     */
    private List<String> dispKeyList;
    /**
     * ��������index���X�g
     */
    private List<String> searchOutIndex;

    private String meisaiGyoNo;
    private String jokenKomokuId;
    private String jokenGyoNo;
    private String jokenChi;
    private String searchFlg;
    private String searchChange;
    private String searchChange1;
    private String searchChange2;
    private String templetSave;
    private String shubetsuCode;
    private String sknKsuKbn;
    private String sknKsuCode;
    private String kaisuCode;

    //�R���X�g���N�^/������/���N�G�X�g�擾
    /**
     * �R���X�g���N�^
     */
    public HanyouSearchJoho() {
        clearInfo();
    }

    /**
     * ���������\�b�h
     */
    public void clearInfoHairetu() {
        setShikennaiyo(null);
        setMoshikomiKbn(null);
        setKojinDantaiKbn(null);
        setMoshikomiJokyoKbn(null);
        setComUmFlg(null);
        setKessaiHoho(null);
        setKessaiJokyoKbn(null);
        setHoseiIraiKbn(null);
        setGohiJokyoKbn(null);
    }

    /**
     * ���������\�b�h
     */
    public void clearInfo() {
        setHanyouSearch("");
        setInpClear("");
        setHanyouSearchWhe("");
        setHayoBack("");
        setHayoKakoBack("");
        setTempSave("");
        setDetailConfirm("");
        setKoumokuSelect("");
        setBtnKotoshi("");
        setBtnKakorireki("");
        setNendo("");
        setUketsukeNo("");
        setJukenJukoNo("");
        setShimei("");
        setFurigana("");
        setSknKsuNm("");
        setBirthYear("");
        setBirthMonth("");
        setBirthDay("");
        setKariuketsukeBiFromYear("");
        setKariuketsukeBiFromMonth("");
        setKariuketsukeBiFromDay("");
        setKariuketsukeBiToYear("");
        setKariuketsukeBiToMonth("");
        setKariuketsukeBiToDay("");
        setMoshikomikanryoBiFromYear("");
        setMoshikomikanryoBiFromMonth("");
        setMoshikomikanryoBiFromDay("");
        setMoshikomikanryoBiToYear("");
        setMoshikomikanryoBiToMonth("");
        setMoshikomikanryoBiToDay("");
        setNendoFrm("");
        setNendoTo("");
        setKigyocode("");
        setKinmusakiName("");
        setBangoNyuryoku("");
        setSrcTempNo("");
        setBangoInput("");
        setUpdateFlag("");
        setSaveFlag("");
        setKaiinKbn("");
        setTempletSave("");
        setTempUpdate("");
        setJokenChi("");
        setShinseiShikakuNo("");
        setHairyoNaiyo("");
        setShinseiMenjoNo("");
        setGokakuBiYear("");
        setGokakuBiMonth("");
        setGokakuBiDay("");
        setYukoKigenYear("");
        setYukoKigenMonth("");
        setYukoKigenDay("");
        setZaisekikikanFrom("");
        setZaisekikikanTo("");
        setShokurekiList(new ArrayList<HanyouSearchJoho>());
        setYukoKigenMenjoYear("");
        setYukoKigenMenjoMonth("");
        setYukoKigenMenjoDay("");
        setHanyoKensakuOutList(new ArrayList<>());
        setHanyoKensakuNoOutList(new ArrayList<>());
        setGraduationDate("");
        setKunrenSyuryonenFrom("");
        setKunrenSyuryonenTo("");
        setKessaiShiharaiKigenbi("");
        setShosai("");
        setExport("");
        setSearchFlg("");
        setBanngo("");
        setYukouKiken("");
        setGokakuBi("");
        setGakkouName("");
        setGakkouGakka("");
        setGakkouShozaichi("");
        setGraduationDate("");
        setKunrenShisetsuName("");
        setKunrenka("");
        setKunrenShozaichi("");
        setKunrenSyuryonenFrom("");
        setKunrenSyuryonenTo("");
        setKessaiGokeiKingaku("");
        setKariUketsukeBi("");
        setNyukinBi("");
        setMoshikomikanryoBiYear("");
        setMoshikomikanryoBiMonth("");
        setMoshikomikanryoBiDay("");
        setKessaiShiharaiKigenbiYear("");
        setKessaiShiharaiKigenbiMonth("");
        setKessaiShiharaiKigenbiDay("");
    }

    /**
     * ���N�G�X�g��������擾���郁�\�b�h
     *
     * @param request ���N�G�X�g
     */
    @Override
    public void copyFromRequest(HttpServletRequest request) {

        setHanyouSearch((String) request.getAttribute("hanyouSearch"));
        setHayoBack((String) request.getAttribute("hayoBack"));
        setDelete((String) request.getAttribute("delete"));
        setHayoKakoBack((String) request.getAttribute("hayoKakoBack"));
        setTempSave((String) request.getAttribute("tempSave"));
        setKoumokuSelect((String) request.getAttribute("koumokuSelect"));
        setBtnKotoshi((String) request.getAttribute("btnKotoshi"));
        setBtnKakorireki((String) request.getAttribute("btnKakorireki"));
        setDetailConfirm((String) request.getAttribute("detailConfirm"));
        setInpClear((String) request.getAttribute("inpClear"));
        setHanyouSearchWhe((String) request.getAttribute("hanyouSearchWhe"));
        setShosai((String) request.getAttribute("shosai"));
        setExport((String) request.getAttribute("export"));
        setCommandPage((String) request.getAttribute("commandPage"));
        setKuusekiConfirm((String) request.getAttribute("kuusekiConfirm"));
        setNendo((String) request.getAttribute("nendo"));
        setSknName((String) request.getAttribute("sknName"));
        setKsuName((String) request.getAttribute("ksuName"));
        setSknksuKbn((String) request.getAttribute("sknksuKbn"));
        setKessaiKingakuTotal((String) request.getAttribute("kessaiKingakuTotal"));

        setUketsukeNo((String) request.getAttribute("uketsukeNo"));
        setNendoFrm((String) request.getAttribute("nendoFrm"));
        setNendoTo((String) request.getAttribute("nendoTo"));
        setShinseiShikakuNo((String) request.getAttribute("shinseiShikakuNo"));
        setKaijoId1((String) request.getAttribute("kaijoId1"));
        setKaijoId2((String) request.getAttribute("kaijoId2"));
        setFurigana((String) request.getAttribute("furigana"));

        setBirthYear((String) request.getAttribute("birthYear"));
        setBirthMonth((String) request.getAttribute("birthMonth"));
        setBirthDay((String) request.getAttribute("birthDay"));

        setShimei((String) request.getAttribute("shimei"));
        setSex((String) request.getAttribute("sex"));
        setGokakuBiYear((String) request.getAttribute("gokakuBiYear"));
        setGokakuBiMonth((String) request.getAttribute("gokakuBiMonth"));
        setGokakuBiDay((String) request.getAttribute("gokakuBiDay"));

        setYukoKigenYear((String) request.getAttribute("yukoKigenYear"));
        setYukoKigenMonth((String) request.getAttribute("yukoKigenMonth"));
        setYukoKigenDay((String) request.getAttribute("yukoKigenDay"));

        setYukoKigenMenjoYear((String) request.getAttribute("yukoKigenMenjoYear"));
        setYukoKigenMenjoMonth((String) request.getAttribute("yukoKigenMenjoMonth"));
        setYukoKigenMenjoDay((String) request.getAttribute("yukoKigenMenjoDay"));

        setKaiinKbn((String) request.getAttribute("kaiinKbn"));
        setKigyocode((String) request.getAttribute("kigyocode"));
        setKinmusakiName((String) request.getAttribute("kinmusakiName"));
        setBangoNyuryoku((String) request.getAttribute("bangoNyuryoku"));
        setBangoInput((String) request.getAttribute("bangoInput"));

        setShikennaiyo((String[]) request.getParameterValues("shikennaiyo"));
        setMoshikomiKbn((String[]) request.getParameterValues("moshikomiKbn"));

        setKojinDantaiKbn((String[]) request.getParameterValues("kojinDantaiKbn"));
        setMoshikomiJokyoKbn((String[]) request.getParameterValues("moshikomiJokyoKbn"));
        setComUmFlg((String[]) request.getParameterValues("comUmFlg"));

        setKariuketsukeBiFromYear((String) request.getAttribute("kariuketsukeBiFromYear"));
        setKariuketsukeBiFromMonth((String) request.getAttribute("kariuketsukeBiFromMonth"));
        setKariuketsukeBiFromDay((String) request.getAttribute("kariuketsukeBiFromDay"));

        setKariuketsukeBiToYear((String) request.getAttribute("kariuketsukeBiToYear"));
        setKariuketsukeBiToMonth((String) request.getAttribute("kariuketsukeBiToMonth"));

        setKariuketsukeBiToDay((String) request.getAttribute("kariuketsukeBiToDay"));
        setMoshikomikanryoBiYear((String) request.getAttribute("moshikomikanryoBiYear"));
        setMoshikomikanryoBiMonth((String) request.getAttribute("moshikomikanryoBiMonth"));
        setMoshikomikanryoBiDay((String) request.getAttribute("moshikomikanryoBiDay"));
        setMoshikomikanryoBiFromYear((String) request.getAttribute("moshikomikanryoBiFromYear"));
        setMoshikomikanryoBiFromMonth((String) request.getAttribute("moshikomikanryoBiFromMonth"));
        setMoshikomikanryoBiFromDay((String) request.getAttribute("moshikomikanryoBiFromDay"));
        setMoshikomikanryoBiToYear((String) request.getAttribute("moshikomikanryoBiToYear"));
        setMoshikomikanryoBiToMonth((String) request.getAttribute("moshikomikanryoBiToMonth"));
        setMoshikomikanryoBiToDay((String) request.getAttribute("moshikomikanryoBiToDay"));
        setSrcTempNo((String) request.getAttribute("srcTempNo"));
        setYubinNoFront((String) request.getAttribute("yubinNoFront"));
        setYubinNoBack((String) request.getAttribute("yubinNoBack"));
        setJusho1((String) request.getAttribute("jusho1"));
        setJusho2((String) request.getAttribute("jusho2"));
        setTatemono((String) request.getAttribute("tatemono"));
        setTelNo((String) request.getAttribute("telNo"));
        setFaxNo((String) request.getAttribute("faxNo"));
        setMailAddress((String) request.getAttribute("mailAddress"));
        setOutputSelect((String) request.getAttribute("outputSelect"));
        setKinmusakiName((String) request.getAttribute("kinmusakiName"));
        setKinmusakiYubinFront((String) request.getAttribute("kinmusakiYubinFront"));
        setKinmusakiYubinBack((String) request.getAttribute("kinmusakiYubinBack"));
        setKinmusakiJusho1((String) request.getAttribute("kinmusakiJusho1"));
        setKinmusakiJusho2((String) request.getAttribute("kinmusakiJusho2"));
        setKinmusakiTatemono((String) request.getAttribute("kinmusakiTatemono"));
        setKinmusakiTelNo((String) request.getAttribute("kinmusakiTelNo"));
        setKinmusakiFaxNo((String) request.getAttribute("kinmusakiFaxNo"));
        setJissiKaijo((String) request.getAttribute("jissiKaijo"));
        setTodofuken((String) request.getAttribute("todofuken"));

        setGaijiFlg((String) request.getAttribute("gaijiFlg"));
        setGaijiShosai((String) request.getAttribute("gaijiShosai"));
        setBiko((String) request.getAttribute("biko"));
        setKanriMemo((String) request.getAttribute("kanriMemo"));
        setSearchChange((String) request.getAttribute("searchChange"));
        setSearchChange1((String) request.getAttribute("searchChange1"));
        setSearchChange2((String) request.getAttribute("searchChange2"));
        setUpdateFlag((String) request.getAttribute("updateFlag"));
        setSknKsuCode((String) request.getAttribute("sknKsuCode"));
        setSknKsuKbn((String) request.getAttribute("sknKsuKbn"));
        setShubetsuCode((String) request.getAttribute("shubetsuCode"));
        setShikenNaiyoKbn((String) request.getAttribute("shikenNaiyoKbn"));
        setUketsukeNo((String) request.getAttribute("uketsukeNo"));
        setJukenJukoNo((String) request.getAttribute("jukenJukoNo"));
        setGenmenFlg((String) request.getAttribute("genmenFlg"));
        setMoshikomiJokyoKbn2((String) request.getAttribute("moshikomiJokyoKbn2"));
        setHairyoFlg((String) request.getAttribute("hairyoFlg"));
        setHairyoNaiyo((String) request.getAttribute("hairyoNaiyo"));
        setSofuSakiKbn((String) request.getAttribute("sofuSakiKbn"));
        setKaijoId1((String) request.getAttribute("kaijoId1"));
        setKaijoId2((String) request.getAttribute("kaijoId2"));
        setKaijoId((String) request.getAttribute("kaijoId"));
        setShikakuCode((String) request.getAttribute("shikakuCode"));

        setShinseiShikakuNo((String) request.getAttribute("shinseiShikakuNo"));
        setMenjoCode((String) request.getAttribute("menjoCode"));
        setShinseiMenjoNo((String) request.getAttribute("shinseiMenjoNo"));

        setKinmusakiKaishaName((String) request.getAttribute("kinmusakiKaishaName"));
        setBushoYakushokuName((String) request.getAttribute("bushoYakushokuName"));
        setShokumuNaiyo((String) request.getAttribute("shokumuNaiyo"));
        setShozaichi((String) request.getAttribute("shozaichi"));
        setZaisekikikanFromYear((String) request.getAttribute("zaisekikikanFromYear"));
        setZaisekikikanFromMonth((String) request.getAttribute("zaisekikikanFromMonth"));
        setZaisekikikanToYear((String) request.getAttribute("zaisekikikanToYear"));
        setZaisekikikanToMonth((String) request.getAttribute("zaisekikikanToMonth"));

        setGakkouName((String) request.getAttribute("gakkouName"));
        setGakkouGakka((String) request.getAttribute("gakkouGakka"));
        setGakkouShozaichi((String) request.getAttribute("gakkouShozaichi"));

        setGraduationDateYear((String) request.getAttribute("graduationDateYear"));
        setGraduationDateMonth((String) request.getAttribute("graduationDateMonth"));

        setKunrenShisetsuName((String) request.getAttribute("kunrenShisetsuName"));
        setKunrenka((String) request.getAttribute("kunrenka"));
        setKunrenShozaichi((String) request.getAttribute("kunrenShozaichi"));

        setKunrenSyuryonenFromYear((String) request.getAttribute("kunrenSyuryonenFromYear"));
        setKunrenSyuryonenFromMonth((String) request.getAttribute("kunrenSyuryonenFromMonth"));
        setKunrenSyuryonenToYear((String) request.getAttribute("kunrenSyuryonenToYear"));
        setKunrenSyuryonenToMonth((String) request.getAttribute("kunrenSyuryonenToMonth"));

        setKessaiShiharaiKigenbiYear((String) request.getAttribute("kessaiShiharaiKigenbiYear"));
        setKessaiShiharaiKigenbiMonth((String) request.getAttribute("kessaiShiharaiKigenbiMonth"));
        setKessaiShiharaiKigenbiDay((String) request.getAttribute("kessaiShiharaiKigenbiDay"));

        setKariUketsukeBiYear((String) request.getAttribute("kariUketsukeBiYear"));
        setKariUketsukeBiMonth((String) request.getAttribute("kariUketsukeBiMonth"));
        setKariUketsukeBiDay((String) request.getAttribute("kariUketsukeBiDay"));

        setNyukinBiYear((String) request.getAttribute("nyukinBiYear"));
        setNyukinBiMonth((String) request.getAttribute("nyukinBiMonth"));
        setNyukinBiDay((String) request.getAttribute("nyukinBiDay"));
        // ���ϕ��@
        setKessaiHohoKbn((String) request.getAttribute("kessaiHohoKbn"));
        setKessaiJokyo((String) request.getAttribute("kessaiJokyo"));
        setKessaiJknjkuryo((String) request.getAttribute("kessaiJknjkuryo"));
        setKessaiJimutesuryo((String) request.getAttribute("kessaiJimutesuryo"));
        setKyokaiName((String) request.getAttribute("kyokaiName"));
        setKessaiHoho((String[]) request.getParameterValues("kessaiHoho"));

        setPeijiKessaiShunokikanNo((String) request.getAttribute("peijiKessaiShunokikanNo"));
        setKessaiUserNo((String) request.getAttribute("kessaiUserNo"));
        setKessaiKakuninNo((String) request.getAttribute("kessaiKakuninNo"));

        setKessaiJokyoKbn((String[]) request.getParameterValues("kessaiJokyoKbn"));
        setHoseiIraiKbn((String[]) request.getParameterValues("hoseiIraiKbn"));
        setGohiJokyoKbn((String[]) request.getParameterValues("gohiJokyoKbn"));
        setTempletSave((String) request.getAttribute("templetSave"));
        setTempUpdate((String) request.getAttribute("tempUpdate"));
        setKessaiConvenienceShubetsu((String) request.getAttribute("kessaiConvenienceShubetsu"));

        setKessaiConvenienceHaraikomiNo((String) request.getAttribute("kessaiConvenienceHaraikomiNo"));
        setMoshikomishaId((String) request.getAttribute("moshikomishaId"));
        HttpSession session = request.getSession(false);
        if (session.getAttribute("MgrTopJoho") != null) {
            MgrTopJoho tmp = (MgrTopJoho) session.getAttribute("MgrTopJoho");
            setUserId(tmp.getUserId());
            //setMoshikomishaId(tmp.getMoshikomishaId());
        }

        //�E�����
        HanyouSearchJoho shokurekiJoho;
        int shokurekiCnt = 0;
        if (request.getAttribute("shokurekiCount") != null) {
            shokurekiCnt = Integer.parseInt((String) request.getAttribute("shokurekiCount"));
        }
        for (int i = 1; i <= shokurekiCnt; i++) {
            shokurekiJoho = new HanyouSearchJoho();
            shokurekiJoho.copyFromRequest_Shokureki(request, i);
            shokurekiList.add(shokurekiJoho);
        }

        setSearchFlg((String) request.getAttribute("searchFlg"));
        setOutputData((String[]) request.getParameterValues("outputData"));
        setNoOutputData((String[]) request.getParameterValues("noOutputData"));
    }

    /**
     * ���N�G�X�g��������擾���� �E���̂�
     *
     * @param request ���N�G�X�g
     * @param idx �E��index
     */
    public void copyFromRequest_Shokureki(HttpServletRequest request, int idx) {
        setShokurekiKbn((String) request.getAttribute("shokurekiKbn" + idx));

        setKinmusakiKaishaName((String) request.getAttribute("kinmusakiKaishaName" + idx));
        setBushoYakushokuName((String) request.getAttribute("bushoYakushokuName" + idx));
        setShokumuNaiyo((String) request.getAttribute("shokumuNaiyo" + idx));
        setShozaichi((String) request.getAttribute("shozaichi" + idx));

        setZaisekikikanFromYear((String) request.getAttribute("zaisekikikanFromYear" + idx));
        setZaisekikikanFromMonth((String) request.getAttribute("zaisekikikanFromMonth" + idx));
        setZaisekikikanToYear((String) request.getAttribute("zaisekikikanToYear" + idx));
        setZaisekikikanToMonth((String) request.getAttribute("zaisekikikanToMonth" + idx));
    }

    public Messages getErrors() {
        return errors;
    }

    public void setErrors(Messages errors) {
        this.errors = errors;
    }

    public String getNendo() {
        return nendo;
    }

    public void setNendo(String nendo) {
        this.nendo = nendo;
    }

    public String getHanyouSearch() {
        return hanyouSearch;
    }

    public void setHanyouSearch(String hanyouSearch) {
        this.hanyouSearch = hanyouSearch;
    }

    public String getSknName() {
        return sknName;
    }

    public void setSknName(String sknName) {
        this.sknName = sknName;
    }

    public String getKsuName() {
        return ksuName;
    }

    public void setKsuName(String ksuName) {
        this.ksuName = ksuName;
    }

    public List<Option> getKsuKbnList() {
        return ksuKbnList;
    }

    public void setKsuKbnList(List<Option> ksuKbnList) {
        this.ksuKbnList = ksuKbnList;
    }

    public List<Option> getSknKbnList() {
        return sknKbnList;
    }

    public void setSknKbnList(List<Option> sknKbnList) {
        this.sknKbnList = sknKbnList;
    }

    public String getSknksuKbn() {
        return sknksuKbn;
    }

    public void setSknksuKbn(String sknksuKbn) {
        this.sknksuKbn = sknksuKbn;
    }

    public String getInpClear() {
        return inpClear;
    }

    public void setInpClear(String inpClear) {
        this.inpClear = inpClear;
    }

    public String getHanyouSearchWhe() {
        return hanyouSearchWhe;
    }

    public void setHanyouSearchWhe(String hanyouSearchWhe) {
        this.hanyouSearchWhe = hanyouSearchWhe;
    }

    public int getFirstDisp() {
        return firstDisp;
    }

    public void setFirstDisp(int firstDisp) {
        this.firstDisp = firstDisp;
    }

    public int getMaxDisp() {
        return maxDisp;
    }

    public void setMaxDisp(int maxDisp) {
        this.maxDisp = maxDisp;
    }

    public int getPage() {
        return page;
    }

    public void setPage(int page) {
        this.page = page;
    }

    public int getPageBegin() {
        return pageBegin;
    }

    public void setPageBegin(int pageBegin) {
        this.pageBegin = pageBegin;
    }

    public int getPageEnd() {
        return pageEnd;
    }

    public void setPageEnd(int pageEnd) {
        this.pageEnd = pageEnd;
    }

    public int getPageMax() {
        return pageMax;
    }

    public void setPageMax(int pageMax) {
        this.pageMax = pageMax;
    }

    public String getCommandPage() {
        return commandPage;
    }

    public void setCommandPage(String commandPage) {
        this.commandPage = commandPage;
    }

    public List<String> getDispKeyList() {
        return dispKeyList;
    }

    public void setDispKeyList(List<String> dispKeyList) {
        this.dispKeyList = dispKeyList;
    }

    public List<String> getSearchOutIndex() {
        return searchOutIndex;
    }

    public void setSearchOutIndex(List<String> searchOutIndex) {
        this.searchOutIndex = searchOutIndex;
    }

    public List<HanyouSearchJoho> getHanyouDetailList() {
        return hanyouDetailList;
    }

    public void setHanyouDetailList(List<HanyouSearchJoho> hanyouDetailList) {
        this.hanyouDetailList = hanyouDetailList;
    }

    public List<HanyouSearchJoho> getHanyouAllList() {
        return hanyouAllList;
    }

    public void setHanyouAllList(List<HanyouSearchJoho> hanyouAllList) {
        this.hanyouAllList = hanyouAllList;
    }

    public String getUketsukeNo() {
        return uketsukeNo;
    }

    public void setUketsukeNo(String uketsukeNo) {
        this.uketsukeNo = uketsukeNo;
    }

    public String getJukenJukoNo() {
        return jukenJukoNo;
    }

    public void setJukenJukoNo(String jukenJukoNo) {
        this.jukenJukoNo = jukenJukoNo;
    }

    public String getShimei() {
        return shimei;
    }

    public void setShimei(String shimei) {
        this.shimei = shimei;
    }

    public String getFurigana() {
        return furigana;
    }

    public void setFurigana(String furigana) {
        this.furigana = furigana;
    }

    public String getSknKsuNm() {
        return sknKsuNm;
    }

    public void setSknKsuNm(String sknKsuNm) {
        this.sknKsuNm = sknKsuNm;
    }

    public String getHayoBack() {
        return hayoBack;
    }

    public void setHayoBack(String hayoBack) {
        this.hayoBack = hayoBack;
    }

    public String getTempSave() {
        return tempSave;
    }

    public void setTempSave(String tempSave) {
        this.tempSave = tempSave;
    }

    public String getKoumokuSelect() {
        return koumokuSelect;
    }

    public void setKoumokuSelect(String koumokuSelect) {
        this.koumokuSelect = koumokuSelect;
    }

    public List<Option> getSearchTmpList() {
        return searchTmpList;
    }

    public void setSearchTmpList(List<Option> searchTmpList) {
        this.searchTmpList = searchTmpList;
    }

    public String getSrcTempNo() {
        return srcTempNo;
    }

    public void setSrcTempNo(String srcTempNo) {
        this.srcTempNo = srcTempNo;
    }

    /**
     * �ėp��������_�����Ƀe���v���[�g�̕\����Ԃ�
     *
     * @return
     */
    public String getSrcTempNoDisp() {
        String ret = "";
        if (BmaUtility.isNullOrEmpty(getSrcTempNo())) {
            return ret;
        }
        for (Option option : getSearchTmpList()) {
            if (option.getValue().equals(getSrcTempNo())) {
                ret = option.getLabel();
                break;
            }
        }
        return ret;
    }

    /**
     * �^�p�󋵖��̂̕\����Ԃ�
     *
     * @return
     */
    public String getunyoJokyoKbnDisp() {
        String ret = "";
        if (BmaUtility.isNullOrEmpty(getUnyoJokyoKbn())) {
            return ret;
        }
        for (Option option : getUnyouList()) {
            if (option.getValue().equals(getUnyoJokyoKbn())) {
                ret = option.getLabel();
                break;
            }
        }
        return ret;
    }

    /**
     * ���ۏ󋵖��̂̕\����Ԃ�
     *
     * @return
     */
    public String getGohiJokyoKbnMoshiDisp() {
        String ret = "";
        if (BmaUtility.isNullOrEmpty(getGohiJokyoKbnMoshi())) {
            return ret;
        }
        for (Option option : getGohiJokyoKbnList()) {
            if (option.getValue().equals(getGohiJokyoKbnMoshi())) {
                ret = option.getLabel();
                break;
            }
        }
        return ret;
    }

    public String getBirthYear() {
        return birthYear;
    }

    public void setBirthYear(String birthYear) {
        this.birthYear = birthYear;
    }

    public String getBirthMonth() {
        return birthMonth;
    }

    public void setBirthMonth(String birthMonth) {
        this.birthMonth = birthMonth;
    }

    public String getBirthDayDisp() {
        return BmaDateTimeUtility.formatYMDToDateString(this.birthYear + this.birthMonth + this.birthDay);
    }

    public String getBirthDay() {
        return birthDay;
    }

    public void setBirthDay(String birthDay) {
        this.birthDay = birthDay;
    }

    public String getNendoFrm() {
        return nendoFrm;
    }

    public void setNendoFrm(String nendoFrm) {
        this.nendoFrm = nendoFrm;
    }

    public String getNendoTo() {
        return nendoTo;
    }

    public void setNendoTo(String nendoTo) {
        this.nendoTo = nendoTo;
    }

    public String getBtnKotoshi() {
        return btnKotoshi;
    }

    public void setBtnKotoshi(String btnKotoshi) {
        this.btnKotoshi = btnKotoshi;
    }

    public String getBtnKakorireki() {
        return btnKakorireki;
    }

    public void setBtnKakorireki(String btnKakorireki) {
        this.btnKakorireki = btnKakorireki;
    }

    public String getKaiinKbn() {
        return kaiinKbn;
    }

    public void setKaiinKbn(String kaiinKbn) {
        this.kaiinKbn = kaiinKbn;
    }

    public String getKigyocode() {
        return kigyocode;
    }

    public void setKigyocode(String kigyocode) {
        this.kigyocode = kigyocode;
    }

    public String getKinmusakiName() {
        return kinmusakiName;
    }

    public void setKinmusakiName(String kinmusakiName) {
        this.kinmusakiName = kinmusakiName;
    }

    public String getBangoNyuryoku() {
        return bangoNyuryoku;
    }

    public void setBangoNyuryoku(String bangoNyuryoku) {
        this.bangoNyuryoku = bangoNyuryoku;
    }

    public List<Option> getShikennaiyoList() {
        return shikennaiyoList;
    }

    public void setShikennaiyoList(List<Option> shikennaiyoList) {
        this.shikennaiyoList = shikennaiyoList;
    }

    public String[] getShikennaiyo() {
        return shikennaiyo;
    }

    public void setShikennaiyo(String[] shikennaiyo) {
        this.shikennaiyo = shikennaiyo;
    }

    public List<Option> getMoshikomiKbnList() {
        return moshikomiKbnList;
    }

    public void setMoshikomiKbnList(List<Option> moshikomiKbnList) {
        this.moshikomiKbnList = moshikomiKbnList;
    }

    public String[] getMoshikomiKbn() {
        return moshikomiKbn;
    }

    public void setMoshikomiKbn(String[] moshikomiKbn) {
        this.moshikomiKbn = moshikomiKbn;
    }

    public List<Option> getMoshikomiJokyoKbnList() {
        return moshikomiJokyoKbnList;
    }

    public void setMoshikomiJokyoKbnList(List<Option> moshikomiJokyoKbnList) {
        this.moshikomiJokyoKbnList = moshikomiJokyoKbnList;
    }

    public String[] getMoshikomiJokyoKbn() {
        return moshikomiJokyoKbn;
    }

    public void setMoshikomiJokyoKbn(String[] moshikomiJokyoKbn) {
        this.moshikomiJokyoKbn = moshikomiJokyoKbn;
    }

    public List<Option> getKojinDantaiKbnList() {
        return kojinDantaiKbnList;
    }

    public void setKojinDantaiKbnList(List<Option> kojinDantaiKbnList) {
        this.kojinDantaiKbnList = kojinDantaiKbnList;
    }

    public String[] getKojinDantaiKbn() {
        return kojinDantaiKbn;
    }

    public void setKojinDantaiKbn(String[] kojinDantaiKbn) {
        this.kojinDantaiKbn = kojinDantaiKbn;
    }

    public List<HanyouKaisaiTiJoho> getKaiMskJohoList() {
        return kaiMskJohoList;
    }

    public void setKaiMskJohoList(List<HanyouKaisaiTiJoho> kaiMskJohoList) {
        this.kaiMskJohoList = kaiMskJohoList;
    }

    public List<Option> getGaijiFlgList() {
        return gaijiFlgList;
    }

    public void setGaijiFlgList(List<Option> gaijiFlgList) {
        this.gaijiFlgList = gaijiFlgList;
    }

    public String[] getComUmFlg() {
        return comUmFlg;
    }

    public void setComUmFlg(String[] comUmFlg) {
        this.comUmFlg = comUmFlg;
    }

    public String getKariuketsukeBiFromYear() {
        return kariuketsukeBiFromYear;
    }

    public void setKariuketsukeBiFromYear(String kariuketsukeBiFromYear) {
        this.kariuketsukeBiFromYear = kariuketsukeBiFromYear;
    }

    public String getKariuketsukeBiFromMonth() {
        return kariuketsukeBiFromMonth;
    }

    public void setKariuketsukeBiFromMonth(String kariuketsukeBiFromMonth) {
        this.kariuketsukeBiFromMonth = kariuketsukeBiFromMonth;
    }

    public String getKariuketsukeBiFromDay() {
        return kariuketsukeBiFromDay;
    }

    public void setKariuketsukeBiFromDay(String kariuketsukeBiFromDay) {
        this.kariuketsukeBiFromDay = kariuketsukeBiFromDay;
    }

    public String getKariuketsukeBiToYear() {
        return kariuketsukeBiToYear;
    }

    public void setKariuketsukeBiToYear(String kariuketsukeBiToYear) {
        this.kariuketsukeBiToYear = kariuketsukeBiToYear;
    }

    public String getKariuketsukeBiToMonth() {
        return kariuketsukeBiToMonth;
    }

    public void setKariuketsukeBiToMonth(String kariuketsukeBiToMonth) {
        this.kariuketsukeBiToMonth = kariuketsukeBiToMonth;
    }

    public String getKariuketsukeBiToDay() {
        return kariuketsukeBiToDay;
    }

    public void setKariuketsukeBiToDay(String kariuketsukeBiToDay) {
        this.kariuketsukeBiToDay = kariuketsukeBiToDay;
    }

    public String getMoshikomikanryoBiFromYear() {
        return moshikomikanryoBiFromYear;
    }

    public void setMoshikomikanryoBiFromYear(String moshikomikanryoBiFromYear) {
        this.moshikomikanryoBiFromYear = moshikomikanryoBiFromYear;
    }

    public String getMoshikomikanryoBiFromMonth() {
        return moshikomikanryoBiFromMonth;
    }

    public void setMoshikomikanryoBiFromMonth(String moshikomikanryoBiFromMonth) {
        this.moshikomikanryoBiFromMonth = moshikomikanryoBiFromMonth;
    }

    public String getMoshikomikanryoBiFromDay() {
        return moshikomikanryoBiFromDay;
    }

    public void setMoshikomikanryoBiFromDay(String moshikomikanryoBiFromDay) {
        this.moshikomikanryoBiFromDay = moshikomikanryoBiFromDay;
    }

    public String getMoshikomikanryoBiToYear() {
        return moshikomikanryoBiToYear;
    }

    public void setMoshikomikanryoBiToYear(String moshikomikanryoBiToYear) {
        this.moshikomikanryoBiToYear = moshikomikanryoBiToYear;
    }

    public String getMoshikomikanryoBiToMonth() {
        return moshikomikanryoBiToMonth;
    }

    public void setMoshikomikanryoBiToMonth(String moshikomikanryoBiToMonth) {
        this.moshikomikanryoBiToMonth = moshikomikanryoBiToMonth;
    }

    public String getMoshikomikanryoBiToDay() {
        return moshikomikanryoBiToDay;
    }

    public void setMoshikomikanryoBiToDay(String moshikomikanryoBiToDay) {
        this.moshikomikanryoBiToDay = moshikomikanryoBiToDay;
    }

    public List<Option> getKessaiHohoList() {
        return kessaiHohoList;
    }

    public void setKessaiHohoList(List<Option> kessaiHohoList) {
        this.kessaiHohoList = kessaiHohoList;
    }

    public String[] getKessaiHoho() {
        return kessaiHoho;
    }

    public void setKessaiHoho(String[] kessaiHoho) {
        this.kessaiHoho = kessaiHoho;
    }

    public List<Option> getKessaiJokyoKbnList() {
        return kessaiJokyoKbnList;
    }

    public void setKessaiJokyoKbnList(List<Option> kessaiJokyoKbnList) {
        this.kessaiJokyoKbnList = kessaiJokyoKbnList;
    }

    public String getKessaiJokyoDisp() {
        String ret = "";
        if (BmaUtility.isNullOrEmpty(getKessaiJokyo())) {
            return ret;
        }
        for (Option option : getKessaiJokyoKbnList()) {
            if (option.getValue().equals(getKessaiJokyo())) {
                ret = option.getLabel();
                break;
            }
        }
        return ret;
    }

    public String[] getKessaiJokyoKbn() {
        return kessaiJokyoKbn;
    }

    public void setKessaiJokyoKbn(String[] kessaiJokyoKbn) {
        this.kessaiJokyoKbn = kessaiJokyoKbn;
    }

    public List<Option> getGohiJokyoKbnList() {
        return gohiJokyoKbnList;
    }

    public void setGohiJokyoKbnList(List<Option> gohiJokyoKbnList) {
        this.gohiJokyoKbnList = gohiJokyoKbnList;
    }

    public String[] getGohiJokyoKbn() {
        return gohiJokyoKbn;
    }

    public void setGohiJokyoKbn(String[] gohiJokyoKbn) {
        this.gohiJokyoKbn = gohiJokyoKbn;
    }

    public List<Option> getHoseiIraiKbnList() {
        return hoseiIraiKbnList;
    }

    public void setHoseiIraiKbnList(List<Option> hoseiIraiKbnList) {
        this.hoseiIraiKbnList = hoseiIraiKbnList;
    }

    public String[] getHoseiIraiKbn() {
        return hoseiIraiKbn;
    }

    public void setHoseiIraiKbn(String[] hoseiIraiKbn) {
        this.hoseiIraiKbn = hoseiIraiKbn;
    }

    public List<Option> getBirthYearList() {
        return birthYearList;
    }

    public void setBirthYearList(List<Option> birthYearList) {
        this.birthYearList = birthYearList;
    }

    public List<Option> getBirthMonthList() {
        return birthMonthList;
    }

    public void setBirthMonthList(List<Option> birthMonthList) {
        this.birthMonthList = birthMonthList;
    }

    public List<Option> getBirthDayList() {
        return birthDayList;
    }

    public void setBirthDayList(List<Option> birthDayList) {
        this.birthDayList = birthDayList;
    }

    public List<Option> getBangoNyuryokuList() {
        return bangoNyuryokuList;
    }

    public void setBangoNyuryokuList(List<Option> bangoNyuryokuList) {
        this.bangoNyuryokuList = bangoNyuryokuList;
    }

    public List<Option> getYearList() {
        return yearList;
    }

    public void setYearList(List<Option> yearList) {
        this.yearList = yearList;
    }

    public List<Option> getMonthList() {
        return monthList;
    }

    public void setMonthList(List<Option> monthList) {
        this.monthList = monthList;
    }

    public List<Option> getDayList() {
        return dayList;
    }

    public void setDayList(List<Option> dayList) {
        this.dayList = dayList;
    }

    public String getBangoInput() {
        return bangoInput;
    }

    public void setBangoInput(String bangoInput) {
        this.bangoInput = bangoInput;
    }

    public String getUnyoJokyoKbn() {
        return unyoJokyoKbn;
    }

    public void setUnyoJokyoKbn(String unyoJokyoKbn) {
        this.unyoJokyoKbn = unyoJokyoKbn;
    }

    public String getUserId() {
        return UserId;
    }

    public void setUserId(String UserId) {
        this.UserId = UserId;
    }

    public List<Option> getUnyouList() {
        return unyouList;
    }

    public void setUnyouList(List<Option> unyouList) {
        this.unyouList = unyouList;
    }

    /**
     * �^�p�󋵖��̂̕\����Ԃ�
     *
     * @return
     */
    public String getUnyoJokyoKbnDisp() {
        String ret = "";
        if (BmaUtility.isNullOrEmpty(getUnyoJokyoKbn())) {
            return ret;
        }
        for (Option option : getUnyouList()) {
            if (option.getValue().equals(getUnyoJokyoKbn())) {
                ret = option.getLabel();
                break;
            }
        }
        return ret;
    }

    public String getMeisaiGyoNo() {
        return meisaiGyoNo;
    }

    public void setMeisaiGyoNo(String meisaiGyoNo) {
        this.meisaiGyoNo = meisaiGyoNo;
    }

    public String getJokenKomokuId() {
        return jokenKomokuId;
    }

    public void setJokenKomokuId(String jokenKomokuId) {
        this.jokenKomokuId = jokenKomokuId;
    }

    public String getJokenGyoNo() {
        return jokenGyoNo;
    }

    public void setJokenGyoNo(String jokenGyoNo) {
        this.jokenGyoNo = jokenGyoNo;
    }

    public String getJokenChi() {
        return jokenChi;
    }

    public void setJokenChi(String jokenChi) {
        this.jokenChi = jokenChi;
    }

    public String getSearchChange() {
        return searchChange;
    }

    public void setSearchChange(String searchChange) {
        this.searchChange = searchChange;
    }

    public String getTempletSave() {
        return templetSave;
    }

    public void setTempletSave(String templetSave) {
        this.templetSave = templetSave;
    }

    public String getTempUpdate() {
        return tempUpdate;
    }

    public void setTempUpdate(String tempUpdate) {
        this.tempUpdate = tempUpdate;
    }

    public String getGokakuBiYear() {
        return gokakuBiYear;
    }

    public void setGokakuBiYear(String gokakuBiYear) {
        this.gokakuBiYear = gokakuBiYear;
    }

    public String getGokakuBiMonth() {
        return gokakuBiMonth;
    }

    public void setGokakuBiMonth(String gokakuBiMonth) {
        this.gokakuBiMonth = gokakuBiMonth;
    }

    public String getGokakuBiDay() {
        return gokakuBiDay;
    }

    public void setGokakuBiDay(String gokakuBiDay) {
        this.gokakuBiDay = gokakuBiDay;
    }

    public String getYukoKigenYear() {
        return yukoKigenYear;
    }

    public void setYukoKigenYear(String yukoKigenYear) {
        this.yukoKigenYear = yukoKigenYear;
    }

    public String getYukoKigenMonth() {
        return yukoKigenMonth;
    }

    public void setYukoKigenMonth(String yukoKigenMonth) {
        this.yukoKigenMonth = yukoKigenMonth;
    }

    public String getYukoKigenDay() {
        return yukoKigenDay;
    }

    public void setYukoKigenDay(String yukoKigenDay) {
        this.yukoKigenDay = yukoKigenDay;
    }

    public String getBackFlag() {
        return backFlag;
    }

    public void setBackFlag(String backFlag) {
        this.backFlag = backFlag;
    }

    public String getHayoKakoBack() {
        return hayoKakoBack;
    }

    public void setHayoKakoBack(String hayoKakoBack) {
        this.hayoKakoBack = hayoKakoBack;
    }

    public String getYukoKigenMenjoYear() {
        return yukoKigenMenjoYear;
    }

    public void setYukoKigenMenjoYear(String yukoKigenMenjoYear) {
        this.yukoKigenMenjoYear = yukoKigenMenjoYear;
    }

    public String getYukoKigenMenjoMonth() {
        return yukoKigenMenjoMonth;
    }

    public void setYukoKigenMenjoMonth(String yukoKigenMenjoMonth) {
        this.yukoKigenMenjoMonth = yukoKigenMenjoMonth;
    }

    public String getYukoKigenMenjoDay() {
        return yukoKigenMenjoDay;
    }

    public void setYukoKigenMenjoDay(String yukoKigenMenjoDay) {
        this.yukoKigenMenjoDay = yukoKigenMenjoDay;
    }

    public String getShosai() {
        return shosai;
    }

    public void setShosai(String shosai) {
        this.shosai = shosai;
    }

    public String getYubinNoFront() {
        return yubinNoFront;
    }

    public void setYubinNoFront(String yubinNoFront) {
        this.yubinNoFront = yubinNoFront;
    }

    public String getYubinNoBack() {
        return yubinNoBack;
    }

    public void setYubinNoBack(String yubinNoBack) {
        this.yubinNoBack = yubinNoBack;
    }

    public String getJusho1() {
        return jusho1;
    }

    public void setJusho1(String jusho1) {
        this.jusho1 = jusho1;
    }

    public String getJusho2() {
        return jusho2;
    }

    public void setJusho2(String jusho2) {
        this.jusho2 = jusho2;
    }

    public String getTatemono() {
        return tatemono;
    }

    public void setTatemono(String tatemono) {
        this.tatemono = tatemono;
    }

    public String getTelNo() {
        return telNo;
    }

    public void setTelNo(String telNo) {
        this.telNo = telNo;
    }

    public String getFaxNo() {
        return faxNo;
    }

    public void setFaxNo(String faxNo) {
        this.faxNo = faxNo;
    }

    public String getMailAddress() {
        return mailAddress;
    }

    public void setMailAddress(String mailAddress) {
        this.mailAddress = mailAddress;
    }

    public String getKinmusakiYubinFront() {
        return kinmusakiYubinFront;
    }

    public void setKinmusakiYubinFront(String kinmusakiYubinFront) {
        this.kinmusakiYubinFront = kinmusakiYubinFront;
    }

    public String getKinmusakiYubinBack() {
        return kinmusakiYubinBack;
    }

    public void setKinmusakiYubinBack(String kinmusakiYubinBack) {
        this.kinmusakiYubinBack = kinmusakiYubinBack;
    }

    public String getKinmusakiJusho1() {
        return kinmusakiJusho1;
    }

    public void setKinmusakiJusho1(String kinmusakiJusho1) {
        this.kinmusakiJusho1 = kinmusakiJusho1;
    }

    public String getKinmusakiJusho2() {
        return kinmusakiJusho2;
    }

    public void setKinmusakiJusho2(String kinmusakiJusho2) {
        this.kinmusakiJusho2 = kinmusakiJusho2;
    }

    public String getKinmusakiTatemono() {
        return kinmusakiTatemono;
    }

    public void setKinmusakiTatemono(String kinmusakiTatemono) {
        this.kinmusakiTatemono = kinmusakiTatemono;
    }

    public String getKinmusakiTelNo() {
        return kinmusakiTelNo;
    }

    public void setKinmusakiTelNo(String kinmusakiTelNo) {
        this.kinmusakiTelNo = kinmusakiTelNo;
    }

    public String getKinmusakiFaxNo() {
        return kinmusakiFaxNo;
    }

    public void setKinmusakiFaxNo(String kinmusakiFaxNo) {
        this.kinmusakiFaxNo = kinmusakiFaxNo;
    }

    public String getJissiKaijo() {
        return jissiKaijo;
    }

    public void setJissiKaijo(String jissiKaijo) {
        this.jissiKaijo = jissiKaijo;
    }

    public String getUpdateFlag() {
        return updateFlag;
    }

    public void setUpdateFlag(String updateFlag) {
        this.updateFlag = updateFlag;
    }

    public String getLoginKbn() {
        return loginKbn;
    }

    public void setLoginKbn(String loginKbn) {
        this.loginKbn = loginKbn;
    }

    public String getKaiinKbnDisp() {
        String rtn = "";
        if (this.getKaiinKbn().equals("1")) {
            rtn = "���";
        } else if (this.getKaiinKbn().equals("2") || this.getKaiinKbn().equals("3") || this.getKaiinKbn().equals("4")) {
            rtn = "���";
        }
        return rtn;
    }

    public String getMoshikomishaId() {
        return moshikomishaId;
    }

    public void setMoshikomishaId(String moshikomishaId) {
        this.moshikomishaId = moshikomishaId;
    }

    public String getGaijiFlg() {
        return gaijiFlg;
    }

    public String getGaijiFlgDisp() {
        if ("1".equals(gaijiFlg)) {
            return "�O���g�p";
        } else {
            return "�O���s�g�p";
        }
    }

    public String getGaijiShosaiDisp() {
        if ("1".equals(gaijiFlg)) {
            return gaijiShosai;
        } else {
            return "";
        }
    }

    public void setGaijiFlg(String gaijiFlg) {
        this.gaijiFlg = gaijiFlg;
    }

    public String getGaijiShosai() {
        return gaijiShosai;
    }

    public void setGaijiShosai(String gaijiShosai) {
        this.gaijiShosai = gaijiShosai;
    }

    public String getSex() {
        return sex;
    }

    public String getSexDisp() {
        if ("1".equals(sex)) {
            return "�j��";
        } else {
            return "����";
        }
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public String getKyokaiName() {
        return kyokaiName;
    }

    public void setKyokaiName(String kyokaiName) {
        this.kyokaiName = kyokaiName;
    }

    public String getShubetsuCode() {
        return shubetsuCode;
    }

    public void setShubetsuCode(String shubetsuCode) {
        this.shubetsuCode = shubetsuCode;
    }

    public String getSknKsuCode() {
        return sknKsuCode;
    }

    public void setSknKsuCode(String sknKsuCode) {
        this.sknKsuCode = sknKsuCode;
    }

    public String getKaisuCode() {
        return kaisuCode;
    }

    public void setKaisuCode(String kaisuCode) {
        this.kaisuCode = kaisuCode;
    }

    public String getGohiJokyoKbnMoshi() {
        return gohiJokyoKbnMoshi;
    }

    public void setGohiJokyoKbnMoshi(String gohiJokyoKbnMoshi) {
        this.gohiJokyoKbnMoshi = gohiJokyoKbnMoshi;
    }

    public List<HanyouSearchJoho> getMoshikomiDetailList() {
        return moshikomiDetailList;
    }

    public void setMoshikomiDetailList(List<HanyouSearchJoho> moshikomiDetailList) {
        this.moshikomiDetailList = moshikomiDetailList;
    }

    public String getMuryoZanCount() {
        return muryoZanCount;
    }

    public String getMuryoZanCountDisp() {
        return "�����񐔎c�F  " + muryoZanCount + "��";
    }

    public void setMuryoZanCount(String muryoZanCount) {
        this.muryoZanCount = muryoZanCount;
    }

    public String getGokakuNo() {
        return gokakuNo;
    }

    public void setGokakuNo(String gokakuNo) {
        this.gokakuNo = gokakuNo;
    }

    public String getYukoKigenDisp() {
        return BmaDateTimeUtility.formatYMDToDateString(yukoKigen);
    }

    public String getYukoKigen() {
        return yukoKigen;
    }

    public void setYukoKigen(String yukoKigen) {
        this.yukoKigen = yukoKigen;
    }

    public List<HanyouSearchJoho> getHoyoSikakuDetailList() {
        return hoyoSikakuDetailList;
    }

    public void setHoyoSikakuDetailList(List<HanyouSearchJoho> hoyoSikakuDetailList) {
        this.hoyoSikakuDetailList = hoyoSikakuDetailList;
    }

    public List<Option> getSexList() {
        return sexList;
    }

    public void setSexList(List<Option> sexList) {
        this.sexList = sexList;
    }

    public String getTodofuken() {
        return todofuken;
    }

    public void setTodofuken(String todofuken) {
        this.todofuken = todofuken;
    }

    public String getKinmusakiTodofuken() {
        return kinmusakiTodofuken;
    }

    public void setKinmusakiTodofuken(String kinmusakiTodofuken) {
        this.kinmusakiTodofuken = kinmusakiTodofuken;
    }

    public List<Option> getTodofukenList() {
        return todofukenList;
    }

    public void setTodofukenList(List<Option> todofukenList) {
        this.todofukenList = todofukenList;
    }

    public String getBiko() {
        return biko;
    }

    public void setBiko(String biko) {
        this.biko = biko;
    }

    public String getMoshikomiFinishBiDisp() {
        // �\��������
        String ymd = getMoshikomikanryoBiYear() + getMoshikomikanryoBiMonth() + getMoshikomikanryoBiDay();
        if (ymd.isEmpty()) {
            return BmaDateTimeUtility.formatYMDToDateString(moshikomiFinishBi);
        } else {
            return BmaDateTimeUtility.formatYMDToDateString(ymd);
        }
    }

    public String getMoshikomiFinishBi() {
        return moshikomiFinishBi;
    }

    public void setMoshikomiFinishBi(String moshikomiFinishBi) {
        this.moshikomiFinishBi = moshikomiFinishBi;
    }

    public List<Option> getSknNaiyoList() {
        return sknNaiyoList;
    }

    public void setSknNaiyoList(List<Option> sknNaiyoList) {
        this.sknNaiyoList = sknNaiyoList;
    }

    public String getShikenNaiyoKbnDisp() {
        String ret = "";
        if (BmaUtility.isNullOrEmpty(getShikenNaiyoKbn())) {
            return ret;
        }
        for (Option option : getSknNaiyoList()) {
            if (option.getValue().equals(getShikenNaiyoKbn())) {
                ret = option.getLabel();
                break;
            }
        }
        return ret;
    }

    public String getShikenNaiyoKbn() {
        return shikenNaiyoKbn;
    }

    public void setShikenNaiyoKbn(String shikenNaiyoKbn) {
        this.shikenNaiyoKbn = shikenNaiyoKbn;
    }

    public String getGenmenFlg() {
        return genmenFlg;
    }

    public void setGenmenFlg(String genmenFlg) {
        this.genmenFlg = genmenFlg;
    }

    public String getGenmenFlgDisp() {
        if ("0".equals(genmenFlg)) {
            return "�Ȃ�";
        } else {
            return "����";
        }
    }

    public String getMoshikomiJokyoKbn2Disp() {
        String ret = "";
        if (BmaUtility.isNullOrEmpty(getMoshikomiJokyoKbn2())) {
            return ret;
        }
        for (Option option : getMoshikomiJokyoKbnList()) {
            if (option.getValue().equals(getMoshikomiJokyoKbn2())) {
                ret = option.getLabel();
                break;
            }
        }
        return ret;
    }

    public String getMoshikomiJokyoKbn2() {
        return moshikomiJokyoKbn2;
    }

    public void setMoshikomiJokyoKbn2(String moshikomiJokyoKbn2) {
        this.moshikomiJokyoKbn2 = moshikomiJokyoKbn2;
    }

    public String getHairyoFlgDisp() {
        //�z���t���O��00�z���Ȃ�
        //�z���t���O��01
        String ret = "";
        if (BmaUtility.isNullOrEmpty(getHairyoFlg())) {
            return ret;
        }
        for (Option option : getHairyoFlgList()) {
            if (option.getValue().equals(getHairyoFlg())) {
                ret = option.getLabel();
                break;
            }
        }
        return ret;
    }

    public String getHairyoFlg() {
        return hairyoFlg;
    }

    public void setHairyoFlg(String hairyoFlg) {
        this.hairyoFlg = hairyoFlg;
    }

    public String getHairyoNaiyoDisp() {
        //�z���t���O��00�z���Ȃ�
        //�z���t���O��01
        if ("00".equals(hairyoFlg)) {
            return "";
        } else {
            return hairyoNaiyo;
        }
    }

    public String getHairyoNaiyo() {
        return hairyoNaiyo;
    }

    public void setHairyoNaiyo(String hairyoNaiyo) {
        this.hairyoNaiyo = hairyoNaiyo;
    }

    public List<Option> getSofusakiList() {
        return sofusakiList;
    }

    public void setSofusakiList(List<Option> sofusakiList) {
        this.sofusakiList = sofusakiList;
    }

    public String getSofuSakiKbnDisp() {
        String ret = "";
        if (BmaUtility.isNullOrEmpty(getSofuSakiKbn())) {
            return ret;
        }
        for (Option option : getSofusakiList()) {
            if (option.getValue().equals(getSofuSakiKbn())) {
                ret = option.getLabel();
                break;
            }
        }
        return ret;
    }

    public String getSofuSakiKbn() {
        return sofuSakiKbn;
    }

    public void setSofuSakiKbn(String sofuSakiKbn) {
        this.sofuSakiKbn = sofuSakiKbn;
    }

    public String getSknKsuKbn() {
        return sknKsuKbn;
    }

    public void setSknKsuKbn(String sknKsuKbn) {
        this.sknKsuKbn = sknKsuKbn;
    }

    public List<Option> getKaisaichiCodeList() {
        return kaisaichiCodeList;
    }

    public void setKaisaichiCodeList(List<Option> kaisaichiCodeList) {
        this.kaisaichiCodeList = kaisaichiCodeList;
    }

    public String getGakKaisaichiCodeDisp() {
        String ret = "";
        if (BmaUtility.isNullOrEmpty(getGakKaisaichiCode())) {
            return ret;
        }
        for (Option option : getKaisaichiCodeList()) {
            if (option.getValue().equals(getGakKaisaichiCode())) {
                ret = option.getLabel();
                break;
            }
        }
        return ret;
    }

    public String getJissiKaisaichiCodeDisp() {
        String ret = "";
        if (BmaUtility.isNullOrEmpty(getJissiKaisaichiCode())) {
            return ret;
        }
        for (Option option : getKaisaichiCodeList()) {
            if (option.getValue().equals(getJissiKaisaichiCode())) {
                ret = option.getLabel();
                break;
            }
        }
        return ret;
    }

    public String getGakKaisaichiCode() {
        return gakKaisaichiCode;
    }

    public void setGakKaisaichiCode(String gakKaisaichiCode) {
        this.gakKaisaichiCode = gakKaisaichiCode;
    }

    public String getGakkaKaijo() {
        return gakkaKaijo;
    }

    public void setGakkaKaijo(String gakkaKaijo) {
        this.gakkaKaijo = gakkaKaijo;
    }

    public String getGakkaDateDisp() {
        return BmaDateTimeUtility.formatYMDToDateString(gakkaDate);
    }

    public String getJissiDateDisp() {
        return BmaDateTimeUtility.formatYMDToDateString(jissiDate);
    }

    public String getGakkaDate() {
        return gakkaDate;
    }

    public void setGakkaDate(String gakkaDate) {
        this.gakkaDate = gakkaDate;
    }

    public String getJissiKaisaichiCode() {
        return jissiKaisaichiCode;
    }

    public void setJissiKaisaichiCode(String jissiKaisaichiCode) {
        this.jissiKaisaichiCode = jissiKaisaichiCode;
    }

    public String getJissiDate() {
        return jissiDate;
    }

    public void setJissiDate(String jissiDate) {
        this.jissiDate = jissiDate;
    }

    public String getGakkaJusho() {
        return gakkaJusho;
    }

    public void setGakkaJusho(String gakkaJusho) {
        this.gakkaJusho = gakkaJusho;
    }

    public String getJissiJusho() {
        return jissiJusho;
    }

    public void setJissiJusho(String jissiJusho) {
        this.jissiJusho = jissiJusho;
    }

    public String getJissiDateFrom() {
        return jissiDateFrom;
    }

    public String getJissiDateFromToDisp() {
        return BmaDateTimeUtility.formatYMDToDateString(jissiDateFrom) + "�`" + BmaDateTimeUtility.formatYMDToDateString(jissiDateTo);
    }

    public void setJissiDateFrom(String jissiDateFrom) {
        this.jissiDateFrom = jissiDateFrom;
    }

    public String getJissiDateTo() {
        return jissiDateTo;
    }

    public void setJissiDateTo(String jissiDateTo) {
        this.jissiDateTo = jissiDateTo;
    }

    public String getShinseiShikakuNo() {
        return shinseiShikakuNo;
    }

    public void setShinseiShikakuNo(String shinseiShikakuNo) {
        this.shinseiShikakuNo = shinseiShikakuNo;
    }

    public String getShinseiMenjoNo() {
        return shinseiMenjoNo;
    }

    public void setShinseiMenjoNo(String shinseiMenjoNo) {
        this.shinseiMenjoNo = shinseiMenjoNo;
    }

    public String getShokurekiKbn() {
        return shokurekiKbn;
    }

    public void setShokurekiKbn(String shokurekiKbn) {
        this.shokurekiKbn = shokurekiKbn;
    }

    public String getShokurekiKbn1() {
        return shokurekiKbn1;
    }

    public void setShokurekiKbn1(String shokurekiKbn1) {
        this.shokurekiKbn1 = shokurekiKbn1;
    }

    public String getShokurekiKbn3() {
        return shokurekiKbn3;
    }

    public void setShokurekiKbn3(String shokurekiKbn3) {
        this.shokurekiKbn3 = shokurekiKbn3;
    }

    public String getShokurekiKbn4() {
        return shokurekiKbn4;
    }

    public void setShokurekiKbn4(String shokurekiKbn4) {
        this.shokurekiKbn4 = shokurekiKbn4;
    }

    public String getKinmusakiKaishaName() {
        return kinmusakiKaishaName;
    }

    public void setKinmusakiKaishaName(String kinmusakiKaishaName) {
        this.kinmusakiKaishaName = kinmusakiKaishaName;
    }

    public String getBushoYakushokuName() {
        return bushoYakushokuName;
    }

    public void setBushoYakushokuName(String bushoYakushokuName) {
        this.bushoYakushokuName = bushoYakushokuName;
    }

    public String getShokumuNaiyo() {
        return shokumuNaiyo;
    }

    public void setShokumuNaiyo(String shokumuNaiyo) {
        this.shokumuNaiyo = shokumuNaiyo;
    }

    public String getShokumuNaiyoDisp() {
        String ret = "";
        if (BmaUtility.isNullOrEmpty(getShokumuNaiyo())) {
            return ret;
        }
        for (Option option : getShokumuNaiyoList()) {
            if (option.getValue().equals(getShokumuNaiyo())) {
                ret = option.getLabel();
                break;
            }
        }
        return ret;
    }

    public String getShozaichi() {
        return shozaichi;
    }

    public void setShozaichi(String shozaichi) {
        this.shozaichi = shozaichi;
    }

    public String getZaisekikikanFrom() {
        return zaisekikikanFrom;
    }

    public String getZaisekikikanFromDisp() {
        return BmaDateTimeUtility.formatYMToDateString(zaisekikikanFrom) + "�`" + BmaDateTimeUtility.formatYMToDateString(zaisekikikanTo);
    }

    public void setZaisekikikanFrom(String zaisekikikanFrom) {
        this.zaisekikikanFrom = zaisekikikanFrom;
    }

    public String getZaisekikikanTo() {
        return zaisekikikanTo;
    }

    public void setZaisekikikanTo(String zaisekikikanTo) {
        this.zaisekikikanTo = zaisekikikanTo;
    }

    public String getGakkouName() {
        return gakkouName;
    }

    public void setGakkouName(String gakkouName) {
        this.gakkouName = gakkouName;
    }

    public String getGakkouGakka() {
        return gakkouGakka;
    }

    public void setGakkouGakka(String gakkouGakka) {
        this.gakkouGakka = gakkouGakka;
    }

    public String getGakkouShozaichi() {
        return gakkouShozaichi;
    }

    public void setGakkouShozaichi(String gakkouShozaichi) {
        this.gakkouShozaichi = gakkouShozaichi;
    }

    public String getGraduationDate() {
        return graduationDate;
    }

    public String getGraduationDateDisp() {
        return BmaDateTimeUtility.formatYMToDateString(graduationDate);
    }

    public void setGraduationDate(String graduationDate) {
        this.graduationDate = graduationDate;
    }

    public String getKunrenShisetsuName() {
        return kunrenShisetsuName;
    }

    public void setKunrenShisetsuName(String kunrenShisetsuName) {
        this.kunrenShisetsuName = kunrenShisetsuName;
    }

    public String getKunrenka() {
        return kunrenka;
    }

    public void setKunrenka(String kunrenka) {
        this.kunrenka = kunrenka;
    }

    public String getKunrenShozaichi() {
        return kunrenShozaichi;
    }

    public void setKunrenShozaichi(String kunrenShozaichi) {
        this.kunrenShozaichi = kunrenShozaichi;
    }

    public String getKunrenSyuryonenFromDisp() {
        return BmaDateTimeUtility.formatYMToDateString(kunrenSyuryonenFrom);
    }

    public String getKunrenSyuryonenToDisp() {
        return BmaDateTimeUtility.formatYMToDateString(kunrenSyuryonenTo);
    }

    public String getKunrenSyuryonenFrom() {
        return kunrenSyuryonenFrom;
    }

    public void setKunrenSyuryonenFrom(String kunrenSyuryonenFrom) {
        this.kunrenSyuryonenFrom = kunrenSyuryonenFrom;
    }

    public String getKessaiHohoKbn() {
        return kessaiHohoKbn;
    }

    public void setKessaiHohoKbn(String kessaiHohoKbn) {
        this.kessaiHohoKbn = kessaiHohoKbn;
    }

    public String getKessaiJknjkuryo() {
        return kessaiJknjkuryo;
    }

    public void setKessaiJknjkuryo(String kessaiJknjkuryo) {
        this.kessaiJknjkuryo = kessaiJknjkuryo;
    }

    public String getKessaiJimutesuryo() {
        return kessaiJimutesuryo;
    }

    public void setKessaiJimutesuryo(String kessaiJimutesuryo) {
        this.kessaiJimutesuryo = kessaiJimutesuryo;
    }

    public String getKessaiGokeiKingaku() {
        return kessaiGokeiKingaku;
    }

    public void setKessaiGokeiKingaku(String kessaiGokeiKingaku) {
        this.kessaiGokeiKingaku = kessaiGokeiKingaku;
    }

    public String getKessaiShiharaiNo() {
        return kessaiShiharaiNo;
    }

    public void setKessaiShiharaiNo(String kessaiShiharaiNo) {
        this.kessaiShiharaiNo = kessaiShiharaiNo;
    }

    public String getKessaiShiharaiKigenbi() {
        return kessaiShiharaiKigenbi;
    }

    public void setKessaiShiharaiKigenbi(String kessaiShiharaiKigenbi) {
        this.kessaiShiharaiKigenbi = kessaiShiharaiKigenbi;
    }

    public String getPeijiKessaiShunokikanNo() {
        return peijiKessaiShunokikanNo;
    }

    public void setPeijiKessaiShunokikanNo(String peijiKessaiShunokikanNo) {
        this.peijiKessaiShunokikanNo = peijiKessaiShunokikanNo;
    }

    public String getKessaiUserNo() {
        return kessaiUserNo;
    }

    public void setKessaiUserNo(String kessaiUserNo) {
        this.kessaiUserNo = kessaiUserNo;
    }

    public String getKessaiKakuninNo() {
        return kessaiKakuninNo;
    }

    public void setKessaiKakuninNo(String kessaiKakuninNo) {
        this.kessaiKakuninNo = kessaiKakuninNo;
    }

    public String getKessaiJokyo() {
        return kessaiJokyo;
    }

    public void setKessaiJokyo(String kessaiJokyo) {
        this.kessaiJokyo = kessaiJokyo;
    }

    public String getKessaiConvenienceHaraikomiNo() {
        return kessaiConvenienceHaraikomiNo;
    }

    public String getKessaiGokeiKingakuDisp() {
        int okeiKingaku = 0;
        if (!kessaiJknjkuryo.isEmpty() && !kessaiJimutesuryo.isEmpty()) {
            okeiKingaku = Integer.parseInt(kessaiJknjkuryo) + Integer.parseInt(kessaiJimutesuryo);
        }
        return BmaStringUtility.editComma(Integer.toString(okeiKingaku)) + "�~";
    }

    public String getkessaiJimutesuryoDisp() {
        return BmaStringUtility.editComma(kessaiJimutesuryo) + "�~";
    }

    public String getkessaiJknjkuryoDisp() {
        return BmaStringUtility.editComma(kessaiJknjkuryo) + "�~";
    }

    public String getKessaiShiharaiKigenbiDisp() {
        String ymd = getKessaiShiharaiKigenbiYear() + getKessaiShiharaiKigenbiMonth() + getKessaiShiharaiKigenbiDay();
        if (ymd.isEmpty()) {
            return BmaDateTimeUtility.formatYMDToDateString(kessaiShiharaiKigenbi);
        } else {
            return BmaDateTimeUtility.formatYMDToDateString(ymd);
        }
    }

    public void setKessaiConvenienceHaraikomiNo(String kessaiConvenienceHaraikomiNo) {
        this.kessaiConvenienceHaraikomiNo = kessaiConvenienceHaraikomiNo;
    }

    public String getKessaiConvenienceShubetsu() {
        return kessaiConvenienceShubetsu;
    }

    public String getYukouKikenDisp() {
        return BmaDateTimeUtility.formatYMDToDateString(yukouKiken);
    }

    public void setKessaiConvenienceShubetsu(String kessaiConvenienceShubetsu) {
        this.kessaiConvenienceShubetsu = kessaiConvenienceShubetsu;
    }

    public String getBanngo() {
        return banngo;
    }

    public void setBanngo(String banngo) {
        this.banngo = banngo;
    }

    public String getYukouKiken() {
        return yukouKiken;
    }

    public void setYukouKiken(String yukouKiken) {
        this.yukouKiken = yukouKiken;
    }

    public List<Option> getKaijoIdList() {
        return kaijoIdList;
    }

    public void setKaijoIdList(List<Option> kaijoIdList) {
        this.kaijoIdList = kaijoIdList;
    }

    public String getKaijoId() {
        return kaijoId;
    }

    public void setKaijoId(String kaijoId) {
        this.kaijoId = kaijoId;
    }

    public String getKaijoId1() {
        return kaijoId1;
    }

    public void setKaijoId1(String kaijoId1) {
        this.kaijoId1 = kaijoId1;
    }

    public String getKaijoId2() {
        return kaijoId2;
    }

    public void setKaijoId2(String kaijoId2) {
        this.kaijoId2 = kaijoId2;
    }

    public List<Option> getKaijoIdAllList() {
        return kaijoIdAllList;
    }

    public void setKaijoIdAllList(List<Option> kaijoIdAllList) {
        this.kaijoIdAllList = kaijoIdAllList;
    }

    public String getKuusekiConfirm() {
        return kuusekiConfirm;
    }

    public void setKuusekiConfirm(String kuusekiConfirm) {
        this.kuusekiConfirm = kuusekiConfirm;
    }

    public String getKaijoShikenKbn() {
        return kaijoShikenKbn;
    }

    public void setKaijoShikenKbn(String kaijoShikenKbn) {
        this.kaijoShikenKbn = kaijoShikenKbn;
    }

    public String getKaijoCode() {
        return kaijoCode;
    }

    public void setKaijoCode(String kaijoCode) {
        this.kaijoCode = kaijoCode;
    }

    public String getKaijoName() {
        return kaijoName;
    }

    public void setKaijoName(String kaijoName) {
        this.kaijoName = kaijoName;
    }

    public String getKaijoJusho() {
        return kaijoJusho;
    }

    public void setKaijoJusho(String kaijoJusho) {
        this.kaijoJusho = kaijoJusho;
    }

    public String getSearchChange1() {
        return searchChange1;
    }

    public void setSearchChange1(String searchChange1) {
        this.searchChange1 = searchChange1;
    }

    public String getSearchChange2() {
        return searchChange2;
    }

    public void setSearchChange2(String searchChange2) {
        this.searchChange2 = searchChange2;
    }

    public String getKunrenSyuryonenTo() {
        return kunrenSyuryonenTo;
    }

    public void setKunrenSyuryonenTo(String kunrenSyuryonenTo) {
        this.kunrenSyuryonenTo = kunrenSyuryonenTo;
    }

    public List<Option> getKessaiConvenienceShubetsuList() {
        return kessaiConvenienceShubetsuList;
    }

    public void setKessaiConvenienceShubetsuList(List<Option> kessaiConvenienceShubetsuList) {
        this.kessaiConvenienceShubetsuList = kessaiConvenienceShubetsuList;
    }

    public String getKessaiConvenienceShubetsuDisp() {
        String ret = "";
        if (BmaUtility.isNullOrEmpty(getKessaiConvenienceShubetsu())) {
            return ret;
        }
        for (Option option : getKessaiConvenienceShubetsuList()) {
            if (option.getValue().equals(getKessaiConvenienceShubetsu())) {
                ret = option.getLabel();
                break;
            }
        }
        return ret;
    }

    public List<Option> getGenmenFlgList() {
        return genmenFlgList;
    }

    public void setGenmenFlgList(List<Option> genmenFlgList) {
        this.genmenFlgList = genmenFlgList;
    }

    public String getDetailConfirm() {
        return detailConfirm;
    }

    public void setDetailConfirm(String detailConfirm) {
        this.detailConfirm = detailConfirm;
    }

    public List<Option> getShikakuList() {
        return shikakuList;
    }

    public void setShikakuList(List<Option> shikakuList) {
        this.shikakuList = shikakuList;
    }

    public String getShikakuCodeDisp() {
        String ret = "";
        if (BmaUtility.isNullOrEmpty(getShikakuCode())) {
            return ret;
        }
        for (Option option : getShikakuList()) {
            if (option.getValue().equals(getShikakuCode())) {
                ret = option.getLabel();
                break;
            }
        }
        return ret;
    }

    public String getMenjoCodeDisp() {
        String ret = "";
        if (BmaUtility.isNullOrEmpty(getMenjoCode())) {
            return ret;
        }
        for (Option option : getMenjoList()) {
            if (option.getValue().equals(getMenjoCode())) {
                ret = option.getLabel();
                break;
            }
        }
        return ret;
    }

    public String getShikakuCode() {
        return shikakuCode;
    }

    public void setShikakuCode(String shikakuCode) {
        this.shikakuCode = shikakuCode;
    }

    public String getKessaiHohoKbnDisp() {
        String ret = "";
        if (BmaUtility.isNullOrEmpty(getKessaiHohoKbn())) {
            return ret;
        }
        for (Option option : getKessaiHohoKbnList()) {
            if (option.getValue().equals(getKessaiHohoKbn())) {
                ret = option.getLabel();
                break;
            }
        }
        return ret;
    }

    public List<Option> getMenjoList() {
        return menjoList;
    }

    public void setMenjoList(List<Option> menjoList) {
        this.menjoList = menjoList;
    }

    public String getMenjoCode() {
        return menjoCode;
    }

    public void setMenjoCode(String menjoCode) {
        this.menjoCode = menjoCode;
    }

    public String getMoshikomikanryoBiDay() {
        return moshikomikanryoBiDay;
    }

    public void setMoshikomikanryoBiDay(String moshikomikanryoBiDay) {
        this.moshikomikanryoBiDay = moshikomikanryoBiDay;
    }

    public String getMoshikomikanryoBiMonth() {
        return moshikomikanryoBiMonth;
    }

    public void setMoshikomikanryoBiMonth(String moshikomikanryoBiMonth) {
        this.moshikomikanryoBiMonth = moshikomikanryoBiMonth;
    }

    public String getMoshikomikanryoBiYear() {
        return moshikomikanryoBiYear;
    }

    public void setMoshikomikanryoBiYear(String moshikomikanryoBiYear) {
        this.moshikomikanryoBiYear = moshikomikanryoBiYear;
    }

    public List<Option> getHairyoFlgList() {
        return hairyoFlgList;
    }

    public void setHairyoFlgList(List<Option> hairyoFlgList) {
        this.hairyoFlgList = hairyoFlgList;
    }

    public String getZaisekikikanFromYear() {
        return zaisekikikanFromYear;
    }

    public void setZaisekikikanFromYear(String zaisekikikanFromYear) {
        this.zaisekikikanFromYear = zaisekikikanFromYear;
    }

    public String getZaisekikikanFromMonth() {
        return zaisekikikanFromMonth;
    }

    public void setZaisekikikanFromMonth(String zaisekikikanFromMonth) {
        this.zaisekikikanFromMonth = zaisekikikanFromMonth;
    }

    public String getZaisekikikanToYear() {
        return zaisekikikanToYear;
    }

    public void setZaisekikikanToYear(String zaisekikikanToYear) {
        this.zaisekikikanToYear = zaisekikikanToYear;
    }

    public String getZaisekikikanToMonth() {
        return zaisekikikanToMonth;
    }

    public void setZaisekikikanToMonth(String zaisekikikanToMonth) {
        this.zaisekikikanToMonth = zaisekikikanToMonth;
    }

    public String getGraduationDateYear() {
        return graduationDateYear;
    }

    public void setGraduationDateYear(String graduationDateYear) {
        this.graduationDateYear = graduationDateYear;
    }

    public String getGraduationDateMonth() {
        return graduationDateMonth;
    }

    public void setGraduationDateMonth(String graduationDateMonth) {
        this.graduationDateMonth = graduationDateMonth;
    }

    public String getKunrenSyuryonenFromYear() {
        return kunrenSyuryonenFromYear;
    }

    public void setKunrenSyuryonenFromYear(String kunrenSyuryonenFromYear) {
        this.kunrenSyuryonenFromYear = kunrenSyuryonenFromYear;
    }

    public String getKunrenSyuryonenFromMonth() {
        return kunrenSyuryonenFromMonth;
    }

    public void setKunrenSyuryonenFromMonth(String kunrenSyuryonenFromMonth) {
        this.kunrenSyuryonenFromMonth = kunrenSyuryonenFromMonth;
    }

    public String getKunrenSyuryonenToYear() {
        return kunrenSyuryonenToYear;
    }

    public void setKunrenSyuryonenToYear(String kunrenSyuryonenToYear) {
        this.kunrenSyuryonenToYear = kunrenSyuryonenToYear;
    }

    public String getKunrenSyuryonenToMonth() {
        return kunrenSyuryonenToMonth;
    }

    public void setKunrenSyuryonenToMonth(String kunrenSyuryonenToMonth) {
        this.kunrenSyuryonenToMonth = kunrenSyuryonenToMonth;
    }

    public List<Option> getShokumuNaiyoList() {
        return shokumuNaiyoList;
    }

    public void setShokumuNaiyoList(List<Option> shokumuNaiyoList) {
        this.shokumuNaiyoList = shokumuNaiyoList;
    }

    public List<Option> getKessaiHohoKbnList() {
        return kessaiHohoKbnList;
    }

    public void setKessaiHohoKbnList(List<Option> kessaiHohoKbnList) {
        this.kessaiHohoKbnList = kessaiHohoKbnList;
    }

    public String getKessaiShiharaiKigenbiYear() {
        return kessaiShiharaiKigenbiYear;
    }

    public void setKessaiShiharaiKigenbiYear(String kessaiShiharaiKigenbiYear) {
        this.kessaiShiharaiKigenbiYear = kessaiShiharaiKigenbiYear;
    }

    public String getKessaiShiharaiKigenbiMonth() {
        return kessaiShiharaiKigenbiMonth;
    }

    public void setKessaiShiharaiKigenbiMonth(String kessaiShiharaiKigenbiMonth) {
        this.kessaiShiharaiKigenbiMonth = kessaiShiharaiKigenbiMonth;
    }

    public String getKessaiShiharaiKigenbiDay() {
        return kessaiShiharaiKigenbiDay;
    }

    public void setKessaiShiharaiKigenbiDay(String kessaiShiharaiKigenbiDay) {
        this.kessaiShiharaiKigenbiDay = kessaiShiharaiKigenbiDay;
    }

    public List<HanyouSearchJoho> getShokurekiList() {
        return shokurekiList;
    }

    public void setShokurekiList(List<HanyouSearchJoho> shokurekiList) {
        this.shokurekiList = shokurekiList;
    }

    public String getKsuNo() {
        return ksuNo;
    }

    public void setKsuNo(String ksuNo) {
        this.ksuNo = ksuNo;
    }

    public String getGokakuBi() {
        return gokakuBi;
    }

    public void setGokakuBi(String gokakuBi) {
        this.gokakuBi = gokakuBi;
    }

    public String getGokakuBiDisp() {
        if (BmaUtility.isNullOrEmpty(gokakuBi)) {
            return "";
        } else {
            return BmaDateTimeUtility.formatYMDToDateString(gokakuBi);
        }
    }

    public String getDelete() {
        return delete;
    }

    public void setDelete(String delete) {
        this.delete = delete;
    }

    public List<Option> getKoumokuTmpList() {
        return koumokuTmpList;
    }

    public void setKoumokuTmpList(List<Option> koumokuTmpList) {
        this.koumokuTmpList = koumokuTmpList;
    }

    public List<Option> getHanyoKensakuOutList() {
        return hanyoKensakuOutList;
    }

    public void setHanyoKensakuOutList(List<Option> hanyoKensakuOutList) {
        this.hanyoKensakuOutList = hanyoKensakuOutList;
    }

    public String[] getNoOutputData() {
        return noOutputData;
    }

    public void setNoOutputData(String[] noOutputData) {
        this.noOutputData = noOutputData;
    }

    public String[] getOutputData() {
        return outputData;
    }

    public void setOutputData(String[] outputData) {
        this.outputData = outputData;
    }

    public String getExport() {
        return export;
    }

    public void setExport(String export) {
        this.export = export;
    }

    public List<Option> getHanyoKensakuNoOutList() {
        return hanyoKensakuNoOutList;
    }

    public void setHanyoKensakuNoOutList(List<Option> hanyoKensakuNoOutList) {
        this.hanyoKensakuNoOutList = hanyoKensakuNoOutList;
    }

    public String getSaveFlag() {
        return saveFlag;
    }

    public void setSaveFlag(String saveFlag) {
        this.saveFlag = saveFlag;
    }

    public String getKsuNameDetail() {
        return ksuNameDetail;
    }

    public void setKsuNameDetail(String ksuNameDetail) {
        this.ksuNameDetail = ksuNameDetail;
    }

    public String getSknNameDetail() {
        return sknNameDetail;
    }

    public void setSknNameDetail(String sknNameDetail) {
        this.sknNameDetail = sknNameDetail;
    }

    public HanyouSearchJoho getTaihi() {
        return taihi;
    }

    public void setTaihi(HanyouSearchJoho taihi) {
        this.taihi = taihi;
    }

    public String getOutputSelect() {
        return outputSelect;
    }

    public void setOutputSelect(String outputSelect) {
        this.outputSelect = outputSelect;
    }

    public String getSql() {
        return sql;
    }

    public void setSql(String sql) {
        this.sql = sql;
    }

    public List<String> getParam() {
        return param;
    }

    public void setParam(List<String> param) {
        this.param = param;
    }

    public String getSearchFlg() {
        return searchFlg;
    }

    public void setSearchFlg(String searchFlg) {
        this.searchFlg = searchFlg;
    }

    public String getKanriMemo() {
        return kanriMemo;
    }

    public void setKanriMemo(String kanriMemo) {
        this.kanriMemo = kanriMemo;
    }

    public String getNyukinBi() {
        return nyukinBi;
    }

    public String getNyukinBiDisp() {
        return BmaDateTimeUtility.formatYMDToDateString(nyukinBi);
    }

    public String getNyukinBiDisp2() {
        return BmaDateTimeUtility.formatYMDToDateString(nyukinBiYear + nyukinBiMonth + nyukinBiDay);
    }

    public void setNyukinBi(String nyukinBi) {
        this.nyukinBi = nyukinBi;
    }

    public String getKariUketsukeBi() {
        return kariUketsukeBi;
    }

    public void setKariUketsukeBi(String kariUketsukeBi) {
        this.kariUketsukeBi = kariUketsukeBi;
    }

    public String getKariUketsukeBiDisp() {
        if (BmaUtility.isNullOrEmpty(this.kariUketsukeBi)) {
            return "";
        }
        return BmaDateTimeUtility.formatYMDToDateString(kariUketsukeBi);
    }

    public String getKariUketsukeBiDisp2() {
        if (BmaUtility.isNullOrEmpty(this.kariUketsukeBi)) {
            return "";
        }
        return BmaDateTimeUtility.formatYMDToDateString(kariUketsukeBiYear + kariUketsukeBiMonth + kariUketsukeBiDay);
    }

    public String getKessaiKingakuTotal() {
        return kessaiKingakuTotal;
    }

    public void setKessaiKingakuTotal(String kessaiKingakuTotal) {
        this.kessaiKingakuTotal = kessaiKingakuTotal;
    }

    public String getNyukinBiYear() {
        return nyukinBiYear;
    }

    public void setNyukinBiYear(String nyukinBiYear) {
        this.nyukinBiYear = nyukinBiYear;
    }

    public String getNyukinBiMonth() {
        return nyukinBiMonth;
    }

    public void setNyukinBiMonth(String nyukinBiMonth) {
        this.nyukinBiMonth = nyukinBiMonth;
    }

    public String getNyukinBiDay() {
        return nyukinBiDay;
    }

    public void setNyukinBiDay(String nyukinBiDay) {
        this.nyukinBiDay = nyukinBiDay;
    }

    public String getKariUketsukeBiYear() {
        return kariUketsukeBiYear;
    }

    public void setKariUketsukeBiYear(String kariUketsukeBiYear) {
        this.kariUketsukeBiYear = kariUketsukeBiYear;
    }

    public String getKariUketsukeBiMonth() {
        return kariUketsukeBiMonth;
    }

    public void setKariUketsukeBiMonth(String kariUketsukeBiMonth) {
        this.kariUketsukeBiMonth = kariUketsukeBiMonth;
    }

    public String getKariUketsukeBiDay() {
        return kariUketsukeBiDay;
    }

    public void setKariUketsukeBiDay(String kariUketsukeBiDay) {
        this.kariUketsukeBiDay = kariUketsukeBiDay;
    }

    public List<HanyouGazouJoho> getGazouList() {
        return gazouList;
    }

    public void setGazouList(List<HanyouGazouJoho> gazouList) {
        this.gazouList = gazouList;
    }

    public String getKessaiKingakuTotalDisp() {
        if (BmaUtility.isNullOrEmpty(this.kessaiKingakuTotal)) {
            return "0�~";
        }
        return BmaStringUtility.editComma(this.kessaiKingakuTotal) + "�~";
    }
}
