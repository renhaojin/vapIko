package jp.co.nii.bma.business.service.manager;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import jp.co.nii.bma.business.domain.Gazo;
import jp.co.nii.bma.business.domain.HoyuShikakuMst;
import jp.co.nii.bma.business.domain.Kessai;
import jp.co.nii.bma.business.domain.MSkkMnjKanri;
import jp.co.nii.bma.business.domain.MeishoKanri;
import jp.co.nii.bma.business.domain.Moshikomi;
import jp.co.nii.bma.business.domain.MoshikomiHenkoRireki;
import jp.co.nii.bma.business.domain.Saiban;
import jp.co.nii.bma.business.domain.ShiyoKaijo;
import jp.co.nii.bma.business.domain.SknksuMst;
import jp.co.nii.bma.business.domain.Torokusha;
import jp.co.nii.bma.business.domain.TorokushaHenkoRireki;
import jp.co.nii.bma.business.rto.manager.SmnMskJoho;
import jp.co.nii.bma.business.service.common.BmaConstants;
import jp.co.nii.bma.business.service.common.BmaLogger;
import jp.co.nii.bma.business.service.common.BmaSaibanService;
import jp.co.nii.bma.business.service.common.BmaValidator;
import jp.co.nii.bma.presentation.common.BmaText;
import jp.co.nii.bma.utility.BmaFileUtility;
import jp.co.nii.bma.utility.BmaUtility;
import jp.co.nii.sew.business.service.AbstractService;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_BACK;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_RELOAD;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_SUCCESS;
import jp.co.nii.sew.presentation.Messages;
import jp.co.nii.sew.presentation.Option;
import jp.co.nii.sew.presentation.RequestTransferObject;
import jp.co.nii.sew.utility.PropertyUtility;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.fileupload.FileItem;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import java.net.URLEncoder;
import java.util.Locale;
import jp.co.nii.bma.business.domain.Schedule;
import jp.co.nii.bma.business.service.common.GazoCommonService;
import jp.co.nii.bma.business.service.common.MoshikomiCommonService;
import jp.co.nii.bma.utility.BmaStringUtility;
import jp.co.nii.sew.presentation.Message;
import jp.co.nii.sew.utility.CheckUtility;
import jp.co.nii.sew.utility.FileUtility;
import org.apache.poi.ss.util.CellReference;

/**
 * �^�C�g��: �\���f�[�^�A�b�v���[�h�T�[�r�X ����: �\���f�[�^�A�b�v���[�hRTO ���쌠: Copyright (c) 2020 ��Ж�:
 * ���{���Y�Ɗ������
 *
 */
public class SmnMskService extends AbstractService {

    /**
     * DB�ڑ��̃f�[�^�\�[�X
     */
    private static String DATA_SOURCE_NAME;
    /**
     * ���O
     */
    BmaLogger log = (BmaLogger) BmaLogger.getLogger(this.getClass().getName());
    /**
     * �Ɩ��R�[�h
     */
    private static final String BUSINESS_CODE = PropertyUtility.getProperty("business_code");
    /**
     * ���׃e�X�g���[�h
     */
    private static final String STRESS_MODE = PropertyUtility.getProperty(BUSINESS_CODE + "stress_mode");
    /**
     * �t�F�C���T�C�Y
     */
    private static final String CSV_SIZE = PropertyUtility.getProperty(BUSINESS_CODE + "max_csv_size");

    /**
     * �R���X�g���N�^
     */
    public SmnMskService() {
        super();
        /* DB�ڑ����̃��[�U�[������ */
        DATA_SOURCE_NAME = BmaConstants.DS_REGISTRANT;
    }

    /**
     * �T�[�r�X�N���X�̎��s���\�b�h
     *
     * @param rto ���N�G�X�g��񂩂�擾����rto
     * @param rtoInSession �Z�b�V�������rto
     * @return foward��
     * @throws Exception ��O
     */
    @Override
    public String doService(RequestTransferObject rto, RequestTransferObject rtoInSession)
            throws Exception {

        SmnMskJoho inRequest = (SmnMskJoho) rto;
        SmnMskJoho inSession = (SmnMskJoho) rtoInSession;
        String processName = "";

        /*�G���[���b�Z�[�W������*/
        inSession.setErrors(new Messages());
        try {
            if (!BmaUtility.isNullOrEmpty(inRequest.getShomenMsk())) {
                /*�u���ʐ\���v�{�^��������*/
                processName = "SmnMskDataUpload";
                log.Start(processName);
                inSession.clearInfo();
                inSession.setTorokuKanryoSknKsuName("");
                inSession.setMoshikomishaId(inRequest.getMoshikomishaId());
//                inSession.setNendo("2020");
                /*���j���[�o�^���{�^��������*/
                processName = "GazoSearchInput";
                log.Start(processName);
                /*���������X�g�擾*/
                inSession.setSknKbnList(findSknKsuList(BmaConstants.SKN_KBN));
                inSession.setKsuKbnList(findSknKsuList(BmaConstants.KSU_KBN));
                inRequest.setKsuName(BmaConstants.KSU_CHECK);
                kaijoSearch(inRequest, inSession);
                inSession.setSknksuKbn(BmaConstants.SKN_KBN);
                inSession.setShomenMsk(inRequest.getShomenMsk());
                /* �\���f�[�^�A�b�v���[�h ��ʕ\�� */
                return FWD_NM_SUCCESS;
            } else if (!BmaUtility.isNullOrEmpty(inRequest.getMskUl())) {
                /*�u�A�b�v���[�h�v�{�^��������*/
                processName = "SmnMskDataUpload";
                log.Start(processName);
                if (BmaUtility.isNullOrEmpty(inSession.getTorokuKanryoSknKsuName())) {
                    /*���͒l���Z�b�V�����ɕۑ�*/
                    setValueRequestToSession(inRequest, inSession);
                    inSession.setFuriganaOnlyErrFlg(BmaConstants.FLG_OFF);
                    inSession.setErrorLogFlg(BmaConstants.FLG_OFF);
                    // �t�@�C���擾
                    String fileName = inRequest.getMskFileChoice().getName();
                    File file = new File(fileName);
                    // PATH���t���Ă���̃t�@�C���̂ݔ��f����
                    int index = fileName.indexOf("\\");
                    // IE��������
                    if (index > 0 && !file.exists()) {
                        /* �e�h�k�d���݂��Ă��܂���̎��G���[*/
                        Messages errors = new Messages();
                        BmaValidator.addMessage(errors, "info",
                                "�t�@�C�������݂��܂���B", "�t�@�C��");
                        inSession.setErrors(errors);
                        return FWD_NM_RELOAD;
                    }

                    /*�g���q�`�F�b�N*/
                    if (!validateSearchInput(inRequest, inSession)) {
                        /*�G���[���������ꍇ�͌���������ʍĕ\��*/
                        return FWD_NM_RELOAD;
                    }
                    boolean result = false;
                    // �G���[���X�g
                    List<ErrorMsg> errorLog = new ArrayList<>();
                    //�t�@�C���`���`�F�b�N
                    if (validateImportFile(inRequest, inSession)) {
                        //�C���|�[�g
                        if (importFile(inRequest, inSession, errorLog)) {
                            result = true;
                        }
                    } else {
                        /*�G���[���������ꍇ�͌���������ʍĕ\��*/
                        return FWD_NM_RELOAD;
                    }

                    if (result) {
                        log.info("���I���ʃf�[�^�C���|�[�g����I��");
                        SknksuMst sknksuMst = new SknksuMst(DATA_SOURCE_NAME);
                        String sknKsuName = sknksuMst.find(inSession.getSknKsuCode(), inSession.getShubetsuCode(), inSession.getKaisuCode()).getSknKsuNameRyaku();
                        inSession.setTorokuKanryoSknKsuName(sknKsuName);
                        inRequest.setMskUl("");
                        return "complete";
                    } else {
                        if (BmaConstants.FLG_ON.equals(inSession.getFuriganaOnlyErrFlg())) {
                            log.error("�f�[�^�C���|�[�g�ُ�I��_�t���K�i�s��v�̂�");
                        } else {
                            log.error("�f�[�^�C���|�[�g�ُ�I��_�f�[�^NG");
                        }
                        inSession.setErrorLogForDownload(errorLog);
                        if (inSession.getErrors().get("info") == null) {
                            inSession.setErrors(new Messages());
                        }
                        return FWD_NM_RELOAD;
                    }
                } else {
                    return "complete";
                }
            } else if (!BmaUtility.isNullOrEmpty(inRequest.getErrorLogCheck())) {
                /*�t���K�i�̂ݕs��v�E�G���[���O����̃|�b�v�A�b�v�I����*/
                processName = "errorLogCheck";
                log.Start(processName);
                
                if ("ok".equals(inRequest.getErrorLogCheck())) {
                    inSession.setFuriganaOnlyErrFlg(BmaConstants.FLG_OFF);
                    try {
                        // �g�����U�N�V�����J�n
                        getTransaction();
                        beginTransaction();
                        for (SmnMskJoho smnJoho : inSession.getCsvEvacuationList()) {
                            csvToroku(inRequest, inSession, smnJoho);
                        }
                        // �R�~�b�g
                        commitTransaction();
                    } catch (Exception ex) {
                        // ���[���o�b�N
                        rollbackTransaction();
                        return FWD_NM_RELOAD;
                    }
                    log.info("���I���ʃf�[�^�C���|�[�g����I��");
                    SknksuMst sknksuMst = new SknksuMst(DATA_SOURCE_NAME);
                    String sknKsuName = sknksuMst.find(inSession.getSknKsuCode(), inSession.getShubetsuCode(), inSession.getKaisuCode()).getSknKsuNameRyaku();
                    inSession.setTorokuKanryoSknKsuName(sknKsuName);
                    // ���펞��ʃ��b�Z�[�W�Z�b�g
                    inSession.setTorokuKanryoKensu(String.valueOf(inSession.getCsvEvacuationList().size()) + "��");
                    inRequest.setMskUl("");
                    return "complete";
                } else {
                    createCsv(inRequest, inSession, inSession.getErrorLogForDownload());
                    inSession.clearInfo();
                    inSession.setMoshikomishaId(inRequest.getMoshikomishaId());
                    return DOWNLOAD;
                }
            } else if (!BmaUtility.isNullOrEmpty(inRequest.getMskTmpDl())) {
                /*�u�e���v���[�g�_�E�����[�h�v�{�^��������*/
                processName = "MskDownload";
                log.Start(processName);
                excelDownload(inRequest, inSession);
                return DOWNLOAD;
            } else if (!BmaUtility.isNullOrEmpty(inRequest.getMskGazoUl())
                    && BmaUtility.isNullOrEmpty(inRequest.getUploadCheck())) {
                processName = "SmnMskGazoUpload";
                log.Start(processName);
                inSession.setPage(0);
                inSession.setSknKsuCode(inSession.getSknKsuCode());
                inSession.setShubetsuCode(inSession.getShubetsuCode());
                inSession.setKaisuCode(inSession.getKaisuCode());
                inSession.setSeniFlg("1");
                SknksuMst sknksuMst = new SknksuMst(BmaConstants.DS_REGISTRANT);
                String sknKsuNameChi = sknksuMst.findSknKsuNameRyaku(inSession.getSknKsuCode(),
                        inSession.getShubetsuCode(), inSession.getKaisuCode()).getSknKsuNameRyaku();
                inSession.setMskGazoUl(inRequest.getMskGazoUl());
                /*�������X�g�擾*/
                if (!searchJoho(inSession)) {
                    /*1�����q�b�g���Ȃ������ꍇ�͌���������ʍĕ\��*/
                    return FWD_NM_RELOAD;
                }
                /*�\�����X�g�擾*/
                if (inSession.getPage() == 0) {
                    setPage(inSession);
                    pageIndex(inSession);
                }
                inSession.setGazoUlKekka("����/�u�K��F" + sknKsuNameChi + "�@�摜���A�b�v���[�h�����F" + inSession.getSearchOutList().size());
                return FWD_NM_RELOAD;
            } else if (!BmaUtility.isNullOrEmpty(inRequest.getGazoUlComplete())) {
                /*�u�����v�{�^��������*/
//                processName = "SmnComplete";
//                log.Start(processName);
//                List<SmnMskJoho> list = new ArrayList<>();
//                list = inSession.getGazoDetailList();
//                if (!BmaUtility.isNullOrEmpty(inSession.getGazoUpd())) {
//                    int cnt = 0;
//                    try {
//                        /* �g�����U�N�V�����擾&�J�n */
//                        getTransaction();
//                        beginTransaction();
//                        for (int i = 0; i < list.size(); i++) {
//                            if (list.get(i).getGazoUlFlg().equals("��")) {
//                                /* �������Z�b�g */
//                                inSession.setNendo(list.get(i).getNendo());
//                                inSession.setGazoUlUketsukeNo(list.get(i).getGazoUlUketsukeNo());
//                                inSession.setSeq(list.get(i).getSeq());
//                                inSession.setGazoKbn(list.get(i).getGazoKbn());
//                                inSession.setGazo_idx(list.get(i).getGazo_idx());
//                                inSession.setMoshikomishaId(list.get(i).getMoshikomishaId());
//                                // �\��������������
//                                Moshikomi moshikomi = new Moshikomi(DATA_SOURCE_NAME);
//                                // �\�������X�V����
//                                BeanUtils.copyProperties(moshikomi, moshikomi.find(inSession.getNendo(), inSession.getGazoUlUketsukeNo()));
//                                /* �X�V���Z�b�g */
//                                moshikomiUpd(moshikomi, inSession);
//                                /*�A�b�v�f�[�g���s*/
//                                moshikomi.update();
//                                // �\���ύX��������o�^����
//                                MoshikomiHenkoRireki moshikomiHenkoRireki = new MoshikomiHenkoRireki(DATA_SOURCE_NAME);
//                                /* �\����񂩂�\���ύX�������ɒl���R�s�[ */
//                                BeanUtils.copyProperties(moshikomiHenkoRireki, moshikomi);
//                                /* �o�^���Z�b�g */
//                                moshikomihenkoTrk(moshikomiHenkoRireki, inSession);
//                                /*�C���T�[�g���s*/
//                                moshikomiHenkoRireki.create();
//                                //�摜�����X�V����
//                                Gazo gazo = new Gazo(DATA_SOURCE_NAME);
//                                /* �\����񂩂�摜���ɒl���R�s�[ */
//                                BeanUtils.copyProperties(gazo, gazo.find(inSession.getNendo(), inSession.getGazoUlUketsukeNo(), inSession.getGazoKbn(), inSession.getSeq()));
//                                /* �X�V���Z�b�g */
//                                gazoUpd(gazo, inSession);
//                                /*�A�b�v�f�[�g���s*/
//                                gazo.update();
//                                // ���ʏ����F�\���󋵋敪�X�V 
//                                MoshikomiCommonService commonService = new MoshikomiCommonService(DATA_SOURCE_NAME);
//                                commonService.updateMoshikomiKbn(inSession.getNendo(), inSession.getGazoUlUketsukeNo(), inSession.getMoshikomishaId());
//                                // ���ʏ����F�摜�\���敪�X�V
//                                GazoCommonService gazoCommonService = new GazoCommonService(DATA_SOURCE_NAME);
//                                gazoCommonService.updateGazoHyojiKbn(gazo.getNendo(), gazo.getUketsukeNo(), gazo.getGazoKbn(), gazo.getSeq(), inSession.getMoshikomishaId());
//                                cnt++;
//                            }
//                        }
//                        /* �R�~�b�g */
//                        commitTransaction();
//                        inSession.setGazoUpd("");
//                        inSession.setGazoUlComplete("1");
//                    } catch (Exception ex) {
//                        // ���[���o�b�N
//                        rollbackTransaction();
//                        return FWD_NM_RELOAD;
//                    }
//                    inSession.setPage(0);
//                    /*�������X�g�擾*/
//                    if (!searchJoho(inSession)) {
//                        /*1�����q�b�g���Ȃ������ꍇ�͌���������ʍĕ\��*/
//                        return FWD_NM_RELOAD;
//                    }
//                    /*�\�����X�g�擾*/
//                    if (inSession.getPage() == 0) {
//                        setPage(inSession);
//                        pageIndex(inSession);
//                    }
//                    inSession.setGazoUlKekka("����/�u�K��F" + inSession.getSknKsuNameChi() + "�@�摜���A�b�v���[�h�����F" + (inSession.getUpKensu() - cnt));
//                    /* �u���ʐ\���o�^�����v��ʂɑJ�� */
//                }
                return FWD_NM_RELOAD;
            } else if (!BmaUtility.isNullOrEmpty(inRequest.getGazoUlBack())) {
                /*�u�߂�v�{�^��������*/
                processName = "SmnGazoDataUploadBack";
                log.Start(processName);
                inSession.setPage(0);
                /* �߂� */
                String let = null;
                if (inRequest.getGazoUlBack().equals("ok")) {
                    if (!inSession.getGazoUlComplete().equals("1") && inRequest.getUploadCheck().equals("1")) {
                        String orgPath = BmaConstants.PHOTO_UPLOAD_PATH_KAKUTEI;
                        List<SmnMskJoho> list = new ArrayList<>();
                        list = inSession.getGazoDetailList();
                        for (int i = 0; i < list.size(); i++) {
                            String strNam = list.get(i).getGazo_idx() + ".jpeg";
                            FileUtility.fileDelete(orgPath + strNam);
                        }
                    }
                    let = FWD_NM_BACK;
                    inSession.setGazoUlComplete("");
                } else {
                    let = FWD_NM_RELOAD;
                }
                return let;
            } else if (!BmaUtility.isNullOrEmpty(inRequest.getGazoChoiceGazoUpd())
                    || !BmaUtility.isNullOrEmpty(inRequest.getGazoUlSeq())) {
                /*�u�A�b�v���[�h�v�{�^��������*/
                processName = "MgrGazoUpload";
                log.Start(processName);
                // �X�e�[�^�X�ݒ�
                setStatus(inSession, inRequest);
                /* �u�摜�f�[�^�A�b�v���[�h�v��ʂɖ߂� */
                return FWD_NM_RELOAD;
            } else if (!BmaUtility.isNullOrEmpty(inRequest.getGazoSearch())) {
                processName = "SmnMskGazoUpload";
                log.Start(processName);
                inSession.setPage(0);
                inSession.setNendo(inRequest.getNendo());
                inSession.setSknKsuCode(inRequest.getSknKsuCode());
                inSession.setShubetsuCode(inRequest.getShubetsuCode());
                inSession.setKaisuCode(inRequest.getKaisuCode());
                inSession.setSeniFlg("2");
                SknksuMst sknksuMst = new SknksuMst(BmaConstants.DS_REGISTRANT);
                String sknKsuNameChi = sknksuMst.findSknKsuNameRyaku(inSession.getSknKsuCode(),
                        inSession.getShubetsuCode(), inSession.getKaisuCode()).getSknKsuNameRyaku();
                /*�������X�g�擾*/
                if (!searchJoho(inSession)) {
                    /*1�����q�b�g���Ȃ������ꍇ�͌���������ʍĕ\��*/
                    inSession.setGazoUlKekka("����/�u�K��F" + sknKsuNameChi + "�@�摜���A�b�v���[�h�����F0");
                    return FWD_NM_RELOAD;
                }
                /*�\�����X�g�擾*/
                if (inSession.getPage() == 0) {
                    setPage(inSession);
                    pageIndex(inSession);
                }
                inSession.setGazoUlKekka("����/�u�K��F" + sknKsuNameChi + "�@�摜���A�b�v���[�h�����F" + inSession.getSearchOutList().size());
                inSession.setSknKsuNameChi(sknKsuNameChi);
                inSession.setUpKensu(inSession.getSearchOutList().size());
                return FWD_NM_SUCCESS;
            } else if (!BmaUtility.isNullOrEmpty(inRequest.getCommandPage())) {
                /*�y�[�W�J��*/
                processName = "setPage";
                log.Start(processName);
                inSession.setPage(Integer.parseInt(inRequest.getCommandPage()));
                setPage(inSession);
                pageIndex(inSession);
                return FWD_NM_SUCCESS;
            } else if (!BmaUtility.isNullOrEmpty(inRequest.getGazoUl())) {
                /*�u��ʐ^�v�{�^��������*/
                processName = "MgrGazoSelect";
                log.Start(processName);

                inSession.setGazoUl(inRequest.getGazoUl());
                inSession.setGazoUlUketsukeNo(inRequest.getGazoUlUketsukeNo());
                inSession.setGazoUlJknJkuNo(inRequest.getGazoUlJknJkuNo());
                inSession.setGazoUlFurigana(inRequest.getGazoUlFurigana());
                inSession.setGazoUlSimei(inRequest.getGazoUlSimei());

                /* �u�摜�I���v��ʂɑJ�� */
                return FWD_NM_UPLOAD;
            }
            if (!BmaUtility.isNullOrEmpty(inRequest.getGazoKakuninBack())) {
                /*�u����v�{�^��������*/
                processName = "MgrGazoSelectBack";
                log.Start(processName);

                /* �u�摜�f�[�^�A�b�v���[�h�v��ʂɖ߂� */
                return FWD_NM_RELOAD;
            } else if (!BmaUtility.isNullOrEmpty(inRequest.getGazoUlKakunin())) {
                /*�u�m�F�v�{�^��������*/
                processName = "MgrGazoConfirm";
                log.Start(processName);

                inSession.setGazoUlKakunin(inRequest.getGazoUlKakunin());

                /* �u�摜�m�F�v��ʂɑJ�� */
                return FWD_NM_CONFIRM;
            } else if (inRequest.getSknksuKbn().equals(BmaConstants.KSU_KBN)) {
                /*��ꌟ��*/
                inSession.setSknksuKbn(inRequest.getSknksuKbn());
                inSession.setKsuName(inRequest.getKsuName());
                kaijoSearch(inRequest, inSession);
                return FWD_NM_SUCCESS;
            } else {
                /*�ُ�J��*/
                log.IllegalFWD();
                return FWD_NM_SESSION;
            }
        } catch (Exception e) {
            return FWD_NM_EXCEPTION;
        } finally {
            log.End(processName);
        }
    }

    // �X�e�[�^�X�ݒ�
    private void setStatus(SmnMskJoho inSession, SmnMskJoho inRequest) throws NumberFormatException {
        List<SmnMskJoho> list = inSession.getGazoDetailList();
        int gazoUiSeq = Integer.parseInt(inRequest.getGazoUlSeq());
        int page = inSession.getPage();
        if (gazoUiSeq > 20) {
            gazoUiSeq = gazoUiSeq - (BmaConstants.MAX_PAGE_NUM_MSK_JOHO_SEARCH * (page - 1));
        }
        if (!BmaUtility.isNullOrEmpty(inRequest.getUploadCheck())) {
            list.get(gazoUiSeq - 1).setGazoUlFlg("��");
        }
        // �폜���ꂽ�ꍇ
        if (BmaUtility.isNullOrEmpty(inRequest.getGazo_idx())) {
            list.get(gazoUiSeq - 1).setGazoUlFlg("��");
        }
        
        list.get(gazoUiSeq - 1).setGazo_idx(inRequest.getGazo_idx());
        inSession.setGazoDetailList(list);
        
        inRequest.setUploadCheck("");
        inSession.setGazoUpd("1");
    }
    
    // �X�e�[�^�X�ݒ� �摜�폜��
    private void setDeleteStatus(SmnMskJoho inSession, SmnMskJoho inRequest) throws NumberFormatException {
        List<SmnMskJoho> list = inSession.getGazoDetailList();
        int gazoUiSeq = Integer.parseInt(inRequest.getGazoUlSeq());
        int page = inSession.getPage();
        if (gazoUiSeq > 20) {
            gazoUiSeq = gazoUiSeq - (BmaConstants.MAX_PAGE_NUM_MSK_JOHO_SEARCH * (page - 1));
        }
        list.get(gazoUiSeq - 1).setGazoUlFlg("��");
        list.get(gazoUiSeq - 1).setGazo_idx("");
        inSession.setGazoDetailList(list);
        inRequest.setUploadCheck("");
        inSession.setGazoUpd("1");
    }

    /**
     * ��ꌟ�������ɃZ�b�g����B
     *
     * @param inRequest ���N�G�X�g��̓��̓f�[�^
     * @param inSession �Z�b�V������̓��̓f�[�^
     */
    private void kaijoSearch(SmnMskJoho inRequest, SmnMskJoho inSession) {
        String sknksuName = inRequest.getKsuName();
        inSession.setSknKsuCode(sknksuName.substring(0, 2));
        inSession.setShubetsuCode(sknksuName.substring(2, 4));
        inSession.setKaisuCode(sknksuName.substring(4, 6));
        inSession.setSknksuKbn(inRequest.getSknksuKbn());
        inSession.setKaijoshikenkbn("0");
        // �N�x�擾
        Schedule schedule = new Schedule(BmaConstants.DS_REGISTRANT);
        String nendo = schedule.findNendoKojiKikan(inSession.getSknKsuCode(), inSession.getShubetsuCode(), inSession.getKaisuCode(), BmaConstants.SCHED_CODE_OPEN, BmaConstants.SCHEDULE_KBN_ST);
        inSession.setNendo(nendo);
        List<SmnMskJoho> kaijoList = new ArrayList<>();
        List<SmnMskJoho> kaijoListNew = new ArrayList<>();
        /*��ꃊ�X�g�擾*/
        ShiyoKaijo shiyoKaijo = new ShiyoKaijo(BmaConstants.DS_REGISTRANT);
        kaijoList = shiyoKaijo.searchKaijoList(inSession.getNendo(), inSession.getSknKsuCode(),
                inSession.getShubetsuCode(), inSession.getKaisuCode(), inSession.getKaijoshikenkbn());
        /*���X�g�̊J�Òn�擾*/
        Map<String, List<SmnMskJoho>> Kaisaichi = kaijoList.stream().collect(
                Collectors.groupingBy(SmnMskJoho::getKaisaichiCode));

        for (Map.Entry<String, List<SmnMskJoho>> entry : Kaisaichi.entrySet()) {
            List<SmnMskJoho> listGroup = entry.getValue();
            for (SmnMskJoho item : listGroup) {
                item.setCount(listGroup.size() + "");
                kaijoListNew.add(item);
            }
        }
        inSession.setKaiMskJohoList(kaijoListNew);
    }

    /**
     * �\��������������
     *
     * @param inSession �Z�b�V����RTO
     * @return true:����
     */
    private boolean searchJoho(SmnMskJoho inSession) {
        Messages errors = new Messages();
        inSession.setSearchFlg("0");
        inSession.setSearchOutList(findGazoList(inSession));
        inSession.setSearchFlg("1");
        if (inSession.getSearchOutList().isEmpty()) {
            /* �L�[���X�g����̏ꍇ */
            BmaValidator.addMessage(errors, BmaConstants.ERR_GROUP_GAZO_SEARCH, BmaText.E00022, BmaConstants.ARG_GAZO_SEARCH);
            inSession.setErrors(errors);
            return false;
        }
        return true;
    }

    /**
     * �摜�ꗗ���X�g������
     *
     * @param inSession
     * @return list
     */
    public List<SmnMskJoho> findGazoList(SmnMskJoho inSession) {
        int page = inSession.getPage();
        List<SmnMskJoho> list = new ArrayList<>();
        Gazo gazo = new Gazo(BmaConstants.DS_REGISTRANT);
        if (!BmaUtility.isNullOrEmpty(inSession.getMskGazoUl())) {
            list = gazo.searchGazoListShomen(inSession.getUketsukeNos(), inSession.getNendo());
        } else {
            list = gazo.searchGazoDateList(inSession.getSknKsuCode(), inSession.getShubetsuCode(),
                    inSession.getKaisuCode(), inSession.getSearchFlg(), inSession.getNendo(), inSession.getPage());
        }
        for (int i = 0; i < list.size(); i++) {
            if (page == 0) {
                list.get(i).setGazoUlSeq(String.valueOf(i + 1));
            } else {
                list.get(i).setGazoUlSeq(String.valueOf(i + (BmaConstants.MAX_PAGE_NUM_MSK_JOHO_SEARCH * page) + 1));
            }
        }
        return list;
    }

    /**
     * �\������f�[�^������
     *
     * @param inSession
     */
    public void pageIndex(SmnMskJoho inSession) {
        /* �ϐ������� */
        List<SmnMskJoho> displayList = new ArrayList<>();
        SmnMskJoho shomenMsk;

        List<SmnMskJoho> resultList = inSession.getSearchOutList();
        /* �y�[�W���ɍ��킹�ĕ\���p���X�g�쐬 */
        for (int i = inSession.getFirstDisp() - 1; i < inSession.getMaxDisp(); ++i) {
            shomenMsk = resultList.get(i);
            displayList.add(shomenMsk);
        }
        inSession.setGazoDetailList(displayList);
    }

    /**
     * �y�[�W����
     *
     * @param inSession�@�Z�b�V�������X�g
     * @return �\���p�L�[���X�g
     */
    private void setPage(SmnMskJoho inSession) {
        int idx;
        int max;
        int maxLenDisp = inSession.getSearchOutList().size();
        int pageMax;

        /* ��ʂɕ\������ő匏�����擾 */
        int page = inSession.getPage();
        idx = page * BmaConstants.MAX_PAGE_NUM_MSK_JOHO_SEARCH;

        max = idx + BmaConstants.MAX_PAGE_NUM_MSK_JOHO_SEARCH;
        inSession.setFirstDisp(idx + 1);

        /* �������ʂ̌��� */
        if (maxLenDisp < max) {
            inSession.setMaxDisp(maxLenDisp);
        } else {
            /* �ő匏����茟�����ʂ������ꍇ */
            inSession.setMaxDisp(max);
        }

        /* �y�[�W�ԍ��̍ő���v�Z */
        pageMax = (int) (Math.ceil((double) maxLenDisp / (double) (BmaConstants.MAX_PAGE_NUM_MSK_JOHO_SEARCH)));
        inSession.setPageMax(pageMax + 1);

        /* �y�[�W�ԍ��ݒ� */
        int now = 0;
        now = inSession.getPage();

        /* �Œጏ�� */
        if (now == 0) {
            inSession.setPageBegin(now + 1);
        } else if (now == 1) {
            inSession.setPageBegin(now);
        } else if (now == 2) {
            inSession.setPageBegin(now - 1);
        } else {
            inSession.setPageBegin(now - 2);
        }
        /* �ő匏�����\������ő匏����3�{�ȉ��������ꍇ�̕\���p�y�[�W�ԍ� */
        if (now == pageMax) {
            inSession.setPageEnd(now + 1);
        } else if (now == pageMax - 1) {
            inSession.setPageEnd(now + 2);
        } else if (now == pageMax - 2) {
            inSession.setPageEnd(now + 3);
        } else {
            inSession.setPageEnd(now + 4);
        }
        inSession.setPage(now + 1);
    }

    /**
     * �\�������X�V����
     *
     * @param bo
     * @param inSession
     */
//    public void moshikomiUpd(Moshikomi bo, SmnMskJoho inSession) {
//        Date date = new Date();
//        SimpleDateFormat dt = new SimpleDateFormat("yyyyMMdd");
//        SimpleDateFormat tm = new SimpleDateFormat("HHmmss");
//        String koshinDate = dt.format(date);
//        String koshinTime = tm.format(date);
//        bo.setMoshikomiJokyoKbn("01");
//        bo.setUnyoJokyoKbn("01");
//        bo.setKoshinKbn("U");
//        bo.setKoshinDate(koshinDate);
//        bo.setKoshinTime(koshinTime);
//        bo.setKoshinUserId(inSession.getMoshikomishaId());
//    }

    /**
     * �\���ύX��o�^����
     *
     * @param bo
     * @param inSession
     */
    public void moshikomihenkoTrk(MoshikomiHenkoRireki bo, SmnMskJoho inSession) throws Exception {
        Saiban saiban = new BmaSaibanService(DATA_SOURCE_NAME).getSaibanAndUpdate(BmaConstants.SAIBAN_MOSHIKOMI_HENKOID, inSession.getMoshikomishaId());
        Date date = new Date();
        SimpleDateFormat dt = new SimpleDateFormat("yyyyMMdd");
        SimpleDateFormat tm = new SimpleDateFormat("HHmmss");
        String koshinDate = dt.format(date);
        String koshinTime = tm.format(date);
        bo.setMoshikomiHenkoRirekiIdx(saiban.getGenzaiNo());
        bo.setHenkoKbn("1");
        bo.setKoshinKbn("I");
        bo.setTorokuDate(koshinDate);
        bo.setTorokuTime(koshinTime);
        bo.setTorokuUserId(inSession.getMoshikomishaId());
        bo.setKoshinDate("");
        bo.setKoshinTime("");
        bo.setKoshinUserId("");
    }

    /**
     * �摜�����X�V����
     *
     * @param bo
     * @param inSession
     */
//    public void gazoUpd(Gazo bo, SmnMskJoho inSession) throws Exception {
//        Date date = new Date();
//        SimpleDateFormat dt = new SimpleDateFormat("yyyyMMdd");
//        SimpleDateFormat tm = new SimpleDateFormat("HHmmss");
//        String koshinDate = dt.format(date);
//        String koshinTime = tm.format(date);
//        bo.setGazoIdx(inSession.getGazo_idx());
//        bo.setHoseiIraiKbn("2");
//        bo.setGazoHyojiKbn("1");
//        bo.setKoshinKbn("U");
//        bo.setKoshinDate(koshinDate);
//        bo.setKoshinTime(koshinTime);
//        bo.setKoshinUserId(inSession.getMoshikomishaId());
//    }

    /**
     * �����u�K���X�g���擾����
     *
     * @param sknksuKbn
     * @return
     */
    public List<Option> findSknKsuList(String sknksuKbn) {
        List<Option> list = new ArrayList<>();
        //�����u�K���X�g��p�ӂ���
        SknksuMst sknksuMst = new SknksuMst(BmaConstants.DS_REGISTRANT);
        sknksuMst.findBySknKsuKbn(sknksuKbn, list);
        return list;
    }

    /**
     * �e���v���[�g�_�E�����[�h
     */
    private void excelDownload(SmnMskJoho inRequest, SmnMskJoho inSession) throws Exception {
        String sknksuName = (inRequest.getSknksuKbn().equals(BmaConstants.SKN_KBN))
                ? inRequest.getSknName() : inRequest.getKsuName();
        Saiban saiban;
        String fileName;
        //�e���v���[�g�t�@�C�����擾
        if (inRequest.getSknksuKbn().equals(BmaConstants.SKN_KBN)) {
            fileName = BmaConstants.SHOMEN_SKN + ".xlsm";
        } else {
            fileName = BmaConstants.SHOMEN_KSU + ".xlsm";
        }

        String path;
        path = BmaConstants.PHOTO_UPLOAD_PATH;
        File file = new File(path + fileName);
        //�e���v���[�g�t�@�C�����擾
        InputStream inputStream = new FileInputStream(file);

//        //���[�N�u�b�N�𐶐�
        Workbook wb = WorkbookFactory.create(inputStream);
//        //�e���v���[�g�V�[�g���R�s�[
        Sheet sheet = wb.getSheetAt(0);

        for (int i = 4; i < sheet.getLastRowNum(); i++) {
            saiban = new BmaSaibanService(DATA_SOURCE_NAME).getSaibanAndUpdate(BmaConstants.SAIBAN_NOID_UKETSUKENO_SYOMEN, inSession.getMoshikomishaId());
            String syomenNo = saiban.getGenzaiNo();
            sheet.getRow(i).getCell(2).setCellValue(syomenNo);
            sheet.getRow(i).getCell(3).setCellValue(sknksuName.substring(0, 2));
            sheet.getRow(i).getCell(4).setCellValue(sknksuName.substring(2, 4));
            sheet.getRow(i).getCell(5).setCellValue(sknksuName.substring(4, 6));
            sheet.getRow(i).getCell(6).setCellValue(inSession.getNendo());
        }

        Date date = new Date();
        SimpleDateFormat dt = new SimpleDateFormat("yyyyMMdd");
        SimpleDateFormat tm = new SimpleDateFormat("HHmmss");
        String koshinDate = dt.format(date);
        String koshinTime = tm.format(date);
        SknksuMst sknksuMst = new SknksuMst(BmaConstants.DS_REGISTRANT);
        String sknKsuNameChi = sknksuMst.findSknKsuNameRyaku(sknksuName.substring(0, 2),
                sknksuName.substring(2, 4), sknksuName.substring(4, 6)).getSknKsuNameRyaku();
        String fileNameOut = sknKsuNameChi + "_" + "���ʐ\���f�[�^" + "_" + koshinDate + koshinTime + ".xlsm";
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        wb.write(out);
        byte[] barray = out.toByteArray();
        InputStream is = new ByteArrayInputStream(barray);
        out.close();
        inRequest.setInputStream(is);
        inRequest.setHeader(path, path);
        inRequest.setHeader("Content-Type", "charset=UTF-8");
        inRequest.setHeader("Content-Disposition",
                "attachment;filename=\"" + URLEncoder.encode(fileNameOut, BmaConstants.ENCODE_UTF_8) + "\"");
        inRequest.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");

    }

    /**
     * �t�@�C����ǂݍ��݁A���f�[�^���C���T�[�g
     *
     * @param inRequest
     * @param inSession
     * @return �C���|�[�g�����̏ꍇ�Atrue
     * @throws Exception
     */
    private boolean importFile(SmnMskJoho inRequest, SmnMskJoho inSession, List<ErrorMsg> errorLog) throws IOException {
        Messages errors = new Messages();

        // �t�@�C���擾
        FileItem fItem = inRequest.getMskFileChoice();
        String line;
        int rowCount = 5;
        List<String> uketsukeNos = new ArrayList<>();

        boolean ret = false;

        if (!(fItem.isFormField())) {
            BufferedReader bufferedReader = null;
            try {
                bufferedReader = new BufferedReader(new InputStreamReader(fItem.getInputStream(), BmaConstants.ENCODE_WINDOWS_31J));
                // systemTime

                String[] lineArray;

                //�t�@�C���ŏI�s�܂ŌJ��Ԃ�
//                bufferedReader.mark(1);
                while ((line = bufferedReader.readLine()) != null) {
                    String tempStr = line;
                    //�t�@�C�����e��String�z��ɕϊ�
                    if (tempStr.endsWith("\"")) {
                        tempStr = tempStr.replaceAll("^\"|\"$", "");
                        lineArray = tempStr.split("\",\"", -1);
                        tempStr = "";
                    } else {
                        lineArray = tempStr.split(",", -1);
                        tempStr = "";
                    }
                    int length;
                    if (String.valueOf(lineArray.length).equals("38")) {
                        inSession.setCsvFlg("1");
                        length = 38;
                    } else {
                        inSession.setCsvFlg("2");
                        length = 40;
                    }
                    if (rowCount < 6) {
                        // 1���ڂ̎����u�K������Z�b�V�����ɕێ�
                        inSession.setSknKsuCode(lineArray[1]);
                        inSession.setShubetsuCode(lineArray[2]);
                        inSession.setKaisuCode(lineArray[3]);
                        inSession.setNendo(lineArray[4]);
                        if (BmaConstants.KSU_KBN.equals(inSession.getCsvFlg())) {
                            // �u�K��̏ꍇ�A�g�p��ꃊ�X�g���쐬
                            List<SmnMskJoho> kaijoList = new ArrayList<>();
                            List<SmnMskJoho> kaijoListNew = new ArrayList<>();
                            /*��ꃊ�X�g�擾*/
                            ShiyoKaijo shiyoKaijo = new ShiyoKaijo(BmaConstants.DS_REGISTRANT);
                            kaijoList = shiyoKaijo.searchKaijoList(inSession.getNendo(), inSession.getSknKsuCode(),
                                    inSession.getShubetsuCode(), inSession.getKaisuCode(), BmaConstants.KAIJO_SHIKEN_KBN_NASHI);
                            /*���X�g�̊J�Òn�擾*/
                            Map<String, List<SmnMskJoho>> Kaisaichi = kaijoList.stream().collect(
                                    Collectors.groupingBy(SmnMskJoho::getKaisaichiCode));

                            for (Map.Entry<String, List<SmnMskJoho>> entry : Kaisaichi.entrySet()) {
                                List<SmnMskJoho> listGroup = entry.getValue();
                                for (SmnMskJoho item : listGroup) {
                                    item.setCount(listGroup.size() + "");
                                    kaijoListNew.add(item);
                                }
                            }
                            inSession.setKaijoCheckList(kaijoListNew);
                        }
                    }
                    // ���ڐ��`�F�b�N
                    if (lineArray.length != length) {
                        BmaValidator.addMessage(errors, "info", BmaText.E00060, "info");
                        log.info("���ڐ��G���[�i" + rowCount + "�s�ځj");
                        inSession.setErrors(errors);
//                        rollbackTransaction();
                        return ret;
                    }
                    // �t�@�C�����ڃ`�F�b�N
                    if (!inputCheck(lineArray, errors, inSession, inRequest, errorLog, rowCount - 4)) {
                        inSession.setErrors(errors);
                        rowCount++;
                    } else {
                        rowCount++;
                    }
                }
                // �G���[����̏ꍇ�A�I��
                if (errorLog.size() > 0 && !BmaConstants.FLG_ON.equals(inSession.getFuriganaOnlyErrFlg())) {
                    Boolean checkErr = false;
                    for (ErrorMsg errorMsg : errorLog) {
                        if (!"�t���K�i�s��v".equals(errorMsg.itemName)) {
                            inSession.setErrorLogFlg(BmaConstants.FLG_ON);
                            checkErr = true;
                            break;
                        }
                    }
                    if (!checkErr) {
                        inSession.setFuriganaOnlyErrFlg(BmaConstants.FLG_ON);
                    } else {
                        inSession.setFuriganaOnlyErrFlg(BmaConstants.FLG_OFF);
                        return false;
                    }
                }
                bufferedReader.close();
                bufferedReader = new BufferedReader(new InputStreamReader(fItem.getInputStream(), BmaConstants.ENCODE_WINDOWS_31J));

                // �s���J�E���g���Z�b�g
                rowCount = 0;
                // �g�����U�N�V�����J�n
                getTransaction();
                beginTransaction();
//                bufferedReader.reset();
                // CSV �o�^
                //�t�@�C���ŏI�s�܂ŌJ��Ԃ�
                while ((line = bufferedReader.readLine()) != null) {
                    String tempStr = line;

                    //�t�@�C�����e��String�z��ɕϊ�
                    if (tempStr.endsWith("\"")) {
                        tempStr = tempStr.replaceAll("^\"|\"$", "");
                        lineArray = tempStr.split("\",\"", -1);
                        tempStr = "";
                    } else {
                        lineArray = tempStr.split(",", -1);
                        tempStr = "";
                    }
                    // CSV�f�[�^��ۑ�����
                    SmnMskJoho torokuLine = new SmnMskJoho();
                    setCSVToSession(lineArray, torokuLine, inSession);
                    if (BmaConstants.FLG_ON.equals(inSession.getFuriganaOnlyErrFlg())) {
                        // ���i���̃t���K�i�s��v�G���[�݂̂̏ꍇ�A�o�^�X�V�f�[�^���ꎞ�ޔ�
                        inSession.getCsvEvacuationList().add(torokuLine);
                    } else {
                        // �o�^�X�V����
                        csvToroku(inRequest, inSession, torokuLine);
                    }
                    rowCount++;
                    uketsukeNos.add(torokuLine.getUketsukeNo());
                }
                inSession.setUketsukeNos(uketsukeNos.toArray(new String[uketsukeNos.size()]));
                if (!inSession.getErrors().isEmpty()) {
                    inSession.setErrors(errors);
                    return false;
                }
                // �R�~�b�g
                commitTransaction();
                ret = true;

                // ���펞��ʃ��b�Z�[�W�Z�b�g
                inSession.setTorokuKanryoKensu(String.valueOf(rowCount) + "��");
                inSession.setErrors(errors);
                // ���O�o��
                log.info("��������" + String.valueOf(rowCount));
            } catch (IOException e) {
                log.error(CLASS_NAME + ".importFile()�ŗ�O����", e);
                rollbackTransaction();
            } finally {
                if (bufferedReader != null) {
                    bufferedReader.close();
                }
            }
        }
        return ret;
    }

    /**
     * ���̓f�[�^���Z�b�V�����f�[�^�ɃZ�b�g����B
     *
     * @param inRequest ���N�G�X�g��̓��̓f�[�^
     * @param inSession �Z�b�V������̓��̓f�[�^
     */
    private void setValueRequestToSession(SmnMskJoho inRequest, SmnMskJoho inSession) {
        inSession.setMskFileChoice(inRequest.getMskFileChoice());
    }

    /**
     * CSV�f�[�^���Z�b�V�����f�[�^�ɃZ�b�g����B
     *
     * @param inRequest ���N�G�X�g��̓��̓f�[�^
     * @param inSession �Z�b�V������̓��̓f�[�^
     */
    private void setCSVToSession(String[] lineArray, SmnMskJoho torokuLine, SmnMskJoho inSession) {
        MoshikomiCommonService service = new MoshikomiCommonService(DATA_SOURCE_NAME);
        String nenrei = "";
        /*trim���s*/
        String shimei = BmaStringUtility.trimSpace2(lineArray[5]);
        String furigana = BmaStringUtility.trimSpace2(lineArray[6]);
        //�S�p�ϊ����s
        shimei = BmaStringUtility.convertHankakuToZenkakuBma(shimei);
        furigana = BmaStringUtility.convertHankakuToZenkakuBma(furigana);
        String jusho1 = BmaStringUtility.convertHankakuToZenkakuBma(lineArray[11]);
        String jusho2 = BmaStringUtility.convertHankakuToZenkakuBma(lineArray[12]);
        String tatemono = BmaStringUtility.convertHankakuToZenkakuBma(lineArray[13]);
        String kinmusakiName = BmaStringUtility.convertHankakuToZenkakuBma(lineArray[17]);
        String kinmusakiJusho1 = BmaStringUtility.convertHankakuToZenkakuBma(lineArray[20]);
        String kinmusakiJusho2 = BmaStringUtility.convertHankakuToZenkakuBma(lineArray[21]);
        String kinmusakiTatemono = BmaStringUtility.convertHankakuToZenkakuBma(lineArray[22]);

        torokuLine.setShomenUketsukeNo(lineArray[0]);
        torokuLine.setSknKsuCode(lineArray[1]);
        torokuLine.setShubetsuCode(lineArray[2]);
        torokuLine.setKaisuCode(lineArray[3]);
        torokuLine.setNendo(lineArray[4]);
        torokuLine.setShimei(shimei);
        torokuLine.setFurigana(furigana);
        torokuLine.setBirthday(lineArray[7]);
        // �N��v�Z
        String birthday = lineArray[7];
        if (birthday.length() == 8) {
            try {
                nenrei = service.calcAge(lineArray[4], lineArray[1], lineArray[2], lineArray[3], lineArray[0], birthday);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        torokuLine.setNenrei(nenrei);
        torokuLine.setSex(lineArray[8]);
        torokuLine.setYubinNo(lineArray[9]);
        torokuLine.setTodofukenCode(lineArray[10]);
        torokuLine.setJusho1(jusho1);
        torokuLine.setJusho2(jusho2);
        torokuLine.setTatemono(tatemono);
        torokuLine.setTelNo(lineArray[14]);
        torokuLine.setFaxNo(lineArray[15]);
        torokuLine.setMailAddress(lineArray[16]);
        torokuLine.setKinmusakiName(kinmusakiName);
        torokuLine.setKinmusakiYubinNo(lineArray[18]);
        torokuLine.setKinmusakiTodofukenCode(lineArray[19]);
        torokuLine.setKinmusakiJusho1(kinmusakiJusho1);
        torokuLine.setKinmusakiJusho2(kinmusakiJusho2);
        torokuLine.setKinmusakiTatemono(kinmusakiTatemono);
        torokuLine.setKinmusakiTelNo(lineArray[23]);
        torokuLine.setKinmusakiFaxNo(lineArray[24]);
        torokuLine.setSofuSakiKbn(lineArray[25]);
        if (inSession.getCsvFlg().equals(BmaConstants.SKN_KBN)) {
            torokuLine.setShikenNaiyoKbn(lineArray[26]);
            torokuLine.setKiboShikenchi(lineArray[27]);
            torokuLine.setGenmenFlg(lineArray[28]);
            torokuLine.setGaijiFlg(lineArray[29]);
            torokuLine.setGaijiShosai(lineArray[30]);
            torokuLine.setHairyoFlg(lineArray[31]);
            torokuLine.setHairyoNaiyo(lineArray[32]);
            torokuLine.setNyukinBi(lineArray[33]);
            torokuLine.setNyuKinkaku(lineArray[34]);
            torokuLine.setKessaiHohoKbn(lineArray[35]);
            torokuLine.setKakuninBi(lineArray[36]);
            torokuLine.setBiko(lineArray[37]);
        } else {
            torokuLine.setDaiichiKibo(lineArray[26]);
            torokuLine.setDainiKibo(lineArray[27]);
            torokuLine.setKaijoId(inSession.getKiboKaijoId().get(torokuLine.getShomenUketsukeNo()));
            torokuLine.setKaiinFlg(lineArray[28]);
            torokuLine.setKigyoCode(lineArray[29]);
            torokuLine.setShinseiShikakuNo(lineArray[30]);
            torokuLine.setGaijiFlg(lineArray[31]);
            torokuLine.setGaijiShosai(lineArray[32]);
            torokuLine.setHairyoFlg(lineArray[33]);
            torokuLine.setHairyoNaiyo(lineArray[34]);
            torokuLine.setNyukinBi(lineArray[35]);
            torokuLine.setNyuKinkaku(lineArray[36]);
            torokuLine.setKessaiHohoKbn(lineArray[37]);
            torokuLine.setKakuninBi(lineArray[38]);
            torokuLine.setBiko(lineArray[39]);
        }

    }

    /**
     * �����������̓`�F�b�N
     *
     * @param inSession �Z�b�V����RTO
     * @return true:�G���[��
     */
    private boolean validateSearchInput(SmnMskJoho inRequest, SmnMskJoho inSession) {
        Messages errors = new Messages();

        String itemName;
        String groupCode;

        groupCode = "info";
        itemName = "�t�@�C�� ";
        String fileName = inRequest.getMskFileChoice().getName();
        if (BmaUtility.isNullOrEmpty(fileName)) {
            BmaValidator.checkNull(errors, groupCode, itemName);
        }
        if (BmaValidator.validateMessageCheck(errors, groupCode)) {
            // �����`�F�b�N
            if (!fileName.contains("���ʐ\��")) {
                BmaValidator.addMessage(errors, groupCode, "�t�@�C�����̂��s���ł�");
            }
        }
        // �g���q�i�[�ϐ�
        String ext = BmaFileUtility.getExtension(fileName);
        if (!BmaUtility.isNullOrEmpty(ext) && !"csv".equals(ext)) {
            BmaValidator.addMessage(errors, groupCode, BmaText.E00070);
        }

        inSession.setErrors(errors);
        return errors.isEmpty();
    }

    /**
     * �t�@�C���̌`���`�F�b�N
     *
     * @param inSession
     * @return �`�F�b�N�n�j�̏ꍇ�Atrue
     */
    private boolean validateImportFile(SmnMskJoho inRequest, SmnMskJoho inSession) {
        Messages errors = new Messages();

        String itemName;
        String groupCode;
        Boolean result = false;

        groupCode = "info";
        itemName = "�t�@�C���T�C�Y";
        // �t�@�C���擾
        FileItem fItem = inRequest.getMskFileChoice();

        // 0���f�[�^�̏ꍇ�G���[
        if (fItem.getSize() == 0) {
            BmaValidator.checkFileSize(errors, groupCode, itemName);
            result = false;
        } else {
            result = BmaValidator.validateFileSize(fItem.getSize(), CSV_SIZE, errors, groupCode, groupCode);
        }

        if (!result) {
            log.info("�t�@�C���T�C�Y�G���[");
            inSession.setErrors(errors);
            fItem.delete();
        }
        return result;
    }

    /**
     * �t�@�C�����̐\���ԍ�������`�F�b�N����
     *
     * @param lineArray
     * @param errors
     * @return �`�F�b�N�n�j�̏ꍇ�Atrue
     */
    private boolean inputCheck(String[] lineArray, Messages errors, SmnMskJoho inSession, SmnMskJoho inRequest, List<ErrorMsg> errorLog, long lineNo) throws IOException {
        String groupCode = "fileInputCheck";

        MeishoKanri meishoKanri = new MeishoKanri(BmaConstants.DS_REGISTRANT);
        SknksuMst sknksuMst = new SknksuMst(BmaConstants.DS_REGISTRANT);
        MoshikomiCommonService service = new MoshikomiCommonService(DATA_SOURCE_NAME);
        // �I���`�F�b�N
        List<Option> sknKsuList = new ArrayList<>();
        List<String> sknKsuCodeList = new ArrayList<>();
        List<String> shubetsuCodeList = new ArrayList<>();
        List<String> kaisuCodeList = new ArrayList<>();
        sknksuMst.findBySknKsuKbn(inSession.getCsvFlg(), sknKsuList);
        for (int i = 0; i < sknKsuList.size(); i++) {
            sknKsuCodeList.add(sknKsuList.get(i).getValue().substring(0, 2));
            if (sknKsuList.get(i).getValue().substring(0, 2).equals(lineArray[1])) {
                shubetsuCodeList.add(sknKsuList.get(i).getValue().substring(2, 4));
                kaisuCodeList.add(sknKsuList.get(i).getValue().substring(4, 6));
            }
        }

        List<Option> kaisaichiList = new ArrayList<>();
        ShiyoKaijo shiyoKaijo = new ShiyoKaijo(BmaConstants.DS_REGISTRANT);
        shiyoKaijo.setNendo(inSession.getNendo());
        shiyoKaijo.setSknKsuCode(inSession.getSknKsuCode());
        shiyoKaijo.setShubetsuCode(inSession.getShubetsuCode());
        shiyoKaijo.setKaisuCode(inSession.getKaisuCode());
        kaisaichiList = shiyoKaijo.findKiboKaisaichiList(shiyoKaijo);
        
        List<Option> todofukenList = new ArrayList<>();
        List<Option> shikennaiyoKbnList = new ArrayList<>();
        List<Option> kessaiHohoList = new ArrayList<>();
        meishoKanri.findByGroupCode("TODOFUKEN_CODE", todofukenList);
        meishoKanri.findByGroupCode("SHIKEN_NAIYO_KBN", shikennaiyoKbnList);
        meishoKanri.findByGroupCode("KESSAI_HOHO_KBN", kessaiHohoList);
        // �u�敪�Ȃ�"00"�v���Ȃ�
        shikennaiyoKbnList.remove(0);
        String[] sex = {"1", "2"};
        String[] sofukuFlg = {"1", "2"};
        String[] genmenFlg = {"0", "1"};
        String[] gaijiFlg = {"0", "1"};
        String[] hairiFlg = {"00", "01"};
        String[] kaiinFlg = {"0", "1"};

        /*trim���s*/
        String shimei = BmaStringUtility.trimSpace2(lineArray[5]);
        String furigana = BmaStringUtility.trimSpace2(lineArray[6]);
        //�S�p�ϊ����s
        shimei = BmaStringUtility.convertHankakuToZenkakuBma(shimei);
        furigana = BmaStringUtility.convertHankakuToZenkakuBma(furigana);
        String jusho1 = BmaStringUtility.convertHankakuToZenkakuBma(lineArray[11]);
        String jusho2 = BmaStringUtility.convertHankakuToZenkakuBma(lineArray[12]);
        String tatemono = BmaStringUtility.convertHankakuToZenkakuBma(lineArray[13]);
        String kinmusakiName = BmaStringUtility.convertHankakuToZenkakuBma(lineArray[17]);
        String kinmusakiJusho1 = BmaStringUtility.convertHankakuToZenkakuBma(lineArray[20]);
        String kinmusakiJusho2 = BmaStringUtility.convertHankakuToZenkakuBma(lineArray[21]);
        String kinmusakiTatemono = BmaStringUtility.convertHankakuToZenkakuBma(lineArray[22]);

        // ���ʎ�t�ԍ�
        // �K�v�`�F�b�N
        if (!BmaValidator.validateRequired(lineArray[0], errors, groupCode, "")) {
            this.createErrorLine(lineNo, 2, "���ʎ�t�ԍ�", errors, errorLog);
        } else {
            List<String> shomenNoList = inSession.getShomenNoList();
            // �����`�F�b�N
            if (!BmaValidator.validateEqualLength(lineArray[0], 10, errors, groupCode, "")) {
                this.createErrorLine(lineNo, 2, "���ʎ�t�ԍ�", errors, errorLog);
            }
            // �����R�[�h�`�F�b�N
            if (!BmaValidator.validateNumber(lineArray[0], errors, groupCode, "")) {
                this.createErrorLine(lineNo, 2, "���ʎ�t�ԍ�", errors, errorLog);
            }
            // �_�u��`�F�b�N
            if (shomenNoList.contains(lineArray[0])) {
                BmaValidator.addMessage(errors, groupCode, BmaText.E00101, "");
                this.createErrorLine(lineNo, 2, "���ʎ�t�ԍ�", errors, errorLog);
            }
            // �����ԍ��`�F�b�N
            if (errorLog.size() < 1) {
                if (shomenNoList.size() >= 1) {
                    if (Long.parseLong(lineArray[0]) - Long.parseLong(shomenNoList.get(shomenNoList.size() - 1)) != 1) {
                        BmaValidator.addMessage(errors, groupCode, BmaText.E00074, "���ʎ�t�ԍ�");
                        this.createErrorLine(lineNo, 2, "���ʎ�t�ԍ�", errors, errorLog);
                    }
                }
            }
            shomenNoList.add(lineArray[0]);
            inSession.setShomenNoList(shomenNoList);
        }
        // �����u�K��R�[�h
        // �K�v�`�F�b�N
        if (!BmaValidator.validateRequired(lineArray[1], errors, groupCode, "")) {
            this.createErrorLine(lineNo, 3, "�����u�K��R�[�h", errors, errorLog);
        } else {
            // �����`�F�b�N
            if (!BmaValidator.validateEqualLength(lineArray[1], 2, errors, groupCode, "")) {
                this.createErrorLine(lineNo, 3, "�����u�K��R�[�h", errors, errorLog);
            }
            // �I���`�F�b�N
            if (!sknKsuCodeList.contains(lineArray[1])) {
                BmaValidator.addMessage(errors, groupCode, BmaText.E00118, "");
                this.createErrorLine(lineNo, 3, "�����u�K��R�[�h", errors, errorLog);
            }
        }
        // ��ʃR�[�h
        // �K�v�`�F�b�N
        if (!BmaValidator.validateRequired(lineArray[2], errors, groupCode, "")) {
            this.createErrorLine(lineNo, 4, "��ʃR�[�h", errors, errorLog);
        } else {
            // �����`�F�b�N
            if (!BmaValidator.validateEqualLength(lineArray[2], 2, errors, groupCode, "")) {
                this.createErrorLine(lineNo, 4, "��ʃR�[�h", errors, errorLog);
            }
            // �����R�[�h�`�F�b�N
            if (!BmaValidator.validateNumber(lineArray[2], errors, groupCode, "")) {
                this.createErrorLine(lineNo, 4, "��ʃR�[�h", errors, errorLog);
            }
            // �I���`�F�b�N
            if (!shubetsuCodeList.contains(lineArray[2])) {
                BmaValidator.addMessage(errors, groupCode, BmaText.E00118, "");
                this.createErrorLine(lineNo, 4, "��ʃR�[�h", errors, errorLog);
            }
        }
        // �񐔃R�[�h
        // �K�v�`�F�b�N
        if (!BmaValidator.validateRequired(lineArray[3], errors, groupCode, "")) {
            this.createErrorLine(lineNo, 5, "�񐔃R�[�h", errors, errorLog);
        } else {
            // �����`�F�b�N
            if (!BmaValidator.validateEqualLength(lineArray[3], 2, errors, groupCode, "")) {
                this.createErrorLine(lineNo, 5, "�񐔃R�[�h", errors, errorLog);
            }
            // �����R�[�h�`�F�b�N
            if (!BmaValidator.validateNumber(lineArray[3], errors, groupCode, "")) {
                this.createErrorLine(lineNo, 5, "�񐔃R�[�h", errors, errorLog);
            }
            if (!kaisuCodeList.contains(lineArray[3])) {
                BmaValidator.addMessage(errors, groupCode, BmaText.E00118, "");
                this.createErrorLine(lineNo, 5, "�񐔃R�[�h", errors, errorLog);
            }
        }
        // �N�x
        // �K�v�`�F�b�N
        if (!BmaValidator.validateRequired(lineArray[4], errors, groupCode, "")) {
            this.createErrorLine(lineNo, 6, "�N�x", errors, errorLog);
        } else {
            // �����`�F�b�N
            if (!BmaValidator.validateEqualLength(lineArray[4], 4, errors, groupCode, "")) {
                this.createErrorLine(lineNo, 6, "�N�x", errors, errorLog);
            }
            // �����R�[�h�`�F�b�N
            if (!BmaValidator.validateNumber(lineArray[4], errors, groupCode, "")) {
                this.createErrorLine(lineNo, 6, "�N�x", errors, errorLog);
            }
            if (!lineArray[4].equals(inSession.getNendo())) {
                BmaValidator.addMessage(errors, groupCode, BmaText.E00119, "");
                this.createErrorLine(lineNo, 6, "�N�x", errors, errorLog);
            }
        }

        // ����
        // �K�v�`�F�b�N
        if (!BmaValidator.validateRequired(shimei, errors, groupCode, "")) {
            this.createErrorLine(lineNo, 7, "����", errors, errorLog);
        } else {
            // �����`�F�b�N
            if (!BmaValidator.validateMaxLength(shimei, BmaConstants.MAX_LENGTH_SHIMEI_KANJI, errors, groupCode, "")) {
                this.createErrorLine(lineNo, 7, "����", errors, errorLog);
            }
            if (!BmaValidator.validateMojiCode3(shimei, errors, groupCode, "")) {
                this.createErrorLine(lineNo, 7, "����", errors, errorLog);
            }
        }
        // �t���K�i
        // �K�v�`�F�b�N
        if (!BmaValidator.validateRequired(furigana, errors, groupCode, "")) {
            this.createErrorLine(lineNo, 8, "�t���K�i", errors, errorLog);
        } else {
            // �����`�F�b�N
            if (!BmaValidator.validateMaxLength(furigana, BmaConstants.MAX_LENGTH_SHIMEI_KANA, errors, groupCode, "")) {
                this.createErrorLine(lineNo, 8, "�t���K�i", errors, errorLog);
            }
            if (!BmaValidator.validateKatakana(furigana, errors, groupCode, "")) {
                this.createErrorLine(lineNo, 8, "�t���K�i", errors, errorLog);
            }
        }
        // ���N����
        // �K�v�`�F�b�N
        if (!BmaValidator.validateRequired(lineArray[7], errors, groupCode, "")) {
            this.createErrorLine(lineNo, 9, "���N����", errors, errorLog);
        } else {
            // �����`�F�b�N
            if (!BmaValidator.validateEqualLength(lineArray[7], 8, errors, groupCode, "")) {
                this.createErrorLine(lineNo, 9, "���N����", errors, errorLog);
            }
            // �����R�[�h�`�F�b�N
            if (!BmaValidator.validateNumber(lineArray[7], errors, groupCode, "")) {
                this.createErrorLine(lineNo, 9, "���N����", errors, errorLog);
            }
            // �N���`�F�b�N
            if (!BmaValidator.validateDate(lineArray[7], errors, groupCode, "")) {
                this.createErrorLine(lineNo, 9, "���N����", errors, errorLog);
            }
        }

        // ����
        // �K�v�`�F�b�N
        if (!BmaValidator.validateRequired(lineArray[8], errors, groupCode, "")) {
            this.createErrorLine(lineNo, 10, "����", errors, errorLog);
        } else {
            // �I���`�F�b�N
            if (!Arrays.asList(sex).contains(lineArray[8])) {
                BmaValidator.addMessage(errors, groupCode, BmaText.E00106, "");
                this.createErrorLine(lineNo, 10, "����", errors, errorLog);
            }
        }
        // ����Z���@�X�֔ԍ�
        // �K�v�`�F�b�N
        if (!BmaValidator.validateRequired(lineArray[9], errors, groupCode, "")) {
            this.createErrorLine(lineNo, 12, "����Z���@�X�֔ԍ�", errors, errorLog);
        } else {
            // �����`�F�b�N
            if (!BmaValidator.validateEqualLength(lineArray[9], BmaConstants.EQUAL_LENGTH_YUBIN_NO, errors, groupCode, "")) {
                this.createErrorLine(lineNo, 12, "����Z���@�X�֔ԍ�", errors, errorLog);
            }
            // ���l�`�F�b�N
            if (!BmaValidator.validateNumber(lineArray[9], errors, groupCode, "")) {
                this.createErrorLine(lineNo, 12, "����Z���@�X�֔ԍ�", errors, errorLog);
            }
        }
        // ����Z���@�s���{��
        // �K�v�`�F�b�N
        if (!BmaValidator.validateRequired(lineArray[10], errors, groupCode, "")) {
            this.createErrorLine(lineNo, 13, "����Z���@�s���{��", errors, errorLog);
        } else {
            if (!BmaValidator.validatePermissionSelect(lineArray[10], todofukenList, errors, groupCode, "")) {
                this.createErrorLine(lineNo, 13, "����Z���@�s���{��", errors, errorLog);
            }
        }
        // ����Z���@�Z���P
        // �K�v�`�F�b�N
        if (!BmaValidator.validateRequired(jusho1, errors, groupCode, "")) {
            this.createErrorLine(lineNo, 15, "����Z���@�Z���P", errors, errorLog);
        } else {
            // �����`�F�b�N
            if (!BmaValidator.validateMaxLength1(jusho1, BmaConstants.MAX_LENGTH_SHIKUCHOSON_NAME, errors, groupCode, "")) {
                this.createErrorLine(lineNo, 15, "����Z���@�Z���P", errors, errorLog);
            }
            if (!BmaValidator.validateMojiCode3(jusho1, errors, groupCode, "")) {
                this.createErrorLine(lineNo, 15, "����Z���@�Z���P", errors, errorLog);
            }
        }
        // ����Z���@�Z��2
        // �K�v�`�F�b�N
        if (!BmaValidator.validateRequired(jusho2, errors, groupCode, "")) {
            this.createErrorLine(lineNo, 16, "����Z���@�Z��2", errors, errorLog);
        } else {
            // �����`�F�b�N
            if (!BmaValidator.validateMaxLength1(jusho2, BmaConstants.MAX_LENGTH_SHIKUCHOSON_NAME, errors, groupCode, "")) {
                this.createErrorLine(lineNo, 16, "����Z���@�Z��2", errors, errorLog);
            }
            if (!BmaValidator.validateMojiCode3(jusho2, errors, groupCode, "")) {
                this.createErrorLine(lineNo, 16, "����Z���@�Z��2", errors, errorLog);
            }
        }
        // ����Z���@�����E�r����
        // �����`�F�b�N
        if (!BmaValidator.validateMaxLength(tatemono, BmaConstants.MAX_LENGTH_SHIKUCHOSON_NAME, errors, groupCode, "")) {
            this.createErrorLine(lineNo, 17, "����Z���@�����E�r����", errors, errorLog);
        }
        if (!BmaValidator.validateMojiCode3(tatemono, errors, groupCode, "")) {
            this.createErrorLine(lineNo, 17, "����Z���@�����E�r����", errors, errorLog);
        }
        // �d�b�ԍ�
        // �K�v�`�F�b�N
        if (!BmaValidator.validateRequired(lineArray[14], errors, groupCode, "")) {
            this.createErrorLine(lineNo, 18, "����Z���@�d�b�ԍ�", errors, errorLog);
        } else {
            // �����`�F�b�N
            if (!BmaValidator.validateMaxLength(lineArray[14], BmaConstants.MAX_LENGTH_TEL_NO, errors, groupCode, "")) {
                this.createErrorLine(lineNo, 18, "����Z���@�d�b�ԍ�", errors, errorLog);
            }
            if (!BmaValidator.validateMinLength(lineArray[14], BmaConstants.MIN_LENGTH_TEL_NO, errors, groupCode, "")) {
                this.createErrorLine(lineNo, 18, "����Z���@�d�b�ԍ�", errors, errorLog);
            }
            // �����R�[�h�`�F�b�N
            if (!BmaValidator.validateNumber(lineArray[14], errors, groupCode, "")) {
                this.createErrorLine(lineNo, 18, "����Z���@�d�b�ԍ�", errors, errorLog);
            }
        }
        // FAX�ԍ�
        // �����`�F�b�N
        if (!BmaValidator.validateMaxLength(lineArray[15], BmaConstants.MAX_LENGTH_FAX_NO, errors, groupCode, "")) {
            this.createErrorLine(lineNo, 19, "����Z���@FAX�ԍ�", errors, errorLog);
        }
        if (!BmaValidator.validateMinLength(lineArray[15], BmaConstants.MIN_LENGTH_FAX_NO, errors, groupCode, "")) {
            this.createErrorLine(lineNo, 19, "����Z���@FAX�ԍ�", errors, errorLog);
        }
        // �����R�[�h�`�F�b�N
        if (!BmaValidator.validateNumber(lineArray[15], errors, groupCode, "")) {
            this.createErrorLine(lineNo, 19, "����Z���@FAX�ԍ�", errors, errorLog);
        }
        // ���[���A�h���X
        // �����`�F�b�N
        if (!BmaValidator.validateMaxLength(lineArray[16], BmaConstants.MAX_LENGTH_MAILADDRESS, errors, groupCode, "")) {
            this.createErrorLine(lineNo, 20, "���[���A�h���X", errors, errorLog);
        }
        // ���[���`���`�F�b�N
        if (!BmaValidator.validateEmail(lineArray[16], errors, groupCode, "")) {
            this.createErrorLine(lineNo, 20, "���[���A�h���X", errors, errorLog);
        }
        //�Ζ����� 1�ł����͂�����ꍇ�A�G���[�`�F�b�N
        if (!BmaUtility.isNullOrEmpty(lineArray[17]) || !BmaUtility.isNullOrEmpty(lineArray[18]) || !BmaUtility.isNullOrEmpty(lineArray[19]) || !BmaUtility.isNullOrEmpty(lineArray[20])
                || !BmaUtility.isNullOrEmpty(lineArray[21]) || !BmaUtility.isNullOrEmpty(lineArray[22]) || !BmaUtility.isNullOrEmpty(lineArray[23]) || !BmaUtility.isNullOrEmpty(lineArray[24])) {
            // �Ζ��於
            // �K�v�`�F�b�N
            if (!BmaValidator.validateRequired(kinmusakiName, errors, groupCode, "")) {
                this.createErrorLine(lineNo, 21, "�Ζ��於", errors, errorLog);
            } else {
                // �����`�F�b�N
                if (!BmaValidator.validateMaxLength(kinmusakiName, BmaConstants.MAX_LENGTH_SHIKUCHOSON_NAME, errors, groupCode, "")) {
                    this.createErrorLine(lineNo, 21, "�Ζ��於", errors, errorLog);
                }
                if (!BmaValidator.validateMojiCode3(kinmusakiName, errors, groupCode, "")) {
                    this.createErrorLine(lineNo, 21, "�Ζ��於", errors, errorLog);
                }
            }
            // �Ζ���@�X�֔ԍ�
            // �K�v�`�F�b�N
            if (!BmaValidator.validateRequired(lineArray[18], errors, groupCode, "")) {
                this.createErrorLine(lineNo, 22, "�Ζ���@�X�֔ԍ�", errors, errorLog);
            } else {
                // �����`�F�b�N
                if (!BmaValidator.validateEqualLength(lineArray[18], BmaConstants.EQUAL_LENGTH_YUBIN_NO, errors, groupCode, "")) {
                    this.createErrorLine(lineNo, 22, "�Ζ���@�X�֔ԍ�", errors, errorLog);
                }
                // �����R�[�h�`�F�b�N
                if (!BmaValidator.validateNumber(lineArray[18], errors, groupCode, "")) {
                    this.createErrorLine(lineNo, 22, "�Ζ���@�X�֔ԍ�", errors, errorLog);
                }
            }
            // �Ζ���@�s���{��
            // �K�v�`�F�b�N
            if (!BmaValidator.validateRequired(lineArray[19], errors, groupCode, "")) {
                this.createErrorLine(lineNo, 23, "�Ζ���@�s���{��", errors, errorLog);
            } else {
                if (!BmaValidator.validatePermissionSelect(lineArray[19], todofukenList, errors, groupCode, "")) {
                    this.createErrorLine(lineNo, 23, "�Ζ���@�s���{��", errors, errorLog);
                }
            }
            // �Ζ���@�Z���P
            // �K�v�`�F�b�N
            if (!BmaValidator.validateRequired(kinmusakiJusho1, errors, groupCode, "")) {
                this.createErrorLine(lineNo, 25, "�Ζ���@�Z���P", errors, errorLog);
            } else {
                // �����`�F�b�N
                if (!BmaValidator.validateMaxLength(kinmusakiJusho1, BmaConstants.MAX_LENGTH_SHIKUCHOSON_NAME, errors, groupCode, "")) {
                    this.createErrorLine(lineNo, 25, "�Ζ���@�Z���P", errors, errorLog);
                }
                if (!BmaValidator.validateMojiCode3(kinmusakiJusho1, errors, groupCode, "")) {
                    this.createErrorLine(lineNo, 25, "�Ζ���@�Z���P", errors, errorLog);
                }
            }
            // �Ζ���@�Z���Q
            // �K�v�`�F�b�N
            if (!BmaValidator.validateRequired(kinmusakiJusho2, errors, groupCode, "")) {
                this.createErrorLine(lineNo, 26, "�Ζ���@�Z���Q", errors, errorLog);
            } else {
                // �����`�F�b�N
                if (!BmaValidator.validateMaxLength(kinmusakiJusho2, BmaConstants.MAX_LENGTH_SHIKUCHOSON_NAME, errors, groupCode, "")) {
                    this.createErrorLine(lineNo, 26, "�Ζ���@�Z���Q", errors, errorLog);
                }
                if (!BmaValidator.validateMojiCode3(kinmusakiJusho2, errors, groupCode, "")) {
                    this.createErrorLine(lineNo, 26, "�Ζ���@�Z���Q", errors, errorLog);
                }
            }
            // �Ζ���@�����E�r����
            // �����`�F�b�N
            if (!BmaValidator.validateMaxLength(kinmusakiTatemono, BmaConstants.MAX_LENGTH_SHIKUCHOSON_NAME, errors, groupCode, "")) {
                this.createErrorLine(lineNo, 27, "�Ζ���@�����E�r����", errors, errorLog);
            }
            if (!BmaValidator.validateMojiCode3(kinmusakiTatemono, errors, groupCode, "")) {
                this.createErrorLine(lineNo, 27, "�Ζ���@�����E�r����", errors, errorLog);
            }
            // �d�b�ԍ�
            // �K�v�`�F�b�N
            if (!BmaValidator.validateRequired(lineArray[23], errors, groupCode, "")) {
                this.createErrorLine(lineNo, 28, "�Ζ���@�d�b�ԍ�", errors, errorLog);
            } else {
                // �����`�F�b�N
                if (!BmaValidator.validateMaxLength(lineArray[23], BmaConstants.MAX_LENGTH_TEL_NO, errors, groupCode, "")) {
                    this.createErrorLine(lineNo, 28, "�Ζ���@�d�b�ԍ�", errors, errorLog);
                }
                if (!BmaValidator.validateMinLength(lineArray[23], BmaConstants.MIN_LENGTH_TEL_NO, errors, groupCode, "")) {
                    this.createErrorLine(lineNo, 28, "�Ζ���@�d�b�ԍ�", errors, errorLog);
                }
                if (!BmaValidator.validateNumber(lineArray[23], errors, groupCode, "")) {
                    this.createErrorLine(lineNo, 28, "�Ζ���@�d�b�ԍ�", errors, errorLog);
                }
            }
            // FAX�ԍ�
            // �����`�F�b�N
            if (!BmaValidator.validateMaxLength(lineArray[24], BmaConstants.MAX_LENGTH_FAX_NO, errors, groupCode, "")) {
                this.createErrorLine(lineNo, 29, "�Ζ���@FAX�ԍ�", errors, errorLog);
            }
            if (!BmaValidator.validateMinLength(lineArray[24], BmaConstants.MIN_LENGTH_FAX_NO, errors, groupCode, "")) {
                this.createErrorLine(lineNo, 29, "�Ζ���@FAX�ԍ�", errors, errorLog);
            }
            if (!BmaValidator.validateNumber(lineArray[24], errors, groupCode, "")) {
                this.createErrorLine(lineNo, 29, "�Ζ���@FAX�ԍ�", errors, errorLog);
            }
        }
        // ���t��敪
        // �K�v�`�F�b�N
        if (!BmaValidator.validateRequired(lineArray[25], errors, groupCode, "")) {
            this.createErrorLine(lineNo, 30, "���t��敪", errors, errorLog);
        } else {
            // �I���`�F�b�N
            if (!"BE".equals(lineArray[1]) && !"BC".equals(lineArray[1])) {
                if (!Arrays.asList(sofukuFlg).contains(lineArray[25])) {
                    BmaValidator.addMessage(errors, groupCode, BmaText.E00106, "");
                    this.createErrorLine(lineNo, 30, "���t��敪", errors, errorLog);
                }
            } else {
                if (!"1".equals(lineArray[25])) {
                    BmaValidator.addMessage(errors, groupCode, BmaText.E00106, "");
                    this.createErrorLine(lineNo, 30, "���t��敪", errors, errorLog);
                }
            }
            // ���t��Ɂu�Ζ���v��I�����Ă���ꍇ�A�Ζ���X�֔ԍ��̓��͂��Ȃ���΃G���[�i�u�K��j
            if ("2".equals(lineArray[25]) && BmaUtility.isNullOrEmpty(lineArray[18])) {
                BmaValidator.addMessage(errors, groupCode, BmaText.E00140);
                this.createErrorLine(lineNo, 30, "���t��敪", errors, errorLog);
            }
        }
        if (BmaConstants.SKN_KBN.equals(inSession.getCsvFlg())) {
            // �������e�敪
            // �K�v�`�F�b�N
            if (!BmaValidator.validateRequired(lineArray[26], errors, groupCode, "")) {
                this.createErrorLine(lineNo, 32, "�������e�敪", errors, errorLog);
            } else {
                // �����`�F�b�N
                if (!BmaValidator.validateEqualLength(lineArray[26], 2, errors, groupCode, "")) {
                    this.createErrorLine(lineNo, 32, "�������e�敪", errors, errorLog);
                }
                // �I���`�F�b�N
                if (!BmaValidator.validatePermissionSelect(lineArray[26], shikennaiyoKbnList, errors, groupCode, "")) {
                    this.createErrorLine(lineNo, 32, "�������e�敪", errors, errorLog);
                }
            }

            // ��]�����n
            // �K�v�`�F�b�N
            if (!BmaValidator.validateRequired(lineArray[27], errors, groupCode, "")) {
                this.createErrorLine(lineNo, 34, "��]�����n", errors, errorLog);
            } else {
                // �����`�F�b�N
                if (!BmaValidator.validateEqualLength(lineArray[27], 2, errors, groupCode, "")) {
                    this.createErrorLine(lineNo, 34, "��]�����n", errors, errorLog);
                }
                // �I���`�F�b�N
                if (!BmaValidator.validatePermissionSelect(lineArray[27], kaisaichiList, errors, groupCode, "")) {
                    this.createErrorLine(lineNo, 34, "��]�����n", errors, errorLog);
                }
            }

            // ���ƃt���O
            // �K�v�`�F�b�N
            if (!BmaValidator.validateRequired(lineArray[28], errors, groupCode, "")) {
                this.createErrorLine(lineNo, 36, "���ƃt���O", errors, errorLog);
            } else {
                // �I���`�F�b�N
                if (!Arrays.asList(genmenFlg).contains(lineArray[28])) {
                    BmaValidator.addMessage(errors, groupCode, BmaText.E00106, "");
                    this.createErrorLine(lineNo, 36, "���ƃt���O", errors, errorLog);
                }
                // �N��`�F�b�N
                if ((("BC".equals(lineArray[1]) && ("02".equals(lineArray[2]) || "03".equals(lineArray[2]))) || ("BE".equals(lineArray[1]) && "02".equals(lineArray[2])))
                        && ("01".equals(lineArray[26]) || "02".equals(lineArray[26]) || "05".equals(lineArray[26]))) {
                    // �N��v�Z
                    String birthday = lineArray[7];
                    String nenrei = "";
                    if (birthday.length() == 8) {
                        try {
                            nenrei = service.calcAge(lineArray[4], lineArray[1], lineArray[2], lineArray[3], lineArray[0], birthday);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                    if (!BmaUtility.isNullOrEmpty(nenrei)) {
                        if (35 <= Integer.parseInt(nenrei) && !"0".equals(lineArray[28])) {
                            BmaValidator.addMessage(errors, groupCode, "35�Έȏ�̕��͎󌟎萔�����Ƒ[�u���󂯂��܂���B");
                            this.createErrorLine(lineNo, 36, "���ƃt���O", errors, errorLog);
                        }
                    }
                } else {
                    if ("1".equals(lineArray[28])) {
                        BmaValidator.addMessage(errors, groupCode, "�󌟎萔�����Ƒ[�u���\�Ȏ������e�ł͂���܂���B");
                        this.createErrorLine(lineNo, 36, "���ƃt���O", errors, errorLog);
                    }
                }
            }
            // �O���t���O
            // �K�v�`�F�b�N
            if (!BmaValidator.validateRequired(lineArray[29], errors, groupCode, "")) {
                this.createErrorLine(lineNo, 38, "�O���t���O", errors, errorLog);
            } else {
                // �I���`�F�b�N
                if (!Arrays.asList(gaijiFlg).contains(lineArray[29])) {
                    BmaValidator.addMessage(errors, groupCode, BmaText.E00106, "");
                    this.createErrorLine(lineNo, 38, "�O���t���O", errors, errorLog);
                }
            }
            // �O���ڍ�
            if (!BmaValidator.validateMaxLength(lineArray[30], 200, errors, groupCode, "")) {
                this.createErrorLine(lineNo, 40, "�O���ڍ�", errors, errorLog);
            }
            if (!BmaValidator.validateMojiCodeForBiko(lineArray[30], errors, groupCode, "")) {
                this.createErrorLine(lineNo, 40, "�O���ڍ�", errors, errorLog);
            }
            // �z���t���O
            // �K�v�`�F�b�N
            if (!BmaValidator.validateRequired(lineArray[31], errors, groupCode, "")) {
                this.createErrorLine(lineNo, 41, "�z���t���O", errors, errorLog);
            } else {
                // �I���`�F�b�N
                if (!Arrays.asList(hairiFlg).contains(lineArray[31])) {
                    BmaValidator.addMessage(errors, groupCode, BmaText.E00106, "");
                    this.createErrorLine(lineNo, 41, "�z���t���O", errors, errorLog);
                }
            }
            if ("01".equals(lineArray[31])) {
                // �z�����e
                if (!BmaValidator.validateMaxLength(lineArray[32], BmaConstants.MAX_LENGTH_HAIRYO_NAIYO, errors, groupCode, "")) {
                    this.createErrorLine(lineNo, 43, "�z�����e", errors, errorLog);
                }
                if (!BmaValidator.validateMojiCodeForBiko(lineArray[32], errors, groupCode, "")) {
                    this.createErrorLine(lineNo, 43, "�z�����e", errors, errorLog);
                }
            }
            // ������
            if (!BmaValidator.validateRequired(lineArray[33], errors, groupCode, "")) {
                this.createErrorLine(lineNo, 44, "������", errors, errorLog);
            } else {
                // �����`�F�b�N
                if (!BmaValidator.validateEqualLength(lineArray[33], 8, errors, groupCode, "")) {
                    this.createErrorLine(lineNo, 44, "������", errors, errorLog);
                }
                if (!BmaValidator.validateDate(lineArray[33], errors, groupCode, "")) {
                    this.createErrorLine(lineNo, 44, "������", errors, errorLog);
                }
            }
            // �����z
            if (!BmaValidator.validateRequired(lineArray[34], errors, groupCode, "")) {
                this.createErrorLine(lineNo, 45, "�����z", errors, errorLog);
            } else {
                // �����`�F�b�N
                if (!BmaValidator.validateEqualLength(lineArray[34], BmaConstants.EQUAL_LENGTH_RYOKIN, errors, groupCode, "")) {
                    this.createErrorLine(lineNo, 45, "�����z", errors, errorLog);
                }
                if (!BmaValidator.validateNumber(lineArray[34], errors, groupCode, "")) {
                    this.createErrorLine(lineNo, 45, "�����z", errors, errorLog);
                }
            }
            // ���ϕ��@
            if (!BmaValidator.validateRequired(lineArray[35], errors, groupCode, "")) {
                this.createErrorLine(lineNo, 46, "���ϕ��@", errors, errorLog);
            } else {
                // �I���`�F�b�N
                if (!BmaValidator.validatePermissionSelect(lineArray[35], kessaiHohoList, errors, groupCode, "")) {
                    this.createErrorLine(lineNo, 46, "���ϕ��@", errors, errorLog);
                }
            }
            // �m�F��
//            if (!BmaValidator.validateRequired(lineArray[36], errors, groupCode, "")) {
//                this.createErrorLine(lineNo, 48, "�m�F��", errors, errorLog);
//            }
            // �����`�F�b�N
            if (!BmaValidator.validateEqualLength(lineArray[36], 8, errors, groupCode, "")) {
                this.createErrorLine(lineNo, 48, "�m�F��", errors, errorLog);
            }
            if (!BmaValidator.validateDate(lineArray[36], errors, groupCode, "")) {
                this.createErrorLine(lineNo, 48, "�m�F��", errors, errorLog);
            }
            // ���l
            // �����`�F�b�N
            if (!BmaValidator.validateMaxLength(lineArray[37], BmaConstants.MAX_LENGTH_BIKO, errors, groupCode, "")) {
                this.createErrorLine(lineNo, 49, "���l", errors, errorLog);
            }
            if (!BmaValidator.validateMojiCodeForBiko(lineArray[37], errors, groupCode, "")) {
                this.createErrorLine(lineNo, 49, "���l", errors, errorLog);
            }
        } else {
            List<SmnMskJoho> kaiMskJohoList = inSession.getKaijoCheckList();
            Map<String, String> kiboKaijoIdMap = inSession.getKiboKaijoId();
            String ret;
            int listNo1 = 0;
            int listNo2 = 0;
            int kuseiki1 = 0;
            int kuseiki2 = 0;
            String kaijocode1 = "";
            String kaijocode2 = "";
            for (int i = 0; i < kaiMskJohoList.size(); i++) {
                if (kaiMskJohoList.get(i).getKaijoId().equals(lineArray[26])) {
                    listNo1 = i;
                    kuseiki1 = Integer.parseInt(kaiMskJohoList.get(i).getKuusekiSuu()) - 1;
                    kaijocode1 = kaiMskJohoList.get(i).getKaijoCode();
                    break;
                }
            }
            for (int i = 0; i < kaiMskJohoList.size(); i++) {
                if (kaiMskJohoList.get(i).getKaijoId().equals(lineArray[27])) {
                    listNo2 = i;
                    kuseiki2 = Integer.parseInt(kaiMskJohoList.get(i).getKuusekiSuu()) - 1;
                    kaijocode2 = kaiMskJohoList.get(i).getKaijoCode();
                    break;
                }
            }
            // ���ID(����])
            // �K�v�`�F�b�N
            if (!BmaValidator.validateRequired(lineArray[26], errors, groupCode, "")) {
                this.createErrorLine(lineNo, 32, "���ID(��1��])", errors, errorLog);
            } else {
                // �����`�F�b�N
                if (!BmaValidator.validateEqualLength(lineArray[26], 2, errors, groupCode, "")) {
                    this.createErrorLine(lineNo, 32, "���ID(��1��])", errors, errorLog);
                }
                // ������`�F�b�N
                if (!BmaValidator.validateNumber(lineArray[26], errors, groupCode, "")) {
                    this.createErrorLine(lineNo, 32, "���ID(��1��])", errors, errorLog);
                } else {
                    // ���̑��݃`�F�b�N
                    if (BmaUtility.isNullOrEmpty(kaijocode1)) {
                        BmaValidator.addMessage(errors, groupCode, BmaText.E00139, "");
                        this.createErrorLine(lineNo, 32, "���ID(��1��])", errors, errorLog);
                    }
                }
                // ����]�Ƒ���]���قȂ��ꂩ�ǂ����`�F�b�N
                if (lineArray[26].equals(lineArray[27])) {
                    BmaValidator.addMessage(errors, groupCode, BmaText.E00137, "");
                    this.createErrorLine(lineNo, 32, "���ID", errors, errorLog);
                }
            }

            // ����]����
            if ((BmaUtility.isNullOrEmpty(kaijocode1) || kuseiki1 < 0) && !lineArray[26].equals(lineArray[27])) {
                // ���ID(����])
                // �K�v�`�F�b�N
                if (!BmaValidator.validateRequired(lineArray[27], errors, groupCode, "")) {
                    this.createErrorLine(lineNo, 33, "���ID(��2��])", errors, errorLog);
                } else {
                    // �����`�F�b�N
                    if (!BmaValidator.validateEqualLength(lineArray[27], 2, errors, groupCode, "")) {
                        this.createErrorLine(lineNo, 33, "���ID(��2��])", errors, errorLog);
                    }
                    // ������`�F�b�N
                    if (!BmaValidator.validateNumber(lineArray[27], errors, groupCode, "")) {
                        this.createErrorLine(lineNo, 33, "���ID(��2��])", errors, errorLog);
                    } else {
                        // ���̑��݃`�F�b�N
                        if (BmaUtility.isNullOrEmpty(kaijocode2)) {
                            BmaValidator.addMessage(errors, groupCode, BmaText.E00139, "");
                            this.createErrorLine(lineNo, 33, "���ID(��2��])", errors, errorLog);
                        }
                    }

                    // ���E���Ƃ��ɉ�ꂪ���݂��Ȃ��Ƃ��͔��肵�Ȃ�
                    if (!BmaUtility.isNullOrEmpty(kaijocode1) && !BmaUtility.isNullOrEmpty(kaijocode2)) {
                        // ����]����
                        if (BmaUtility.isNullOrEmpty(kaijocode2) || kuseiki2 < 0) {
                            BmaValidator.addMessage(errors, groupCode, BmaText.E00138, "");
                            this.createErrorLine(lineNo, 32, "���ID", errors, errorLog);
                        } else {
                            // ����]�œo�^
                            if (!BmaUtility.isNullOrEmpty(lineArray[0])) {
                                kiboKaijoIdMap.put(lineArray[0], lineArray[27]);
                                kaiMskJohoList.get(listNo2).setKuusekiSuu(String.valueOf(kuseiki2));
                            }
                        }
                    }
                }
            } else {
                // ����]�œo�^
                if (!BmaUtility.isNullOrEmpty(lineArray[0])) {
                    kiboKaijoIdMap.put(lineArray[0], lineArray[26]);
                    kaiMskJohoList.get(listNo1).setKuusekiSuu(String.valueOf(kuseiki1));
                }
            }
            inSession.setKaijoCheckList(kaiMskJohoList);
            inSession.setKiboKaijoId(kiboKaijoIdMap);

            // ����t���O
            // �K�v�`�F�b�N
            if (!BmaValidator.validateRequired(lineArray[28], errors, groupCode, "")) {
                this.createErrorLine(lineNo, 34, "����t���O", errors, errorLog);
            } else {
                // �I���`�F�b�N
                if (!Arrays.asList(kaiinFlg).contains(lineArray[28])) {
                    BmaValidator.addMessage(errors, groupCode, BmaText.E00013, "����t���O");
                    this.createErrorLine(lineNo, 34, "����t���O", errors, errorLog);
                }
            }
            // ��ƃR�[�h
            if (!BmaValidator.validateEqualLength(lineArray[29], 10, errors, groupCode, "")) {
                this.createErrorLine(lineNo, 36, "��ƃR�[�h", errors, errorLog);
            }
            if (!BmaValidator.validateNumber(lineArray[29], errors, groupCode, "")) {
                this.createErrorLine(lineNo, 36, "��ƃR�[�h", errors, errorLog);
            }
            // ���i�ԍ��i�C���ԍ��j
            if (("IP".equals(lineArray[1]) && "12".equals(lineArray[2])) || ("HC".equals(lineArray[1]) && "13".equals(lineArray[2]))) {
                // ���i�ԍ�
                if (!BmaValidator.validateMaxLength(lineArray[30], 20, errors, groupCode, "")) {
                    this.createErrorLine(lineNo, 37, "���i�ԍ��i�C���ԍ��j", errors, errorLog);
                } else {
                    HoyuShikakuMst hoyuShikakuMst = new HoyuShikakuMst(DATA_SOURCE_NAME);
                    hoyuShikakuMst = hoyuShikakuMst.getByGokakuNo(lineArray[1], lineArray[30]);
                    Map<String, HoyuShikakuMst> hoyuShikakuMstMapForUpdateBefore = inSession.getHoyuShikakuMstMapForUpdateBefore();
                    if (!BmaUtility.isNullOrEmpty(hoyuShikakuMst.getGokakuNo())) {
                        if (!hoyuShikakuMst.getBirthday().equals(lineArray[7])) {
                            BmaValidator.addMessage(errors, groupCode, BmaText.E00075, "���i�ԍ��i�C���ԍ��j");
                            this.createErrorLine(lineNo, 9, "���N����", errors, errorLog);
                        } else {
                            if (!hoyuShikakuMst.getFurigana().equals(lineArray[6])) {
                                // ���������擾
                                Torokusha torokusha = new Torokusha(DATA_SOURCE_NAME).find(hoyuShikakuMst.getMoshikomishaId());
                                if (torokusha != null && !BmaUtility.isNullOrEmpty(torokusha.getShimei())) {
                                    String torokuShimei = torokusha.getShimei();
                                    BmaValidator.addMessage(errors, groupCode, BmaText.E00141, torokuShimei, hoyuShikakuMst.getFurigana());
                                    this.createErrorLine(lineNo, 8, "�t���K�i�s��v", errors, errorLog);
                                    // ���i�ԍ���key�ɂ��ăZ�b�V�����ۑ�
                                    hoyuShikakuMstMapForUpdateBefore.put(lineArray[28], hoyuShikakuMst);
                                    inSession.setHoyuShikakuMstMapForUpdateBefore(hoyuShikakuMstMapForUpdateBefore);
                                    // ���ϕ��@�F�������T�̏ꍇ�A�����c�񐔂����邩���`�F�b�N
                                    if (BmaConstants.KESSAI_HOHO_KBN_BENEFITS.equals(lineArray[37])) {
                                        if (BmaUtility.isNullOrEmpty(hoyuShikakuMst.getMuryoZanCount()) || !CheckUtility.isNumber(hoyuShikakuMst.getMuryoZanCount()) || Integer.parseInt(hoyuShikakuMst.getMuryoZanCount()) < 1) {
                                            String errMsg = "�������T�̎c��������܂���B";
                                            BmaValidator.addMessage(errors, groupCode, errMsg, "");
                                            this.createErrorLine(lineNo, 46, "���ϕ��@", errors, errorLog);
                                        }
                                    }
                                } else {
                                    // �o�^�҃e�[�u���Ƀf�[�^�Ȃ�
                                    BmaValidator.addMessage(errors, groupCode, BmaText.E00142, "���i�ԍ��i�C���ԍ��j");
                                    this.createErrorLine(lineNo, 37, "���i�ԍ��i�C���ԍ��j", errors, errorLog);
                                }
                            } else {
                                // ���i�ԍ���key�ɂ��ăZ�b�V�����ۑ�
                                hoyuShikakuMstMapForUpdateBefore.put(lineArray[28], hoyuShikakuMst);
                                inSession.setHoyuShikakuMstMapForUpdateBefore(hoyuShikakuMstMapForUpdateBefore);
                                // ���ϕ��@�F�������T�̏ꍇ�A�����c�񐔂����邩���`�F�b�N
                                if (BmaConstants.KESSAI_HOHO_KBN_BENEFITS.equals(lineArray[37])) {
                                    if (BmaUtility.isNullOrEmpty(hoyuShikakuMst.getMuryoZanCount()) || !CheckUtility.isNumber(hoyuShikakuMst.getMuryoZanCount()) || Integer.parseInt(hoyuShikakuMst.getMuryoZanCount()) < 1) {
                                        String errMsg = "�������T�̎c��������܂���B";
                                        BmaValidator.addMessage(errors, groupCode, errMsg, "");
                                        this.createErrorLine(lineNo, 46, "���ϕ��@", errors, errorLog);
                                    }
                                }
                            }
                        }
                    } else {
                        BmaValidator.addMessage(errors, groupCode, BmaText.E00076, "�ۗL���i");
                        this.createErrorLine(lineNo, 37, "���i�ԍ��i�C���ԍ��j", errors, errorLog);
                    }
                }
            }
            // �O���t���O
            // �K�v�`�F�b�N
            if (!BmaValidator.validateRequired(lineArray[31], errors, groupCode, "")) {
                this.createErrorLine(lineNo, 38, "�O���t���O", errors, errorLog);
            } else {
                // �I���`�F�b�N
                if (!Arrays.asList(gaijiFlg).contains(lineArray[31])) {
                    BmaValidator.addMessage(errors, groupCode, BmaText.E00106, "");
                    this.createErrorLine(lineNo, 38, "�O���t���O", errors, errorLog);
                }
            }
            // �O���ڍ�
            if (!BmaValidator.validateMaxLength(lineArray[32], 200, errors, groupCode, "")) {
                this.createErrorLine(lineNo, 40, "�O���ڍ�", errors, errorLog);
            }
            if (!BmaValidator.validateMojiCodeForBiko(lineArray[32], errors, groupCode, "")) {
                this.createErrorLine(lineNo, 40, "�O���ڍ�", errors, errorLog);
            }
            // �z���t���O
            // �K�v�`�F�b�N
            if (!BmaValidator.validateRequired(lineArray[33], errors, groupCode, "")) {
                this.createErrorLine(lineNo, 41, "�z���t���O", errors, errorLog);
            } else {
                // �I���`�F�b�N
                if (!Arrays.asList(hairiFlg).contains(lineArray[33])) {
                    BmaValidator.addMessage(errors, groupCode, BmaText.E00106, "");
                    this.createErrorLine(lineNo, 41, "�z���t���O", errors, errorLog);
                }
            }
            if ("01".equals(lineArray[32])) {
                // �z�����e
                if (!BmaValidator.validateMaxLength(lineArray[34], BmaConstants.MAX_LENGTH_HAIRYO_NAIYO, errors, groupCode, "")) {
                    this.createErrorLine(lineNo, 43, "�z�����e", errors, errorLog);
                }
                if (!BmaValidator.validateMojiCodeForBiko(lineArray[34], errors, groupCode, "")) {
                    this.createErrorLine(lineNo, 43, "�z�����e", errors, errorLog);
                }
            }
            // ������
            if (!BmaValidator.validateRequired(lineArray[35], errors, groupCode, "")) {
                this.createErrorLine(lineNo, 44, "������", errors, errorLog);
            } else {
                // �����`�F�b�N
                if (!BmaValidator.validateEqualLength(lineArray[35], 8, errors, groupCode, "")) {
                    this.createErrorLine(lineNo, 44, "������", errors, errorLog);
                }
                if (!BmaValidator.validateDate(lineArray[35], errors, groupCode, "")) {
                    this.createErrorLine(lineNo, 44, "������", errors, errorLog);
                }
            }
            // �����z
            if (!BmaValidator.validateRequired(lineArray[36], errors, groupCode, "")) {
                this.createErrorLine(lineNo, 45, "�����z", errors, errorLog);
            } else {
                // �����`�F�b�N
                if (!BmaValidator.validateEqualLength(lineArray[36], BmaConstants.EQUAL_LENGTH_RYOKIN, errors, groupCode, "")) {
                    this.createErrorLine(lineNo, 45, "�����z", errors, errorLog);
                }
                if (!BmaValidator.validateNumber(lineArray[36], errors, groupCode, "")) {
                    this.createErrorLine(lineNo, 45, "�����z", errors, errorLog);
                }
            }
            // ���ϕ��@
            if (!BmaValidator.validateRequired(lineArray[37], errors, groupCode, "")) {
                this.createErrorLine(lineNo, 46, "���ϕ��@", errors, errorLog);
            } else {
                // �I���`�F�b�N
                if (!BmaValidator.validatePermissionSelect(lineArray[37], kessaiHohoList, errors, groupCode, "")) {
                    this.createErrorLine(lineNo, 46, "���ϕ��@", errors, errorLog);
                }
            }
            // �m�F��
//            if (!BmaValidator.validateRequired(lineArray[38], errors, groupCode, "")) {
//                this.createErrorLine(lineNo, 48, "�m�F��", errors, errorLog);
//            }
            // �����`�F�b�N
            if (!BmaValidator.validateEqualLength(lineArray[38], 8, errors, groupCode, "")) {
                this.createErrorLine(lineNo, 48, "�m�F��", errors, errorLog);
            }
            if (!BmaValidator.validateDate(lineArray[38], errors, groupCode, "")) {
                this.createErrorLine(lineNo, 48, "�m�F��", errors, errorLog);
            }
            // ���l
            // �����`�F�b�N
            if (!BmaValidator.validateMaxLength(lineArray[39], BmaConstants.MAX_LENGTH_BIKO, errors, groupCode, "")) {
                this.createErrorLine(lineNo, 49, "���l", errors, errorLog);
            }
            if (!BmaValidator.validateMojiCodeForBiko(lineArray[39], errors, groupCode, "")) {
                this.createErrorLine(lineNo, 49, "���l", errors, errorLog);
            }
        }

        createCsv(inRequest, inSession, errorLog);

        if (!errors.isEmpty()) {
            return false;
        } else {
            return true;
        }
    }

    /**
     * �G���[���b�Z�[�W�s��ǉ�����B
     *
     * @param lineNo
     * @param errors
     * @param columnNo
     * @param itemName
     * @param errors
     * @param errorLog
     */
    private void createErrorLine(long lineNo, long columnNo, String itemName, Messages errors, List<ErrorMsg> errorLog) {
        ErrorMsg errorMsg = new ErrorMsg();
        Date date = new Date();
        SimpleDateFormat dt = new SimpleDateFormat("yyyyMMdd");
        SimpleDateFormat tm = new SimpleDateFormat("HHmmss");
        String koshinDate = dt.format(date);
        String koshinTime = tm.format(date);
        //�w�b�_�[�ǉ�
        //���e�ǉ�    
        errorMsg.lineNo = String.valueOf(lineNo);
        errorMsg.columnNo = CellReference.convertNumToColString((int) columnNo);
        errorMsg.itemName = itemName;
        List<Message> valueList = new ArrayList<>(errors.getMessages().values());
        List<String> messages = valueList.get(valueList.size() - 1).getMessage();
        String message = messages.get(messages.size() - 1);
        errorMsg.message = message;
        errorLog.add(errorMsg);
    }

    private String createCsv(SmnMskJoho inRequest, SmnMskJoho inSession, List<ErrorMsg> errorLog) throws IOException {
        Date date = new Date();
        SimpleDateFormat dt = new SimpleDateFormat("yyyyMMdd");
        SimpleDateFormat tm = new SimpleDateFormat("HHmmss");
        String koshinDate = dt.format(date);
        String koshinTime = tm.format(date);
        SknksuMst sknksuMst = new SknksuMst(BmaConstants.DS_REGISTRANT);
        String sknKsuNameChi = sknksuMst.findSknKsuNameRyaku(inSession.getSknKsuCode(),
                inSession.getShubetsuCode(), inSession.getKaisuCode()).getSknKsuNameRyaku();
        String path = BmaConstants.PHOTO_UPLOAD_PATH;
        String fileName = sknKsuNameChi + "_" + "���ʐ\���f�[�^" + "_" + koshinDate + koshinTime + ".csv";
        // �w�b�_�[����
        inRequest.setHeader("Content-Disposition", String.format(Locale.JAPAN, "attachment; filename*=utf-8'jp'%s", URLEncoder.encode(fileName, "utf-8")));
        inRequest.setContentType("application/octet-stream;charset=" + BmaConstants.ENCODE_SHIFT_JIS);
        BufferedWriter bw = null;
        ByteArrayOutputStream outputStream = null;
        try {
            // �X�g���[������
            outputStream = new ByteArrayOutputStream();
            bw = new BufferedWriter(new OutputStreamWriter(outputStream, BmaConstants.ENCODE_SHIFT_JIS));
            for (int i = 0; i < errorLog.size(); i++) {
                if (i == 0) {
                    bw.write("�s�ԍ�");
                    bw.write(",");
                    bw.write("��ԍ�");
                    bw.write(",");
                    bw.write("���ږ�");
                    bw.write(",");
                    bw.write("�G���[���b�Z�[�W");
                    bw.write(",");
                    bw.write("\r\n");
                    bw.write(errorLog.get(i).lineNo);
                    bw.write(",");
                    bw.write(errorLog.get(i).columnNo);
                    bw.write(",");
                    bw.write(errorLog.get(i).itemName);
                    bw.write(",");
                    bw.write(errorLog.get(i).message);
                    bw.write(",");
                    bw.write("\r\n");
                } else {
                    bw.write(errorLog.get(i).lineNo);
                    bw.write(",");
                    bw.write(errorLog.get(i).columnNo);
                    bw.write(",");
                    bw.write(errorLog.get(i).itemName);
                    bw.write(",");
                    bw.write(errorLog.get(i).message);
                    bw.write(",");
                    bw.write("\r\n");
                }
            }
            bw.flush();
        } catch (Exception e) {
            log.error("CSV�o�͏����ŃG���[���������܂����B", e);
        } finally {
            if (bw != null) {
                bw.close();
            }
        }
        InputStream io = new ByteArrayInputStream(outputStream.toByteArray());
        inRequest.setInputStream(io);
        inRequest.setHeader("Content-Type", "charset=" + BmaConstants.ENCODE_SHIFT_JIS);
        inRequest.setContentType("text/csv; charset=" + BmaConstants.ENCODE_SHIFT_JIS);
        return DOWNLOAD;

    }
    // �G���[���b�Z�[�W�i�[�p

    public class ErrorMsg {

        String lineNo;
        String columnNo;
        String itemName;
        String message;
    }

    private void csvToroku(SmnMskJoho inRequest, SmnMskJoho inSession, SmnMskJoho torokuLine) {
        String sknKsuCode = torokuLine.getSknKsuCode();
        String shubetsuCode = torokuLine.getShubetsuCode();
        Moshikomi moshikomi = new Moshikomi(DATA_SOURCE_NAME);
        Moshikomi moshikomiMoto = new Moshikomi(DATA_SOURCE_NAME);
        MoshikomiHenkoRireki moshikomiHenkoRireki = new MoshikomiHenkoRireki(DATA_SOURCE_NAME);
        Torokusha torokusha = new Torokusha(DATA_SOURCE_NAME);
        Torokusha torokushaMoto = new Torokusha(DATA_SOURCE_NAME);
        MSkkMnjKanri mSkkMnjKanri = new MSkkMnjKanri(DATA_SOURCE_NAME);
        MSkkMnjKanri mSkkMnjKanriMoto = new MSkkMnjKanri(DATA_SOURCE_NAME);
        ShiyoKaijo shiyoKaijo = new ShiyoKaijo(DATA_SOURCE_NAME);
        ShiyoKaijo shiyoKaijoMoto = new ShiyoKaijo(DATA_SOURCE_NAME);
        TorokushaHenkoRireki torokushaHenkoRireki = new TorokushaHenkoRireki(DATA_SOURCE_NAME);
        Gazo gazo = new Gazo(DATA_SOURCE_NAME);
        Kessai kessai = new Kessai(DATA_SOURCE_NAME);
        Kessai kessaiMoto = new Kessai(DATA_SOURCE_NAME);
        HoyuShikakuMst hoyuShikakuMst = new HoyuShikakuMst(DATA_SOURCE_NAME);
        List<String> shomenUketsukeNo = new ArrayList<>();
        shomenUketsukeNo = moshikomi.searchShomenUketsukeNo();
        Map<String, HoyuShikakuMst> hoyuShikakuMstMapForUpdateBefore = inSession.getHoyuShikakuMstMapForUpdateBefore();
        try {
            if (!shomenUketsukeNo.contains(torokuLine.getShomenUketsukeNo())) {
                if (("IP".equals(sknKsuCode) && "12".equals(shubetsuCode)) || ("HC".equals(sknKsuCode) && "13".equals(shubetsuCode))) {
                    // �\������o�^����
                    /* �o�^���Z�b�g */
                    CSVmoshikomiTrk2(moshikomi, inSession, torokuLine);
                    /*�C���T�[�g���s*/
                    moshikomi.create();
                    torokuLine.setUketsukeNo(moshikomi.getUketsukeNo());
                    torokuLine.setMoshikomishaId(moshikomi.getMoshikomishaId());
                    // �\�����i�Ə��Ǘ���o�^����
                    /* �o�^���Z�b�g */
                    CSVskkmnjTrk2(mSkkMnjKanri, inSession, torokuLine);
                    /*�C���T�[�g���s*/
                    mSkkMnjKanri.create();
                    // �摜��o�^����
                    /* �o�^���Z�b�g */
                    CSVgazoTrk2(gazo, inSession, torokuLine);
                    /*�C���T�[�g���s*/
                    gazo.create();
                    // ���ς�o�^����
                    /* ���Ϗ��Z�b�g */
                    CSVkessaiTrk(kessai, inSession, torokuLine);
                    /*�C���T�[�g���s*/
                    kessai.create();
                    /* �X�V�ł���f�[�^�擾 */
                    torokushaMoto = torokusha.find(torokuLine.getMoshikomishaId());
                    /* �o�^�҂ɕύX�_������΍X�V���� */
                    if (torokushaMoto != null && checkTorokushaUpd(torokushaMoto, torokuLine)) {
                        // �o�^�ҕύX������o�^����
                        /* �o�^���Z�b�g */
                        BeanUtils.copyProperties(torokushaHenkoRireki, torokushaMoto);
                        CSVtorokuhenkoTrk(torokushaHenkoRireki, inSession);
                        /*�C���T�[�g���s*/
                        torokushaHenkoRireki.create();
                        // �o�^�҂��X�V����
                        BeanUtils.copyProperties(torokusha, torokushaMoto);
                        /* �X�V���Z�b�g */
                        CSVtorokushaUpd(torokusha, inSession, torokuLine);
                        /*�A�b�v�f�[�g���s*/
                        torokusha.update();
                    } else {
                        // �o�^�҂�o�^����
                        /* �o�^���Z�b�g */
                        CSVtorokushaTrk(torokusha, inSession, torokuLine);
                        /*�C���T�[�g���s*/
                        torokusha.create();
                    }
                    if (!BmaUtility.isNullOrEmpty(torokuLine.getKaijoId())) {
                        /* �X�V�ł���f�[�^�擾 */
                        shiyoKaijoMoto = shiyoKaijo.findKaijo(torokuLine.getNendo(), torokuLine.getSknKsuCode(),
                                torokuLine.getShubetsuCode(), torokuLine.getKaisuCode(), torokuLine.getKaijoId(), "0");
                        /* ���݂̂ݍX�V���� */
                        if (shiyoKaijoMoto != null) {
                            // �����X�V����
                            BeanUtils.copyProperties(shiyoKaijo, shiyoKaijoMoto);
                            /* �X�V���Z�b�g */
                            CSVshiyokaijoUpd(shiyoKaijo, inSession);
                            /*�A�b�v�f�[�g���s*/
                            shiyoKaijo.update();
                        }
                    }
                    // �ۗL���i�}�X�^���X�V����
                    BeanUtils.copyProperties(hoyuShikakuMst, hoyuShikakuMstMapForUpdateBefore.get(torokuLine.getShinseiShikakuNo()));
                    CSVhoyuShiakuMstUpd(hoyuShikakuMst, inSession, torokuLine);
                    // �\����ID�ƂƂ��ɃA�b�v�f�[�g���s
                    hoyuShikakuMst.updateWithMoshikomishaId(hoyuShikakuMst, moshikomi.getMoshikomishaId());
                } else {
                    // �\������o�^����
                    /* �o�^���Z�b�g */
                    CSVmoshikomiTrk1(moshikomi, inSession, torokuLine);
                    torokuLine.setUketsukeNo(moshikomi.getUketsukeNo());
                    torokuLine.setMoshikomishaId(moshikomi.getMoshikomishaId());
                    /*�C���T�[�g���s*/
                    moshikomi.create();
                    //��t�ԍ����Z�b�V�����ɕۑ�����
                    torokuLine.setUketsukeNo(moshikomi.getUketsukeNo());
                    // �\�����i�Ə��Ǘ���o�^����
                    /* �o�^���Z�b�g */
                    CSVskkmnjTrk1(mSkkMnjKanri, inSession, torokuLine);
                    /*�C���T�[�g���s*/
                    mSkkMnjKanri.create();
                    // �摜��o�^����
                    /* �o�^���Z�b�g */
                    CSVgazoTrk1(gazo, inSession, torokuLine);
                    /*�C���T�[�g���s*/
                    gazo.create();
                    // ���ς�o�^����
                    /* ���Ϗ��Z�b�g */
                    CSVkessaiTrk(kessai, inSession, torokuLine);
                    /*�C���T�[�g���s*/
                    kessai.create();
                    /* �X�V�ł���f�[�^�擾 */
                    torokushaMoto = torokusha.find(torokuLine.getMoshikomishaId());
                    /* �o�^�҂ɕύX�_������΍X�V���� */
                    if (torokushaMoto != null && checkTorokushaUpd(torokushaMoto, torokuLine)) {
                        // �o�^�ҕύX������o�^����
                        /* �o�^���Z�b�g */
                        BeanUtils.copyProperties(torokushaHenkoRireki, torokushaMoto);
                        CSVtorokuhenkoTrk(torokushaHenkoRireki, inSession);
                        /*�C���T�[�g���s*/
                        torokushaHenkoRireki.create();
                        // �o�^�҂��X�V����
                        BeanUtils.copyProperties(torokusha, torokushaMoto);
                        /* �X�V���Z�b�g */
                        CSVtorokushaUpd(torokusha, inSession, torokuLine);
                        /*�A�b�v�f�[�g���s*/
                        torokusha.update();
                    } else {
                        // �o�^�҂�o�^����
                        /* �o�^���Z�b�g */
                        CSVtorokushaTrk(torokusha, inSession, torokuLine);
                        /*�C���T�[�g���s*/
                        torokusha.create();
                    }
                    if (!BmaUtility.isNullOrEmpty(torokuLine.getKaijoId())) {
                        /* �X�V�ł���f�[�^�擾 */
                        shiyoKaijoMoto = shiyoKaijo.findKaijo(torokuLine.getNendo(), torokuLine.getSknKsuCode(),
                                torokuLine.getShubetsuCode(), torokuLine.getKaisuCode(), torokuLine.getKaijoId(), "0");
                        /* ���݂̂ݍX�V���� */
                        if (shiyoKaijoMoto != null) {
                            // �����X�V����
                            BeanUtils.copyProperties(shiyoKaijo, shiyoKaijoMoto);
                            /* �X�V���Z�b�g */
                            CSVshiyokaijoUpd(shiyoKaijo, inSession);
                            /*�A�b�v�f�[�g���s*/
                            shiyoKaijo.update();
                        }
                    }
                }
            } else {
                /* �X�V�ł���f�[�^�擾 */
                moshikomiMoto = moshikomi.searchMoshikomiJoho(torokuLine.getShomenUketsukeNo());
                /* �\���ɕύX�_������΍X�V���� */
                if (moshikomiMoto != null && checkMoshikomiUpd(moshikomiMoto, torokuLine)) {
                    /* �o�^���Z�b�g */
                    BeanUtils.copyProperties(moshikomiHenkoRireki, moshikomiMoto);
                    moshikomihenkoTrk(moshikomiHenkoRireki, inSession);
                    /*�C���T�[�g���s*/
                    moshikomiHenkoRireki.create();
                    // �\�������X�V����
                    BeanUtils.copyProperties(moshikomi, moshikomiMoto);
                    /* �X�V���Z�b�g */
                    CSVmoshikomiUpd(moshikomi, inSession, torokuLine);
                    /*�A�b�v�f�[�g���s*/
                    moshikomi.update();

                    /* �u�K��\���̉��ID���ύX���ꂽ�ꍇ�A�g�p�����X�V */
                    if (!moshikomiMoto.getKaijoId1().equals(torokuLine.getKaijoId())) {
                        /* �X�V�ł���f�[�^�擾 - csv�f�[�^�̉�� */
                        shiyoKaijoMoto = shiyoKaijo.findKaijo(torokuLine.getNendo(), torokuLine.getSknKsuCode(),
                                torokuLine.getShubetsuCode(), torokuLine.getKaisuCode(), torokuLine.getKaijoId(), "0");
                        /* ���݂̂ݍX�V���� */
                        if (shiyoKaijoMoto != null) {
                            // �����X�V����
                            BeanUtils.copyProperties(shiyoKaijo, shiyoKaijoMoto);
                            /* �X�V���Z�b�g */
                            CSVshiyokaijoUpd(shiyoKaijo, inSession);
                            /*�A�b�v�f�[�g���s*/
                            shiyoKaijo.update();
                        }
                        /* �X�V�ł���f�[�^�擾 - �X�V���̉�� */
                        shiyoKaijoMoto = shiyoKaijo.findKaijo(torokuLine.getNendo(), torokuLine.getSknKsuCode(),
                                torokuLine.getShubetsuCode(), torokuLine.getKaisuCode(), moshikomiMoto.getKaijoId1(), "0");
                        /* ���݂̂ݍX�V���� */
                        if (shiyoKaijoMoto != null) {
                            // �����X�V����
                            BeanUtils.copyProperties(shiyoKaijo, shiyoKaijoMoto);
                            /* �X�V���Z�b�g */
                            AddshiyokaijoUpd(shiyoKaijo, inSession);
                            /*�A�b�v�f�[�g���s*/
                            shiyoKaijo.update();
                        }

                    }
                }
                // ��t�ԍ��Ɛ\����ID��ێ�
                torokuLine.setUketsukeNo(moshikomiMoto.getUketsukeNo());
                torokuLine.setMoshikomishaId(moshikomiMoto.getMoshikomishaId());
                /* �X�V�ł���f�[�^�擾 */
                mSkkMnjKanriMoto = mSkkMnjKanri.find(torokuLine.getNendo(), torokuLine.getUketsukeNo());
                /* �\�����i�ԍ��ɕύX������΁A�\�����i�Ə��Ǘ����X�V���� */
                if (mSkkMnjKanriMoto != null && !mSkkMnjKanriMoto.getShinseiShikakuNo().equals(torokuLine.getShinseiShikakuNo())) {
                    // �\�����i�Ə��Ǘ����X�V����
                    BeanUtils.copyProperties(mSkkMnjKanri, mSkkMnjKanriMoto);
                    /* �X�V���Z�b�g */
                    CSVskkmnjUpd(mSkkMnjKanri, inSession, torokuLine);
                    /*�A�b�v�f�[�g���s*/
                    mSkkMnjKanri.update();
                }
                /* �X�V�ł���f�[�^�擾 */
                torokushaMoto = torokusha.find(torokuLine.getMoshikomishaId());
                /* �o�^�҂ɕύX�_������΍X�V���� */
                if (torokushaMoto != null && checkTorokushaUpd(torokushaMoto, torokuLine)) {
                    // �o�^�ҕύX������o�^����
                    /* �o�^���Z�b�g */
                    BeanUtils.copyProperties(torokushaHenkoRireki, torokushaMoto);
                    CSVtorokuhenkoTrk(torokushaHenkoRireki, inSession);
                    /*�C���T�[�g���s*/
                    torokushaHenkoRireki.create();
                    // �o�^�҂��X�V����
                    BeanUtils.copyProperties(torokusha, torokushaMoto);
                    /* �X�V���Z�b�g */
                    CSVtorokushaUpd(torokusha, inSession, torokuLine);
                    /*�A�b�v�f�[�g���s*/
                    torokusha.update();
                }
                /* �X�V�ł���f�[�^�擾 */
                kessaiMoto = kessai.find(torokuLine.getNendo(), torokuLine.getUketsukeNo());
                /* ���ςɕύX�_������΍X�V���� */
                if (kessaiMoto != null && checkKessaiUpd(kessaiMoto, torokuLine)) {
                    // ���ς��X�V����
                    BeanUtils.copyProperties(kessai, kessaiMoto);
                    /* �X�V���Z�b�g */
                    CSVkessaiUpd(kessai, inSession, torokuLine);
                    /*�A�b�v�f�[�g���s*/
                    kessai.update();
                }
            }
        } catch (Exception ex) {
            // ���[���o�b�N
            rollbackTransaction();
        }
    }

    /**
     * �o�^�ҕύX������o�^����
     *
     * @param bo
     * @param inSession
     */
    public void CSVtorokuhenkoTrk(TorokushaHenkoRireki bo, SmnMskJoho inSession) throws Exception {
        Saiban saiban = new BmaSaibanService(DATA_SOURCE_NAME).getSaibanAndUpdate(BmaConstants.SAIBAN_TOROKUSHA_HENKO_ID, inSession.getMoshikomishaId());
        Date date = new Date();
        SimpleDateFormat dt = new SimpleDateFormat("yyyyMMdd");
        SimpleDateFormat tm = new SimpleDateFormat("HHmmss");
        String koshinDate = dt.format(date);
        String koshinTime = tm.format(date);
        bo.setTorokushaHenkoRirekiIdx(saiban.getGenzaiNo());
        bo.setHenkoKbn("1");
        bo.setKoshinKbn("I");
        bo.setTorokuDate(koshinDate);
        bo.setTorokuTime(koshinTime);
        bo.setTorokuUserId(inSession.getMoshikomishaId());
        bo.setKoshinDate("");
        bo.setKoshinTime("");
        bo.setKoshinUserId("");
        bo.setRonriSakujoFlg("0");
    }

    /**
     * �\������o�^����
     *
     * @param bo
     * @param inSession
     * @param torokuLine csv���͒l
     */
    public void CSVmoshikomiTrk1(Moshikomi bo, SmnMskJoho inSession, SmnMskJoho torokuLine) throws Exception {
        Saiban saiban = new BmaSaibanService(DATA_SOURCE_NAME).getSaibanAndUpdate(BmaConstants.SAIBAN_TOROKUSHAID, inSession.getMoshikomishaId());
        Date date = new Date();
        SimpleDateFormat dt = new SimpleDateFormat("yyyyMMdd");
        SimpleDateFormat tm = new SimpleDateFormat("HHmmss");
        String koshinDate = dt.format(date);
        String koshinTime = tm.format(date);
        bo.setMoshikomishaId(saiban.getGenzaiNo());
        bo.setNendo(torokuLine.getNendo());
        bo.setSknKsuCode(torokuLine.getSknKsuCode());
        bo.setShubetsuCode(torokuLine.getShubetsuCode());
        bo.setKaisuCode(torokuLine.getKaisuCode());

        if (inSession.getCsvFlg().equals(BmaConstants.SKN_KBN)) {
            bo.setKiboKaisaichiCode(torokuLine.getKiboShikenchi());
            bo.setKaijoId1("");
        } else {
            bo.setKiboKaisaichiCode("");
            bo.setKaijoId1(torokuLine.getKaijoId());
        }
        bo.setKaisaichiCode1("");
        bo.setKaijoCode1("");
        bo.setKyoshitsuCode1("");
        bo.setKaijoId2("");
        bo.setKaisaichiCode2("");
        bo.setKaijoCode2("");
        bo.setKyoshitsuCode2("");
        bo.setMoshikomiKbn("2");
        bo.setKojinDantaiKbn("1");
        if (inSession.getCsvFlg().equals(BmaConstants.KSU_KBN)) {
            bo.setKaiinShinseiFlg(torokuLine.getKaiinFlg());
        } else {
            bo.setKaiinShinseiFlg("0");
        }
        bo.setMoshikomiJokyoKbn("02");
        bo.setUnyoJokyoKbn("02");
        bo.setGohiJokyoKbn("");
        bo.setShomenUketsukeNo(torokuLine.getShomenUketsukeNo());
        saiban = new BmaSaibanService(DATA_SOURCE_NAME).getSaibanAndUpdate(BmaConstants.SAIBAN_NOID_SYOMEN_UKETSUKENO, bo.getMoshikomishaId());
        bo.setUketsukeNo(saiban.getGenzaiNo());
        bo.setJukenJukoNo("");
        if (inSession.getCsvFlg().equals(BmaConstants.SKN_KBN)) {
            bo.setShikenNaiyoKbn(torokuLine.getShikenNaiyoKbn());
        } else {
            bo.setShikenNaiyoKbn("00");
        }
        bo.setSofuSakiKbn(torokuLine.getSofuSakiKbn());
        bo.setHairyoFlg(torokuLine.getHairyoFlg());
        bo.setHairyoNaiyo(torokuLine.getHairyoNaiyo());
        if (inSession.getCsvFlg().equals(BmaConstants.SKN_KBN)) {
            bo.setGenmenFlg(torokuLine.getGenmenFlg());
        } else {
            bo.setGenmenFlg("0");
        }
        bo.setNenrei(torokuLine.getNenrei());
        bo.setKariUketsukeBi(torokuLine.getKakuninBi());
        bo.setKariUketsukeTime("");
        bo.setMoshikomiTorokuDate(torokuLine.getNyukinBi());
        bo.setMoshikomiTorokuTime("");
        bo.setMoshikomiFinishBi("");
        bo.setMoshikomiFinishTime("");
        bo.setHoseiIraiKbn("1");
        bo.setKanriMemo(torokuLine.getBiko());
        bo.setKoshinKbn("I");
        bo.setTorokuDate(koshinDate);
        bo.setTorokuTime(koshinTime);
        bo.setTorokuUserId(inSession.getMoshikomishaId());
        bo.setKoshinDate("");
        bo.setKoshinTime("");
        bo.setKoshinUserId("");
        bo.setRonriSakujoFlg("0");
    }

    /**
     * �\������o�^����
     *
     * @param bo
     * @param inSession
     * @param torokuLine csv���͒l
     */
    public void CSVmoshikomiTrk2(Moshikomi bo, SmnMskJoho inSession, SmnMskJoho torokuLine) throws Exception {
        Saiban saiban = new BmaSaibanService(DATA_SOURCE_NAME).getSaibanAndUpdate(BmaConstants.SAIBAN_TOROKUSHAID, inSession.getMoshikomishaId());
        Date date = new Date();
        SimpleDateFormat dt = new SimpleDateFormat("yyyyMMdd");
        SimpleDateFormat tm = new SimpleDateFormat("HHmmss");
        String koshinDate = dt.format(date);
        String koshinTime = tm.format(date);
        bo.setMoshikomishaId(saiban.getGenzaiNo());
        bo.setNendo(torokuLine.getNendo());
        bo.setSknKsuCode(torokuLine.getSknKsuCode());
        bo.setShubetsuCode(torokuLine.getShubetsuCode());
        bo.setKaisuCode(torokuLine.getKaisuCode());
        bo.setKiboKaisaichiCode("");
        bo.setKaijoId1(torokuLine.getKaijoId());
        bo.setKaisaichiCode1("");
        bo.setKaijoCode1("");
        bo.setKyoshitsuCode1("");
        bo.setKaijoId2("");
        bo.setKaisaichiCode2("");
        bo.setKaijoCode2("");
        bo.setKyoshitsuCode2("");
        bo.setMoshikomiKbn("2");
        bo.setKojinDantaiKbn("1");
        bo.setKaiinShinseiFlg(torokuLine.getKaiinFlg());
        bo.setMoshikomiJokyoKbn("02");
        bo.setUnyoJokyoKbn("02");
        bo.setGohiJokyoKbn("");
        bo.setShomenUketsukeNo(torokuLine.getShomenUketsukeNo());
        saiban = new BmaSaibanService(DATA_SOURCE_NAME).getSaibanAndUpdate(BmaConstants.SAIBAN_NOID_SYOMEN_UKETSUKENO, inSession.getMoshikomishaId());
        bo.setUketsukeNo(saiban.getGenzaiNo());
        bo.setJukenJukoNo("");
        bo.setShikenNaiyoKbn("00");
        bo.setSofuSakiKbn(torokuLine.getSofuSakiKbn());
        bo.setHairyoFlg(torokuLine.getHairyoFlg());
        bo.setHairyoNaiyo(torokuLine.getHairyoNaiyo());
        bo.setGenmenFlg("0");
        bo.setNenrei(torokuLine.getNenrei());
        bo.setKariUketsukeBi(torokuLine.getKakuninBi());
        bo.setKariUketsukeTime("");
        bo.setMoshikomiTorokuDate(torokuLine.getNyukinBi());
        bo.setMoshikomiTorokuTime("");
        bo.setMoshikomiFinishBi("");
        bo.setMoshikomiFinishTime("");
        bo.setHoseiIraiKbn("1");
        bo.setKanriMemo(torokuLine.getBiko());
        bo.setKoshinKbn("I");
        bo.setTorokuDate(koshinDate);
        bo.setTorokuTime(koshinTime);
        bo.setTorokuUserId(inSession.getMoshikomishaId());
        bo.setKoshinDate("");
        bo.setKoshinTime("");
        bo.setKoshinUserId("");
        bo.setRonriSakujoFlg("0");
    }

    /**
     * �\�������X�V����
     *
     * @param bo
     * @param inSession
     * @param torokuLine csv���͒l
     */
    public void CSVmoshikomiUpd(Moshikomi bo, SmnMskJoho inSession, SmnMskJoho torokuLine) throws Exception {
        Date date = new Date();
        SimpleDateFormat dt = new SimpleDateFormat("yyyyMMdd");
        SimpleDateFormat tm = new SimpleDateFormat("HHmmss");
        String koshinDate = dt.format(date);
        String koshinTime = tm.format(date);
//        bo.setSknKsuCode(torokuLine.getSknKsuCode());
//        bo.setShubetsuCode(torokuLine.getShubetsuCode());
        if (inSession.getCsvFlg().equals(BmaConstants.SKN_KBN)) {
            bo.setKiboKaisaichiCode(torokuLine.getKiboShikenchi());
            bo.setKaijoId1("");
        } else {
            bo.setKiboKaisaichiCode("");
            bo.setKaijoId1(torokuLine.getKaijoId());
        }
        if (inSession.getCsvFlg().equals(BmaConstants.KSU_KBN)) {
            bo.setKaiinShinseiFlg(torokuLine.getKaiinFlg());
        }
        if (inSession.getCsvFlg().equals(BmaConstants.SKN_KBN)) {
            bo.setShikenNaiyoKbn(torokuLine.getShikenNaiyoKbn());
        }
        bo.setSofuSakiKbn(torokuLine.getSofuSakiKbn());
        bo.setHairyoFlg(torokuLine.getHairyoFlg());
        bo.setHairyoNaiyo(torokuLine.getHairyoNaiyo());
        if (inSession.getCsvFlg().equals(BmaConstants.SKN_KBN)) {
            bo.setGenmenFlg(torokuLine.getGenmenFlg());
        }
        bo.setNenrei(torokuLine.getNenrei());
        bo.setKariUketsukeBi(torokuLine.getKakuninBi());
        bo.setMoshikomiTorokuDate(torokuLine.getNyukinBi());
        bo.setKanriMemo(torokuLine.getBiko());
        bo.setKoshinKbn("U");
        bo.setKoshinDate(koshinDate);
        bo.setKoshinTime(koshinTime);
        bo.setKoshinUserId(inSession.getMoshikomishaId());
        bo.setRonriSakujoFlg("0");
    }

    /**
     * �摜����o�^����
     *
     * @param bo
     * @param inSession
     * @param torokuLine csv���͒l
     */
    public void CSVgazoTrk1(Gazo bo, SmnMskJoho inSession, SmnMskJoho torokuLine) throws Exception {
        Date date = new Date();
        SimpleDateFormat dt = new SimpleDateFormat("yyyyMMdd");
        SimpleDateFormat tm = new SimpleDateFormat("HHmmss");
        String koshinDate = dt.format(date);
        String koshinTime = tm.format(date);
        bo.setGazoIdx("");
        bo.setNendo(torokuLine.getNendo());
        bo.setUketsukeNo(torokuLine.getUketsukeNo());
        bo.setGazoKbn("00");
        bo.setSeq("01");
        bo.setHoseiIraiKbn("1");
        bo.setGazoHyojiKbn("4");
        bo.setHoseiIraiBi("");
        bo.setHoseiIraiTime("");
        bo.setHoseiIraiCode1("");
        bo.setHoseiIraiCode2("");
        bo.setHoseiIraiCode3("");
        bo.setHoseiTaioBi("");
        bo.setHoseiTaioTime("");
        bo.setHoseiFinishBi("");
        bo.setHoseiFinishTime("");
        bo.setHoseiIraiMailSoshinFlg("0");
        bo.setHoseiKigenBi("");
        bo.setKoshinKbn("I");
        bo.setTorokuDate(koshinDate);
        bo.setTorokuTime(koshinTime);
        bo.setTorokuUserId(inSession.getMoshikomishaId());
        bo.setKoshinDate("");
        bo.setKoshinTime("");
        bo.setKoshinUserId("");
        bo.setRonriSakujoFlg("0");
    }

    /**
     * �摜����o�^����
     *
     * @param bo
     * @param inSession
     * @param torokuLine csv���͒l
     */
    public void CSVgazoTrk2(Gazo bo, SmnMskJoho inSession, SmnMskJoho torokuLine) throws Exception {
        Date date = new Date();
        SimpleDateFormat dt = new SimpleDateFormat("yyyyMMdd");
        SimpleDateFormat tm = new SimpleDateFormat("HHmmss");
        String koshinDate = dt.format(date);
        String koshinTime = tm.format(date);
        bo.setGazoIdx("");
        bo.setNendo(torokuLine.getNendo());
        bo.setUketsukeNo(torokuLine.getUketsukeNo());
        bo.setGazoKbn("00");
        bo.setSeq("01");
        bo.setHoseiIraiKbn("1");
        bo.setGazoHyojiKbn("4");
        bo.setHoseiIraiBi("");
        bo.setHoseiIraiTime("");
        bo.setHoseiIraiCode1("");
        bo.setHoseiIraiCode2("");
        bo.setHoseiIraiCode3("");
        bo.setHoseiTaioBi("");
        bo.setHoseiTaioTime("");
        bo.setHoseiFinishBi("");
        bo.setHoseiFinishTime("");
        bo.setHoseiIraiMailSoshinFlg("0");
        bo.setHoseiKigenBi("");
        bo.setKoshinKbn("I");
        bo.setTorokuDate(koshinDate);
        bo.setTorokuTime(koshinTime);
        bo.setTorokuUserId(inSession.getMoshikomishaId());
        bo.setKoshinDate("");
        bo.setKoshinTime("");
        bo.setKoshinUserId("");
        bo.setRonriSakujoFlg("0");
    }

    /**
     * �\���Ə��Ǘ���o�^����
     *
     * @param bo
     * @param inSession
     * @param torokuLine csv���͒l
     */
    public void CSVskkmnjTrk1(MSkkMnjKanri bo, SmnMskJoho inSession, SmnMskJoho torokuLine) throws Exception {
        Date date = new Date();
        SimpleDateFormat dt = new SimpleDateFormat("yyyyMMdd");
        SimpleDateFormat tm = new SimpleDateFormat("HHmmss");
        String koshinDate = dt.format(date);
        String koshinTime = tm.format(date);
        bo.setNendo(torokuLine.getNendo());
        bo.setUketsukeNo(torokuLine.getUketsukeNo());
        bo.setShikakuCode("");
        bo.setShinseiShikakuNo("");
        bo.setMenjoCode("");
        bo.setShinseiMenjoNo("");
        bo.setKoshinKbn("I");
        bo.setTorokuDate(koshinDate);
        bo.setTorokuTime(koshinTime);
        bo.setTorokuUserId(inSession.getMoshikomishaId());
        bo.setKoshinDate("");
        bo.setKoshinTime("");
        bo.setKoshinUserId("");
        bo.setRonriSakujoFlg("0");
    }

    /**
     * �\���Ə��Ǘ���o�^����
     *
     * @param bo
     * @param inSession
     * @param torokuLine csv���͒l
     */
    public void CSVskkmnjTrk2(MSkkMnjKanri bo, SmnMskJoho inSession, SmnMskJoho torokuLine) throws Exception {
        Date date = new Date();
        SimpleDateFormat dt = new SimpleDateFormat("yyyyMMdd");
        SimpleDateFormat tm = new SimpleDateFormat("HHmmss");
        String koshinDate = dt.format(date);
        String koshinTime = tm.format(date);
        bo.setNendo(torokuLine.getNendo());
        bo.setUketsukeNo(torokuLine.getUketsukeNo());
        bo.setShikakuCode("0000");
        bo.setShinseiShikakuNo(torokuLine.getShinseiShikakuNo());
        bo.setMenjoCode("");
        bo.setShinseiMenjoNo("");
        bo.setKoshinKbn("I");
        bo.setTorokuDate(koshinDate);
        bo.setTorokuTime(koshinTime);
        bo.setTorokuUserId(inSession.getMoshikomishaId());
        bo.setKoshinDate("");
        bo.setKoshinTime("");
        bo.setKoshinUserId("");
        bo.setRonriSakujoFlg("0");
    }

    /**
     * �\���Ə��Ǘ����X�V����
     *
     * @param bo
     * @param inSession
     * @param torokuLine csv���͒l
     */
    public void CSVskkmnjUpd(MSkkMnjKanri bo, SmnMskJoho inSession, SmnMskJoho torokuLine) throws Exception {
        Date date = new Date();
        SimpleDateFormat dt = new SimpleDateFormat("yyyyMMdd");
        SimpleDateFormat tm = new SimpleDateFormat("HHmmss");
        String koshinDate = dt.format(date);
        String koshinTime = tm.format(date);
//        bo.setShikakuCode(torokuLine.getShikakuCode());
        bo.setShinseiShikakuNo(torokuLine.getShinseiShikakuNo());
        bo.setKoshinKbn("U");
        bo.setKoshinDate(koshinDate);
        bo.setKoshinTime(koshinTime);
        bo.setKoshinUserId(inSession.getMoshikomishaId());
        bo.setRonriSakujoFlg("0");
    }

    /**
     * ���ς�o�^����
     *
     * @param bo
     * @param inSession
     * @param torokuLine csv���͒l
     */
    public void CSVkessaiTrk(Kessai bo, SmnMskJoho inSession, SmnMskJoho torokuLine) throws Exception {
        Date date = new Date();
        SimpleDateFormat dt = new SimpleDateFormat("yyyyMMdd");
        SimpleDateFormat tm = new SimpleDateFormat("HHmmss");
        String koshinDate = dt.format(date);
        String koshinTime = tm.format(date);
        bo.setNendo(torokuLine.getNendo());
        bo.setUketsukeNo(torokuLine.getUketsukeNo());
        if (!BmaUtility.isNullOrEmpty(torokuLine.getKakuninBi())) {
            bo.setKessaiJokyoKbn("1");
        } else {
            bo.setKessaiJokyoKbn("2");
        }
        bo.setKessaiHohoKbn(torokuLine.getKessaiHohoKbn());
        bo.setIpCode("");
        bo.setTorihikiCode("");
        bo.setKessaiConvenienceShubetsu("");
        bo.setKessaiConvenienceHaraikomiNo("");
        bo.setKessaiShunoKikanNo("");
        bo.setKessaiOkyakusamaNo("");
        bo.setKessaiKakuninNo("");
        bo.setKessaiHaraikomihyoUrl("");
        bo.setNyukinBi(torokuLine.getNyukinBi());
        bo.setNyukinTime("");
        bo.setKessaiKigenBi("");
        bo.setKessaiKingaku(torokuLine.getNyuKinkaku());
        bo.setKessaiTesuryo("");
        bo.setKessaiKingakuTotal(torokuLine.getNyuKinkaku());
        bo.setKessaiTokusokuMailSoshinFlg("0");
        bo.setKoshinKbn("I");
        bo.setTorokuDate(koshinDate);
        bo.setTorokuTime(koshinTime);
        bo.setTorokuUserId(inSession.getMoshikomishaId());
        bo.setKoshinDate("");
        bo.setKoshinTime("");
        bo.setKoshinUserId("");
        bo.setRonriSakujoFlg("0");
    }

    /**
     * �o�^�҂�o�^����
     *
     * @param bo
     * @param inSession
     * @param torokuLine csv���͒l
     */
    public void CSVtorokushaTrk(Torokusha bo, SmnMskJoho inSession, SmnMskJoho torokuLine) throws Exception {
//                Saiban saiban = new BmaSaibanService(DATA_SOURCE_NAME).getSaibanAndUpdate(BmaConstants.SAIBAN_TOROKUSHAID, inSession.getMoshikomishaId());
        Date date = new Date();
        SimpleDateFormat dt = new SimpleDateFormat("yyyyMMdd");
        SimpleDateFormat tm = new SimpleDateFormat("HHmmss");
        String koshinDate = dt.format(date);
        String koshinTime = tm.format(date);
        bo.setMoshikomishaId(torokuLine.getMoshikomishaId());
        bo.setKaiinId("");
        bo.setKaiinKbn("");
        bo.setLoginKbn("02");
        bo.setKengenKbn("00");
        bo.setShimei(torokuLine.getShimei());
        bo.setFurigana(torokuLine.getFurigana());
        bo.setBirthday(torokuLine.getBirthday());
        bo.setSex(torokuLine.getSex());
        bo.setYubinNo(torokuLine.getYubinNo());
        bo.setTodofukenCode(torokuLine.getTodofukenCode());
        bo.setJusho1(torokuLine.getJusho1());
        bo.setJusho2(torokuLine.getJusho2());
        bo.setTatemono(torokuLine.getTatemono());
        bo.setTelNo(torokuLine.getTelNo());
        bo.setFaxNo(torokuLine.getFaxNo());
        bo.setMailAddress(torokuLine.getMailAddress());
        bo.setKuniId("");
        bo.setKunimeiJpn("");
        bo.setKunimeiEng("");
        bo.setZairyuCardNo("");
        bo.setKinmusakiName(torokuLine.getKinmusakiName());
        bo.setKinmusakiYubinNo(torokuLine.getKinmusakiYubinNo());
        bo.setKinmusakiTodofukenCode(torokuLine.getKinmusakiTodofukenCode());
        bo.setKinmusakiJusho1(torokuLine.getKinmusakiJusho1());
        bo.setKinmusakiJusho2(torokuLine.getKinmusakiJusho2());
        bo.setKinmusakiTatemono(torokuLine.getKinmusakiTatemono());
        bo.setKinmusakiTelNo(torokuLine.getKinmusakiTelNo());
        bo.setKinmusakiFaxNo(torokuLine.getKinmusakiFaxNo());
        bo.setKigyoCode(torokuLine.getKigyoCode());
        bo.setKigyoHpUrl("");
        bo.setKyokaiName("");
        bo.setGaijiFlg(torokuLine.getGaijiFlg());
        bo.setGaijiShosai(torokuLine.getGaijiShosai());
        bo.setKekkakuFlg("0");
        bo.setBiko("");
        bo.setKoshinKbn("I");
        bo.setTorokuDate(koshinDate);
        bo.setTorokuTime(koshinTime);
        bo.setTorokuUserId(inSession.getMoshikomishaId());
        bo.setKoshinDate("");
        bo.setKoshinTime("");
        bo.setKoshinUserId("");
        bo.setRonriSakujoFlg("0");
    }

    /**
     * �g�p�����X�V����i���ݐl��+1�j
     *
     * @param bo
     * @param inSession
     */
    public void CSVshiyokaijoUpd(ShiyoKaijo bo, SmnMskJoho inSession) throws Exception {
        Date date = new Date();
        int genzaiNinzu = 0;
        SimpleDateFormat dt = new SimpleDateFormat("yyyyMMdd");
        SimpleDateFormat tm = new SimpleDateFormat("HHmmss");
        String koshinDate = dt.format(date);
        String koshinTime = tm.format(date);
//        bo.setNendo(inSession.getNendo());
        genzaiNinzu = Integer.parseInt(bo.getGenzaiNinzu());
        bo.setGenzaiNinzu(String.valueOf(genzaiNinzu + 1));
        bo.setKoshinKbn("U");
        bo.setKoshinDate(koshinDate);
        bo.setKoshinTime(koshinTime);
        bo.setKoshinUserId(inSession.getMoshikomishaId());
        bo.setRonriSakujoFlg("0");
    }

    /**
     * �g�p�����X�V����i���ݐl��-1�j
     *
     * @param bo
     * @param inSession
     */
    public void AddshiyokaijoUpd(ShiyoKaijo bo, SmnMskJoho inSession) throws Exception {
        Date date = new Date();
        int genzaiNinzu = 0;
        SimpleDateFormat dt = new SimpleDateFormat("yyyyMMdd");
        SimpleDateFormat tm = new SimpleDateFormat("HHmmss");
        String koshinDate = dt.format(date);
        String koshinTime = tm.format(date);
//        bo.setNendo(inSession.getNendo());
        genzaiNinzu = Integer.parseInt(bo.getGenzaiNinzu());
        bo.setGenzaiNinzu(String.valueOf(genzaiNinzu - 1));
        bo.setKoshinKbn("U");
        bo.setKoshinDate(koshinDate);
        bo.setKoshinTime(koshinTime);
        bo.setKoshinUserId(inSession.getMoshikomishaId());
        bo.setRonriSakujoFlg("0");
    }

    /**
     * �o�^�ҕύX�������X�V����
     *
     * @param bo
     * @param inSession
     */
    public void CSVtorokushahenkouUpd(TorokushaHenkoRireki bo, SmnMskJoho inSession) throws Exception {
        Date date = new Date();
        SimpleDateFormat dt = new SimpleDateFormat("yyyyMMdd");
        SimpleDateFormat tm = new SimpleDateFormat("HHmmss");
        String koshinDate = dt.format(date);
        String koshinTime = tm.format(date);
        bo.setHenkoKbn("1");
        bo.setKoshinKbn("I");
        bo.setKoshinDate(koshinDate);
        bo.setKoshinTime(koshinTime);
        bo.setKoshinUserId(inSession.getMoshikomishaId());
    }

    /**
     * �o�^�ҕύX������o�^����
     *
     * @param bo
     * @param inSession
     */
    public void CSVtorokushahenkouTrk(TorokushaHenkoRireki bo, SmnMskJoho inSession) throws Exception {
        Saiban saiban = new BmaSaibanService(DATA_SOURCE_NAME).getSaibanAndUpdate(BmaConstants.SAIBAN_TOROKUSHA_HENKO_ID, inSession.getMoshikomishaId());
        Date date = new Date();
        SimpleDateFormat dt = new SimpleDateFormat("yyyyMMdd");
        SimpleDateFormat tm = new SimpleDateFormat("HHmmss");
        String koshinDate = dt.format(date);
        String koshinTime = tm.format(date);
        bo.setTorokushaHenkoRirekiIdx(saiban.getGenzaiNo());
        bo.setHenkoKbn("1");
        bo.setKoshinKbn("I");
        bo.setTorokuDate(koshinDate);
        bo.setTorokuTime(koshinTime);
        bo.setTorokuUserId(inSession.getMoshikomishaId());
    }

    /**
     * �o�^�҂��X�V����
     *
     * @param bo
     * @param inSession
     * @param torokuLine csv���͒l
     */
    public void CSVtorokushaUpd(Torokusha bo, SmnMskJoho inSession, SmnMskJoho torokuLine) throws Exception {
        Date date = new Date();
        SimpleDateFormat dt = new SimpleDateFormat("yyyyMMdd");
        SimpleDateFormat tm = new SimpleDateFormat("HHmmss");
        String koshinDate = dt.format(date);
        String koshinTime = tm.format(date);
        bo.setShimei(torokuLine.getShimei());
        bo.setFurigana(torokuLine.getFurigana());
        bo.setBirthday(torokuLine.getBirthday());
        bo.setSex(torokuLine.getSex());
        bo.setYubinNo(torokuLine.getYubinNo());
        bo.setTodofukenCode(torokuLine.getTodofukenCode());
        bo.setJusho1(torokuLine.getJusho1());
        bo.setJusho2(torokuLine.getJusho2());
        bo.setTatemono(torokuLine.getTatemono());
        bo.setTelNo(torokuLine.getTelNo());
        bo.setFaxNo(torokuLine.getFaxNo());
        bo.setMailAddress(torokuLine.getMailAddress());
        bo.setKinmusakiName(torokuLine.getKinmusakiName());
        bo.setKinmusakiYubinNo(torokuLine.getKinmusakiYubinNo());
        bo.setKinmusakiTodofukenCode(torokuLine.getKinmusakiTodofukenCode());
        bo.setKinmusakiJusho1(torokuLine.getKinmusakiJusho1());
        bo.setKinmusakiJusho2(torokuLine.getKinmusakiJusho2());
        bo.setKinmusakiTatemono(torokuLine.getKinmusakiTatemono());
        bo.setKinmusakiTelNo(torokuLine.getKinmusakiTelNo());
        bo.setKinmusakiFaxNo(torokuLine.getKinmusakiFaxNo());
        bo.setKoshinKbn("U");
        bo.setKoshinDate(koshinDate);
        bo.setKoshinTime(koshinTime);
        bo.setKoshinUserId(inSession.getMoshikomishaId());
    }

    /**
     * ���ς��X�V����
     *
     * @param bo
     * @param inSession
     * @param torokuLine csv���͒l
     */
    public void CSVkessaiUpd(Kessai bo, SmnMskJoho inSession, SmnMskJoho torokuLine) throws Exception {
        Date date = new Date();
        SimpleDateFormat dt = new SimpleDateFormat("yyyyMMdd");
        SimpleDateFormat tm = new SimpleDateFormat("HHmmss");
        String koshinDate = dt.format(date);
        String koshinTime = tm.format(date);
        if (!BmaUtility.isNullOrEmpty(torokuLine.getKakuninBi())) {
            bo.setKessaiJokyoKbn("1");
        } else {
            bo.setKessaiJokyoKbn("2");
        }
        bo.setKessaiHohoKbn(torokuLine.getKessaiHohoKbn());
        bo.setNyukinBi(torokuLine.getNyukinBi());
        bo.setKessaiKingaku(torokuLine.getNyuKinkaku());
        bo.setKessaiKingakuTotal(torokuLine.getNyuKinkaku());
        bo.setKoshinKbn("U");
        bo.setKoshinDate(koshinDate);
        bo.setKoshinTime(koshinTime);
        bo.setKoshinUserId(inSession.getMoshikomishaId());
        bo.setRonriSakujoFlg("0");
    }

    /**
     * �\���f�[�^�̕ύX�L���`�F�b�N
     *
     * @param bo DB�o�^�l
     * @param torokuLine csv���͒l
     * @return �ύX�L:true, �ύX��:false
     */
    public Boolean checkMoshikomiUpd(Moshikomi bo, SmnMskJoho torokuLine) throws Exception {
        MoshikomiCommonService service = new MoshikomiCommonService(DATA_SOURCE_NAME);
        Boolean result = false;
        String kiboKaisaichi = "";
        String kaijoId = "";
        String kaiinFlg = "0";
        String shikenNaiyoKbn = "00";
        String genmenFlg = "0";
        String nenrei = "";

        if (!BmaUtility.isNullOrEmpty(torokuLine.getKiboShikenchi())) {
            kiboKaisaichi = torokuLine.getKiboShikenchi();
        }
        if (!BmaUtility.isNullOrEmpty(torokuLine.getKaijoId())) {
            kaijoId = torokuLine.getKaijoId();
        }
        if (!BmaUtility.isNullOrEmpty(torokuLine.getKaiinFlg())) {
            kaiinFlg = torokuLine.getKaiinFlg();
        }
        if (!BmaUtility.isNullOrEmpty(torokuLine.getShikenNaiyoKbn())) {
            shikenNaiyoKbn = torokuLine.getShikenNaiyoKbn();
        }
        if (!BmaUtility.isNullOrEmpty(torokuLine.getGenmenFlg())) {
            genmenFlg = torokuLine.getGenmenFlg();
        }
        if (torokuLine.getBirthday().length() == 8) {
            try {
                nenrei = service.calcAge(torokuLine.getNendo(), torokuLine.getSknKsuCode(), torokuLine.getShubetsuCode(), torokuLine.getKaisuCode(), torokuLine.getShomenUketsukeNo(), torokuLine.getBirthday());
            } catch (Exception e) {
                e.printStackTrace();
                result = false;
            }
        }
        // �ЂƂł��Ⴆ�΍X�V������
        if (!bo.getKiboKaisaichiCode().equals(kiboKaisaichi)
                || !bo.getKaijoId1().equals(kaijoId)
                || !bo.getKaiinShinseiFlg().equals(kaiinFlg)
                || !bo.getShikenNaiyoKbn().equals(shikenNaiyoKbn)
                || !bo.getSofuSakiKbn().equals(torokuLine.getSofuSakiKbn())
                || !bo.getHairyoFlg().equals(torokuLine.getHairyoFlg())
                || !bo.getHairyoNaiyo().equals(torokuLine.getHairyoNaiyo())
                || !bo.getGenmenFlg().equals(genmenFlg)
                || !bo.getNenrei().equals(nenrei)
                || !bo.getKariUketsukeBi().equals(torokuLine.getKakuninBi())
                || !bo.getMoshikomiTorokuDate().equals(torokuLine.getNyukinBi())
                || !bo.getKanriMemo().equals(torokuLine.getBiko())) {
            result = true;
        } else {
            result = false;
        }
        return result;
    }

    /**
     * �o�^�҃f�[�^�̕ύX�L���`�F�b�N
     *
     * @param bo DB�o�^�l
     * @param torokuLine csv���͒l
     * @return �ύX�L:true, �ύX��:false
     */
    public Boolean checkTorokushaUpd(Torokusha bo, SmnMskJoho torokuLine) throws Exception {
        Boolean result = false;
        // �ЂƂł��Ⴆ�΍X�V������
        if (!bo.getShimei().equals(torokuLine.getShimei())
                || !bo.getFurigana().equals(torokuLine.getFurigana())
                || !bo.getBirthday().equals(torokuLine.getBirthday())
                || !bo.getSex().equals(torokuLine.getSex())
                || !bo.getYubinNo().equals(torokuLine.getYubinNo())
                || !bo.getJusho1().equals(torokuLine.getJusho1())
                || !bo.getJusho2().equals(torokuLine.getJusho2())
                || !bo.getTatemono().equals(torokuLine.getTatemono())
                || !bo.getTelNo().equals(torokuLine.getTelNo())
                || !bo.getFaxNo().equals(torokuLine.getFaxNo())
                || !bo.getMailAddress().equals(torokuLine.getMailAddress())
                || !bo.getKinmusakiName().equals(torokuLine.getKinmusakiName())
                || !bo.getKinmusakiYubinNo().equals(torokuLine.getKinmusakiYubinNo())
                || !bo.getKinmusakiJusho1().equals(torokuLine.getKinmusakiJusho1())
                || !bo.getKinmusakiJusho2().equals(torokuLine.getKinmusakiJusho2())
                || !bo.getKinmusakiTatemono().equals(torokuLine.getKinmusakiTatemono())
                || !bo.getKinmusakiTelNo().equals(torokuLine.getKinmusakiTelNo())
                || !bo.getKinmusakiFaxNo().equals(torokuLine.getKinmusakiFaxNo())
                || !bo.getKigyoCode().equals(torokuLine.getKigyoCode())
                || !bo.getGaijiFlg().equals(torokuLine.getGaijiFlg())
                || !bo.getGaijiShosai().equals(torokuLine.getGaijiShosai())) {
            result = true;
        } else {
            result = false;
        }
        return result;
    }

    /**
     * ���σf�[�^�̕ύX�L���`�F�b�N
     *
     * @param bo DB�o�^�l
     * @param torokuLine csv���͒l
     * @return �ύX�L:true, �ύX��:false
     */
    public Boolean checkKessaiUpd(Kessai bo, SmnMskJoho torokuLine) throws Exception {
        Boolean result = false;
        String kessaiJokyoKbn = "2";

        if (!BmaUtility.isNullOrEmpty(torokuLine.getKakuninBi())) {
            kessaiJokyoKbn = "1";
        }
        // �ЂƂł��Ⴆ�΍X�V������
        if (!bo.getKessaiJokyoKbn().equals(kessaiJokyoKbn)
                || !bo.getKessaiHohoKbn().equals(torokuLine.getKessaiHohoKbn())
                || !bo.getNyukinBi().equals(torokuLine.getNyukinBi())
                || !bo.getKessaiKingaku().equals(torokuLine.getNyuKinkaku())) {
            result = true;
        } else {
            result = false;
        }
        return result;
    }

    /**
     * �ۗL���i�}�X�^���X�V����i�\����ID�ȊO�j
     *
     * @param bo
     * @param inSession
     */
    public void CSVhoyuShiakuMstUpd(HoyuShikakuMst bo, SmnMskJoho inSession, SmnMskJoho torokuLine) throws Exception {
        Date date = new Date();
        SimpleDateFormat dt = new SimpleDateFormat("yyyyMMdd");
        SimpleDateFormat tm = new SimpleDateFormat("HHmmss");
        String koshinDate = dt.format(date);
        String koshinTime = tm.format(date);
        HoyuShikakuMst hoyuShikakuMst = inSession.getHoyuShikakuMstMapForUpdateBefore().get(torokuLine.getShinseiShikakuNo());
        BeanUtils.copyProperties(bo, hoyuShikakuMst);

        if (CheckUtility.isNumber(hoyuShikakuMst.getMuryoZanCount())) {
            int muryoZanCnt = Integer.parseInt(hoyuShikakuMst.getMuryoZanCount());
            // IP(�t�H���[�A�b�v)�̏ꍇ�A�������T���g�p����ꍇ�͖����c�񐔂����Z
            if ("IP".equals(torokuLine.getSknKsuCode()) && "12".equals(torokuLine.getShubetsuCode())
                    && BmaConstants.KESSAI_HOHO_KBN_BENEFITS.equals(torokuLine.getKessaiHohoKbn()) && 0 < muryoZanCnt) {
                bo.setMuryoZanCount(String.valueOf(muryoZanCnt - 1));
            }
        }
        bo.setKoshinKbn(BmaConstants.SHORI_KBN_UPDATE);
        bo.setKoshinDate(koshinDate);
        bo.setKoshinTime(koshinTime);
        bo.setKoshinUserId(inSession.getMoshikomishaId());
        bo.setRonriSakujoFlg(BmaConstants.FLG_OFF);
    }

}
