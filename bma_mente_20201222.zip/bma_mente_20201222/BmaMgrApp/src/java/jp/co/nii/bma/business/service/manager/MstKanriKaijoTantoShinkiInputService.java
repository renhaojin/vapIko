package jp.co.nii.bma.business.service.manager;

import java.util.List;
import java.util.ArrayList;
import jp.co.nii.bma.business.domain.KaijoMst;
import jp.co.nii.bma.business.rto.manager.MstKanriKaijoTantoJoho;
import jp.co.nii.bma.business.service.common.BmaConstants;
import jp.co.nii.bma.business.service.common.BmaLogger;
import jp.co.nii.bma.business.service.common.BmaValidator;
import jp.co.nii.bma.utility.BmaStringUtility;
import jp.co.nii.bma.utility.BmaUtility;
import jp.co.nii.sew.business.service.AbstractService;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_SUCCESS;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_RELOAD;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_BACK;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_EXCEPTION;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_SESSION;
import jp.co.nii.sew.presentation.Messages;
import jp.co.nii.sew.presentation.Option;
import jp.co.nii.sew.presentation.RequestTransferObject;
import jp.co.nii.sew.utility.PropertyUtility;

/**
 *
 * @author nii19042
 */
public class MstKanriKaijoTantoShinkiInputService extends AbstractService {

    /**
     * DB�ڑ��̃f�[�^�\�[�X
     */
    private static String DATA_SOURCE_NAME;
    /**
     * ���O
     */
    BmaLogger log = (BmaLogger) BmaLogger.getLogger(this.getClass().getName());
    /**
     * �Ɩ��R�[�h
     */
    private static final String BUSINESS_CODE = PropertyUtility.getProperty("business_code");
    /**
     * ���׃e�X�g���[�h
     */
    private static final String STRESS_MODE = PropertyUtility.getProperty(BUSINESS_CODE + "stress_mode");

    /**
     * �R���X�g���N�^
     */
    public MstKanriKaijoTantoShinkiInputService() {
        super();
        /* DB�ڑ����̃��[�U�[������ */
        DATA_SOURCE_NAME = BmaConstants.DS_REGISTRANT;
    }

    /**
     * �T�[�r�X�N���X�̎��s���\�b�h
     *
     * @param rto ���N�G�X�g��񂩂�擾����rto
     * @param rtoInSession �Z�b�V�������rto
     * @return foward��
     * @throws Exception ��O
     */
    @Override
    public String doService(RequestTransferObject rto, RequestTransferObject rtoInSession)
            throws Exception {

        MstKanriKaijoTantoJoho inRequest = (MstKanriKaijoTantoJoho) rto;
        MstKanriKaijoTantoJoho inSession = (MstKanriKaijoTantoJoho) rtoInSession;
        String processName = "";

        /* �G���[���b�Z�[�W������ */
        inSession.setErrors(new Messages());

        try {
            if (!(inRequest.getKaisaichiChange().equals(inSession.getKaisaichiCode()))) {
                /* �J�Òn��ύX�����ꍇ */
                processName = "MstKanriKaijoTantoShinkiInput_ChangeKaisaichi";
                log.Start(processName);

                /* �J�Òn�����ƂɁA��ꃊ�X�g���쐬 */
                KaijoMst kaijo = new KaijoMst(DATA_SOURCE_NAME);
                List<Option> kaijoByKaisaichiList = new ArrayList<Option>();
                String kaisaichi = inRequest.getKaisaichiChange();
                kaijo.findByOneKaisaichi(kaisaichi, kaijoByKaisaichiList);

                /* �I��l�Ɖ�ꃊ�X�g���Z�b�V�����ɕێ� */
                inSession.setKaisaichiCode(kaisaichi);
                inSession.setKaijoByKaisaichiList(kaijoByKaisaichiList);
                inSession.setKaijoCode("");

                /* �u���S���҃}�X�^�V�K�o�^�v���reload */
                return FWD_NM_RELOAD;

            } else if (!BmaUtility.isNullOrEmpty(inRequest.getKaijoTantoInpConf())) {
                /*�u�m�F�v�{�^�������� */
                processName = "MstKanriKaijoTantoShinkiInput_Confirm";
                log.Start(processName);

                /* ���͒l���Z�b�V�����ɕێ� */
                inSession.setKaijoCode(inRequest.getKaijoCode());
                inSession.setTantosha(inRequest.getTantosha());
                inSession.setTantoBusho(inRequest.getTantoBusho());
                inSession.setTelNo(inRequest.getTelNo());
                inSession.setFaxNo(inRequest.getFaxNo());
                inSession.setTantoshaMailAddress(inRequest.getTantoshaMailAddress());
                inSession.setBiko(inRequest.getBiko());

                /* ���͒l�`�F�b�N */
                if (!validateInput(inSession)) {
                    // �G���[���������ꍇ�u���S���҃}�X�^�V�K�o�^�v���Reload
                    return FWD_NM_RELOAD;
                }

                /* �J�Òn�Ɖ�ꖼ�̖��̂��擾 */
                for (Option kaisaichi : inSession.getKaisaichiList()) {
                    if (kaisaichi.getValue().equals(inSession.getKaisaichiCode())) {
                        // �J�Òn����
                        inSession.setKaisaichiName(kaisaichi.getLabel());
                        for (Option kaijo : inSession.getKaijoByKaisaichiList()) {
                            if (kaijo.getValue().equals(inRequest.getKaijoCode())) {
                                // ��ꖼ
                                inSession.setKaijoName(kaijo.getLabel());
                                break;
                            }
                        }
                        break;
                    }
                }

                /* �u���S���҃}�X�^�V�K�o�^�m�F�v��ʕ\�� */
                return FWD_NM_SUCCESS;

            } else if (!BmaUtility.isNullOrEmpty(inRequest.getKaijoTantoInpBack())) {
                /*�u�߂�v�{�^�������� */
                processName = "MstKanriKaijoTantoShinkiInput_BackKaijoTantoSearch";
                log.Start(processName);

                /* �c���Ă���I��l��j�� */
                String initKaisaichi[] = {""};
                inSession.setKaisaichiSelect(initKaisaichi);
                inSession.setTantoSrcListFlg("");
                inSession.setTantoResultList(new ArrayList<MstKanriKaijoTantoJoho>());

                /* �u���S���҃}�X�^�����v��ʕ\�� */
                return FWD_NM_BACK;

            } else {
                /* �ُ�J�� */
                log.IllegalFWD();
                return FWD_NM_SESSION;
            }
        } catch (Exception e) {
            return FWD_NM_EXCEPTION;
        } finally {
            log.End(processName);
        }
    }

    /**
     * ���̓`�F�b�N
     *
     * @param inSession �Z�b�V����RTO
     * @return true:�G���[��
     */
    private boolean validateInput(MstKanriKaijoTantoJoho inSession) {
        /* �ϐ������� */
        Messages errors = new Messages();
        String groupCode;
        String itemName;

        //�S�p�ϊ����s
        inSession.setTantosha(BmaStringUtility.convertHankakuToZenkakuBma(inSession.getTantosha()));
        inSession.setTantoBusho(BmaStringUtility.convertHankakuToZenkakuBma(inSession.getTantoBusho()));

        /* �J�Òn�R�[�h */
        groupCode = "kaisaichiCode";
        itemName = "�J�Òn�R�[�h";
        if (BmaValidator.validateSelect(inSession.getKaisaichiCode(), errors, groupCode, itemName)) {
            BmaValidator.validatePermissionSelect(inSession.getKaisaichiCode(), inSession.getKaisaichiList(), errors, groupCode, itemName);
        }

        /* ���R�[�h */
        groupCode = "kaijoCode";
        itemName = "���R�[�h";
        if (BmaValidator.validateSelect(inSession.getKaijoCode(), errors, groupCode, itemName)) {
            BmaValidator.validatePermissionSelect(inSession.getKaijoCode(), inSession.getKaijoByKaisaichiList(), errors, groupCode, itemName);
        }

        /* �S���� */
        groupCode = "tantosha";
        itemName = "�S����";
        if (BmaValidator.validateRequired(inSession.getTantosha(), errors, groupCode, itemName)) {
            if (BmaValidator.validateMaxLength(inSession.getTantosha(), BmaConstants.MAX_LENGTH_TANTOSHA, errors, groupCode, itemName)) {
                BmaValidator.validateMojiCode3(inSession.getTantosha(), errors, groupCode, itemName);
            }
        }

        /* �S������ */
        groupCode = "tantoBusho";
        itemName = "�S������";
        if (BmaValidator.validateMaxLength(inSession.getTantoBusho(), BmaConstants.MAX_LENGTH_TANTOBUSHO, errors, groupCode, itemName)) {
            BmaValidator.validateMojiCode3(inSession.getTantoBusho(), errors, groupCode, itemName);
        }

        /* �d�b�ԍ� */
        groupCode = "telNo";
        itemName = "�d�b�ԍ�";
        if (BmaValidator.validateRequired(inSession.getTelNo(), errors, groupCode, itemName)) {
            if (BmaValidator.validateNumber(inSession.getTelNo(), errors, groupCode, itemName)) {
                BmaValidator.validateRangeLength(inSession.getTelNo(), BmaConstants.MIN_LENGTH_TEL_NO, BmaConstants.MAX_LENGTH_TEL_NO, errors, groupCode, itemName);
            }
        }

        /* FAX�ԍ� */
        groupCode = "faxNo";
        itemName = "FAX�ԍ�";
        if (BmaValidator.validateNumber(inSession.getFaxNo(), errors, groupCode, itemName)) {
            BmaValidator.validateRangeLength(inSession.getFaxNo(), BmaConstants.MIN_LENGTH_FAX_NO, BmaConstants.MAX_LENGTH_FAX_NO, errors, groupCode, itemName);
        }

        /* �S���҃��[���A�h���X */
        groupCode = "tantoshaMailAddress";
        itemName = "�S���҃��[���A�h���X";
        if (BmaValidator.validateMaxLength(inSession.getTantoshaMailAddress(), BmaConstants.MAX_LENGTH_TANTOSHA_MAILADDRESS, errors, groupCode, itemName)) {
            BmaValidator.validateEmail(inSession.getTantoshaMailAddress(), errors, groupCode, itemName);
        }

        /* ���l */
        groupCode = "biko";
        itemName = "���l";
        if (BmaValidator.validateMaxLength(inSession.getBiko(), BmaConstants.MAX_LENGTH_BIKO, errors, groupCode, itemName)) {
            String replaced = inSession.getBiko().replaceAll("\r\n", "\n");
            replaced = replaced.replaceAll("\r", "\n");
            if (BmaValidator.validateMojiCodeForBiko(replaced, errors, groupCode, itemName)) {
                // �G���[���Ȃ���΁A�\���p�ɃZ�b�V�����ێ�
                inSession.setBikoDisp(replaced.replaceAll("\n", "<br>"));
            }
        }

        inSession.setErrors(errors);
        return errors.isEmpty();
    }
}