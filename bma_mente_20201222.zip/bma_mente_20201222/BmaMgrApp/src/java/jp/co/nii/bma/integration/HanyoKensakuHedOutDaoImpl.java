package jp.co.nii.bma.integration;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import jp.co.nii.bma.business.domain.HanyoKensakuHedOutDao;
import jp.co.nii.bma.business.rto.manager.HanyouSearchJoho;
import jp.co.nii.sew.common.LogGenerate;
import jp.co.nii.sew.integration.SQLStateSQLExceptionTranslater;
import jp.co.nii.sew.presentation.Option;

/**
 * �ėp�����w�b�__�o�� DAO�����N���X
 *
 * @author DB�Ǘ��c�[��
 */
public class HanyoKensakuHedOutDaoImpl extends GeneratedHanyoKensakuHedOutDaoImpl implements HanyoKensakuHedOutDao {

    /**
     * �C���X�^���X�𐶐�����B
     *
     * @param datasource �f�[�^�\�[�X��
     */
    public HanyoKensakuHedOutDaoImpl(String datasource) {
        super(datasource);
    }

    @Override
    public void findHanyoListSearch(List<Option> list) {

        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = "";

        String limit = "";

        limit = " LIMIT " + "1000";
        try {
            con = getConnection();
            sql = "SELECT " + FIELDS_DECRYPT
                    + " FROM " + getSchemaName() + "." + TABLE_NAME
                    + " WHERE " + " RONRI_SAKUJO_FLG = '0'"
                    + " ORDER BY hanyo_kensaku_id_out ASC "
                    + limit;

            stmt = con.prepareStatement(sql);

            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();

            while (rs.next()) {
                if (list != null) {
                    list.add(new Option(rs.getString("hanyo_kensaku_id_out"), rs.getString("hanyo_kensaku_name")));
                }

            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }

    }

    @Override
    public void findDtlOutHeadDtlList(List<Option> list, HanyouSearchJoho inSession) {
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = "";

        try {
            con = getConnection();
            sql = "SELECT " + "viw_clm_name_jkn,komoku_name"
                    + " FROM  bma.HANYO_KENSAKU_DTL_OUT DTL "
                    + " INNER JOIN  bma.HANYO_KENSAKU_HED_OUT HED "
                    + " ON HED.HANYO_KENSAKU_ID_OUT = DTL.HANYO_KENSAKU_ID_OUT "
                    + " INNER JOIN  bma.hanyo_kensaku_out_mst mst "
                    + " ON mst.viw_clm_name_out = DTL.viw_clm_name_jkn  "
                    + " WHERE " + " HED.RONRI_SAKUJO_FLG = '0'"
                    + " AND HED.HANYO_KENSAKU_ID_OUT = ? "
                    + " ORDER BY viw_clm_name_jkn ASC ";
   
            stmt = con.prepareStatement(sql);
            int i = 1;
            stmt.setString(i++, inSession.getSearchChange());

            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();

            while (rs.next()) {
                if (list != null) {
                    list.add(new Option(rs.getString("viw_clm_name_jkn"), rs.getString("komoku_name")));
                }
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
    }
}
