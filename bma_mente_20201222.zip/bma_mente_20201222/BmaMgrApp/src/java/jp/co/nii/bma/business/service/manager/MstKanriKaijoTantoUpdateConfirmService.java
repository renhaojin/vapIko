package jp.co.nii.bma.business.service.manager;

import java.util.ArrayList;
import java.util.List;
import jp.co.nii.bma.business.domain.KaijoMst;
import jp.co.nii.bma.business.domain.KaijoTantoMst;
import jp.co.nii.bma.business.rto.manager.MstKanriKaijoTantoJoho;
import jp.co.nii.bma.business.service.common.BmaConstants;
import jp.co.nii.bma.business.service.common.BmaLogger;
import jp.co.nii.bma.business.service.common.BmaValidator;
import jp.co.nii.bma.presentation.common.BmaText;
import jp.co.nii.bma.utility.BmaStringUtility;
import jp.co.nii.bma.utility.BmaUtility;
import jp.co.nii.sew.business.SystemTime;
import jp.co.nii.sew.business.service.AbstractService;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_SUCCESS;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_RELOAD;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_BACK;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_EXCEPTION;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_SESSION;
import jp.co.nii.sew.presentation.Messages;
import jp.co.nii.sew.presentation.Option;
import jp.co.nii.sew.presentation.RequestTransferObject;
import jp.co.nii.sew.utility.PropertyUtility;
import org.apache.commons.beanutils.BeanUtils;

/**
 *
 * @author nii19042
 */
public class MstKanriKaijoTantoUpdateConfirmService extends AbstractService {

    /**
     * DB�ڑ��̃f�[�^�\�[�X
     */
    private static String DATA_SOURCE_NAME;
    /**
     * ���O
     */
    BmaLogger log = (BmaLogger) BmaLogger.getLogger(this.getClass().getName());
    /**
     * �Ɩ��R�[�h
     */
    private static final String BUSINESS_CODE = PropertyUtility.getProperty("business_code");
    /**
     * ���׃e�X�g���[�h
     */
    private static final String STRESS_MODE = PropertyUtility.getProperty(BUSINESS_CODE + "stress_mode");

    /**
     * �R���X�g���N�^
     */
    public MstKanriKaijoTantoUpdateConfirmService() {
        super();
        /* DB�ڑ����̃��[�U�[������ */
        DATA_SOURCE_NAME = BmaConstants.DS_REGISTRANT;
    }

    /**
     * �T�[�r�X�N���X�̎��s���\�b�h
     *
     * @param rto ���N�G�X�g��񂩂�擾����rto
     * @param rtoInSession �Z�b�V�������rto
     * @return foward��
     * @throws Exception ��O
     */
    @Override
    public String doService(RequestTransferObject rto, RequestTransferObject rtoInSession)
            throws Exception {

        MstKanriKaijoTantoJoho inRequest = (MstKanriKaijoTantoJoho) rto;
        MstKanriKaijoTantoJoho inSession = (MstKanriKaijoTantoJoho) rtoInSession;
        String processName = "";

        /* �G���[���b�Z�[�W������ */
        inSession.setErrors(new Messages());

        try {
            if (!BmaUtility.isNullOrEmpty(inRequest.getKaijoTantoUpdComp())) {
                /*�u�m��v�{�^�������� */
                processName = "MstKanriKaijoTantoUpdateConfirm_Complete";
                log.Start(processName);

                /* ��L�[�擾 */
                KaijoTantoMst tantoUpd = new KaijoTantoMst(DATA_SOURCE_NAME);
                String kaisaichiCode = inSession.getKaisaichiCode();
                String kaijoCode = inSession.getKaijoCode();
                String tantoshaCode = inSession.getTantoshaCode();

                /* ���͒l�`�F�b�N */
                if(!validateInput(inSession)){
                    // �G���[���������ꍇ�u���S���҃}�X�^�ύX�m�F�v���Reload
                    return FWD_NM_RELOAD;
                } else {
                    try {
                        /* �g�����U�N�V�����擾&�J�n */
                        getTransaction();
                        beginTransaction();

                        // �J�Òn�R�[�h�A���R�[�h�A�S���҃R�[�h�����S���҃f�[�^�擾
                        KaijoTantoMst tantoBfr  = tantoUpd.lockNoWait(kaisaichiCode, kaijoCode, tantoshaCode);

                        if(tantoBfr != null){
                            /* �ύX�OBO����X�V�pBO�ɒl���R�s�[ */
                            BeanUtils.copyProperties(tantoUpd, tantoBfr);
                            /* �V�X�e���������擾 */
                            SystemTime sysTime = new SystemTime();

                            /* �ύX�����S���҃}�X�^�ɃZ�b�g */ 
                            tantoUpd.setTantoBusho(inSession.getTantoBusho());
                            tantoUpd.setTelNo(inSession.getTelNo());
                            tantoUpd.setFaxNo(inSession.getFaxNo());
                            tantoUpd.setTantoshaMailAddress(inSession.getTantoshaMailAddress());
                            tantoUpd.setBiko(inSession.getBiko());

                            /* DB���ʍ��ڃZ�b�g */
                            tantoUpd.setKoshinKbn(BmaConstants.SHORI_KBN_UPDATE);
                            tantoUpd.setKoshinDate(sysTime.getymd1());
                            tantoUpd.setKoshinTime(sysTime.gethms1());
                            tantoUpd.setKoshinUserId(inRequest.getMoshikomishaId());

                            tantoUpd.update();
                        } else {
                            /* Update����f�[�^���擾�ł��Ȃ������ꍇ�u���S���҃}�X�^�ύX�m�F�v���Reload */
                            Messages errors = new Messages();
                            BmaValidator.addMessage(errors, "kaijoTantoData", BmaText.E00120, "���S����");
                            inSession.setErrors(errors);
                            return FWD_NM_RELOAD;
                        }
                        /* �R�~�b�g */
                        commitTransaction();
                       } catch (Exception ex) {
                           ex.printStackTrace();
                           // ���[���o�b�N
                           rollbackTransaction();
                            return FWD_NM_SESSION;
                       }
                /* �u���S���҃}�X�^�ύX�����v��ʕ\�� */
                return FWD_NM_SUCCESS;
                   }

            } else if (!BmaUtility.isNullOrEmpty(inRequest.getKaijoTantoUpdConfBack())) {
                /*�u�����v�{�^�������� */
                processName = "MstKanriKaijoTantoUpdateConfirm_BackKaijoTantoUpdInput";
                log.Start(processName);

                /* �u���S���҃}�X�^�ύX���́v��ʕ\�� */
                return FWD_NM_BACK;

            } else {
                /* �ُ�J�� */
                log.IllegalFWD();
                return FWD_NM_SESSION;
            }
        } catch (Exception e) {
            return FWD_NM_EXCEPTION;
        } finally {
            log.End(processName);
        }
    }

    /**
     * ���̓`�F�b�N
     *
     * @param inSession �Z�b�V����RTO
     * @return true:�G���[��
     */
    private boolean validateInput(MstKanriKaijoTantoJoho inSession) {
        /* �ϐ������� */
        Messages errors = new Messages();
        String groupCode;
        String itemName;

        /* �J�Òn�R�[�h */
        groupCode = "kaisaichiCode";
        itemName = "�J�Òn�R�[�h";
        if (BmaValidator.validateSelect(inSession.getKaisaichiCode(), errors, groupCode, itemName)) {
            BmaValidator.validatePermissionSelect(inSession.getKaisaichiCode(), inSession.getKaisaichiList(), errors, groupCode, itemName);
        }

        // �G���[�`�F�b�N�p���X�g�쐬
        /* �J�Òn�����ƂɁA��ꃊ�X�g���쐬 */
        KaijoMst kaijo = new KaijoMst(DATA_SOURCE_NAME);
        List<Option> kaijoByKaisaichiList = new ArrayList<Option>();
        kaijo.findByOneKaisaichi(inSession.getKaisaichiCode(), kaijoByKaisaichiList);
        /* ���R�[�h */
        groupCode = "kaijoCode";
        itemName = "���R�[�h";
        if (BmaValidator.validateSelect(inSession.getKaijoCode(), errors, groupCode, itemName)) {
            BmaValidator.validatePermissionSelect(inSession.getKaijoCode(), kaijoByKaisaichiList, errors, groupCode, itemName);
        }

        /* �S���� */
        groupCode = "tantosha";
        itemName = "�S����";
        if (BmaValidator.validateRequired(inSession.getTantosha(), errors, groupCode, itemName)) {
            if (BmaValidator.validateMaxLength(inSession.getTantosha(), BmaConstants.MAX_LENGTH_TANTOSHA, errors, groupCode, itemName)) {
                BmaValidator.validateHankakuAndZenkaku(inSession.getTantosha(), errors, groupCode, itemName);
            }
        }

        /* �S������ */
        groupCode = "tantoBusho";
        itemName = "�S������";
        if (BmaValidator.validateMaxLength(inSession.getTantoBusho(), BmaConstants.MAX_LENGTH_TANTOBUSHO, errors, groupCode, itemName)) {
            BmaValidator.validateHankakuAndZenkaku(inSession.getTantoBusho(), errors, groupCode, itemName);
        }

        /* �d�b�ԍ� */
        groupCode = "telNo";
        itemName = "�d�b�ԍ�";
        if (BmaValidator.validateRequired(inSession.getTelNo(), errors, groupCode, itemName)) {
            if (BmaValidator.validateNumber(inSession.getTelNo(), errors, groupCode, itemName)) {
                BmaValidator.validateRangeLength(inSession.getTelNo(), BmaConstants.MIN_LENGTH_TEL_NO, BmaConstants.MAX_LENGTH_TEL_NO, errors, groupCode, itemName);
            }
        }

        /* FAX�ԍ� */
        groupCode = "faxNo";
        itemName = "FAX�ԍ�";
        if (BmaValidator.validateNumber(inSession.getFaxNo(), errors, groupCode, itemName)) {
            BmaValidator.validateRangeLength(inSession.getFaxNo(), BmaConstants.MIN_LENGTH_FAX_NO, BmaConstants.MAX_LENGTH_FAX_NO, errors, groupCode, itemName);
        }

        /* �S���҃��[���A�h���X */
        groupCode = "tantoshaMailAddress";
        itemName = "�S���҃��[���A�h���X";
        if (BmaValidator.validateMaxLength(inSession.getTantoshaMailAddress(), BmaConstants.MAX_LENGTH_TANTOSHA_MAILADDRESS, errors, groupCode, itemName)) {
            BmaValidator.validateEmail(inSession.getTantoshaMailAddress(), errors, groupCode, itemName);
        }

        /* ���l */
        groupCode = "biko";
        itemName = "���l";
        if (BmaValidator.validateMaxLength(inSession.getBiko(), BmaConstants.MAX_LENGTH_BIKO, errors, groupCode, itemName)) {
            BmaValidator.validateMojiCodeForBiko(inSession.getBiko(), errors, groupCode, itemName);
        }

        inSession.setErrors(errors);
        return errors.isEmpty();
    }
}