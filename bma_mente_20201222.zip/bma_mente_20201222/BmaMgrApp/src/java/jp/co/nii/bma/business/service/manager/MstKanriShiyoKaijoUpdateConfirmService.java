package jp.co.nii.bma.business.service.manager;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import jp.co.nii.bma.business.domain.KaijoMst;
import jp.co.nii.bma.business.domain.KaijoTantoMst;
import jp.co.nii.bma.business.domain.ShiyoKaijo;
import jp.co.nii.bma.business.rto.manager.MstKanriShiyoKaijoJoho;
import jp.co.nii.bma.business.service.common.BmaConstants;
import jp.co.nii.bma.business.service.common.BmaLogger;
import jp.co.nii.bma.business.service.common.BmaValidator;
import static jp.co.nii.bma.business.service.manager.MstKanriShiyoKaijoSerchService.dateToWeek;
import jp.co.nii.bma.presentation.common.BmaText;
import jp.co.nii.bma.utility.BmaUtility;
import jp.co.nii.sew.business.SystemTime;
import jp.co.nii.sew.business.service.AbstractService;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_BACK;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_EXCEPTION;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_SESSION;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_SUCCESS;
import jp.co.nii.sew.presentation.Messages;
import jp.co.nii.sew.presentation.Option;
import jp.co.nii.sew.presentation.RequestTransferObject;
import jp.co.nii.sew.utility.PropertyUtility;
import org.apache.commons.beanutils.BeanUtils;

/**
 *
 * @author nii19049
 */
public class MstKanriShiyoKaijoUpdateConfirmService extends AbstractService {

    /**
     * DB�ڑ��̃f�[�^�\�[�X
     */
    private static String DATA_SOURCE_NAME;
    /**
     * ���O
     */
    BmaLogger log = (BmaLogger) BmaLogger.getLogger(this.getClass().getName());
    /**
     * �Ɩ��R�[�h
     */
    private static final String BUSINESS_CODE = PropertyUtility.getProperty("business_code");
    /**
     * ���׃e�X�g���[�h
     */
    private static final String STRESS_MODE = PropertyUtility.getProperty(BUSINESS_CODE + "stress_mode");

    /**
     * �R���X�g���N�^
     */
    public MstKanriShiyoKaijoUpdateConfirmService() {
        super();
        /* DB�ڑ����̃��[�U�[������ */
        DATA_SOURCE_NAME = BmaConstants.DS_REGISTRANT;
    }

    /**
     * �T�[�r�X�N���X�̎��s���\�b�h
     *
     * @param rto ���N�G�X�g��񂩂�擾����rto
     * @param rtoInSession �Z�b�V�������rto
     * @return foward��
     * @throws Exception ��O
     */
    @Override
    public String doService(RequestTransferObject rto, RequestTransferObject rtoInSession)
            throws Exception {

        MstKanriShiyoKaijoJoho inRequest = (MstKanriShiyoKaijoJoho) rto;
        MstKanriShiyoKaijoJoho inSession = (MstKanriShiyoKaijoJoho) rtoInSession;
        String processName = "";

        /*�G���[���b�Z�[�W������*/
        inSession.setErrors(new Messages());
        try {
            if (!BmaUtility.isNullOrEmpty(inRequest.getNext())) {
                /*�u�m��v�{�^��������*/
                processName = "MstKanriShiyoKaijoUpdateConfirm_Complete";
                log.Start(processName);

                /* �ϐ������� */
                String kaijoId = "";
                String dbKaijoShikenKbn = "";
                String kaisaichiCode = "";
                String dbKaijoCode = "";

                /* ��L�[�擾 */
                ShiyoKaijo shiyoKaijoUpd = new ShiyoKaijo(DATA_SOURCE_NAME);
                KaijoMst kaijoUpd = new KaijoMst(DATA_SOURCE_NAME);
                String nendo = inSession.getNendo();
                String sknKsuCode = inSession.getSknKsuCode();
                String shubetsuCode = inSession.getShubetsuCode();
                String kaisuCode = inSession.getKaisuCode();

                /* ���͒l�`�F�b�N */
                if (!validateInput(inSession.getShiyoKaijoUpdateList(), inSession)) {
                    // �G���[���������ꍇ�u�g�p���ύX�m�F�v���Reload
                    return FWD_NM_RELOAD;
                } else {
                    try {
                        /* �g�����U�N�V�����擾&�J�n */
                        getTransaction();
                        beginTransaction();

                        for (MstKanriShiyoKaijoJoho shiyoKaijo : inSession.getShiyoKaijoInputList()) {
//                        if ("1".equals(shiyoKaijo.getSelectedKaijo())) {
                            // ��L�[���g�p���f�[�^�擾
                            kaijoId = shiyoKaijo.getKaijoId();
                            dbKaijoShikenKbn = shiyoKaijo.getDbKaijoShikenKbn();      // �ύX���͉�ʂŕύX�\�Ȃ��߁A�ޔ��������f�[�^���g�p
                            kaisaichiCode = shiyoKaijo.getKaisaichiCode();
                            dbKaijoCode = shiyoKaijo.getDbKaijoCode();                // �ύX���͉�ʂŕύX�\�Ȃ��߁A�ޔ��������f�[�^���g�p
                            ShiyoKaijo shiyoKaijoBfr = shiyoKaijoUpd.lockNoWait(nendo, sknKsuCode, shubetsuCode, kaisuCode, kaijoId, dbKaijoShikenKbn, kaisaichiCode, dbKaijoCode);

                            if (shiyoKaijoBfr != null) {
                                /* �ύX�OBO����X�V�pBO�ɒl���R�s�[ */
                                BeanUtils.copyProperties(shiyoKaijoUpd, shiyoKaijoBfr);
                                /* �V�X�e���������擾 */
                                SystemTime sysTime = new SystemTime();

                                /* �ύX���g�p���ɃZ�b�g */
                                shiyoKaijoUpd.setKaijoShikenKbn(shiyoKaijo.getKaijoShikenKbn());
                                shiyoKaijoUpd.setTantoshaCode(shiyoKaijo.getTantoshaCode());
                                shiyoKaijoUpd.setNitteiFrom(shiyoKaijo.getNitteiFrom());
                                shiyoKaijoUpd.setNitteiTo(shiyoKaijo.getNitteiTo());
                                shiyoKaijoUpd.setTeiin(shiyoKaijo.getTeiin());
                                shiyoKaijoUpd.setBikoKaijo(shiyoKaijo.getBikoKaijo());
                                shiyoKaijoUpd.setBikoTanto(shiyoKaijo.getBikoTanto());
                                if ("10".equals(kaisaichiCode)) {
                                    KaijoMst kaijo = kaijoUpd.find(shiyoKaijo.getKaijoCode().substring(0, 2), shiyoKaijo.getKaijoCode().substring(2, 5));
                                    shiyoKaijoUpd.setKaijoName(kaijo.getKaijoName());
                                    shiyoKaijoUpd.setKaijoNameRyaku(kaijo.getKaijoNameRyaku());
                                    shiyoKaijoUpd.setJusho(kaijo.getJusho());
                                    shiyoKaijoUpd.setYubinNo(kaijo.getYubinNo());
                                    shiyoKaijoUpd.setKaijoCode(shiyoKaijo.getKaijoCode().substring(2, 5));
                                    shiyoKaijoUpd.setKaisaichiCodeKaijoMst(shiyoKaijo.getKaisaichiCodeKaijoMst());
                                } else {
                                    KaijoMst kaijo = kaijoUpd.find(kaisaichiCode, shiyoKaijo.getKaijoCode());
                                    shiyoKaijoUpd.setKaijoName(kaijo.getKaijoName());
                                    shiyoKaijoUpd.setKaijoNameRyaku(kaijo.getKaijoNameRyaku());
                                    shiyoKaijoUpd.setJusho(kaijo.getJusho());
                                    shiyoKaijoUpd.setYubinNo(kaijo.getYubinNo());
                                    shiyoKaijoUpd.setKaijoCode(shiyoKaijo.getKaijoCode());
                                    shiyoKaijoUpd.setKaisaichiCodeKaijoMst("");
                                }

                                /* DB���ʍ��ڃZ�b�g */
                                shiyoKaijoUpd.setKoshinKbn(BmaConstants.SHORI_KBN_UPDATE);
                                shiyoKaijoUpd.setKoshinDate(sysTime.getymd1());
                                shiyoKaijoUpd.setKoshinTime(sysTime.gethms1());
                                shiyoKaijoUpd.setKoshinUserId(inRequest.getMoshikomishaId());

                                shiyoKaijoUpd.updateShiyoKaijo(shiyoKaijoUpd, dbKaijoShikenKbn, dbKaijoCode);
//                            }

                            } else {
                                /* Update����f�[�^���擾�ł��Ȃ������ꍇ�u�g�p���ύX�m�F�v���Reload */
                                Messages errors = new Messages();
                                BmaValidator.addMessage(errors, "shiyoKaijoData", BmaText.E00120, "�g�p���");
                                inSession.setErrors(errors);
                                return FWD_NM_RELOAD;
                            }
                        }
                        /* �R�~�b�g */
                        commitTransaction();
                    } catch (Exception ex) {
                        ex.printStackTrace();
                        // ���[���o�b�N
                        rollbackTransaction();
                        return FWD_NM_SESSION;
                    }
                    /* �u�g�p���ύX�����v��ʕ\�� */
                    return FWD_NM_SUCCESS;
                }

            } else if (!BmaUtility.isNullOrEmpty(inRequest.getBack())) {
                /*�u�����v�{�^��������*/
                processName = "MstKanriShiyoKaijoUpdateConfirm_BackShiyoKaijoUpdInput";
                log.Start(processName);

                List<MstKanriShiyoKaijoJoho> kaijoList = inSession.getKaijoList();

                KaijoTantoMst tanto = new KaijoTantoMst(DATA_SOURCE_NAME);
                KaijoMst kaijoM = new KaijoMst(DATA_SOURCE_NAME);

                for (int i = 0; i < kaijoList.size(); ++i) {
                    List<Option> tantoshaList = new ArrayList<Option>();
                    List<Option> kaijoByKaisaichiList = new ArrayList<Option>();

                    MstKanriShiyoKaijoJoho shiyoKaijo = kaijoList.get(i);

                    String kaisaichi = shiyoKaijo.getKaisaichiCode();
                    String kaijo = shiyoKaijo.getKaijoCode();
                    String tantoshaCode = shiyoKaijo.getTantoshaCode();

                    //copy
                    /* �J�Òn�����ƂɁA��ꃊ�X�g���쐬 */
                    KaijoMst kaijoL = new KaijoMst(DATA_SOURCE_NAME);
                    List<Option> kaijoByTantoshaList = new ArrayList<Option>();

                    // �\�������ւ̏ꍇ
                    if ("10".equals(kaisaichi)) {
                        String[] kaisaichies = {"03", "04"};
                        kaijoL.findByKaisaichies(kaisaichies, kaijoByKaisaichiList);
                        shiyoKaijo.setTokanKaijoCode(kaijo);
                        tanto.findByOneTantosha(kaijo.substring(0, 2), kaijo.substring(2, 5), kaijoByTantoshaList);
                    } else {
                        kaijoL.findByOneKaisaichi(kaisaichi, kaijoByKaisaichiList);
                        tanto.findByOneTantosha(kaisaichi, kaijo, kaijoByTantoshaList);
                    }

                    shiyoKaijo.setKaijoByKaisaichiList(kaijoByKaisaichiList);
                    shiyoKaijo.setKaijoByTantoshaList(kaijoByTantoshaList);
                    //�����܂�

                    String shiyoKaijoName = kaijoM.findKaijoNameRyaku(kaisaichi, kaijo);
                    tanto.findByOneTantosha(kaisaichi, kaijo, tantoshaList);
                    String shiyoKaijoTantosha = tanto.searchTantoshaName(kaisaichi, kaijo, tantoshaCode);
                    shiyoKaijo.setTantosha(shiyoKaijoTantosha);

                    shiyoKaijo.setKaijoName(shiyoKaijoName);
                    shiyoKaijo.setTantoshaList(tantoshaList);

                    kaijoList.set(i, shiyoKaijo);
                }
                inSession.setKaijoList(kaijoList);

                inSession.setShiyoKaijoUpdateList(new LinkedList<MstKanriShiyoKaijoJoho>());

                /* �u�g�p���ύX���́v��ʕ\�� */
                return FWD_NM_BACK;

            } else {
                /*�ُ�J��*/
                log.IllegalFWD();
                return FWD_NM_SESSION;
            }
        } catch (Exception e) {
            return FWD_NM_EXCEPTION;
        } finally {
            log.End(processName);
        }
    }

    /**
     * �ꗗ�\���p�ɐ��`����
     *
     * @param kaijoMst ��������
     * @return �������ʕ\���p
     */
    private MstKanriShiyoKaijoJoho createShiyoKaijoDetail(ShiyoKaijo shiyoKaijo, List<Option> kaisaichiCodeList) {
        String teiinBfr = "";
        String teiinAft = "";
        String detailCodes = "";
        String kaijoShikenKbnName = "";
        String kaijoShikenName = "";

        MstKanriShiyoKaijoJoho shiyoKaijoDetail = new MstKanriShiyoKaijoJoho();

        /**
         * ����̐��`
         */
        teiinBfr = shiyoKaijo.getTeiin();
        teiinAft = teiinBfr.replaceFirst("^0+", "");
        if (teiinAft.isEmpty()) {
            teiinAft = "0";
        } else if (teiinAft.length() > 3) {
            teiinAft = teiinAft.substring(0, teiinAft.length() - 3)
                    + ","
                    + teiinAft.substring(teiinAft.length() - 3);
        }
        shiyoKaijoDetail.setTeiinDisp(teiinAft);

        /* ��ꎎ���敪���́i���́j���Z�b�g */
        if (BmaConstants.KAIJO_SHIKEN_KBN_NASHI.equals(shiyoKaijo.getKaijoShikenKbn())) {
            kaijoShikenKbnName = "-";
        } else if (BmaConstants.KAIJO_SHIKEN_KBN_GAKKA.equals(shiyoKaijo.getKaijoShikenKbn())) {
            kaijoShikenKbnName = "�w��";
        } else if (BmaConstants.KAIJO_SHIKEN_KBN_ZITSUGI.equals(shiyoKaijo.getKaijoShikenKbn())) {
            kaijoShikenKbnName = "���Z";
        }
        shiyoKaijoDetail.setKaijoShikenKbnName(kaijoShikenKbnName);

        /* ��ꎎ���敪���̂��Z�b�g */
        if (BmaConstants.KAIJO_SHIKEN_KBN_NASHI.equals(shiyoKaijo.getKaijoShikenKbn())) {
            kaijoShikenName = "�敪���g�p���Ȃ�";
        } else if (BmaConstants.KAIJO_SHIKEN_KBN_GAKKA.equals(shiyoKaijo.getKaijoShikenKbn())) {
            kaijoShikenName = "�w�Ȏ����y�ю��Z�y�[�p�[�e�X�g";
        } else if (BmaConstants.KAIJO_SHIKEN_KBN_ZITSUGI.equals(shiyoKaijo.getKaijoShikenKbn())) {
            kaijoShikenName = "���Z��Ǝ���";
        }
        shiyoKaijoDetail.setKaijoShikenName(kaijoShikenName);

        // �ڍ׃{�^���p
        detailCodes = shiyoKaijo.getNendo()
                + shiyoKaijo.getSknKsuCode()
                + shiyoKaijo.getShubetsuCode()
                + shiyoKaijo.getKaisuCode()
                + shiyoKaijo.getKaijoId()
                + shiyoKaijo.getKaijoShikenKbn()
                + shiyoKaijo.getKaisaichiCode()
                + shiyoKaijo.getKaijoCode();
        shiyoKaijoDetail.setShiyoKaijoDetail(detailCodes);

        for (Option kaisaichi : kaisaichiCodeList) {
            if (kaisaichi.getValue().equals(shiyoKaijo.getKaisaichiCode())) {
                /**
                 * �J�Òn���̂��Z�b�g
                 */
                shiyoKaijoDetail.setKaisaichiName(kaisaichi.getLabel());
                break;
            }
        }

        shiyoKaijoDetail.setFromYear(shiyoKaijo.getNitteiFrom().substring(0, 4));
        shiyoKaijoDetail.setFromMonth(shiyoKaijo.getNitteiFrom().substring(4, 6));
        shiyoKaijoDetail.setFromDate(shiyoKaijo.getNitteiFrom().substring(6, 8));
        shiyoKaijoDetail.setFromYobi(dateToWeek(shiyoKaijo.getNitteiFrom()));

        shiyoKaijoDetail.setToYear(shiyoKaijo.getNitteiTo().substring(0, 4));
        shiyoKaijoDetail.setToMonth(shiyoKaijo.getNitteiTo().substring(4, 6));
        shiyoKaijoDetail.setToDate(shiyoKaijo.getNitteiTo().substring(6, 8));
        shiyoKaijoDetail.setToYobi(dateToWeek(shiyoKaijo.getNitteiTo()));

        return shiyoKaijoDetail;
    }

    /**
     * �W���f�[�^��MstKanriShiyoKaijoJoho�ɕێ�
     *
     * @param shiyoKaijo ���f�[�^
     * @param saveObject �ۑ���
     */
    private void saveShiyoKaijoSession(ShiyoKaijo shiyoKaijo, MstKanriShiyoKaijoJoho saveObject) {
        saveObject.setNendo(shiyoKaijo.getNendo());
        saveObject.setSknKsuCode(shiyoKaijo.getSknKsuCode());
        saveObject.setShubetsuCode(shiyoKaijo.getShubetsuCode());
        saveObject.setKaisuCode(shiyoKaijo.getKaisuCode());
        saveObject.setKaijoId(shiyoKaijo.getKaijoId());
        saveObject.setKaijoShikenKbn(shiyoKaijo.getKaijoShikenKbn());
        saveObject.setKaisaichiCode(shiyoKaijo.getKaisaichiCode());
        saveObject.setKaijoCode(shiyoKaijo.getKaijoCode());
        saveObject.setKaijoName(shiyoKaijo.getKaijoName());
        saveObject.setKaijoNameRyaku(shiyoKaijo.getKaijoNameRyaku());
        saveObject.setYubinNo(shiyoKaijo.getYubinNo());
        saveObject.setJusho(shiyoKaijo.getJusho());
        saveObject.setTantoshaCode(shiyoKaijo.getTantoshaCode());
        saveObject.setNitteiFrom(shiyoKaijo.getNitteiFrom());
        saveObject.setNitteiTo(shiyoKaijo.getNitteiTo());
        saveObject.setTeiin(shiyoKaijo.getTeiin());
        saveObject.setGenzaiNinzu(shiyoKaijo.getGenzaiNinzu());
        saveObject.setBikoKaijo(shiyoKaijo.getBikoKaijo());
        saveObject.setBikoTanto(shiyoKaijo.getBikoTanto());
    }

    /**
     * ���̓`�F�b�N
     *
     * @param inSession �Z�b�V����RTO
     * @return true:�G���[��
     */
    private boolean validateInput(List<MstKanriShiyoKaijoJoho> shiyoKaijoList, MstKanriShiyoKaijoJoho inSession) {
        /* �ϐ������� */
        Messages errors = new Messages();
        String groupCode;
        String itemName;

        // �G���[�`�F�b�N�p���X�g�쐬
        String[] kaijoShikenKbns = {BmaConstants.KAIJO_SHIKEN_KBN_NASHI, BmaConstants.KAIJO_SHIKEN_KBN_GAKKA, BmaConstants.KAIJO_SHIKEN_KBN_ZITSUGI};

        for (int i = 0; i < shiyoKaijoList.size(); ++i) {
            MstKanriShiyoKaijoJoho shiyoKaijo = shiyoKaijoList.get(i);

            /* ��ꎎ���敪 */
            groupCode = "kaijoShikenKbn";
            itemName = "��ꎎ���敪";
            if (BmaValidator.validateSelect(shiyoKaijo.getKaijoShikenKbn(), errors, groupCode, itemName)) {
                BmaValidator.validatePermissionSelect(shiyoKaijo.getKaijoShikenKbn(), kaijoShikenKbns, errors, groupCode, itemName);
            }

            /* �S���҃R�[�h */
            groupCode = "tantosha";
            itemName = "�S����";
            BmaValidator.validateSelect(shiyoKaijo.getTantoshaCode(), errors, groupCode, itemName);

            /* ����From */
            groupCode = "nitteiFrom";
            // �N
            itemName = "�����QFROM�̔N";
            if (BmaValidator.validateRequired(shiyoKaijo.getFromYear(), errors, groupCode, itemName)) {
                if (BmaValidator.validateNumber(shiyoKaijo.getFromYear(), errors, groupCode, itemName)) {
                    BmaValidator.validateMaxLength(shiyoKaijo.getFromYear(), BmaConstants.EQUAL_LENGTH_SCHED_DATE_YEAR, errors, groupCode, itemName);
                }
            }
            // ��
            itemName = "�����QFROM�̌�";
            if (BmaValidator.validateRequired(shiyoKaijo.getFromMonth(), errors, groupCode, itemName)) {
                if (BmaValidator.validateNumber(shiyoKaijo.getFromMonth(), errors, groupCode, itemName)) {
                    BmaValidator.validateMaxLength(shiyoKaijo.getFromMonth(), BmaConstants.EQUAL_LENGTH_SCHED_DATE_MONTH, errors, groupCode, itemName);
                }
            }
            // ��
            itemName = "�����QFROM�̓�";
            if (BmaValidator.validateRequired(shiyoKaijo.getFromDate(), errors, groupCode, itemName)) {
                if (BmaValidator.validateNumber(shiyoKaijo.getFromDate(), errors, groupCode, itemName)) {
                    BmaValidator.validateMaxLength(shiyoKaijo.getFromDate(), BmaConstants.EQUAL_LENGTH_SCHED_DATE_DAY, errors, groupCode, itemName);
                }
            }
            // ���t�̐�����
            if (errors.isEmpty()) {
                itemName = "�����QFROM";
                BmaValidator.validateDate2(shiyoKaijo.getNitteiFrom(), errors, groupCode, itemName);
            }

            /* ����To */
            groupCode = "nitteiTo";
            // �N
            itemName = "�����QTO�̔N";
            if (BmaValidator.validateRequired(shiyoKaijo.getToYear(), errors, groupCode, itemName)) {
                if (BmaValidator.validateNumber(shiyoKaijo.getToYear(), errors, groupCode, itemName)) {
                    BmaValidator.validateMaxLength(shiyoKaijo.getToYear(), BmaConstants.EQUAL_LENGTH_SCHED_DATE_YEAR, errors, groupCode, itemName);
                }
            }
            // ��
            itemName = "�����QTO�̌�";
            if (BmaValidator.validateRequired(shiyoKaijo.getToMonth(), errors, groupCode, itemName)) {
                if (BmaValidator.validateNumber(shiyoKaijo.getToMonth(), errors, groupCode, itemName)) {
                    BmaValidator.validateMaxLength(shiyoKaijo.getToMonth(), BmaConstants.EQUAL_LENGTH_SCHED_DATE_MONTH, errors, groupCode, itemName);
                }
            }
            // ��
            itemName = "�����QTO�̓�";
            if (BmaValidator.validateRequired(shiyoKaijo.getToDate(), errors, groupCode, itemName)) {
                if (BmaValidator.validateNumber(shiyoKaijo.getToDate(), errors, groupCode, itemName)) {
                    BmaValidator.validateMaxLength(shiyoKaijo.getToDate(), BmaConstants.EQUAL_LENGTH_SCHED_DATE_DAY, errors, groupCode, itemName);
                }
            }
//             ���t�̐�����
            if (errors.isEmpty()) {
                itemName = "�����QTO";
                BmaValidator.validateDate2(shiyoKaijo.getNitteiTo(), errors, groupCode, itemName);
            }

            /* ��� */
            groupCode = "teiin";
            itemName = "���";
            if (BmaValidator.validateRequired(shiyoKaijo.getTeiin(), errors, groupCode, itemName)) {
                if (BmaValidator.validateMaxLength(shiyoKaijo.getTeiin(), BmaConstants.MAX_LENGTH_TEIIN, errors, groupCode, itemName)) {
                    BmaValidator.validateNumber(shiyoKaijo.getTeiin(), errors, groupCode, itemName);
                }
            }

            /* ���l�i���j */
            groupCode = "bikoKaijo";
            itemName = "���l�i���j";
            if (BmaValidator.validateMaxLength(shiyoKaijo.getBikoKaijo(), BmaConstants.MAX_LENGTH_BIKO_KAIJO, errors, groupCode, itemName)) {
                BmaValidator.validateMojiCodeForBiko(shiyoKaijo.getBikoKaijo(), errors, groupCode, itemName);
            }

            /* ���l�i�S���j */
            groupCode = "bikoTanto";
            itemName = "���l�i�S���j";
            if (BmaValidator.validateMaxLength(shiyoKaijo.getBikoTanto(), BmaConstants.MAX_LENGTH_BIKO_TANTO, errors, groupCode, itemName)) {
                BmaValidator.validateMojiCodeForBiko(shiyoKaijo.getBikoTanto(), errors, groupCode, itemName);
            }
        }
        inSession.setErrors(errors);
        return errors.isEmpty();
    }
}
