package jp.co.nii.bma.integration;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import jp.co.nii.bma.business.domain.MailTemplateDao;
import jp.co.nii.bma.business.rto.manager.MgrMailJoho;
import jp.co.nii.bma.business.service.common.BmaConstants;
import jp.co.nii.bma.utility.BmaDateTimeUtility;
import jp.co.nii.sew.common.LogGenerate;
import jp.co.nii.sew.integration.SQLStateSQLExceptionTranslater;
import jp.co.nii.sew.presentation.Option;

/**
 * ���[���e���v���[�g DAO�����N���X
 *
 * @author DB�Ǘ��c�[��
 */
public class MailTemplateDaoImpl extends GeneratedMailTemplateDaoImpl implements MailTemplateDao {

    /**
     * �C���X�^���X�𐶐�����B
     *
     * @param datasource �f�[�^�\�[�X��
     */
    public MailTemplateDaoImpl(String datasource) {
        super(datasource);
    }

    /**
     * ���[���e���v���[�g���X�g�擾
     *
     * @param inSession
     */
    @Override
    public List<MgrMailJoho> findTempList(MgrMailJoho inSession) {

        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = "";
        List<MgrMailJoho> resultList = new ArrayList<>();
        String max = String.valueOf(BmaConstants.MAX_DISP_NUM_MSK_JOHO_SEARCH_MAIL);

        String limit = "";

        limit = " LIMIT " + max;
        try {
            con = getConnection();
            sql = "SELECT " + FIELDS_DECRYPT
                    + " FROM " + getSchemaName() + "." + TABLE_NAME
                    + " WHERE " + " RONRI_SAKUJO_FLG = '0'"
                    + " AND " + " MAIL_TEMPLATE_IDX >= '0000000014'  "
                    + " ORDER BY MAIL_TEMPLATE_IDX ASC "
                    + limit;

            stmt = con.prepareStatement(sql);

            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();
            while (rs.next()) {
                MgrMailJoho mailJoho = new MgrMailJoho();

                mailJoho.setTmpMailId(rs.getString("MAIL_TEMPLATE_IDX"));
                mailJoho.setTmpName(rs.getString("MAIL_TEMPLATE_NAME"));
                mailJoho.setKenName(rs.getString("MAIL_KENMEI"));
                mailJoho.setKoshinDate(rs.getString("TOROKU_DATE") + rs.getString("TOROKU_TIME"));

                resultList.add(mailJoho);
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return resultList;
    }

    /**
     * ���[���e���v���[�g���X�g�擾
     *
     * inSession
     *
     * @param list
     */
    @Override
    public void findTempListSearch(List<Option> list) {

        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = "";

        //String max = String.valueOf(BmaConstants.MAX_DISP_NUM_MSK_JOHO_SEARCH_MAIL);
        String limit = "";

        limit = " LIMIT " + "100";
        try {
            con = getConnection();
            sql = "SELECT " + FIELDS_DECRYPT
                    + " FROM " + getSchemaName() + "." + TABLE_NAME
                    + " WHERE " + " RONRI_SAKUJO_FLG = '0'"
                    + " AND " + " MAIL_TEMPLATE_IDX >= '1000000001'  "
                    + " ORDER BY MAIL_TEMPLATE_IDX ASC "
                    + limit;

            stmt = con.prepareStatement(sql);

            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();

            while (rs.next()) {
                if (list != null) {
                    String time = rs.getString("KOSHIN_DATE") + rs.getString("KOSHIN_TIME");

                    time = BmaDateTimeUtility.formatYMDHMToDateSemiString(time);
                    String name = rs.getString("MAIL_KENMEI") + "(" + time + "�X�V)";

                    list.add(new Option(rs.getString("MAIL_TEMPLATE_IDX"), name));
                }

            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
    }

}
