package jp.co.nii.bma.business.rto.manager;

import java.util.ArrayList;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import jp.co.nii.bma.business.domain.Moshikomi;
import jp.co.nii.bma.business.service.common.BmaConstants;
import jp.co.nii.sew.presentation.DownloadRTO;
import jp.co.nii.sew.presentation.Messages;
import jp.co.nii.sew.presentation.Option;
import org.apache.commons.fileupload.disk.DiskFileItem;

/**
 *�^�C�g��: �\���f�[�^�A�b�v���[�h ����: �\�����RTO ���쌠: Copyright (c) 2020 ��Ж�: ���{���Y�Ɗ������
 * @author Luo-Yang
 */

public class NumKanriJoho extends DownloadRTO{


    private Messages errors;
    private String moshikomishaId;
     /**
     * 04�ԍ��Ǘ����
     */
    private String jknJkuNoFuyo;
    private String elearningKanri;
    private String gokakuNoFuyo;
     /**
     * 04-1�ԍ��Ǘ�_�󌟎�u�ԍ��A�b�v���[�h���
     */
    private String sknksuKbn; 
    private String sknName; 
    private String ksuName; 
    private String jknJkuNoFileChoice; 
    private String jknJkuNoTmpDl; 
    private String jknJkuNoUl; 
    private List<Option> sknKbnList;
    private List<Option> ksuKbnList;
    private String sknKsuCode;
    private String shubetsuCode;
    private String kaisuCode;
    private String nendo;
    private DiskFileItem fileData;
    private ArrayList<Moshikomi> resultDetailList;
    private String sknKsuNameChi;
 
    /**�@04-1-1�ԍ��Ǘ�_�󌟎�u�ԍ��m�F */
    private String jknJkuName; 
    private String jknJkuNoKakuninSeq; 
    private String uketukeNo; 
    private String simei; 
    private String jknJkuNo; 
    private String kaijoCode; 
    private String kaijoCode1;
    private String kaijoCode2;
    
    private String jknJkuNoKakuninBack; 
    private String jknJkuNoKakuninKakutei; 
    
    /**�@04-1-2�ԍ��Ǘ�_�󌟎�u�ԍ����� */
    private String jknJkuNoFuyoSknKsuName; 
    private String jknJkuNoFuyoKensu;
    
    /**
     * 04-2�ԍ��Ǘ�_���i�ԍ��A�b�v���[�h���
     */
    private String gokakuNoTmpDl; 
    private String gokakuNoUl; 
    
    
    /**�@04-2-1�ԍ��Ǘ�_���i�ԍ��m�F */
    private String gokakuNoKakuninSeq; 
    private String gokakuNoKakuninSimei; 
    private String shikenShubetu; 
    private String shikenShukketsu; 
    private String shikenTokuten; 
    private String shikenShubetu2; 
    private String shikenShukketsu2; 
    private String shikenTokuten2; 
    private String shikenShubetu3; 
    private String shikenShukketsu3; 
    private String shikenTokuten3; 
    private String gohi; 
    private String gokakuTsuchiNo; 
    private String ginoshiNo; 
    private String gokakuNoKakuninBack;
    private String gokakuNoKakuninKakutei;
    private String gokakuNo;
    private String gakkaGokakuNo;
    private String jitsugiGokakuNo;
    private String shikakuNo;
    private String gokakuBi;
    
    /**�@04-2-2�ԍ��Ǘ�_���i�ԍ����� */
    private String gokakuNoFuyoSknKsuName; 
    private String gokakuNoFuyoKensu; 
    
    /**�@���j���[��ʁ@�u�ԍ��Ǘ��v�{�^��*/
    private String bangoKanri; 
    
    /** ��u�󌱔ԍ��m�F��ʁ@���X�g*/
    private List<NumKanriJoho> numJkoJknList;
    /** ���i�ԍ��m�F��ʁ@���X�g*/
    private List<NumKanriJoho> numGokakuList;
    // �G���[���X�g
    private List<NumKanriJoho> errorLog;
    
    private String systemTime;
    private String lineNo;
    private String columnNo;
    private String itemName;
    private String message;
    private String errorLogFlg;
    
     /**
     * �R���X�g���N�^
     */
    public NumKanriJoho() {
        clearInfo();
    }
    
    /**
     * ���������\�b�h
     */
    public void clearInfo() {
        setErrors(new Messages());
        setMoshikomishaId("");
        /** 04�ԍ��Ǘ���� */
        setJknJkuNoFuyo("");
        setElearningKanri("");
        setGokakuNoFuyo("");
        
        /** 04-1�ԍ��Ǘ�_�󌟎�u�ԍ��A�b�v���[�h */
        setSknksuKbn("1");
        setSknName(BmaConstants.SKN_CHECK);
        setKsuName(BmaConstants.KSU_CHECK);
        setJknJkuNoFileChoice("");
        setJknJkuNoTmpDl("");
        setJknJkuNoUl("");
        setSknKsuNameChi("");
        
        /**�@04-1-1�ԍ��Ǘ�_�󌟎�u�ԍ��m�F */
        setJknJkuName("");
        setJknJkuNoKakuninSeq("");
        setUketukeNo("");
        setSimei("");
        setJknJkuNo("");
        setKaijoCode("");
        setKaijoCode1("");
        setKaijoCode2("");
        setJknJkuNoKakuninBack("");
        setJknJkuNoKakuninKakutei("");
         
        /**�@04-1-2�ԍ��Ǘ�_�󌟎�u�ԍ����� */
        setJknJkuNoFuyoSknKsuName("");
        setJknJkuNoFuyoKensu("");
         
        /** 04-2�ԍ��Ǘ�_���i�ԍ��A�b�v���[�h */ 
        setGokakuNoTmpDl("");
        setGokakuNoUl("");
        /**�@04-2-1�ԍ��Ǘ�_���i�ԍ��m�F */
        setGokakuNoKakuninSeq("");
        setGokakuNoKakuninSimei("");
        setShikenShubetu("");
        setShikenShukketsu("");
        setShikenTokuten("");
        setGohi("");
        setGokakuTsuchiNo("");
        setGinoshiNo("");
        setGokakuNoKakuninBack("");
         
        /**�@04-2-2�ԍ��Ǘ�_���i�ԍ����� */
        setGokakuNoFuyoSknKsuName("");
        setGokakuNoFuyoKensu("");
         
        /**�@���j���[��ʁ@�u�ԍ��Ǘ��v�{�^��*/
        setBangoKanri("");
        
        setErrorLogFlg("");
        
        /** ��u�󌱔ԍ��m�F��ʁ@���X�g*/
        setNumJkoJknList(new ArrayList<>());
        /** ���i�ԍ��m�F��ʁ@���X�g*/
        setNumGokakuList(new ArrayList<>());
    }
    
     /**
     * ���N�G�X�g��������擾���郁�\�b�h
     *
     * @param request ���N�G�X�g
     */
    @Override
    public void copyFromRequest(HttpServletRequest request) {        
        setMoshikomishaId((String) request.getAttribute("moshikomishaId"));
        /** 04�ԍ��Ǘ���� */
        setJknJkuNoFuyo((String) request.getAttribute("jknJkuNoFuyo")); 
        setElearningKanri((String) request.getAttribute("elearningKanri")); 
        setGokakuNoFuyo((String) request.getAttribute("gokakuNoFuyo")); 
        
        /** 04-1�ԍ��Ǘ�_�󌟎�u�ԍ��A�b�v���[�h */
        setSknksuKbn((String) request.getAttribute("sknksuKbn"));
        setSknName((String) request.getAttribute("sknName"));
        setKsuName((String) request.getAttribute("ksuName"));
        setJknJkuNoFileChoice((String) request.getAttribute("jknJkuNoFileChoice"));
        setJknJkuNoTmpDl((String) request.getAttribute("jknJkuNoTmpDl"));
        setJknJkuNoUl((String) request.getAttribute("jknJkuNoUl"));
        setFileData((DiskFileItem) request.getAttribute("fileData"));
        setSknKsuNameChi((String) request.getAttribute("sknKsuNameChi"));
        
        /**�@04-1-1�ԍ��Ǘ�_�󌟎�u�ԍ��m�F */
        setJknJkuName((String) request.getAttribute("jknJkuName")); 
        setJknJkuNoKakuninSeq((String) request.getAttribute("jknJkuNoKakuninSeq")); 
        setUketukeNo((String) request.getAttribute("uketukeNo")); 
        setSimei((String) request.getAttribute("simei")); 
        setJknJkuNo((String) request.getAttribute("jknJkuNo")); 
        setKaijoCode((String) request.getAttribute("kaijoCode")); 
        setKaijoCode1((String) request.getAttribute("kaijoCode1")); 
        setKaijoCode2((String) request.getAttribute("kaijoCode2")); 
        setJknJkuNoKakuninBack((String) request.getAttribute("jknJkuNoKakuninBack")); 
        setJknJkuNoKakuninKakutei((String) request.getAttribute("jknJkuNoKakuninKakutei")); 
        
        /**�@04-1-2�ԍ��Ǘ�_�󌟎�u�ԍ����� */
        setJknJkuNoFuyoSknKsuName((String) request.getAttribute("jknJkuNoFuyoSknKsuName")); 
        setJknJkuNoFuyoKensu((String) request.getAttribute("jknJkuNoFuyoKensu")); 
         
        /** 04-1�ԍ��Ǘ�_���i�ԍ��A�b�v���[�h */
        setGokakuNoTmpDl((String) request.getAttribute("gokakuNoTmpDl"));
        setGokakuNoUl((String) request.getAttribute("gokakuNoUl"));
         
        /**�@04-2-1�ԍ��Ǘ�_���i�ԍ��m�F */
        setGokakuNoKakuninSeq((String) request.getAttribute("gokakuNoKakuninSeq")); 
        setGokakuNoKakuninSimei((String) request.getAttribute("gokakuNoKakuninSimei")); 
        setShikenShubetu((String) request.getAttribute("shikenShubetu")); 
        setShikenShukketsu((String) request.getAttribute("shikenShukketsu")); 
        setShikenTokuten((String) request.getAttribute("shikenTokuten")); 
        setGohi((String) request.getAttribute("gohi")); 
        setGokakuTsuchiNo((String) request.getAttribute("gokakuTsuchiNo")); 
        setGinoshiNo((String) request.getAttribute("ginoshiNo")); 
        setGokakuNoKakuninBack((String) request.getAttribute("gokakuNoKakuninBack"));
        setGokakuNoKakuninKakutei((String) request.getAttribute("gokakuNoKakuninKakutei"));
          
        /**�@04-2-2�ԍ��Ǘ�_���i�ԍ����� */
        setGokakuNoFuyoSknKsuName((String) request.getAttribute("gokakuNoFuyoSknKsuName")); 
        setGokakuNoFuyoKensu((String) request.getAttribute("gokakuNoFuyoKensu")); 
         
        /**�@���j���[��ʁ@�u�ԍ��Ǘ��v�{�^��*/
        setBangoKanri((String) request.getAttribute("bangoKanri"));
        
        setErrorLogFlg((String) request.getAttribute("errorLogFlg"));
          
        HttpSession session = request.getSession(false);
        if (session.getAttribute("MgrTopJoho") != null) {
            MgrTopJoho tmp = (MgrTopJoho) session.getAttribute("MgrTopJoho");
            setMoshikomishaId(tmp.getMoshikomishaId());
            //�N�x
            
        }
    }
    
    public Messages getErrors() {
        return errors;
    }

    public void setErrors(Messages errors) {
        this.errors = errors;
    }
    
    /**
     * @return the moshikomishaId
     */
    public String getMoshikomishaId() {
        return moshikomishaId;
    }

    /**
     * @param moshikomishaId the moshikomishaId to set
     */
    public void setMoshikomishaId(String moshikomishaId) {
        this.moshikomishaId = moshikomishaId;
    }

    public String getJknJkuNoFuyo() {
        return jknJkuNoFuyo;
    }

    public void setJknJkuNoFuyo(String jknJkuNoFuyo) {
        this.jknJkuNoFuyo = jknJkuNoFuyo;
    }

    public String getElearningKanri() {
        return elearningKanri;
    }

    public void setElearningKanri(String elearningKanri) {
        this.elearningKanri = elearningKanri;
    }

    public String getGokakuNoFuyo() {
        return gokakuNoFuyo;
    }

    public void setGokakuNoFuyo(String gokakuNoFuyo) {
        this.gokakuNoFuyo = gokakuNoFuyo;
    }

    public String getSknksuKbn() {
        return sknksuKbn;
    }

    public void setSknksuKbn(String sknksuKbn) {
        this.sknksuKbn = sknksuKbn;
    }

    public String getSknName() {
        return sknName;
    }

    public void setSknName(String sknName) {
        this.sknName = sknName;
    }

    public String getKsuName() {
        return ksuName;
    }

    public void setKsuName(String ksuName) {
        this.ksuName = ksuName;
    }
    
    public String getBangoKanri() {
        return bangoKanri;
    }

    public void setBangoKanri(String bangoKanri) {
        this.bangoKanri = bangoKanri;
    }

    public String getJknJkuName() {
        return jknJkuName;
    }

    public void setJknJkuName(String jknJkuName) {
        this.jknJkuName = jknJkuName;
    }

    public String getJknJkuNoTmpDl() {
        return jknJkuNoTmpDl;
    }

    public void setJknJkuNoTmpDl(String jknJkuNoTmpDl) {
        this.jknJkuNoTmpDl = jknJkuNoTmpDl;
    }

    public String getUketukeNo() {
        return uketukeNo;
    }

    public void setUketukeNo(String uketukeNo) {
        this.uketukeNo = uketukeNo;
    }

    public String getSimei() {
        return simei;
    }

    public void setSimei(String simei) {
        this.simei = simei;
    }

    public String getJknJkuNo() {
        return jknJkuNo;
    }

    public void setJknJkuNo(String jknJkuNo) {
        this.jknJkuNo = jknJkuNo;
    }

    public String getKaijoCode() {
        return kaijoCode;
    }

    public void setKaijoCode(String kaijoCode) {
        this.kaijoCode = kaijoCode;
    }

    public String getJknJkuNoKakuninBack() {
        return jknJkuNoKakuninBack;
    }

    public void setJknJkuNoKakuninBack(String jknJkuNoKakuninBack) {
        this.jknJkuNoKakuninBack = jknJkuNoKakuninBack;
    }

    public String getJknJkuNoKakuninKakutei() {
        return jknJkuNoKakuninKakutei;
    }

    public void setJknJkuNoKakuninKakutei(String jknJkuNoKakuninKakutei) {
        this.jknJkuNoKakuninKakutei = jknJkuNoKakuninKakutei;
    }

    public String getJknJkuNoFileChoice() {
        return jknJkuNoFileChoice;
    }

    public void setJknJkuNoFileChoice(String jknJkuNoFileChoice) {
        this.jknJkuNoFileChoice = jknJkuNoFileChoice;
    }

    public String getJknJkuNoUl() {
        return jknJkuNoUl;
    }

    public void setJknJkuNoUl(String jknJkuNoUl) {
        this.jknJkuNoUl = jknJkuNoUl;
    }

    public String getJknJkuNoKakuninSeq() {
        return jknJkuNoKakuninSeq;
    }

    public void setJknJkuNoKakuninSeq(String jknJkuNoKakuninSeq) {
        this.jknJkuNoKakuninSeq = jknJkuNoKakuninSeq;
    }

    public List<NumKanriJoho> getNumJkoJknList() {
        return numJkoJknList;
    }

    public void setNumJkoJknList(List<NumKanriJoho> numJkoJknList) {
        this.numJkoJknList = numJkoJknList;
    }

    public String getJknJkuNoFuyoSknKsuName() {
        return jknJkuNoFuyoSknKsuName;
    }

    public void setJknJkuNoFuyoSknKsuName(String jknJkuNoFuyoSknKsuName) {
        this.jknJkuNoFuyoSknKsuName = jknJkuNoFuyoSknKsuName;
    }

    public String getJknJkuNoFuyoKensu() {
        return jknJkuNoFuyoKensu;
    }

    public void setJknJkuNoFuyoKensu(String jknJkuNoFuyoKensu) {
        this.jknJkuNoFuyoKensu = jknJkuNoFuyoKensu;
    }

    public String getGokakuNoKakuninSeq() {
        return gokakuNoKakuninSeq;
    }

    public void setGokakuNoKakuninSeq(String gokakuNoKakuninSeq) {
        this.gokakuNoKakuninSeq = gokakuNoKakuninSeq;
    }

    public String getGokakuNoKakuninSimei() {
        return gokakuNoKakuninSimei;
    }

    public void setGokakuNoKakuninSimei(String gokakuNoKakuninSimei) {
        this.gokakuNoKakuninSimei = gokakuNoKakuninSimei;
    }

    public String getShikenShubetu() {
        return shikenShubetu;
    }

    public void setShikenShubetu(String shikenShubetu) {
        this.shikenShubetu = shikenShubetu;
    }

    public String getShikenShukketsu() {
        return shikenShukketsu;
    }

    public void setShikenShukketsu(String shikenShukketsu) {
        this.shikenShukketsu = shikenShukketsu;
    }

    public String getShikenTokuten() {
        return shikenTokuten;
    }

    public void setShikenTokuten(String shikenTokuten) {
        this.shikenTokuten = shikenTokuten;
    }

    public String getGohi() {
        return gohi;
    }

    public void setGohi(String gohi) {
        this.gohi = gohi;
    }

    public String getGokakuTsuchiNo() {
        return gokakuTsuchiNo;
    }

    public void setGokakuTsuchiNo(String gokakuTsuchiNo) {
        this.gokakuTsuchiNo = gokakuTsuchiNo;
    }

    public String getGinoshiNo() {
        return ginoshiNo;
    }

    public void setGinoshiNo(String ginoshiNo) {
        this.ginoshiNo = ginoshiNo;
    }

    public String getGokakuNoKakuninBack() {
        return gokakuNoKakuninBack;
    }

    public void setGokakuNoKakuninBack(String gokakuNoKakuninBack) {
        this.gokakuNoKakuninBack = gokakuNoKakuninBack;
    }

    public String getGokakuNoFuyoSknKsuName() {
        return gokakuNoFuyoSknKsuName;
    }

    public void setGokakuNoFuyoSknKsuName(String gokakuNoFuyoSknKsuName) {
        this.gokakuNoFuyoSknKsuName = gokakuNoFuyoSknKsuName;
    }

    public String getGokakuNoFuyoKensu() {
        return gokakuNoFuyoKensu;
    }

    public void setGokakuNoFuyoKensu(String gokakuNoFuyoKensu) {
        this.gokakuNoFuyoKensu = gokakuNoFuyoKensu;
    }

    public String getShikenShukketsu2() {
        return shikenShukketsu2;
    }

    public void setShikenShukketsu2(String shikenShukketsu2) {
        this.shikenShukketsu2 = shikenShukketsu2;
    }

    public String getShikenTokuten2() {
        return shikenTokuten2;
    }

    public void setShikenTokuten2(String shikenTokuten2) {
        this.shikenTokuten2 = shikenTokuten2;
    }

    public String getShikenShukketsu3() {
        return shikenShukketsu3;
    }

    public void setShikenShukketsu3(String shikenShukketsu3) {
        this.shikenShukketsu3 = shikenShukketsu3;
    }

    public String getShikenTokuten3() {
        return shikenTokuten3;
    }

    public void setShikenTokuten3(String shikenTokuten3) {
        this.shikenTokuten3 = shikenTokuten3;
    }

    public String getShikenShubetu2() {
        return shikenShubetu2;
    }

    public void setShikenShubetu2(String shikenShubetu2) {
        this.shikenShubetu2 = shikenShubetu2;
    }

    public String getShikenShubetu3() {
        return shikenShubetu3;
    }

    public void setShikenShubetu3(String shikenShubetu3) {
        this.shikenShubetu3 = shikenShubetu3;
    }
    
    public List<NumKanriJoho> getNumGokakuList() {
        return numGokakuList;
    }

    public void setNumGokakuList(List<NumKanriJoho> numGokakuList) {
        this.numGokakuList = numGokakuList;
    }
    
    /**
     * @return the sknKbnList
     */
    public List<Option> getSknKbnList() {
        return sknKbnList;
    }

    /**
     * @param sknKbnList the sknKbnList to set
     */
    public void setSknKbnList(List<Option> sknKbnList) {
        this.sknKbnList = sknKbnList;
    }

    /**
     * @return the ksuKbnList
     */
    public List<Option> getKsuKbnList() {
        return ksuKbnList;
    }

    /**
     * @param ksuKbnList the ksuKbnList to set
     */
    public void setKsuKbnList(List<Option> ksuKbnList) {
        this.ksuKbnList = ksuKbnList;
    }
    
    /**
     * @return the sknKsuCode
     */
    public String getSknKsuCode() {
        return sknKsuCode;
    }

    /**
     * @param sknKsuCode the sknKsuCode to set
     */
    public void setSknKsuCode(String sknKsuCode) {
        this.sknKsuCode = sknKsuCode;
    }

    /**
     * @return the shubetsuCode
     */
    public String getShubetsuCode() {
        return shubetsuCode;
    }

    /**
     * @param shubetsuCode the shubetsuCode to set
     */
    public void setShubetsuCode(String shubetsuCode) {
        this.shubetsuCode = shubetsuCode;
    }

    /**
     * @return the kaisuCode
     */
    public String getKaisuCode() {
        return kaisuCode;
    }

    /**
     * @param kaisuCode the kaisuCode to set
     */
    public void setKaisuCode(String kaisuCode) {
        this.kaisuCode = kaisuCode;
    }

    /**
     * @return the nendo
     */
    public String getNendo() {
        return nendo;
    }

    /**
     * @param nendo the nendo to set
     */
    public void setNendo(String nendo) {
        this.nendo = nendo;
    }
    
    /**
     * @return the fileData
     */
    public DiskFileItem getFileData() {
        return fileData;
    }

    /**
     * @param fileData the fileData to set
     */
    public void setFileData(DiskFileItem fileData) {
        this.fileData = fileData;
    }
    
    /**
     * @return the resultDetailList
     */
    public ArrayList<Moshikomi> getResultDetailList() {
        return resultDetailList;
    }

    /**
     * @param resultDetailList the resultDetailList to set
     */
    public void setResultDetailList(ArrayList<Moshikomi> resultDetailList) {
        this.resultDetailList = resultDetailList;
    }
    
    /**
     * @return the sknKsuNameChi
     */
    public String getSknKsuNameChi() {
        return sknKsuNameChi;
    }

    /**
     * @param sknKsuNameChi the sknKsuNameChi to set
     */
    public void setSknKsuNameChi(String sknKsuNameChi) {
        this.sknKsuNameChi = sknKsuNameChi;
    }
    
    /**
     * @return the kaijoCode1
     */
    public String getKaijoCode1() {
        return kaijoCode1;
    }

    /**
     * @param kaijoCode1 the kaijoCode1 to set
     */
    public void setKaijoCode1(String kaijoCode1) {
        this.kaijoCode1 = kaijoCode1;
    }

    /**
     * @return the kaijoCode2
     */
    public String getKaijoCode2() {
        return kaijoCode2;
    }

    /**
     * @param kaijoCode2 the kaijoCode2 to set
     */
    public void setKaijoCode2(String kaijoCode2) {
        this.kaijoCode2 = kaijoCode2;
    }
    
    
    /**
     * @return the gokakuNoTmpDl
     */
    public String getGokakuNoTmpDl() {
        return gokakuNoTmpDl;
    }

    /**
     * @param gokakuNoTmpDl the gokakuNoTmpDl to set
     */
    public void setGokakuNoTmpDl(String gokakuNoTmpDl) {
        this.gokakuNoTmpDl = gokakuNoTmpDl;
    }

    /**
     * @return the gokakuNoUl
     */
    public String getGokakuNoUl() {
        return gokakuNoUl;
    }

    /**
     * @param gokakuNoUl the gokakuNoUl to set
     */
    public void setGokakuNoUl(String gokakuNoUl) {
        this.gokakuNoUl = gokakuNoUl;
    }
    
    
    /**
     * @return the gokakuNoKakuninKakutei
     */
    public String getGokakuNoKakuninKakutei() {
        return gokakuNoKakuninKakutei;
    }

    /**
     * @param gokakuNoKakuninKakutei the gokakuNoKakuninKakutei to set
     */
    public void setGokakuNoKakuninKakutei(String gokakuNoKakuninKakutei) {
        this.gokakuNoKakuninKakutei = gokakuNoKakuninKakutei;
    }
    
    
    /**
     * @return the gokakuNo
     */
    public String getGokakuNo() {
        return gokakuNo;
    }

    /**
     * @param gokakuNo the gokakuNo to set
     */
    public void setGokakuNo(String gokakuNo) {
        this.gokakuNo = gokakuNo;
    }

    /**
     * @return the gakkaGokakuNo
     */
    public String getGakkaGokakuNo() {
        return gakkaGokakuNo;
    }

    /**
     * @param gakkaGokakuNo the gakkaGokakuNo to set
     */
    public void setGakkaGokakuNo(String gakkaGokakuNo) {
        this.gakkaGokakuNo = gakkaGokakuNo;
    }

    /**
     * @return the jitsugiGokakuNo
     */
    public String getJitsugiGokakuNo() {
        return jitsugiGokakuNo;
    }

    /**
     * @param jitsugiGokakuNo the jitsugiGokakuNo to set
     */
    public void setJitsugiGokakuNo(String jitsugiGokakuNo) {
        this.jitsugiGokakuNo = jitsugiGokakuNo;
    }

    /**
     * @return the shikakuNo
     */
    public String getShikakuNo() {
        return shikakuNo;
    }

    /**
     * @param shikakuNo the shikakuNo to set
     */
    public void setShikakuNo(String shikakuNo) {
        this.shikakuNo = shikakuNo;
    }

    /**
     * @return the gokakuBi
     */
    public String getGokakuBi() {
        return gokakuBi;
    }

    /**
     * @param gokakuBi the gokakuBi to set
     */
    public void setGokakuBi(String gokakuBi) {
        this.gokakuBi = gokakuBi;
    }
    
    /**
     * @return the errorLog
     */
    public List<NumKanriJoho> getErrorLog() {
        return errorLog;
    }

    /**
     * @param errorLog the errorLog to set
     */
    public void setErrorLog(List<NumKanriJoho> errorLog) {
        this.errorLog = errorLog;
    }
    
    /**
     * @return the systemTime
     */
    public String getSystemTime() {
        return systemTime;
    }

    /**
     * @param systemTime the systemTime to set
     */
    public void setSystemTime(String systemTime) {
        this.systemTime = systemTime;
    }

    /**
     * @return the lineNo
     */
    public String getLineNo() {
        return lineNo;
    }

    /**
     * @param lineNo the lineNo to set
     */
    public void setLineNo(String lineNo) {
        this.lineNo = lineNo;
    }

    /**
     * @return the columnNo
     */
    public String getColumnNo() {
        return columnNo;
    }

    /**
     * @param columnNo the columnNo to set
     */
    public void setColumnNo(String columnNo) {
        this.columnNo = columnNo;
    }

    /**
     * @return the itemName
     */
    public String getItemName() {
        return itemName;
    }

    /**
     * @param itemName the itemName to set
     */
    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    /**
     * @return the message
     */
    public String getMessage() {
        return message;
    }

    /**
     * @param message the message to set
     */
    public void setMessage(String message) {
        this.message = message;
    }

    /**
     * @return the errorLogFlg
     */
    public String getErrorLogFlg() {
        return errorLogFlg;
    }

    /**
     * @param errorLogFlg the errorLogFlg to set
     */
    public void setErrorLogFlg(String errorLogFlg) {
        this.errorLogFlg = errorLogFlg;
    }
    
}
