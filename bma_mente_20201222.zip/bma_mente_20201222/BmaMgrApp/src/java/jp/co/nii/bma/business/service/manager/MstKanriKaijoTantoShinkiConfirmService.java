package jp.co.nii.bma.business.service.manager;

import jp.co.nii.bma.business.domain.KaijoTantoMst;
import jp.co.nii.bma.business.rto.manager.MstKanriKaijoTantoJoho;
import jp.co.nii.bma.business.service.common.BmaConstants;
import jp.co.nii.bma.business.service.common.BmaLogger;
import jp.co.nii.bma.business.service.common.BmaValidator;
import jp.co.nii.bma.presentation.common.BmaText;
import jp.co.nii.bma.utility.BmaUtility;
import jp.co.nii.sew.business.SystemTime;
import jp.co.nii.sew.business.service.AbstractService;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_SUCCESS;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_RELOAD;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_BACK;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_EXCEPTION;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_SESSION;
import jp.co.nii.sew.presentation.Messages;
import jp.co.nii.sew.presentation.RequestTransferObject;
import jp.co.nii.sew.utility.PropertyUtility;

/**
 *
 * @author nii19042
 */
public class MstKanriKaijoTantoShinkiConfirmService extends AbstractService {

    /**
     * DB�ڑ��̃f�[�^�\�[�X
     */
    private static String DATA_SOURCE_NAME;
    /**
     * ���O
     */
    BmaLogger log = (BmaLogger) BmaLogger.getLogger(this.getClass().getName());
    /**
     * �Ɩ��R�[�h
     */
    private static final String BUSINESS_CODE = PropertyUtility.getProperty("business_code");
    /**
     * ���׃e�X�g���[�h
     */
    private static final String STRESS_MODE = PropertyUtility.getProperty(BUSINESS_CODE + "stress_mode");

    /**
     * �R���X�g���N�^
     */
    public MstKanriKaijoTantoShinkiConfirmService() {
        super();
        /* DB�ڑ����̃��[�U�[������ */
        DATA_SOURCE_NAME = BmaConstants.DS_REGISTRANT;
    }

    /**
     * �T�[�r�X�N���X�̎��s���\�b�h
     *
     * @param rto ���N�G�X�g��񂩂�擾����rto
     * @param rtoInSession �Z�b�V�������rto
     * @return foward��
     * @throws Exception ��O
     */
    @Override
    public String doService(RequestTransferObject rto, RequestTransferObject rtoInSession)
            throws Exception {

        MstKanriKaijoTantoJoho inRequest = (MstKanriKaijoTantoJoho) rto;
        MstKanriKaijoTantoJoho inSession = (MstKanriKaijoTantoJoho) rtoInSession;
        String processName = "";

        /* �G���[���b�Z�[�W������ */
        inSession.setErrors(new Messages());

        try {
            if (!BmaUtility.isNullOrEmpty(inRequest.getKaijoTantoInpComp())) {
                /*�u�m��v�{�^�������� */
                processName = "MstKanriKaijoTantoShinkiConfirm_Complete";
                log.Start(processName);

                /* ��L�[�擾 */
                KaijoTantoMst tantoInp = new KaijoTantoMst(DATA_SOURCE_NAME);
                String kaisaichiCode = inSession.getKaisaichiCode();
                String kaijoCode = inSession.getKaijoCode();

                /* ���͒l�`�F�b�N */
                if(!validateInput(inSession)){
                    // �G���[���������ꍇ�u���S���҃}�X�^�V�K�o�^�m�F�v���Reload
                    return FWD_NM_RELOAD;
                } else {
                    try {
                        /* �g�����U�N�V�����擾&�J�n */
                        getTransaction();
                        beginTransaction();

                        /* �J�Òn�R�[�h�A���R�[�h��薖���̉��S���҃R�[�h���擾 */
                        String lastTantoCode  = tantoInp.findLastTantoshaCode(kaisaichiCode, kaijoCode);

                        /* �擾�����S���҃R�[�h�����ƂɁA�o�^����S���҃R�[�h��ݒ� */
                        if (!BmaUtility.isNullOrEmpty(lastTantoCode)) {
                            int tantoCodeInt = Integer.parseInt(lastTantoCode) + 1;
                            String tantoCodeStr = String.valueOf(tantoCodeInt);

                            if (tantoCodeStr.length() < 2) {
                                // 1���̏ꍇ�A�O�[����ǉ����ēo�^
                                tantoInp.setTantoshaCode("0" + tantoCodeStr);
                            } else if (tantoCodeStr.length() > 2) {
                                // 3���ȏ�̏ꍇ�u���S���҃}�X�^�V�K�o�^�m�F�v���Reload */
                                Messages errors = new Messages();
                                BmaValidator.addMessage(errors, "kaijoTantoData", BmaText.E00121);
                                inSession.setErrors(errors);
                                return FWD_NM_RELOAD;
                            } else {
                                // ���̑��͖���+1��S���҃R�[�h�ɓo�^
                                tantoInp.setTantoshaCode(tantoCodeStr);
                            }
                        // null �̏ꍇ�A�擪��01��o�^
                        } else {
                            tantoInp.setTantoshaCode("01");
                        }

                        /* �V�X�e���������擾 */
                        SystemTime sysTime = new SystemTime();

                        /* �o�^�������S���҃}�X�^�ɃZ�b�g */ 
                        tantoInp.setKaisaichiCode(inSession.getKaisaichiCode());
                        tantoInp.setKaijoCode(inSession.getKaijoCode());
                        tantoInp.setTantosha(inSession.getTantosha());
                        tantoInp.setTantoBusho(inSession.getTantoBusho());
                        tantoInp.setTelNo(inSession.getTelNo());
                        tantoInp.setFaxNo(inSession.getFaxNo());
                        tantoInp.setTantoshaMailAddress(inSession.getTantoshaMailAddress());
                        tantoInp.setBiko(inSession.getBiko());

                        /* DB���ʍ��ڃZ�b�g */
                        tantoInp.setKoshinKbn(BmaConstants.SHORI_KBN_INSERT);
                        tantoInp.setTorokuDate(sysTime.getymd1());
                        tantoInp.setTorokuTime(sysTime.gethms1());
                        tantoInp.setTorokuUserId(inRequest.getMoshikomishaId());
                        tantoInp.setKoshinDate("");
                        tantoInp.setKoshinTime("");
                        tantoInp.setKoshinUserId("");
                        tantoInp.setRonriSakujoFlg(BmaConstants.FLG_OFF);

                        tantoInp.create();
                        /* �R�~�b�g */
                        commitTransaction();
                    } catch (Exception ex) {
                        ex.printStackTrace();
                        // ���[���o�b�N
                        rollbackTransaction();
                        return FWD_NM_SESSION;
                    }

                /* �u���S���҃}�X�^�V�K�o�^�����v��ʕ\�� */
                return FWD_NM_SUCCESS;
                }

        } else if (!BmaUtility.isNullOrEmpty(inRequest.getKaijoTantoInpConfBack())) {
                /*�u�����v�{�^�������� */
                processName = "MstKanriKaijoTantoShinkiConfirm_BackKaijoTantoShinkiInput";
                log.Start(processName);

                /* �u���S���҃}�X�^�V�K�o�^�v��ʕ\�� */
                return FWD_NM_BACK;

        } else {
                /* �ُ�J�� */
                log.IllegalFWD();
                return FWD_NM_SESSION;
            }
        } catch (Exception e) {
            return FWD_NM_EXCEPTION;
        } finally {
            log.End(processName);
        }
    }

    /**
     * ���̓`�F�b�N
     *
     * @param inSession �Z�b�V����RTO
     * @return true:�G���[��
     */
    private boolean validateInput(MstKanriKaijoTantoJoho inSession) {
        /* �ϐ������� */
        Messages errors = new Messages();
        String groupCode;
        String itemName;

        // �G���[�`�F�b�N�p���X�g�쐬
        String[] zeiKbns = {BmaConstants.ZEI_KBN_ZEINUKI, BmaConstants.ZEI_KBN_ZEIKOMI};

        /* �J�Òn�R�[�h */
        groupCode = "kaisaichiCode";
        itemName = "�J�Òn�R�[�h";
        if (BmaValidator.validateSelect(inSession.getKaisaichiCode(), errors, groupCode, itemName)) {
            BmaValidator.validatePermissionSelect(inSession.getKaisaichiCode(), inSession.getKaisaichiList(), errors, groupCode, itemName);
        }

        /* ���R�[�h */
        groupCode = "kaijoCode";
        itemName = "���R�[�h";
        if (BmaValidator.validateSelect(inSession.getKaijoCode(), errors, groupCode, itemName)) {
            BmaValidator.validatePermissionSelect(inSession.getKaijoCode(), inSession.getKaijoByKaisaichiList(), errors, groupCode, itemName);
        }

        /* �S���� */
        groupCode = "tantosha";
        itemName = "�S����";
        if (BmaValidator.validateRequired(inSession.getTantosha(), errors, groupCode, itemName)) {
            if (BmaValidator.validateMaxLength(inSession.getTantosha(), BmaConstants.MAX_LENGTH_TANTOSHA, errors, groupCode, itemName)) {
                BmaValidator.validateMojiCode3(inSession.getTantosha(), errors, groupCode, itemName);
            }
        }

        /* �S������ */
        groupCode = "tantoBusho";
        itemName = "�S������";
        if (BmaValidator.validateMaxLength(inSession.getTantoBusho(), BmaConstants.MAX_LENGTH_TANTOBUSHO, errors, groupCode, itemName)) {
            BmaValidator.validateMojiCode3(inSession.getTantoBusho(), errors, groupCode, itemName);
        }

        /* �d�b�ԍ� */
        groupCode = "telNo";
        itemName = "�d�b�ԍ�";
        if (BmaValidator.validateRequired(inSession.getTelNo(), errors, groupCode, itemName)) {
            if (BmaValidator.validateNumber(inSession.getTelNo(), errors, groupCode, itemName)) {
                BmaValidator.validateRangeLength(inSession.getTelNo(), BmaConstants.MIN_LENGTH_TEL_NO, BmaConstants.MAX_LENGTH_TEL_NO, errors, groupCode, itemName);
            }
        }

        /* FAX�ԍ� */
        groupCode = "faxNo";
        itemName = "FAX�ԍ�";
        if (BmaValidator.validateNumber(inSession.getFaxNo(), errors, groupCode, itemName)) {
            BmaValidator.validateRangeLength(inSession.getFaxNo(), BmaConstants.MIN_LENGTH_FAX_NO, BmaConstants.MAX_LENGTH_FAX_NO, errors, groupCode, itemName);
        }

        /* �S���҃��[���A�h���X */
        groupCode = "tantoshaMailAddress";
        itemName = "�S���҃��[���A�h���X";
        if (BmaValidator.validateMaxLength(inSession.getTantoshaMailAddress(), BmaConstants.MAX_LENGTH_TANTOSHA_MAILADDRESS, errors, groupCode, itemName)) {
            BmaValidator.validateEmail(inSession.getTantoshaMailAddress(), errors, groupCode, itemName);
        }

        /* ���l */
        groupCode = "biko";
        itemName = "���l";
        if (BmaValidator.validateMaxLength(inSession.getBiko(), BmaConstants.MAX_LENGTH_BIKO, errors, groupCode, itemName)) {
            BmaValidator.validateMojiCodeForBiko(inSession.getBiko(), errors, groupCode, itemName);
        }

        inSession.setErrors(errors);
        return errors.isEmpty();
    }
}