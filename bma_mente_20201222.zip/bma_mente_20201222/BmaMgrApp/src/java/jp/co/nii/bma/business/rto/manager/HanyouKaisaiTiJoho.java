package jp.co.nii.bma.business.rto.manager;

import jp.co.nii.bma.utility.BmaDateTimeUtility;

/**
 * �^�C�g��: TOP��� ����: TOP���RTO ���쌠: Copyright (c) 2020 ��Ж�: ���{���Y�Ɗ������
 */
public class HanyouKaisaiTiJoho {

    private String kaisaichiCode;
    private String kaijoId;
    private String kaisaichi;
    private String dateFrom;
    private String dateTo;
    private String kaijoCode;
    private String kaijoName;
    private String kaijoJusho;
    private String kuusekiSuu;

    private String count;

    public String getKaisaichiCode() {
        return kaisaichiCode;
    }

    public void setKaisaichiCode(String kaisaichiCode) {
        this.kaisaichiCode = kaisaichiCode;
    }

    public String getKaijoId() {
        return kaijoId;
    }

    public void setKaijoId(String kaijoId) {
        this.kaijoId = kaijoId;
    }

    public String getKaisaichi() {
        return kaisaichi;
    }

    public void setKaisaichi(String kaisaichi) {
        this.kaisaichi = kaisaichi;
    }

    public String getDateFrom() {
        return dateFrom;
    }

    public void setDateFrom(String dateFrom) {
        this.dateFrom = dateFrom;
    }

    public String getDateTo() {
        return dateTo;
    }

    public void setDateTo(String dateTo) {
        this.dateTo = dateTo;
    }

    public String getKaijoCode() {
        return kaijoCode;
    }

    public void setKaijoCode(String kaijoCode) {
        this.kaijoCode = kaijoCode;
    }

    public String getKaijoName() {
        return kaijoName;
    }

    public void setKaijoName(String kaijoName) {
        this.kaijoName = kaijoName;
    }

    public String getDateToDisp() {
        return BmaDateTimeUtility.formatYMDToDateString(dateTo) + "(" + BmaDateTimeUtility.dateToWeek(dateTo) + ")";
    }

    public String getKaijoJusho() {
        return kaijoJusho;
    }

    public void setKaijoJusho(String kaijoJusho) {
        this.kaijoJusho = kaijoJusho;
    }

    public String getKuusekiSuu() {
        return kuusekiSuu;
    }

    public String getDateFromDisp() {
        return BmaDateTimeUtility.formatYMDToDateString(dateFrom) + "(" + BmaDateTimeUtility.dateToWeek(dateFrom) + ")";
    }

    public void setKuusekiSuu(String kuusekiSuu) {
        this.kuusekiSuu = kuusekiSuu;
    }

    public String getCount() {
        return count;
    }

    public void setCount(String count) {
        this.count = count;
    }
}
