package jp.co.nii.bma.business.service.manager;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Date;
import java.util.Calendar;
import jp.co.nii.bma.business.domain.Schedule;
import jp.co.nii.bma.business.rto.manager.MstKanriScheduleJoho;
import jp.co.nii.bma.business.domain.SknksuMst;
import jp.co.nii.bma.business.service.common.BmaConstants;
import jp.co.nii.bma.business.service.common.BmaLogger;
import jp.co.nii.bma.business.service.common.BmaValidator;
import jp.co.nii.bma.utility.BmaUtility;
import jp.co.nii.sew.business.service.AbstractService;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_SUCCESS;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_RELOAD;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_BACK;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_EXCEPTION;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_SESSION;
import jp.co.nii.sew.presentation.Messages;
import jp.co.nii.sew.presentation.Option;
import jp.co.nii.sew.presentation.RequestTransferObject;
import jp.co.nii.sew.utility.PropertyUtility;

/**
 *
 * @author nii19042
 */
public class MstKanriScheduleService extends AbstractService {

    /**
     * DB�ڑ��̃f�[�^�\�[�X
     */
    private static String DATA_SOURCE_NAME;
    /**
     * ���O
     */
    BmaLogger log = (BmaLogger) BmaLogger.getLogger(this.getClass().getName());
    /**
     * �Ɩ��R�[�h
     */
    private static final String BUSINESS_CODE = PropertyUtility.getProperty("business_code");
    /**
     * ���׃e�X�g���[�h
     */
    private static final String STRESS_MODE = PropertyUtility.getProperty(BUSINESS_CODE + "stress_mode");
    // ���s ���̓��[���̃e���v���[�g�ꍇ
    String newLine = "\\n";

    /**
     * �R���X�g���N�^
     */
    public MstKanriScheduleService() {
        super();
        /* DB�ڑ����̃��[�U�[������ */
        DATA_SOURCE_NAME = BmaConstants.DS_REGISTRANT;
    }

    /**
     * �T�[�r�X�N���X�̎��s���\�b�h
     *
     * @param rto ���N�G�X�g��񂩂�擾����rto
     * @param rtoInSession �Z�b�V�������rto
     * @return foward��
     * @throws Exception ��O
     */
    @Override
    public String doService(RequestTransferObject rto, RequestTransferObject rtoInSession)
            throws Exception {

        MstKanriScheduleJoho inRequest = (MstKanriScheduleJoho) rto;
        MstKanriScheduleJoho inSession = (MstKanriScheduleJoho) rtoInSession;
        String processName = "";

        /* �G���[���b�Z�[�W������ */
        inSession.setErrors(new Messages());

        try {
            if (!BmaUtility.isNullOrEmpty(inRequest.getScheduleTable())) {
                /*�u�X�P�W���[���v�{�^���œ���ʂɑJ�ڎ� */
                processName = "MstKanriSchedule_First";
                log.Start(processName);

                /* �c���Ă���Z�b�V������j�� */
                inSession.clearInfo();

                /* �����u�K��X�g���쐬 */
                inSession.setSknKbnList(findSknKsuList(BmaConstants.SKN_KBN));
                inSession.setKsuKbnList(findSknKsuList(BmaConstants.KSU_KBN));

                /* �u�X�P�W���[�������v��ʕ\�� */
                return FWD_NM_RELOAD;

            } else if (!BmaUtility.isNullOrEmpty(inRequest.getScheduleSearchResult())) {
                /*�u�����v�{�^�������� */
                processName = "MstKanriSchedule_Search";
                log.Start(processName);

                /* �ϐ������� */
                Schedule schedule = new Schedule(DATA_SOURCE_NAME);
                String nendo = "";
                String sknKsuCode = "";
                String shubetsuCode = "";
                String kaisuCode = "";

                /* �I��l�ێ� */
                inSession.setSknksuKbn(inRequest.getSknksuKbn());
                if (BmaConstants.SKN_KBN.equals(inRequest.getSknksuKbn())) {
                    inSession.setSknName(inRequest.getSknName());
                    inSession.setKsuName("");
                } else if (BmaConstants.KSU_KBN.equals(inRequest.getSknksuKbn())) {
                    inSession.setSknName("");
                    inSession.setKsuName(inRequest.getKsuName());
                }
                // �I��l�`�F�b�N
                if (!validateInput(inSession)) {
                    // �G���[���������ꍇ�u�X�P�W���[�������v���Reload
                    return FWD_NM_RELOAD;
                }

                /* �e�R�[�h���Z�b�V�����ɕێ� */
                if (BmaConstants.SKN_KBN.equals(inRequest.getSknksuKbn())) {
                    sknKsuCode = inRequest.getSknName().substring(0,2);
                    shubetsuCode = inRequest.getSknName().substring(2,4);
                    kaisuCode = inRequest.getSknName().substring(4,6);
                } else if (BmaConstants.KSU_KBN.equals(inRequest.getSknksuKbn())) {
                    sknKsuCode = inRequest.getKsuName().substring(0,2);
                    shubetsuCode = inRequest.getKsuName().substring(2,4);
                    kaisuCode = inRequest.getKsuName().substring(4,6);
                }
                inSession.setSknKsuCode(sknKsuCode);
                inSession.setShubetsuCode(shubetsuCode);
                inSession.setKaisuCode(kaisuCode);

                //�N�x �X�P�W���[�������J�n���̍ŐV�N�x���擾
                nendo = schedule.findNendoKojiKikan(sknKsuCode, shubetsuCode, kaisuCode, BmaConstants.SCHED_CODE_OPEN, BmaConstants.SCHEDULE_KBN_ST);
                inSession.setNendo(nendo);

                /* �X�P�W���[�����X�g�擾 */
                List<MstKanriScheduleJoho> scheduleSearchList = schedule.findBySknKsu(nendo, sknKsuCode, shubetsuCode, kaisuCode);

                List<MstKanriScheduleJoho> scheduleResultList = new LinkedList<MstKanriScheduleJoho>();
                if (!scheduleSearchList.isEmpty()) {
                    inSession.setScheduleSearchList(scheduleSearchList);
                    scheduleResultList = createScheduleDisp(scheduleSearchList, inSession);
                    inSession.setScheduleResultList(scheduleResultList);
                    inSession.setScheduleSrcListFlg(BmaConstants.FLG_ON);
                } else {
                    // �������ʂ��Ȃ��ꍇ
                    inSession.setScheduleSrcListFlg(BmaConstants.FLG_OFF);
                }

                /* �u�X�P�W���[�������v���Reload */
                return FWD_NM_RELOAD;

            } else if (!BmaUtility.isNullOrEmpty(inRequest.getScheduleUpdInput())) {
                /*�u�ύX�v�{�^�������� */
                processName = "MstKanriSchedule_ScheduleUpdInput";
                log.Start(processName);

                /* �ϐ������� */
                String sknKsuCode = "";
                String shubetsuCode = "";
                String kaisuCode = "";

                /* �I��l�ێ� */
                inSession.setSknksuKbn(inRequest.getSknksuKbn());
                if (BmaConstants.SKN_KBN.equals(inRequest.getSknksuKbn())) {
                    inSession.setSknName(inRequest.getSknName());
                    inSession.setKsuName("");
                } else if (BmaConstants.KSU_KBN.equals(inRequest.getSknksuKbn())) {
                    inSession.setSknName("");
                    inSession.setKsuName(inRequest.getKsuName());
                }
                // �I��l�`�F�b�N
                if (!validateInput(inSession)) {
                    // �G���[���������ꍇ�u�X�P�W���[�������v���Reload
                    return FWD_NM_RELOAD;
                }

                /* �e�R�[�h���Z�b�V�����ɕێ� */
                if (BmaConstants.SKN_KBN.equals(inRequest.getSknksuKbn())) {
                    sknKsuCode = inRequest.getSknName().substring(0,2);
                    shubetsuCode = inRequest.getSknName().substring(2,4);
                    kaisuCode = inRequest.getSknName().substring(4,6);
                } else if (BmaConstants.KSU_KBN.equals(inRequest.getSknksuKbn())) {
                    sknKsuCode = inRequest.getKsuName().substring(0,2);
                    shubetsuCode = inRequest.getKsuName().substring(2,4);
                    kaisuCode = inRequest.getKsuName().substring(4,6);
                }
                inSession.setSknKsuCode(sknKsuCode);
                inSession.setShubetsuCode(shubetsuCode);
                inSession.setKaisuCode(kaisuCode);

                /* �����u�K��@���̎擾 */
                SknksuMst sknksuMst = new SknksuMst(BmaConstants.DS_REGISTRANT);
                inSession.setSknksuNameRyaku(sknksuMst.findSknKsuNameRyaku(sknKsuCode, shubetsuCode, kaisuCode).getSknKsuNameRyaku());

                /* �����{�^�����������ɕύX�{�^�����������ꍇ */
                if (inSession.getScheduleResultList().isEmpty()) {
                    Schedule schedule = new Schedule(DATA_SOURCE_NAME);
                    String nendo = "";

                    //�N�x �X�P�W���[�������J�n���̍ŐV�N�x���擾
                    nendo = schedule.findNendoKojiKikan(sknKsuCode, shubetsuCode, kaisuCode, BmaConstants.SCHED_CODE_OPEN, BmaConstants.SCHEDULE_KBN_ST);
                    inSession.setNendo(nendo);

                    /* �X�P�W���[�����X�g�擾 */
                    List<MstKanriScheduleJoho> scheduleSearchList = schedule.findBySknKsu(nendo, sknKsuCode, shubetsuCode, kaisuCode);

                    List<MstKanriScheduleJoho> scheduleResultList = new LinkedList<MstKanriScheduleJoho>();
                    if (!scheduleSearchList.isEmpty()) {
                        inSession.setScheduleSearchList(scheduleSearchList);
                        scheduleResultList = createScheduleDisp(scheduleSearchList, inSession);
                        inSession.setScheduleResultList(scheduleResultList);
                        inSession.setScheduleSrcListFlg(BmaConstants.FLG_ON);
                    } else {
                        // �������ʂ��Ȃ��ꍇ�u�X�P�W���[�������v���Reload
                        inSession.setScheduleSrcListFlg(BmaConstants.FLG_OFF);
                        return FWD_NM_RELOAD;
                    }
                }

                /* �u�X�P�W���[���ύX���́v��ʕ\�� */
                return FWD_NM_SUCCESS;

            } else if (!BmaUtility.isNullOrEmpty(inRequest.getScheduleBack())) {
                /*�u�߂�v�{�^�������� */
                processName = "MstKanriSchedule_BackMstKanri";
                log.Start(processName);

                /* �u�}�X�^�Ǘ��v��ʕ\�� */
                return FWD_NM_BACK;

            } else {
                /* �ُ�J�� */
                log.IllegalFWD();
                return FWD_NM_SESSION;
            }
        } catch (Exception e) {
            return FWD_NM_EXCEPTION;
        } finally {
            log.End(processName);
        }
    }

    /**
        * �����u�K��X�g���擾����
        * @param sknksuKbn
        * @return 
    */    
    public List<Option> findSknKsuList(String sknksuKbn) {
        List<Option> list = new ArrayList<>();
        //�����u�K���X�g��p�ӂ���
        SknksuMst sknksuMst = new SknksuMst(BmaConstants.DS_REGISTRANT);
        sknksuMst.findBySknKsuKbn(sknksuKbn,list);
        return list;
    }

    /**
     * �W���f�[�^��MstKanriScheduleJoho�ɕێ�
     *
     * @param ryokin ���f�[�^
     * @param �ۑ���
     */
    private void saveSchedule(MstKanriScheduleJoho schedule, MstKanriScheduleJoho saveObject){
        saveObject.setNendo(schedule.getNendo());
        saveObject.setSknKsuCode(schedule.getSknKsuCode());
        saveObject.setShubetsuCode(schedule.getShubetsuCode());
        saveObject.setKaisuCode(schedule.getKaisuCode());
        saveObject.setScheduleCode(schedule.getScheduleCode());
        saveObject.setScheduleKbn(schedule.getScheduleKbn());
        saveObject.setDate(schedule.getDate());
        saveObject.setTime(schedule.getTime());
        saveObject.setNissu(schedule.getNissu());
        saveObject.setScheduleName(schedule.getScheduleName());
    }

    /**
        * �\���p�̃X�P�W���[�����쐬����
        * @param scheduleSearchList �X�P�W���[����������
        * @param inSession �Z�b�V�������
        * @return scheduleResultList �\���p�X�P�W���[�����X�g
    */    
    private List<MstKanriScheduleJoho> createScheduleDisp(List<MstKanriScheduleJoho> scheduleSearchList, MstKanriScheduleJoho inSession){
        List<MstKanriScheduleJoho> scheduleResultList = new LinkedList<MstKanriScheduleJoho>();

        for (MstKanriScheduleJoho schedule : scheduleSearchList) {
            MstKanriScheduleJoho scheduleForInput = new MstKanriScheduleJoho();
            // 0. ��������
            if (BmaConstants.SCHED_CODE_OPEN.equals(schedule.getScheduleCode())) {
                if (BmaConstants.SCHEDULE_KBN_ST.equals(schedule.getScheduleKbn())){
                    saveSchedule(schedule, scheduleForInput);
                    setScheduleForDisp(schedule, scheduleForInput);
                    scheduleForInput.setScheduleTitle("�X�P�W���[��" + newLine + "��������");
                    scheduleForInput.setSchedStEdFlg(BmaConstants.FLG_ON);
                    scheduleForInput.setTimeDisabledFlg(BmaConstants.FLG_ON);
                    scheduleResultList.add(scheduleResultList.size(), scheduleForInput);
                } else {
                    scheduleForInput = scheduleResultList.get(scheduleResultList.size() - 1);
                    setScheduleForDisp(schedule, scheduleForInput);
                    scheduleResultList.set(scheduleResultList.size() - 1, scheduleForInput);
                }
            // 1. ��u�҃f�[�^�ύX�\����
            } else if (BmaConstants.SCHED_CODE_DATA_UPD.equals(schedule.getScheduleCode())) {
                if (BmaConstants.SCHEDULE_KBN_ST.equals(schedule.getScheduleKbn())){
                    saveSchedule(schedule, scheduleForInput);
                    setScheduleForDisp(schedule, scheduleForInput);
                    scheduleForInput.setScheduleTitle("��u�҃f�[�^" + newLine + "�ύX�\����");
                    scheduleForInput.setSchedStEdFlg(BmaConstants.FLG_ON);
                    scheduleForInput.setTimeDisabledFlg(BmaConstants.FLG_ON);
                    scheduleResultList.add(scheduleResultList.size(), scheduleForInput);
                } else {
                    scheduleForInput = scheduleResultList.get(scheduleResultList.size() - 1);
                    setScheduleForDisp(schedule, scheduleForInput);
                    scheduleResultList.set(scheduleResultList.size() - 1, scheduleForInput);
                }
            // 2. WEB�\���@��t���ԁy����z
            } else if (BmaConstants.SCHED_CODE_WEB_KAIIN.equals(schedule.getScheduleCode())) {
                if (BmaConstants.SCHEDULE_KBN_ST.equals(schedule.getScheduleKbn())){
                    saveSchedule(schedule, scheduleForInput);
                    setScheduleForDisp(schedule, scheduleForInput);
                    scheduleForInput.setScheduleTitle("WEB�\���@��t����" + newLine + "�y����z");
                    scheduleForInput.setSchedStEdFlg(BmaConstants.FLG_ON);
                    scheduleForInput.setMarginFlg(BmaConstants.FLG_ON);
                    scheduleResultList.add(scheduleResultList.size(), scheduleForInput);
                } else {
                    scheduleForInput = scheduleResultList.get(scheduleResultList.size() - 1);
                    setScheduleForDisp(schedule, scheduleForInput);
                    scheduleResultList.set(scheduleResultList.size() - 1, scheduleForInput);
                }
            // 3. WEB�\���@��t���ԁy��ʁz
            } else if (BmaConstants.SCHED_CODE_WEB_IPPAN.equals(schedule.getScheduleCode())) {
                if (BmaConstants.SCHEDULE_KBN_ST.equals(schedule.getScheduleKbn())){
                    saveSchedule(schedule, scheduleForInput);
                    setScheduleForDisp(schedule, scheduleForInput);
                    scheduleForInput.setScheduleTitle("WEB�\���@��t����" + newLine + "�y��ʁz");
                    scheduleForInput.setSchedStEdFlg(BmaConstants.FLG_ON);
                    scheduleResultList.add(scheduleResultList.size(), scheduleForInput);
                } else {
                    scheduleForInput = scheduleResultList.get(scheduleResultList.size() - 1);
                    setScheduleForDisp(schedule, scheduleForInput);
                    scheduleResultList.set(scheduleResultList.size() - 1, scheduleForInput);
                }
            // 4. �X���\���@��t���ԁy����z
            } else if (BmaConstants.SCHED_CODE_YUSO_KAIIN.equals(schedule.getScheduleCode())) {
                if (BmaConstants.SCHEDULE_KBN_ST.equals(schedule.getScheduleKbn())){
                    saveSchedule(schedule, scheduleForInput);
                    setScheduleForDisp(schedule, scheduleForInput);
                    scheduleForInput.setScheduleTitle("�X���\���@��t����" + newLine + "�y����z");
                    scheduleForInput.setSchedStEdFlg(BmaConstants.FLG_ON);
                    scheduleForInput.setTimeDisabledFlg(BmaConstants.FLG_ON);
                    scheduleResultList.add(scheduleResultList.size(), scheduleForInput);
                } else {
                    scheduleForInput = scheduleResultList.get(scheduleResultList.size() - 1);
                    setScheduleForDisp(schedule, scheduleForInput);
                    scheduleResultList.set(scheduleResultList.size() - 1, scheduleForInput);
                }
            // 5. �X���\���@��t���ԁy��ʁz
            } else if (BmaConstants.SCHED_CODE_YUSO_IPPAN.equals(schedule.getScheduleCode())) {
                if (BmaConstants.SCHEDULE_KBN_ST.equals(schedule.getScheduleKbn())){
                    saveSchedule(schedule, scheduleForInput);
                    setScheduleForDisp(schedule, scheduleForInput);
                    scheduleForInput.setScheduleTitle("�X���\���@��t����" + newLine + "�y��ʁz");
                    scheduleForInput.setSchedStEdFlg(BmaConstants.FLG_ON);
                    scheduleForInput.setTimeDisabledFlg(BmaConstants.FLG_ON);
                    scheduleResultList.add(scheduleResultList.size(), scheduleForInput);
                } else {
                    scheduleForInput = scheduleResultList.get(scheduleResultList.size() - 1);
                    setScheduleForDisp(schedule, scheduleForInput);
                    scheduleResultList.set(scheduleResultList.size() - 1, scheduleForInput);
                }
            // 6. WEB�@��������
            } else if (BmaConstants.SCHED_CODE_HARAIKOMI_WEB.equals(schedule.getScheduleCode())) {
                if (BmaConstants.SCHEDULE_KBN_ST.equals(schedule.getScheduleKbn())){
                    saveSchedule(schedule, scheduleForInput);
                    setScheduleForDisp(schedule, scheduleForInput);
                    scheduleForInput.setScheduleTitle("WEB�@��������");
                    scheduleForInput.setSchedStEdFlg(BmaConstants.FLG_ON);
                    scheduleForInput.setMarginFlg(BmaConstants.FLG_ON);
                    scheduleResultList.add(scheduleResultList.size(), scheduleForInput);
                } else {
                    scheduleForInput = scheduleResultList.get(scheduleResultList.size() - 1);
                    setScheduleForDisp(schedule, scheduleForInput);
                    scheduleResultList.set(scheduleResultList.size() - 1, scheduleForInput);
                }
            // 7. �X���@��������
            } else if (BmaConstants.SCHED_CODE_HARAIKOMI_YUSO.equals(schedule.getScheduleCode())) {
                if (BmaConstants.SCHEDULE_KBN_ST.equals(schedule.getScheduleKbn())){
                    saveSchedule(schedule, scheduleForInput);
                    setScheduleForDisp(schedule, scheduleForInput);
                    scheduleForInput.setScheduleTitle("�X���@��������");
                    scheduleForInput.setSchedStEdFlg(BmaConstants.FLG_ON);
                    scheduleResultList.add(scheduleResultList.size(), scheduleForInput);
                } else {
                    scheduleForInput = scheduleResultList.get(scheduleResultList.size() - 1);
                    setScheduleForDisp(schedule, scheduleForInput);
                    scheduleResultList.set(scheduleResultList.size() - 1, scheduleForInput);
                }
            // 8. �摜�s���@��������
            } else if (BmaConstants.SCHED_CODE_GAZO_KAISHO.equals(schedule.getScheduleCode())) {
                if (BmaConstants.SCHEDULE_KBN_ST.equals(schedule.getScheduleKbn())){
                    saveSchedule(schedule, scheduleForInput);
                    setScheduleForDisp(schedule, scheduleForInput);
                    scheduleForInput.setScheduleTitle("�摜�s���@��������");
                    scheduleForInput.setSchedStEdFlg(BmaConstants.FLG_ON);
                    scheduleForInput.setTimeDisabledFlg(BmaConstants.FLG_ON);
                    scheduleResultList.add(scheduleResultList.size(), scheduleForInput);
                } else {
                    scheduleForInput = scheduleResultList.get(scheduleResultList.size() - 1);
                    setScheduleForDisp(schedule, scheduleForInput);
                    scheduleResultList.set(scheduleResultList.size() - 1, scheduleForInput);
                }
            // 9. �󌟎�u�[������
            } else if (BmaConstants.SCHED_CODE_JUKENHYO_SEND.equals(schedule.getScheduleCode())) {
                saveSchedule(schedule, scheduleForInput);
                setScheduleForDisp(schedule, scheduleForInput);
                // �����ƍu�K��ŁA�ʃ^�C�g��
                if (BmaConstants.SKN_KBN.equals(inSession.getSknksuKbn())){
                    scheduleForInput.setScheduleTitle("�󌟕[������");
                } else {
                    scheduleForInput.setScheduleTitle("��u�[������");
                }
                scheduleForInput.setMarginFlg(BmaConstants.FLG_ON);
                scheduleForInput.setTimeDisabledFlg(BmaConstants.FLG_ON);
                scheduleResultList.add(scheduleResultList.size(), scheduleForInput);
            // 10.(����) �w�Ȏ����E���Z�y�[�p�[�e�X�g
            } else if (BmaConstants.SCHED_CODE_SKN_GAKKA.equals(schedule.getScheduleCode())) {
                saveSchedule(schedule, scheduleForInput);
                setScheduleForDisp(schedule, scheduleForInput);
                scheduleForInput.setScheduleTitle("�w�Ȏ����E���Z�y�[�p�[�e�X�g" + newLine + "���{��");
                scheduleForInput.setTimeDisabledFlg(BmaConstants.FLG_ON);
                scheduleResultList.add(scheduleResultList.size(), scheduleForInput);
            // 11.(����) ���Z��Ǝ���
            } else if (BmaConstants.SCHED_CODE_SKN_JITSUGI.equals(schedule.getScheduleCode())) {
                if (BmaConstants.SCHEDULE_KBN_ST.equals(schedule.getScheduleKbn())){
                    saveSchedule(schedule, scheduleForInput);
                    setScheduleForDisp(schedule, scheduleForInput);
                    scheduleForInput.setScheduleTitle("���Z��Ǝ���" + newLine + "���{����");
                    scheduleForInput.setSchedStEdFlg(BmaConstants.FLG_ON);
                    scheduleForInput.setTimeDisabledFlg(BmaConstants.FLG_ON);
                    scheduleResultList.add(scheduleResultList.size(), scheduleForInput);
                } else {
                    scheduleForInput = scheduleResultList.get(scheduleResultList.size() - 1);
                    setScheduleForDisp(schedule, scheduleForInput);
                    scheduleResultList.set(scheduleResultList.size() - 1, scheduleForInput);
                }
            // 10.(�u�K��) �u�K��i���Z���K�j
            } else if (BmaConstants.SCHED_CODE_KSU_JITSUGI.equals(schedule.getScheduleCode())) {
                if (BmaConstants.SCHEDULE_KBN_ST.equals(schedule.getScheduleKbn())){
                    saveSchedule(schedule, scheduleForInput);
                    setScheduleForDisp(schedule, scheduleForInput);
                    // �C���y�N�y�V�K�z�̏ꍇ�̂݁A�ʃ^�C�g�����u�u�K��i�C���ۑ�j�v����
                    if (   "IP".equals(schedule.getSknKsuCode())
                        && "11".equals(schedule.getShubetsuCode())) {
                        scheduleForInput.setScheduleTitle("�u�K��i���Z���K�j" + newLine + "���{����");
                        scheduleForInput.setSchedStEdFlg(BmaConstants.FLG_ON);
                        scheduleForInput.setTimeDisabledFlg(BmaConstants.FLG_ON);
                        scheduleResultList.add(scheduleResultList.size(), scheduleForInput);
                    } else{
                        scheduleForInput.setScheduleTitle("�u�K��" + newLine + "���{����");
                        scheduleForInput.setSchedStEdFlg(BmaConstants.FLG_ON);
                        scheduleForInput.setTimeDisabledFlg(BmaConstants.FLG_ON);
                        scheduleResultList.add(scheduleResultList.size(), scheduleForInput);
                    }
                } else {
                    scheduleForInput = scheduleResultList.get(scheduleResultList.size() - 1);
                    setScheduleForDisp(schedule, scheduleForInput);
                    scheduleResultList.set(scheduleResultList.size() - 1, scheduleForInput);
                    if (!("IP".equals(schedule.getSknKsuCode()) && "11".equals(schedule.getShubetsuCode()))) {
                        // �C���y�N�y�V�K�z�ȊO�́A�e�����X�L�b�v�p�ɃX�P�W���[���R�[�h�̂ݓo�^���Ă���
                        scheduleForInput = new MstKanriScheduleJoho();
                        scheduleForInput.setScheduleCode(BmaConstants.SCHED_CODE_KSU_SHURYO);
                        scheduleForInput.setNotHandUpdateFlg(BmaConstants.FLG_ON);
                        scheduleResultList.add(scheduleResultList.size(), scheduleForInput);
                    }
                }
            // 11.(�u�K��) �u�K��i�C���ۑ�j
            } else if (BmaConstants.SCHED_CODE_KSU_SHURYO.equals(schedule.getScheduleCode())) {
                if (BmaConstants.SCHEDULE_KBN_ST.equals(schedule.getScheduleKbn())){
                    saveSchedule(schedule, scheduleForInput);
                    setScheduleForDisp(schedule, scheduleForInput);
                    scheduleForInput.setScheduleTitle("�u�K��i�C���ۑ�j" + newLine + "���{����");
                    scheduleForInput.setSchedStEdFlg(BmaConstants.FLG_ON);
                    scheduleForInput.setTimeDisabledFlg(BmaConstants.FLG_ON);
                    scheduleResultList.add(scheduleResultList.size(), scheduleForInput);
                } else {
                    scheduleForInput = scheduleResultList.get(scheduleResultList.size() - 1);
                    setScheduleForDisp(schedule, scheduleForInput);
                    scheduleResultList.set(scheduleResultList.size() - 1, scheduleForInput);
                }
            // 12. ���i���\��
            } else if (BmaConstants.SCHED_CODE_GOUHATSU.equals(schedule.getScheduleCode())) {
                saveSchedule(schedule, scheduleForInput);
                setScheduleForDisp(schedule, scheduleForInput);
                // �����ƍu�K��ŁA�ʃ^�C�g��
                if (BmaConstants.SKN_KBN.equals(inSession.getSknksuKbn())) {
                    scheduleForInput.setScheduleTitle("���i���\��");
                } else {
                    scheduleForInput.setScheduleTitle("�C���Ҕ��\��");
                }
                scheduleForInput.setMarginFlg(BmaConstants.FLG_ON);
                scheduleForInput.setTimeDisabledFlg(BmaConstants.FLG_ON);
                scheduleResultList.add(scheduleResultList.size(), scheduleForInput);
            // 13. ���i�ʒm������
            } else if (BmaConstants.SCHED_CODE_GOKAKU_SEND.equals(schedule.getScheduleCode())) {
                saveSchedule(schedule, scheduleForInput);
                setScheduleForDisp(schedule, scheduleForInput);
                // �����ƍu�K��ŁA�ʃ^�C�g��
                if (BmaConstants.SKN_KBN.equals(inSession.getSknksuKbn())) {
                    scheduleForInput.setScheduleTitle("���i�ʒm������");
                } else {
                    scheduleForInput.setScheduleTitle("�C���؏�������");
                }
                scheduleForInput.setTimeDisabledFlg(BmaConstants.FLG_ON);
                scheduleResultList.add(scheduleResultList.size(), scheduleForInput);
            // 14. �N��v�Z���
            } else if (BmaConstants.SCHED_CODE_NENREI_CALC.equals(schedule.getScheduleCode())) {
                saveSchedule(schedule, scheduleForInput);
                setScheduleForDisp(schedule, scheduleForInput);
                scheduleForInput.setScheduleTitle("�N��v�Z" + newLine + "���");
                scheduleForInput.setMarginFlg(BmaConstants.FLG_ON);
                scheduleForInput.setNotHandUpdateFlg(BmaConstants.FLG_ON);
                scheduleResultList.add(scheduleResultList.size(), scheduleForInput);
            // 15. �����o���N���Z�o���
            } else if (BmaConstants.SCHED_CODE_JITSUMU_CALC.equals(schedule.getScheduleCode())) {
                saveSchedule(schedule, scheduleForInput);
                setScheduleForDisp(schedule, scheduleForInput);
                scheduleForInput.setScheduleTitle("�����o���N��" + newLine + "�Z�o���");
                scheduleForInput.setNotHandUpdateFlg(BmaConstants.FLG_ON);
                scheduleResultList.add(scheduleResultList.size(), scheduleForInput);
            // 16. �C���s���ԂP
            } else if (BmaConstants.SCHED_CODE_CANT_UPD1.equals(schedule.getScheduleCode())) {
                if (BmaConstants.SCHEDULE_KBN_ST.equals(schedule.getScheduleKbn())){
                    saveSchedule(schedule, scheduleForInput);
                    setScheduleForDisp(schedule, scheduleForInput);
                    scheduleForInput.setScheduleTitle("�C���s���ԂP");
                    scheduleForInput.setSchedStEdFlg(BmaConstants.FLG_ON);
                    scheduleResultList.add(scheduleResultList.size(), scheduleForInput);
                } else {
                    scheduleForInput = scheduleResultList.get(scheduleResultList.size() - 1);
                    setScheduleForDisp(schedule, scheduleForInput);
                    scheduleResultList.set(scheduleResultList.size() - 1, scheduleForInput);
                }
            // 17. �C���s���ԂQ
            } else if (BmaConstants.SCHED_CODE_CANT_UPD2.equals(schedule.getScheduleCode())) {
                // �C���s���ԂP���u�����N�̏ꍇ
                if (scheduleResultList.size() < 17) {
                    if (!scheduleResultList.contains("�C���s���ԂP")) {
                        scheduleForInput = new MstKanriScheduleJoho();
                        scheduleForInput.setScheduleCode(BmaConstants.SCHED_CODE_CANT_UPD1);
                        scheduleForInput.setScheduleName("�C���s���ԂP");
                        scheduleForInput.setScheduleTitle("�C���s���ԂP");
                        scheduleForInput.setSchedStEdFlg(BmaConstants.FLG_ON);
                        scheduleResultList.add(scheduleResultList.size(), scheduleForInput);
                    }
                }
                if (BmaConstants.SCHEDULE_KBN_ST.equals(schedule.getScheduleKbn())){
                    scheduleForInput = new MstKanriScheduleJoho();
                    saveSchedule(schedule, scheduleForInput);
                    setScheduleForDisp(schedule, scheduleForInput);
                    scheduleForInput.setScheduleTitle("�C���s���ԂQ");
                    scheduleForInput.setSchedStEdFlg(BmaConstants.FLG_ON);
                    scheduleResultList.add(scheduleResultList.size(), scheduleForInput);
                } else {
                    scheduleForInput = scheduleResultList.get(scheduleResultList.size() - 1);
                    setScheduleForDisp(schedule, scheduleForInput);
                    scheduleResultList.set(scheduleResultList.size() - 1, scheduleForInput);
                }
            }
        }

        // �C���s���Ԃ��u�����N�̏ꍇ
            if (scheduleResultList.size() < 18) {
                // �C���s���ԂP���u�����N�̏ꍇ
                if (scheduleResultList.size() < 17) {
                    if (!scheduleResultList.contains("�C���s���ԂP")) {
                        MstKanriScheduleJoho scheduleForInput = new MstKanriScheduleJoho();
                        scheduleForInput = new MstKanriScheduleJoho();
                        scheduleForInput.setScheduleCode(BmaConstants.SCHED_CODE_CANT_UPD1);
                        scheduleForInput.setScheduleName("�C���s���ԂP");
                        scheduleForInput.setScheduleTitle("�C���s���ԂP");
                        scheduleForInput.setSchedStEdFlg(BmaConstants.FLG_ON);
                        scheduleResultList.add(scheduleResultList.size(), scheduleForInput);
                    }
                }
                // �C���s���ԂQ���u�����N�̏ꍇ
                if (!scheduleResultList.contains("�C���s���ԂQ")) {
                    MstKanriScheduleJoho scheduleForInput = new MstKanriScheduleJoho();
                    scheduleForInput.setScheduleCode(BmaConstants.SCHED_CODE_CANT_UPD2);
                    scheduleForInput.setScheduleName("�C���s���ԂQ");
                    scheduleForInput.setScheduleTitle("�C���s���ԂQ");
                    scheduleForInput.setSchedStEdFlg(BmaConstants.FLG_ON);
                    scheduleResultList.add(scheduleResultList.size(), scheduleForInput);
                }
            }

        return scheduleResultList;
    }

    /**
     * ���t�E������\������`�ɐ��`����
     * @param scheduleData�@���f�[�^
     * @param scheduleDisp�@�\���p�f�[�^�i�[
     */
    private void setScheduleForDisp(MstKanriScheduleJoho scheduleData, MstKanriScheduleJoho scheduleDisp){
        if (   BmaConstants.SCHEDULE_KBN_ST.equals(scheduleData.getScheduleKbn())
            || BmaConstants.SCHEDULE_KBN_BS.equals(scheduleData.getScheduleKbn())) {
            scheduleDisp.setStartYear(scheduleData.getDate().substring(0, 4));
            scheduleDisp.setStartMonth(scheduleData.getDate().substring(4, 6));
            scheduleDisp.setStartDay(scheduleData.getDate().substring(6, 8));
            scheduleDisp.setStartYobi(dateToWeek(scheduleData.getDate()));
            scheduleDisp.setStartHour(scheduleData.getTime().substring(0, 2));
            scheduleDisp.setStartMinute(scheduleData.getTime().substring(2, 4));
        } else if (BmaConstants.SCHEDULE_KBN_ED.equals(scheduleData.getScheduleKbn())) {
            scheduleDisp.setEndYear(scheduleData.getDate().substring(0, 4));
            scheduleDisp.setEndMonth(scheduleData.getDate().substring(4, 6));
            scheduleDisp.setEndDay(scheduleData.getDate().substring(6, 8));
            scheduleDisp.setEndYobi(dateToWeek(scheduleData.getDate()));
            scheduleDisp.setEndHour(scheduleData.getTime().substring(0, 2));
            scheduleDisp.setEndMinute(scheduleData.getTime().substring(2, 4));
        }
    }

    /**
     * ���t�ɂ���ėj�����擾����
     * @param datetime�@���t
     * @return  �j��
     */
    public static String dateToWeek(String datetime) {

        SimpleDateFormat f = new SimpleDateFormat("yyyyMMdd");
        String[] weekDays = {"��", "��", "��", "��", "��", "��", "�y"};
        Calendar cal = Calendar.getInstance();
        Date date;
        try {
            date = f.parse(datetime);
            cal.setTime(date);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        //the day number of a week
        int w = cal.get(Calendar.DAY_OF_WEEK) - 1;
        if (w < 0)
            w = 0;
        return weekDays[w];
    }

    /**
     * ���̓`�F�b�N
     *
     * @param inSession �Z�b�V����RTO
     * @return true:�G���[��
     */
    private boolean validateInput(MstKanriScheduleJoho inSession) {
        Messages errors = new Messages();

        String groupCode;
        String itemName;
        
        // �G���[�`�F�b�N�p���X�g�쐬
        String[] sknKsuKbns = {BmaConstants.SKN_KBN, BmaConstants.KSU_KBN};
        
        /** �����u�K��敪 */
        groupCode = "sknksuKbn";
        itemName = "�����u�K��敪";
        BmaValidator.validateSelect(inSession.getSknksuKbn(), errors, groupCode, itemName);
        BmaValidator.validatePermissionSelect(inSession.getSknksuKbn(), sknKsuKbns, errors, groupCode, itemName);

        /** �����u�K�� */
        groupCode = "sknKsuCode";
        itemName = "�����u�K��";
        if (BmaConstants.SKN_KBN.equals(inSession.getSknksuKbn())) {
            BmaValidator.validateSelect(inSession.getSknName(), errors, groupCode, itemName);
            BmaValidator.validatePermissionSelect(inSession.getSknName(), inSession.getSknKbnList(), errors, groupCode, itemName);
        } else if (BmaConstants.KSU_KBN.equals(inSession.getSknksuKbn())) {
            BmaValidator.validateSelect(inSession.getKsuName(), errors, groupCode, itemName);
            BmaValidator.validatePermissionSelect(inSession.getKsuName(), inSession.getKsuKbnList(), errors, groupCode, itemName);
        }

        inSession.setErrors(errors);
        return errors.isEmpty();
    }
}