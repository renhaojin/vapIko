package jp.co.nii.sew.presentation;

import java.io.*;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.transaction.UserTransaction;
import jp.co.nii.sew.business.Constants;
import jp.co.nii.sew.business.SystemTime;
import jp.co.nii.sew.business.domain.NoSuchDataException;
import jp.co.nii.sew.business.domain.SessionEvacuate;
import jp.co.nii.sew.business.service.transaction.TransactionUtility;
import jp.co.nii.sew.utility.StringUtility;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 *
 * @author r-tomita
 */
public class SessionHelper {

    Log log = LogFactory.getLog(this.getClass());
    private final static String USER_ID = "config";
    private final static String COOKIE_SESSION_ID = "JSESSIONID";
    private final static String COOKIE_SESSION_TOKEN = "SESSIONTOKEN";

    /**
     * �Z�b�V�����𕜋�����
     *
     * @param request
     * @return
     * @throws IOException
     */
    public HttpSession restoreSession(HttpServletRequest request) throws IOException {

        String sessionId = getCookieValue(request, COOKIE_SESSION_ID);
        if (sessionId == null || "".equals(sessionId)) {
            log.debug("JSESSIONID���擾�ł��܂���ł����B");
            return null;
        }
        //�C���X�^���X�������ɕt���Ă���ꍇ�i.fsa-instance1���j
        //DB�ɓo�^����ID�ƈ�v���Ȃ����߁A.(�h�b�g)�ȍ~���폜���Č�������
        int endIndex;
        if ((endIndex = sessionId.indexOf(".")) != -1) {
            sessionId = sessionId.substring(0, endIndex);
        }

        String sessionToken = getCookieValue(request, COOKIE_SESSION_TOKEN);
        if (sessionToken == null || "".equals(sessionToken)) {
            log.debug("SESSIONTOKEN���擾�ł��܂���ł����B");
            return null;
        }

        SessionEvacuate evacuatedSession = new SessionEvacuate(Configs.DB_DSLOOKUP_CONFIG);
        ByteArrayInputStream bais = null;
        ObjectInputStream ois = null;

        try {
            UserTransaction tx = TransactionUtility.get();
            tx.begin();

            evacuatedSession = evacuatedSession.lockWaitIfLocked(sessionId, sessionToken);
            if (evacuatedSession == null) {
                tx.rollback();
                log.debug("�Z�b�V��������DB����擾�ł��܂���ł����B");
                return null;
            }

            HttpSession session = request.getSession();

            byte[] byteSessionInfo = evacuatedSession.getSessionInformationBytes();
            bais = new ByteArrayInputStream(byteSessionInfo);
            ois = new ObjectInputStream(bais);

            // �擾���������Z�b�V�����Ɋi�[
            HashMap<String, Object> map = (HashMap) ois.readObject();
            Iterator<String> it = map.keySet().iterator();
            while (it.hasNext()) {
                String key = it.next();
                Object value = map.get(key);
                session.setAttribute(key, value);
            }

            log.info("SESSION TOKEN=" + sessionToken + ", SESSION ID=" + sessionId + " �̃Z�b�V������DB���畜�����܂���");

            deleteEvacuatedSession(sessionId, sessionToken);
            tx.commit();

            return session;

        } catch (Exception ex) {
            log.error("SESSION TOKEN=" + sessionToken + ", SESSION ID=" + sessionId + " �̃Z�b�V�����̕����Ɏ��s���܂���", ex);
            return null;
        } finally {
            if (bais != null) {
                bais.close();
            }
            if (ois != null) {
                ois.close();
            }
        }
    }

    /**
     * �Z�b�V������ޔ�����
     *
     * @param request
     * @param response
     * @param config
     */
    public void evacuateSession(HttpServletRequest request, HttpServletResponse response, Config config) throws IOException {

        HttpSession session = request.getSession(false);
        if (session == null) {
            return;
        }
        String sessionId = session.getId();
        String sessionToken = getCookieValue(request, COOKIE_SESSION_TOKEN);

        ByteArrayOutputStream baos = null;
        ObjectOutputStream oos = null;

        try {
            // �ޔ�p�ɃZ�b�V�������̂��̂� Map�Ɉڂ��ς���
            HashMap<String, Object> map = new HashMap<String, Object>();
            Enumeration<String> enum_session = session.getAttributeNames();
            while (enum_session.hasMoreElements()) {
                String key = enum_session.nextElement();
                Object value = session.getAttribute(key);
                map.put(key, value);
            }

            baos = new ByteArrayOutputStream();
            oos = new ObjectOutputStream(baos);
            oos.writeObject(map);

            if (sessionToken == null || "".equals(sessionToken)) {
                sessionToken = StringUtility.randomString(32, "1");
            }

            SessionEvacuate evacuatingSession;
            evacuatingSession = new SessionEvacuate(Configs.DB_DSLOOKUP_CONFIG);
            evacuatingSession.setSessionId(sessionId);
            evacuatingSession.setSessionToken(sessionToken);
            evacuatingSession.setSessionInformationBytes(baos.toByteArray());

            SessionEvacuate bo = evacuatingSession.find(sessionId, sessionToken);
            SystemTime sysTim = new SystemTime();
            if (bo == null) {
                evacuatingSession.setKoshinKbn(Constants.SHORI_KBN_INSERT);
                evacuatingSession.setTorokuDate(sysTim.getymd1());
                evacuatingSession.setTorokuTime(sysTim.gethms1());
                evacuatingSession.setTorokuUserId(USER_ID);
                evacuatingSession.setKoshinDate(sysTim.getymd1());
                evacuatingSession.setKoshinTime(sysTim.gethms1());
                evacuatingSession.setKoshinUserId(USER_ID);
                evacuatingSession.setRonriSakujoFlg(Constants.FLG_OFF);

                // �Z�b�V�������o�^
                evacuatingSession.create();

            } else {
                evacuatingSession.setKoshinKbn(Constants.SHORI_KBN_UPDATE);
                evacuatingSession.setTorokuDate(bo.getTorokuDate());
                evacuatingSession.setTorokuTime(bo.getTorokuTime());
                evacuatingSession.setTorokuUserId(bo.getTorokuUserId());
                evacuatingSession.setKoshinDate(sysTim.getymd1());
                evacuatingSession.setKoshinTime(sysTim.gethms1());
                evacuatingSession.setKoshinUserId(USER_ID);
                evacuatingSession.setRonriSakujoFlg(Constants.FLG_OFF);

                // �Z�b�V�������X�V
                evacuatingSession.update();
            }

            Cookie cookie = new Cookie(COOKIE_SESSION_TOKEN, sessionToken);
            cookie.setHttpOnly(true);
            // @todo config�Ŋ��ɂ���ăZ�b�g
//            cookie.setSecure(true);
            cookie.setPath("/");
            cookie.setMaxAge(-1);
            response.addCookie(cookie);

            log.info("SESSION TOKEN=" + sessionToken + ", SESSION ID=" + sessionId + " �̃Z�b�V������DB�֑ޔ����܂���");

        } catch (NotSerializableException nse) {
            String attributeNames = "";
            Enumeration<String> enum_session = session.getAttributeNames();
            while (enum_session.hasMoreElements()) {
                attributeNames += enum_session.nextElement() + ", ";
            }
            attributeNames = attributeNames.replaceAll(", $", "");
            log.debug("�Z�b�V�����̑ޔ��Ɏ��s���܂����B"
                    + "�������ɃV���A���C�Y�s�Ȃ��̂��܂܂�Ă��܂��B"
                    + "AttributeNames�F" + attributeNames, nse);
        } catch (Exception ex) {
            log.error("SESSION TOKEN=" + sessionToken + ", SESSION ID=" + sessionId + " �̃Z�b�V�����̑ޔ��Ɏ��s���܂���", ex);
        } finally {
            if (baos != null) {
                baos.close();
            }
            if (oos != null) {
                oos.close();
            }
        }
    }

    /**
     * �ޔ��ς݂̃Z�b�V�������폜����
     *
     * @param request
     */
    public void deleteEvacuatedSession(HttpServletRequest request) {
        String sessionId = getCookieValue(request, COOKIE_SESSION_ID);
        String sessionToken = getCookieValue(request, COOKIE_SESSION_TOKEN);
        deleteEvacuatedSession(sessionId, sessionToken);
    }

    private void deleteEvacuatedSession(String sessionId, String sessionToken) {
        try {
            SessionEvacuate bo = new SessionEvacuate(Configs.DB_DSLOOKUP_CONFIG);
            bo.setSessionId(sessionId);
            bo.setSessionToken(sessionToken);
            // �Z�b�V�������폜
            bo.remove();
            log.info("SESSION TOKEN=" + sessionToken + ", SESSION ID=" + sessionId + " �̑ޔ��ς݃Z�b�V������DB����폜���܂���");
        } catch (NoSuchDataException ex) {
            log.warn("SESSION TOKEN=" + sessionToken + ", SESSION ID=" + sessionId + " �̃Z�b�V������DB�ɑ��݂��Ȃ��������߁A�폜�͍s���܂���ł���", ex);
        }
    }

    private String getCookieValue(HttpServletRequest request, String target) {

        String returnValue = "";
        Cookie[] cookies = request.getCookies();
        if (cookies != null) {
            for (int i = 0; i < cookies.length; i++) {
                if (target.equals(cookies[i].getName())) {
                    returnValue = cookies[i].getValue();
                    i = +cookies.length;
                }
            }
        }
        return returnValue;
    }
}
