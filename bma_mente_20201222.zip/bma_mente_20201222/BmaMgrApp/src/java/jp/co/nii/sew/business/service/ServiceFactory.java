package jp.co.nii.sew.business.service;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author n-machida
 */
public class ServiceFactory {

    /**
     *
     * @param serviceName
     * @return
     */
    public static ApplicationService getService(String serviceName) {
        Object o = null;
        try {
            Class<ApplicationService> c;
            c = (Class<ApplicationService>) Class.forName(serviceName);
            o = c.newInstance();
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(ServiceFactory.class.getName()).log(Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            Logger.getLogger(ServiceFactory.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            Logger.getLogger(ServiceFactory.class.getName()).log(Level.SEVERE, null, ex);
        }
        return (ApplicationService) o;
    }
    
}
