package jp.co.nii.bma.integration;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import static jp.co.nii.bma.business.domain.GeneratedMMenjoMstDao.TABLE_NAME;
import static jp.co.nii.bma.business.domain.GeneratedShiyoKaijoDao.TABLE_NAME;
import jp.co.nii.bma.business.domain.MMenjoMst;
import jp.co.nii.bma.business.domain.MShikakuMst;
import jp.co.nii.bma.business.domain.MShikakuMstDao;
import jp.co.nii.bma.business.rto.manager.HanyouSearchJoho;
import static jp.co.nii.bma.integration.GeneratedShiyoKaijoDaoImpl.FIELDS_DECRYPT;
import jp.co.nii.sew.common.LogGenerate;
import static jp.co.nii.sew.integration.AbstractDao.getSchemaName;
import jp.co.nii.sew.integration.SQLStateSQLExceptionTranslater;
import jp.co.nii.sew.presentation.Option;

/**
 * �\�����i�}�X�^ DAO�����N���X
 *
 * @author DB�Ǘ��c�[��
 */
public class MShikakuMstDaoImpl extends GeneratedMShikakuMstDaoImpl implements MShikakuMstDao {

    /**
     * �C���X�^���X�𐶐�����B
     *
     * @param datasource �f�[�^�\�[�X��
     */
    public MShikakuMstDaoImpl(String datasource) {
        super(datasource);
    }

    /**
     * �Ə��ڍׂ��擾����B
     *
     * @return �摜�ڍ׃��X�g
     */
    @Override
    public String searchShikakuShosai(MShikakuMst bo) {
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = "";
        List<String> param = new ArrayList<>();
        String sknKsuCode = bo.getSknKsuCode();
        String shubetsuCode = bo.getShubetsuCode();
        String kaisuCode = bo.getKaisuCode();
        String shikakuCode = bo.getShikakuCode();
        String shikakuShosai = null;
        try {
            con = getConnection();
            sql = "SELECT SHIKAKU_SHOSAI"
                    + " FROM " + getSchemaName() + "." + TABLE_NAME
                    + " WHERE SKN_KSU_CODE = ?"
                    + " AND SHUBETSU_CODE = ?"
                    + " AND KAISU_CODE = ?"
                    + " AND SHIKAKU_CODE = ?"
                    + " AND RONRI_SAKUJO_FLG = '0'";
            param.add(sknKsuCode);
            param.add(shubetsuCode);
            param.add(kaisuCode);
            param.add(shikakuCode);
            stmt = con.prepareStatement(sql);
            int i = 1;
            for (String pm : param) {
                stmt.setString(i++, pm);
            }

            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();
            while (rs.next()) {
                shikakuShosai = rs.getString("SHIKAKU_SHOSAI");
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return shikakuShosai;
    }

    /**
     * ���i��񃊃X�g�擾
     *
     * @param list
     * @param bo
     */
    @Override
    public void findShikakuList(List<Option> list, HanyouSearchJoho bo) {
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = "";

        String limit = "";

        limit = " LIMIT " + "100";
        try {
            con = getConnection();
            sql = "SELECT " + FIELDS_DECRYPT
                    + " FROM " + getSchemaName() + "." + TABLE_NAME
                    + " WHERE SKN_KSU_CODE = ?"
                    + " AND SHUBETSU_CODE = ?"
                    + " AND KAISU_CODE = ?"
                    + " AND RONRI_SAKUJO_FLG = '0'";

            stmt = con.prepareStatement(sql);
            int i = 1;
            stmt.setString(i++, bo.getSknKsuCode());
            stmt.setString(i++, bo.getShubetsuCode());
            stmt.setString(i++, bo.getKaisuCode());

            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();

            while (rs.next()) {
                if (list != null) {
                    list.add(new Option(rs.getString("SHIKAKU_CODE"), rs.getString("SHIKAKU_SHOSAI")
                    ));
                }

            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
    }
}
