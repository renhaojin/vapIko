package jp.co.nii.bma.business.rto.manager;

import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import jp.co.nii.sew.presentation.AbstractRequestTransferObject;
import jp.co.nii.sew.presentation.Messages;
import jp.co.nii.sew.presentation.Option;

/**
 * �^�C�g��: Ryokin��� ����: Ryokin���RTO ���쌠: Copyright (c) 2020 ��Ж�: ���{���Y�Ɗ������
 * @author nii19042
 */
public class MstKanriRyokinJoho extends AbstractRequestTransferObject {
    private Messages errors;
    private Map<Option,Messages> errorJohoMaps;
    private String moshikomishaId;

    /* �{�^���J�� */
    private String ryokinTable;
    // �����������
    private String ryokinSearchResult;
    private String ryokinDetail;
    private String ryokinShinkiInput;
    private String ryokinSearchBack;
    // �����V�K�o�^���
    private String ryokinInpConf;
    private String ryokinInpBack;
    // �����V�K�o�^�m�F���
    private String ryokinInpComp;
    private String ryokinInpConfBack;
    // �����V�K�o�^�������
    private String ryokinInpCompBack;
    // �����ڍ׉��
    private String ryokinUpdInput;
    private String ryokinDetailBack;
    // �����ύX���͉��
    private String ryokinUpdConf;
    private String ryokinUpdInputBack;
    // �����ύX�m�F���
    private String ryokinUpdComp;
    private String ryokinUpdConfBack;
    // �����X�V�������
    private String ryokinUpdCompBack;
    
    /* �����f�[�^ */
    private String sknKsuCode;
    private String shubetsuCode;
    private String ryokinKbn;
    private String ryokin;
    private String zeiKbn;
    private String zeiritsu;
    // �\���p
    private String ryokinKbnName;
    private String ryokinDisp;
    private String zeiKbnName;
    private String zeiritsuDisp;
    
    /* �����u�K��I�� */
    private String sknksuKbn;
    private String kaisuCode;
    private String sknName;
    private String ksuName;
    private String sknksuNameRyaku;
    private List<Option> sknKbnList;
    private List<Option> ksuKbnList;

    private List<Option> ryokinKbnList;
    private List<MstKanriRyokinJoho> ryokinResultList;
    private String rknSrcListFlg;

    /**
     * �R���X�g���N�^
     */
    public MstKanriRyokinJoho() {
        clearInfo();
    }

    /**
     * ���������\�b�h
     */
    public void clearInfo() {
        setErrors(new Messages());
        setErrorJohoMaps(new HashMap<Option,Messages>());
        setMoshikomishaId("");
        
        setRyokinTable("");
        setRyokinSearchResult("");
        setRyokinDetail("");
        setRyokinShinkiInput("");
        setRyokinSearchBack("");
        setRyokinInpConf("");
        setRyokinInpBack("");
        setRyokinInpComp("");
        setRyokinInpConfBack("");
        setRyokinInpCompBack("");
        setRyokinUpdInput("");
        setRyokinDetailBack("");
        setRyokinUpdConf("");
        setRyokinUpdInputBack("");
        setRyokinUpdComp("");
        setRyokinUpdConfBack("");
        setRyokinUpdCompBack("");
        
        setSknKsuCode("");
        setShubetsuCode("");
        setRyokinKbn("");
        setRyokin("");
        setZeiKbn("");
        setZeiritsu("");
        setRyokinKbnName("");
        setRyokinDisp("");
        setZeiKbnName("");
        setZeiritsuDisp("");
        
        setSknksuKbn("1");
        setKaisuCode("");
        setSknName("");
        setKsuName("");
        setSknksuNameRyaku("");
        setSknKbnList(new ArrayList<Option>());
        setKsuKbnList(new ArrayList<Option>());
        
        setRyokinKbnList(new ArrayList<Option>());
        setRyokinResultList(new ArrayList<MstKanriRyokinJoho>());
        setRknSrcListFlg("");
    }

    /**
     * ���N�G�X�g��������擾���郁�\�b�h
     *
     * @param request ���N�G�X�g
     */
    @Override
    public void copyFromRequest(HttpServletRequest request) {
         
        setRyokinTable((String) request.getAttribute("ryokinTable"));
        setRyokinSearchResult((String) request.getAttribute("ryokinSearchResult"));
        setRyokinDetail((String) request.getAttribute("ryokinDetail"));
        setRyokinShinkiInput((String) request.getAttribute("ryokinShinkiInput"));
        setRyokinSearchBack((String) request.getAttribute("ryokinSearchBack"));
        setRyokinInpConf((String) request.getAttribute("ryokinInpConf"));
        setRyokinInpBack((String) request.getAttribute("ryokinInpBack"));
        setRyokinInpComp((String) request.getAttribute("ryokinInpComp"));
        setRyokinInpConfBack((String) request.getAttribute("ryokinInpConfBack"));
        setRyokinInpCompBack((String) request.getAttribute("ryokinInpCompBack"));
        setRyokinUpdInput((String) request.getAttribute("ryokinUpdInput"));
        setRyokinDetailBack((String) request.getAttribute("ryokinDetailBack"));
        setRyokinUpdConf((String) request.getAttribute("ryokinUpdConf"));
        setRyokinUpdInputBack((String) request.getAttribute("ryokinUpdInputBack"));
        setRyokinUpdComp((String) request.getAttribute("ryokinUpdComp"));
        setRyokinUpdConfBack((String) request.getAttribute("ryokinUpdConfBack"));
        setRyokinUpdCompBack((String) request.getAttribute("ryokinUpdCompBack"));

        setSknKsuCode((String) request.getAttribute("sknKsuCode"));
        setShubetsuCode((String) request.getAttribute("shubetsuCode"));
        setRyokinKbn((String) request.getAttribute("ryokinKbn"));
        setRyokin((String) request.getAttribute("ryokin"));
        setZeiKbn((String) request.getAttribute("zeiKbn"));
        setZeiritsu((String) request.getAttribute("zeiritsu"));
        setRyokinKbnName((String) request.getAttribute("ryokinKbnName"));
        setRyokinDisp((String) request.getAttribute("ryokinDisp"));
        setZeiKbnName((String) request.getAttribute("zeiKbnName"));
        setZeiritsuDisp((String) request.getAttribute("zeiritsuDisp"));

        setRyokinKbnList((List<Option>) request.getAttribute("ryokinKbnList"));
        setRyokinResultList((List<MstKanriRyokinJoho>) request.getAttribute("ryokinResultList"));
        setRknSrcListFlg((String) request.getAttribute("rknSrcListFlg"));

        setSknksuKbn((String) request.getAttribute("sknksuKbn"));
        setKaisuCode((String) request.getAttribute("kaisuCode"));
        setSknName((String) request.getAttribute("sknName"));
        setKsuName((String) request.getAttribute("ksuName"));
        setSknksuNameRyaku((String) request.getAttribute("sknksuNameRyaku"));
        setSknKbnList((List<Option>) request.getAttribute("sknKbnList"));
        setKsuKbnList((List<Option>) request.getAttribute("ksuKbnList"));

        HttpSession session = request.getSession(false);
        if (session.getAttribute("MgrTopJoho") != null) {
            MgrTopJoho tmp = (MgrTopJoho) session.getAttribute("MgrTopJoho");
            setMoshikomishaId((String) tmp.getMoshikomishaId());
        }
    }

    public Messages getErrors() {
        return errors;
    }

    public void setErrors(Messages errors) {
        this.errors = errors;
    }

    public Map<Option, Messages> getErrorJohoMaps() {
        return errorJohoMaps;
    }

    public void setErrorJohoMaps(Map<Option, Messages> errorJohoMaps) {
        this.errorJohoMaps = errorJohoMaps;
    }

    public String getMoshikomishaId() {
        return moshikomishaId;
    }

    public void setMoshikomishaId(String moshikomishaId) {
        this.moshikomishaId = moshikomishaId;
    }
    
    public String getRyokinTable() {
        return ryokinTable;
    }

    public void setRyokinTable(String ryokinTable) {
        this.ryokinTable = ryokinTable;
    }

    public String getRyokinSearchResult() {
        return ryokinSearchResult;
    }

    public void setRyokinSearchResult(String ryokinSearchResult) {
        this.ryokinSearchResult = ryokinSearchResult;
    }

    public String getRyokinDetail() {
        return ryokinDetail;
    }

    public void setRyokinDetail(String ryokinDetail) {
        this.ryokinDetail = ryokinDetail;
    }

    public String getRyokinShinkiInput() {
        return ryokinShinkiInput;
    }

    public void setRyokinShinkiInput(String ryokinShinkiInput) {
        this.ryokinShinkiInput = ryokinShinkiInput;
    }
    
    public String getRyokinSearchBack() {
        return ryokinSearchBack;
    }

    public void setRyokinSearchBack(String ryokinSearchBack) {
        this.ryokinSearchBack = ryokinSearchBack;
    }

    public String getRyokinInpConf() {
        return ryokinInpConf;
    }

    public void setRyokinInpConf(String ryokinInpConf) {
        this.ryokinInpConf = ryokinInpConf;
    }

    public String getRyokinInpBack() {
        return ryokinInpBack;
    }

    public void setRyokinInpBack(String ryokinInpBack) {
        this.ryokinInpBack = ryokinInpBack;
    }
    
    public String getRyokinInpComp() {
        return ryokinInpComp;
    }

    public void setRyokinInpComp(String ryokinInpComp) {
        this.ryokinInpComp = ryokinInpComp;
    }

    public String getRyokinInpConfBack() {
        return ryokinInpConfBack;
    }

    public void setRyokinInpConfBack(String ryokinInpConfBack) {
        this.ryokinInpConfBack = ryokinInpConfBack;
    }
    
    public String getRyokinInpCompBack() {
        return ryokinInpCompBack;
    }

    public void setRyokinInpCompBack(String ryokinInpCompBack) {
        this.ryokinInpCompBack = ryokinInpCompBack;
    }
    
    public String getRyokinUpdInput() {
        return ryokinUpdInput;
    }

    public void setRyokinUpdInput(String ryokinUpdInput) {
        this.ryokinUpdInput = ryokinUpdInput;
    }

    public String getRyokinDetailBack() {
        return ryokinDetailBack;
    }

    public void setRyokinDetailBack(String ryokinDetailBack) {
        this.ryokinDetailBack = ryokinDetailBack;
    }

    public String getRyokinUpdConf() {
        return ryokinUpdConf;
    }

    public void setRyokinUpdConf(String ryokinUpdConf) {
        this.ryokinUpdConf = ryokinUpdConf;
    }

    public String getRyokinUpdInputBack() {
        return ryokinUpdInputBack;
    }

    public void setRyokinUpdInputBack(String ryokinUpdInputBack) {
        this.ryokinUpdInputBack = ryokinUpdInputBack;
    }
    
    public String getRyokinUpdComp() {
        return ryokinUpdComp;
    }

    public void setRyokinUpdComp(String ryokinUpdComp) {
        this.ryokinUpdComp = ryokinUpdComp;
    }

    public String getRyokinUpdConfBack() {
        return ryokinUpdConfBack;
    }

    public void setRyokinUpdConfBack(String ryokinUpdConfBack) {
        this.ryokinUpdConfBack = ryokinUpdConfBack;
    }

    public String getRyokinUpdCompBack() {
        return ryokinUpdCompBack;
    }

    public void setRyokinUpdCompBack(String ryokinUpdCompBack) {
        this.ryokinUpdCompBack = ryokinUpdCompBack;
    }

    public String getSknKsuCode() {
        return sknKsuCode;
    }

    public void setSknKsuCode(String sknKsuCode) {
        this.sknKsuCode = sknKsuCode;
    }

    public String getShubetsuCode() {
        return shubetsuCode;
    }

    public void setShubetsuCode(String shubetsuCode) {
        this.shubetsuCode = shubetsuCode;
    }
    
    public String getRyokinKbn() {
        return ryokinKbn;
    }

    public void setRyokinKbn(String ryokinKbn) {
        this.ryokinKbn = ryokinKbn;
    }

    public String getRyokin() {
        return ryokin;
    }

    public void setRyokin(String ryokin) {
        this.ryokin = ryokin;
    }
    
    public String getZeiKbn() {
        return zeiKbn;
    }

    public void setZeiKbn(String zeiKbn) {
        this.zeiKbn = zeiKbn;
    }
    
    public String getZeiritsu() {
        return zeiritsu;
    }

    public void setZeiritsu(String zeiritsu) {
        this.zeiritsu = zeiritsu;
    }
    
    public String getRyokinKbnName() {
        return ryokinKbnName;
    }

    public void setRyokinKbnName(String ryokinKbnName) {
        this.ryokinKbnName = ryokinKbnName;
    }
    
    public String getRyokinDisp() {
        return ryokinDisp;
    }

    public void setRyokinDisp(String ryokinDisp) {
        this.ryokinDisp = ryokinDisp;
    }

    public String getZeiKbnName() {
        return zeiKbnName;
    }

    public void setZeiKbnName(String zeiKbnName) {
        this.zeiKbnName = zeiKbnName;
    }

    public String getZeiritsuDisp() {
        return zeiritsuDisp;
    }

    public void setZeiritsuDisp(String zeiritsuDisp) {
        this.zeiritsuDisp = zeiritsuDisp;
    }

    public String getSknksuKbn() {
        return sknksuKbn;
    }

    public void setSknksuKbn(String sknksuKbn) {
        this.sknksuKbn = sknksuKbn;
    }

    public String getKaisuCode() {
        return kaisuCode;
    }

    public void setKaisuCode(String kaisuCode) {
        this.kaisuCode = kaisuCode;
    }

    public String getSknName() {
        return sknName;
    }

    public void setSknName(String sknName) {
        this.sknName = sknName;
    }
    
    public String getKsuName() {
        return ksuName;
    }

    public void setKsuName(String ksuName) {
        this.ksuName = ksuName;
    }

    public String getSknksuNameRyaku() {
        return sknksuNameRyaku;
    }

    public void setSknksuNameRyaku(String sknksuNameRyaku) {
        this.sknksuNameRyaku = sknksuNameRyaku;
    }
    
    public List<Option> getSknKbnList() {
        return sknKbnList;
    }

    public void setSknKbnList(List<Option> sknKbnList) {
        this.sknKbnList = sknKbnList;
    }

    public List<Option> getKsuKbnList() {
        return ksuKbnList;
    }

    public void setKsuKbnList(List<Option> ksuKbnList) {
        this.ksuKbnList = ksuKbnList;
    }

    public List<Option> getRyokinKbnList() {
        return ryokinKbnList;
    }

    public void setRyokinKbnList(List<Option> ryokinKbnList) {
        this.ryokinKbnList = ryokinKbnList;
    }
    
    public List<MstKanriRyokinJoho> getRyokinResultList() {
        return ryokinResultList;
    }

    public void setRyokinResultList(List<MstKanriRyokinJoho> ryokinResultList) {
        this.ryokinResultList = ryokinResultList;
    }

    public String getRknSrcListFlg() {
        return rknSrcListFlg;
    }

    public void setRknSrcListFlg(String rknSrcListFlg) {
        this.rknSrcListFlg = rknSrcListFlg;
    }
}