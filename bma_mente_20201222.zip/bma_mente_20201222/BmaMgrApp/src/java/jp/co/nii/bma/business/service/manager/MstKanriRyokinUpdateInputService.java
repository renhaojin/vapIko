package jp.co.nii.bma.business.service.manager;

import jp.co.nii.bma.business.domain.Ryokin;
import jp.co.nii.bma.business.rto.manager.MstKanriRyokinJoho;
import jp.co.nii.bma.business.service.common.BmaConstants;
import jp.co.nii.bma.business.service.common.BmaLogger;
import jp.co.nii.bma.business.service.common.BmaValidator;
import jp.co.nii.bma.utility.BmaUtility;
import jp.co.nii.sew.business.service.AbstractService;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_SUCCESS;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_RELOAD;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_EXCEPTION;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_SESSION;
import jp.co.nii.sew.presentation.Messages;
import jp.co.nii.sew.presentation.RequestTransferObject;
import jp.co.nii.sew.utility.PropertyUtility;

/**
 *
 * @author nii19042
 */
public class MstKanriRyokinUpdateInputService extends AbstractService {

    /**
     * DB�ڑ��̃f�[�^�\�[�X
     */
    private static String DATA_SOURCE_NAME;
    /**
     * ���O
     */
    BmaLogger log = (BmaLogger) BmaLogger.getLogger(this.getClass().getName());
    /**
     * �Ɩ��R�[�h
     */
    private static final String BUSINESS_CODE = PropertyUtility.getProperty("business_code");
    /**
     * ���׃e�X�g���[�h
     */
    private static final String STRESS_MODE = PropertyUtility.getProperty(BUSINESS_CODE + "stress_mode");

    /**
     * �R���X�g���N�^
     */
    public MstKanriRyokinUpdateInputService() {
        super();
        /* DB�ڑ����̃��[�U�[������ */
        DATA_SOURCE_NAME = BmaConstants.DS_REGISTRANT;
    }

    /**
     * �T�[�r�X�N���X�̎��s���\�b�h
     *
     * @param rto ���N�G�X�g��񂩂�擾����rto
     * @param rtoInSession �Z�b�V�������rto
     * @return foward��
     * @throws Exception ��O
     */
    @Override
    public String doService(RequestTransferObject rto, RequestTransferObject rtoInSession)
            throws Exception {

        MstKanriRyokinJoho inRequest = (MstKanriRyokinJoho) rto;
        MstKanriRyokinJoho inSession = (MstKanriRyokinJoho) rtoInSession;
        String processName = "";

        /* �G���[���b�Z�[�W������ */
        inSession.setErrors(new Messages());

        try {
            if (!BmaUtility.isNullOrEmpty(inRequest.getRyokinUpdConf())) {
                /*�u�m�F�v�{�^�������� */
                processName = "MstKanriRyokinUpdateInput_Confirm";
                log.Start(processName);

                /* ���͒l���Z�b�V�����ɕێ� */
                inSession.setRyokinDisp(inRequest.getRyokinDisp());
                inSession.setZeiKbnName(inRequest.getZeiKbnName());
                inSession.setZeiritsuDisp(inRequest.getZeiritsuDisp());

                /* ���l�͑O�[���𖄂߂ăZ�b�V�����ɕێ� */
                // ����
                if (!BmaUtility.isNullOrEmpty(inRequest.getRyokinDisp())) {
                     inSession.setRyokin(String.format("%6s", inRequest.getRyokinDisp()).replace(' ', '0'));
                } else {
                    // ���͒l���Ȃ��ꍇ�̓G���[
                    inSession.setRyokin(inRequest.getRyokinDisp());
                }
                // �ŗ�
                if (!BmaUtility.isNullOrEmpty(inRequest.getZeiritsuDisp())) {
                     inSession.setZeiritsu(String.format("%2s", inRequest.getZeiritsuDisp()).replace(' ', '0'));
                } else {
                    inSession.setZeiritsu(inRequest.getZeiritsuDisp());
                }
                inSession.setZeiKbn(inRequest.getZeiKbn());

                /* ���͒l�`�F�b�N */
                if (!validateInput(inSession)) {
                    // �G���[���������ꍇ�u�����ύX���́v���Reload
                    return FWD_NM_RELOAD;
                }

                /* �\���p�f�[�^���Z�b�V�����ɕێ� */
                MstKanriRyokinJoho ryokinDetail = createRyokinDetail(inSession);
                inSession.setRyokinDisp(ryokinDetail.getRyokinDisp());
                inSession.setZeiKbnName(ryokinDetail.getZeiKbnName());
                inSession.setZeiritsuDisp(ryokinDetail.getZeiritsuDisp());

                /* �u�����ύX�m�F�v��ʕ\�� */
                return FWD_NM_SUCCESS;

            } else if (!BmaUtility.isNullOrEmpty(inRequest.getRyokinUpdInputBack())) {
                /*�u�߂�v�{�^�������� */
                processName = "MstKanriRyokinUpdateInput_BackDetail";
                log.Start(processName);

                /* ���͏���j�����ēo�^�f�[�^���ĕ\�� */
                Ryokin rkn = new Ryokin(DATA_SOURCE_NAME);
                String sknKsuCode = inSession.getSknKsuCode();
                String shubetsuCode = inSession.getShubetsuCode();
                String ryokinKbn = inSession.getRyokinKbn();

                /* �ڍ׃f�[�^���擾���A�Z�b�V�����ɕێ� */
                MstKanriRyokinJoho ryokinResult = rkn.findDetail(sknKsuCode, shubetsuCode, ryokinKbn);
                inSession.setRyokinKbnName(ryokinResult.getRyokinKbnName());
                inSession.setRyokin(ryokinResult.getRyokin());
                inSession.setZeiKbn(ryokinResult.getZeiKbn());
                inSession.setZeiritsu(ryokinResult.getZeiritsu());

                /* �\���p�̃f�[�^�𐮌`���āA�Z�b�V�����ɕێ� */
                MstKanriRyokinJoho ryokinDetail = createRyokinDetail(ryokinResult);
                inSession.setRyokinDisp(ryokinDetail.getRyokinDisp());
                inSession.setZeiKbnName(ryokinDetail.getZeiKbnName());
                inSession.setZeiritsuDisp(ryokinDetail.getZeiritsuDisp());

                /* �u�����ڍׁv��ʕ\�� */
                return FWD_NM_BACK;

            } else {
                /* �ُ�J�� */
                log.IllegalFWD();
                return FWD_NM_SESSION;
            }
        } catch (Exception e) {
            return FWD_NM_EXCEPTION;
        } finally {
            log.End(processName);
        }
    }

    /**
     * �ꗗ�\���p�ɐ��`����
     *
     * @param ryokin ���͏��
     * @return �m�F��ʕ\���p
     */
    private MstKanriRyokinJoho createRyokinDetail(MstKanriRyokinJoho ryokin){
        /* �ϐ������� */
        String ryokinBfr = "";
        String ryokinAft = "";
        String zeiKbnName = "";
        String zeiritsuBfr = "";
        String zeiritsuAft = "";
        MstKanriRyokinJoho ryokinDetail = new MstKanriRyokinJoho();

        /* �����̐��` */
        ryokinBfr = ryokin.getRyokin();
        ryokinAft = ryokinBfr.replaceFirst("^0+", "");
        if (ryokinAft.isEmpty()) {
            ryokinAft = "0";
        } else if (ryokinAft.length() > 3) {
            ryokinAft = ryokinAft.substring(0, ryokinAft.length() - 3)
                        + ","
                        + ryokinAft.substring(ryokinAft.length() - 3);
        }
        ryokinDetail.setRyokinDisp(ryokinAft);

        /* �ŋ敪���̂��Z�b�g */
        if (BmaConstants.ZEI_KBN_ZEINUKI.equals(ryokin.getZeiKbn())) {
            zeiKbnName = "�Ŕ���";
        } else if (BmaConstants.ZEI_KBN_ZEIKOMI.equals(ryokin.getZeiKbn())) {
            zeiKbnName = "�ō���";
        }
        ryokinDetail.setZeiKbnName(zeiKbnName);

        /* �ŗ��̐��` */
        zeiritsuBfr = ryokin.getZeiritsu();
        zeiritsuAft = zeiritsuBfr.replaceFirst("^0+", "");
        if (zeiritsuAft.isEmpty()) {
            zeiritsuAft = "0";
        }
        ryokinDetail.setZeiritsuDisp(zeiritsuAft);

        return ryokinDetail;
    }

    /**
     * ���̓`�F�b�N
     *
     * @param inSession �Z�b�V����RTO
     * @return true:�G���[��
     */
    private boolean validateInput(MstKanriRyokinJoho inSession) {
        /* �ϐ������� */
        Messages errors = new Messages();
        String groupCode;
        String itemName;

        // �G���[�`�F�b�N�p���X�g�쐬
        String[] zeiKbns = {BmaConstants.ZEI_KBN_ZEINUKI, BmaConstants.ZEI_KBN_ZEIKOMI};

        /* ���� */
        groupCode = "ryokin";
        itemName = "����";
        if (BmaValidator.validateRequired(inSession.getRyokin(), errors, groupCode, itemName)) {
            if (BmaValidator.validateNumber(inSession.getRyokin(), errors, groupCode, itemName)) {
                BmaValidator.validateMaxLength(inSession.getRyokin(), BmaConstants.EQUAL_LENGTH_RYOKIN, errors, groupCode, itemName);
            }
        }

        /* �ŋ敪 */
        groupCode = "zeiKbn";
        itemName = "�ŋ敪";
        if (BmaValidator.validateSelect(inSession.getZeiKbn(), errors, groupCode, itemName)) {
            BmaValidator.validatePermissionSelect(inSession.getZeiKbn(), zeiKbns, errors, groupCode, itemName);
        }

        /* �ŗ� */
        groupCode = "zeiritsu";
        itemName = "�ŗ�";
        if (BmaValidator.validateRequired(inSession.getZeiritsu(), errors, groupCode, itemName)) {
            if (BmaValidator.validateNumber(inSession.getZeiritsu(), errors, groupCode, itemName)) {
                BmaValidator.validateMaxLength(inSession.getZeiritsu(), BmaConstants.EQUAL_LENGTH_ZEIRITSU, errors, groupCode, itemName);
            }
        }

        inSession.setErrors(errors);
        return errors.isEmpty();
    }
}