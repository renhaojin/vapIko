package jp.co.nii.bma.business.service.manager;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.List;
import java.util.Calendar;
import java.util.Date;
import java.util.LinkedList;
import java.util.Map;
import java.util.HashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import jp.co.nii.bma.business.domain.Schedule;
import jp.co.nii.bma.business.rto.manager.MstKanriScheduleJoho;
import jp.co.nii.bma.business.service.common.BmaConstants;
import jp.co.nii.bma.business.service.common.BmaLogger;
import jp.co.nii.bma.business.service.common.BmaValidator;
import jp.co.nii.bma.presentation.common.BmaText;
import jp.co.nii.bma.utility.BmaUtility;
import jp.co.nii.sew.business.SystemTime;
import jp.co.nii.sew.business.service.AbstractService;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_SUCCESS;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_RELOAD;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_BACK;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_EXCEPTION;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_SESSION;
import jp.co.nii.sew.presentation.Messages;
import jp.co.nii.sew.presentation.RequestTransferObject;
import jp.co.nii.sew.utility.PropertyUtility;

/**
 *
 * @author nii19042
 */
public class MstKanriScheduleUpdateInputService extends AbstractService {

    /**
     * DB�ڑ��̃f�[�^�\�[�X
     */
    private static String DATA_SOURCE_NAME;
    /**
     * ���O
     */
    BmaLogger log = (BmaLogger) BmaLogger.getLogger(this.getClass().getName());
    /**
     * �Ɩ��R�[�h
     */
    private static final String BUSINESS_CODE = PropertyUtility.getProperty("business_code");
    /**
     * ���׃e�X�g���[�h
     */
    private static final String STRESS_MODE = PropertyUtility.getProperty(BUSINESS_CODE + "stress_mode");

    /**
     * �R���X�g���N�^
     */
    public MstKanriScheduleUpdateInputService() {
        super();
        /* DB�ڑ����̃��[�U�[������ */
        DATA_SOURCE_NAME = BmaConstants.DS_REGISTRANT;
    }

    /**
     * �T�[�r�X�N���X�̎��s���\�b�h
     *
     * @param rto ���N�G�X�g��񂩂�擾����rto
     * @param rtoInSession �Z�b�V�������rto
     * @return foward��
     * @throws Exception ��O
     */
    @Override
    public String doService(RequestTransferObject rto, RequestTransferObject rtoInSession)
            throws Exception {

        MstKanriScheduleJoho inRequest = (MstKanriScheduleJoho) rto;
        MstKanriScheduleJoho inSession = (MstKanriScheduleJoho) rtoInSession;
        String processName = "";

        /* �G���[���b�Z�[�W������ */
        inSession.setErrors(new Messages());

        try {
            if (!BmaUtility.isNullOrEmpty(inRequest.getScheduleUpdConf())) {
                /*�u�m�F�v�{�^�������� */
                processName = "MstKanriScheduleUpdateInput_Confirm";
                log.Start(processName);

                /* �ϐ������� */
                List<MstKanriScheduleJoho> scheduleUpdateListPre = new LinkedList<MstKanriScheduleJoho>();
                List<MstKanriScheduleJoho> scheduleUpdateList = new LinkedList<MstKanriScheduleJoho>();

                /* �N�x�EUpdate���X�g���Z�b�V�����ɕێ� */
                inSession.setNendo(inRequest.getNendo());
                inSession.setScheduleInputList(inRequest.getScheduleInputList());
                inSession.setScheduleResultList(inSession.getScheduleInputList());
                // ���t�E���������ꂼ�ꌋ��
                for (MstKanriScheduleJoho scedulePre : inRequest.getScheduleInputList()) {
                    createSchedule(scedulePre);
                    scheduleUpdateListPre.add(scedulePre);
                }

                /* �G���[�`�F�b�N */
                // ���͒l�`�F�b�N
                if (!validateInput(scheduleUpdateListPre, inSession)) {
                    // �G���[���������ꍇ�u�X�P�W���[���ύX���́v���Reload
                    return FWD_NM_RELOAD;
                }
                // �`�F�b�N�p�̓��t�}�b�v�쐬
                Map<String, String> dateMapForSchedCheck = createMapForSchedCheck(scheduleUpdateListPre, inSession);
                // �X�P�W���[���������`�F�b�N
                if (!validateSchedule(scheduleUpdateListPre, inSession, dateMapForSchedCheck)) {
                    // �G���[���������ꍇ�u�X�P�W���[���ύX���́v���Reload
                    return FWD_NM_RELOAD;
                }

                /* �\���p�̍��ڂ�ǉ� */
                // �ύX���͉�ʂœ��͂��Ȃ��X�P�W���[����ǉ�
                addSchedule(inSession, scheduleUpdateListPre);

                // �j���ǉ�
                for (MstKanriScheduleJoho schedule : scheduleUpdateListPre) {
                    schedule.setStartYobi(dateToWeek(schedule.getStartDate()));
                    if (!BmaUtility.isNullOrEmpty(schedule.getEndDate())) {
                        schedule.setEndYobi(dateToWeek(schedule.getEndDate()));
                    }
                    scheduleUpdateList.add(schedule);
                }

                /* ���͒l��\���p�E�X�V�p���X�g�ɂ��ꂼ��ێ� */
                inSession.setScheduleUpdateList(scheduleUpdateList);
                inSession.setScheduleResultList(inSession.getScheduleUpdateList());

                /* �u�X�P�W���[���ύX�m�F�v��ʕ\�� */
                return FWD_NM_SUCCESS;

            } else if (!BmaUtility.isNullOrEmpty(inRequest.getScheduleUpdInputBack())) {
                /*�u�߂�v�{�^��������*/
                processName = "MstKanriScheduleUpdateInput_BackScheduleSearch";
                log.Start(processName);

                /* �c���Ă�����͒l��j�� */
                inSession.setSknksuKbn("1");
                inSession.setSknName("");
                inSession.setKsuName("");
                inSession.setScheduleResultList(new LinkedList<MstKanriScheduleJoho>());
                inSession.setScheduleInputList(new LinkedList<MstKanriScheduleJoho>());
                inSession.setScheduleSrcListFlg("");

                /* �u�X�P�W���[�������v��ʕ\�� */
                return FWD_NM_BACK;

            } else {
                /* �ُ�J�� */
                log.IllegalFWD();
                return FWD_NM_SESSION;
            }
        } catch (Exception e) {
            return FWD_NM_EXCEPTION;
        } finally {
            log.End(processName);
        }
    }

    /**
     * ���͒l���X�V�p�ɕҏW����
     * @param schedule�@���f�[�^
     */
    public static void createSchedule(MstKanriScheduleJoho schedule) {
        /* �ϐ������� */
        String startDate = "";
        String startTime = "";
        String endDate = "";
        String endTime = "";

        // �J�n���t
        // �O�[������
        if (!BmaUtility.isNullOrEmpty(schedule.getStartYear())) {
            schedule.setStartYear(String.format("%4s", schedule.getStartYear()).replace(' ', '0'));
            startDate = schedule.getStartYear();
        } else {
            // ���͒l���Ȃ��ꍇ�̓G���[
            schedule.setStartYear(schedule.getStartYear());
        }
        if (!BmaUtility.isNullOrEmpty(schedule.getStartMonth())) {
            schedule.setStartMonth(String.format("%2s", schedule.getStartMonth()).replace(' ', '0'));
            startDate += schedule.getStartMonth();
        } else {
            schedule.setStartYear(schedule.getStartYear());
        }
        if (!BmaUtility.isNullOrEmpty(schedule.getStartDay())) {
            schedule.setStartDay(String.format("%2s", schedule.getStartDay()).replace(' ', '0'));
            startDate += schedule.getStartDay();
        } else {
            schedule.setStartDay(schedule.getStartDay());
        }
        schedule.setStartDate(startDate);

        // �J�n����
        if (!BmaUtility.isNullOrEmpty(schedule.getStartHour())) {
            schedule.setStartHour(String.format("%2s", schedule.getStartHour()).replace(' ', '0'));
            startTime = schedule.getStartHour();
        } else {
            schedule.setStartHour(schedule.getStartHour());
        }
        if (!BmaUtility.isNullOrEmpty(schedule.getStartMinute())) {
            schedule.setStartMinute(String.format("%2s", schedule.getStartMinute()).replace(' ', '0'));
            startTime += schedule.getStartMinute() + "00";
        } else {
            schedule.setStartMinute(schedule.getStartMinute());
        }
        schedule.setStartTime(startTime);

        // �I�����t
        if (!BmaUtility.isNullOrEmpty(schedule.getEndYear())) {
            schedule.setEndYear(String.format("%4s", schedule.getEndYear()).replace(' ', '0'));
            endDate = schedule.getEndYear();
        } else {
            schedule.setEndYear(schedule.getEndYear());
        }
        if (!BmaUtility.isNullOrEmpty(schedule.getEndMonth())) {
            schedule.setEndMonth(String.format("%2s", schedule.getEndMonth()).replace(' ', '0'));
            endDate += schedule.getEndMonth();
        } else {
            schedule.setEndMonth(schedule.getEndMonth());
        }
        if (!BmaUtility.isNullOrEmpty(schedule.getEndDay())) {
            schedule.setEndDay(String.format("%2s", schedule.getEndDay()).replace(' ', '0'));
            endDate += schedule.getEndDay();
        } else {
            schedule.setEndDay(schedule.getEndDay());
        }
        schedule.setEndDate(endDate);

        // �I������
        if (!BmaUtility.isNullOrEmpty(schedule.getEndHour())) {
            schedule.setEndHour(String.format("%2s", schedule.getEndHour()).replace(' ', '0'));
            endTime = schedule.getEndHour();
        } else {
            schedule.setEndHour(schedule.getEndHour());
        }
        if (!BmaUtility.isNullOrEmpty(schedule.getEndMinute())) {
            schedule.setEndMinute(String.format("%2s", schedule.getEndMinute()).replace(' ', '0'));
            endTime += schedule.getEndMinute() + "00";
        } else {
            schedule.setEndMinute(schedule.getEndMinute());
        }
        schedule.setEndTime(endTime);
    }

    /**
     * �ύX���͉�ʂœ��͂��Ȃ��l���Z�b�g����
     * @param nendo�@���͔N�x
     * @param scheduleResultList�@�������ʃ��X�g
     * @param scheduleInputList�@��ʓ��͒l���X�g
     */
    public static void addSchedule(MstKanriScheduleJoho inSession, List<MstKanriScheduleJoho> scheduleInputList) {
        /* �ϐ������� */
        Schedule sched = new Schedule(DATA_SOURCE_NAME);
        String searchTime = "";
        MstKanriScheduleJoho nenreiKeisan = new MstKanriScheduleJoho();
        String date = "";
        MstKanriScheduleJoho jitsumuKeiken = new MstKanriScheduleJoho();

        SimpleDateFormat f = new SimpleDateFormat("yyyyMMdd");
        Date maxDate;

        /* �N��v�Z��� �N�x4/1 */
        nenreiKeisan = scheduleInputList.get(14);
        nenreiKeisan.setNendo(inSession.getNendo());
        date = inSession.getNendo() + "0401";
        nenreiKeisan.setDate(date);
        // �\���p
        nenreiKeisan.setStartDate(date);
        nenreiKeisan.setStartYear(inSession.getNendo());
        nenreiKeisan.setStartMonth("04");
        nenreiKeisan.setStartDay("01");

        // �����͓o�^����Ă��鎞�����̂܂�
        searchTime = sched.findTime(inSession.getSknKsuCode(), inSession.getShubetsuCode(), inSession.getKaisuCode(), BmaConstants.SCHED_CODE_NENREI_CALC, BmaConstants.SCHEDULE_KBN_BS);
        nenreiKeisan.setTime(searchTime);
        nenreiKeisan.setStartTime(searchTime);
        nenreiKeisan.setStartHour(searchTime.substring(0, 2));
        nenreiKeisan.setStartMinute(searchTime.substring(2, 4));

        scheduleInputList.set(14,nenreiKeisan);

        /* �����o���N���v�Z��� �\���ŏI�� */
        jitsumuKeiken = scheduleInputList.get(15);
        jitsumuKeiken.setNendo(inSession.getNendo());

        // �\���ŏI�����擾
        try {
            maxDate = f.parse(scheduleInputList.get(2).getEndDate());                // WEB�\���@��t���ԁy����z�̏I���� ����
            if (f.parse(scheduleInputList.get(3).getEndDate()).after(maxDate)) {     // WEB�\���@��t���ԁy��ʁz �̕�����
                maxDate = f.parse(scheduleInputList.get(3).getEndDate());
            }
            if  (f.parse(scheduleInputList.get(4).getEndDate()).after(maxDate)) {     // �X���\���@��t���ԁy����z �̕�����
                maxDate = f.parse(scheduleInputList.get(4).getEndDate());
            }
            if  (f.parse(scheduleInputList.get(5).getEndDate()).after(maxDate)) {     // �X���\���@��t���ԁy��ʁz �̕�����
                maxDate = f.parse(scheduleInputList.get(5).getEndDate());
            }
            date = f.format(maxDate);
        } catch (ParseException e) {
            e.printStackTrace();
        }

        jitsumuKeiken.setDate(date);
        // �\���p
        jitsumuKeiken.setStartDate(date);
        jitsumuKeiken.setStartYear(date.substring(0, 4));
        jitsumuKeiken.setStartMonth(date.substring(4, 6));
        jitsumuKeiken.setStartDay(date.substring(6, 8));

        // �����͓o�^����Ă��鎞�����̂܂�
        searchTime = sched.findTime(inSession.getSknKsuCode(), inSession.getShubetsuCode(), inSession.getKaisuCode(), BmaConstants.SCHED_CODE_JITSUMU_CALC, BmaConstants.SCHEDULE_KBN_BS);
        jitsumuKeiken.setTime(searchTime);
        jitsumuKeiken.setStartTime(searchTime);
        jitsumuKeiken.setStartHour(searchTime.substring(0, 2));
        jitsumuKeiken.setStartMinute(searchTime.substring(2, 4));

        scheduleInputList.set(15,jitsumuKeiken);
    }

    /**
     * ���t�ɂ���ėj�����擾����
     * @param datetime�@���t
     * @return  �j��
     */
    public static String dateToWeek(String datetime) {

        SimpleDateFormat f = new SimpleDateFormat("yyyyMMdd");
        String[] weekDays = {"��", "��", "��", "��", "��", "��", "�y"};
        Calendar cal = Calendar.getInstance();
        Date date;
        try {
            date = f.parse(datetime);
            cal.setTime(date);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        //the day number of a week
        int w = cal.get(Calendar.DAY_OF_WEEK) - 1;
        if (w < 0)
            w = 0;
        return weekDays[w];
    }

    /**
     * �X�P�W���[���������`�F�b�N�p�̓��t���X�g���쐬����
     *
     * @param scheduleList �X�P�W���[�����̓��X�g
     * @param inSession �Z�b�V�������
     * @return �`�F�b�N�p���t�}�b�v
     */
    private Map<String, String> createMapForSchedCheck(List<MstKanriScheduleJoho> scheduleList, MstKanriScheduleJoho inSession) {
        /* �ϐ������� */
        Map<String, String> resultMap = new HashMap<String, String>();
        SimpleDateFormat f = new SimpleDateFormat("yyyyMMdd");
        Date checkerDate;
        String checkerDateStr = "";

        /* ����p�̓��t���擾 */
        // �\���̍ő��J�n��
            try {
                checkerDate = f.parse(scheduleList.get(2).getStartDate());                // WEB�\���@��t���ԁy����z�̊J�n�� ����
                if (f.parse(scheduleList.get(3).getStartDate()).before(checkerDate)) {     // WEB�\���@��t���ԁy��ʁz �̕�����
                    checkerDate = f.parse(scheduleList.get(3).getStartDate());
                }
                if  (f.parse(scheduleList.get(4).getStartDate()).before(checkerDate)) {     // �X���\���@��t���ԁy����z �̕�����
                    checkerDate = f.parse(scheduleList.get(4).getStartDate());
                }
                if  (f.parse(scheduleList.get(5).getStartDate()).before(checkerDate)) {     // �X���\���@��t���ԁy��ʁz �̕�����
                    checkerDate = f.parse(scheduleList.get(5).getStartDate());
                }
                checkerDateStr = f.format(checkerDate);
            } catch (ParseException e) {
                e.printStackTrace();
            }
            resultMap.put("moshikomiFirstDate", checkerDateStr);
        // �\���̍Œx�I����
            try {
                checkerDate = f.parse(scheduleList.get(2).getEndDate());                // WEB�\���@��t���ԁy����z�̏I���� ����
                if (f.parse(scheduleList.get(3).getEndDate()).after(checkerDate)) {     // WEB�\���@��t���ԁy��ʁz �̕�����
                    checkerDate = f.parse(scheduleList.get(3).getEndDate());
                }
                if  (f.parse(scheduleList.get(4).getEndDate()).after(checkerDate)) {     // �X���\���@��t���ԁy����z �̕�����
                    checkerDate = f.parse(scheduleList.get(4).getEndDate());
                }
                if  (f.parse(scheduleList.get(5).getEndDate()).after(checkerDate)) {     // �X���\���@��t���ԁy��ʁz �̕�����
                    checkerDate = f.parse(scheduleList.get(5).getEndDate());
                }
                checkerDateStr = f.format(checkerDate);
            } catch (ParseException e) {
                e.printStackTrace();
            }
            resultMap.put("moshikomiLastDate", checkerDateStr);
        // �����Ɖ摜�̍Œx�I����
            try {
                checkerDate = f.parse(scheduleList.get(6).getEndDate());                // WEB�@�������Ԃ̏I���� ����
                if (f.parse(scheduleList.get(7).getEndDate()).after(checkerDate)) {     // �X���@�������� �̕�����
                    checkerDate = f.parse(scheduleList.get(7).getEndDate());
                }
                if  (f.parse(scheduleList.get(8).getEndDate()).after(checkerDate)) {     // �摜�s���@�������� �̕�����
                    checkerDate = f.parse(scheduleList.get(8).getEndDate());
                }
                checkerDateStr = f.format(checkerDate);
            } catch (ParseException e) {
                e.printStackTrace();
            }
            resultMap.put("HaraikomiGazoLastDate", checkerDateStr);
        // �󌟎�u�[������
            checkerDateStr = scheduleList.get(9).getStartDate();
            resultMap.put("JknJkuSendDate", checkerDateStr);
        // �u�K��i���Z�����j�I����
            checkerDateStr = scheduleList.get(10).getEndDate();
            resultMap.put("KsuJitsugiEndDate", checkerDateStr);

        if (BmaConstants.SKN_KBN.equals(inSession.getSknksuKbn())) {
        // �w�Ȏ��Z�̑S�����I����
            try {
                checkerDate = f.parse(scheduleList.get(10).getStartDate());                // �w�Ȏ����E���Z�y�[�p�[�e�X�g�̎��{�� ����
                if (f.parse(scheduleList.get(11).getEndDate()).after(checkerDate)) {     // ���Z��Ǝ��� �̕�����
                    checkerDate = f.parse(scheduleList.get(11).getEndDate());
                }
                checkerDateStr = f.format(checkerDate);
            } catch (ParseException e) {
                e.printStackTrace();
            }
            resultMap.put("ShikenEndDate", checkerDateStr);
        } else {
        // ���Z�C���̑S�u�K��I����
            try {
                checkerDate = f.parse(scheduleList.get(10).getEndDate());                // �u�K��i���Z���K�j�̏I���� ����
                // �C���y�N�y�V�K�z�̂݁A�C���ۑ�I�����̔���
                if ("IP".equals(inSession.getSknKsuCode()) && "11".equals(inSession.getShubetsuCode())) {
                    if (f.parse(scheduleList.get(11).getEndDate()).after(checkerDate)) {     // �u�K��i�C���ۑ�j �̕�����
                        checkerDate = f.parse(scheduleList.get(11).getEndDate());
                    }
                }
                checkerDateStr = f.format(checkerDate);
            } catch (ParseException e) {
                e.printStackTrace();
            }
            resultMap.put("KoshukaiEndDate", checkerDateStr);
        }
        // ���i���\��
            checkerDateStr = scheduleList.get(12).getStartDate();
            resultMap.put("GohatsuDate", checkerDateStr);

        return resultMap;
    }

    /**
     * ���͒l�`�F�b�N
     *
     * @param scheduleList �X�P�W���[�����̓��X�g
     * @param inSession �Z�b�V����
     * @return true:�G���[��
     */
    private boolean validateInput(List<MstKanriScheduleJoho> scheduleList, MstKanriScheduleJoho inSession) {
        /* �ϐ������� */
        Messages errors = new Messages();
        String groupCode = "";
        String itemName = "";
        Schedule sched = new Schedule(DATA_SOURCE_NAME);
        String nendoDb = "";

        /* �G���[�`�F�b�N�p���X�g�쐬 */
        // �I�����̓��͂��s�v�ȃR�[�h�ꗗ
        String[] noEndDateCodes = {BmaConstants.SCHED_CODE_JUKENHYO_SEND, BmaConstants.SCHED_CODE_SKN_GAKKA, BmaConstants.SCHED_CODE_GOUHATSU, BmaConstants.SCHED_CODE_GOKAKU_SEND};

        /* �N�x */
        groupCode = "nendo";
        itemName = "�N�x";
        if (BmaValidator.validateRequired(inSession.getNendo(), errors, groupCode, itemName)) {
            if (BmaValidator.validateNumber(inSession.getNendo(), errors, groupCode, itemName)) {
                BmaValidator.validateMaxLength(inSession.getNendo(), BmaConstants.EQUAL_LENGTH_SCHEDULE_NENDO, errors, groupCode, itemName);
            }
        }

        // DB�ɓo�^����Ă���N�x���擾 �X�P�W���[�������J�n���̍ŐV�N�x
        nendoDb = sched.findNendoKojiKikan(inSession.getSknKsuCode(), inSession.getShubetsuCode(), inSession.getKaisuCode(), BmaConstants.SCHED_CODE_OPEN, BmaConstants.SCHEDULE_KBN_ST);
        // ���݂̓o�^�N�x���O�̒l�̓G���[
        if (errors.get(groupCode) == null) {
            if (Integer.parseInt(nendoDb) > Integer.parseInt(inSession.getNendo())) {
                BmaValidator.addMessage(errors, groupCode, BmaText.E00122, itemName);
            }
        }

        /* �X�P�W���[�����͕� */
        for (MstKanriScheduleJoho schedule : scheduleList) {
            // �N��v�Z����E�����o���N���v�Z����̓`�F�b�N�㎩������
            if (BmaConstants.SCHED_CODE_NENREI_CALC.equals(schedule.getScheduleCode()) || BmaConstants.SCHED_CODE_JITSUMU_CALC.equals(schedule.getScheduleCode())) {
                continue;
            // �C���s���Ԃ͓��͂Ȃ��ł�OK
            } else if (   (BmaConstants.SCHED_CODE_CANT_UPD1.equals(schedule.getScheduleCode()) || BmaConstants.SCHED_CODE_CANT_UPD2.equals(schedule.getScheduleCode()))
                       && (BmaUtility.isNullOrEmpty(schedule.getStartDate()) && BmaUtility.isNullOrEmpty(schedule.getStartTime()))
                       && (BmaUtility.isNullOrEmpty(schedule.getEndDate()) && BmaUtility.isNullOrEmpty(schedule.getEndTime()))) {
                continue;
            // �C���y�N�y�V�K�z�ȊO�̍u�K��́A�u�K��i�C���ۑ�j�̃`�F�b�N�Ȃ�
            } else if (   !("IP".equals(inSession.getSknKsuCode()) && "11".equals(inSession.getShubetsuCode()))
                       && BmaConstants.SCHED_CODE_KSU_SHURYO.equals(schedule.getScheduleCode())) {
                continue;
            } else {
                /* �J�n���E��� */
                groupCode = "date" + schedule.getScheduleCode();
                /* ���t */
                // �N
                itemName = schedule.getScheduleName() + "�J�n���̔N";
                if (BmaValidator.validateRequired(schedule.getStartYear(), errors, groupCode, itemName)) {
                    if (BmaValidator.validateNumber(schedule.getStartYear(), errors, groupCode, itemName)) {
                        BmaValidator.validateMaxLength(schedule.getStartYear(), BmaConstants.EQUAL_LENGTH_SCHED_DATE_YEAR, errors, groupCode, itemName);
                    }
                }
                // ��
                itemName = schedule.getScheduleName() + "�J�n���̌�";
                if (BmaValidator.validateRequired(schedule.getStartMonth(), errors, groupCode, itemName)) {
                    if (BmaValidator.validateNumber(schedule.getStartMonth(), errors, groupCode, itemName)) {
                        BmaValidator.validateMaxLength(schedule.getStartMonth(), BmaConstants.EQUAL_LENGTH_SCHED_DATE_MONTH, errors, groupCode, itemName);
                    }
                }
                // ��
                itemName = schedule.getScheduleName() + "�J�n���̓�";
                if (BmaValidator.validateRequired(schedule.getStartDay(), errors, groupCode, itemName)) {
                    if (BmaValidator.validateNumber(schedule.getStartDay(), errors, groupCode, itemName)) {
                        BmaValidator.validateMaxLength(schedule.getStartDay(), BmaConstants.EQUAL_LENGTH_SCHED_DATE_DAY, errors, groupCode, itemName);
                    }
                }
                // ���t�̐�����
                if (errors.get(groupCode) == null) {
                    itemName = schedule.getScheduleName() + "�J�n��";
                    BmaValidator.validateDate2(schedule.getStartDate(), errors, groupCode, itemName);
                }

                /* ���� */
                groupCode = "time" + schedule.getScheduleCode();
                // ��
                itemName = schedule.getScheduleName() + "�J�n�����̎�";
                if (BmaValidator.validateRequired(schedule.getStartHour(), errors, groupCode, itemName)) {
                    if (BmaValidator.validateNumber(schedule.getStartHour(), errors, groupCode, itemName)) {
                        BmaValidator.validateMaxLength(schedule.getStartHour(), BmaConstants.EQUAL_LENGTH_SCHED_TIME_HOUR, errors, groupCode, itemName);
                    }
                }
                // ��
                itemName = schedule.getScheduleName() + "�J�n�����̕�";
                if (BmaValidator.validateRequired(schedule.getStartMinute(), errors, groupCode, itemName)) {
                    if (BmaValidator.validateNumber(schedule.getStartMinute(), errors, groupCode, itemName)) {
                        BmaValidator.validateMaxLength(schedule.getStartMinute(), BmaConstants.EQUAL_LENGTH_SCHED_TIME_MINUTE, errors, groupCode, itemName);
                    }
                }
                // �����̐�����
                if (errors.get(groupCode) == null) {
                    itemName = schedule.getScheduleName() + "�J�n����";
                    if (!checkTime(schedule.getStartTime())) {
                        BmaValidator.addMessage(errors, groupCode, BmaText.E00123, itemName);
                    }
                }

                /* �I���� */
                if (!Arrays.asList(noEndDateCodes).contains(schedule.getScheduleCode())) {
                    /* ���t */
                    // �N
                    itemName = schedule.getScheduleName() + "�I�����̔N";
                    if (BmaValidator.validateRequired(schedule.getEndYear(), errors, groupCode, itemName)) {
                        if (BmaValidator.validateNumber(schedule.getEndYear(), errors, groupCode, itemName)) {
                            BmaValidator.validateMaxLength(schedule.getEndYear(), BmaConstants.EQUAL_LENGTH_SCHED_DATE_YEAR, errors, groupCode, itemName);
                        }
                    }
                    // ��
                    itemName = schedule.getScheduleName() + "�I�����̌�";
                    if (BmaValidator.validateRequired(schedule.getEndMonth(), errors, groupCode, itemName)) {
                        if (BmaValidator.validateNumber(schedule.getEndMonth(), errors, groupCode, itemName)) {
                            BmaValidator.validateMaxLength(schedule.getEndMonth(), BmaConstants.EQUAL_LENGTH_SCHED_DATE_MONTH, errors, groupCode, itemName);
                        }
                    }
                    // ��
                    itemName = schedule.getScheduleName() + "�I�����̓�";
                    if (BmaValidator.validateRequired(schedule.getEndDay(), errors, groupCode, itemName)) {
                        if (BmaValidator.validateNumber(schedule.getEndDay(), errors, groupCode, itemName)) {
                            BmaValidator.validateMaxLength(schedule.getEndDay(), BmaConstants.EQUAL_LENGTH_SCHED_DATE_DAY, errors, groupCode, itemName);
                        }
                    }
                    // ���t�̐�����
                    if (errors.get(groupCode) == null) {
                        itemName = schedule.getScheduleName() + "�I����";
                        BmaValidator.validateDate2(schedule.getEndDate(), errors, groupCode, itemName);
                    }

                    /* ���� */
                    groupCode = "time" + schedule.getScheduleCode();
                    // ��
                    itemName = schedule.getScheduleName() + "�I�������̎�";
                    if (BmaValidator.validateRequired(schedule.getEndHour(), errors, groupCode, itemName)) {
                        if (BmaValidator.validateNumber(schedule.getEndHour(), errors, groupCode, itemName)) {
                            BmaValidator.validateMaxLength(schedule.getEndHour(), BmaConstants.EQUAL_LENGTH_SCHED_TIME_HOUR, errors, groupCode, itemName);
                        }
                    }
                    // ��
                    itemName = schedule.getScheduleName() + "�I�������̕�";
                    if (BmaValidator.validateRequired(schedule.getEndMinute(), errors, groupCode, itemName)) {
                        if (BmaValidator.validateNumber(schedule.getEndMinute(), errors, groupCode, itemName)) {
                            BmaValidator.validateMaxLength(schedule.getEndMinute(), BmaConstants.EQUAL_LENGTH_SCHED_TIME_MINUTE, errors, groupCode, itemName);
                        }
                    }
                    // �����̐�����
                    if (errors.get(groupCode) == null) {
                        itemName = schedule.getScheduleName() + "�I������";
                        if (!checkTime(schedule.getEndTime())) {
                            BmaValidator.addMessage(errors, groupCode, BmaText.E00123, itemName);
                        }
                    }
                }
            }
        }

        inSession.setErrors(errors);
        return errors.isEmpty();
    }

    /**
     * �X�P�W���[���������`�F�b�N
     *
     * @param scheduleList �X�P�W���[�����̓��X�g
     * @param inSession �Z�b�V����
     * @return true:�G���[��
     */
    private boolean validateSchedule(List<MstKanriScheduleJoho> scheduleList, MstKanriScheduleJoho inSession, Map<String, String> dateMapForSchedCheck) {
        /* �ϐ������� */
        Messages errors = new Messages();
        String groupCode;
        String itemName;
        String strMessage1;
        String strMessage2;
        String startDateOpen = "";
        String endDateOpen = "";
        String startDateDataUpd = "";
        String endDateDataUpd = "";
        String compareResult = "";

        /* �V�X�e�����t�擾 */
        SystemTime sysTime = new SystemTime();
        String sysDate = sysTime.getymd1();

        /* �X�P�W���[�����͕� */
        for (MstKanriScheduleJoho schedule : scheduleList) {
            // �N��v�Z����E�����o���N���v�Z����̓`�F�b�N�㎩������
            if (BmaConstants.SCHED_CODE_NENREI_CALC.equals(schedule.getScheduleCode()) || BmaConstants.SCHED_CODE_JITSUMU_CALC.equals(schedule.getScheduleCode())) {
                continue;
            // �C���s���Ԃ͓��͂Ȃ��ł�OK
            } else if (   (BmaConstants.SCHED_CODE_CANT_UPD1.equals(schedule.getScheduleCode()) || BmaConstants.SCHED_CODE_CANT_UPD2.equals(schedule.getScheduleCode()))
                && (BmaUtility.isNullOrEmpty(schedule.getStartDate()) && BmaUtility.isNullOrEmpty(schedule.getStartTime()))
                && (BmaUtility.isNullOrEmpty(schedule.getEndDate()) && BmaUtility.isNullOrEmpty(schedule.getEndTime()))) {
                continue;
            // �C���y�N�y�V�K�z�ȊO�̍u�K��́A�u�K��i�C���ۑ�j�̃`�F�b�N�Ȃ�
            } else if (   !("IP".equals(inSession.getSknKsuCode()) && "11".equals(inSession.getShubetsuCode()))
                       && BmaConstants.SCHED_CODE_KSU_SHURYO.equals(schedule.getScheduleCode())) {
                continue;
            } else {
                if (BmaConstants.SCHED_CODE_OPEN.equals(schedule.getScheduleCode())) {
                    // �X�P�W���[���������� �G���[�������return
                    groupCode = "schedOpen";
                    itemName = "�X�P�W���[����������";
                    if (checkSysDateInTerm(sysDate, schedule.getStartDate(), schedule.getEndDate())) {
                        BmaValidator.addMessage(errors, groupCode, BmaText.E00124, itemName);
                    } else if (!checkStartEndDate(schedule.getStartDate(), schedule.getEndDate(), schedule.getStartTime(), schedule.getEndTime())) {
                        BmaValidator.addMessage(errors, groupCode, BmaText.E00126, itemName);
                    } else if (!checkNumOfDays(schedule.getStartDate(), schedule.getEndDate())) {
                        strMessage1 = "1�N";
                        BmaValidator.addMessage(errors, groupCode, BmaText.E00129, itemName, strMessage1);
                    }
                    if (errors.isEmpty()) {
                        startDateOpen = schedule.getStartDate();
                        endDateOpen = schedule.getEndDate();
                    } else {
                        inSession.setErrors(errors);
                        return errors.isEmpty();
                    }
                } else if (BmaConstants.SCHED_CODE_DATA_UPD.equals(schedule.getScheduleCode())) {
                    // ��u�҃f�[�^�ύX�\���� �G���[�������return
                    groupCode = "schedDataUpdate";
                    itemName = "��u�҃f�[�^�ύX�\����";
                    if (checkSysDateInTerm(sysDate, schedule.getStartDate(), schedule.getEndDate())) {
                        BmaValidator.addMessage(errors, groupCode, BmaText.E00124, itemName);
                    } else if (!checkStartEndDate(schedule.getStartDate(), schedule.getEndDate(), schedule.getStartTime(), schedule.getEndTime())) {
                        BmaValidator.addMessage(errors, groupCode, BmaText.E00126, itemName);
                    } else if (!checkNumOfDays(schedule.getStartDate(), schedule.getEndDate())) {
                        strMessage1 = "1�N";
                        BmaValidator.addMessage(errors, groupCode, BmaText.E00129, itemName, strMessage1);
                    }
                    if (errors.isEmpty()) {
                        compareResult = compareTwoDays(schedule.getStartDate(), dateMapForSchedCheck.get("moshikomiFirstDate"));
                        if (!BmaUtility.isNullOrEmpty(compareResult) && "1".equals(compareResult)) {
                            strMessage1 = itemName + "�̊J�n��";
                            strMessage2 = "�e�\���̊J�n��";
                            BmaValidator.addMessage(errors, groupCode, BmaText.E00127, strMessage1, strMessage2);
                        }
                    }
                    if (errors.isEmpty()) {
                        startDateDataUpd = schedule.getStartDate();
                        endDateDataUpd = schedule.getEndDate();
                    } else {
                        inSession.setErrors(errors);
                        return errors.isEmpty();
                    }
                } else if (BmaConstants.SCHED_CODE_WEB_KAIIN.equals(schedule.getScheduleCode())) {
                    // WEB��t���ԁy����z
                    groupCode = "schedWebUketsukeKaiin";
                    itemName = "WEB��t���ԁy����z";
                    if (checkSysDateInTerm(sysDate, schedule.getStartDate(), schedule.getEndDate())) {
                        BmaValidator.addMessage(errors, groupCode, BmaText.E00124, itemName);
                    } else if (!checkDaysInTerm(schedule.getStartDate(), schedule.getEndDate(), startDateOpen, endDateOpen)) {
                        strMessage1 = "�X�P�W���[����������";
                        BmaValidator.addMessage(errors, groupCode, BmaText.E00129, itemName, strMessage1);
                    } else if (!checkStartEndDate(schedule.getStartDate(), schedule.getEndDate(), schedule.getStartTime(), schedule.getEndTime())) {
                        BmaValidator.addMessage(errors, groupCode, BmaText.E00126, itemName);
                    }
                } else if (BmaConstants.SCHED_CODE_WEB_IPPAN.equals(schedule.getScheduleCode())) {
                    // WEB��t���ԁy��ʁz
                    groupCode = "schedWebUketsukeIppan";
                    itemName = "WEB��t���ԁy��ʁz";
                    if (checkSysDateInTerm(sysDate, schedule.getStartDate(), schedule.getEndDate())) {
                        BmaValidator.addMessage(errors, groupCode, BmaText.E00124, itemName);
                    } else if (!checkDaysInTerm(schedule.getStartDate(), schedule.getEndDate(), startDateOpen, endDateOpen)) {
                        strMessage1 = "�X�P�W���[����������";
                        BmaValidator.addMessage(errors, groupCode, BmaText.E00129, itemName, strMessage1);
                    } else if (!checkStartEndDate(schedule.getStartDate(), schedule.getEndDate(), schedule.getStartTime(), schedule.getEndTime())) {
                        BmaValidator.addMessage(errors, groupCode, BmaText.E00126, itemName);
                    }
                } else if (BmaConstants.SCHED_CODE_YUSO_KAIIN.equals(schedule.getScheduleCode())) {
                    // �X����t���ԁy����z
                    groupCode = "schedYusoUketsukeKaiin";
                    itemName = "�X����t���ԁy����z";
                    if (checkSysDateInTerm(sysDate, schedule.getStartDate(), schedule.getEndDate())) {
                        BmaValidator.addMessage(errors, groupCode, BmaText.E00124, itemName);
                    } else if (!checkDaysInTerm(schedule.getStartDate(), schedule.getEndDate(), startDateOpen, endDateOpen)) {
                        strMessage1 = "�X�P�W���[����������";
                        BmaValidator.addMessage(errors, groupCode, BmaText.E00129, itemName, strMessage1);
                    } else if (!checkStartEndDate(schedule.getStartDate(), schedule.getEndDate(), schedule.getStartTime(), schedule.getEndTime())) {
                        BmaValidator.addMessage(errors, groupCode, BmaText.E00126, itemName);
                    }
                } else if (BmaConstants.SCHED_CODE_YUSO_IPPAN.equals(schedule.getScheduleCode())) {
                    // �X����t���ԁy��ʁz
                    groupCode = "schedYusoUketsukeIppan";
                    itemName = "�X����t���ԁy��ʁz";
                    if (checkSysDateInTerm(sysDate, schedule.getStartDate(), schedule.getEndDate())) {
                        BmaValidator.addMessage(errors, groupCode, BmaText.E00124, itemName);
                    } else if (!checkDaysInTerm(schedule.getStartDate(), schedule.getEndDate(), startDateOpen, endDateOpen)) {
                        strMessage1 = "�X�P�W���[����������";
                        BmaValidator.addMessage(errors, groupCode, BmaText.E00129, itemName, strMessage1);
                    } else if (!checkStartEndDate(schedule.getStartDate(), schedule.getEndDate(), schedule.getStartTime(), schedule.getEndTime())) {
                        BmaValidator.addMessage(errors, groupCode, BmaText.E00126, itemName);
                    }
                } else if (BmaConstants.SCHED_CODE_HARAIKOMI_WEB.equals(schedule.getScheduleCode())) {
                    // WEB��������
                    groupCode = "schedWebHaraikomi";
                    itemName = "WEB��������";
                    if (checkSysDateInTerm(sysDate, schedule.getStartDate(), schedule.getEndDate())) {
                        BmaValidator.addMessage(errors, groupCode, BmaText.E00124, itemName);
                    } else if (!checkDaysInTerm(schedule.getStartDate(), schedule.getEndDate(), startDateOpen, endDateOpen)) {
                        strMessage1 = "�X�P�W���[����������";
                        BmaValidator.addMessage(errors, groupCode, BmaText.E00129, itemName, strMessage1);
                    } else if (!checkStartEndDate(schedule.getStartDate(), schedule.getEndDate(), schedule.getStartTime(), schedule.getEndTime())) {
                        BmaValidator.addMessage(errors, groupCode, BmaText.E00126, itemName);
                    }
                    if (errors.get(groupCode) == null) {
                        compareResult = compareTwoDays(schedule.getStartDate(), dateMapForSchedCheck.get("moshikomiFirstDate"));
                        if (!BmaUtility.isNullOrEmpty(compareResult) && "1".equals(compareResult)) {
                            strMessage1 = itemName + "�̊J�n��";
                            strMessage2 = "�e�\���̊J�n��";
                            BmaValidator.addMessage(errors, groupCode, BmaText.E00127, strMessage1, strMessage2);
                        }
                    }
                    if (errors.get(groupCode) == null) {
                        compareResult = compareTwoDays(schedule.getEndDate(), dateMapForSchedCheck.get("moshikomiLastDate"));
                        if (!BmaUtility.isNullOrEmpty(compareResult) && "1".equals(compareResult)) {
                            strMessage1 = itemName + "�̏I����";
                            strMessage2 = "�e�\���̏I����";
                            BmaValidator.addMessage(errors, groupCode, BmaText.E00127, strMessage1, strMessage2);
                        }
                    }
                } else if (BmaConstants.SCHED_CODE_HARAIKOMI_YUSO.equals(schedule.getScheduleCode())) {
                    // �X����������
                    groupCode = "schedYusoHaraikomi";
                    itemName = "�X����������";
                    if (checkSysDateInTerm(sysDate, schedule.getStartDate(), schedule.getEndDate())) {
                        BmaValidator.addMessage(errors, groupCode, BmaText.E00124, itemName);
                    } else if (!checkDaysInTerm(schedule.getStartDate(), schedule.getEndDate(), startDateOpen, endDateOpen)) {
                        strMessage1 = "�X�P�W���[����������";
                        BmaValidator.addMessage(errors, groupCode, BmaText.E00129, itemName, strMessage1);
                    } else if (!checkStartEndDate(schedule.getStartDate(), schedule.getEndDate(), schedule.getStartTime(), schedule.getEndTime())) {
                        BmaValidator.addMessage(errors, groupCode, BmaText.E00126, itemName);
                    }
                    if (errors.get(groupCode) == null) {
                        compareResult = compareTwoDays(schedule.getStartDate(), dateMapForSchedCheck.get("moshikomiFirstDate"));
                        if (!BmaUtility.isNullOrEmpty(compareResult) && "1".equals(compareResult)) {
                            strMessage1 = itemName + "�̊J�n��";
                            strMessage2 = "�e�\���̊J�n��";
                            BmaValidator.addMessage(errors, groupCode, BmaText.E00127, strMessage1, strMessage2);
                        }
                    }
                    if (errors.get(groupCode) == null) {
                        compareResult = compareTwoDays(schedule.getEndDate(), dateMapForSchedCheck.get("moshikomiLastDate"));
                        if (!BmaUtility.isNullOrEmpty(compareResult) && "1".equals(compareResult)) {
                            strMessage1 = itemName + "�̏I����";
                            strMessage2 = "�e�\���̏I����";
                            BmaValidator.addMessage(errors, groupCode, BmaText.E00127, strMessage1, strMessage2);
                        }
                    }
                } else if (BmaConstants.SCHED_CODE_GAZO_KAISHO.equals(schedule.getScheduleCode())) {
                    // �摜�s����������
                    groupCode = "schedGazoKaisho";
                    itemName = "�摜�s����������";
                    if (checkSysDateInTerm(sysDate, schedule.getStartDate(), schedule.getEndDate())) {
                        BmaValidator.addMessage(errors, groupCode, BmaText.E00124, itemName);
                    } else if (!checkDaysInTerm(schedule.getStartDate(), schedule.getEndDate(), startDateOpen, endDateOpen)) {
                        strMessage1 = "�X�P�W���[����������";
                        BmaValidator.addMessage(errors, groupCode, BmaText.E00129, itemName, strMessage1);
                    } else if (!checkStartEndDate(schedule.getStartDate(), schedule.getEndDate(), schedule.getStartTime(), schedule.getEndTime())) {
                        BmaValidator.addMessage(errors, groupCode, BmaText.E00126, itemName);
                    }
                    if (errors.get(groupCode) == null) {
                        compareResult = compareTwoDays(schedule.getStartDate(), dateMapForSchedCheck.get("moshikomiFirstDate"));
                        if (!BmaUtility.isNullOrEmpty(compareResult) && "1".equals(compareResult)) {
                            strMessage1 = itemName + "�̊J�n��";
                            strMessage2 = "�e�\���̊J�n��";
                            BmaValidator.addMessage(errors, groupCode, BmaText.E00127, strMessage1, strMessage2);
                        }
                    }
                    if (errors.get(groupCode) == null) {
                        compareResult = compareTwoDays(schedule.getEndDate(), dateMapForSchedCheck.get("moshikomiLastDate"));
                        if (!BmaUtility.isNullOrEmpty(compareResult) && "1".equals(compareResult)) {
                            strMessage1 = itemName + "�̏I����";
                            strMessage2 = "�e�\���̏I����";
                            BmaValidator.addMessage(errors, groupCode, BmaText.E00127, strMessage1, strMessage2);
                        }
                    }
                } else if (BmaConstants.SCHED_CODE_JUKENHYO_SEND.equals(schedule.getScheduleCode())) {
                    // �󌟎�u�[������
                    groupCode = "schedGazoKaisho";
                    if (BmaConstants.SKN_KBN.equals(inSession.getSknksuKbn())) {
                        itemName = "�󌟕[������";
                    } else {
                        itemName = "��u�[������";
                    }
                    if (checkSysDateEqStandard(sysDate, schedule.getStartDate())) {
                        BmaValidator.addMessage(errors, groupCode, BmaText.E00125, itemName);
                    } else if (!checkOneDayInTerm(schedule.getStartDate(), startDateOpen, endDateOpen)) {
                        strMessage1 = "�X�P�W���[����������";
                        BmaValidator.addMessage(errors, groupCode, BmaText.E00129, itemName, strMessage1);
                    }
                    if (errors.get(groupCode) == null) {
                        compareResult = compareTwoDays(schedule.getStartDate(), dateMapForSchedCheck.get("HaraikomiGazoLastDate"));
                        if (!BmaUtility.isNullOrEmpty(compareResult) && !"-1".equals(compareResult)) {
                            strMessage1 = "�e�������ԂƉ摜�s���������Ԃ̏I����";
                            BmaValidator.addMessage(errors, groupCode, BmaText.E00128, itemName, strMessage1);
                        }
                    }
                } else if (BmaConstants.SCHED_CODE_SKN_GAKKA.equals(schedule.getScheduleCode())) {
                    // �w�Ȏ����E���Z�y�[�p�[�e�X�g
                    groupCode = "schedSknGakka";
                    itemName = "�w�Ȏ����E���Z�y�[�p�[�e�X�g";
                    if (checkSysDateEqStandard(sysDate, schedule.getStartDate())) {
                        BmaValidator.addMessage(errors, groupCode, BmaText.E00125, itemName);
                    } else if (!checkOneDayInTerm(schedule.getStartDate(), startDateOpen, endDateOpen)) {
                        strMessage1 = "�X�P�W���[����������";
                        BmaValidator.addMessage(errors, groupCode, BmaText.E00129, itemName, strMessage1);
                    }
                    if (errors.get(groupCode) == null) {
                        compareResult = compareTwoDays(schedule.getStartDate(), dateMapForSchedCheck.get("JknJkuSendDate"));
                        if (!BmaUtility.isNullOrEmpty(compareResult) && !"-1".equals(compareResult)) {
                            strMessage1 = "�󌟕[������";
                            BmaValidator.addMessage(errors, groupCode, BmaText.E00128, itemName, strMessage1);
                        }
                    }
                } else if (BmaConstants.SCHED_CODE_SKN_JITSUGI.equals(schedule.getScheduleCode())) {
                    // ���Z��Ǝ���
                    groupCode = "schedSknJitsugi";
                    itemName = "���Z��Ǝ���";
                    if (checkSysDateInTerm(sysDate, schedule.getStartDate(), schedule.getEndDate())) {
                        BmaValidator.addMessage(errors, groupCode, BmaText.E00124, itemName);
                    } else if (!checkDaysInTerm(schedule.getStartDate(), schedule.getEndDate(), startDateOpen, endDateOpen)) {
                        strMessage1 = "�X�P�W���[����������";
                        BmaValidator.addMessage(errors, groupCode, BmaText.E00129, itemName, strMessage1);
                    } else if (!checkStartEndDate(schedule.getStartDate(), schedule.getEndDate(), schedule.getStartTime(), schedule.getEndTime())) {
                        BmaValidator.addMessage(errors, groupCode, BmaText.E00126, itemName);
                    }
                    if (errors.get(groupCode) == null) {
                        compareResult = compareTwoDays(schedule.getStartDate(), dateMapForSchedCheck.get("JknJkuSendDate"));
                        if (!BmaUtility.isNullOrEmpty(compareResult) && !"-1".equals(compareResult)) {
                            strMessage1 = itemName + "�̊J�n��";
                            strMessage2 = "�󌟕[������";
                            BmaValidator.addMessage(errors, groupCode, BmaText.E00128, strMessage1, strMessage2);
                        }
                    }
                } else if (BmaConstants.SCHED_CODE_KSU_JITSUGI.equals(schedule.getScheduleCode())) {
                    // �u�K��i���Z���K�j
                    groupCode = "schedKsuJitsugi";
                    if (   "IP".equals(inSession.getSknKsuCode())
                        && "11".equals(inSession.getShubetsuCode())) {
                        itemName = "�u�K��i���Z���K�j";
                    } else {
                        itemName = "�u�K��";
                    }
                    if (checkSysDateInTerm(sysDate, schedule.getStartDate(), schedule.getEndDate())) {
                        BmaValidator.addMessage(errors, groupCode, BmaText.E00124, itemName);
                    } else if (!checkDaysInTerm(schedule.getStartDate(), schedule.getEndDate(), startDateOpen, endDateOpen)) {
                        strMessage1 = "�X�P�W���[����������";
                        BmaValidator.addMessage(errors, groupCode, BmaText.E00129, itemName, strMessage1);
                    } else if (!checkStartEndDate(schedule.getStartDate(), schedule.getEndDate(), schedule.getStartTime(), schedule.getEndTime())) {
                        BmaValidator.addMessage(errors, groupCode, BmaText.E00126, itemName);
                    }
                    if (errors.get(groupCode) == null) {
                        compareResult = compareTwoDays(schedule.getStartDate(), dateMapForSchedCheck.get("JknJkuSendDate"));
                        if (!BmaUtility.isNullOrEmpty(compareResult) && !"-1".equals(compareResult)) {
                            strMessage1 = itemName + "�̊J�n��";
                            strMessage2 = "��u�[������";
                            BmaValidator.addMessage(errors, groupCode, BmaText.E00128, strMessage1, strMessage2);
                        }
                    }
                } else if (BmaConstants.SCHED_CODE_KSU_SHURYO.equals(schedule.getScheduleCode())) {
                    // �u�K��i�C���ۑ�j
                    groupCode = "schedKsuShuryo";
                    itemName = "�u�K��i�C���ۑ�j";
                    if (checkSysDateInTerm(sysDate, schedule.getStartDate(), schedule.getEndDate())) {
                        BmaValidator.addMessage(errors, groupCode, BmaText.E00124, itemName);
                    } else if (!checkDaysInTerm(schedule.getStartDate(), schedule.getEndDate(), startDateOpen, endDateOpen)) {
                        strMessage1 = "�X�P�W���[����������";
                        BmaValidator.addMessage(errors, groupCode, BmaText.E00129, itemName, strMessage1);
                    } else if (!checkStartEndDate(schedule.getStartDate(), schedule.getEndDate(), schedule.getStartTime(), schedule.getEndTime())) {
                        BmaValidator.addMessage(errors, groupCode, BmaText.E00126, itemName);
                    }
                    if (errors.get(groupCode) == null) {
                        compareResult = compareTwoDays(schedule.getStartDate(), dateMapForSchedCheck.get("JknJkuSendDate"));
                        if (!BmaUtility.isNullOrEmpty(compareResult) && !"-1".equals(compareResult)) {
                            strMessage1 = itemName + "�̊J�n��";
                            strMessage2 = "��u�[������";
                            BmaValidator.addMessage(errors, groupCode, BmaText.E00128, strMessage1, strMessage2);
                        }
                    }
                    if (errors.get(groupCode) == null) {
                        compareResult = compareTwoDays(schedule.getEndDate(), dateMapForSchedCheck.get("KsuJitsugiEndDate"));
                        if (!BmaUtility.isNullOrEmpty(compareResult) && !"-1".equals(compareResult)) {
                            strMessage1 = itemName + "�̏I����";
                            strMessage2 = "�u�K��i���Z���K�j�̏I����";
                            BmaValidator.addMessage(errors, groupCode, BmaText.E00128, strMessage1, strMessage2);
                        }
                    }
                } else if (   BmaConstants.SCHED_CODE_GOUHATSU.equals(schedule.getScheduleCode())
                           && BmaConstants.SKN_KBN.equals(inSession.getSknksuKbn())) {
                    // ���i���\��
                    groupCode = "schedGokakuHappyo";
                    itemName = "���i���\��";
                    if (checkSysDateEqStandard(sysDate, schedule.getStartDate())) {
                        BmaValidator.addMessage(errors, groupCode, BmaText.E00125, itemName);
                    } else if (!checkOneDayInTerm(schedule.getStartDate(), startDateOpen, endDateOpen)) {
                        strMessage1 = "�X�P�W���[����������";
                        BmaValidator.addMessage(errors, groupCode, BmaText.E00129, itemName, strMessage1);
                    }
                    if (errors.get(groupCode) == null) {
                        compareResult = compareTwoDays(schedule.getStartDate(), dateMapForSchedCheck.get("ShikenEndDate"));
                        if (!BmaUtility.isNullOrEmpty(compareResult) && !"-1".equals(compareResult)) {
                            strMessage1 = "�w�Ȏ����E���Z�y�[�p�[�e�X�g���{���ȑO�A�܂��͎��Z��Ǝ������{���ԏI����";
                            BmaValidator.addMessage(errors, groupCode, BmaText.E00128, itemName, strMessage1);
                        }
                    }
                } else if (   BmaConstants.SCHED_CODE_GOUHATSU.equals(schedule.getScheduleCode())
                           && BmaConstants.KSU_KBN.equals(inSession.getSknksuKbn())) {
                    // �C���Ҕ��\��
                    groupCode = "schedShuryoshaHappyo";
                    itemName = "�C���Ҕ��\��";
                    if (checkSysDateEqStandard(sysDate, schedule.getStartDate())) {
                        BmaValidator.addMessage(errors, groupCode, BmaText.E00125, itemName);;
                    } else if (!checkOneDayInTerm(schedule.getStartDate(), startDateOpen, endDateOpen)) {
                        strMessage1 = "�X�P�W���[����������";
                        BmaValidator.addMessage(errors, groupCode, BmaText.E00129, itemName, strMessage1);
                    }
                    if (errors.get(groupCode) == null) {
                        compareResult = compareTwoDays(schedule.getStartDate(), dateMapForSchedCheck.get("KoshukaiEndDate"));
                        if (!BmaUtility.isNullOrEmpty(compareResult) && !"-1".equals(compareResult)) {
                            strMessage1 = "�e�u�K��̏I����";
                            BmaValidator.addMessage(errors, groupCode, BmaText.E00128, itemName, strMessage1);
                        }
                    }
                } else if (   BmaConstants.SCHED_CODE_GOKAKU_SEND.equals(schedule.getScheduleCode())
                           && BmaConstants.SKN_KBN.equals(inSession.getSknksuKbn())) {
                    // ���i�ʒm������
                    groupCode = "schedGokakuTsuchiSend";
                    itemName = "���i�ʒm������";
                    if (checkSysDateEqStandard(sysDate, schedule.getStartDate())) {
                        BmaValidator.addMessage(errors, groupCode, BmaText.E00125, itemName);
                    } else if (!checkOneDayInTerm(schedule.getStartDate(), startDateOpen, endDateOpen)) {
                        strMessage1 = "�X�P�W���[����������";
                        BmaValidator.addMessage(errors, groupCode, BmaText.E00129, itemName, strMessage1);
                    }
                    if (errors.get(groupCode) == null) {
                        compareResult = compareTwoDays(schedule.getStartDate(), dateMapForSchedCheck.get("GohatsuDate"));
                        if (!BmaUtility.isNullOrEmpty(compareResult) && "1".equals(compareResult)) {
                            strMessage1 = "���i���\��";
                            BmaValidator.addMessage(errors, groupCode, BmaText.E00127, itemName, strMessage1);
                        }
                    }
                } else if (   BmaConstants.SCHED_CODE_GOKAKU_SEND.equals(schedule.getScheduleCode())
                           && BmaConstants.KSU_KBN.equals(inSession.getSknksuKbn())) {
                    // �C���؏�������
                    groupCode = "schedShuryoShoshoSend";
                    itemName = "�C���؏�������";
                    if (checkSysDateEqStandard(sysDate, schedule.getStartDate())) {
                        BmaValidator.addMessage(errors, groupCode, BmaText.E00125, itemName);
                    } else if (!checkOneDayInTerm(schedule.getStartDate(), startDateOpen, endDateOpen)) {
                        strMessage1 = "�X�P�W���[����������";
                        BmaValidator.addMessage(errors, groupCode, BmaText.E00129, itemName, strMessage1);
                    }
                    if (errors.get(groupCode) == null) {
                        compareResult = compareTwoDays(schedule.getStartDate(), dateMapForSchedCheck.get("GohatsuDate"));
                        if (!BmaUtility.isNullOrEmpty(compareResult) && "1".equals(compareResult)) {
                            strMessage1 = "�C���Ҕ��\��";
                            BmaValidator.addMessage(errors, groupCode, BmaText.E00127, itemName, strMessage1);
                        }
                    }
                } else if (BmaConstants.SCHED_CODE_CANT_UPD1.equals(schedule.getScheduleCode())) {
                    // �C���s���ԂP
                    groupCode = "schedCantDataUpd1";
                    itemName = "�C���s���ԂP";
                    if (checkSysDateInTerm(sysDate, schedule.getStartDate(), schedule.getEndDate())) {
                        BmaValidator.addMessage(errors, groupCode, BmaText.E00124, itemName);
                    } else if (!checkDaysInTerm(schedule.getStartDate(), schedule.getEndDate(), startDateDataUpd, endDateDataUpd)) {
                        strMessage1 = "��u�҃f�[�^�ύX�\����";
                        BmaValidator.addMessage(errors, groupCode, BmaText.E00129, itemName, strMessage1);
                    } else if (!checkStartEndDate(schedule.getStartDate(), schedule.getEndDate(), schedule.getStartTime(), schedule.getEndTime())) {
                        BmaValidator.addMessage(errors, groupCode, BmaText.E00126, itemName);
                    }
                } else if (BmaConstants.SCHED_CODE_CANT_UPD2.equals(schedule.getScheduleCode())) {
                    // �C���s���ԂQ
                    groupCode = "schedCantDataUpd2";
                    itemName = "�C���s���ԂQ";
                    if (checkSysDateInTerm(sysDate, schedule.getStartDate(), schedule.getEndDate())) {
                        BmaValidator.addMessage(errors, groupCode, BmaText.E00124, itemName);
                    } else if (!checkDaysInTerm(schedule.getStartDate(), schedule.getEndDate(), startDateDataUpd, endDateDataUpd)) {
                        strMessage1 = "��u�҃f�[�^�ύX�\����";
                        BmaValidator.addMessage(errors, groupCode, BmaText.E00129, itemName, strMessage1);
                    } else if (!checkStartEndDate(schedule.getStartDate(), schedule.getEndDate(), schedule.getStartTime(), schedule.getEndTime())) {
                        BmaValidator.addMessage(errors, groupCode, BmaText.E00126, itemName);
                    }
                }
            }
        }
        inSession.setErrors(errors);
        return errors.isEmpty();
    }

    /**
     * ���͎����̐������`�F�b�N
     *
     * @param value ����
     * @return true:�G���[�� false:�s���ȕ�����
     */
    private boolean checkTime(String value) {
        if (BmaUtility.isNullOrEmpty(value)) {
            return false;
        } else {
            Pattern p = Pattern.compile("^([0-1][0-9]|[2][0-3])[0-5][0-9][0-9][0-9]$");
            Matcher m = p.matcher(value);
            if (!m.find()) {
                return false;
            } else {
                return true;
            }
        }
    }

    /**
     * �V�X�e�����t�����ԓ����ǂ����`�F�b�N�i����OK�j
     *
     * @param sysDate �V�X�e�����t
     * @param startDate �J�n��
     * @param endDate �I����
     * @return true:���ԓ��@false:���ԊO
     */
    private boolean checkSysDateInTerm(String sysDate, String startDate, String endDate) {
        /* �ϐ������� */
        SimpleDateFormat f = new SimpleDateFormat("yyyyMMdd");

        try {
            Date dateSystem = f.parse(sysDate);
            Date dateStart = f.parse(startDate);
            Date dateEnd = f.parse(endDate);
            if (   dateSystem.compareTo(dateStart) != -1
                && dateSystem.compareTo(dateEnd) != 1) {
                return true;
            } else {
                return false;
            }
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return false;
    }

    /**
     * �V�X�e�����t������ƈ�v���邩�ǂ����`�F�b�N
     *
     * @param sysDate �V�X�e�����t
     * @param standardDate ���
     * @return true:��v����@false:��v���Ȃ�
     */
    private boolean checkSysDateEqStandard(String sysDate, String standardDate) {
        /* �ϐ������� */
        SimpleDateFormat f = new SimpleDateFormat("yyyyMMdd");

        try {
            Date dateSystem = f.parse(sysDate);
            Date dateStandard = f.parse(standardDate);
            if (dateStandard.compareTo(dateSystem) == 0) {
                return true;
            } else {
                return false;
            }
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return false;
    }

    /**
     * �I�������J�n�����ォ�ǂ����`�F�b�N
     *
     * @param startDate �J�n��
     * @param endDate �I����
     * @param startTime �J�n����
     * @param endTime �I������
     * @return true:�J�n�����O�@false:�I�������O
     */
    private boolean checkStartEndDate(String startDate, String endDate, String startTime, String endTime) {
        /* �ϐ������� */
        SimpleDateFormat f = new SimpleDateFormat("yyyyMMddhhmmss");

        String checkStart = startDate + startTime;
        String checkEnd = endDate + endTime;

        try {
            Date dateStart = f.parse(checkStart);
            Date dateEnd = f.parse(checkEnd);
            if (dateStart.before(dateEnd)) {
                return true;
            } else {
                return false;
            }
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return false;
    }

    /**
     * �w��̊��ԓ����ǂ����`�F�b�N�i���ԁj �i����OK�j
     *
     * @param startDate �J�n��
     * @param endDate �I����
     * @param standardStartDate �w��̊��Ԃ̊J�n��
     * @param standardEndDate �w��̊��Ԃ̏I����
     * @return true:�������ԓ��@false:�������ԊO
     */
    private boolean checkDaysInTerm(String startDate, String endDate, String standardStartDate, String standardEndDate) {
        /* �ϐ������� */
        SimpleDateFormat f = new SimpleDateFormat("yyyyMMdd");

        try {
            Date dateStart = f.parse(startDate);
            Date dateEnd = f.parse(endDate);
            Date dateStandardStart = f.parse(standardStartDate);
            Date dateStandardEnd = f.parse(standardEndDate);
            if (   dateStart.compareTo(dateStandardStart) != -1
                && dateEnd.compareTo(dateStandardEnd) != 1) {
                return true;
            } else {
                return false;
            }
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return false;
    }

    /**
     * �w��̊��ԓ����ǂ����`�F�b�N�i����j�i����OK�j
     *
     * @param checkDate ���
     * @param standardStartDate �w��̊��Ԃ̊J�n��
     * @param standardEndDate �w��̊��Ԃ̏I����
     * @return true:�������ԓ��@false:�������ԊO
     */
    private boolean checkOneDayInTerm(String checkDate, String standardStartDate, String standardEndDate) {
        /* �ϐ������� */
        SimpleDateFormat f = new SimpleDateFormat("yyyyMMdd");

        try {
            Date dateCheckDate = f.parse(checkDate);
            Date dateStandardStart = f.parse(standardStartDate);
            Date dateStandardEnd = f.parse(standardEndDate);
            if (   dateCheckDate.compareTo(dateStandardStart) != -1
                && dateCheckDate.compareTo(dateStandardEnd) != 1) {
                return true;
            } else {
                return false;
            }
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return false;
    }

    /**
     * ���Ԃ�1�N�ȓ����ǂ����`�F�b�N
     *
     * @param startDate �J�n��
     * @param endDate �I����
     * @return true:1�N�ȓ��@false:1�N�ȏ�
     */
    private boolean checkNumOfDays(String startDate, String endDate) {
        /* �ϐ������� */
        SimpleDateFormat f = new SimpleDateFormat("yyyyMMdd");
        boolean checkYear = false;
        int baseDays;
        Date dateStart = null;
        Date dateEnd = null;

        /* ��̓������� */
        int year = Integer.valueOf(startDate.substring(0, 4));
        if (year % 4 == 0) {
            if (year % 100 == 0) {
                if (year % 400 == 0) {
                    checkYear = true;
                }
            } else {
                checkYear = true;
            }
        }
        if (checkYear) {
            baseDays = 366;
        } else {
            baseDays = 365;
        }

        /* �J�n�I���Ԃ̓����v�Z */
        try {
            dateStart = f.parse(startDate);
            dateEnd = f.parse(endDate);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        long dateStartTime = dateStart.getTime();
        long dateEndTime = dateEnd.getTime();
        long numOfDays = (dateEndTime - dateStartTime) / (1000 * 60 * 60 * 24);

        /* 1�N�ȓ����ǂ����`�F�b�N */
        if (baseDays < (int)numOfDays) {
            return false;
        } else {
            return true;
        }
    }

    /**
     * 2�̓��t���r����
     *
     * @param checkDate1 ��r���������t�P
     * @param checkDate2 ��r���������t�Q
     * @return 1:checkDate1����A -1:checkDate2����A 0:��v
     */
    private String compareTwoDays(String checkDate1, String checkDate2) {
        /* �ϐ������� */
        SimpleDateFormat f = new SimpleDateFormat("yyyyMMdd");

        try {
            Date dateCheckDate1 = f.parse(checkDate1);
            Date dateCheckDate2 = f.parse(checkDate2);

            return String.valueOf(dateCheckDate2.compareTo(dateCheckDate1));
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return null;
    }
}