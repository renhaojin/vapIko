package jp.co.nii.bma.business.service.manager;

import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URLEncoder;
import java.nio.file.FileSystemException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;
import jp.co.nii.bma.business.domain.Gazo;
import jp.co.nii.bma.business.domain.MMenjoMst;
import jp.co.nii.bma.business.domain.MShikakuMst;
import jp.co.nii.bma.business.domain.MeishoKanri;
import jp.co.nii.bma.business.domain.Moshikomi;
import jp.co.nii.bma.business.domain.MoshikomiHenkoRireki;
import jp.co.nii.bma.business.domain.Saiban;
import jp.co.nii.bma.business.domain.Schedule;
import jp.co.nii.bma.business.domain.Shokureki;
import jp.co.nii.bma.business.domain.SknksuMst;
import jp.co.nii.bma.business.rto.manager.GazoKanriJoho;
import jp.co.nii.bma.business.service.common.BmaConstants;
import jp.co.nii.bma.business.service.common.BmaLogger;
import jp.co.nii.bma.business.service.common.BmaSaibanService;
import jp.co.nii.bma.business.service.common.BmaValidator;
import jp.co.nii.bma.business.service.common.GazoCommonService;
import jp.co.nii.bma.business.service.common.MoshikomiCommonService;
import jp.co.nii.bma.presentation.common.BmaText;
import jp.co.nii.bma.utility.BmaDateTimeUtility;
import jp.co.nii.bma.utility.BmaUtility;
import jp.co.nii.sew.business.Validator;
import jp.co.nii.sew.business.service.AbstractService;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_SESSION;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_SUCCESS;
import jp.co.nii.sew.presentation.Messages;
import jp.co.nii.sew.presentation.Option;
import jp.co.nii.sew.presentation.RequestTransferObject;
import jp.co.nii.sew.utility.FileUtility;
import jp.co.nii.sew.utility.PropertyUtility;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.fileupload.FileItem;

/**
 * <p>
 * �^�C�g��: �������ʃT�[�r�X</p>
 * <p>
 * ����: �������ʃT�[�r�X</p>
 * <p>
 * ���쌠: Copyright (c) 2020</p>
 * <p>
 * ��Ж�: ���{���Y�Ɗ������</p>
 */
public class GazoKanriService extends AbstractService {

    /**
     * DB�ڑ��̃f�[�^�\�[�X
     */
    private static String DATA_SOURCE_NAME;
    /**
     * ���O
     */
    BmaLogger log = (BmaLogger) BmaLogger.getLogger(this.getClass().getName());
    /**
     * �Ɩ��R�[�h
     */
    private static final String BUSINESS_CODE = PropertyUtility.getProperty("business_code");
    /**
     * ���׃e�X�g���[�h
     */
    private static final String STRESS_MODE = PropertyUtility.getProperty(BUSINESS_CODE + "stress_mode");
    /**
     * �N�x
     */
    private static final String NEN = PropertyUtility.getProperty(BUSINESS_CODE + "nen");
    // ���s ���̓��[���̃e���v���[�g�ꍇ
    String newLine = "\r\n";
    // ���s ���̓��[���̃e���v���[�g�ꍇ
    String newLineKakunin = "\\n";

    /**
     * �R���X�g���N�^
     */
    public GazoKanriService() {
        super();
        /* DB�ڑ����̃��[�U�[������ */
        DATA_SOURCE_NAME = BmaConstants.DS_REGISTRANT;
    }

    /**
     * �T�[�r�X�N���X�̎��s���\�b�h
     *
     * @param rto ���N�G�X�g��񂩂�擾����rto
     * @param rtoinSession �Z�b�V�������rto
     * @return foward��
     * @throws Exception ��O
     */
    @Override
    public String doService(RequestTransferObject rto, RequestTransferObject rtoinSession)
            throws Exception {

        GazoKanriJoho inRequest = (GazoKanriJoho) rto;
        GazoKanriJoho inSession = (GazoKanriJoho) rtoinSession;
        String processName = "";

        /*�G���[���b�Z�[�W������*/
        inSession.setErrors(new Messages());
        inSession.setMoshikomishaId(inRequest.getMoshikomishaId());
        try {
            if (!BmaUtility.isNullOrEmpty(inRequest.getGazoKanri())
                    || !BmaUtility.isNullOrEmpty(inRequest.getGazoUlBack())) {
                inSession.clearInfo();
                /*���j���[�o�^���{�^��������*/
                processName = "GazoSearchInput";
                log.Start(processName);
                /*���������X�g�擾*/
                inSession.setSknKbnList(findSknKsuList(BmaConstants.SKN_KBN));
                inSession.setKsuKbnList(findSknKsuList(BmaConstants.KSU_KBN));
                inSession.setGazoKbnList(findMeishoList(BmaConstants.MEISHO_KANRI_GROUP_GAZO_KBN));
                inSession.setHoseiIraiKbnList(findMeishoList(BmaConstants.MEISHO_KANRI_GROUP_HOSEI_IRAI_KBN));
                inSession.setMoshikomiKbnList(findMeishoList(BmaConstants.MEISHO_KANRI_GROUP_MOSHIKOMI_KBN));
                inSession.setKojinDantaiKbnList(findMeishoList(BmaConstants.MEISHO_KANRI_GROUP_KOJIN_DANTAI_KBN));
                return FWD_NM_SUCCESS;
            } else if (!BmaUtility.isNullOrEmpty(inRequest.getInpClear())) {
                /*��ʃ��Z�b�g*/
                inSession.clearInfo();
                inSession.setScrollPlace(inRequest.getScrollPlace());
                return FWD_NM_RELOAD;
            } else if (!BmaUtility.isNullOrEmpty(inRequest.getGazoSearch())
                    || !BmaUtility.isNullOrEmpty(inSession.getGazoSearch())) {
                processName = "GazoSearchList";
                String let = "";
                log.Start(processName);
                
                // �ڍ׉摜��ʂ���߂�̏ꍇ
                if (!BmaUtility.isNullOrEmpty(inSession.getGazoSearch())) {
                    /*�������X�g�擾*/
                    searchJoho(inSession);
                    /*�\�����X�g�擾*/
                    if (inSession.getPage() == 0) {
                        setPage(inSession);
                        pageIndex(inSession);
                    }
                    inSession.setGazoSearch("");
                    return FWD_NW_SEARCH;
                }
                // �Z�b�V�����N���A
                inSession.clearInfo();

                /*���̓f�[�^�Z�b�g*/
                setValueRequestToSession(inRequest, inSession);

                /*���̓`�F�b�N*/
                boolean retCheck = ValidatorCaller(inRequest, inSession);
                boolean checkUpload = checkUpload(inSession);
                if (checkUpload) {
                    if (retCheck) {
                        let = FWD_NM_UPLOAD;
                    } else {
                        let = FWD_NM_RELOAD;
                    }
                } else {
                    if (retCheck) {
//                        /*���̓f�[�^�Z�b�g*/
//                        setValueRequestToSession(inRequest, inSession);
                        // �l�E�X����I�����́y���ʐ\���z�摜�A�b�v���[�h��ʂ�
                        if (checkToSmn(inSession)) {
                            let = "smnGazo";
                        } else {
                            /*�^�C�g�����擾*/
                            SknksuMst sknksuMst = new SknksuMst(BmaConstants.DS_REGISTRANT);
                            String sknKsuNameChi = sknksuMst.findSknKsuNameRyaku(inSession.getSknKsuCode(),
                                    inSession.getShubetsuCode(), inSession.getKaisuCode()).getSknKsuNameRyaku();
                            MeishoKanri meishoKanri = new MeishoKanri(BmaConstants.DS_REGISTRANT);
                            String gazoChi = meishoKanri.findHanYoChi(BmaConstants.MEISHO_KANRI_GROUP_GAZO_KBN, inSession.getGazoShuruiChoice()).getHanyoChi();
                            inSession.setGazoSearchKekka("����/�u�K��F" + sknKsuNameChi + "�@�ʐ^��ށF" + gazoChi);

                            /*�������X�g�擾*/
                            if (!searchJoho(inSession)) {
                                /*1�����q�b�g���Ȃ������ꍇ�͌���������ʍĕ\��*/
                                let = FWD_NM_RELOAD;
                            } else {
                                /*�\�����X�g�擾*/
                                if (inSession.getPage() == 0) {
                                    setPage(inSession);
                                    pageIndex(inSession);
                                }
                                let = FWD_NW_SEARCH;
                            }
                        }
                    } else {
                        let = FWD_NM_RELOAD;
                    }
                }

                return let;
            } else if (!BmaUtility.isNullOrEmpty(inRequest.getCommandPage())) {
                /*�y�[�W�J��*/
                processName = "setPage";
                log.Start(processName);
                inSession.setPage(Integer.parseInt(inRequest.getCommandPage()));
                setPage(inSession);
                pageIndex(inSession);
                return FWD_NW_SEARCH;
            } else if (!BmaUtility.isNullOrEmpty(inRequest.getKaojashinSearchKekkaUpd())) {
                /*�X�V*/
                processName = "update";
                log.Start(processName);
                List<GazoKanriJoho> list = inSession.getGazoDetailList();
                Messages errors = new Messages();
                try {
                    Boolean updateCheck = false;
                    Date date = new Date();
                    SimpleDateFormat dt = new SimpleDateFormat("yyyyMMdd");
                    SimpleDateFormat tm = new SimpleDateFormat("HHmmss");

                    /* �g�����U�N�V�����擾&�J�n */
                    getTransaction();
                    beginTransaction();
                    for (int i = 0; i < list.size(); i++) {
                        // �X�V�O�̕␳�˗��敪���u���m�F�v�̃f�[�^�̂ݍX�V����
                        if (BmaConstants.MEISHO_KANRI_GROUP_CODE_HOSEI_IRAI_KBN_MIKAKUNIN.equals(list.get(i).getGazoStatus())) {
                            updateCheck = true;
                            Gazo gazoKoshinData = new Gazo();
                            boolean check = (inRequest.getChkOkng() != null)
                                    ? Arrays.asList(inRequest.getChkOkng()).contains(String.valueOf(i)) : false;
                            String chkOkng = (check) ? BmaConstants.MEISHO_KANRI_GROUP_CODE_KAHI_FLG_NG
                                    : BmaConstants.MEISHO_KANRI_GROUP_CODE_KAHI_FLG_OK;
                            String gazoHyojiKbn = (chkOkng.equals(BmaConstants.MEISHO_KANRI_GROUP_CODE_KAHI_FLG_NG))
                                    ? BmaConstants.MEISHO_KANRI_GROUP_CODE_GAZO_HYOJI_KBN_SHINSHA : BmaConstants.MEISHO_KANRI_GROUP_CODE_GAZO_HYOJI_KBN_KANRYOU;
                            String hoseiIraiKbn = (gazoHyojiKbn.equals(BmaConstants.MEISHO_KANRI_GROUP_CODE_KAHI_FLG_NG))
                                    ? BmaConstants.MEISHO_KANRI_GROUP_CODE_HOSEI_IRAI_KBN_FUBI_MITOROKU : BmaConstants.MEISHO_KANRI_GROUP_CODE_HOSEI_IRAI_KBN_KANRYOU;
                            MeishoKanri meishoKanri = new MeishoKanri(BmaConstants.DS_REGISTRANT);
                            String newGazoStatusCode = meishoKanri.findHanYoChi("HOSEI_IRAI_KBN", hoseiIraiKbn).getHanyoCode();
                            String newGazoStatusChi = meishoKanri.findHanYoChi("HOSEI_IRAI_KBN", hoseiIraiKbn).getHanyoChi();
                            gazoKoshinData.setHoseiIraiCode1(list.get(i).getFubiRiyu1());
                            gazoKoshinData.setHoseiIraiCode2(list.get(i).getFubiRiyu2());
                            gazoKoshinData.setHoseiIraiCode3(list.get(i).getFubiRiyu3());
                            gazoKoshinData.setHoseiIraiKbn(hoseiIraiKbn);
                            gazoKoshinData.setGazoHyojiKbn(gazoHyojiKbn);
                            if (BmaConstants.MEISHO_KANRI_GROUP_CODE_HOSEI_IRAI_KBN_KANRYOU.equals(hoseiIraiKbn)) {
                                gazoKoshinData.setHoseiFinishBi(dt.format(date));
                                gazoKoshinData.setHoseiFinishTime(tm.format(date));
                            }
                            //�摜�����X�V����
                            Gazo gazo = new Gazo(DATA_SOURCE_NAME);
                            /* ������ʂ���摜���ɒl���R�s�[ */
                            BeanUtils.copyProperties(gazo, gazo.find(list.get(i).getNendo(), list.get(i).getUketukeNo(),
                                    list.get(i).getGazoKbn(), list.get(i).getSeq()));
                            /* �X�V���Z�b�g */
                            setGazoUpd(gazo, inSession, gazoKoshinData);
                            /*�A�b�v�f�[�g���s*/
                            gazo.update();
                            list.get(i).setGazoStatus(newGazoStatusCode);
                            list.get(i).setGazoStatusChi(newGazoStatusChi);

                            // ���ʏ����F�摜�\���敪�X�V�ďo
                            GazoCommonService gazoCommonService = new GazoCommonService(DATA_SOURCE_NAME);
                            gazoCommonService.updateGazoHyojiKbn(list.get(i).getNendo(), list.get(i).getUketukeNo(),
                                    list.get(i).getGazoKbn(), list.get(i).getSeq(), list.get(i).getMoshikomishaId());
                        }
                    }
                    /* �R�~�b�g */
                    commitTransaction();
                    log.warn("�Y�������X�V���܂���");
                    if (updateCheck) {
                        BmaValidator.addMessage(errors, BmaConstants.ERR_GROUP_SEARCH_KEKKA_UPD,
                                "�Y������o�^���܂����B", BmaConstants.ARG_SEARCH_KEKKA_UPD);
                    } else {
                        BmaValidator.addMessage(errors, BmaConstants.ERR_GROUP_SEARCH_KEKKA_UPD,
                                "�X�V�\�Ȗ��m�F�摜������܂���ł����B�ڍ׉�ʂŊm�F���Ă��������B", BmaConstants.ARG_SEARCH_KEKKA_UPD);
                    }
                    inSession.setErrors(errors);
                } catch (Exception ex) {
                    ex.printStackTrace();
                    // ���[���o�b�N
                    rollbackTransaction();
                    log.warn("���擾�G���[�ׁ̈A�G���[�R���e���c��ԋp���܂�");
                    BmaValidator.addMessage(errors, BmaConstants.ERR_GROUP_SEARCH_KEKKA_UPD, BmaText.E00044, BmaConstants.ARG_SEARCH_KEKKA_UPD);
                    inSession.setErrors(errors);
                }
                inSession.setGazoDetailList(list);
                return FWD_NM_UPDATE;
            } else if (!BmaUtility.isNullOrEmpty(inRequest.getKaojashinShosaiToroku())) {
                /*�摜�ڍדo�^*/
                processName = "toroku";
                log.Start(processName);
                /*���̓`�F�b�N*/
                boolean retCheck = ValidatorCallerShosai(inRequest, inSession);
                Messages errors = new Messages();
                if (retCheck) {
                    try {
                        /* �g�����U�N�V�����擾&�J�n */
                        getTransaction();
                        beginTransaction();
                        //�摜�����X�V����
                        Gazo gazo = new Gazo(DATA_SOURCE_NAME);
                        List<GazoKanriJoho> list = new ArrayList<>();
                        list = inSession.getGazoShosaiList();
                        /* ������ʂ���摜���ɒl���R�s�[ */
                        BeanUtils.copyProperties(gazo, gazo.find(list.get(0).getNendo(), list.get(0).getUketukeNo(),
                                list.get(0).getGazoKbn(), list.get(0).getSeq()));
                        /* �R�[�h�]�� */
                        String gazoHyojiKbn = (inRequest.getShinsaKekka().equals(BmaConstants.MEISHO_KANRI_GROUP_CODE_KAHI_FLG_NG))
                                ? BmaConstants.MEISHO_KANRI_GROUP_CODE_GAZO_HYOJI_KBN_SHINSHA : BmaConstants.MEISHO_KANRI_GROUP_CODE_GAZO_HYOJI_KBN_KANRYOU;
                        String hoseiIraiKbn = (inRequest.getShinsaKekka().equals(BmaConstants.MEISHO_KANRI_GROUP_CODE_KAHI_FLG_NG))
                                ? BmaConstants.MEISHO_KANRI_GROUP_CODE_HOSEI_IRAI_KBN_SAIIRAI : BmaConstants.MEISHO_KANRI_GROUP_CODE_HOSEI_IRAI_KBN_KANRYOU;
                        String[] hoseiIraiCode = inRequest.getChkFubiRiyu();
                        // �摜�s�����R�Ɂu�\�����e�ɕs������v�I�����A�␳�˗��敪��ύX
                        if (BmaConstants.MEISHO_KANRI_GROUP_CODE_KAHI_FLG_NG.equals(inRequest.getShinsaKekka())) {
                            for (int i=0; i < hoseiIraiCode.length; ++i) {
                                if ("901".equals(hoseiIraiCode[i])) {
                                    hoseiIraiKbn = BmaConstants.MEISHO_KANRI_GROUP_CODE_HOSEI_IRAI_KBN_MSK_FUBI;
                                    break;
                                }
                            }
                        }
                        inSession.setHoseiIraiKbn(hoseiIraiKbn);
                        inSession.setGazoHyojiKbn(gazoHyojiKbn);
                        if (inRequest.getShinsaKekka().equals(BmaConstants.MEISHO_KANRI_GROUP_CODE_KAHI_FLG_NG)) {
                            if (hoseiIraiCode == null) {
                                BmaValidator.addMessage(errors, BmaConstants.ERR_GROUP_FUBIRIYU,
                                        "�s�����R��I�����Ă��������B", BmaConstants.ARG_FUBIRIYU);
                                inSession.setFubiRiyuList(new ArrayList<>());
                                inSession.setErrors(errors);
                                return FWD_NM_RELOAD;
                            } else if (hoseiIraiCode[0].equals("009") && BmaUtility.isNullOrEmpty(inRequest.getBiko())) {
                                BmaValidator.addMessage(errors, BmaConstants.ERR_GROUP_FUBIRIYU,
                                        "���̑���I������ꍇ�A���l�ɕs�����R����͂��Ă��������B", BmaConstants.ARG_FUBIRIYU);
                                List<String> fubiriyu = new ArrayList<>();
                                fubiriyu.add(0, "009");
                                inSession.setFubiRiyuList(fubiriyu);
                                inSession.setErrors(errors);
                                return FWD_NM_RELOAD;
                            } else if (hoseiIraiCode.length == 1) {
                                inSession.setFubiRiyu1(hoseiIraiCode[0]);
                                inSession.setFubiRiyu2("");
                                inSession.setFubiRiyu3("");
                            } else if (hoseiIraiCode.length == 2) {
                                inSession.setFubiRiyu1(hoseiIraiCode[0]);
                                inSession.setFubiRiyu2(hoseiIraiCode[1]);
                                inSession.setFubiRiyu3("");
                            } else if (hoseiIraiCode.length == 3) {
                                inSession.setFubiRiyu1(hoseiIraiCode[0]);
                                inSession.setFubiRiyu2(hoseiIraiCode[1]);
                                inSession.setFubiRiyu3(hoseiIraiCode[2]);
                            } else {
                                inSession.setFubiRiyuList(Arrays.asList(inRequest.getChkFubiRiyu()));
                                BmaValidator.addMessage(errors, BmaConstants.ERR_GROUP_FUBIRIYU,
                                        BmaText.E00071, BmaConstants.ARG_FUBIRIYU);
                                inSession.setErrors(errors);
                                return FWD_NM_RELOAD;
                            }
                        }
                        /* �X�V���Z�b�g */
                        setGazoTrk(gazo, inSession);
                        /*�A�b�v�f�[�g���s*/
                        gazo.update();
                        // ���ʏ����F�摜�\���敪�X�V�ďo
                        GazoCommonService gazoCommonService = new GazoCommonService(DATA_SOURCE_NAME);
                        gazoCommonService.updateGazoHyojiKbn(list.get(0).getNendo(), list.get(0).getUketukeNo(),
                                list.get(0).getGazoKbn(), list.get(0).getSeq(), inSession.getMoshikomishaId());
                        inSession.setShinsaKekka(inRequest.getShinsaKekka());
                        if (inRequest.getChkFubiRiyu() != null) {
                            inSession.setFubiRiyuList(Arrays.asList(inRequest.getChkFubiRiyu()));
                        }
                        inSession.setBiko(inRequest.getBiko());
                        // �\��������������
                        Moshikomi moshikomi = new Moshikomi(DATA_SOURCE_NAME);
                        Moshikomi moshikomiBfr = moshikomi.find(list.get(0).getNendo(), list.get(0).getUketukeNo());
                        // �\���ύX��������o�^����
                        MoshikomiHenkoRireki moshikomiHenkoRireki = new MoshikomiHenkoRireki(DATA_SOURCE_NAME);
                        /* �\����񂩂�\���ύX�������ɒl���R�s�[ */
                        BeanUtils.copyProperties(moshikomiHenkoRireki, moshikomiBfr);
                        /* �o�^���Z�b�g */
                        setMoshikomihenkoTrk(moshikomiHenkoRireki, inSession);
                        /*�C���T�[�g���s*/
                        moshikomiHenkoRireki.create();
                        /* �\����񂩂�\�����ɒl���R�s�[ */
                        BeanUtils.copyProperties(moshikomi, moshikomiBfr);
                        /* �X�V���Z�b�g */
                        setMoshikomiUpd(moshikomi, inSession);
                        /*�A�b�v�f�[�g���s*/
                        moshikomi.update();
                        /* �R�~�b�g */
                        commitTransaction();
                        log.warn("�Y������o�^���܂���");
                        inSession.setTorokuCheck("1");
                        BmaValidator.addMessage(errors, BmaConstants.ERR_GROUP_SEARCH_KEKKA_UPD,
                                "�Y������o�^���܂����B", BmaConstants.ARG_SEARCH_KEKKA_UPD);
                        inSession.setErrors(errors);
                        inSession.setKaojashinShosaiToroku("1");
                    } catch (Exception ex) {
                        ex.printStackTrace();
                        // ���[���o�b�N
                        rollbackTransaction();
                        log.warn("���擾�G���[�ׁ̈A�G���[�R���e���c��ԋp���܂�");
                        BmaValidator.addMessage(errors, BmaConstants.ERR_GROUP_SEARCH_KEKKA_UPD, BmaText.E00044, BmaConstants.ARG_SEARCH_KEKKA_UPD);
                        inSession.setErrors(errors);
                    }
                }
                return FWD_NM_UPDATE;
            } else if (!BmaUtility.isNullOrEmpty(inRequest.getKaojashinShosaiGazoDl())) {
                /* �_�E�����[�h */
                processName = "download";
                log.Start(processName);
                gazoDownload(inRequest, inSession);
                return DOWNLOAD;
            } else if (!BmaUtility.isNullOrEmpty(inRequest.getShomeiSearchKekkaBack())
                    || !BmaUtility.isNullOrEmpty(inRequest.getKaojashinSearchKekkaBack())) {
                /* �߂� */
                processName = "back";
                log.Start(processName);
                String result = null;
                if (!BmaUtility.isNullOrEmpty(inRequest.getShomeiSearchKekkaBack())) {
                    result = "cancell".equals(inRequest.getKaojashinShosaiBack()) ? FWD_NM_RELOAD : FWD_NM_BACK;
                } else {
                    result = "cancell".equals(inRequest.getKaojashinSearchKekkaBack()) ? FWD_NM_RELOAD : FWD_NM_BACK;
                }
                if (result.equals(FWD_NM_BACK)) {
                    inSession.clearInfo();
                    inSession.setPage(0);
                } else {
                    inSession.setOkngList(Arrays.asList(inRequest.getChkOkng()));
                }
                return result;
            } else if (!BmaUtility.isNullOrEmpty(inRequest.getGazoShosai())
                    && BmaUtility.isNullOrEmpty(inSession.getGazoChoiceGazoUpd())
                    && BmaUtility.isNullOrEmpty(inRequest.getKaojashinShosaiBack())) {
                /* �ڍ� */
                processName = "shosai";
                log.Start(processName);
                /* �ڍ׃��X�g�擾 */
                searchShosaiJoho(inRequest, inSession);
                inSession.setGazoShosai(inRequest.getGazoShosai());
                return "shosai";
            } else if (!BmaUtility.isNullOrEmpty(inRequest.getGazoShosai())
                    && !BmaUtility.isNullOrEmpty(inSession.getGazoChoiceGazoUpd())
                    && BmaUtility.isNullOrEmpty(inRequest.getKaojashinShosaiBack())) {
                /* �ڍ� */
                processName = "shosaireload";
                log.Start(processName);
                /* �ڍ׃��X�g�擾 */
                searchShosaiJoho(inRequest, inSession);
                return "shosai";
            } else if (!BmaUtility.isNullOrEmpty(inRequest.getGazoChoiceGazoUpd())
                    && BmaUtility.isNullOrEmpty(inSession.getKaojashinShosaiGazoUpd())) {
                /*�u�m�F�v�{�^��������*/
                processName = "MgrGazoUpload";
                log.Start(processName);
                if (BmaUtility.isNullOrEmpty(inSession.getGazo_idx())) {
                    /**
                     * �摜�h�c�w (�̔�)
                     */
                    Saiban saiban = new BmaSaibanService(DATA_SOURCE_NAME).getSaibanAndUpdate(BmaConstants.SAIBAN_GAZOIDX, inSession.getMoshikomishaId());
                    inSession.setGazo_idx(saiban.getGenzaiNo());
                }
                inSession.setGazoChoice(inRequest.getGazoChoice());
                inSession.setGazoChoiceGazoUpd(inRequest.getGazoChoiceGazoUpd());
                /* �t�@�C�����擾 */
                String fileName = inRequest.getFileItem().getName();
                File file = new File(fileName);
                // PATH���t���Ă���̃t�@�C���̂ݔ��f����
                int index = fileName.indexOf("\\");
                // IE��������
                if (index > 0 && !file.exists()) {
                    /* �e�h�k�d���݂��Ă��܂���̎��G���[*/
                    Messages errors = new Messages();
                    BmaValidator.addMessage(errors, "fileItem", BmaText.E00045, "�t�@�C��");
                    inSession.setErrors(errors);
                    return FWD_NM_RELOAD;
                }
                /* �ʐ^���ۑ� */
                if (!uploadGazo(inRequest, inSession)) {
                    log.End(processName);
                    inSession.setUploadCheck("");
                } else {
                    inSession.setUploadCheck("1");
                    Messages errors = new Messages();
                    try {
                        /* �g�����U�N�V�����擾&�J�n */
                        getTransaction();
                        beginTransaction();
                        // �\��������������
                        Moshikomi moshikomi = new Moshikomi(DATA_SOURCE_NAME);
                        Moshikomi moshikomiBfr = moshikomi.find(inSession.getNendo(), inSession.getUketukeNo());
                        // �\���ύX��������o�^����
                        MoshikomiHenkoRireki moshikomiHenkoRireki = new MoshikomiHenkoRireki(DATA_SOURCE_NAME);
                        /* �\����񂩂�\���ύX�������ɒl���R�s�[ */
                        BeanUtils.copyProperties(moshikomiHenkoRireki, moshikomiBfr);
                        /* �o�^���Z�b�g */
                        setMoshikomihenkoTrk(moshikomiHenkoRireki, inSession);
                        /*�C���T�[�g���s*/
                        moshikomiHenkoRireki.create();
                        // �\�������X�V����
                        BeanUtils.copyProperties(moshikomi, moshikomiBfr);
                        /* �X�V���Z�b�g */
                        moshikomiUpdForGazoUpload(moshikomi, inSession);
                        /*�A�b�v�f�[�g���s*/
                        moshikomi.update();
                        //�摜�����X�V����
                        Gazo gazo = new Gazo(DATA_SOURCE_NAME);
                        /* �\����񂩂�摜���ɒl���R�s�[ */
                        BeanUtils.copyProperties(gazo, gazo.find(inSession.getNendo(), inSession.getUketukeNo(), inSession.getGazoKbn(), inSession.getSeq()));
                        /* �X�V���Z�b�g */
                        gazoUpdForGazoUpload(gazo, inSession);
                        /*�A�b�v�f�[�g���s*/
                        gazo.update();
                        // ���ʏ����F�\���󋵋敪�X�V 
                        MoshikomiCommonService commonService = new MoshikomiCommonService(DATA_SOURCE_NAME);
                        commonService.updateMoshikomiKbn(inSession.getNendo(), inSession.getUketukeNo(), inSession.getMoshikomishaId());
                        // ���ʏ����F�摜�\���敪�X�V
                        GazoCommonService gazoCommonService = new GazoCommonService(DATA_SOURCE_NAME);
                        gazoCommonService.updateGazoHyojiKbn(gazo.getNendo(), gazo.getUketsukeNo(), gazo.getGazoKbn(), gazo.getSeq(), inSession.getMoshikomishaId());

                        /* �R�~�b�g */
                        commitTransaction();
                        inSession.setGazoUpd("");
                    } catch (Exception ex) {
                        // ���[���o�b�N
                        rollbackTransaction();
                        BmaValidator.addMessage(errors, "fileItem", "�摜�̉��o�^�Ɏ��s���܂����B", "fileItem");
                        inSession.setErrors(errors);
                        return FWD_NM_RELOAD;
                    }
                    BmaValidator.addMessage(errors, "fileItem", "�摜�̉��o�^���������܂����B", "fileItem");
                    inSession.setErrors(errors);
                    inSession.setGazoUpd("true");
                }
                return FWD_NM_UPLOAD;
            } else if (!BmaUtility.isNullOrEmpty(inRequest.getGazoChoiceGazoUpd())
                    && !BmaUtility.isNullOrEmpty(inSession.getKaojashinShosaiGazoUpd())) {
                /*�u�m�F�v�{�^��������*/
                processName = "MgrGazoUpload";
                log.Start(processName);
                if (BmaUtility.isNullOrEmpty(inSession.getGazo_idx())) {
                    /**
                     * �摜�h�c�w (�̔�)
                     */
                    Saiban saiban = new BmaSaibanService(DATA_SOURCE_NAME).getSaibanAndUpdate(BmaConstants.SAIBAN_GAZOIDX, inSession.getMoshikomishaId());
                    inSession.setGazo_idx(saiban.getGenzaiNo());
                }
                inSession.setKaojashinShosaiGazoUpd("1");
                inSession.setGazoChoice(inRequest.getGazoChoice());
                inSession.setGazoChoiceGazoUpd(inRequest.getGazoChoiceGazoUpd());
                /* �t�@�C�����擾 */
                String fileName = inRequest.getFileItem().getName();
                File file = new File(fileName);
                // PATH���t���Ă���̃t�@�C���̂ݔ��f����
                int index = fileName.indexOf("\\");
                // IE��������
                if (index > 0 && !file.exists()) {
                    /* �e�h�k�d���݂��Ă��܂���̎��G���[*/
                    Messages errors = new Messages();
                    BmaValidator.addMessage(errors, "fileItem", BmaText.E00045, "�t�@�C��");
                    inSession.setErrors(errors);
                    return FWD_NM_RELOAD;
                }
                /* �ʐ^���ۑ� */
                if (!uploadGazo(inRequest, inSession)) {
                    log.End(processName);
                    inSession.setUploadCheck("");
                } else {
                    inSession.setUploadCheck("1");
                    Messages errors = new Messages();
                    try {
                        /* �g�����U�N�V�����擾&�J�n */
                        getTransaction();
                        beginTransaction();
                        // �\��������������
                        Moshikomi moshikomi = new Moshikomi(DATA_SOURCE_NAME);
                        Moshikomi moshikomiBfr = moshikomi.find(inSession.getNendo(), inSession.getUketukeNo());
                        // �\���ύX��������o�^����
                        MoshikomiHenkoRireki moshikomiHenkoRireki = new MoshikomiHenkoRireki(DATA_SOURCE_NAME);
                        /* �\����񂩂�\���ύX�������ɒl���R�s�[ */
                        BeanUtils.copyProperties(moshikomiHenkoRireki, moshikomiBfr);
                        /* �o�^���Z�b�g */
                        setMoshikomihenkoTrk(moshikomiHenkoRireki, inSession);
                        /*�C���T�[�g���s*/
                        moshikomiHenkoRireki.create();
                        // �\�������X�V����
                        BeanUtils.copyProperties(moshikomi, moshikomiBfr);
                        /* �X�V���Z�b�g */
                        moshikomiUpdForGazoUpload(moshikomi, inSession);
                        /*�A�b�v�f�[�g���s*/
                        moshikomi.update();
                        //�摜�����X�V����
                        Gazo gazo = new Gazo(DATA_SOURCE_NAME);
                        /* �\����񂩂�摜���ɒl���R�s�[ */
                        BeanUtils.copyProperties(gazo, gazo.find(inSession.getNendo(), inSession.getUketukeNo(), inSession.getGazoKbn(), inSession.getSeq()));
                        /* �X�V���Z�b�g */
                        gazoUpdForGazoUpload(gazo, inSession);
                        /*�A�b�v�f�[�g���s*/
                        gazo.update();
                        // ���ʏ����F�\���󋵋敪�X�V 
                        MoshikomiCommonService commonService = new MoshikomiCommonService(DATA_SOURCE_NAME);
                        commonService.updateMoshikomiKbn(inSession.getNendo(), inSession.getUketukeNo(), inSession.getMoshikomishaId());
                        // ���ʏ����F�摜�\���敪�X�V
                        GazoCommonService gazoCommonService = new GazoCommonService(DATA_SOURCE_NAME);
                        gazoCommonService.updateGazoHyojiKbn(gazo.getNendo(), gazo.getUketsukeNo(), gazo.getGazoKbn(), gazo.getSeq(), inSession.getMoshikomishaId());

                        /* �R�~�b�g */
                        commitTransaction();
                        inSession.setGazoUpd("");
                    } catch (Exception ex) {
                        // ���[���o�b�N
                        rollbackTransaction();
                        BmaValidator.addMessage(errors, "fileItem", "�摜�̉��o�^�Ɏ��s���܂����B", "fileItem");
                        inSession.setErrors(errors);
                        return FWD_NM_RELOAD;
                    }
                    BmaValidator.addMessage(errors, "fileItem", "�摜�̉��o�^���������܂����B", "fileItem");
                    inSession.setErrors(errors);
                    inSession.setGazoUpd("true");
                }
                return FWD_NM_UPLOAD;
            } else if (!BmaUtility.isNullOrEmpty(inRequest.getGazoChoiceGazoDl())) {
                /* �摜�؂���c�[��*/
                processName = "MgrPhotoCutWeb";
                log.Start(processName);
                return "cut";
            } else if (!BmaUtility.isNullOrEmpty(inRequest.getKaojashinShosaiBack())) {
                /* �ڍ� */
                processName = "back";
                log.Start(processName);
                String result;
                if (inRequest.getTorokuCheck().equals("1")) {
                    result = FWD_NM_BACK;
                    inSession.setTorokuCheck("");
                    inSession.setPage(0);
                    /*�\�����X�g�擾*/
                    if (inSession.getPage() == 0) {
                        pageIndex(inSession);
                    }
                } else {
                    result = inRequest.getKaojashinShosaiBack().equals("ok") ? FWD_NM_BACK : FWD_NM_RELOAD;
//                    if (inRequest.getKaojashinShosaiBack().equals("ok") && inSession.getUploadCheck().equals("1")) {
//                        String orgPath = BmaConstants.PHOTO_UPLOAD_PATH_KAKUTEI;
//                        String strNam = inSession.getGazo_idx() + ".jpeg";
//                        Files.delete((Paths.get(orgPath + strNam)));
//                        inSession.setUploadCheck("");
//                    }
                }
                // �ꗗ�������{
                inSession.setGazoSearch(FWD_NM_BACK.equals(result) ? "1" : "");
                return result;
            } else if (!BmaUtility.isNullOrEmpty(inRequest.getGazoUl())) {
                /*�u��ʐ^�v�{�^��������*/
                processName = "MgrGazoSelect";
                log.Start(processName);
                inSession.setUploadCheck("");
                inSession.setNendo(inRequest.getNendo());
                inSession.setGazoUlSeq(inRequest.getGazoUl());
                inSession.setGazo_idx(inRequest.getGazo_idx());
                inSession.setUketukeNo(inRequest.getUketukeNo());
                inSession.setJknJkuNo(inRequest.getJknJkuNo());
                inSession.setFurigana(inRequest.getFurigana());
                inSession.setShimei(inRequest.getShimei());
                inSession.setSeq(inRequest.getSeq());
                inSession.setGazoKbn(inRequest.getGazoKbn());
                /* �u�摜�I���v��ʂɑJ�� */
                return FWD_NM_SUCCESS;
//            } else if (!BmaUtility.isNullOrEmpty(inSession.getGazo_idx())
//                    || !BmaUtility.isNullOrEmpty(inRequest.getKaojashinShosaiGazoUpd())) {
            } else if (!BmaUtility.isNullOrEmpty(inRequest.getKaojashinShosaiGazoUpd())) {
                /*�u��ʐ^�v�{�^��������*/
                processName = "MgrGazoSelect";
                log.Start(processName);
                String uketukeNo = !BmaUtility.isNullOrEmpty(inSession.getUketukeNo()) ? inSession.getUketukeNo() : inSession.getShosaiUketukeNo();
                String juknJkuNo = !BmaUtility.isNullOrEmpty(inSession.getJknJkuNo()) ? inSession.getJknJkuNo() : inSession.getShosaiJknJkuNo();
                String furigana = !BmaUtility.isNullOrEmpty(inSession.getFurigana()) ? inSession.getFurigana() : inSession.getShosaiFurigana();
                String shimei = !BmaUtility.isNullOrEmpty(inSession.getShimei()) ? inSession.getShimei() : inSession.getShosaiShimei();
                String seq = !BmaUtility.isNullOrEmpty(inSession.getSeq()) ? inSession.getSeq() : inSession.getShosaiSeq();
                if (BmaUtility.isNullOrEmpty(inSession.getGazo_idx())) {
                    /**
                     * �摜�h�c�w (�̔�)
                     */
                    Saiban saiban = new BmaSaibanService(DATA_SOURCE_NAME).getSaibanAndUpdate(BmaConstants.SAIBAN_GAZOIDX, inSession.getMoshikomishaId());
                    inSession.setGazo_idx(saiban.getGenzaiNo());
                }
                inSession.setUketukeNo(uketukeNo);
                inSession.setJknJkuNo(juknJkuNo);
                inSession.setFurigana(furigana);
                inSession.setShimei(shimei);
                inSession.setSeq(seq);
                /* �u�摜�I���v��ʂɑJ�� */
                return FWD_NM_SUCCESS;
            } else if (!BmaUtility.isNullOrEmpty(inRequest.getGazoUlKakunin())) {
                /*�u��ʐ^�v�{�^��������*/
                processName = "MgrGazoConfirm";
                log.Start(processName);
                inSession.setUketukeNo(inRequest.getUketukeNo());
                inSession.setJknJkuNo(inRequest.getJknJkuNo());
                inSession.setFurigana(inRequest.getFurigana());
                inSession.setShimei(inRequest.getShimei());
                inSession.setGazo_idx(inRequest.getGazoUlKakunin());

                /* �u�摜�m�F�v��ʂɑJ�� */
                return FWD_NM_SUCCESS;
            } else if (!BmaUtility.isNullOrEmpty(inRequest.getGazoChoiceBack())
                    && !BmaUtility.isNullOrEmpty(inSession.getKaojashinShosaiGazoUpd())) {
                /*�u�L�����Z���v�{�^��������*/
                processName = "MgrGazoSelectBack";
                log.Start(processName);

                /* �u�摜�f�[�^�A�b�v���[�h�v��ʂɖ߂� */
                return FWD_NM_RELOAD;
            } else if (!BmaUtility.isNullOrEmpty(inRequest.getGazoChoiceBack())) {
                /*�u�L�����Z���v�{�^��������*/
                processName = "MgrGazoSelectBack";
                log.Start(processName);

                /* �u�摜�f�[�^�A�b�v���[�h�v��ʂɖ߂� */
                return FWD_NM_BACK;
            } else if (!BmaUtility.isNullOrEmpty(inRequest.getGazoKakuninBack())) {
                /*�u����v�{�^��������*/
                processName = "MgrGazoConfirmBack";
                log.Start(processName);

                /* �u�摜�f�[�^�A�b�v���[�h�v��ʂɖ߂� */
                return FWD_NM_BACK;
            } else if (!BmaUtility.isNullOrEmpty(inSession.getGazoShosai())) {
                /*�u�L�����Z���v�{�^��������*/
                processName = "MgrGazoSelectBack";
                log.Start(processName);
               /* �ڍ׃��X�g�擾 */
               inRequest.setGazoShosai(inSession.getGazoShosai());
                searchShosaiJoho(inRequest, inSession);
                inSession.setGazoShosai(inRequest.getGazoShosai());
                return "shosai";
            } else {
                /*�ُ�J��*/
                log.IllegalFWD();
                return FWD_NM_SESSION;
            }
        } catch (Exception e) {
            throw e;
        } finally {
            log.End(processName);
        }
    }

    /**
     * ���̃��X�g���擾����
     *
     * @param groupCode
     * @return
     */
    public List<Option> findMeishoList(String groupCode) {
        List<Option> list = new ArrayList<>();
        //���̃��X�g��p�ӂ���
        MeishoKanri meishoKanri = new MeishoKanri(BmaConstants.DS_REGISTRANT);
        meishoKanri.findByGroupCode(groupCode, list);
        return list;
    }

    /**
     * �����u�K���X�g���擾����
     *
     * @param sknksuKbn
     * @return
     */
    public List<Option> findSknKsuList(String sknksuKbn) {
        List<Option> list = new ArrayList<>();
        //�����u�K���X�g��p�ӂ���
        SknksuMst sknksuMst = new SknksuMst(BmaConstants.DS_REGISTRANT);
        sknksuMst.findBySknKsuKbn(sknksuKbn, list);
        return list;
    }

    /**
     * ���̓`�F�b�N(����)
     *
     * @param inRequest
     * @return ��肪�Ȃ���� true�A����� false
     */
    private boolean ValidatorCaller(GazoKanriJoho inRequest, GazoKanriJoho inSession) throws Exception {
        if (BmaUtility.isNullOrEmpty(inRequest.getSknksuKbn())) {
            return true;
        }
        Messages errors = new Messages();	//���b�Z�[�W�i�[�p
        String sknksuKbn = inRequest.getSknksuKbn();
        String sknksuName = (sknksuKbn.equals(BmaConstants.SKN_KBN))
                ? inRequest.getSknName() : inRequest.getKsuName();
        String gazoShuruiChoice = inRequest.getGazoShuruiChoice();
        String[] chkGazoStatusChoice = inRequest.getChkGazoStatusChoice();
        String uketukeNo = inRequest.getUketukeNo();
        String jknJkuNo = inRequest.getJknJkuNo();
        String furigana = inRequest.getFurigana();
        String[] chkMskKbn = inRequest.getChkMskKbn();
        String[] chkKojinDantai = inRequest.getChkKojinDantai();

        // ����/�u�K��F�K�{�`�F�b�N
        BmaValidator.validateSelect(sknksuKbn, errors, BmaConstants.ERR_GROUP_SKN_KSU_KBN, BmaConstants.ARG_SKN_KSU_KBN);
        if (BmaValidator.validateMessageCheck(errors, BmaConstants.ERR_GROUP_SKN_KSU_KBN)) {
            // ����/�u�K��F�����`�F�b�N
            Validator.validateMaxLength(sknksuKbn, BmaConstants.LEN_SKN_KSU_KBN, errors, BmaConstants.ERR_GROUP_SKN_KSU_KBN, BmaConstants.ARG_SKN_KSU_KBN);
        }

        // ����/�u�K��F�K�{�`�F�b�N
        BmaValidator.validateSelect(sknksuName, errors, BmaConstants.ERR_GROUP_SKN_KSU_NAME, BmaConstants.ARG_SKN_KSU_NAME);
        if (BmaValidator.validateMessageCheck(errors, BmaConstants.ERR_GROUP_SKN_KSU_NAME)) {
            // ����/�u�K��F�����`�F�b�N
            Validator.validateMaxLength(sknksuName, BmaConstants.LEN_SKN_KSU_NAME, errors, BmaConstants.ERR_GROUP_SKN_KSU_NAME, BmaConstants.ARG_SKN_KSU_NAME);
        }

        // �摜��ށF�K�{�`�F�b�N
        BmaValidator.validateSelect(gazoShuruiChoice, errors, BmaConstants.ERR_GROUP_GAZO_SHURUI, BmaConstants.ARG_GAZO_SHURUI);
        if (BmaValidator.validateMessageCheck(errors, BmaConstants.ERR_GROUP_GAZO_SHURUI)) {
            // �摜��ށF�����`�F�b�N
            Validator.validateMaxLength(gazoShuruiChoice, BmaConstants.LEN_GAZO_SHURUI, errors, BmaConstants.ERR_GROUP_GAZO_SHURUI, BmaConstants.ARG_GAZO_SHURUI);
        }
        if (chkGazoStatusChoice != null) {
            // �摜�X�e�[�^�X�F�����`�F�b�N
            for (String chkGazoStatusChoice1 : chkGazoStatusChoice) {
                Validator.validateMaxLength(chkGazoStatusChoice1, BmaConstants.LEN_GAZO_STATUS, errors, BmaConstants.ERR_GROUP_GAZO_STATUS, BmaConstants.ARG_GAZO_STATUS);
                break;
            }
        }
        // ��t�ԍ��F�����`�F�b�N
        BmaValidator.validateNumber(uketukeNo, errors, BmaConstants.ERR_GROUP_UKETSUKE_NO, BmaConstants.ARG_UKETSUKE_NO);
        if (BmaValidator.validateMessageCheck(errors, BmaConstants.ERR_GROUP_UKETSUKE_NO)) {
            // ��t�ԍ��F�����`�F�b�N
            Validator.validateMaxLength(uketukeNo, BmaConstants.LEN_UKETSUKE_NO, errors, BmaConstants.ERR_GROUP_UKETSUKE_NO, BmaConstants.ARG_UKETSUKE_NO);
        }

        // ��/��u�ԍ��F�����`�F�b�N
        BmaValidator.validateAlphabetOrNumber(jknJkuNo, errors, BmaConstants.ERR_GROUP_JKN_JKU_NO, BmaConstants.ARG_JKN_JKU_NO);
        if (BmaValidator.validateMessageCheck(errors, BmaConstants.ERR_GROUP_JKN_JKU_NO)) {
            // ��/��u�ԍ��F�����`�F�b�N
            Validator.validateMaxLength(jknJkuNo, BmaConstants.LEN_JKN_JKU_NO, errors, BmaConstants.ERR_GROUP_JKN_JKU_NO, BmaConstants.ARG_JKN_JKU_NO);
        }

        // �t���K�i�F�����`�F�b�N
        BmaValidator.validateKatakana(furigana, errors, BmaConstants.ERR_GROUP_FURIGANA, BmaConstants.ARG_FURIGANA);
        if (BmaValidator.validateMessageCheck(errors, BmaConstants.ERR_GROUP_FURIGANA)) {
            // �t���K�i�F�����`�F�b�N
            Validator.validateMaxLength(furigana, BmaConstants.LEN_FURIGANA, errors, BmaConstants.ERR_GROUP_FURIGANA, BmaConstants.ARG_FURIGANA);
        }
        if (chkMskKbn != null) {
            // �\���敪�F�����`�F�b�N
            for (String chkMskKbn1 : chkMskKbn) {
                Validator.validateMaxLength(chkMskKbn1, BmaConstants.LEN_CHK_MSK_KBN, errors, BmaConstants.ERR_GROUP_CHK_MSK_KBN, BmaConstants.ARG_CHK_MSK_KBN);
                break;
            }
        }
        if (chkKojinDantai != null) {
            // �\���敪�F�����`�F�b�N
            for (String chkKojinDantai1 : chkKojinDantai) {
                Validator.validateMaxLength(chkKojinDantai1, BmaConstants.LEN_CHK_KOJIN_DANTAI, errors, BmaConstants.ERR_GROUP_CHK_KOJIN_DANTAI, BmaConstants.ARG_CHK_KOJIN_DANTAI);
                break;
            }
        }
        if (!errors.isEmpty()) {
            inSession.setErrors(errors);
            return false;
        } else {
            return true;
        }
    }

    /**
     * ���̓`�F�b�N(�ڍ�)
     *
     * @param inRequest
     * @return ��肪�Ȃ���� true�A����� false
     */
    private boolean ValidatorCallerShosai(GazoKanriJoho inRequest, GazoKanriJoho inSession) throws Exception {
        Messages errors = new Messages();	//���b�Z�[�W�i�[�p

        String biko = inRequest.getBiko();
        String shinsaKekka = inRequest.getShinsaKekka();
        String[] chkFubiRiyu = inRequest.getChkFubiRiyu();
        String[] arinashi = {"1", "2"};
        List<Option> fubiList = findMeishoList("HOSEI_IRAI_CODE");

        // ���l���F�����`�F�b�N
        if (BmaValidator.validateMaxLength(biko, BmaConstants.MAX_LENGTH_BIKO, errors, BmaConstants.ERR_GROUP_BIKO, BmaConstants.ARG_BIKO)) {
            // ���l���F�����`�F�b�N
            BmaValidator.validateMojiCodeForBiko(biko, errors, BmaConstants.ERR_GROUP_BIKO, BmaConstants.ARG_BIKO);
        }

        // �K�{�`�F�b�N
        BmaValidator.validateSelect(shinsaKekka, errors, BmaConstants.ERR_GROUP_SHINSAKEKKA, BmaConstants.ARG_SHINSAKEKKA);
        // �Ó����`�F�b�N
        if (BmaValidator.validateMessageCheck(errors, BmaConstants.ERR_GROUP_SHINSAKEKKA)) {
            Validator.validatePermissionSelect(shinsaKekka, arinashi, errors, BmaConstants.ERR_GROUP_SHINSAKEKKA, BmaConstants.ARG_SHINSAKEKKA);
        }
        if (chkFubiRiyu != null) {
            // �Ó����`�F�b�N
            for (String fubiRiyu : chkFubiRiyu) {
                BmaValidator.validatePermissionSelect(fubiRiyu, fubiList, errors, BmaConstants.ERR_GROUP_FUBIRIYU, BmaConstants.ARG_FUBIRIYU);
                break;
            }
        }
        if (!errors.isEmpty()) {
            inSession.setErrors(errors);
            return false;
        } else {
            return true;
        }
    }

    /**
     * �\��������������
     *
     * @param inSession �Z�b�V����RTO
     * @return true:����
     */
    private boolean searchJoho(GazoKanriJoho inSession) {
        Messages errors = new Messages();
        inSession.setSearchFlg("0");
        inSession.setSearchOutList(findGazoList(inSession));
        inSession.setSearchFlg("1");
        if (inSession.getSearchOutList().isEmpty()) {
            /* �L�[���X�g����̏ꍇ */
            BmaValidator.addMessage(errors, BmaConstants.ERR_GROUP_GAZO_SEARCH, BmaText.E00022, BmaConstants.ARG_GAZO_SEARCH);
            inSession.setErrors(errors);
            return false;
        }
        return true;
    }

    public boolean checkUpload(GazoKanriJoho inSession) {
        String gazoShuruiChoice = inSession.getGazoShuruiChoice();
        String[] chkGazoStatusChoice = inSession.getChkGazoStatusChoice();
        String[] chkMskKbn = inSession.getChkMskKbn();
        String[] chkKojinDantai = inSession.getChkKojinDantai();
        String hoseiKigen = inSession.getHoseiKigen();
        if (!BmaUtility.isNullOrEmpty(gazoShuruiChoice) && chkGazoStatusChoice[0] != null
                && chkKojinDantai[0] != null && chkMskKbn[0] != null && BmaUtility.isNullOrEmpty(hoseiKigen)) {
            return gazoShuruiChoice.equals(BmaConstants.FILE_KBN_PHOTO)
                    && chkGazoStatusChoice[0].equals(BmaConstants.MEISHO_KANRI_GROUP_CODE_HOSEI_IRAI_KBN_MIUPLOAD)
                    && (chkGazoStatusChoice.length == 1)
                    && chkMskKbn[0].equals(BmaConstants.MEISHO_KANRI_GROUP_CODE_MOSHIKOMI_KBN_YUBIN)
                    && (chkMskKbn.length == 1)
                    && chkKojinDantai[0].equals(BmaConstants.MEISHO_KANRI_GROUP_CODE_KOJIN_DANTAI_KBN_KOJIN)
                    && (chkKojinDantai.length == 1);
        } else {
            return false;
        }
    }

    /**
     * �摜�ꗗ���X�g������
     *
     * @param inSession
     * @return list
     */
    public List<GazoKanriJoho> findGazoList(GazoKanriJoho inSession) {
        String sknKsuCode = inSession.getSknKsuCode();
        String shubetsuCode = inSession.getShubetsuCode();
        String kaisuCode = inSession.getKaisuCode();
        String gazoShuruiChoice = inSession.getGazoShuruiChoice();
        String uketukeNo = inSession.getUketukeNoCond();
        String jknJkuNo = inSession.getJknJkuNo();
        String furigana = inSession.getFuriganaCond();
        String hoseiKigenBi = inSession.getHoseiKigenBi();
        String[] chkGazoStatusChoice = inSession.getChkGazoStatusChoice();
        String[] chkMskKbn = inSession.getChkMskKbn();
        String[] chkKojinDantai = inSession.getChkKojinDantai();
        String nendo = inSession.getNendo();
        String searchFlg = inSession.getSearchFlg();
        int page = inSession.getPage();
        List<GazoKanriJoho> list = new ArrayList<>();
        Gazo gazo = new Gazo(BmaConstants.DS_REGISTRANT);
        list = gazo.searchGazoList(sknKsuCode, shubetsuCode, kaisuCode,
                gazoShuruiChoice, chkGazoStatusChoice, uketukeNo, jknJkuNo,
                furigana, chkMskKbn, chkKojinDantai, page, searchFlg, nendo, hoseiKigenBi);
        for (int i = 0; i < list.size(); i++) {
            if (page == 0) {
                list.get(i).setGazoUlSeq(String.valueOf(i + 1));
            } else {
                list.get(i).setGazoUlSeq(String.valueOf(i + (BmaConstants.MAX_PAGE_NUM_MSK_JOHO_SEARCH * page) + 1));
            }
        }
        return list;
    }

    /**
     * �摜�ڍ׃��X�g������
     *
     * @param inRequest
     *
     * @param inSession
     */
    public void searchShosaiJoho(GazoKanriJoho inRequest, GazoKanriJoho inSession) throws ParseException {
        List<GazoKanriJoho> list;
        List<Option> fubiList;
        List<Option> fubiRiyuList = new ArrayList<>();
        List<Option> fubiAriList = new ArrayList<>();
        List<Shokureki> shoruilist;
        MeishoKanri meishoKanri = new MeishoKanri(BmaConstants.DS_REGISTRANT);
        fubiList = findMeishoList("HOSEI_IRAI_CODE");
        for (int i = 0; i < fubiList.size(); i++) {
            if (fubiList.get(i).getValue().equals("901")) {
                fubiAriList.add(new Option(fubiList.get(i).getValue(), fubiList.get(i).getLabel()));
            } else {
                fubiRiyuList.add(new Option(fubiList.get(i).getValue(), fubiList.get(i).getLabel()));
            }
        }
        inSession.setFubiAriCodes(fubiAriList);
        inSession.setFubiRiyuCodes(fubiRiyuList);
        list = findGazoShosai(inRequest, inSession);
        String gazoKbn = list.get(0).getGazoKbn();
        String gazoKbnChi = meishoKanri.find("GAZO_KBN", gazoKbn).getHanyoChi();
        inSession.setGazoShosaiList(list);
        inSession.setGazoKbn(gazoKbn);
        inSession.setGazoKbnChi(gazoKbnChi);
        String sknKsuCode = inSession.getSknKsuCode();
        String shubetsuCode = inSession.getShubetsuCode();
        String kaisuCode = inSession.getKaisuCode();
        String shikakuCode = list.get(0).getShikakuCode();
        String menjoCode = list.get(0).getMenjoCode();
        inSession.setShosaiUketukeNo(list.get(0).getUketukeNo());
        inSession.setShosaiJknJkuNo(list.get(0).getJknJkuNo());
        inSession.setShosaiFurigana(list.get(0).getFurigana());
        inSession.setShosaiShimei(list.get(0).getShimei());
        inSession.setShosaiSeq(list.get(0).getSeq());
        String gazoIdx = list.get(0).getGazo_idx();
        inSession.setGazo_idx(gazoIdx);
        inSession.setShinsaKekka(list.get(0).getShinsaKekka());
        List<String> fubiriyu = new ArrayList<>();
        fubiriyu.add(0, list.get(0).getFubiRiyu1());
        fubiriyu.add(1, list.get(0).getFubiRiyu2());
        fubiriyu.add(2, list.get(0).getFubiRiyu3());
        inSession.setFubiRiyuList(fubiriyu);
        inSession.setBiko(list.get(0).getBiko());
        SimpleDateFormat sdFormat = new SimpleDateFormat("yyyyMM");
        SimpleDateFormat sdFormat1 = new SimpleDateFormat("yyyyMMdd");
        SimpleDateFormat dt = new SimpleDateFormat("yyyy�NMM��dd��");
        if (gazoKbn.equals(BmaConstants.FILE_KBN_NENREI)) {
            String genmenChi = meishoKanri.findHanYoChi("COM_UMU_FLG", list.get(0).getGenmen()).getHanyoChi();
            inSession.setGazoKanrenKomoku1st("���Ɛ\��");
            inSession.setGazoKanrenKomoku2nd("���N����");
            inSession.setGazoKanrenJoho1st(genmenChi);
            Date date = new Date();
            String date1 = sdFormat1.format(date);
            SimpleDateFormat br1 = new SimpleDateFormat("yyyyMMdd");
            String birthday = list.get(0).getBirthday();
            int diff = BmaDateTimeUtility.differenceMonth(date1, birthday);
            inSession.setGazoKanrenJoho2nd(dt.format(br1.parse(birthday)) + "(" + String.valueOf(diff / 12) + "��)");
        }
        if (gazoKbn.equals(BmaConstants.FILE_KBN_SHIKAKU) || gazoKbn.equals(BmaConstants.FILE_KBN_MENJO)) {
            inSession.setGazoKanrenKomoku1st("���i���e");
            shoruilist = findShoruiShosai(inRequest, inSession);
            ArrayList<GazoKanriJoho> gakurekiShosaiList = new ArrayList<>();
            ArrayList<GazoKanriJoho> kunrenShosaiList = new ArrayList<>();
            for (int i = 0; i < shoruilist.size(); i++) {
                if (shoruilist.get(i).getShokurekiKbn().equals("3")) {
                    GazoKanriJoho bo = new GazoKanriJoho();
                    Date zaisekikikanFrom = sdFormat.parse(shoruilist.get(i).getZaisekikikanFrom());
                    Date zaisekikikanTo = sdFormat.parse(shoruilist.get(i).getZaisekikikanTo());
                    bo.setGazoKanrenKomoku3rd("�w����e");
                    bo.setGazoKanrenKomoku4td("�P������e");
                    bo.setGazoKanrenJoho3rd(shoruilist.get(i).getKinmusakiKaishaName());
                    bo.setGazoKanrenJoho4td(shoruilist.get(i).getBushoYakushokuName());
                    bo.setGazoKanrenJoho5td(dt.format(zaisekikikanFrom) + "�`" + dt.format(zaisekikikanTo));
                    bo.setGazoKanrenJoho6td("");
                    bo.setGazoKanrenJoho7td("");
                    bo.setGazoKanrenJoho8td("");
                    gakurekiShosaiList.add(bo);
                    inSession.setGakurekiShosaiList(gakurekiShosaiList);
                } else {
                    GazoKanriJoho bo = new GazoKanriJoho();
                    Date zaisekikikanFrom = sdFormat.parse(shoruilist.get(i).getZaisekikikanFrom());
                    Date zaisekikikanTo = sdFormat.parse(shoruilist.get(i).getZaisekikikanTo());
                    bo.setGazoKanrenKomoku3rd("�w����e");
                    bo.setGazoKanrenKomoku4td("�P������e");
                    bo.setGazoKanrenJoho3rd("");
                    bo.setGazoKanrenJoho4td("");
                    bo.setGazoKanrenJoho5td("");
                    bo.setGazoKanrenJoho6td(shoruilist.get(i).getKinmusakiKaishaName());
                    bo.setGazoKanrenJoho7td(shoruilist.get(i).getBushoYakushokuName());
                    bo.setGazoKanrenJoho8td(dt.format(zaisekikikanFrom) + "�`" + dt.format(zaisekikikanTo));
                    kunrenShosaiList.add(bo);
                    inSession.setKunrenShosaiList(kunrenShosaiList);
                }
            }
        }
        if (gazoKbn.equals(BmaConstants.FILE_KBN_SHIKAKU)) {
            MShikakuMst mShikakuMst = new MShikakuMst(BmaConstants.DS_REGISTRANT);
            String shikakuShosai = mShikakuMst.searchShikakuShosai(sknKsuCode, shubetsuCode, kaisuCode, shikakuCode);
            inSession.setGazoKanrenJoho1st(shikakuShosai);
            inSession.setGazoKanrenJoho2nd(list.get(0).getShinseiShikakuNo());
        }
        if (gazoKbn.equals(BmaConstants.FILE_KBN_MENJO)) {
            MMenjoMst mMenjoMst = new MMenjoMst(BmaConstants.DS_REGISTRANT);
            String menjoShosai = mMenjoMst.searchMenjoShosai(sknKsuCode, shubetsuCode, kaisuCode, menjoCode);
            inSession.setGazoKanrenJoho1st(menjoShosai);
            inSession.setGazoKanrenJoho2nd(list.get(0).getShinseiMenjoNo());
        }
    }

    /**
     * �摜�ڍ׃��X�g������
     *
     * @param inRequest
     * @param inSession
     * @return list
     */
    public List<GazoKanriJoho> findGazoShosai(GazoKanriJoho inRequest, GazoKanriJoho inSession) {
        List<GazoKanriJoho> list;
        List<GazoKanriJoho> listShosai;
        Gazo gazo = new Gazo(BmaConstants.DS_REGISTRANT);
        list = inSession.getGazoDetailList();
        String nendo = null;
        String uketukeNo = null;
        String gazoKbn = null;
        String seq = null;
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).getGazoUlSeq().equals(inRequest.getGazoShosai())) {
                nendo = list.get(i).getNendo();
                uketukeNo = list.get(i).getUketukeNo();
                gazoKbn = list.get(i).getGazoKbn();
                seq = list.get(i).getSeq();
                break;
            }
        }

        listShosai = gazo.searchGazoShosai(nendo, uketukeNo, gazoKbn, seq);
        return listShosai;
    }

    /**
     * ���i�ڍ׃��X�g������
     *
     * @param inRequest
     * @param inSession
     * @return list
     */
    public List<Shokureki> findShoruiShosai(GazoKanriJoho inRequest, GazoKanriJoho inSession) {
        List<Shokureki> list = new ArrayList<>();
        Shokureki shokureki = new Shokureki(BmaConstants.DS_REGISTRANT);
        list = shokureki.searchGazoShoruiShosai(inSession.getShosaiUketukeNo(), inSession.getNendo());
        return list;
    }

    /**
     * �w��y�[�W���ɍ��킹�āA�\�������ꃊ�X�g���쐬
     *
     * @param inSession�@�Z�b�V�������X�g
     */
    public void pageIndex(GazoKanriJoho inSession) {
        /* �ϐ������� */
        List<GazoKanriJoho> displayList = new ArrayList<>();
        GazoKanriJoho gazoKanri;

        List<GazoKanriJoho> resultList = inSession.getSearchOutList();
        if (resultList.isEmpty() || resultList.size() < inSession.getMaxDisp()) {
            return;
        }
        /* �y�[�W���ɍ��킹�ĕ\���p���X�g�쐬 */
        for (int i = inSession.getFirstDisp() - 1; i < inSession.getMaxDisp(); ++i) {
            gazoKanri = resultList.get(i);
            displayList.add(gazoKanri);
        }
        inSession.setGazoDetailList(displayList);
    }

    /**
     * �y�[�W����
     *
     * @param inSession�@�Z�b�V�������X�g
     * @return �\���p�L�[���X�g
     */
    private void setPage(GazoKanriJoho inSession) {
        int idx;
        int max;
        int maxLenDisp = inSession.getSearchOutList().size();
        int pageMax;

        /* ��ʂɕ\������ő匏�����擾 */
        int page = inSession.getPage();
        idx = page * BmaConstants.MAX_PAGE_NUM_MSK_JOHO_SEARCH;

        max = idx + BmaConstants.MAX_PAGE_NUM_MSK_JOHO_SEARCH;
        inSession.setFirstDisp(idx + 1);

        /* �������ʂ̌��� */
        if (maxLenDisp < max) {
            inSession.setMaxDisp(maxLenDisp);
        } else {
            /* �ő匏����茟�����ʂ������ꍇ */
            inSession.setMaxDisp(max);
        }

        /* �y�[�W�ԍ��̍ő���v�Z */
        pageMax = (int) (Math.ceil((double) maxLenDisp / (double) (BmaConstants.MAX_PAGE_NUM_MSK_JOHO_SEARCH)));
        inSession.setPageMax(pageMax + 1);

        /* �y�[�W�ԍ��ݒ� */
        int now = 0;
        now = inSession.getPage();

        /* �Œጏ�� */
        if (now == 0) {
            inSession.setPageBegin(now + 1);
        } else if (now == 1) {
            inSession.setPageBegin(now);
        } else if (now == 2) {
            inSession.setPageBegin(now - 1);
        } else {
            inSession.setPageBegin(now - 2);
        }
        /* �ő匏�����\������ő匏����3�{�ȉ��������ꍇ�̕\���p�y�[�W�ԍ� */
        if (now == pageMax) {
            inSession.setPageEnd(now + 1);
        } else if (now == pageMax - 1) {
            inSession.setPageEnd(now + 2);
        } else if (now == pageMax - 2) {
            inSession.setPageEnd(now + 3);
        } else {
            inSession.setPageEnd(now + 4);
        }
        inSession.setPage(now + 1);
    }

    /**
     * ���̓f�[�^���Z�b�V�����f�[�^�ɃZ�b�g����B
     *
     * @param inRequest ���N�G�X�g��̓��̓f�[�^
     * @param inSession �Z�b�V������̓��̓f�[�^
     */
    private void setValueRequestToSession(GazoKanriJoho inRequest, GazoKanriJoho inSession) {
        if (BmaUtility.isNullOrEmpty(inRequest.getSknksuKbn())) {
            return;
        }
        Date date = new Date();
        SimpleDateFormat dt = new SimpleDateFormat("yyyyMMdd");
        String sknksuName = (BmaConstants.SKN_KBN.equals(inRequest.getSknksuKbn()))
                ? inRequest.getSknName() : inRequest.getKsuName();
        inSession.setSknKsuCode(sknksuName.substring(0, 2));
        inSession.setShubetsuCode(sknksuName.substring(2, 4));
        inSession.setKaisuCode(sknksuName.substring(4, 6));

        // �����^�u�K��
        inSession.setSknksuKbn(inRequest.getSknksuKbn());
        // ������
        inSession.setSknName(inRequest.getSknName());
        // �u�K�
        inSession.setKsuName(inRequest.getKsuName());
        // �摜���
        inSession.setGazoShuruiChoice(inRequest.getGazoShuruiChoice());
        // �摜�X�e�[�^�X
        List<Option> tmp = inSession.getHoseiIraiKbnList();
        String strChkGazoStatusChoice[] = new String[tmp.size()];
        List<String> chkGazoStatusChoice = null;
        if (inRequest.getChkGazoStatusChoice() != null) {
            chkGazoStatusChoice = Arrays.asList(inRequest.getChkGazoStatusChoice());
        }
        if (chkGazoStatusChoice != null) {
            if (chkGazoStatusChoice.size() > 0) {
                for (int j = 0; j < tmp.size(); j++) {
                    String fromList = tmp.get(j).getValue();
                    if (chkGazoStatusChoice.contains(fromList)) {
                        strChkGazoStatusChoice[j] = fromList;
                    } else {
                        strChkGazoStatusChoice[j] = "";
                    }
                }
            }
        }
        inSession.setChkGazoStatusChoice(strChkGazoStatusChoice);

        // �␳����        
        inSession.setHoseiKigen(inRequest.getHoseiKigen());
        // ��t�ԍ�
        inSession.setUketukeNoCond(inRequest.getUketukeNoCond());
        // �󌟁^��u�ԍ�
        inSession.setJknJkuNo(inRequest.getJknJkuNo());
        // �t���K�i
        inSession.setFuriganaCond(inRequest.getFuriganaCond());

        // �\���敪
        inSession.setChkMskKbn(inRequest.getChkMskKbn());
        tmp = inSession.getMoshikomiKbnList();
        String strChkMskKbn[] = new String[tmp.size()];
        List<String> chkMskKbn = null;
        if (inRequest.getChkMskKbn() != null) {
            chkMskKbn = Arrays.asList(inRequest.getChkMskKbn());
        }
        if (chkMskKbn != null) {
            if (chkMskKbn.size() > 0) {
                for (int j = 0; j < tmp.size(); j++) {
                    String fromList = tmp.get(j).getValue();
                    if (chkMskKbn.contains(fromList)) {
                        strChkMskKbn[j] = fromList;
                    } else {
                        strChkMskKbn[j] = "";
                    }
                }
            }
        }
        inSession.setChkMskKbn(strChkMskKbn);

        // �l�^�c�̋敪
        tmp = inSession.getMoshikomiKbnList();
        String strChkKojinDantai[] = new String[tmp.size()];
        List<String> chkKojinDantai = null;
        if (inRequest.getChkKojinDantai() != null) {
            chkKojinDantai = Arrays.asList(inRequest.getChkKojinDantai());
        }
        if (chkKojinDantai != null) {
            if (chkKojinDantai.size() > 0) {
                for (int j = 0; j < tmp.size(); j++) {
                    String fromList = tmp.get(j).getValue();
                    if (chkKojinDantai.contains(fromList)) {
                        strChkKojinDantai[j] = fromList;
                    } else {
                        strChkKojinDantai[j] = "";
                    }
                }
            }
        }
        inSession.setChkKojinDantai(strChkKojinDantai);

        if (!BmaUtility.isNullOrEmpty(inRequest.getHoseiKigenBi())) {
            inSession.setHoseiKigenBi(dt.format(date));
        }
        /* �N�x�擾 */
        Schedule schedule = new Schedule(BmaConstants.DS_REGISTRANT);
        String nendo = schedule.findNendoKojiKikan(inSession.getSknKsuCode(), inSession.getShubetsuCode(), inSession.getKaisuCode(), BmaConstants.SCHED_CODE_OPEN, BmaConstants.SCHEDULE_KBN_ST);
        inSession.setNendo(nendo);

    }

    /**
     * �y���ʐ\���z�摜�A�b�v���[�h�ɑJ�ڂ��邩���肷��B
     *
     * @param inSession �Z�b�V������̓��̓f�[�^
     */
    private Boolean checkToSmn(GazoKanriJoho inSession) {
        Boolean result = false;

        if ("00".equals(inSession.getGazoShuruiChoice())// �摜�敪=��ʐ^
                && (inSession.getChkGazoStatusChoice() != null && inSession.getChkGazoStatusChoice().length == 1 && BmaConstants.HOSEI_IRAI_KBN_1.equals(inSession.getChkGazoStatusChoice()[0]))// �摜�X�e�[�^�X=���A�b�v���[�hOnly
                && BmaUtility.isNullOrEmpty(inSession.getHoseiKigenBi())// �␳����Blank
                && BmaUtility.isNullOrEmpty(inSession.getUketukeNo())// ��t�ԍ�Blank
                && BmaUtility.isNullOrEmpty(inSession.getJknJkuNo())// �󌟎�u�ԍ�Blank
                && BmaUtility.isNullOrEmpty(inSession.getFurigana())// �t���K�iBlank
                && (inSession.getChkMskKbn() != null && inSession.getChkMskKbn().length == 1 && BmaConstants.MEISHO_KANRI_GROUP_CODE_MOSHIKOMI_KBN_YUBIN.equals(inSession.getChkMskKbn()[0]))// �\���敪=�X��
                && (inSession.getChkKojinDantai() != null && inSession.getChkKojinDantai().length == 1 && BmaConstants.MEISHO_KANRI_GROUP_CODE_KOJIN_DANTAI_KBN_KOJIN.equals(inSession.getChkKojinDantai()[0]))// �l�c�̋敪=�l
                ) {
            result = true;
        }
        return result;
    }

    /**
     * �摜�ڍ׏���o�^����
     *
     * @param gazo
     * @param inSession
     */
    public void setGazoTrk(Gazo gazo, GazoKanriJoho inSession) {
        Date date = new Date();
        SimpleDateFormat dt = new SimpleDateFormat("yyyyMMdd");
        SimpleDateFormat tm = new SimpleDateFormat("HHmmss");
        gazo.setHoseiIraiKbn(inSession.getHoseiIraiKbn());
        gazo.setGazoHyojiKbn(inSession.getGazoHyojiKbn());
        if (BmaConstants.MEISHO_KANRI_GROUP_CODE_HOSEI_IRAI_KBN_KANRYOU.equals(gazo.getHoseiIraiKbn())) {
            gazo.setHoseiFinishBi(dt.format(date));
            gazo.setHoseiFinishTime(tm.format(date));    
        } else {
            gazo.setHoseiIraiBi(dt.format(date));
            gazo.setHoseiIraiTime(tm.format(date));
            gazo.setHoseiFinishBi("");
            gazo.setHoseiFinishTime("");    
            // �摜�s���������ԏI�������擾
            Schedule sched = new Schedule(DATA_SOURCE_NAME);
            sched = sched.find(inSession.getNendo(), inSession.getSknKsuCode(), inSession.getShubetsuCode(), inSession.getKaisuCode(), BmaConstants.SCHEDULE_CODE_20, BmaConstants.SCHEDULE_KBN_2);
            gazo.setHoseiKigenBi(sched.getDate());
        }
        gazo.setHoseiIraiCode1(inSession.getFubiRiyu1());
        gazo.setHoseiIraiCode2(inSession.getFubiRiyu2());
        gazo.setHoseiIraiCode3(inSession.getFubiRiyu3());
        gazo.setKoshinKbn("U");
        gazo.setKoshinDate(dt.format(date));
        gazo.setKoshinTime(tm.format(date));
        gazo.setKoshinUserId(inSession.getMoshikomishaId());
        gazo.setGazoIdx(inSession.getGazo_idx());
    }

    /**
     * �摜�_�E�����[�h����
     *
     * @param inRequest
     * @param inSession
     * @throws Exception ��O
     */
    public void gazoDownload(GazoKanriJoho inRequest, GazoKanriJoho inSession) throws Exception {
        List<GazoKanriJoho> list;
        List<String> idxList = new ArrayList<>();
        List<String> uketsukeList = new ArrayList<>();
        list = inSession.getSearchOutList();
        idxList = list.stream().map(GazoKanriJoho::getGazo_idx).collect(Collectors.toList());
        uketsukeList = list.stream().map(GazoKanriJoho::getUketukeNo).collect(Collectors.toList());
        String[] gazo_idxs = inRequest.getGazo_idxs();
        gazo_idxs = Arrays.stream(gazo_idxs)
                .filter(s -> (s != null && s.length() > 0))
                .toArray(String[]::new);
        String[] urls = new String[gazo_idxs.length];
        String path = BmaConstants.PHOTO_UPLOAD_PATH_KAKUTEI;
        for (int i = 0; i < gazo_idxs.length; i++) {
            urls[i] = path + gazo_idxs[i] + ".jpeg";
        }
        Date date = new Date();
        SimpleDateFormat dt = new SimpleDateFormat("yyyyMMddHHmmss");
        String downloadDate = dt.format(date);
        String kanrishaName = inSession.getShimei();
        String tagPath = kanrishaName + downloadDate + ".zip";
        ZipOutputStream out = new ZipOutputStream(new FileOutputStream(tagPath));
        File[] files = new File[urls.length];
        for (int i = 0; i < files.length; i++) {
            files[i] = new File(urls[i]);
        }
        byte[] b = new byte[1024];
        for (int j = 0; j < files.length; j++) {
            if (!files[j].exists()) {
                continue;
            }
            FileInputStream in = new FileInputStream(files[j]);
            out.putNextEntry(new ZipEntry(files[j].getName()));
            int len = 0;
            while ((len = in.read(b)) > -1) {
                out.write(b, 0, len);
            }
            out.closeEntry();
        }
        out.close();
        FileInputStream is = new FileInputStream(tagPath);
        inRequest.setInputStream(is);
        inRequest.setHeader(tagPath, tagPath);
        inRequest.setHeader("Content-Type", "charset=UTF-8");
        inRequest.setHeader("Content-Disposition", "attachment; filename=\"" + URLEncoder.encode(tagPath, BmaConstants.ENCODE_UTF_8) + "\"");
        inRequest.setHeader("Content-Type", "application/zip");
    }

    /**
     * �摜�����X�V����
     *
     * @param gazo
     * @param inSession
     * @param gazoKoshinData
     */
    public void setGazoUpd(Gazo gazo, GazoKanriJoho inSession, Gazo gazoKoshinData) {
        Date date = new Date();
        SimpleDateFormat dt = new SimpleDateFormat("yyyyMMdd");
        SimpleDateFormat tm = new SimpleDateFormat("HHmmss");
        gazo.setHoseiIraiKbn(gazoKoshinData.getHoseiIraiKbn());
        gazo.setGazoHyojiKbn(gazoKoshinData.getGazoHyojiKbn());
        gazo.setHoseiIraiCode1(gazoKoshinData.getHoseiIraiCode1());
        gazo.setHoseiIraiCode2(gazoKoshinData.getHoseiIraiCode2());
        gazo.setHoseiIraiCode3(gazoKoshinData.getHoseiIraiCode3());
        gazo.setKoshinKbn("U");
        gazo.setKoshinDate(dt.format(date));
        gazo.setKoshinTime(tm.format(date));
        gazo.setKoshinUserId(inSession.getMoshikomishaId());
    }

    /**
     * �\�������X�V����
     *
     * @param bo
     * @param inSession
     */
    public void setMoshikomiUpd(Moshikomi bo, GazoKanriJoho inSession) {
        Date date = new Date();
        SimpleDateFormat dt = new SimpleDateFormat("yyyyMMdd");
        SimpleDateFormat tm = new SimpleDateFormat("HHmmss");
        bo.setKanriMemo(inSession.getBiko());
        bo.setKoshinKbn(BmaConstants.SHORI_KBN_UPDATE);
        bo.setKoshinDate(dt.format(date));
        bo.setKoshinTime(tm.format(date));
        bo.setKoshinUserId(inSession.getMoshikomishaId());
    }

    /**
     * �\���ύX��o�^����
     *
     * @param bo
     * @param inSession
     * @throws java.lang.Exception
     */
    public void setMoshikomihenkoTrk(MoshikomiHenkoRireki bo, GazoKanriJoho inSession) throws Exception {
        Date date = new Date();
        SimpleDateFormat dt = new SimpleDateFormat("yyyyMMdd");
        SimpleDateFormat tm = new SimpleDateFormat("HHmmss");
        String koshinDate = dt.format(date);
        String koshinTime = tm.format(date);
        Saiban saiban = new BmaSaibanService(DATA_SOURCE_NAME).getSaibanAndUpdate(BmaConstants.SAIBAN_MOSHIKOMI_HENKOID, inSession.getMoshikomishaId());
        bo.setMoshikomiHenkoRirekiIdx(saiban.getGenzaiNo());
        bo.setHenkoKbn("1");
        bo.setKoshinKbn(BmaConstants.SHORI_KBN_INSERT);
        bo.setTorokuDate(koshinDate);
        bo.setTorokuTime(koshinTime);
        bo.setTorokuUserId(inSession.getMoshikomishaId());
        bo.setKoshinDate("");
        bo.setKoshinTime("");
        bo.setKoshinUserId("");
        bo.setRonriSakujoFlg(BmaConstants.FLG_OFF);
    }

    /**
     * �\�������X�V����(�摜�A�b�v���[�h��)
     *
     * @param bo
     * @param inSession
     */
    public void moshikomiUpdForGazoUpload(Moshikomi bo, GazoKanriJoho inSession) {
        Date date = new Date();
        SimpleDateFormat dt = new SimpleDateFormat("yyyyMMdd");
        SimpleDateFormat tm = new SimpleDateFormat("HHmmss");
        String koshinDate = dt.format(date);
        String koshinTime = tm.format(date);
        bo.setMoshikomiJokyoKbn("01");
        bo.setUnyoJokyoKbn("01");
        bo.setKoshinKbn(BmaConstants.SHORI_KBN_UPDATE);
        bo.setKoshinDate(koshinDate);
        bo.setKoshinTime(koshinTime);
        bo.setKoshinUserId(inSession.getMoshikomishaId());
    }

    /**
     * �摜�����X�V����(�摜�A�b�v���[�h��)
     *
     * @param bo
     * @param inSession
     */
    public void gazoUpdForGazoUpload(Gazo bo, GazoKanriJoho inSession) throws Exception {
        Date date = new Date();
        SimpleDateFormat dt = new SimpleDateFormat("yyyyMMdd");
        SimpleDateFormat tm = new SimpleDateFormat("HHmmss");
        String koshinDate = dt.format(date);
        String koshinTime = tm.format(date);
        bo.setGazoIdx(inSession.getGazo_idx());
        bo.setHoseiIraiKbn("2");
        bo.setGazoHyojiKbn("1");
        bo.setKoshinKbn(BmaConstants.SHORI_KBN_UPDATE);
        bo.setKoshinDate(koshinDate);
        bo.setKoshinTime(koshinTime);
        bo.setKoshinUserId(inSession.getMoshikomishaId());
    }

    /**
     * �摜�A�b�v���[�h����
     *
     * @param inRequest
     * @param inSession
     * @return true:�A�b�v���[�h���� false:�A�b�v���[�h�t�@�C����
     */
    private boolean uploadGazo(GazoKanriJoho inRequest, GazoKanriJoho inSession) throws Exception {
        Messages errors = new Messages();
        String groupCode = "fileItem";
        String itemName = "�摜�t�@�C��";

        //�t�@�C���A�b�v���[�h FileItem�g�p
        if (inRequest.getFileItem() != null && !BmaUtility.isNullOrEmpty(inRequest.getFileItem().getName())) {
            FileItem item = inRequest.getFileItem();
            /* �t�@�C�����擾 */
            String fileName = inRequest.getFileItem().getName();
            String orgPath = BmaConstants.PHOTO_UPLOAD_PATH_KAKUTEI;
            String strNam = "";
            strNam = inSession.getGazo_idx() + ".jpeg";
            /* �g���q�`�F�b�N */
            if (!BmaValidator.validateFileExtension(fileName, BmaConstants.PHOTO_FILE_EXTENSIONS, errors, groupCode, "JPEG")) {
                inSession.setErrors(errors);
                return false;
            }

            /* �t�@�C���T�C�Y�`�F�b�N */
            if (!BmaValidator.validateFileSize(item.getSize(),
                    BmaConstants.PHOTO_UPLOAD_MAX_FILE_SIZE, errors, groupCode, itemName)) {
                /* ����l���I�[�o�[�����ꍇ�G���[ */
                inSession.setErrors(errors);
                return false;
            }

            File file = new File(orgPath);
            if (!file.exists()) {
                /* PATH���݂��Ă��܂���̎��G���[*/
                BmaValidator.addMessage(errors, "fileItem", "{0}�͑��݂��Ă��܂���B", orgPath);
                inSession.setErrors(errors);
                return false;
            }

            FileItem objFi = inRequest.getFileItem();
            String path = orgPath + strNam;
            try {
                /*���[�U�C���f�b�N�X���ݎ�*/
                if (strNam != null && !strNam.equals("")) {
                    /*�������Ƀt�@�C�������݂����ꍇ�͍폜*/
                    if (new File(orgPath + strNam).exists()) {
                        Files.delete((Paths.get(orgPath + strNam)));
                    }

                    objFi.write(new File(orgPath + strNam));
                    boolean retCheck = isImage(inSession, item, orgPath, strNam);
                    if (!retCheck) {
                        Files.delete((Paths.get(orgPath + strNam)));
                        inSession.setGazo_idx("");
                        return false;
                    }
                    /* �摜�̃T�C�Y�`�F�b�N */
                    if (!BmaValidator.validateImgSize(path, Integer.parseInt(BmaConstants.PHOTO_PIXEL_WIDTH),
                            Integer.parseInt(BmaConstants.PHOTO_PIXEL_HEIGHT), errors, groupCode, itemName)) {
                        /* ����l���I�[�o�[�����ꍇ�G���[ */
                        inSession.setErrors(errors);
                        Files.delete((Paths.get(orgPath + strNam)));
                        inSession.setGazo_idx("");
                        return false;
                    }
                } else {
                    BmaValidator.validateRequired("", errors, groupCode, itemName);
                    inSession.setErrors(errors);
                    return false;
                }
            } catch (FileSystemException e) {
                /*���O�o�͓�*/
                log.warn("�摜�̃A�b�v���[�h�Ɏ��s���܂����B", e);
            } catch (Exception e) {
                /*���O�o�͓�*/
                log.warn("�摜�̃A�b�v���[�h�Ɏ��s���܂����B", e);
                throw e;
            } finally {
                objFi.delete();
                inRequest.setFileItem(null);
            }

            BmaValidator.addMessage(errors, "fileItem", BmaText.E00046, "");
            inSession.setErrors(errors);

            return true;
        } else {
            BmaValidator.validateRequired("", errors, groupCode, itemName);
            inSession.setErrors(errors);
            return false;
        }

    }

    public static boolean isImage(GazoKanriJoho inSession, FileItem image, String orgPath, String strNam) throws IOException {
        Messages errors = new Messages();
        //DataInputStream dataInStream = null;
        // RGB���[�h������
        byte[] header = new byte[20];
        int readByte = 0, totalByte = 0;
        try ( // From *.jpg
                DataInputStream dataInStream
                = new DataInputStream(
                        new BufferedInputStream(
                                new FileInputStream(orgPath + strNam)));) {
            readByte = dataInStream.read(header);
            // RGB���[�h������@JPEG�t�@�C���擪�W�o�C�g��FF D8 FF E0�ł��邱��
            if ((header[0] & 0xFF) == 0xFF
                    && (header[1] & 0xFF) == 0xD8
                    && (header[2] & 0xFF) == 0xFF
                    && (header[3] & 0xFF) == 0xE0) {
            } else {
                /* RGB���[�h�łȂ����G���[*/
                BmaValidator.addMessage(errors, "fileItem", "JPEG�`�����ł�RGB���[�h�̃t�@�C�����g�p���Ă��������B", orgPath);
                inSession.setErrors(errors);
                return false;
            }
            return true;
        }
    }

}
