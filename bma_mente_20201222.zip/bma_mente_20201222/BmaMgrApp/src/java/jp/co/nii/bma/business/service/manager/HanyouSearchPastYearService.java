package jp.co.nii.bma.business.service.manager;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import jp.co.nii.bma.business.domain.HanyoKensakuDtlJkn;
import jp.co.nii.bma.business.domain.HanyoKensakuHedJkn;
import jp.co.nii.bma.business.domain.Torokusha;
import jp.co.nii.bma.business.domain.MeishoKanri;
import jp.co.nii.bma.business.domain.Saiban;
import jp.co.nii.bma.business.rto.manager.HanyouSearchJoho;
import jp.co.nii.bma.business.service.common.BmaConstants;
import jp.co.nii.bma.business.service.common.BmaLogger;
import jp.co.nii.bma.business.service.common.BmaSaibanService;
import jp.co.nii.bma.business.service.common.BmaValidator;
import jp.co.nii.bma.presentation.common.BmaText;
import jp.co.nii.bma.utility.BmaStringUtility;
import jp.co.nii.bma.utility.BmaUtility;
import jp.co.nii.sew.business.SystemTime;
import jp.co.nii.sew.business.Validator;
import jp.co.nii.sew.business.service.AbstractService;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_SESSION;
import jp.co.nii.sew.presentation.Messages;
import jp.co.nii.sew.presentation.Option;
import jp.co.nii.sew.presentation.RequestTransferObject;
import jp.co.nii.sew.utility.PropertyUtility;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.validator.GenericValidator;

/**
 * <p>
 * �^�C�g��: �ėp������ʃT�[�r�X</p>
 * <p>
 * ����: �ėp������ʃT�[�r�X</p>
 * <p>
 * ���쌠: Copyright (c) 2020</p>
 * <p>
 * ��Ж�: ���{���Y�Ɗ������</p>
 */
public class HanyouSearchPastYearService extends AbstractService {

    /**
     * DB�ڑ��̃f�[�^�\�[�X
     */
    private static String DATA_SOURCE_NAME;
    /**
     * ���O
     */
    BmaLogger log = (BmaLogger) BmaLogger.getLogger(this.getClass().getName());
    /**
     * �Ɩ��R�[�h
     */
    private static final String BUSINESS_CODE = PropertyUtility.getProperty("business_code");
    /**
     * ���׃e�X�g���[�h
     */
    private static final String STRESS_MODE = PropertyUtility.getProperty(BUSINESS_CODE + "stress_mode");
    /**
     * �N�x
     */
    private static final String NEN = PropertyUtility.getProperty(BUSINESS_CODE + "nen");

    /**
     * �R���X�g���N�^
     */
    public HanyouSearchPastYearService() {
        super();
        /* DB�ڑ����̃��[�U�[������ */
        DATA_SOURCE_NAME = BmaConstants.DS_REGISTRANT;
    }

    /**
     * �T�[�r�X�N���X�̎��s���\�b�h
     *
     * @param rto ���N�G�X�g��񂩂�擾����rto
     * @param rtoinSession �Z�b�V�������rto
     * @return foward��
     * @throws Exception ��O
     */
    @Override
    public String doService(RequestTransferObject rto, RequestTransferObject rtoinSession)
            throws Exception {

        HanyouSearchJoho inRequest = (HanyouSearchJoho) rto;
        HanyouSearchJoho inSession = (HanyouSearchJoho) rtoinSession;
        String processName = "";

        /*�G���[���b�Z�[�W������*/
        inSession.setErrors(new Messages());

        try {
            if (!BmaUtility.isNullOrEmpty(inRequest.getInpClear())) {
                /*��ʃ��Z�b�g*/
                inSession.clearInfo();
                /*��ʃ��Z�b�g*/
                inSession.clearInfo();
                inSession.clearInfoHairetu();

                return FWD_NM_RELOAD;
            } else if (!BmaUtility.isNullOrEmpty(inRequest.getHanyouSearchWhe())) {
                /*�����{�^��������*/
                processName = "hanyouSearchWhe";
                log.Start(processName);

                String forword = "";

                List<Option> list;
                /* ���̊Ǘ��I�u�W�F�N�g�擾 */
                MeishoKanri meisho = new MeishoKanri(DATA_SOURCE_NAME);
                /*�^�p�󋵃��X�g�擾*/
                list = new ArrayList<>();
                meisho.findByGroupCode(BmaConstants.UNYO_JOKYO_KBN, list);
                inSession.setUnyouList(list);
                // ���̓f�[�^���Z�b�V�����f�[�^�ɃZ�b�g
                HanyouSearchJoho taihi = new HanyouSearchJoho();
                setValueRequestToTaihi(inRequest, inSession, taihi);
                inSession.setTaihi(taihi);

                // ���̓f�[�^���Z�b�V�����f�[�^�ɃZ�b�g����
                setValueRequestToSession(inRequest, inSession);

                /*���̓`�F�b�N*/
                boolean retCheck = ValidatorSearch(inRequest, inSession);
                if (!retCheck) {
                    return FWD_NM_RELOAD;
                }
                Torokusha torokusha = new Torokusha(DATA_SOURCE_NAME);

                /* ���X�g��������t�ԍ��̃f�[�^�𒊏o */
                List<HanyouSearchJoho> allList = torokusha.findHanyouPastList(inRequest, inSession);
                inSession.setHanyouAllList(allList);
                if (allList.isEmpty()) {
                    Messages errors = new Messages();
                    BmaValidator.addMessage(errors, "info", BmaText.M00034, "");
                    inSession.setErrors(errors);
                }

                // ��肪�Ȃ���� true
                if (retCheck && !allList.isEmpty()) {
                    /* �������������� */
                    clearSearchInput(inSession);

                    // �߂�{�^���p�t���O
                    inSession.setBackFlag("2");

                    // �y�[�W����
                    inSession.setPage(0);
                    setPage(inSession);
                    setDisplayList(inSession);

                    forword = FWD_NM_NEXT;
                } else {
                    if (allList.isEmpty()) {
                        Messages errors = new Messages();
                        BmaValidator.addMessage(errors, "info", BmaText.M00034, "");
                        inSession.setErrors(errors);
                    }
                    forword = FWD_NM_RELOAD;
                }
                /* ����������ʍĕ\�� */
                return forword;
            } else if (!BmaUtility.isNullOrEmpty(inRequest.getSearchChange())
                    && BmaUtility.isNullOrEmpty(inRequest.getTempSave()) && BmaUtility.isNullOrEmpty(inRequest.getTempUpdate())) {

                /*�����e���v���[�g�I��*/
                processName = "searchChange";
                log.Start(processName);

                inSession.clearInfo();

                String value = inRequest.getSearchChange();
                if ("�I��".equals(value)) {
                    // ���� �u�K��̑I��
                    inSession.setSknksuKbn("1");
                    // ����
                    inSession.setSknName(BmaConstants.SKN_CHECK);
                    // �u�K��
                    inSession.setKsuName(BmaConstants.KSU_CHECK);
                    /*��ʃ��Z�b�g*/
                    inSession.clearInfo();
                    inSession.clearInfoHairetu();
                } else {
                    inSession.setUpdateFlag("1");
                    inSession.setSrcTempNo(value);
                    // �ڍׂ�������擾���A��ʂɃZ�b�g����
                    setDtlJknList(inSession, value);
                }
                return FWD_NM_RELOAD;
            } else if (!BmaUtility.isNullOrEmpty(inRequest.getTempSave())) {
                /*���������e���v���[�g�ۑ��{�^��������*/
                processName = "tempSave";
                log.Start(processName);

                inSession.setUserId(inRequest.getUserId());

                setValueRequestToSession(inRequest, inSession);

                String SearchChange = inRequest.getSearchChange();

                /*���̓`�F�b�N*/
                boolean retCheck = ValidatorSearch(inRequest, inSession);
                inSession.setSrcTempNo(SearchChange);

                // ��肪�Ȃ���� true
                if (retCheck) {
                    //�̔ԃf�[�^�擾
                    Saiban saiban = new BmaSaibanService(DATA_SOURCE_NAME).
                            getSaibanAndUpdateForKeta(BmaConstants.SAIBAN_HANYOKENSAKUHEDJKN_IDX, inSession.getUserId());
                    String hanyoKensakuIndex = "";
                    if (saiban != null) {
                        hanyoKensakuIndex = saiban.getGenzaiNo();
                    }

                    try {
                        //�g�����U�N�V�����J�n
                        getTransaction();
                        beginTransaction();

                        // �ėp�w�b�_�[�e�[�u���ɓo�^����
                        insertHanyoKensakuHedJkn(inSession, hanyoKensakuIndex);

                        // �ėp�ڍ׃e�[�u���ɓo�^����
                        insertAllDtl(inRequest, inSession, hanyoKensakuIndex);

                        commitTransaction();

                        Messages errors = new Messages();
                        BmaValidator.addMessage(errors, "info", "�ėp�����w�b�_�[,�ڍ׃e�[�u���ɏ�����o�^���܂���", "");
                        inSession.setErrors(errors);

                    } catch (Exception e) {
                        rollbackTransaction();
                        log.info("�ėp�ڍ׃e�[�u�������ŗ�O������", e);
                    }
                }
                /* �������ʈꗗ��ʕ\�� */
                return FWD_NM_RELOAD;

            } else if (!BmaUtility.isNullOrEmpty(inRequest.getTempUpdate())) {
                /*���������e���v���[�g�X�V�{�^��������*/
                processName = "tempSave";
                log.Start(processName);

                inSession.setUserId(inRequest.getUserId());

                String SearchChange = inRequest.getSearchChange();

                setValueRequestToSession(inRequest, inSession);

                inSession.setSrcTempNo(SearchChange);

                inSession.setSrcTempNo(inRequest.getSearchChange());
                /*���̓`�F�b�N*/
                boolean retCheck = ValidatorSearch(inRequest, inSession);

                // ��肪�Ȃ���� true
                if (retCheck) {
                    String hanyoKensakuIndex = inRequest.getSearchChange();

                    try {
                        //�g�����U�N�V�����J�n
                        getTransaction();
                        beginTransaction();

                        // �ėp�ڍ׃e�[�u���ɍX�V����
                        updateAllDtl(inSession, hanyoKensakuIndex);

                        commitTransaction();

                        Messages errors = new Messages();
                        BmaValidator.addMessage(errors, "info", "�ėp�����ڍ׃e�[�u���ɏ������X�V���܂���", "");
                        inSession.setErrors(errors);

                    } catch (Exception e) {
                        rollbackTransaction();
                        log.info("�ėp�ڍ׃e�[�u�������ŗ�O������", e);
                    }
                }
                /* �������ʈꗗ��ʕ\�� */
                return FWD_NM_RELOAD;
            } else {
                /*�ُ�J��*/
                log.IllegalFWD();
                return FWD_NM_SESSION;
            }
        } catch (Exception e) {
            throw e;
        } finally {
            log.End(processName);
        }
    }

    /**
     * �ėp�w�b�_�[�e�[�u���ɓo�^����B
     *
     * @param inSession ���N�G�X�g
     * @param hanyoKensakuIdJkn
     */
    public void insertHanyoKensakuHedJkn(HanyouSearchJoho inSession, String hanyoKensakuIdJkn) {
        String userId = inSession.getUserId();

        SystemTime sysTim = new SystemTime();

        //���[���e���v���[�g�@�I�u�W�F�N�g�쐬
        HanyoKensakuHedJkn kensakuHedJknJoho = new HanyoKensakuHedJkn(DATA_SOURCE_NAME);

        kensakuHedJknJoho.setHanyoKensakuIdJkn(hanyoKensakuIdJkn);

        String tempNoDisp = inSession.getTempletSave();
        kensakuHedJknJoho.setHanyoKensakuName(tempNoDisp);

        //�_���폜�t���O���Z�b�g
        kensakuHedJknJoho.setRonriSakujoFlg(BmaConstants.FLG_OFF);
        //�����敪
        kensakuHedJknJoho.setKoshinKbn(BmaConstants.SHORI_KBN_INSERT);

        //�o�^�����E�o�^��
        kensakuHedJknJoho.setTorokuDate(sysTim.getymd1());
        kensakuHedJknJoho.setTorokuTime(sysTim.gethms1());

        kensakuHedJknJoho.setTorokuUserId(userId);

        //�X�V�����E�X�V��
        kensakuHedJknJoho.setKoshinDate(sysTim.getymd1());
        kensakuHedJknJoho.setKoshinTime(sysTim.gethms1());
        kensakuHedJknJoho.setKoshinUserId(userId);

        //�o�^
        kensakuHedJknJoho.create();
    }

    /**
     * �ėp�ڍ׃e�[�u���ɓo�^����B
     *
     * @param search ���N�G�X�g
     *
     * @return �����ꍇ�Ftrue;���s�Ffalse
     */
    private void insertAllDtl(HanyouSearchJoho inRequest, HanyouSearchJoho search, String hanyoKensakuIndex) {

        int allLineCount = 0;
        if (search.getSknksuKbn().equals(BmaConstants.SKN_KBN) || search.getSknksuKbn().equals(BmaConstants.KSU_KBN)) {
            insertOneLineDtlJkn(search, hanyoKensakuIndex, 1, "SKN_KSU_KBN", 1, search.getSknksuKbn());
        }
        // �����̏ꍇ
        if (!search.getSknName().isEmpty() && search.getSknksuKbn().equals(BmaConstants.SKN_KBN)) {
            String sknksucode = search.getSknName().substring(0, 2);
            String shubetsucode = search.getSknName().substring(2, 4);
            String kaisucode = search.getSknName().substring(4, 6);

            int count = 0;
            count++;
            insertOneLineDtlJkn(search, hanyoKensakuIndex, 2, "SKN_NM", count, sknksucode);

            count++;
            insertOneLineDtlJkn(search, hanyoKensakuIndex, 3, "SKN_NM", count, shubetsucode);

            count++;
            insertOneLineDtlJkn(search, hanyoKensakuIndex, 4, "SKN_NM", count, kaisucode);

        } // �u�K��̏ꍇ
        else if (!search.getKsuName().isEmpty() && search.getSknksuKbn().equals(BmaConstants.KSU_KBN)) {
            String sknksucode = search.getKsuName().substring(0, 2);
            String shubetsucode = search.getKsuName().substring(2, 4);
            String kaisucode = search.getKsuName().substring(4, 6);

            int count = 0;
            count++;
            insertOneLineDtlJkn(search, hanyoKensakuIndex, 5, "KSU_NM", count, sknksucode);

            count++;
            insertOneLineDtlJkn(search, hanyoKensakuIndex, 6, "KSU_NM", count, shubetsucode);

            count++;
            insertOneLineDtlJkn(search, hanyoKensakuIndex, 7, "KSU_NM", count, kaisucode);
        }
        // �N�x
        if (!search.getNendoFrm().isEmpty() && !search.getNendoTo().isEmpty()) {
            int count = 0;
            count++;
            insertOneLineDtlJkn(search, hanyoKensakuIndex, 8, "NENDO_FRM", count, search.getNendoFrm());

            count++;
            insertOneLineDtlJkn(search, hanyoKensakuIndex, 9, "NENDO_TO", count, search.getNendoTo());

        }
        // �t���K�i
        if (!search.getFurigana().isEmpty()) {
            int count = 0;
            count++;
            insertOneLineDtlJkn(search, hanyoKensakuIndex, 10, "FURIGANA", count, search.getFurigana());
        }
        // ���N����
        if (!search.getBirthYear().isEmpty() && !search.getBirthMonth().isEmpty() && !search.getBirthDay().isEmpty()) {
            String birthy = search.getBirthYear() + search.getBirthMonth() + search.getBirthDay();
            int count = 0;
            count++;
            insertOneLineDtlJkn(search, hanyoKensakuIndex, 11, "BIRTHDAY", count, birthy);
        }
        // ����敪
        if (search.getKaiinKbn() != null) {
            int count = 0;
            count++;
            insertOneLineDtlJkn(search, hanyoKensakuIndex, 12, "KAIIN_KBN", count, search.getKaiinKbn());
        }
        // ��ƃR�[�h
        if (!search.getKigyocode().isEmpty()) {
            int count = 0;
            count++;
            insertOneLineDtlJkn(search, hanyoKensakuIndex, 13, "KIGYOCODE", count, search.getKigyocode());
        }
        // �Ζ��於
        if (!search.getKinmusakiName().isEmpty()) {
            int count = 0;
            count++;
            insertOneLineDtlJkn(search, hanyoKensakuIndex, 14, "KINMUSAKI_NAME", count, search.getKinmusakiName());
        }

        // �ԍ��I��
        if (search.getBangoNyuryoku() != null) {
            int count = 0;
            count++;
            insertOneLineDtlJkn(search, hanyoKensakuIndex, 15, "BANGO_NYURYOKU", count, search.getBangoNyuryoku());
        }
        // �ԍ�����

        // ���ۏ�
        List<Option> tmp8 = search.getGohiJokyoKbnList();
        List<String> gohiJokyoKbn = null;
        if (search.getGohiJokyoKbn() != null) {
            gohiJokyoKbn = Arrays.asList(search.getGohiJokyoKbn());
        }
        if (gohiJokyoKbn != null) {
            if (gohiJokyoKbn.size() > 0) {
                allLineCount = 47;
                for (int j = 0; j < tmp8.size(); j++) {
                    allLineCount++;
                    String fromList = tmp8.get(j).getValue();
                    if (gohiJokyoKbn.contains(fromList)) {
                        insertOneLineDtlJkn(search, hanyoKensakuIndex, allLineCount, "GOHI_JOKYO", j + 1, fromList);
                    } else {
                        insertOneLineDtlJkn(search, hanyoKensakuIndex, allLineCount, "GOHI_JOKYO", j + 1, "");
                    }

                }
            }
        }

        // ���i��
        if (!search.getGokakuBiYear().isEmpty() && !search.getGokakuBiMonth().isEmpty() && !search.getGokakuBiDay().isEmpty()) {
            String gokakuBi = search.getGokakuBiYear() + search.getGokakuBiMonth() + search.getGokakuBiDay();
            int count = 0;
            count++;
            insertOneLineDtlJkn(search, hanyoKensakuIndex, 53, "GOKAKU_BI", count, gokakuBi);
        }

        // �L������
        if (!search.getYukoKigenYear().isEmpty() && !search.getYukoKigenMonth().isEmpty() && !search.getYukoKigenDay().isEmpty()) {
            String yukoKigen = search.getYukoKigenYear() + search.getYukoKigenMonth() + search.getYukoKigenDay();
            int count = 0;
            count++;
            insertOneLineDtlJkn(search, hanyoKensakuIndex, 54, "YUKO_KIGEN_SHIKAKU", count, yukoKigen);
        }
        // �ꕔ�Ə�����
        if (!search.getYukoKigenMenjoYear().isEmpty() && !search.getYukoKigenMenjoMonth().isEmpty() && !search.getYukoKigenMenjoDay().isEmpty()) {
            String yukoKigenMenjo = search.getYukoKigenMenjoYear() + search.getYukoKigenMenjoMonth() + search.getYukoKigenMenjoDay();
            int count = 0;
            count++;
            insertOneLineDtlJkn(search, hanyoKensakuIndex, 55, "YUKO_KIGEN_MENJO", count, yukoKigenMenjo);
        }
    }

    /**
     * �ėp�ڍ׃e�[�u���Ɉ�s�f�[�^��o�^����B
     *
     * @param inSession ���N�G�X�g
     * @param hanyoKensakuIdJkn
     * @param meisaiGyoNo
     * @param jokenKomokuId
     * @param jokenGyoNo
     */
    public void insertOneLineDtlJkn(HanyouSearchJoho inSession, String hanyoKensakuIdJkn,
            int meisaiGyoNo, String jokenKomokuId, int jokenGyoNo, String jokenChi) {

        String userId = inSession.getUserId();
        if (userId == null) {
            userId = "";
        }
        SystemTime sysTim = new SystemTime();

        //���[���e���v���[�g�@�I�u�W�F�N�g�쐬
        HanyoKensakuDtlJkn kensakuDtlJknJoho = new HanyoKensakuDtlJkn(DATA_SOURCE_NAME);

        kensakuDtlJknJoho.setHanyoKensakuIdJkn(hanyoKensakuIdJkn);

        kensakuDtlJknJoho.setMeisaiGyoNo(String.valueOf(meisaiGyoNo));
        kensakuDtlJknJoho.setJokenKomokuId(jokenKomokuId);
        kensakuDtlJknJoho.setJokenGyoNo(String.valueOf(jokenGyoNo));
        kensakuDtlJknJoho.setJokenChi(jokenChi);

        //�_���폜�t���O���Z�b�g
        kensakuDtlJknJoho.setRonriSakujoFlg(BmaConstants.FLG_OFF);
        //�����敪
        kensakuDtlJknJoho.setKoshinKbn(BmaConstants.SHORI_KBN_INSERT);

        //�o�^�����E�o�^��
        kensakuDtlJknJoho.setTorokuDate(sysTim.getymd1());
        kensakuDtlJknJoho.setTorokuTime(sysTim.gethms1());

        kensakuDtlJknJoho.setTorokuUserId(userId);

        //�X�V�����E�X�V��
        kensakuDtlJknJoho.setKoshinDate(sysTim.getymd1());
        kensakuDtlJknJoho.setKoshinTime(sysTim.gethms1());
        kensakuDtlJknJoho.setKoshinUserId(userId);

        //�o�^
        kensakuDtlJknJoho.create();
    }

    /**
     * �ėp�ڍ׃e�[�u���ɓo�^����B
     *
     * @param search ���N�G�X�g
     *
     * @return �����ꍇ�Ftrue;���s�Ffalse
     */
    private void updateAllDtl(HanyouSearchJoho search, String hanyoKensakuIndex) throws Exception {

        int allLineCount = 1;
        try {
            if (search.getSknksuKbn().equals(BmaConstants.SKN_KBN) || search.getSknksuKbn().equals(BmaConstants.KSU_KBN)) {
                updateOneLineDtlJkn(search, hanyoKensakuIndex, 1, "SKN_KSU_KBN", 1, search.getSknksuKbn());
            }
            // �����̏ꍇ
            if (!search.getSknName().isEmpty() && search.getSknksuKbn().equals(BmaConstants.SKN_KBN)) {
                String sknksucode = search.getSknName().substring(0, 2);
                String shubetsucode = search.getSknName().substring(2, 4);
                String kaisucode = search.getSknName().substring(4, 6);

                int count = 0;
                count++;
                updateOneLineDtlJkn(search, hanyoKensakuIndex, 2, "SKN_NM", count, sknksucode);

                count++;
                updateOneLineDtlJkn(search, hanyoKensakuIndex, 3, "SKN_NM", count, shubetsucode);

                count++;
                updateOneLineDtlJkn(search, hanyoKensakuIndex, 4, "SKN_NM", count, kaisucode);

            } // �u�K��̏ꍇ
            else if (!search.getKsuName().isEmpty() && search.getSknksuKbn().equals(BmaConstants.KSU_KBN)) {
                String sknksucode = search.getKsuName().substring(0, 2);
                String shubetsucode = search.getKsuName().substring(2, 4);
                String kaisucode = search.getKsuName().substring(4, 6);

                int count = 0;
                count++;
                updateOneLineDtlJkn(search, hanyoKensakuIndex, 5, "KSU_NM", count, sknksucode);

                count++;
                updateOneLineDtlJkn(search, hanyoKensakuIndex, 6, "KSU_NM", count, shubetsucode);

                count++;
                updateOneLineDtlJkn(search, hanyoKensakuIndex, 7, "KSU_NM", count, kaisucode);
            }
            // �N�x
            if (!search.getNendoFrm().isEmpty() && !search.getNendoTo().isEmpty()) {
                int count = 0;
                count++;
                updateOneLineDtlJkn(search, hanyoKensakuIndex, 8, "NENDO_FRM", count, search.getNendoFrm());

                count++;
                updateOneLineDtlJkn(search, hanyoKensakuIndex, 9, "NENDO_TO", count, search.getNendoTo());

            }
            // �t���K�i
            if (!search.getFurigana().isEmpty()) {
                int count = 0;

                count++;
                updateOneLineDtlJkn(search, hanyoKensakuIndex, 10, "FURIGANA", count, search.getFurigana());
            }
            // ���N����
            if (!search.getBirthYear().isEmpty() && !search.getBirthMonth().isEmpty() && !search.getBirthDay().isEmpty()) {
                String birthy = search.getBirthYear() + search.getBirthMonth() + search.getBirthDay();
                int count = 0;
                count++;
                updateOneLineDtlJkn(search, hanyoKensakuIndex, 11, "BIRTHDAY", count, birthy);
            }
            // ����敪
            if (search.getKaiinKbn() != null) {
                int count = 0;

                count++;
                updateOneLineDtlJkn(search, hanyoKensakuIndex, 12, "KAIIN_KBN", count, search.getKaiinKbn());
            }
            // ��ƃR�[�h
            if (!search.getKigyocode().isEmpty()) {
                int count = 0;
                count++;
                updateOneLineDtlJkn(search, hanyoKensakuIndex, 13, "KIGYOCODE", count, search.getKigyocode());
            }
            // �Ζ��於
            if (!search.getKinmusakiName().isEmpty()) {
                int count = 0;
                count++;
                updateOneLineDtlJkn(search, hanyoKensakuIndex, 14, "KINMUSAKI_NAME", count, search.getKinmusakiName());
            }

            // �ԍ��I��
            if (search.getBangoNyuryoku() != null) {
                int count = 0;

                count++;
                updateOneLineDtlJkn(search, hanyoKensakuIndex, 15, "BANGO_NYURYOKU", count, search.getBangoNyuryoku());
            }
            // �ԍ�����

            // ���ۏ�
            List<Option> tmp8 = search.getGohiJokyoKbnList();
            List<String> gohiJokyoKbn = null;
            if (search.getGohiJokyoKbn() != null) {
                gohiJokyoKbn = Arrays.asList(search.getGohiJokyoKbn());
            }
            if (gohiJokyoKbn != null) {
                if (gohiJokyoKbn.size() > 0) {
                    allLineCount = 47;
                    for (int j = 0; j < tmp8.size(); j++) {
                        allLineCount++;
                        String fromList = tmp8.get(j).getValue();
                        if (gohiJokyoKbn.contains(fromList)) {
                            updateOneLineDtlJkn(search, hanyoKensakuIndex, allLineCount, "GOHI_JOKYO", j + 1, fromList);
                        } else {
                            updateOneLineDtlJkn(search, hanyoKensakuIndex, allLineCount, "GOHI_JOKYO", j + 1, "");
                        }

                    }
                }
            }

            // ���i��
            if (!search.getGokakuBiYear().isEmpty() && !search.getGokakuBiMonth().isEmpty() && !search.getGokakuBiDay().isEmpty()) {
                String gokakuBi = search.getGokakuBiYear() + search.getGokakuBiMonth() + search.getGokakuBiDay();
                int count = 0;
                count++;
                updateOneLineDtlJkn(search, hanyoKensakuIndex, 53, "GOKAKU_BI", count, gokakuBi);
            }

            // �L������
            if (!search.getYukoKigenYear().isEmpty() && !search.getYukoKigenMonth().isEmpty() && !search.getYukoKigenDay().isEmpty()) {
                String yukoKigen = search.getYukoKigenYear() + search.getYukoKigenMonth() + search.getYukoKigenDay();
                int count = 0;
                count++;
                updateOneLineDtlJkn(search, hanyoKensakuIndex, 54, "YUKO_KIGEN_SHIKAKU", count, yukoKigen);
            }
            // �ꕔ�Ə�����
            if (!search.getYukoKigenMenjoYear().isEmpty() && !search.getYukoKigenMenjoMonth().isEmpty() && !search.getYukoKigenMenjoDay().isEmpty()) {
                String yukoKigenMenjo = search.getYukoKigenMenjoYear() + search.getYukoKigenMenjoMonth() + search.getYukoKigenMenjoDay();
                int count = 0;
                count++;
                updateOneLineDtlJkn(search, hanyoKensakuIndex, 55, "YUKO_KIGEN_MENJO", count, yukoKigenMenjo);
            }

        } catch (Exception ex) {
            throw ex;
        }
    }

    /**
     * �ėp�ڍ׃e�[�u���Ɉ�s�f�[�^���X�V����B
     *
     * @param inSession ���N�G�X�g
     * @param hanyoKensakuIdJkn
     * @param meisaiGyoNo
     * @param jokenKomokuId
     * @param jokenGyoNo
     * @return �����ꍇ�Ftrue;���s�Ffalse
     */
    public void updateOneLineDtlJkn(HanyouSearchJoho inSession, String hanyoKensakuIdJkn,
            int meisaiGyoNo, String jokenKomokuId, int jokenGyoNo, String jokenChi) throws IllegalAccessException, InvocationTargetException {

        String userId = inSession.getUserId();
        if (userId == null) {
            userId = "";
        }
        SystemTime sysTim = new SystemTime();
        try {
            //���[���e���v���[�g�@�I�u�W�F�N�g�쐬
            HanyoKensakuDtlJkn kensakuDtl = new HanyoKensakuDtlJkn(DATA_SOURCE_NAME);
            /* �X�V�ł���f�[�^�擾 */
            HanyoKensakuDtlJkn kensakuDtlJknJohoMoto = kensakuDtl.find(hanyoKensakuIdJkn, String.valueOf(meisaiGyoNo));
            if (kensakuDtlJknJohoMoto == null) {
                insertOneLineDtlJkn(inSession, hanyoKensakuIdJkn, meisaiGyoNo, jokenKomokuId, jokenGyoNo, jokenChi);
            } else {
                HanyoKensakuDtlJkn kensakuDtlJknJoho = new HanyoKensakuDtlJkn(DATA_SOURCE_NAME);
                /* ���݂̂ݍX�V���� */
                // �o�^�҂��X�V����
                BeanUtils.copyProperties(kensakuDtlJknJoho, kensakuDtlJknJohoMoto);

                kensakuDtlJknJoho.setHanyoKensakuIdJkn(hanyoKensakuIdJkn);

                kensakuDtlJknJoho.setJokenKomokuId(jokenKomokuId);
                kensakuDtlJknJoho.setJokenGyoNo(String.valueOf(jokenGyoNo));
                kensakuDtlJknJoho.setJokenChi(jokenChi);

                //�_���폜�t���O���Z�b�g
                kensakuDtlJknJoho.setRonriSakujoFlg(BmaConstants.FLG_OFF);
                //�����敪
                kensakuDtlJknJoho.setKoshinKbn(BmaConstants.SHORI_KBN_UPDATE);

                //�X�V�����E�X�V��
                kensakuDtlJknJoho.setKoshinDate(sysTim.getymd1());
                kensakuDtlJknJoho.setKoshinTime(sysTim.gethms1());
                kensakuDtlJknJoho.setKoshinUserId(userId);

                // �X�V
                kensakuDtlJknJoho.update();

            }
        } catch (InvocationTargetException ex) {
            throw ex;
        }

    }

    /**
     * �w��y�[�W���ɍ��킹�āA�\�������ꃊ�X�g���쐬
     *
     * @param inSession�@�Z�b�V�������X�g
     */
    public void setDisplayList(HanyouSearchJoho inSession) {
        /* �ϐ������� */
        List<HanyouSearchJoho> displayList = new ArrayList<>();
        HanyouSearchJoho kaijo;

        List<HanyouSearchJoho> resultList = inSession.getHanyouAllList();
        /* �y�[�W���ɍ��킹�ĕ\���p���X�g�쐬 */
        for (int i = inSession.getFirstDisp() - 1; i < inSession.getMaxDisp(); ++i) {
            kaijo = resultList.get(i);
            displayList.add(kaijo);
        }
        inSession.setHanyouDetailList(displayList);
    }

    /**
     * �y�[�W����
     *
     * @param inSession�@�Z�b�V�������X�g
     */
    public void setPage(HanyouSearchJoho inSession) {
        /* �ϐ������� */
        int idx;
        int max;
        int maxLenDisp = inSession.getHanyouAllList().size();
        int pageMax;

        /* ��ʂɕ\������ő匏�����擾 */
        int page = inSession.getPage();
        idx = page * BmaConstants.MAX_PAGE_NUM_HANYO_SEARCH;

        max = idx + BmaConstants.MAX_PAGE_NUM_HANYO_SEARCH;
        inSession.setFirstDisp(idx + 1);

        /* �������ʂ̌��� */
        if (maxLenDisp < max) {
            inSession.setMaxDisp(maxLenDisp);
        } else {
            /* �ő匏����茟�����ʂ������ꍇ */
            inSession.setMaxDisp(max);
        }

        /* �y�[�W�ԍ��̍ő���v�Z */
        pageMax = (int) (Math.ceil((double) maxLenDisp / (double) (BmaConstants.MAX_PAGE_NUM_HANYO_SEARCH)));
        inSession.setPageMax(pageMax + 1);

        /* �y�[�W�ԍ��ݒ� */
        int now = 0;
        now = inSession.getPage();

        /* �Œጏ�� */
        if (now == 0) {
            inSession.setPageBegin(now + 1);
        } else if (now == 1) {
            inSession.setPageBegin(now);
        } else if (now == 2) {
            inSession.setPageBegin(now - 1);
        } else {
            inSession.setPageBegin(now - 2);
        }
        /* �ő匏�����\������ő匏����3�{�ȉ��������ꍇ�̕\���p�y�[�W�ԍ� */
        if (now == pageMax) {
            inSession.setPageEnd(now + 1);
        } else if (now == pageMax - 1) {
            inSession.setPageEnd(now + 2);
        } else if (now == pageMax - 2) {
            inSession.setPageEnd(now + 3);
        } else {
            inSession.setPageEnd(now + 4);
        }
        inSession.setPage(now + 1);
    }

    /**
     * �������������Z�b�g����B
     *
     * @param inSession �Z�b�V����RTO
     */
    private void clearSearchInput(HanyouSearchJoho inSession) {
        inSession.setPage(0);
        inSession.setPageMax(0);
        inSession.setFirstDisp(0);
        inSession.setMaxDisp(0);
        inSession.setSearchOutIndex(null);

        inSession.setDispKeyList(null);

        inSession.setErrors(new Messages());
    }

    /**
     * ���̓f�[�^���Z�b�V�����f�[�^�ɃZ�b�g����B
     *
     * @param inRequest ���N�G�X�g��̓��̓f�[�^
     * @param inSession �Z�b�V������̓��̓f�[�^
     */
    private void setValueRequestToTaihi(HanyouSearchJoho inRequest, HanyouSearchJoho inSession, HanyouSearchJoho taihi) {
        taihi.setSknksuKbn(inRequest.getSknksuKbn());

        taihi.setSknName(inRequest.getSknName());
        taihi.setKsuName(inRequest.getKsuName());

        taihi.setNendoFrm(inRequest.getNendoFrm());
        taihi.setNendoTo(inRequest.getNendoTo());

        taihi.setFurigana(inRequest.getFurigana());
        taihi.setBirthYear(inRequest.getBirthYear());
        taihi.setBirthMonth(inRequest.getBirthMonth());
        taihi.setBirthDay(inRequest.getBirthDay());

        taihi.setKaiinKbn(inRequest.getKaiinKbn());
        taihi.setKigyocode(inRequest.getKigyocode());
        taihi.setKinmusakiName(inRequest.getKinmusakiName());
        taihi.setBangoNyuryoku(inRequest.getBangoNyuryoku());
        taihi.setBangoInput(inRequest.getBangoInput());

        taihi.setSrcTempNo(inRequest.getSearchChange());
        taihi.setSearchChange(inRequest.getSearchChange());

        taihi.setKariuketsukeBiFromYear(inRequest.getKariuketsukeBiFromYear());
        taihi.setKariuketsukeBiFromMonth(inRequest.getKariuketsukeBiFromMonth());
        taihi.setKariuketsukeBiFromDay(inRequest.getKariuketsukeBiFromDay());

        taihi.setKariuketsukeBiToYear(inRequest.getKariuketsukeBiToYear());
        taihi.setKariuketsukeBiToMonth(inRequest.getKariuketsukeBiToMonth());
        taihi.setKariuketsukeBiToDay(inRequest.getKariuketsukeBiToDay());

        taihi.setMoshikomikanryoBiFromYear(inRequest.getMoshikomikanryoBiFromYear());
        taihi.setMoshikomikanryoBiFromMonth(inRequest.getMoshikomikanryoBiFromMonth());
        taihi.setMoshikomikanryoBiFromDay(inRequest.getMoshikomikanryoBiFromDay());

        taihi.setMoshikomikanryoBiToYear(inRequest.getMoshikomikanryoBiToYear());
        taihi.setMoshikomikanryoBiToMonth(inRequest.getMoshikomikanryoBiToMonth());
        taihi.setMoshikomikanryoBiToDay(inRequest.getMoshikomikanryoBiToDay());

        taihi.setTempletSave(inRequest.getTempletSave());

        // ���ۏ�
        String strGohiJokyoKbn[] = new String[4];
        List<Option> tmp8 = inSession.getGohiJokyoKbnList();
        List<String> gohiJokyoKbn = null;
        if (inRequest.getGohiJokyoKbn() != null) {
            gohiJokyoKbn = Arrays.asList(inRequest.getGohiJokyoKbn());
        }
        if (gohiJokyoKbn != null) {
            if (gohiJokyoKbn.size() > 0) {
                for (int j = 0; j < tmp8.size(); j++) {

                    String fromList = tmp8.get(j).getValue();
                    if (gohiJokyoKbn.contains(fromList)) {
                        strGohiJokyoKbn[j] = fromList;
                    } else {
                        strGohiJokyoKbn[j] = "";
                    }
                }
            }
        }

        // ���i�N����
        taihi.setGokakuBiYear(inRequest.getGokakuBiYear());
        taihi.setGokakuBiMonth(inRequest.getGokakuBiMonth());
        taihi.setGokakuBiDay(inRequest.getGokakuBiDay());

        // �L������
        taihi.setYukoKigenYear(inRequest.getYukoKigenYear());
        taihi.setYukoKigenMonth(inRequest.getYukoKigenMonth());
        taihi.setYukoKigenDay(inRequest.getYukoKigenDay());

        // �ꕔ�Ə�����
        taihi.setYukoKigenMenjoYear(inRequest.getYukoKigenMenjoYear());
        taihi.setYukoKigenMenjoMonth(inRequest.getYukoKigenMenjoMonth());
        taihi.setYukoKigenMenjoDay(inRequest.getYukoKigenMenjoDay());

        taihi.setGohiJokyoKbn(strGohiJokyoKbn);
    }

    /**
     * ���̓f�[�^���Z�b�V�����f�[�^�ɃZ�b�g����B
     *
     * @param inRequest ���N�G�X�g��̓��̓f�[�^
     * @param inSession �Z�b�V������̓��̓f�[�^
     */
    private void setValueRequestToSession(HanyouSearchJoho inRequest, HanyouSearchJoho inSession) {
        inSession.setSknksuKbn(inRequest.getSknksuKbn());

        inSession.setKaiinKbn(inRequest.getKaiinKbn());
        inSession.setSknName(inRequest.getSknName());
        inSession.setKsuName(inRequest.getKsuName());

        inSession.setNendoFrm(inRequest.getNendoFrm());
        inSession.setNendoTo(inRequest.getNendoTo());

        inSession.setFurigana(inRequest.getFurigana());
        inSession.setBirthYear(inRequest.getBirthYear());
        inSession.setBirthMonth(inRequest.getBirthMonth());
        inSession.setBirthDay(inRequest.getBirthDay());

        inSession.setKaiinKbn(inRequest.getKaiinKbn());
        inSession.setKigyocode(inRequest.getKigyocode());
        inSession.setKinmusakiName(inRequest.getKinmusakiName());
        inSession.setBangoNyuryoku(inRequest.getBangoNyuryoku());
        inSession.setBangoInput(inRequest.getBangoInput());

        inSession.setSrcTempNo(inRequest.getSearchChange());
        inSession.setSearchChange(inRequest.getSearchChange());

        inSession.setKariuketsukeBiFromYear(inRequest.getKariuketsukeBiFromYear());
        inSession.setKariuketsukeBiFromMonth(inRequest.getKariuketsukeBiFromMonth());
        inSession.setKariuketsukeBiFromDay(inRequest.getKariuketsukeBiFromDay());

        inSession.setKariuketsukeBiToYear(inRequest.getKariuketsukeBiToYear());
        inSession.setKariuketsukeBiToMonth(inRequest.getKariuketsukeBiToMonth());
        inSession.setKariuketsukeBiToDay(inRequest.getKariuketsukeBiToDay());

        inSession.setMoshikomikanryoBiFromYear(inRequest.getMoshikomikanryoBiFromYear());
        inSession.setMoshikomikanryoBiFromMonth(inRequest.getMoshikomikanryoBiFromMonth());
        inSession.setMoshikomikanryoBiFromDay(inRequest.getMoshikomikanryoBiFromDay());

        inSession.setMoshikomikanryoBiToYear(inRequest.getMoshikomikanryoBiToYear());
        inSession.setMoshikomikanryoBiToMonth(inRequest.getMoshikomikanryoBiToMonth());
        inSession.setMoshikomikanryoBiToDay(inRequest.getMoshikomikanryoBiToDay());

        inSession.setTempletSave(inRequest.getTempletSave());

        // ���ۏ�
        String strGohiJokyoKbn[] = new String[4];
        List<Option> tmp8 = inSession.getGohiJokyoKbnList();
        List<String> gohiJokyoKbn = null;
        if (inRequest.getGohiJokyoKbn() != null) {
            gohiJokyoKbn = Arrays.asList(inRequest.getGohiJokyoKbn());
        }
        if (gohiJokyoKbn != null) {
            if (gohiJokyoKbn.size() > 0) {
                for (int j = 0; j < tmp8.size(); j++) {

                    String fromList = tmp8.get(j).getValue();
                    if (gohiJokyoKbn.contains(fromList)) {
                        strGohiJokyoKbn[j] = fromList;
                    } else {
                        strGohiJokyoKbn[j] = "";
                    }
                }
            }
        }

        // ���i�N����
        inSession.setGokakuBiYear(inRequest.getGokakuBiYear());
        inSession.setGokakuBiMonth(inRequest.getGokakuBiMonth());
        inSession.setGokakuBiDay(inRequest.getGokakuBiDay());

        // �L������
        inSession.setYukoKigenYear(inRequest.getYukoKigenYear());
        inSession.setYukoKigenMonth(inRequest.getYukoKigenMonth());
        inSession.setYukoKigenDay(inRequest.getYukoKigenDay());

        // �ꕔ�Ə�����
        inSession.setYukoKigenMenjoYear(inRequest.getYukoKigenMenjoYear());
        inSession.setYukoKigenMenjoMonth(inRequest.getYukoKigenMenjoMonth());
        inSession.setYukoKigenMenjoDay(inRequest.getYukoKigenMenjoDay());

        inSession.setGohiJokyoKbn(strGohiJokyoKbn);
    }

    /**
     * ���̓`�F�b�N(����)
     *
     * @param inRequest
     * @return ��肪�Ȃ���� true�A����� false
     */
    private boolean ValidatorSearch(HanyouSearchJoho inRequest, HanyouSearchJoho inSession) throws Exception {
        String groupCode = "";
        String itemName = "";

        //�t���K�i�̑S�p�ϊ����s
        inSession.setFurigana(BmaStringUtility.convertHankakuToZenkakuBma(inSession.getFurigana()));
        inSession.setKinmusakiName(BmaStringUtility.convertHankakuToZenkakuBma(inSession.getKinmusakiName()));

        inRequest.setFurigana(BmaStringUtility.convertHankakuToZenkakuBma(inSession.getFurigana()));
        inRequest.setKinmusakiName(BmaStringUtility.convertHankakuToZenkakuBma(inSession.getKinmusakiName()));

        //���b�Z�[�W�i�[�p
        Messages errors = new Messages();

        String sknksuKbn = inRequest.getSknksuKbn();
        if (sknksuKbn == null) {
            sknksuKbn = "";
        }
        String sknksuName = (sknksuKbn.equals(BmaConstants.SKN_KBN))
                ? inRequest.getSknName() : inRequest.getKsuName();

        String nendoFrm = inRequest.getNendoFrm();
        String nendoTo = inRequest.getNendoTo();

        groupCode = "";
        itemName = "����/�u�K��";
        // ����/�u�K��F�K�{�`�F�b�N
        BmaValidator.validateSelect(sknksuKbn, errors, groupCode, itemName);
        // ����/�u�K��F�����`�F�b�N
        Validator.validateMaxLength(sknksuKbn, 1, errors, groupCode, itemName);

        groupCode = "sknksuName";
        itemName = "����/�u�K�";
        // ����/�u�K��F�K�{�`�F�b�N
        BmaValidator.validateSelect(sknksuName, errors, groupCode, itemName);

        // ����/�u�K��F�����`�F�b�N
        Validator.validateMaxLength(sknksuName, 6, errors, groupCode, itemName);

        groupCode = "nendoFrm";
        itemName = "�N�xFROM��";
        // �N�xFROM�F�����`�F�b�N
        BmaValidator.validateNumber(nendoFrm, errors, groupCode, itemName);
        // �N�x�F�����`�F�b�N
        Validator.validateMaxLength(nendoFrm, 4, errors, groupCode, itemName);

        groupCode = "nendoTo";
        itemName = "�N�xTO��";
        // �N�xFROM�F�����`�F�b�N
        BmaValidator.validateNumber(nendoTo, errors, groupCode, itemName);
        // �N�x�F�����`�F�b�N
        Validator.validateMaxLength(nendoTo, 4, errors, groupCode, itemName);

        // �t���K�i�F�����`�F�b�N
        groupCode = "furigana";
        itemName = "�t���K�i";

        //BmaValidator.validateKatakana(furigana, errors, groupCode, itemName);
        if (BmaValidator.validateMessageCheck(errors, itemName)) {
            // �t���K�i�F�����`�F�b�N
            Validator.validateMaxLength(inSession.getFurigana(), 200, errors, groupCode, itemName);
        }

        /*���N����*/
        groupCode = "birthYear";
        /*�N*/
        itemName = "���N�����̔N";
        BmaValidator.validatePermissionSelect(inSession.getBirthYear(), inSession.getBirthYearList(), errors, groupCode, itemName);
        /*��*/
        itemName = "���N�����̌�";
        BmaValidator.validatePermissionSelect(inSession.getBirthMonth(), inSession.getBirthMonthList(), errors, groupCode, itemName);

        /*��*/
        itemName = "���N�����̓�";
        BmaValidator.validatePermissionSelect(inSession.getBirthDay(), inSession.getBirthDayList(), errors, groupCode, itemName);
        /*���N����*/
        itemName = "���N����";
        if (!BmaUtility.isNullOrEmpty(inSession.getBirthDay())
                && !BmaUtility.isNullOrEmpty(inSession.getBirthMonth())
                && !BmaUtility.isNullOrEmpty(inSession.getBirthYear())) {
            /*�N�������I������Ă���Ƃ����ݓ��`�F�b�N*/
            String strBirthDay = inSession.getBirthYear() + inSession.getBirthMonth() + inSession.getBirthDay();
            if (BmaValidator.validateDate(strBirthDay, errors, groupCode, itemName)) {
                inSession.setBirthYear(strBirthDay.substring(0, 4));
                inSession.setBirthMonth(strBirthDay.substring(4, 6));
                inSession.setBirthDay(strBirthDay.substring(6, 8));
            }
        }

        /*���*/
        groupCode = "kaiinKbn";
        itemName = "���";
        //BmaValidator.validatePermissionSelect(inSession.getKaiinKbn(), inSession.getKaiinKbnList(), errors, groupCode, itemName);

        /*��ƃR�[�h*/
        groupCode = "kigyocode";
        itemName = "��ƃR�[�h";
        // ��ƃR�[�h�F�����`�F�b�N
        BmaValidator.validateNumber(inSession.getKigyocode(), errors, groupCode, itemName);
        Validator.validateMaxLength(inSession.getKigyocode(), 10, errors, groupCode, itemName);
        if (!inSession.getKigyocode().isEmpty() && inSession.getKigyocode().length() != 10) {
            BmaValidator.addMessage(errors, groupCode, itemName + "���P�O�����œ��͂��Ă��������B", "");
        }

        // �Ζ��於�̃`�F�b�N
        groupCode = "KinmusakiName";
        itemName = "�Ζ��於";
        BmaValidator.validateMojiCode3(inSession.getKinmusakiName(), errors, groupCode, itemName);
        BmaValidator.validateMaxLength(inSession.getKinmusakiName(), 200, errors, groupCode, itemName);

        /*�ԍ��I��*/
        groupCode = "bangoNyuryoku";
        itemName = "�ԍ��I��";
        //BmaValidator.validateSelect(inSession.getBangoNyuryoku(), errors, groupCode, itemName);
        BmaValidator.validatePermissionSelect(inSession.getBangoNyuryoku(), inSession.getBangoNyuryokuList(), errors, groupCode, itemName);

        if ("����".equals(inRequest.getHanyouSearchWhe())) {
            // �ԍ��I�� �ԍ�����
            if (inSession.getBangoNyuryoku() != null) {
                groupCode = "";
                itemName = "�ԍ����̗͂�";
                BmaValidator.validateRequired(inSession.getBangoInput(), errors, groupCode, itemName);
                BmaValidator.validateMaxLength(inSession.getBangoInput(), 20, errors, groupCode, itemName);
            }
        }

        if (inSession.getGohiJokyoKbn() != null) {
            /*���ۏ�*/
            groupCode = "gohiJokyoKbn";
            itemName = "���ۏ�";
            for (String komiKbn : inSession.getGohiJokyoKbn()) {
                BmaValidator.validatePermissionSelect(komiKbn, inSession.getGohiJokyoKbnList(), errors, groupCode, itemName);
                Validator.validateMaxLength(komiKbn, 2, errors, groupCode, itemName);
                break;
            }
        }

        /*���i�N����*/
        groupCode = "";
        /*�N*/
        itemName = "���i�N�����̔N";
        BmaValidator.validatePermissionSelect(inSession.getGokakuBiYear(), inSession.getYearList(), errors, groupCode, itemName);
        /*��*/
        itemName = "���i�N�����̌�";
        BmaValidator.validatePermissionSelect(inSession.getGokakuBiMonth(), inSession.getMonthList(), errors, groupCode, itemName);
        /*��*/
        itemName = "���i�N�����̓�";
        BmaValidator.validatePermissionSelect(inSession.getGokakuBiDay(), inSession.getDayList(), errors, groupCode, itemName);
        /*���i�N����*/
        itemName = "���i�N����";
        if (!BmaUtility.isNullOrEmpty(inSession.getGokakuBiDay())
                && !BmaUtility.isNullOrEmpty(inSession.getGokakuBiMonth())
                && !BmaUtility.isNullOrEmpty(inSession.getGokakuBiYear())) {
            /*�N�������I������Ă���Ƃ����ݓ��`�F�b�N*/
            String strGokakuBiDay = inSession.getGokakuBiYear() + inSession.getGokakuBiMonth() + inSession.getGokakuBiDay();
            if (BmaValidator.validateDate(strGokakuBiDay, errors, groupCode, itemName)) {
                inSession.setGokakuBiYear(strGokakuBiDay.substring(0, 4));
                inSession.setGokakuBiMonth(strGokakuBiDay.substring(4, 6));
                inSession.setGokakuBiDay(strGokakuBiDay.substring(6, 8));
            }
        }
        /*�L������*/
        groupCode = "";
        /*�N*/
        itemName = "�L�������̔N";
        BmaValidator.validatePermissionSelect(inSession.getYukoKigenYear(), inSession.getYearList(), errors, groupCode, itemName);
        /*��*/
        itemName = "�L�������̌�";
        BmaValidator.validatePermissionSelect(inSession.getYukoKigenMonth(), inSession.getMonthList(), errors, groupCode, itemName);

        /*��*/
        itemName = "�L�������̓�";
        BmaValidator.validatePermissionSelect(inSession.getYukoKigenDay(), inSession.getDayList(), errors, groupCode, itemName);
        /*�L������*/
        itemName = "�L������";
        if (!BmaUtility.isNullOrEmpty(inSession.getYukoKigenDay())
                && !BmaUtility.isNullOrEmpty(inSession.getYukoKigenMonth())
                && !BmaUtility.isNullOrEmpty(inSession.getYukoKigenYear())) {
            /*�N�������I������Ă���Ƃ����ݓ��`�F�b�N*/
            String strYukoKigenDay = inSession.getYukoKigenYear() + inSession.getYukoKigenMonth() + inSession.getYukoKigenDay();
            if (BmaValidator.validateDate(strYukoKigenDay, errors, groupCode, itemName)) {
                inSession.setYukoKigenYear(strYukoKigenDay.substring(0, 4));
                inSession.setYukoKigenMonth(strYukoKigenDay.substring(4, 6));
                inSession.setYukoKigenDay(strYukoKigenDay.substring(6, 8));
            }
        }

        /*�ꕔ�Ə�����*/
        groupCode = "";
        /*�N*/
        itemName = "�ꕔ�Ə������̔N";
        BmaValidator.validatePermissionSelect(inSession.getYukoKigenMenjoYear(), inSession.getYearList(), errors, groupCode, itemName);
        /*��*/
        itemName = "�ꕔ�Ə������̌�";
        BmaValidator.validatePermissionSelect(inSession.getYukoKigenMenjoMonth(), inSession.getMonthList(), errors, groupCode, itemName);

        /*��*/
        itemName = "�ꕔ�Ə������̓�";
        BmaValidator.validatePermissionSelect(inSession.getYukoKigenMenjoDay(), inSession.getDayList(), errors, groupCode, itemName);
        /*�ꕔ�Ə�����*/
        itemName = "�ꕔ�Ə�����";
        if (!BmaUtility.isNullOrEmpty(inSession.getYukoKigenMenjoDay())
                && !BmaUtility.isNullOrEmpty(inSession.getYukoKigenMenjoMonth())
                && !BmaUtility.isNullOrEmpty(inSession.getYukoKigenMenjoYear())) {
            /*�N�������I������Ă���Ƃ����ݓ��`�F�b�N*/
            String strYukoKigenMenjoDay = inSession.getYukoKigenMenjoYear() + inSession.getYukoKigenMenjoMonth() + inSession.getYukoKigenMenjoDay();
            if (BmaValidator.validateDate(strYukoKigenMenjoDay, errors, groupCode, itemName)) {
                inSession.setYukoKigenMenjoYear(strYukoKigenMenjoDay.substring(0, 4));
                inSession.setYukoKigenMenjoMonth(strYukoKigenMenjoDay.substring(4, 6));
                inSession.setYukoKigenMenjoDay(strYukoKigenMenjoDay.substring(6, 8));
            }
        }

        if ("���������ۑ�".equals(inRequest.getTempSave())) {
            groupCode = "";
            itemName = "���������e���v���[�g�V�K�ۑ���";
            BmaValidator.validateRequired(inSession.getTempletSave(), errors, groupCode, itemName);
            Validator.validateMaxLength(inSession.getTempletSave(), 100, errors, groupCode, itemName);
        }

        if ("���������X�V".equals(inRequest.getTempUpdate())) {
            groupCode = "";
            itemName = "�����e���v���[�g";
            if (GenericValidator.isBlankOrNull(inRequest.getSearchChange()) || "�I��".equals(inRequest.getSearchChange())) {
                BmaValidator.addMessage(errors, "info", "�����e���v���[�g��I�����Ă��������B", "");
            }
            Validator.validateMaxLength(inRequest.getSearchChange(), 5, errors, groupCode, itemName);
        }

        if (!errors.isEmpty()) {
            inSession.setErrors(errors);
            return false;
        } else {
            return true;
        }
    }

    /**
     * ���̃��X�g���擾����
     *
     * @param groupCode
     * @return
     */
    public List<Option> findMeishoList(String groupCode) {
        List<Option> list = new ArrayList<>();
        //���̃��X�g��p�ӂ���
        MeishoKanri meishoKanri = new MeishoKanri(BmaConstants.DS_REGISTRANT);
        meishoKanri.findByGroupCode(groupCode, list);
        return list;
    }

    /**
     * �ڍׂ�������擾���A��ʂɃZ�b�g����
     *
     * @param groupCode
     * @return
     */
    private void setDtlJknList(HanyouSearchJoho inSession, String value) {

        HanyoKensakuDtlJkn hanyoKensakuDtlJkn = new HanyoKensakuDtlJkn(BmaConstants.DS_REGISTRANT);

        List<HanyouSearchJoho> dtlJknList = hanyoKensakuDtlJkn.findByKensakuId(value);
        String sknKsuKbnJokenChi = "";
        // ����
        String sknNmJokenChi = "";
        // �u�K��
        String ksuNmJokenChi = "";

        String strGohiJokyoKbn[] = new String[4];

        for (int i = 0; i < dtlJknList.size(); ++i) {
            HanyouSearchJoho oneLine = dtlJknList.get(i);

            String jokenKomokuId = oneLine.getJokenKomokuId();
            switch (jokenKomokuId) {
                case "SKN_KSU_KBN":
                    sknKsuKbnJokenChi = sknKsuKbnJokenChi + oneLine.getJokenChi();
                    break;
                case "SKN_NM":
                    sknNmJokenChi = sknNmJokenChi + oneLine.getJokenChi();
                    break;
                case "KSU_NM":
                    ksuNmJokenChi = ksuNmJokenChi + oneLine.getJokenChi();
                    break;
                case "NENDO_FRM":
                    inSession.setNendoFrm(oneLine.getJokenChi());
                    break;
                case "NENDO_TO":
                    inSession.setNendoTo(oneLine.getJokenChi());
                    break;
                case "FURIGANA":
                    inSession.setFurigana(oneLine.getJokenChi());
                    break;
                case "BIRTHDAY":
                    String birthday = oneLine.getJokenChi();
                    inSession.setBirthYear(birthday.substring(0, 4));
                    inSession.setBirthMonth(birthday.substring(4, 6));
                    inSession.setBirthDay(birthday.substring(6));
                    break;
                case "KAIIN_KBN":
                    inSession.setKaiinKbn(oneLine.getJokenChi());
                    break;
                case "KIGYOCODE":
                    inSession.setKigyocode(oneLine.getJokenChi());
                    break;
                case "KINMUSAKI_NAME":
                    inSession.setKinmusakiName(oneLine.getJokenChi());
                    break;
                case "BANGO_NYURYOKU":
                    inSession.setBangoNyuryoku(oneLine.getJokenChi());
                    break;
                case "GOKAKU_BI":
                    String gokakuBi = oneLine.getJokenChi();
                    inSession.setGokakuBiYear(gokakuBi.substring(0, 4));
                    inSession.setGokakuBiMonth(gokakuBi.substring(4, 6));
                    inSession.setGokakuBiDay(gokakuBi.substring(6));
                    break;
                case "YUKO_KIGEN_SHIKAKU":
                    String yukoKigen = oneLine.getJokenChi();
                    inSession.setYukoKigenYear(yukoKigen.substring(0, 4));
                    inSession.setYukoKigenMonth(yukoKigen.substring(4, 6));
                    inSession.setYukoKigenDay(yukoKigen.substring(6));
                    break;
                case "YUKO_KIGEN_MENJO":
                    String yukoKigenMenjo = oneLine.getJokenChi();
                    inSession.setYukoKigenMenjoYear(yukoKigenMenjo.substring(0, 4));
                    inSession.setYukoKigenMenjoMonth(yukoKigenMenjo.substring(4, 6));
                    inSession.setYukoKigenMenjoDay(yukoKigenMenjo.substring(6));
                    break;

                case "GOHI_JOKYO":
                    int num9 = Integer.parseInt(oneLine.getJokenGyoNo()) - 1;
                    if (num9 >= 0) {
                        strGohiJokyoKbn[num9] = oneLine.getJokenChi();
                    }
                    break;
                default:
                    break;
            }
        }

        // �����@�u�K��̑I��
        inSession.setSknksuKbn(sknKsuKbnJokenChi);

        // ����
        inSession.setSknName(sknNmJokenChi);
        // �u�K��
        inSession.setKsuName(ksuNmJokenChi);

        // ���ۏ�
        inSession.setGohiJokyoKbn(strGohiJokyoKbn);
    }
}
