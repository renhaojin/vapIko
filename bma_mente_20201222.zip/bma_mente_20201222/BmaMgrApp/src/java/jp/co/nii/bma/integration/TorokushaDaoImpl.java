package jp.co.nii.bma.integration;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import static jp.co.nii.bma.business.domain.GeneratedTorokushaDao.TABLE_NAME;
import jp.co.nii.bma.business.domain.Torokusha;
import jp.co.nii.bma.business.domain.TorokushaDao;
import jp.co.nii.bma.business.rto.manager.HanyouSearchJoho;
import jp.co.nii.bma.business.service.common.BmaConstants;
import jp.co.nii.bma.utility.BmaUtility;
import jp.co.nii.sew.common.LogGenerate;
import static jp.co.nii.sew.integration.AbstractDao.getSchemaName;
import jp.co.nii.sew.integration.SQLStateSQLExceptionTranslater;
import static jp.co.nii.bma.integration.GeneratedTorokushaDaoImpl.FIELDS_DECRYPT;
import jp.co.nii.sew.business.domain.UniqueViolationException;

/**
 * �o�^�� DAO�����N���X
 *
 * @author DB�Ǘ��c�[��
 */
public class TorokushaDaoImpl extends GeneratedTorokushaDaoImpl implements TorokushaDao {

    /**
     * �C���X�^���X�𐶐�����B
     *
     * @param datasource �f�[�^�\�[�X��
     */
    public TorokushaDaoImpl(String datasource) {
        super(datasource);
    }

    /**
     * �ėp���X�g���擾����B
     *
     * @param search
     * @param inSession
     * @return
     */
    @Override
    public List<HanyouSearchJoho> findHanyouList(HanyouSearchJoho search, HanyouSearchJoho inSession) {
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = "";

        List<HanyouSearchJoho> moshikomiRreki = new ArrayList<>();

        List<String> param = new ArrayList<>();

        try {
            con = getConnection();
            sql = "SELECT "
                    + "nendo"
                    + ",moshikomisha_id"
                    + ",skn_ksu_nm"
                    + ",uketsuke_no"
                    + ",juken_juko_no"
                    + ",shimei"
                    + ",furigana"
                    + ",moshikomi_jokyo_kbn"
                    + ",unyo_jokyo_kbn"
                    + ",moshikomi_jokyo_nm"
                    + " FROM " + getSchemaName() + "." + " hanYO_kensaku_all_view"
                    + " WHERE ronri_sakujo_flg_msk = '0'"
                    + " AND ";

            sql = makeSql(param, search, sql);
            int index = sql.indexOf("WHERE");
            inSession.setSql(sql.substring(index + 5));

            sql = sql + " group by "
                    + "nendo"
                    + ",moshikomisha_id"
                    + ",skn_ksu_nm"
                    + ",uketsuke_no"
                    + ",juken_juko_no"
                    + ",shimei"
                    + ",furigana"
                    + ",moshikomi_jokyo_kbn"
                    + ",unyo_jokyo_kbn"
                    + ",moshikomi_jokyo_nm";

            /* ����������l���Z�b�g */
            stmt = con.prepareStatement(sql);
            int i = 1;
            for (String pm : param) {
                stmt.setString(i++, pm);
            }

            inSession.setParam(param);

            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();

            while (rs.next()) {
                HanyouSearchJoho detail = new HanyouSearchJoho();

                detail.setNendo(rs.getString("nendo"));
                detail.setMoshikomishaId(rs.getString("moshikomisha_id"));
                detail.setUketsukeNo(rs.getString("uketsuke_no"));
                detail.setJukenJukoNo(rs.getString("juken_juko_no"));
                detail.setShimei(rs.getString("shimei"));
                detail.setFurigana(rs.getString("furigana"));
                detail.setSknKsuNm(rs.getString("skn_ksu_nm"));
                detail.setUnyoJokyoKbn(rs.getString("unyo_jokyo_kbn"));

                detail.setUnyouList(inSession.getUnyouList());

                moshikomiRreki.add(detail);
            }

        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return moshikomiRreki;
    }

    /**
     * ����SQL�쐬<br>
     *
     * @param param �p�����[�^
     * @param search �ėp�}�X�^bean
     * @return �쐬SQL�쐬<br>
     */
    private String makeSql(List<String> param, HanyouSearchJoho search, String sql) {
        // �����̏ꍇ
        if (!search.getSknName().isEmpty() && search.getSknksuKbn().equals(BmaConstants.SKN_KBN)) {

            String sknksucode = search.getSknName().substring(0, 2);
            String shubetsucode = search.getSknName().substring(2, 4);
            String kaisucode = search.getSknName().substring(4, 6);

            sql = sql + " SKN_KSU_CODE =  ?";
            param.add(sknksucode);
            sql = sql + " and  SHUBETSU_CODE =  ?";
            param.add(shubetsucode);
            sql = sql + " and KAISU_CODE =  ?";
            param.add(kaisucode);
        } // �u�K��̏ꍇ
        else if (!search.getKsuName().isEmpty() && search.getSknksuKbn().equals(BmaConstants.KSU_KBN)) {

            String sknksucode = search.getKsuName().substring(0, 2);
            String shubetsucode = search.getKsuName().substring(2, 4);
            String kaisucode = search.getKsuName().substring(4, 6);

            sql = sql + " SKN_KSU_CODE =  ?";
            param.add(sknksucode);
            sql = sql + " and  SHUBETSU_CODE =  ?";
            param.add(shubetsucode);
            sql = sql + " and KAISU_CODE =  ?";
            param.add(kaisucode);
        }
        // �N�x
        if (!search.getNendoFrm().isEmpty() && !search.getNendoTo().isEmpty()) {
            sql = sql + " AND NENDO BETWEEN ? AND ? ";
            param.add(search.getNendoFrm());
            param.add(search.getNendoTo());
        }
        // �t���K�i
        if (!search.getFurigana().isEmpty()) {
            sql = sql + "AND FURIGANA like ?";
            param.add("%" + search.getFurigana() + "%");
        }
        // ���N����
        if (!search.getBirthYear().isEmpty() && !search.getBirthMonth().isEmpty() && !search.getBirthDay().isEmpty()) {
            String birthy = search.getBirthYear() + search.getBirthMonth() + search.getBirthDay();
            if (birthy.length() == 8) {
                sql = sql + " AND BIRTHDAY = ? ";
                param.add(birthy);
            }
        }
        // ����敪
        if (search.getKaiinKbn() != null) {
            if (search.getKaiinKbn().equals("1")) {
                sql = sql + " AND KAIIN_KBN = ? ";
                param.add(search.getKaiinKbn());
            } else {
                sql = sql + " AND KAIIN_KBN IN (";
                sql = sql + "?";
                sql = sql + ", ";
                param.add("2");
                sql = sql + "?";
                sql = sql + ", ";
                param.add("3");
                sql = sql + "?";
                param.add("4");
                sql = sql + ") ";
            }
        }
        // ��ƃR�[�h
        if (!search.getKigyocode().isEmpty()) {
            sql = sql + " AND KIGYO_CODE = ? ";
            param.add(search.getKigyocode());
        }
        // �Ζ��於
        if (!BmaUtility.isNullOrEmpty(search.getKinmusakiName())) {
            sql = sql + "AND KINMUSAKI_NAME like ?";
            param.add("%" + search.getKinmusakiName() + "%");
        }
        // �ԍ�����
        String key = search.getBangoInput();
        // �ԍ��I��
        if (search.getBangoNyuryoku() != null) {
            switch (search.getBangoNyuryoku()) {
                case "1":
                    sql = sql + " AND UKETSUKE_NO = ? ";
                    param.add(key);
                    break;
                case "2":
                    sql = sql + " AND JUKEN_JUKO_NO = ? ";
                    param.add(key);
                    break;
                case "3":
                    sql = sql + " AND GOKAKU_NO = ? ";
                    param.add(key);
                    break;
                case "4":
                    sql = sql + " AND GOUKAKU_NO_GAKKA = ? ";
                    param.add(key);
                    break;
                case "5":
                    sql = sql + " AND GOUKAKU_NO_JITSUGI = ? ";
                    param.add(key);
                    break;

                default:
                    break;
            }
        }

        // �������e
        List<String> shikennaiyo = null;
        if (search.getShikennaiyo() != null) {
            shikennaiyo = Arrays.asList(search.getShikennaiyo());
        }
        if (shikennaiyo != null) {
            if (shikennaiyo.size() > 0) {
                sql = sql + " AND SHIKEN_NAIYO_KBN IN (";
                for (int j = 0; j < shikennaiyo.size(); j++) {
                    if (j > 0) {
                        sql = sql + ", ";
                    }
                    sql = sql + "?";
                    param.add(shikennaiyo.get(j));
                }
                sql = sql + ") ";
            }
        }

        // �\�����@
        List<String> moshikomiKbn = null;
        if (search.getMoshikomiKbn() != null) {
            moshikomiKbn = Arrays.asList(search.getMoshikomiKbn());
        }
        if (moshikomiKbn != null) {
            if (moshikomiKbn.size() > 0) {
                sql = sql + " AND MOSHIKOMI_KBN IN (";
                for (int j = 0; j < moshikomiKbn.size(); j++) {
                    if (j > 0) {
                        sql = sql + ", ";
                    }
                    sql = sql + "?";
                    param.add(moshikomiKbn.get(j));
                }
                sql = sql + ") ";
            }
        }

        // �\���敪
        List<String> kojinDantaiKbn = null;
        if (search.getKojinDantaiKbn() != null) {
            kojinDantaiKbn = Arrays.asList(search.getKojinDantaiKbn());
        }
        if (kojinDantaiKbn != null) {
            if (kojinDantaiKbn.size() > 0) {
                sql = sql + " AND MOSHIKOMI_KBN IN (";
                for (int j = 0; j < kojinDantaiKbn.size(); j++) {
                    if (j > 0) {
                        sql = sql + ", ";
                    }
                    sql = sql + "?";
                    param.add(kojinDantaiKbn.get(j));
                }
                sql = sql + ") ";
            }
        }

        // �\����
        List<String> moshikomiJokyoKbn = null;
        if (search.getMoshikomiJokyoKbn() != null) {
            moshikomiJokyoKbn = Arrays.asList(search.getMoshikomiJokyoKbn());
        }
        if (moshikomiJokyoKbn != null) {
            if (moshikomiJokyoKbn.size() > 0) {
                sql = sql + " AND MOSHIKOMI_JOKYO_KBN IN (";
                for (int j = 0; j < moshikomiJokyoKbn.size(); j++) {
                    if (j > 0) {
                        sql = sql + ", ";
                    }
                    sql = sql + "?";
                    param.add(moshikomiJokyoKbn.get(j));
                }
                sql = sql + ") ";
            }
        }

        // �z���\��
        List<String> comUmFlg = null;
        if (search.getComUmFlg() != null) {
            comUmFlg = Arrays.asList(search.getComUmFlg());
        }
        if (comUmFlg != null) {
            if (comUmFlg.size() > 0) {
                sql = sql + " AND HAIRYO_FLG IN (";
                for (int j = 0; j < comUmFlg.size(); j++) {
                    if (j > 0) {
                        sql = sql + ", ";
                    }
                    sql = sql + "?";
                    param.add(comUmFlg.get(j));
                }
                sql = sql + ") ";
            }
        }
        // ����t��
        String KariuketsukeBiFrom = "";
        String KariuketsukeBiTo = "";
        if (!search.getKariuketsukeBiFromYear().isEmpty() && !search.getKariuketsukeBiFromMonth().isEmpty() && !search.getKariuketsukeBiFromDay().isEmpty()) {
            KariuketsukeBiFrom = search.getKariuketsukeBiFromYear() + search.getKariuketsukeBiFromMonth() + search.getKariuketsukeBiFromDay();
        }
        if (!search.getKariuketsukeBiToYear().isEmpty() && !search.getKariuketsukeBiToMonth().isEmpty() && !search.getKariuketsukeBiToDay().isEmpty()) {
            KariuketsukeBiTo = search.getKariuketsukeBiToYear() + search.getKariuketsukeBiToMonth() + search.getKariuketsukeBiToDay();
        }
        if (KariuketsukeBiFrom.length() == 8 && KariuketsukeBiTo.length() == 8) {
            sql = sql + " AND KARI_UKETSUKE_BI BETWEEN ? AND ? ";
            param.add(KariuketsukeBiFrom);
            param.add(KariuketsukeBiTo);
        }

        // �\��(����)������
        String MoshikomikanryoBiFrom = "";
        String MoshikomikanryoBiTo = "";
        if (!search.getMoshikomikanryoBiFromYear().isEmpty() && !search.getMoshikomikanryoBiFromMonth().isEmpty() && !search.getMoshikomikanryoBiFromDay().isEmpty()) {
            MoshikomikanryoBiFrom = search.getMoshikomikanryoBiFromYear() + search.getMoshikomikanryoBiFromMonth() + search.getMoshikomikanryoBiFromDay();
        }
        if (!search.getMoshikomikanryoBiToYear().isEmpty() && !search.getMoshikomikanryoBiToMonth().isEmpty() && !search.getMoshikomikanryoBiToDay().isEmpty()) {
            MoshikomikanryoBiTo = search.getMoshikomikanryoBiToYear() + search.getMoshikomikanryoBiToMonth() + search.getMoshikomikanryoBiToDay();
        }
        if (MoshikomikanryoBiFrom.length() == 8 && MoshikomikanryoBiTo.length() == 8) {
            sql = sql + " AND MOSHIKOMI_FINISH_BI BETWEEN ? AND ? ";
            param.add(MoshikomikanryoBiFrom);
            param.add(MoshikomikanryoBiTo);
        }

        // ���ϕ��@
        List<String> kessaiHoho = null;
        if (search.getKessaiHoho() != null) {
            kessaiHoho = Arrays.asList(search.getKessaiHoho());
        }
        if (kessaiHoho != null) {
            if (kessaiHoho.size() > 0) {
                sql = sql + " AND KESSAI_HOHO_KBN IN (";
                for (int j = 0; j < kessaiHoho.size(); j++) {
                    if (j > 0) {
                        sql = sql + ", ";
                    }
                    sql = sql + "?";
                    param.add(kessaiHoho.get(j));
                }
                sql = sql + ") ";
            }
        }

        // ���Ϗ�
        List<String> kessaiJokyoKbn = null;
        if (search.getKessaiJokyoKbn() != null) {
            kessaiJokyoKbn = Arrays.asList(search.getKessaiJokyoKbn());
        }
        if (kessaiJokyoKbn != null) {
            if (kessaiJokyoKbn.size() > 0) {
                sql = sql + " AND KESSAI_JOKYO_KBN IN (";
                for (int j = 0; j < kessaiJokyoKbn.size(); j++) {
                    if (j > 0) {
                        sql = sql + ", ";
                    }
                    sql = sql + "?";
                    param.add(kessaiJokyoKbn.get(j));
                }
                sql = sql + ") ";
            }
        }

        // �摜�␳�˗���
        List<String> hoseiIraiKbn = null;
        if (search.getHoseiIraiKbn() != null) {
            hoseiIraiKbn = Arrays.asList(search.getHoseiIraiKbn());
        }
        if (hoseiIraiKbn != null) {
            if (hoseiIraiKbn.size() > 0) {
                sql = sql + " AND HOSEI_IRAI_KBN IN (";
                for (int j = 0; j < hoseiIraiKbn.size(); j++) {
                    if (j > 0) {
                        sql = sql + ", ";
                    }
                    sql = sql + "?";
                    param.add(hoseiIraiKbn.get(j));
                }
                sql = sql + ") ";
            }
        }

        // ���ۏ�
        List<String> gohiJokyoKbn = null;
        if (search.getGohiJokyoKbn() != null) {
            gohiJokyoKbn = Arrays.asList(search.getGohiJokyoKbn());
        }
        if (gohiJokyoKbn != null) {
            if (gohiJokyoKbn.size() > 0) {
                sql = sql + " AND GOHI_JOKYO_KBN IN (";
                for (int j = 0; j < gohiJokyoKbn.size(); j++) {
                    if (j > 0) {
                        sql = sql + ", ";
                    }
                    sql = sql + "?";
                    param.add(gohiJokyoKbn.get(j));
                }
                sql = sql + ") ";
            }
        }
        return sql;
    }

    @Override
    public List<HanyouSearchJoho> findHanyouPastList(HanyouSearchJoho search, HanyouSearchJoho inSession) {

        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = "";

        List<HanyouSearchJoho> moshikomiRreki = new ArrayList<>();

        List<String> param = new ArrayList<>();

        try {
            con = getConnection();
            sql = "SELECT "
                    + "nendo"
                    + ",moshikomisha_id"
                    + ",skn_ksu_nm"
                    + ",uketsuke_no"
                    + ",juken_juko_no"
                    + ",shimei"
                    + ",furigana"
                    + ",moshikomi_jokyo_kbn"
                    + ",unyo_jokyo_kbn"
                    + ",moshikomi_jokyo_nm"
                    + " FROM " + getSchemaName() + "." + " hanYO_kensaku_all_view"
                    + " WHERE ronri_sakujo_flg_msk = '0'"
                    + " AND ";

            sql = makeKakoSql(param, search, sql);
            int index = sql.indexOf("WHERE");
            inSession.setSql(sql.substring(index + 5));

            sql = sql + " group by "
                    + "nendo"
                    + ",moshikomisha_id"
                    + ",skn_ksu_nm"
                    + ",uketsuke_no"
                    + ",juken_juko_no"
                    + ",shimei"
                    + ",furigana"
                    + ",moshikomi_jokyo_kbn"
                    + ",unyo_jokyo_kbn"
                    + ",moshikomi_jokyo_nm";

            /* ����������l���Z�b�g */
            stmt = con.prepareStatement(sql);
            int i = 1;
            for (String pm : param) {
                stmt.setString(i++, pm);
            }

            inSession.setParam(param);

            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();

            while (rs.next()) {
                HanyouSearchJoho detail = new HanyouSearchJoho();

                detail.setNendo(rs.getString("nendo"));
                detail.setUketsukeNo(rs.getString("uketsuke_no"));
                detail.setMoshikomishaId(rs.getString("moshikomisha_id"));
                detail.setJukenJukoNo(rs.getString("juken_juko_no"));
                detail.setShimei(rs.getString("shimei").replace(" ", ""));
                detail.setFurigana(rs.getString("furigana").replace(" ", ""));
                detail.setSknKsuNm(rs.getString("skn_ksu_nm"));
                detail.setUnyoJokyoKbn(rs.getString("unyo_jokyo_kbn"));

                detail.setUnyouList(inSession.getUnyouList());

                moshikomiRreki.add(detail);
            }

        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return moshikomiRreki;

    }

    /**
     * ����SQL�쐬<br>
     *
     * @param param �p�����[�^
     * @param search �ėp�}�X�^bean
     * @return �쐬SQL�쐬<br>
     */
    private String makeKakoSql(List<String> param, HanyouSearchJoho search, String sql) {
        // �����̏ꍇ
        if (!search.getSknName().isEmpty() && search.getSknksuKbn().equals(BmaConstants.SKN_KBN)) {

            String sknksucode = search.getSknName().substring(0, 2);
            String shubetsucode = search.getSknName().substring(2, 4);
            String kaisucode = search.getSknName().substring(4, 6);

            sql = sql + " SKN_KSU_CODE =  ?";
            param.add(sknksucode);
            sql = sql + " and  SHUBETSU_CODE =  ?";
            param.add(shubetsucode);
            sql = sql + " and KAISU_CODE =  ?";
            param.add(kaisucode);
        } // �u�K��̏ꍇ
        else if (!search.getKsuName().isEmpty() && search.getSknksuKbn().equals(BmaConstants.KSU_KBN)) {

            String sknksucode = search.getKsuName().substring(0, 2);
            String shubetsucode = search.getKsuName().substring(2, 4);
            String kaisucode = search.getKsuName().substring(4, 6);

            sql = sql + " SKN_KSU_CODE =  ?";
            param.add(sknksucode);
            sql = sql + " and  SHUBETSU_CODE =  ?";
            param.add(shubetsucode);
            sql = sql + " and KAISU_CODE =  ?";
            param.add(kaisucode);
        }
        // �N�x
        if (!search.getNendoFrm().isEmpty() && !search.getNendoTo().isEmpty()) {
            sql = sql + " AND NENDO BETWEEN ? AND ? ";
            param.add(search.getNendoFrm());
            param.add(search.getNendoTo());
        }
        // �t���K�i
        if (!search.getFurigana().isEmpty()) {
            sql = sql + "AND FURIGANA like ?";
            param.add("%" + search.getFurigana() + "%");
        }
        // ���N����
        if (!search.getBirthYear().isEmpty() && !search.getBirthMonth().isEmpty() && !search.getBirthDay().isEmpty()) {
            String birthy = search.getBirthYear() + search.getBirthMonth() + search.getBirthDay();
            if (birthy.length() == 8) {
                sql = sql + " AND BIRTHDAY = ? ";
                param.add(birthy);
            }
        }
        // ����敪
        if (search.getKaiinKbn() != null) {
            if (search.getKaiinKbn().equals("1")) {
                sql = sql + " AND KAIIN_KBN = ? ";
                param.add(search.getKaiinKbn());
            } else {
                sql = sql + " AND KAIIN_KBN IN (";
                sql = sql + "?";
                sql = sql + ", ";
                param.add("2");
                sql = sql + "?";
                sql = sql + ", ";
                param.add("3");
                sql = sql + "?";
                param.add("4");
                sql = sql + ") ";
            }
        }
        // ��ƃR�[�h
        if (!search.getKigyocode().isEmpty()) {
            sql = sql + " AND KIGYO_CODE = ? ";
            param.add(search.getKigyocode());
        }
        // �Ζ��於
        if (!search.getKinmusakiName().isEmpty()) {
            sql = sql + "AND KINMUSAKI_NAME like ?";
            param.add("%" + search.getKinmusakiName() + "%");
        }
        // �ԍ�����
        String key = search.getBangoInput();
        // �ԍ��I��
        if (search.getBangoNyuryoku() != null) {
            switch (search.getBangoNyuryoku()) {
                case "1":
                    sql = sql + " AND UKETSUKE_NO = ? ";
                    param.add(key);
                    break;
                case "2":
                    sql = sql + " AND JUKEN_JUKO_NO = ? ";
                    param.add(key);
                    break;
                case "3":
                    sql = sql + " AND GOKAKU_NO = ? ";
                    param.add(key);
                    break;
                case "4":
                    sql = sql + " AND GOUKAKU_NO_GAKKA = ? ";
                    param.add(key);
                    break;
                case "5":
                    sql = sql + " AND GOUKAKU_NO_JITSUGI = ? ";
                    param.add(key);
                    break;

                default:
                    break;
            }
        }

        // ���ۏ�
        List<String> gohiJokyoKbn = null;
        if (search.getGohiJokyoKbn() != null) {
            gohiJokyoKbn = Arrays.asList(search.getGohiJokyoKbn());
        }
        if (gohiJokyoKbn != null) {
            if (gohiJokyoKbn.size() > 0) {
                sql = sql + " AND GOHI_JOKYO_KBN IN (";
                for (int j = 0; j < gohiJokyoKbn.size(); j++) {
                    if (j > 0) {
                        sql = sql + ", ";
                    }
                    sql = sql + "?";
                    param.add(gohiJokyoKbn.get(j));
                }
                sql = sql + ") ";
            }
        }
        // ���i�N����
        if (!search.getGokakuBiYear().isEmpty() && !search.getGokakuBiMonth().isEmpty() && !search.getGokakuBiDay().isEmpty()) {
            String gokaku = search.getGokakuBiYear() + search.getGokakuBiMonth() + search.getGokakuBiDay();
            if (gokaku.length() == 8) {
                sql = sql + " AND GOKAKU_BI = ? ";
                param.add(gokaku);
            }
        }
        // �L������
        if (!search.getYukoKigenYear().isEmpty() && !search.getYukoKigenMonth().isEmpty() && !search.getYukoKigenDay().isEmpty()) {
            String yukou = search.getYukoKigenYear() + search.getYukoKigenMonth() + search.getYukoKigenDay();
            if (yukou.length() == 8) {
                sql = sql + " AND YUKO_KIGEN_SHIKAKU = ? ";
                param.add(yukou);
            }
        }
        // �ꕔ�Ə�����
        if (!search.getYukoKigenMenjoYear().isEmpty() && !search.getYukoKigenMenjoMonth().isEmpty() && !search.getYukoKigenMenjoDay().isEmpty()) {
            String yukouMen = search.getYukoKigenMenjoYear() + search.getYukoKigenMenjoMonth() + search.getYukoKigenMenjoDay();
            if (yukouMen.length() == 8) {
                sql = sql + " AND YUKO_KIGEN_MENJO = ? ";
                param.add(yukouMen);
            }
        }

        return sql;
    }

    /*@Override
    public Torokusha findByKaiinId(Torokusha bo, String lockMode) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }*/
 /* (non-Javadoc)
     * @see jp.co.nii.bma.business.domain.TorokushaDao#findByKaiinId(jp.co.nii.bma.business.domain.Torokusha, java.lang.String)
     */
    @Override
    public Torokusha findByKaiinId(Torokusha bo, String lockMode) {
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = "";
        try {
            con = getConnection();
            sql = "SELECT " + FIELDS_DECRYPT
                    + " FROM " + getSchemaName() + "." + TABLE_NAME
                    + " WHERE"
                    + " KAIIN_ID = ?";

            stmt = con.prepareStatement(sql + lockMode);
            int i = 1;
            stmt.setString(i++, bo.getKaiinId());

            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();
            if (rs.next()) {
                setBoFromResultSet(bo, rs);
                if (rs.next()) {
                    throw new UniqueViolationException("�o�^�҃e�[�u���̉��ID" + bo.getKaiinId() + "����ӂł͂���܂���B");
                }
            } else {
                bo = null;
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return bo;
    }

}
