package jp.co.nii.bma.business.service.manager;

import jp.co.nii.bma.business.domain.KaijoTantoMst;
import jp.co.nii.bma.business.rto.manager.MstKanriKaijoTantoJoho;
import jp.co.nii.bma.business.service.common.BmaConstants;
import jp.co.nii.bma.business.service.common.BmaLogger;
import jp.co.nii.bma.business.service.common.BmaValidator;
import jp.co.nii.bma.utility.BmaStringUtility;
import jp.co.nii.bma.utility.BmaUtility;
import jp.co.nii.sew.business.service.AbstractService;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_SUCCESS;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_RELOAD;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_EXCEPTION;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_SESSION;
import jp.co.nii.sew.presentation.Messages;
import jp.co.nii.sew.presentation.RequestTransferObject;
import jp.co.nii.sew.utility.PropertyUtility;

/**
 *
 * @author nii19042
 */
public class MstKanriKaijoTantoUpdateInputService extends AbstractService {

    /**
     * DB�ڑ��̃f�[�^�\�[�X
     */
    private static String DATA_SOURCE_NAME;
    /**
     * ���O
     */
    BmaLogger log = (BmaLogger) BmaLogger.getLogger(this.getClass().getName());
    /**
     * �Ɩ��R�[�h
     */
    private static final String BUSINESS_CODE = PropertyUtility.getProperty("business_code");
    /**
     * ���׃e�X�g���[�h
     */
    private static final String STRESS_MODE = PropertyUtility.getProperty(BUSINESS_CODE + "stress_mode");

    /**
     * �R���X�g���N�^
     */
    public MstKanriKaijoTantoUpdateInputService() {
        super();
        /* DB�ڑ����̃��[�U�[������ */
        DATA_SOURCE_NAME = BmaConstants.DS_REGISTRANT;
    }

    /**
     * �T�[�r�X�N���X�̎��s���\�b�h
     *
     * @param rto ���N�G�X�g��񂩂�擾����rto
     * @param rtoInSession �Z�b�V�������rto
     * @return foward��
     * @throws Exception ��O
     */
    @Override
    public String doService(RequestTransferObject rto, RequestTransferObject rtoInSession)
            throws Exception {

        MstKanriKaijoTantoJoho inRequest = (MstKanriKaijoTantoJoho) rto;
        MstKanriKaijoTantoJoho inSession = (MstKanriKaijoTantoJoho) rtoInSession;
        String processName = "";

        /* �G���[���b�Z�[�W������ */
        inSession.setErrors(new Messages());

        try {
            if (!BmaUtility.isNullOrEmpty(inRequest.getKaijoTantoUpdConf())) {
                /*�u�m�F�v�{�^�������� */
                processName = "MstKanriKaijoTantoUpdateInput_Confirm";
                log.Start(processName);

                /* �Z�b�V�����ɕێ� */
                inSession.setTantoBusho(inRequest.getTantoBusho());
                inSession.setTelNo(inRequest.getTelNo());
                inSession.setFaxNo(inRequest.getFaxNo());
                inSession.setTantoshaMailAddress(inRequest.getTantoshaMailAddress());
                inSession.setBiko(inRequest.getBiko());

                /* ���͒l�`�F�b�N */
                if (!validateInput(inSession)) {
                    // �G���[���������ꍇ�u���S���҃}�X�^�ύX���́v���Reload
                    return FWD_NM_RELOAD;
                }

                /* �u���S���҃}�X�^�ύX�m�F�v��ʕ\�� */
                return FWD_NM_SUCCESS;

            } else if (!BmaUtility.isNullOrEmpty(inRequest.getKaijoTantoUpdInputBack())) {
                /*�u�߂�v�{�^�������� */
                processName = "MstKanriKaijoTantoUpdateInput_BackDetail";
                log.Start(processName);

                /* ���͏���j�����ēo�^�f�[�^���ĕ\�� */
                KaijoTantoMst tanto = new KaijoTantoMst(DATA_SOURCE_NAME);
                String kaisaichi = inSession.getKaisaichiCode();
                String kaijoCode = inSession.getKaijoCode();
                String tantoshaCode = inSession.getTantoshaCode();

                /* �ڍ׃f�[�^���擾���A�Z�b�V�����ɕێ� */
                KaijoTantoMst tantoResult  = tanto.lockNoWait(kaisaichi, kaijoCode, tantoshaCode);
                inSession.setTantoBusho(tantoResult.getTantoBusho());
                inSession.setTelNo(tantoResult.getTelNo());
                inSession.setFaxNo(tantoResult.getFaxNo());
                inSession.setTantoshaMailAddress(tantoResult.getTantoshaMailAddress());
                inSession.setBiko(tantoResult.getBiko());

                /* �u���S���҃}�X�^�ڍׁv��ʕ\�� */
                return FWD_NM_BACK;

            } else {
                /* �ُ�J�� */
                log.IllegalFWD();
                return FWD_NM_SESSION;
            }
        } catch (Exception e) {
            return FWD_NM_EXCEPTION;
        } finally {
            log.End(processName);
        }
    }

    /**
     * ���̓`�F�b�N
     *
     * @param inSession �Z�b�V����RTO
     * @return true:�G���[��
     */
    private boolean validateInput(MstKanriKaijoTantoJoho inSession) {
        /* �ϐ������� */
        Messages errors = new Messages();
        String groupCode;
        String itemName;

        //�S�p�ϊ����s
        inSession.setTantoBusho(BmaStringUtility.convertHankakuToZenkakuBma(inSession.getTantoBusho()));

        /* �S������ */
        groupCode = "tantoBusho";
        itemName = "�S������";
        if (BmaValidator.validateMaxLength(inSession.getTantoBusho(), BmaConstants.MAX_LENGTH_TANTOBUSHO, errors, groupCode, itemName)) {
            BmaValidator.validateMojiCode3(inSession.getTantoBusho(), errors, groupCode, itemName);
        }

        /* �d�b�ԍ� */
        groupCode = "telNo";
        itemName = "�d�b�ԍ�";
        if (BmaValidator.validateRequired(inSession.getTelNo(), errors, groupCode, itemName)) {
            if (BmaValidator.validateNumber(inSession.getTelNo(), errors, groupCode, itemName)) {
                BmaValidator.validateRangeLength(inSession.getTelNo(), BmaConstants.MIN_LENGTH_TEL_NO, BmaConstants.MAX_LENGTH_TEL_NO, errors, groupCode, itemName);
            }
        }

        /* FAX�ԍ� */
        groupCode = "faxNo";
        itemName = "FAX�ԍ�";
        if (BmaValidator.validateNumber(inSession.getFaxNo(), errors, groupCode, itemName)) {
            BmaValidator.validateRangeLength(inSession.getFaxNo(), BmaConstants.MIN_LENGTH_FAX_NO, BmaConstants.MAX_LENGTH_FAX_NO, errors, groupCode, itemName);
        }

        /* �S���҃��[���A�h���X */
        groupCode = "tantoshaMailAddress";
        itemName = "�S���҃��[���A�h���X";
        if (BmaValidator.validateMaxLength(inSession.getTantoshaMailAddress(), BmaConstants.MAX_LENGTH_TANTOSHA_MAILADDRESS, errors, groupCode, itemName)) {
            BmaValidator.validateEmail(inSession.getTantoshaMailAddress(), errors, groupCode, itemName);
        }

        /* ���l */
        groupCode = "biko";
        itemName = "���l";
        if (BmaValidator.validateMaxLength(inSession.getBiko(), BmaConstants.MAX_LENGTH_BIKO, errors, groupCode, itemName)) {
            String replaced = inSession.getBiko().replaceAll("\r\n", "\n");
            replaced = replaced.replaceAll("\r", "\n");
            if (BmaValidator.validateMojiCodeForBiko(replaced, errors, groupCode, itemName)) {
                // �G���[���Ȃ���΁A�\���p�ɃZ�b�V�����ێ�
                inSession.setBikoDisp(replaced.replaceAll("\n", "<br>"));
            }
        }

        inSession.setErrors(errors);
        return errors.isEmpty();
    }
}