package jp.co.nii.bma.business.service.manager;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import jp.co.nii.bma.business.domain.HoyuMenjoMst;
import jp.co.nii.bma.business.domain.HoyuShikakuMst;
import jp.co.nii.bma.business.domain.MSkkMnjKanri;
import jp.co.nii.bma.business.domain.MeishoKanri;
import jp.co.nii.bma.business.domain.Moshikomi;
import jp.co.nii.bma.business.domain.MoshikomiHenkoRireki;
import jp.co.nii.bma.business.domain.Saiban;
import jp.co.nii.bma.business.domain.Schedule;
import jp.co.nii.bma.business.domain.ShiyoKaijo;
import jp.co.nii.bma.business.domain.SknksuMst;
import jp.co.nii.bma.business.domain.YukoKigenMst;
import jp.co.nii.bma.business.rto.manager.NumKanriJoho;
import jp.co.nii.bma.business.service.common.BmaConstants;
import jp.co.nii.bma.business.service.common.BmaLogger;
import jp.co.nii.bma.business.service.common.BmaSaibanService;
import jp.co.nii.bma.business.service.common.BmaValidator;
import jp.co.nii.bma.presentation.common.BmaText;
import jp.co.nii.bma.utility.BmaFileUtility;
import jp.co.nii.bma.utility.BmaUtility;
import jp.co.nii.sew.business.Constants;
import jp.co.nii.sew.business.SystemTime;
import jp.co.nii.sew.business.service.AbstractService;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_RELOAD;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_SUCCESS;
import jp.co.nii.sew.presentation.Message;
import jp.co.nii.sew.presentation.Messages;
import jp.co.nii.sew.presentation.Option;
import jp.co.nii.sew.presentation.RequestTransferObject;
import jp.co.nii.sew.utility.CheckUtility;
import jp.co.nii.sew.utility.PropertyUtility;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.fileupload.FileItem;

/**
 * �^�C�g��: �\���f�[�^�A�b�v���[�h�T�[�r�X
 * ����: �\���f�[�^�A�b�v���[�hRTO
 * ���쌠: Copyright (c) 2020
 * ��Ж�: ���{���Y�Ɗ������
 * */

public class NumKanriService extends AbstractService {
    /**
     * DB�ڑ��̃f�[�^�\�[�X
     */
    private static String DATA_SOURCE_NAME;
    /**
     * ���O
     */
    BmaLogger log = (BmaLogger) BmaLogger.getLogger(this.getClass().getName());
    /**
     * �Ɩ��R�[�h
     */
    private static final String BUSINESS_CODE = PropertyUtility.getProperty("business_code");
    /**
     * ���׃e�X�g���[�h
     */
    private static final String STRESS_MODE = PropertyUtility.getProperty(BUSINESS_CODE + "stress_mode");
    /**
     * ���ڐ��i�󌟎�u�ԍ��j
     */
    private static final int JKO_JKN_LENGTH = 9;
    /**
     * ���ڐ��i���i�ԍ��j
     */
    private static final int GOKAKU_LENGTH = 12;
    /**
     * �t�@�C���T�C�Y
     */
    private static final String CSV_SIZE = PropertyUtility.getProperty(BUSINESS_CODE + "max_csv_size");
    

    /**
     * �R���X�g���N�^
     */
    public NumKanriService() {
        super();
        /* DB�ڑ����̃��[�U�[������ */
        DATA_SOURCE_NAME = BmaConstants.DS_REGISTRANT;
    }

    /**
     * �T�[�r�X�N���X�̎��s���\�b�h
     *
     * @param rto ���N�G�X�g��񂩂�擾����rto
     * @param rtoInSession �Z�b�V�������rto
     * @return foward��
     * @throws Exception ��O
     */
    @Override
    public String doService(RequestTransferObject rto, RequestTransferObject rtoInSession)
            throws Exception {

        NumKanriJoho inRequest = (NumKanriJoho) rto;
        NumKanriJoho inSession = (NumKanriJoho) rtoInSession;
        String processName = "";
        String dataName = "";

        /*�G���[���b�Z�[�W������*/
        inSession.setErrors(new Messages());

        try {
            if (!BmaUtility.isNullOrEmpty(inRequest.getBangoKanri())) {
                /*�u�ԍ��Ǘ��v�{�^��������*/
                processName = "NumKanri";
                log.Start(processName);
                /* rto�̏����N���A */
                inSession.clearInfo();
                /* �u�ԍ��Ǘ��v��ʕ\�� */
                return FWD_NM_SUCCESS;
            } else if (!BmaUtility.isNullOrEmpty(inRequest.getJknJkuNoFuyo())) {
                /*�u�󌟁^��u�ԍ��t�^�v�{�^��������*/
                processName = "NumJkoJknUpload";
                log.Start(processName);

                /* �u�󌟁^��u�ԍ��A�b�v���[�h�v��ʕ\�� */
                //�����^�u�K��̃��W�I�{�^�������擾
                inSession.setSknKbnList(findSknKsuList(BmaConstants.SKN_KBN));
                inSession.setKsuKbnList(findSknKsuList(BmaConstants.KSU_KBN));

                return "jknUpload";
            } else if (!BmaUtility.isNullOrEmpty(inRequest.getJknJkuNoTmpDl())) {
                /*�u�e���v���[�g�_�E�����[�h�v�{�^��������*/
                processName = "jknJkuNoTmpDl";
                log.Start(processName);

                /* ���̓f�[�^�Z�b�g */
                setValueRequestToSession(inRequest, inSession);

                /* ����/�u�K��擾 */
                findsknKsuNameChi(inSession);

                /* �_�E�����[�h�f�[�^�擾 */
                Moshikomi mc = new Moshikomi(DATA_SOURCE_NAME);
                ArrayList<Moshikomi> moshikomiList = mc.findTmpJohoList(inSession);
                inSession.setResultDetailList(moshikomiList);
                inSession.setJknJkuNoTmpDl("jknJkuNoTmpDl");

                /* �_�E�����[�h */
                return "jknJkuNoTmpDl";

            } else if (!BmaUtility.isNullOrEmpty(inRequest.getJknJkuNoUl())) {
                /*�u�A�b�v���[�h�v�{�^�������� */
                processName = "NumJkoJknConfirm";
                dataName = "�󌟎�u�ԍ��f�[�^";
                log.Start(processName);
                //�G���[���O������
                List<NumKanriJoho> errorLog = new ArrayList<>();
                inSession.setErrorLog(errorLog);
                inSession.setErrorLogFlg(Constants.FLG_OFF);

                /* ���͒l���Z�b�V�����ɕۑ� */
                setValueRequestToSession(inRequest, inSession);
                
                /* ����/�u�K��擾 */
                findsknKsuNameChi(inSession);
                // �t�@�C���擾
                String fileName = inRequest.getFileData().getName();
                File file = new File(fileName);
                // PATH���t���Ă���̃t�@�C���̂ݔ��f����
                int index = fileName.indexOf("\\");
                // IE��������
                if (index > 0 && !file.exists()) {
                    /* �e�h�k�d���݂��Ă��܂���̎��G���[*/
                    Messages errors = new Messages();
                    BmaValidator.addMessage(errors, "fileErr", BmaText.E00045, "�t�@�C��");
                    inSession.setErrors(errors);
                    return FWD_NM_RELOAD;
                }
                /* �t�@�C�����`�F�b�N */
                if (!validateFileName(inRequest, inSession, dataName)) {
                    /*�G���[���������ꍇ�͍ĕ\��*/
                    return FWD_NM_RELOAD;
                }
                /* �t�@�C���T�C�Y�`�F�b�N */
                if (!validateImportFile(inRequest, inSession)) {
                    /*�G���[���������ꍇ�͍ĕ\��*/
                    return FWD_NM_RELOAD;
                }
                //�A�b�v���[�h
                importJknJkuNo(inRequest, inSession);
                
                //DL��UL�̃`�F�b�N
                /* �_�E�����[�h�f�[�^�擾 */
                Moshikomi mc = new Moshikomi(DATA_SOURCE_NAME);
                ArrayList<Moshikomi> moshikomiList = mc.findTmpJohoList(inSession);
                
                if (moshikomiList.size() != inSession.getNumJkoJknList().size()) {
                    Messages errors = new Messages();
                    BmaValidator.addMessage(errors, "DLULErr", BmaText.E00115, "");
                    inSession.setErrors(errors);
                    return FWD_NM_RELOAD;
                }
                
                return FWD_NM_CONFIRM;

            } else if (!BmaUtility.isNullOrEmpty(inRequest.getJknJkuNoKakuninKakutei())) {
                /*�u�m��v�{�^��������*/
                processName = "NumJkoJknComplete";
                dataName = "�󌟎�u�ԍ��f�[�^";
                log.Start(processName);
                //�G���[������ꍇ�Acsv�f�[�^���_�E�����[�h
                if (!inSession.getErrorLog().isEmpty()) {
                    createCsv(inRequest, inSession, dataName);
                    log.error("�󌟎�u�ԍ��f�[�^�A�b�v���[�h�@�G���[���O�o��");

                    return DOWNLOAD;
                } else {
                    //DB�X�V  
                    if (updateJknJkoData(inSession)) {
                        log.info("�󌟎�u�ԍ��f�[�^�A�b�v���[�h����I��");
                        /* �u�ԍ��Ǘ��v�t�^������ʕ\�� */
                        return FWD_NM_COMPLETE;
                    } else {
                        log.info("�󌟎�u�ԍ��f�[�^�A�b�v���[�h�ُ�I��");
                        /* �G���[��ʕ\�� */
                        return FWD_NM_EXCEPTION;
                    }
                }
            } else if (!BmaUtility.isNullOrEmpty(inRequest.getGokakuNoFuyo())) {
                /*�u���i�ԍ��t�^�v�{�^��������*/
                processName = "NumGokakuUpload";
                log.Start(processName);

                /*  �����^�u�K��̃��W�I�{�^�������擾 */
                inSession.setSknKbnList(findSknKsuList(BmaConstants.SKN_KBN));
                inSession.setKsuKbnList(findSknKsuList(BmaConstants.KSU_KBN));

                /* �u�󌟁^��u�ԍ��A�b�v���[�h�v��ʕ\�� */
                return "gokakuUpload";

            } else if (!BmaUtility.isNullOrEmpty(inRequest.getGokakuNoTmpDl())) {
                /*�u�e���v���[�g�_�E�����[�h�v�{�^��������*/
                processName = "gokakuNo";
                log.Start(processName);
                /* ���̓f�[�^�Z�b�g */
                setValueRequestToSession(inRequest, inSession);

                /* ����/�u�K��擾 */
                findsknKsuNameChi(inSession);

                /* �_�E�����[�h�f�[�^�擾 */
                Moshikomi mc = new Moshikomi(DATA_SOURCE_NAME);
                ArrayList<Moshikomi> moshikomiList = mc.findTmpJohoList(inSession);
                inSession.setResultDetailList(moshikomiList);
                inSession.setGokakuNoTmpDl("gokakuNoTmpDl");

                /* �_�E�����[�h */
                return "gokakuNoTmpDl";

            } else if (!BmaUtility.isNullOrEmpty(inRequest.getGokakuNoUl())) {
                /*�u�A�b�v���[�h�v�{�^�������� */
                processName = "NumGokakuConfirm";
                dataName = "���i�ԍ��f�[�^";
                log.Start(processName);
                //�G���[���O������
                List<NumKanriJoho> errorLog = new ArrayList<>();
                inSession.setErrorLog(errorLog);
                inSession.setErrorLogFlg(Constants.FLG_OFF);

                /* ���͒l���Z�b�V�����ɕۑ� */
                setValueRequestToSession(inRequest, inSession);
                /* ����/�u�K��擾 */
                findsknKsuNameChi(inSession);
                // �t�@�C���擾
                String fileName = inRequest.getFileData().getName();
                File file = new File(fileName);
                // PATH���t���Ă���̃t�@�C���̂ݔ��f����
                int index = fileName.indexOf("\\");
                // IE��������
                if (index > 0 && !file.exists()) {
                    /* �e�h�k�d���݂��Ă��܂���̎��G���[*/
                    Messages errors = new Messages();
                    BmaValidator.addMessage(errors, "fileErr", BmaText.E00045, "�t�@�C��");
                    inSession.setErrors(errors);
                    return FWD_NM_RELOAD;
                }
                /* �t�@�C�����`�F�b�N */
                if (!validateFileName(inRequest, inSession, dataName)) {
                    /*�G���[���������ꍇ�͍ĕ\��*/
                    return FWD_NM_RELOAD;
                }
                /* �t�@�C���T�C�Y�`�F�b�N */
                if (!validateImportFile(inRequest, inSession)) {
                    /*�G���[���������ꍇ�͍ĕ\��*/
                    return FWD_NM_RELOAD;
                }
                //�C���|�[�g
                importGokakuNo(inRequest, inSession);
                
                //DL��UL�̃`�F�b�N
                /* �_�E�����[�h�f�[�^�擾 */
                Moshikomi mc = new Moshikomi(DATA_SOURCE_NAME);
                ArrayList<Moshikomi> moshikomiList = mc.findTmpJohoList(inSession);
                
                if (moshikomiList.size() != inSession.getNumGokakuList().size()) {
                    Messages errors = new Messages();
                    BmaValidator.addMessage(errors, "DLULErr", BmaText.E00115, "");
                    inSession.setErrors(errors);
                    return FWD_NM_RELOAD;
                }

                return FWD_NM_CONFIRM;

            } else if (!BmaUtility.isNullOrEmpty(inRequest.getGokakuNoKakuninKakutei())) {
                /*�u�m��v�{�^�������� */
                processName = "NumGokakuComplete";
                dataName = "���i�ԍ��f�[�^";
                log.Start(processName);
                //�G���[������ꍇ�Acsv�f�[�^���_�E�����[�h
                if (!inSession.getErrorLog().isEmpty()) {
                    createCsv(inRequest, inSession, dataName);
                    log.error("���i�ԍ��f�[�^�A�b�v���[�h�@�G���[���O�o��");

                    return DOWNLOAD;
                } else {
                    //DB�X�V  
                    if (updateGokakuData(inSession)) {
                        log.info("���i�ԍ��f�[�^�A�b�v���[�h����I��");
                        /* �u�ԍ��Ǘ��v�t�^������ʕ\�� */
                        return FWD_NM_COMPLETE;
                    } else {
                        log.info("���i�ԍ��f�[�^�A�b�v���[�h�ُ�I��");
                        /* �G���[��ʕ\�� */
                        return FWD_NM_EXCEPTION;
                    }
                }
            } else if (!BmaUtility.isNullOrEmpty(inRequest.getJknJkuNoKakuninBack())) {
                /*�u�߂�v�{�^��������*/
                processName = "NumJkoJknConfirmBack";
                log.Start(processName);
                /* �߂� */
                return FWD_NM_BACK;
            } else if (!BmaUtility.isNullOrEmpty(inRequest.getGokakuNoKakuninBack())) {
                /*�u�߂�v�{�^��������*/
                processName = "NumGokakuConfirmBack";
                log.Start(processName);
                /* �߂� */
                return FWD_NM_BACK;
            } else {
                /*�ُ�J��*/
                log.IllegalFWD();
                return FWD_NM_SESSION;
            }
        } catch (Exception e) {
            throw e;
        } finally {
            log.End(processName);
        }
    }
    
    /**
     * �����u�K���X�g���擾����
     * @param sknksuKbn
     * @return
     */
    public List<Option> findSknKsuList(String sknksuKbn) {
        List<Option> list = new ArrayList<>();
        //�����u�K���X�g��p�ӂ���
        SknksuMst sknksuMst = new SknksuMst(BmaConstants.DS_REGISTRANT);
        sknksuMst.findBySknKsuKbn(sknksuKbn, list);
        return list;
    }
    
    /**
     * ���̓f�[�^���Z�b�V�����f�[�^�ɃZ�b�g����B
     * @param inRequest ���N�G�X�g��̓��̓f�[�^
     * @param inSession �Z�b�V������̓��̓f�[�^
     */
    private void setValueRequestToSession(NumKanriJoho inRequest, NumKanriJoho inSession) {
        String sknksuName = "";
        
        if (BmaConstants.SKN_KBN.equals(inRequest.getSknksuKbn())) {
            sknksuName = inRequest.getSknName();
        } else if (BmaConstants.KSU_KBN.equals(inRequest.getSknksuKbn())) {
            sknksuName = inRequest.getKsuName();
        }
        inSession.setSknksuKbn(inRequest.getSknksuKbn());
        inSession.setSknKsuCode(sknksuName.substring(0, 2));
        inSession.setShubetsuCode(sknksuName.substring(2, 4));
        inSession.setKaisuCode(sknksuName.substring(4, 6));

        /* �N�x�擾 */
        Schedule schedule = new Schedule(BmaConstants.DS_REGISTRANT);
        String nendo = schedule.findNendoKojiKikan(inSession.getSknKsuCode(), inSession.getShubetsuCode(), inSession.getKaisuCode(), BmaConstants.SCHED_CODE_OPEN, BmaConstants.SCHEDULE_KBN_ST);
        inSession.setNendo(nendo);
    }
    
    /**
     * �t�@�C���̃T�C�Y�`�F�b�N
     *
     * @param chusenKekkaImportInSession
     * @return �`�F�b�N�n�j�̏ꍇ�Atrue
     */
    private boolean validateImportFile(NumKanriJoho inRequest, NumKanriJoho inSession) {
        Messages errors = new Messages();

        String itemName;
        String groupCode;

        groupCode = "fileErr";
        itemName = "�t�@�C���T�C�Y";
        // �t�@�C���擾
        FileItem fItem = inRequest.getFileData();

        /* �t�@�C���T�C�Y�`�F�b�N */
            if (!BmaValidator.validateFileSize(fItem.getSize(),
                    CSV_SIZE, errors, groupCode, itemName)) {
                /* ����l���I�[�o�[�����ꍇ�G���[ */
                inSession.setErrors(errors);
                return false;
            }
            return true;
    }
    
    /**
     * �t�@�C����ǂݍ���
     *
     * @param inRequest
     * @param inSession
     * @return �C���|�[�g�����̏ꍇ�Atrue
     * @throws Exception
     */
    private void importJknJkuNo(NumKanriJoho inRequest, NumKanriJoho inSession) {
        List<NumKanriJoho> numJkoJknList = new ArrayList<>();
        List<NumKanriJoho> errorLog = new ArrayList<>();
        ArrayList uketsukeNoList = new ArrayList();
        ArrayList jknJkuNoList = new ArrayList();

        // �t�@�C���擾
        FileItem fItem = inRequest.getFileData();
        String line;
        int rowCount = 0;

        if (!(fItem.isFormField())) {
            BufferedReader bufferedReader = null;
            try {
                bufferedReader = new BufferedReader(new InputStreamReader(fItem.getInputStream(), BmaConstants.ENCODE_WINDOWS_31J));

                String[] lineArray;

                //�t�@�C���ŏI�s�܂ŌJ��Ԃ�
                while ((line = bufferedReader.readLine()) != null) {
                    Messages errors = new Messages();
                    rowCount++;
                    String tempStr = line;

                    //�t�@�C�����e��String�z��ɕϊ�
                    if (tempStr.endsWith("\"")) {
                        tempStr = tempStr.replaceAll("^\"|\"$", "");
                        lineArray = tempStr.split("\",\"", -1);
                        tempStr = "";
                    } else {
                        lineArray = tempStr.split(",", -1);
                        tempStr = "";
                    }

                    // ���ڐ��`�F�b�N
                    if (lineArray.length != JKO_JKN_LENGTH) {
                        BmaValidator.addMessage(errors, "info", BmaText.E00060, lineArray[0]);
                        log.info("���ڐ��G���[�i" + rowCount + "�s�ځj");
                        inSession.setErrors(errors);
                    }
                    // �t�@�C�����ڃ`�F�b�N
                    if (!inputJkoJknCheck(lineArray, errors, rowCount+3, errorLog, inSession, uketsukeNoList, jknJkuNoList)) {
                        inSession.setErrors(errors);
                        inSession.setErrorLog(errorLog);
                        inSession.setErrorLogFlg(Constants.FLG_ON);
                    }

                    // �󌟁^��u�ԍ��o�^����
                    NumKanriJoho joho = new NumKanriJoho();

                    /* ���ڃZ�b�g */
                    // �����u�K��R�[�h
                    joho.setSknKsuCode(lineArray[0]);
                    // ��ʃR�[�h
                    joho.setShubetsuCode(lineArray[1]);
                    // �񐔃R�[�h
                    joho.setKaisuCode(lineArray[2]);
                    // �N�x
                    joho.setNendo(lineArray[3]);
                    // ��t�ԍ�
                    joho.setUketukeNo(lineArray[4]);
                    //����
                    joho.setSimei(lineArray[5]);
                    // �󌟎�u�ԍ�
                    joho.setJknJkuNo(lineArray[6]);
                    // ���ID�i�w�ȁj
                    joho.setKaijoCode1(lineArray[7]);
                    // ���ID�i���Z�j
                    joho.setKaijoCode2(lineArray[8]);

                    numJkoJknList.add(joho);
                }
                
                inSession.setNumJkoJknList(numJkoJknList);
                // ���O�o��
                log.info("��������" + String.valueOf(rowCount));
            } catch (Exception e) {
                log.error(CLASS_NAME + ".importFile()�ŗ�O����", e);
            } finally {
                if (bufferedReader != null) {
                    // bufferedReader.close();
                }
            }
        }
    }
    
    /**
     * �t�@�C�������`�F�b�N����
     *
     * @param lineArray
     * @param errors
     * @param rowCount
     * @return �`�F�b�N�n�j�̏ꍇ�Atrue
     */
    private boolean inputJkoJknCheck(String[] lineArray, Messages errors, int rowCount, List<NumKanriJoho> errorLog, NumKanriJoho inSession, ArrayList uketsukeNoList, ArrayList jknJkuNoList) {

        String groupCode = "";
        String itemName = "";

        /* �����u�K��R�[�h */
        groupCode = "SKN_KSU_CODE";
        itemName = "�����u�K��R�[�h";
        // �K�{
        if (!BmaValidator.validateRequired1(lineArray[0], errors, groupCode, "")) {
            this.createErrorLine(rowCount, "C", itemName, errors, errorLog);
        }
        // �w�蕶����
        if (!BmaValidator.validateEqualLength1(lineArray[0], 2, errors, groupCode, "")) {
            this.createErrorLine(rowCount, "C", itemName, errors, errorLog);
        }
        // �I���ƕs��v
        if (BmaValidator.validateMessageCheck(errors, groupCode)) {
            if (!inSession.getSknKsuCode().equals(lineArray[0])) {
                BmaValidator.addMessage(errors, groupCode, BmaText.E00118, "");
                this.createErrorLine(rowCount, "C", itemName, errors, errorLog);
            }
        }

        /* ��ʃR�[�h */
        groupCode = "SHUBETSU_CODE";
        itemName = "��ʃR�[�h";
        // �K�{
        if (!BmaValidator.validateRequired1(lineArray[1], errors, groupCode, "")) {
            this.createErrorLine(rowCount, "D", itemName, errors, errorLog);
        }
        // �w�蕶����
        if (!BmaValidator.validateEqualLength1(lineArray[1], 2, errors, groupCode, "")) {
            this.createErrorLine(rowCount, "D", itemName, errors, errorLog);
        }
        // �I���ƕs��v
        if (BmaValidator.validateMessageCheck(errors, groupCode)) {
            if (!inSession.getShubetsuCode().equals(lineArray[1])) {
                BmaValidator.addMessage(errors, groupCode, BmaText.E00118, "");
                this.createErrorLine(rowCount, "D", itemName, errors, errorLog);
            }
        }
        
        /* �񐔃R�[�h */
        groupCode = "KAISU_CODE";
        itemName = "�񐔃R�[�h";
        // �K�{
        if (!BmaValidator.validateRequired1(lineArray[2], errors, groupCode, "")) {
            this.createErrorLine(rowCount, "E", itemName, errors, errorLog);
        }
        // �w�蕶����
        if (!BmaValidator.validateEqualLength1(lineArray[2], 2, errors, groupCode, "")) {
            this.createErrorLine(rowCount, "E", itemName, errors, errorLog);
        }
        // �I���ƕs��v
        if (BmaValidator.validateMessageCheck(errors, groupCode)) {
            if (!inSession.getKaisuCode().equals(lineArray[2])) {
                BmaValidator.addMessage(errors, groupCode, BmaText.E00118, "");
                this.createErrorLine(rowCount, "E", itemName, errors, errorLog);
            }
        }
        
        /* �N�x */
        groupCode = "NENDO";
        itemName = "�N�x";
        // �K�{
        if (!BmaValidator.validateRequired1(lineArray[3], errors, groupCode, "")) {
            this.createErrorLine(rowCount, "F", itemName, errors, errorLog);
        }
        // �w�蕶����
        if (!BmaValidator.validateEqualLength1(lineArray[3], 4, errors, groupCode, "")) {
            this.createErrorLine(rowCount, "F", itemName, errors, errorLog);
        }
        // �N�x�s��v
        if (BmaValidator.validateMessageCheck(errors, groupCode)) {
            if (!inSession.getNendo().equals(lineArray[3])) {
                BmaValidator.addMessage(errors, groupCode, BmaText.E00119, "");
                this.createErrorLine(rowCount, "F", itemName, errors, errorLog);
            }
        }
        
        /* ��t�ԍ� */
        groupCode = "UKETSUKE_NO";
        itemName = "��t�ԍ�";
        // �K�{
        if (!BmaValidator.validateRequired1(lineArray[4], errors, groupCode, "")) {
            this.createErrorLine(rowCount, "G", itemName, errors, errorLog);
        }
        // �w�蕶����
        if (!BmaValidator.validateEqualLength1(lineArray[4], 10, errors, groupCode, "")) {
            this.createErrorLine(rowCount, "G", itemName, errors, errorLog);
        }
        // ���l�`�F�b�N
        if (!BmaValidator.validateNumber1(lineArray[4], errors, groupCode, "")) {
            this.createErrorLine(rowCount, "G", itemName, errors, errorLog);
        }
        // �d���`�F�b�N�iCSV�j
        if (uketsukeNoList.contains(lineArray[4])) {
            BmaValidator.addMessage(errors, groupCode, BmaText.E00101, "");
            this.createErrorLine(rowCount, "G", itemName, errors, errorLog);
        } else {
            uketsukeNoList.add(lineArray[4]);
        }
        
        /* ���� */
        groupCode = "SHIMEI";
        itemName = "����";
        // �K�{
        if (!BmaValidator.validateRequired1(lineArray[5], errors, groupCode, "")) {
            this.createErrorLine(rowCount, "H", itemName, errors, errorLog);
        }
        
        /* �󌟎�u�ԍ� */
        groupCode = "JUKEN_JUKO_NO";
        itemName = "�󌟎�u�ԍ�";
        // �K�{
        if (!BmaValidator.validateRequired1(lineArray[6], errors, groupCode, "")) {
            this.createErrorLine(rowCount, "I", itemName, errors, errorLog);
        }
        // �ő啶����
        if (!BmaValidator.validateMaxLength1(lineArray[6], 20, errors, groupCode, "")) {
            this.createErrorLine(rowCount, "I", itemName, errors, errorLog);
        }
        // �̔ԃ��[���@�r���N�A�r���݁A�a�@�A�C���y�N ��
        if (BmaValidator.validateMessageCheck(errors, groupCode)) {
            if (BmaConstants.SKN_KBN.equals(inSession.getSknksuKbn())) {
                //10���̏ꍇ
                if ("A".equals(lineArray[6].substring(0, 1))) {
                    if (!lineArray[6].substring(2, 4).equals(inSession.getNendo().substring(2, 4))
                            || !lineArray[6].substring(5, 6).equals(inSession.getShubetsuCode().substring(1, 2))
                            || !CheckUtility.isNumber(lineArray[6].substring(6, 10))) {
                        BmaValidator.addMessage(errors, groupCode, BmaText.E00116, "");
                        this.createErrorLine(rowCount, "I", itemName, errors, errorLog);
                    }
                } else {
                    //9���̏ꍇ
                    if (!lineArray[6].substring(1, 3).equals(inSession.getNendo().substring(2, 4))
                            || !lineArray[6].substring(4, 5).equals(inSession.getShubetsuCode().substring(1, 2))
                            || !CheckUtility.isNumber(lineArray[6].substring(5, 9))) {
                        BmaValidator.addMessage(errors, groupCode, BmaText.E00116, "");
                        this.createErrorLine(rowCount, "I", itemName, errors, errorLog);
                    }
                }
            } else if (BmaConstants.KSU_KBN.equals(inSession.getSknksuKbn())) {
                if ("HC".equals(inSession.getSknKsuCode())) {
                    if (!lineArray[6].substring(2, 4).equals(inSession.getNendo().substring(2, 4))
                            || !CheckUtility.isNumber(lineArray[6].substring(5, 9))) {
                        BmaValidator.addMessage(errors, groupCode, BmaText.E00116, "");
                        this.createErrorLine(rowCount, "I", itemName, errors, errorLog);
                    }
                } else if ("IP".equals(inSession.getSknKsuCode())) {
                    if (!lineArray[6].substring(2, 4).equals(inSession.getNendo().substring(2, 4))
                            || !CheckUtility.isNumber(lineArray[6].substring(6, 9))) {
                        BmaValidator.addMessage(errors, groupCode, BmaText.E00116, "");
                        this.createErrorLine(rowCount, "I", itemName, errors, errorLog);
                    }
                }
            }
        }
        
        if (BmaValidator.validateMessageCheck(errors, groupCode)) {
            // �d���`�F�b�N�iCSV�j
            if (jknJkuNoList.contains(lineArray[6])) {
                BmaValidator.addMessage(errors, groupCode, BmaText.E00101, "");
                this.createErrorLine(rowCount, "I", itemName, errors, errorLog);
            } else {
                jknJkuNoList.add(lineArray[6]);
            }
            // �d���`�F�b�N�iDB�j
            Moshikomi mc = new Moshikomi(DATA_SOURCE_NAME);
            Moshikomi moshikomi = mc.findByJukenJukoNo(inSession.getSknKsuCode(), inSession.getShubetsuCode(), inSession.getKaisuCode() ,inSession.getNendo(), lineArray[6]);
            if (moshikomi != null) {
                BmaValidator.addMessage(errors, groupCode, BmaText.E00101, "");
                this.createErrorLine(rowCount, "I", itemName, errors, errorLog);
            }
        }
        
        /* ���ID�i�w�ȁj */
        groupCode = "KAIJO_ID1";
        itemName = "���ID�i�w�ȁj";
        //�����̂�
        if (BmaConstants.SKN_KBN.equals(inSession.getSknksuKbn())) {
            // �K�{
            if (!BmaValidator.validateRequired1(lineArray[7], errors, groupCode, "")) {
                this.createErrorLine(rowCount, "J", itemName, errors, errorLog);
            }
            // �w�蕶����
            if (!BmaValidator.validateEqualLength1(lineArray[7], 2, errors, groupCode, "")) {
                this.createErrorLine(rowCount, "J", itemName, errors, errorLog);
            }
            //���l�`�F�b�N
            if (!BmaValidator.validateNumber1(lineArray[7], errors, groupCode, "")) {
                this.createErrorLine(rowCount, "J", itemName, errors, errorLog);
            }
            if (BmaValidator.validateMessageCheck(errors, groupCode)) {
                // �g�p��������
                ShiyoKaijo shiyoKaijo = new ShiyoKaijo(DATA_SOURCE_NAME);
                ShiyoKaijo shiyoKaijo1 = shiyoKaijo.findKaijo(lineArray[3], lineArray[0], lineArray[1], lineArray[2], lineArray[7], BmaConstants.KAIJO_SHIKEN_KBN_GAKKA);
                if (shiyoKaijo1 == null) {
                    BmaValidator.addMessage(errors, groupCode, BmaText.E00022, "");
                    this.createErrorLine(rowCount, "J", itemName, errors, errorLog);
                }
            }
        } else if (BmaConstants.KSU_KBN.equals(inSession.getSknksuKbn())) {
            if (!lineArray[7].isEmpty()) {
                BmaValidator.addMessage(errors, groupCode, BmaText.E00106, "");
                this.createErrorLine(rowCount, "J", itemName, errors, errorLog);
            }
        }

        /* ���ID�i���Z�j */
        groupCode = "KAIJO_ID2";
        itemName = "���ID�i���Z�j";
        //�����̂݃`�F�b�N����
        if (BmaConstants.SKN_KBN.equals(inSession.getSknksuKbn())) {
            if (!BmaValidator.validateRequired1(lineArray[8], errors, groupCode, "")) {
                this.createErrorLine(rowCount, "K", itemName, errors, errorLog);
            }
            // �w�蕶����
            if (!BmaValidator.validateEqualLength1(lineArray[8], 2, errors, groupCode, "")) {
                this.createErrorLine(rowCount, "K", itemName, errors, errorLog);
            }
            //���l�`�F�b�N
            if (!BmaValidator.validateNumber1(lineArray[8], errors, groupCode, "")) {
                this.createErrorLine(rowCount, "K", itemName, errors, errorLog);
            }
            if (BmaValidator.validateMessageCheck(errors, groupCode)) {
                // �g�p��������
                ShiyoKaijo shiyoKaijo = new ShiyoKaijo(DATA_SOURCE_NAME);
                ShiyoKaijo shiyoKaijo2 = shiyoKaijo.findKaijo(lineArray[3], lineArray[0], lineArray[1], lineArray[2], lineArray[8], BmaConstants.KAIJO_SHIKEN_KBN_ZITSUGI);
                if (shiyoKaijo2 == null) {
                    BmaValidator.addMessage(errors, groupCode, BmaText.E00022, "");
                    this.createErrorLine(rowCount, "K", itemName, errors, errorLog);
                }
            }
        } else if (BmaConstants.KSU_KBN.equals(inSession.getSknksuKbn())) {
            if (!lineArray[8].isEmpty()) {
                BmaValidator.addMessage(errors, groupCode, BmaText.E00106, "");
                this.createErrorLine(rowCount, "K", itemName, errors, errorLog);
            }
        }

        if (!errors.isEmpty()) {
            return false;
        } else {
            return true;
        }

    }

    /**
     * �����u�K���X�g���擾����
     * @param inSession
     */
    public void findsknKsuNameChi(NumKanriJoho inSession) {
        /*����/�u�K��擾*/
        SknksuMst sknksuMst = new SknksuMst(BmaConstants.DS_REGISTRANT);
        String sknKsuNameChi = sknksuMst.findSknKsuNameRyaku(inSession.getSknKsuCode(),
                inSession.getShubetsuCode(), inSession.getKaisuCode()).getSknKsuNameRyaku();

        inSession.setSknKsuNameChi(sknKsuNameChi);
    }
     
    /**
     * �t�@�C�����`�F�b�N
     *
     * @param inSession �Z�b�V����RTO
     * @return true:�G���[��
     */
    private boolean validateFileName(NumKanriJoho inRequest, NumKanriJoho inSession, String dataName) {
        Messages errors = new Messages();

        String itemName;
        String groupCode;

        groupCode = "fileErr";
        itemName = "�t�@�C�� ";
        String fileName = inRequest.getFileData().getName();
        if (BmaUtility.isNullOrEmpty(fileName)) {
            BmaValidator.checkNull(errors, groupCode, itemName);
        }
        String ext = BmaFileUtility.getExtension(fileName);
        // �t�@�C�����̂̐������`�F�b�N
        if (!BmaUtility.isNullOrEmpty(ext) && !fileName.contains(dataName)) {
            BmaValidator.addMessage(errors, groupCode, "�t�@�C�����̂��s���ł�");
        }
        if (!BmaUtility.isNullOrEmpty(ext) && !"csv".equals(ext)) {
            BmaValidator.addMessage(errors, groupCode, BmaText.E00070);
        }

        inSession.setErrors(errors);
        return errors.isEmpty();
    }
    
    /**
     * �G���[�̃`�F�b�N�@iterator���\�b�h�@hasNext()�̑��
     * @param errors Messages�I�u�W�F�N�g
     * @param errorsGroup Messages�̃O���[�v��
     * @return
     */
    public static boolean validateMessageCheck(Messages errors, String errorsGroup) {
        if (errors.get(errorsGroup) != null) {
            if (!errors.get(errorsGroup).getMessage().isEmpty()) {
                return false;
            }
        }
        return true;
    }
     
    /**
     * �󌟎�u�f�[�^��update����B
     *
     * @param inSession
     * @return 
     */
    public boolean updateJknJkoData(NumKanriJoho inSession) {

        try {
            //�g�����U�N�V�����J�n
            getTransaction();
            beginTransaction();
            SystemTime sysTim = new SystemTime();

            for (NumKanriJoho row : inSession.getNumJkoJknList()) {

                // �\��������������
                Moshikomi moshikomi = new Moshikomi(DATA_SOURCE_NAME);
                // �\���ύX����
                MoshikomiHenkoRireki moshikomiHenkoRireki = new MoshikomiHenkoRireki(DATA_SOURCE_NAME);
                /* �\����񂩂�\�����ɒl���R�s�[ */
                BeanUtils.copyProperties(moshikomi, moshikomi.find(row.getNendo(), row.getUketukeNo()));
                /* �\����񂩂�\���ύX�������ɒl���R�s�[ */
                BeanUtils.copyProperties(moshikomiHenkoRireki, moshikomi);
                /* �o�^���Z�b�g */
                setMoshikomihenkoTrk(moshikomiHenkoRireki, inSession);
                /*�C���T�[�g���s*/
                moshikomiHenkoRireki.create();

                // �g�p��������
                ShiyoKaijo shiyoKaijo = new ShiyoKaijo(DATA_SOURCE_NAME);

                if (BmaConstants.SKN_KBN.equals(inSession.getSknksuKbn())) {
                    moshikomi.setKaijoId1(row.getKaijoCode1());
                    moshikomi.setKaijoId2(row.getKaijoCode2());
                    moshikomi.setKaisaichiCode1(shiyoKaijo.findKaijo(row.getNendo(), row.getSknKsuCode(), row.getShubetsuCode(), row.getKaisuCode(), row.getKaijoCode1(), BmaConstants.KAIJO_SHIKEN_KBN_GAKKA).getKaisaichiCode());
                    moshikomi.setKaisaichiCode2(shiyoKaijo.findKaijo(row.getNendo(), row.getSknKsuCode(), row.getShubetsuCode(), row.getKaisuCode(), row.getKaijoCode2(), BmaConstants.KAIJO_SHIKEN_KBN_ZITSUGI).getKaisaichiCode());
                    moshikomi.setKaijoCode1(shiyoKaijo.findKaijo(row.getNendo(), row.getSknKsuCode(), row.getShubetsuCode(), row.getKaisuCode(), row.getKaijoCode1(), BmaConstants.KAIJO_SHIKEN_KBN_GAKKA).getKaijoCode());
                    moshikomi.setKaijoCode2(shiyoKaijo.findKaijo(row.getNendo(), row.getSknKsuCode(), row.getShubetsuCode(), row.getKaisuCode(), row.getKaijoCode2(), BmaConstants.KAIJO_SHIKEN_KBN_ZITSUGI).getKaijoCode());
                }
                moshikomi.setJukenJukoNo(row.getJknJkuNo());
                moshikomi.setKoshinDate(sysTim.getymd1());
                moshikomi.setKoshinTime(sysTim.gethms1());
                moshikomi.setKoshinKbn(BmaConstants.SHORI_KBN_UPDATE);
                moshikomi.setKoshinUserId(inSession.getMoshikomishaId());

                moshikomi.update();
            }
            // �g�����U�N�V�������R�~�b�g����
            commitTransaction();
            inSession.setJknJkuNoFuyoKensu(String.valueOf(inSession.getNumJkoJknList().size()));

            return true;

        } catch (Exception e) {
            rollbackTransaction();
            log.info("�b�r�u�f�[�^�捞�����ŗ�O������", e);
            return false;
        }
    }
    
    /**
     * �t�@�C����ǂݍ��݁A���i�ԍ��f�[�^���C���T�[�g
     *
     * @param inRequest
     * @param inSession
     * @return �C���|�[�g�����̏ꍇ�Atrue
     * @throws Exception
     */
    private void importGokakuNo(NumKanriJoho inRequest, NumKanriJoho inSession) {
        List<NumKanriJoho> numGokakuList = new ArrayList<>();
        List<NumKanriJoho> errorLog = new ArrayList<>();
        ArrayList jknJkuNoList = new ArrayList();
        ArrayList gokakuNoList = new ArrayList();

        // �t�@�C���擾
        FileItem fItem = inRequest.getFileData();
        String line;
        int rowCount = 0;

        if (!(fItem.isFormField())) {
            BufferedReader bufferedReader = null;
            try {
                bufferedReader = new BufferedReader(new InputStreamReader(fItem.getInputStream(), BmaConstants.ENCODE_WINDOWS_31J));

                String[] lineArray;

                //�t�@�C���ŏI�s�܂ŌJ��Ԃ�
                while ((line = bufferedReader.readLine()) != null) {
                    Messages errors = new Messages();
                    rowCount++;
                    String tempStr = line;

                    //�t�@�C�����e��String�z��ɕϊ�
                    if (tempStr.endsWith("\"")) {
                        tempStr = tempStr.replaceAll("^\"|\"$", "");
                        lineArray = tempStr.split("\",\"", -1);
                        tempStr = "";
                    } else {
                        lineArray = tempStr.split(",", -1);
                        tempStr = "";
                    }

                    // ���ڐ��`�F�b�N
                    if (lineArray.length != GOKAKU_LENGTH) {
                        BmaValidator.addMessage(errors, "info", BmaText.E00060, lineArray[0]);
                        log.info("���ڐ��G���[�i" + rowCount + "�s�ځj");
                        inSession.setErrors(errors);
                    }
                    // �t�@�C�����ڃ`�F�b�N
                    if (!inputGokakuCheck(lineArray, errors, rowCount+3, errorLog, inSession, jknJkuNoList, gokakuNoList)) {
                        inSession.setErrors(errors);
                        inSession.setErrorLog(errorLog);
                        inSession.setErrorLogFlg(Constants.FLG_ON);
                    }

                    // ���i�ԍ��o�^����
                    NumKanriJoho joho = new NumKanriJoho();

                    /* ���ڃZ�b�g */
                    // �����u�K��R�[�h
                    joho.setSknKsuCode(lineArray[0]);
                    // ��ʃR�[�h
                    joho.setShubetsuCode(lineArray[1]);
                    // �񐔃R�[�h
                    joho.setKaisuCode(lineArray[2]);
                    // �N�x
                    joho.setNendo(lineArray[3]);
                    // �󌟎�u�ԍ�
                    joho.setJknJkuNo(lineArray[4]);
                    //����
                    joho.setSimei(lineArray[5]);
                    // ���ی���
                    joho.setGohi(lineArray[6]);
                    // ���i�ԍ�
                    joho.setGokakuNo(lineArray[7]);
                    // �w�ȍ��i�ԍ�
                    joho.setGakkaGokakuNo(lineArray[8]);
                    // ���Z���i�ԍ�
                    joho.setJitsugiGokakuNo(lineArray[9]);
                    // ���i�ԍ��i�C���ԍ��j
                    joho.setShikakuNo(lineArray[10]);
                    // ���i�N����
                    joho.setGokakuBi(lineArray[11]);

                    numGokakuList.add(joho);
                }
                
                inSession.setNumGokakuList(numGokakuList);
                // ���O�o��
                log.info("��������" + String.valueOf(rowCount));
            } catch (Exception e) {
                log.error(CLASS_NAME + ".importFile()�ŗ�O����", e);
            } finally {
                if (bufferedReader != null) {
                    // bufferedReader.close();
                }
            }
        }
    }
    
    /**
     * ���i�ԍ�CSV�t�@�C�����`�F�b�N����
     *
     * @param lineArray
     * @param errors
     * @param rowCount
     * @return �`�F�b�N�n�j�̏ꍇ�Atrue
     */
    private boolean inputGokakuCheck(String[] lineArray, Messages errors, int rowCount, List<NumKanriJoho> errorLog, NumKanriJoho inSession, ArrayList jknJkuNoList, ArrayList gokakuNoList) {

        String groupCode = "";
        String itemName = "";
        MeishoKanri meishoKanri = new MeishoKanri(BmaConstants.DS_REGISTRANT);

        /* �����u�K��R�[�h */
        groupCode = "SKN_KSU_CODE";
        itemName = "�����u�K��R�[�h";
        // �K�{
        if (!BmaValidator.validateRequired1(lineArray[0], errors, groupCode, "")) {
            this.createErrorLine(rowCount, "C", itemName, errors, errorLog);
        }
        // �w�蕶����
        if (!BmaValidator.validateEqualLength1(lineArray[0], 2, errors, groupCode, "")) {
            this.createErrorLine(rowCount, "C", itemName, errors, errorLog);
        }
        // �I���ƕs��v
        if (BmaValidator.validateMessageCheck(errors, groupCode)) {
            if (!inSession.getSknKsuCode().equals(lineArray[0])) {
                BmaValidator.addMessage(errors, groupCode, BmaText.E00118, "");
                this.createErrorLine(rowCount, "C", itemName, errors, errorLog);
            }
        }

        /* ��ʃR�[�h */
        groupCode = "SHUBETSU_CODE";
        itemName = "��ʃR�[�h";
        // �K�{
        if (!BmaValidator.validateRequired1(lineArray[1], errors, groupCode, "")) {
            this.createErrorLine(rowCount, "D", itemName, errors, errorLog);
        }
        // �w�蕶����
        if (!BmaValidator.validateEqualLength1(lineArray[1], 2, errors, groupCode, "")) {
            this.createErrorLine(rowCount, "D", itemName, errors, errorLog);
        }
        // �I���ƕs��v
        if (BmaValidator.validateMessageCheck(errors, groupCode)) {
            if (!inSession.getShubetsuCode().equals(lineArray[1])) {
                BmaValidator.addMessage(errors, groupCode, BmaText.E00118, "");
                this.createErrorLine(rowCount, "D", itemName, errors, errorLog);
            }
        }

        /* �񐔃R�[�h */
        groupCode = "KAISU_CODE";
        itemName = "�񐔃R�[�h";
        // �K�{
        if (!BmaValidator.validateRequired1(lineArray[2], errors, groupCode, "")) {
            this.createErrorLine(rowCount, "E", itemName, errors, errorLog);
        }
        // �w�蕶����
        if (!BmaValidator.validateEqualLength1(lineArray[2], 2, errors, groupCode, "")) {
            this.createErrorLine(rowCount, "E", itemName, errors, errorLog);
        }
        // �I���ƕs��v
        if (BmaValidator.validateMessageCheck(errors, groupCode)) {
            if (!inSession.getKaisuCode().equals(lineArray[2])) {
                BmaValidator.addMessage(errors, groupCode, BmaText.E00118, "");
                this.createErrorLine(rowCount, "E", itemName, errors, errorLog);
            }
        }

        /* �N�x */
        groupCode = "NENDO";
        itemName = "�N�x";
        // �K�{
        if (!BmaValidator.validateRequired1(lineArray[3], errors, groupCode, "")) {
            this.createErrorLine(rowCount, "F", itemName, errors, errorLog);
        }
        // �w�蕶����
        if (!BmaValidator.validateEqualLength1(lineArray[3], 4, errors, groupCode, "")) {
            this.createErrorLine(rowCount, "F", itemName, errors, errorLog);
        }
        // �N�x�s��v
        if (BmaValidator.validateMessageCheck(errors, groupCode)) {
            if (!inSession.getNendo().equals(lineArray[3])) {
                BmaValidator.addMessage(errors, groupCode, BmaText.E00119, "");
                this.createErrorLine(rowCount, "F", itemName, errors, errorLog);
            }
        }

        /* �󌟎�u�ԍ� */
        groupCode = "JUKEN_JUKO_NO";
        itemName = "�󌟎�u�ԍ�";
        // �K�{
        if (!BmaValidator.validateRequired1(lineArray[4], errors, groupCode, "")) {
            this.createErrorLine(rowCount, "G", itemName, errors, errorLog);
        }
        // �w�蕶����
        if (!BmaValidator.validateMaxLength1(lineArray[4], 20, errors, groupCode, "")) {
            this.createErrorLine(rowCount, "G", itemName, errors, errorLog);
        }
        if (BmaValidator.validateMessageCheck(errors, groupCode)) {
            //�d���`�F�b�N�iCSV�j
            if (jknJkuNoList.contains(lineArray[4])) {
                BmaValidator.addMessage(errors, groupCode, BmaText.E00101, "");
                this.createErrorLine(rowCount, "G", itemName, errors, errorLog);
            } else {
                jknJkuNoList.add(lineArray[4]);
            }
        }

        /* ���� */
        groupCode = "SHIMEI";
        itemName = "����";
        // �K�{
        if (!BmaValidator.validateRequired1(lineArray[5], errors, groupCode, "")) {
            this.createErrorLine(rowCount, "H", itemName, errors, errorLog);
        }

        /* ���ی��� */
        groupCode = "GOHI";
        itemName = "���ی���";
        // �K�{
        if (!BmaValidator.validateRequired1(lineArray[6], errors, groupCode, "")) {
            this.createErrorLine(rowCount, "I", itemName, errors, errorLog);
        }
        // �ő啶����
        if (!BmaValidator.validateMaxLength1(lineArray[6], 2, errors, groupCode, "")) {
            this.createErrorLine(rowCount, "I", itemName, errors, errorLog);
        }
        //�I��
        List<Option> list = new ArrayList<>();
        meishoKanri.findByGroupCode("GOHI_JOKYO_KBN", list);
        if (!BmaValidator.validatePermissionSelect3(lineArray[6], list, errors, groupCode, "")) {
            this.createErrorLine(rowCount, "I", itemName, errors, errorLog);
        }

        /* ���i�ԍ� */
        groupCode = "GOKAKUNO";
        itemName = "���i�ԍ�";
        //�����̂�
        //���ی��ʂŔ��f  01
        if (BmaConstants.SKN_KBN.equals(inSession.getSknksuKbn())) {
            if ("01".equals(lineArray[6])) {
                // �K�{
                if (!BmaValidator.validateRequired1(lineArray[7], errors, groupCode, "")) {
                    this.createErrorLine(rowCount, "K", itemName, errors, errorLog);
                }
                // �ő啶����
                if (!BmaValidator.validateMaxLength1(lineArray[7], 20, errors, groupCode, "")) {
                    this.createErrorLine(rowCount, "K", itemName, errors, errorLog);
                }
                if (BmaValidator.validateMessageCheck(errors, groupCode)) {
                    //�d���`�F�b�N�iCSV�j
                    if (gokakuNoList.contains(lineArray[7])) {
                        BmaValidator.addMessage(errors, groupCode, BmaText.E00101, "");
                        this.createErrorLine(rowCount, "K", itemName, errors, errorLog);
                    } else {
                        gokakuNoList.add(lineArray[7]);
                    }
                }
                //�̔ԃ��[��
                if (BmaValidator.validateMessageCheck(errors, groupCode)) {
                    if ("BC".equals(inSession.getSknKsuCode())) {
                        if (!lineArray[7].substring(1, 3).equals(inSession.getNendo().substring(2, 4))
                                || !lineArray[7].substring(4, 5).equals(inSession.getShubetsuCode().substring(1, 2))
                                || !lineArray[7].substring(6, 9).equals("120")
                                || !CheckUtility.isNumber(lineArray[7].substring(12, 16))) {
                            BmaValidator.addMessage(errors, groupCode, BmaText.E00116, "");
                            this.createErrorLine(rowCount, "K", itemName, errors, errorLog);
                        }
                    } else if ("BE".equals(inSession.getSknKsuCode())) {
                        if (!lineArray[7].substring(1, 3).equals(inSession.getNendo().substring(2, 4))
                                || !lineArray[7].substring(4, 5).equals(inSession.getShubetsuCode().substring(1, 2))
                                || !lineArray[7].substring(6, 9).equals("165")
                                || !CheckUtility.isNumber(lineArray[7].substring(12, 16))) {
                            BmaValidator.addMessage(errors, groupCode, BmaText.E00116, "");
                            this.createErrorLine(rowCount, "K", itemName, errors, errorLog);
                        }
                    }
                }
            } else {
                if (!lineArray[7].isEmpty()) {
                    BmaValidator.addMessage(errors, groupCode, BmaText.E00132, "");
                    this.createErrorLine(rowCount, "K", itemName, errors, errorLog);
                }
            }
            /* �w�ȍ��i�ԍ� */
            groupCode = "GAKKA_GOKAKUNO";
            itemName = "�w�ȍ��i�ԍ�";
            //�����̂�
            //���ی��ʂŔ��f  03
            if ("03".equals(lineArray[6])) {
                // �K�{
                if (!BmaValidator.validateRequired1(lineArray[8], errors, groupCode, "")) {
                    this.createErrorLine(rowCount, "L", itemName, errors, errorLog);
                }
                // �ő啶����
                if (!BmaValidator.validateMaxLength1(lineArray[8], 20, errors, groupCode, "")) {
                    this.createErrorLine(rowCount, "L", itemName, errors, errorLog);
                }
                if (BmaValidator.validateMessageCheck(errors, groupCode)) {
                    //�d���`�F�b�N�iCSV�j
                    if (gokakuNoList.contains(lineArray[8])) {
                        BmaValidator.addMessage(errors, groupCode, BmaText.E00101, "");
                        this.createErrorLine(rowCount, "L", itemName, errors, errorLog);
                    } else {
                        gokakuNoList.add(lineArray[8]);
                    }
                }
                //�̔ԃ��[��
                if (BmaValidator.validateMessageCheck(errors, groupCode)) {
                    if (!lineArray[8].substring(0, 2).equals(inSession.getNendo().substring(2, 4))
                            || !lineArray[8].substring(3, 4).equals(inSession.getShubetsuCode().substring(1, 2))
                            || !lineArray[8].substring(4, 10).equals("�ꕔ�i�w�ȁj")
                            || !CheckUtility.isNumber(lineArray[8].substring(12, 15))) {
                        BmaValidator.addMessage(errors, groupCode, BmaText.E00116, "");
                        this.createErrorLine(rowCount, "L", itemName, errors, errorLog);
                    }
                }
            } else {
                if (!lineArray[8].isEmpty()) {
                    BmaValidator.addMessage(errors, groupCode, BmaText.E00132, "");
                    this.createErrorLine(rowCount, "L", itemName, errors, errorLog);
                }
            }
            /* ���Z���i�ԍ� */
            groupCode = "JITSUGI_GOKAKUNO";
            itemName = "���Z���i�ԍ�";
            //�����̂�
            //���ی��ʂŔ��f  04
            if ("04".equals(lineArray[6])) {
                // �K�{
                if (!BmaValidator.validateRequired1(lineArray[9], errors, groupCode, "")) {
                    this.createErrorLine(rowCount, "M", itemName, errors, errorLog);
                }
                // �ő啶����
                if (!BmaValidator.validateMaxLength1(lineArray[9], 20, errors, groupCode, "")) {
                    this.createErrorLine(rowCount, "M", itemName, errors, errorLog);
                }
                if (BmaValidator.validateMessageCheck(errors, groupCode)) {
                    //�d���`�F�b�N�iCSV�j
                    if (gokakuNoList.contains(lineArray[9])) {
                        BmaValidator.addMessage(errors, groupCode, BmaText.E00101, "");
                        this.createErrorLine(rowCount, "M", itemName, errors, errorLog);
                    } else {
                        gokakuNoList.add(lineArray[9]);
                    }
                }
                //�̔ԃ��[��
                if (BmaValidator.validateMessageCheck(errors, groupCode)) {
                    if (!lineArray[9].substring(0, 2).equals(inSession.getNendo().substring(2, 4))
                            || !lineArray[9].substring(3, 4).equals(inSession.getShubetsuCode().substring(1, 2))
                            || !lineArray[9].substring(4, 10).equals("�ꕔ�i���Z�j")
                            || !CheckUtility.isNumber(lineArray[9].substring(12, 15))) {
                        BmaValidator.addMessage(errors, groupCode, BmaText.E00116, "");
                        this.createErrorLine(rowCount, "M", itemName, errors, errorLog);
                    }
                }
            } else {
                if (!lineArray[9].isEmpty()) {
                    BmaValidator.addMessage(errors, groupCode, BmaText.E00132, "");
                    this.createErrorLine(rowCount, "M", itemName, errors, errorLog);
                }
            }

            /* ���i�ԍ��i�C���ԍ��j */
            groupCode = "SHIKAKUNO";
            itemName = "���i�ԍ��i�C���ԍ��j";
            if (!lineArray[10].isEmpty()) {
                BmaValidator.addMessage(errors, groupCode, BmaText.E00132, "");
                this.createErrorLine(rowCount, "N", itemName, errors, errorLog);
            }

        } else if (BmaConstants.KSU_KBN.equals(inSession.getSknksuKbn())) {

            /* ���i�ԍ� */
            groupCode = "GOKAKUNO";
            itemName = "���i�ԍ�";
            if (!lineArray[7].isEmpty()) {
                BmaValidator.addMessage(errors, groupCode, BmaText.E00132, "");
                this.createErrorLine(rowCount, "K", itemName, errors, errorLog);
            }

            /* �w�ȍ��i�ԍ� */
            groupCode = "GAKKA_GOKAKUNO";
            itemName = "�w�ȍ��i�ԍ�";
            if (!lineArray[8].isEmpty()) {
                BmaValidator.addMessage(errors, groupCode, BmaText.E00132, "");
                this.createErrorLine(rowCount, "L", itemName, errors, errorLog);
            }

            /* ���Z���i�ԍ� */
            groupCode = "JITSUGI_GOKAKUNO";
            itemName = "���Z���i�ԍ�";
            if (!lineArray[9].isEmpty()) {
                BmaValidator.addMessage(errors, groupCode, BmaText.E00132, "");
                this.createErrorLine(rowCount, "M", itemName, errors, errorLog);
            }

            /* ���i�ԍ��i�C���ԍ��j */
            groupCode = "SHIKAKUNO";
            itemName = "���i�ԍ��i�C���ԍ��j";
            //�u�K��̂�
            //���ی��ʂŔ��f�@01
            if ("01".equals(lineArray[6])) {
                // �K�{
                if (!BmaValidator.validateRequired1(lineArray[10], errors, groupCode, "")) {
                    this.createErrorLine(rowCount, "N", itemName, errors, errorLog);
                }
                // �ő啶����
                if (!BmaValidator.validateMaxLength1(lineArray[10], 20, errors, groupCode, "")) {
                    this.createErrorLine(rowCount, "N", itemName, errors, errorLog);
                }
                if (BmaValidator.validateMessageCheck(errors, groupCode)) {
                    //�d���`�F�b�N�iCSV�j
                    if (gokakuNoList.contains(lineArray[10])) {
                        BmaValidator.addMessage(errors, groupCode, BmaText.E00101, "");
                        this.createErrorLine(rowCount, "N", itemName, errors, errorLog);
                    } else {
                        gokakuNoList.add(lineArray[10]);
                    }
                }
                if (BmaValidator.validateMessageCheck(errors, groupCode)) {
                    if ("HC".equals(inSession.getSknKsuCode()) && "11".equals(inSession.getShubetsuCode())) {
                        if (!lineArray[10].substring(0, 4).equals(inSession.getNendo())
                                || !lineArray[10].substring(5, 6).equals("N")
                                || !CheckUtility.isNumber(lineArray[10].substring(7, 12))) {
                            BmaValidator.addMessage(errors, groupCode, BmaText.E00116, "");
                            this.createErrorLine(rowCount, "N", itemName, errors, errorLog);
                        }
                    } else if ("HC".equals(inSession.getSknKsuCode()) && "13".equals(inSession.getShubetsuCode())) {
                        if (!lineArray[10].substring(0, 4).equals(inSession.getNendo())
                                || !lineArray[10].substring(5, 6).equals("R")
                                || !CheckUtility.isNumber(lineArray[10].substring(7, 12))) {
                            BmaValidator.addMessage(errors, groupCode, BmaText.E00116, "");
                            this.createErrorLine(rowCount, "N", itemName, errors, errorLog);
                        }
                    }

                    if ("IP".equals(inSession.getSknKsuCode()) && "11".equals(inSession.getShubetsuCode())) {
                        if (!lineArray[10].substring(1, 5).equals(inSession.getNendo())
                                || !CheckUtility.isNumber(lineArray[10].substring(6, 10))) {
                            BmaValidator.addMessage(errors, groupCode, BmaText.E00116, "");
                            this.createErrorLine(rowCount, "N", itemName, errors, errorLog);
                        }
                    } else if ("IP".equals(inSession.getSknKsuCode()) && "12".equals(inSession.getShubetsuCode())) {
                        if (!lineArray[10].substring(1, 5).equals(inSession.getNendo())
                                || !lineArray[10].substring(6, 7).equals("F")
                                || !CheckUtility.isNumber(lineArray[10].substring(8, 12))) {
                            BmaValidator.addMessage(errors, groupCode, BmaText.E00116, "");
                            this.createErrorLine(rowCount, "N", itemName, errors, errorLog);
                        }
                    }
                }
            } else {
                if (!lineArray[10].isEmpty()) {
                    BmaValidator.addMessage(errors, groupCode, BmaText.E00132, "");
                    this.createErrorLine(rowCount, "N", itemName, errors, errorLog);
                }
            }
        }

        /* ���i�N���� */
        groupCode = "GOKAKU_BI";
        itemName = "���i�N����";
        //���ی��ʂŔ��f�@01,03,04
        if (("01".equals(lineArray[6])) || ("03".equals(lineArray[6])) || ("04".equals(lineArray[6]))) {
            // �K�{
            if (!BmaValidator.validateRequired1(lineArray[11], errors, groupCode, "")) {
                this.createErrorLine(rowCount, "O", itemName, errors, errorLog);
            }
            // �w�蕶����
            if (!BmaValidator.validateEqualLength1(lineArray[11], 8, errors, groupCode, "")) {
                this.createErrorLine(rowCount, "O", itemName, errors, errorLog);
            }
        } else {
            if (!lineArray[11].isEmpty()) {
                BmaValidator.addMessage(errors, groupCode, BmaText.E00132, "");
                this.createErrorLine(rowCount, "O", itemName, errors, errorLog);
            }
        }

        if (!errors.isEmpty()) {
            return false;
        } else {
            return true;
        }
    }
    
    /**
     * ���i�ԍ��f�[�^��update����B
     *
     * @param inSession
     * @return �C���T�[�gOK�̏ꍇ�@true
     */
    public boolean updateGokakuData(NumKanriJoho inSession) {

        try {
            //�g�����U�N�V�����J�n
            getTransaction();
            beginTransaction();

            SystemTime sysTim = new SystemTime();

            for (NumKanriJoho row : inSession.getNumGokakuList()) {

                // �\��������������
                Moshikomi moshikomi = new Moshikomi(DATA_SOURCE_NAME);
                HoyuShikakuMst hoyuShikakuMst = new HoyuShikakuMst(DATA_SOURCE_NAME);
                HoyuMenjoMst hoyuMenjoMst = new HoyuMenjoMst(DATA_SOURCE_NAME);
                YukoKigenMst yukoKigenMst = new YukoKigenMst(DATA_SOURCE_NAME);
                MSkkMnjKanri mSkkMnjKanri = new MSkkMnjKanri(DATA_SOURCE_NAME);
                String yukokgn = "";

                // �\���ύX����
                MoshikomiHenkoRireki moshikomiHenkoRireki = new MoshikomiHenkoRireki(DATA_SOURCE_NAME);
                /* �\����񂩂�\�����ɒl���R�s�[ */
                BeanUtils.copyProperties(moshikomi, moshikomi.findByJukenJukoNo(row.getSknKsuCode(), row.getShubetsuCode(), row.getKaisuCode() ,row.getNendo(), row.getJknJkuNo()));
                /* �\����񂩂�\���ύX�������ɒl���R�s�[ */
                BeanUtils.copyProperties(moshikomiHenkoRireki, moshikomi);
                /* �o�^���Z�b�g */
                setMoshikomihenkoTrk(moshikomiHenkoRireki, inSession);
                /*�C���T�[�g���s*/
                moshikomiHenkoRireki.create();

                // �����񐔎c_����
                HoyuShikakuMst hoyuShikakuMst_Muryo = hoyuShikakuMst.findMuryo_Zan_Count(moshikomiHenkoRireki.getMoshikomishaId(), row.getSknKsuCode(), row.getShubetsuCode(), row.getKaisuCode());

                // ���ی��ʂ��Z�b�g
                moshikomi.setGohiJokyoKbn(row.getGohi());
                moshikomi.setKoshinDate(sysTim.getymd1());
                moshikomi.setKoshinTime(sysTim.gethms1());
                moshikomi.setKoshinKbn(BmaConstants.SHORI_KBN_UPDATE);
                moshikomi.setKoshinUserId(inSession.getMoshikomishaId());

                moshikomi.update();

                // �ۗL���i�}�X�^�A�ۗL�Ə��}�X�^�������i�ēo�^�҂�z��j
                HoyuShikakuMst hoyuShikakuMstRireki = hoyuShikakuMst.find(moshikomiHenkoRireki.getMoshikomishaId(), row.getSknKsuCode(), row.getSknKsuCode(), row.getShubetsuCode(), row.getNendo());
                // ���݂���ꍇ�A�폜
                if (hoyuShikakuMstRireki != null) {
                    hoyuShikakuMstRireki.remove();
                }

                HoyuMenjoMst hoyuMenjoMstRireki = hoyuMenjoMst.find(moshikomiHenkoRireki.getMoshikomishaId(), row.getSknKsuCode(), row.getSknKsuCode(), row.getShubetsuCode(), row.getNendo());
                // ���݂���ꍇ�A�폜
                if (hoyuMenjoMstRireki != null) {
                    hoyuMenjoMstRireki.remove();
                }
                
                // �\�����i�Ə��Ǘ�������
                MSkkMnjKanri mSkkMnjKanriJoho = mSkkMnjKanri.find(row.getNendo(), moshikomiHenkoRireki.getUketsukeNo());
                
                // 02:�s���i�̏ꍇ�ȊO
                if (!"02".equals(row.getGohi())) {
                    //�L�������擾
                    yukoKigenMst = yukoKigenMst.find(row.getSknKsuCode(), row.getShubetsuCode(), row.getGohi());
                    if (yukoKigenMst != null) {
                        SimpleDateFormat dt = new SimpleDateFormat("yyyyMMdd");
                        Date formatDate = dt.parse(row.getGokakuBi());
                        // �J�����_�[�N���X�̃C���X�^���X���擾
                        Calendar cal = Calendar.getInstance();
                        // ���ݎ�����ݒ�
                        cal.setTime(formatDate);
                        // �P�N�����Z
                        cal.add(Calendar.YEAR, Integer.parseInt(yukoKigenMst.getNensu()));
                        if ("0".equals(yukoKigenMst.getYukoKigenKbn())) {
                            yukokgn = dt.format(cal.getTime());
                        } else if ("1".equals(yukoKigenMst.getYukoKigenKbn())) {
                            yukokgn = dt.format(cal.getTime()).substring(0, 4) + yukoKigenMst.getYukoKigenKijunbi();
                        }
                    } else {
                        rollbackTransaction();
                        log.info("�L�������擾�G���[");
                        return false;
                    }

                    // ���i�Ə��֘A���擾
                    Moshikomi shikakuMenjo = moshikomi.findShikakuMenjo(row.getNendo(), row.getJknJkuNo());
                    if (shikakuMenjo != null) {
                        if ("01".equals(row.getGohi())) {
                            //�ۗL���i�}�X�^���Z�b�g
                            setHoyuShikakuMstTrk(hoyuShikakuMst, inSession, row, shikakuMenjo, yukokgn, hoyuShikakuMst_Muryo);
                            /*�C���T�[�g���s*/
                            hoyuShikakuMst.create();

                            // �\�����i�Ə��Ǘ������݂���ꍇ�@�_���폜
                            if (mSkkMnjKanriJoho != null && !mSkkMnjKanriJoho.getShinseiMenjoNo().isEmpty()) {
                                /* �ۗL�Ə��}�X�^����ۗL�Ə��}�X�^�ɒl���R�s�[ */
                                BeanUtils.copyProperties(hoyuMenjoMst, hoyuMenjoMst.findByShinseiMenjoNo(mSkkMnjKanriJoho.getShinseiMenjoNo()));
                                // �_���폜�t���O(1)���Z�b�g
                                setHoyuMenjoMstUpd(hoyuMenjoMst, inSession, BmaConstants.FLG_ON);
                                // �X�V
                                hoyuMenjoMst.update();
                            }
                        } else if ("03".equals(row.getGohi()) || "04".equals(row.getGohi())) {
                            // �\�����i�Ə��Ǘ������݂���ꍇ
                            if (mSkkMnjKanriJoho != null && !mSkkMnjKanriJoho.getShinseiMenjoNo().isEmpty()) {
                                /* �ۗL�Ə��}�X�^����ۗL�Ə��}�X�^�ɒl���R�s�[ */
                                BeanUtils.copyProperties(hoyuMenjoMst, hoyuMenjoMst.findByShinseiMenjoNo(mSkkMnjKanriJoho.getShinseiMenjoNo()));
                                // �_���폜�t���O(0)���Z�b�g
                                setHoyuMenjoMstUpd(hoyuMenjoMst, inSession, BmaConstants.FLG_OFF);
                                // �X�V
                                hoyuMenjoMst.update();
                            } else {
                                //�ۗL�Ə��}�X�^���Z�b�g
                                setHoyuMenjoMstTrk(hoyuMenjoMst, inSession, row, shikakuMenjo, yukokgn);
                                /*�C���T�[�g���s*/
                                hoyuMenjoMst.create();
                            }
                        }
                    } else {
                        rollbackTransaction();
                        log.info("���i�Ə��֘A���擾�G���[");
                        return false;
                    }
                } else {
                    // �\�����i�Ə��Ǘ������݂���ꍇ
                            if (mSkkMnjKanriJoho != null && !mSkkMnjKanriJoho.getShinseiMenjoNo().isEmpty()) {
                                /* �ۗL�Ə��}�X�^����ۗL�Ə��}�X�^�ɒl���R�s�[ */
                                BeanUtils.copyProperties(hoyuMenjoMst, hoyuMenjoMst.findByShinseiMenjoNo(mSkkMnjKanriJoho.getShinseiMenjoNo()));  
                                // �_���폜�t���O(0)���Z�b�g
                                setHoyuMenjoMstUpd(hoyuMenjoMst, inSession, BmaConstants.FLG_OFF);
                                // �X�V
                                hoyuMenjoMst.update();
                            }
                }
            }         
            // �g�����U�N�V�������R�~�b�g����
            commitTransaction();
            inSession.setGokakuNoFuyoKensu(String.valueOf(inSession.getNumGokakuList().size()));
            return true;

        } catch (Exception e) {
            rollbackTransaction();
            log.info("�b�r�u�f�[�^�捞�����ŗ�O������", e);
            return false;
        }
    }
    
    /**
     * �\���ύX������o�^����
     *
     * @param bo
     * @param inSession
     * @throws java.lang.Exception
     */
    public void setMoshikomihenkoTrk(MoshikomiHenkoRireki bo, NumKanriJoho inSession) throws Exception {
        SystemTime sysTime = new SystemTime();
        Saiban saiban = new BmaSaibanService(DATA_SOURCE_NAME).getSaibanAndUpdate(BmaConstants.SAIBAN_MOSHIKOMI_HENKOID, inSession.getMoshikomishaId());
        bo.setMoshikomiHenkoRirekiIdx(saiban.getGenzaiNo());
        bo.setHenkoKbn(BmaConstants.FLG_ON);
        bo.setKoshinKbn(BmaConstants.SHORI_KBN_INSERT);
        bo.setTorokuDate(sysTime.getymd1());
        bo.setTorokuTime(sysTime.gethms1());
        bo.setTorokuUserId(inSession.getMoshikomishaId());
        bo.setKoshinDate("");
        bo.setKoshinTime("");
        bo.setKoshinUserId("");
        bo.setRonriSakujoFlg(BmaConstants.FLG_OFF);
    }
    
    /**
     * �G���[���b�Z�[�W�s��ǉ�����B
     *
     * @param lineNo
     * @param errors
     * @param columnNo
     * @param itemName
     * @param errors
     * @param errorLog
     */
    private void createErrorLine(int rowCount, String columnNo, String itemName, Messages errors , List errorLog) {
        NumKanriJoho joho = new NumKanriJoho();
        //�w�b�_�[�ǉ�
        //���e�ǉ�    
        joho.setLineNo(String.valueOf(rowCount));
        joho.setColumnNo(columnNo);
        joho.setItemName(itemName);
        List<Message> valueList = new ArrayList<>(errors.getMessages().values());
        List<String> messages = valueList.get(valueList.size() - 1).getMessage();
        String message = messages.get(messages.size() - 1);
        joho.setMessage(message);
        errorLog.add(joho);
    }
    
    private void createCsv(NumKanriJoho inRequest, NumKanriJoho inSession, String dataName) throws IOException {
        SystemTime systime = new SystemTime();    
        SknksuMst sknksuMst = new SknksuMst(BmaConstants.DS_REGISTRANT);
        String sknKsuNameChi = sknksuMst.findSknKsuNameRyaku(inSession.getSknKsuCode(),
                inSession.getShubetsuCode(), inSession.getKaisuCode()).getSknKsuNameRyaku();
        String fileName = sknKsuNameChi + "_" + dataName + "_" + systime.getymd1() + systime.gethms1() + ".log";
        // �w�b�_�[����
        inRequest.setHeader("Content-Disposition", String.format(Locale.JAPAN, "attachment; filename*=utf-8'jp'%s", URLEncoder.encode(fileName, "utf-8")));
        inRequest.setContentType("application/octet-stream;charset=" + BmaConstants.ENCODE_SHIFT_JIS);
        BufferedWriter bw = null;
        ByteArrayOutputStream outputStream = null;
        try {
            // �X�g���[������
            outputStream = new ByteArrayOutputStream();
            bw = new BufferedWriter(new OutputStreamWriter(outputStream, BmaConstants.ENCODE_SHIFT_JIS));
            for (int i = 0; i < inSession.getErrorLog().size(); i++) {
                if (i == 0) {
                    bw.write("�s�ԍ�");
                    bw.write(",");
                    bw.write("��ԍ�");
                    bw.write(",");
                    bw.write("���ږ�");
                    bw.write(",");
                    bw.write("�G���[���b�Z�[�W");
                    bw.write(",");
                    bw.write("\r\n");
                    bw.write(inSession.getErrorLog().get(i).getLineNo());
                    bw.write(",");
                    bw.write(inSession.getErrorLog().get(i).getColumnNo());
                    bw.write(",");
                    bw.write(inSession.getErrorLog().get(i).getItemName());
                    bw.write(",");
                    bw.write(inSession.getErrorLog().get(i).getMessage());
                    bw.write("\r\n");
                } else {
                    bw.write(inSession.getErrorLog().get(i).getLineNo());
                    bw.write(",");
                    bw.write(inSession.getErrorLog().get(i).getColumnNo());
                    bw.write(",");
                    bw.write(inSession.getErrorLog().get(i).getItemName());
                    bw.write(",");
                    bw.write(inSession.getErrorLog().get(i).getMessage());
                    bw.write("\r\n");
                }
            }
            bw.flush();
        } catch (Exception e) {
            log.error("CSV�o�͏����ŃG���[���������܂����B", e);
        } finally {
            if (bw != null) {
                bw.close();
            }
        }
        InputStream io = new ByteArrayInputStream(outputStream.toByteArray());
        inRequest.setInputStream(io);
        inRequest.setHeader("Content-Type", "charset=" + BmaConstants.ENCODE_SHIFT_JIS);
        inRequest.setContentType("text/csv; charset=" + BmaConstants.ENCODE_SHIFT_JIS);
        
    }
    
    /**
     * �ۗL���i�}�X�^��o�^����
     *
     * @param bo
     * @param inSession
     * @param row
     * @param shikakuMenjo
     * @param yukokgn
     * @param hoyuShikakuMst_Muryo
     * @throws java.lang.Exception
     */
    public void setHoyuShikakuMstTrk(HoyuShikakuMst bo, NumKanriJoho inSession, NumKanriJoho row, Moshikomi shikakuMenjo, String yukokgn, HoyuShikakuMst hoyuShikakuMst_Muryo) throws Exception {
        SystemTime sysTime = new SystemTime();
        
        bo.setMoshikomishaId(shikakuMenjo.getMoshikomishaId());
        bo.setSknKsuCode(row.getSknKsuCode());
        bo.setShubetsuCode(row.getShubetsuCode());
        bo.setKaisuCode(row.getKaisuCode());
        bo.setNendo(row.getNendo());     
        if (BmaConstants.SKN_KBN.equals(inSession.getSknksuKbn())) {
            bo.setGokakuNo(row.getGokakuNo());
        } else if (BmaConstants.KSU_KBN.equals(inSession.getSknksuKbn())) {
            bo.setGokakuNo(row.getShikakuNo());
        }
        bo.setGokakuBi(row.getGokakuBi());
        //�L�������擾�@�u�K��̂�
        if (BmaConstants.KSU_KBN.equals(inSession.getSknksuKbn())) {
            bo.setYukoKigen(yukokgn);
        }
        bo.setFurigana(shikakuMenjo.getFurigana());
        bo.setBirthday(shikakuMenjo.getBirthday());
        
        //MURYO_ZAN_COUNT �ۗL���i�}�X�^����N�x�̈�ԑ傫���l���擾_2020/10/06
        if (hoyuShikakuMst_Muryo != null) {
            bo.setMuryoZanCount(hoyuShikakuMst_Muryo.getMuryoZanCount());
        } else {
            bo.setMuryoZanCount("");
        }
        
        //�V�X�e�����
        bo.setKoshinKbn(BmaConstants.SHORI_KBN_INSERT);
        bo.setTorokuDate(sysTime.getymd1());
        bo.setTorokuTime(sysTime.gethms1());
        bo.setTorokuUserId(inSession.getMoshikomishaId());
        bo.setKoshinDate("");
        bo.setKoshinTime("");
        bo.setKoshinUserId("");
        bo.setRonriSakujoFlg(BmaConstants.FLG_OFF);
        
    }
    
    /**
     * �ۗL�Ə��}�X�^��o�^����
     *
     * @param bo
     * @param inSession
     * @param row
     * @param shikakuMenjo
     * @param yukokgn
     * @throws java.lang.Exception
     */
    public void setHoyuMenjoMstTrk(HoyuMenjoMst bo, NumKanriJoho inSession, NumKanriJoho row, Moshikomi shikakuMenjo, String yukokgn) throws Exception {
        SystemTime sysTime = new SystemTime();
        
        bo.setMoshikomishaId(shikakuMenjo.getMoshikomishaId());
        bo.setSknKsuCode(row.getSknKsuCode());
        bo.setShubetsuCode(row.getShubetsuCode());
        bo.setKaisuCode(row.getKaisuCode());
        bo.setNendo(row.getNendo());     
        if ("03".equals(row.getGohi())) {
            bo.setMenjoKbn("1");
            bo.setGokakuTsuchiNo(row.getGakkaGokakuNo());
        } else if ("04".equals(row.getGohi())) {
            bo.setMenjoKbn("2");
            bo.setGokakuTsuchiNo(row.getJitsugiGokakuNo());
        }
        //�L�������擾
        bo.setYukoKigen(yukokgn);
        bo.setFurigana(shikakuMenjo.getFurigana());
        bo.setBirthday(shikakuMenjo.getBirthday());     
        //�V�X�e�����
        bo.setKoshinKbn(BmaConstants.SHORI_KBN_INSERT);
        bo.setTorokuDate(sysTime.getymd1());
        bo.setTorokuTime(sysTime.gethms1());
        bo.setTorokuUserId(inSession.getMoshikomishaId());
        bo.setKoshinDate("");
        bo.setKoshinTime("");
        bo.setKoshinUserId("");
        bo.setRonriSakujoFlg(BmaConstants.FLG_OFF);
        
    }
    
    /**
     * �ۗL�Ə��}�X�^�̘_���폜�t���O���X�V����B
     *
     * @param bo
     * @param inSession
     * @param ronriSakujoFlg
     * @throws java.lang.Exception
     */
    public void setHoyuMenjoMstUpd(HoyuMenjoMst bo, NumKanriJoho inSession, String ronriSakujoFlg) throws Exception {
        SystemTime sysTim = new SystemTime();

        bo.setKoshinDate(sysTim.getymd1());
        bo.setKoshinTime(sysTim.gethms1());
        bo.setKoshinKbn(BmaConstants.SHORI_KBN_UPDATE);
        bo.setKoshinUserId(inSession.getMoshikomishaId());
        bo.setRonriSakujoFlg(ronriSakujoFlg);
    }

}
