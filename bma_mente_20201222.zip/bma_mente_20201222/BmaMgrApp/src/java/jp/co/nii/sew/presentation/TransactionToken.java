package jp.co.nii.sew.presentation;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import jp.co.nii.sew.utility.StringUtility;

/**
 *
 * @author r-tomita
 */
public class TransactionToken {

    public static final String KEY_TOKEN = "token";
    public static final String MODE_CREATE = "CREATE";
    public static final String MODE_CHECK = "CHECK";

    public TransactionToken() {
    }

    /**
     * �g�[�N���i�[
     *
     * @param request
     */
    protected void saveToken(HttpServletRequest request) {

        HttpSession session = request.getSession(false);
        if (session == null) {
            return;
        }
        // 12���̃����_���ȑ召�p�����𐶐�
        String token = StringUtility.randomString(12, "1");
        if (token != null) {
            session.setAttribute(KEY_TOKEN, token);
        }

    }

    /**
     * �g�[�N���`�F�b�N
     *
     * @param request
     * @return boolean
     */
    protected boolean isTokenValid(HttpServletRequest request) {

        HttpSession session = request.getSession(false);
        if (session == null) {
            return false;
        }
        synchronized (session) {
            try {
                String saved = (String) session.getAttribute(KEY_TOKEN);
                if (saved == null) {
                    return false;
                }
                session.removeAttribute(KEY_TOKEN);

                String token = (String) request.getParameter(KEY_TOKEN);
                if (token == null) {
                    return false;
                }

                return saved.equals(token);
            } catch (IllegalStateException ise) {
                return false;
            }
        }
    }
}
