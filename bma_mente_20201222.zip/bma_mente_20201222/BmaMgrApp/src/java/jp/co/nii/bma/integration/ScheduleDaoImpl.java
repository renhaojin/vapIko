package jp.co.nii.bma.integration;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;
import jp.co.nii.bma.business.domain.MeishoKanriDao;
import jp.co.nii.bma.business.domain.Schedule;
import jp.co.nii.bma.business.domain.ScheduleDao;
import jp.co.nii.bma.business.rto.manager.MgrTopJoho;
import jp.co.nii.bma.business.rto.manager.MstKanriScheduleJoho;
import jp.co.nii.sew.business.SystemTime;
import jp.co.nii.sew.common.LogGenerate;
import static jp.co.nii.sew.integration.AbstractDao.getSchemaName;
import jp.co.nii.sew.integration.SQLStateSQLExceptionTranslater;

/**
 * �X�P�W���[�� DAO�����N���X
 *
 * @author DB�Ǘ��c�[��
 */
public class ScheduleDaoImpl extends GeneratedScheduleDaoImpl implements ScheduleDao {

    /**
     * �C���X�^���X�𐶐�����B
     *
     * @param datasource �f�[�^�\�[�X��
     */
    public ScheduleDaoImpl(String datasource) {
        super(datasource);
    }

    /**
     * �u�X�P�W���[���������ԁv�u�J�n���v�̔N�x���擾����B
     *
     * @param sknKsuCode �����u�K��R�[�h
     * @param shubetsuCode ��ʃR�[�h
     * @param kaisuCode �񐔃R�[�h
     * @param scheduleCode �X�P�W���[���R�[�h
     * @param scheduleKbn �X�P�W���[���敪
     */
    @Override
    public String findNendoKojiKikan(String sknKsuCode, String shubetsuCode, String kaisuCode, String scheduleCode, String scheduleKbn) {

        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = "";
        String nendo = "";

        try {
            con = getConnection();
            sql = "SELECT "
                    + "schedule.NENDO AS NENDO"
                    + " FROM " + getSchemaName() + "." + ScheduleDao.TABLE_NAME + " AS schedule"
                    + " WHERE " + "schedule.SKN_KSU_CODE = ?"
                    + " AND " + "schedule.SHUBETSU_CODE = ?"
                    + " AND " + "schedule.KAISU_CODE = ?"
                    + " AND " + "schedule.SCHEDULE_CODE = ?"
                    + " AND " + "schedule.SCHEDULE_KBN = ?"
                    + " AND " + "schedule.RONRI_SAKUJO_FLG = '0'"
                    + " ORDER BY schedule.NENDO DESC "
                    + " LIMIT 1";

            stmt = con.prepareStatement(sql);
            int i = 1;
            stmt.setString(i++, sknKsuCode);
            stmt.setString(i++, shubetsuCode);
            stmt.setString(i++, kaisuCode);
            stmt.setString(i++, scheduleCode);
            stmt.setString(i++, scheduleKbn);
            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();

            if (rs.next()) {
                nendo = rs.getString("NENDO");
            } else {
                nendo = null;
            }

        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return nendo;
    }

    /**
     * �N�x�A�����u�K��R�[�h�A��ʃR�[�h�A�񐔃R�[�h����v����X�P�W���[����S���擾����B
     *
     * @param nendo �N�x
     * @param sknKsuCode �����u�K��R�[�h
     * @param shubetsuCode ��ʃR�[�h
     * @param kaisuCode �񐔃R�[�h
     */
    @Override
    public List<MstKanriScheduleJoho> findBySknKsu(String nendo, String sknKsuCode, String shubetsuCode, String kaisuCode) {

        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = "";
        List<MstKanriScheduleJoho> scheduleSearchList = new LinkedList<MstKanriScheduleJoho>();

        try {
            con = getConnection();
            sql = "SELECT "
                    + "schedule.NENDO AS NENDO"
                    + ", " + "schedule.SKN_KSU_CODE AS SKN_KSU_CODE"
                    + ", " + "schedule.SHUBETSU_CODE AS SHUBETSU_CODE"
                    + ", " + "schedule.KAISU_CODE AS KAISU_CODE"
                    + ", " + "schedule.SCHEDULE_CODE AS SCHEDULE_CODE"
                    + ", " + "schedule.SCHEDULE_KBN AS SCHEDULE_KBN"
                    + ", " + "schedule.DATE AS DATE"
                    + ", " + "schedule.TIME AS TIME"
                    + ", " + "sch_code.HANYO_CHI AS SCHEDULE_NAME"
                    + ", " + "sch_code.HYOJI_JUNJO AS HYOJI_JUNJO"
                    + " FROM " + getSchemaName() + "." + ScheduleDao.TABLE_NAME + " AS schedule"
                    + " LEFT JOIN " + getSchemaName() + "." + MeishoKanriDao.TABLE_NAME + " AS sch_code"
                    + " ON " + "schedule.SCHEDULE_CODE = sch_code.HANYO_CODE "
                    + " AND " + "sch_code.GROUP_CODE = 'SCHEDULE_CODE' "
                    + " WHERE " + "schedule.NENDO = ?"
                    + " AND " + "schedule.SKN_KSU_CODE = ?"
                    + " AND " + "schedule.SHUBETSU_CODE = ?"
                    + " AND " + "schedule.KAISU_CODE = ?"
                    + " AND " + "schedule.RONRI_SAKUJO_FLG = '0'"
                    + " ORDER BY to_number(HYOJI_JUNJO,'999') , schedule.SCHEDULE_KBN ASC";

            stmt = con.prepareStatement(sql);
            int i = 1;
            stmt.setString(i++, nendo);
            stmt.setString(i++, sknKsuCode);
            stmt.setString(i++, shubetsuCode);
            stmt.setString(i++, kaisuCode);
            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();

            while (rs.next()) {
                MstKanriScheduleJoho detail = new MstKanriScheduleJoho();
                // �N�x
                detail.setNendo(rs.getString("NENDO"));
                // �����u�K��
                detail.setSknKsuCode(rs.getString("SKN_KSU_CODE"));
                detail.setShubetsuCode(rs.getString("SHUBETSU_CODE"));
                detail.setKaisuCode(rs.getString("KAISU_CODE"));
                // �X�P�W���[��
                detail.setScheduleCode(rs.getString("SCHEDULE_CODE"));
                detail.setScheduleName(rs.getString("SCHEDULE_NAME"));
                detail.setScheduleKbn(rs.getString("SCHEDULE_KBN"));
                detail.setDate(rs.getString("DATE"));
                detail.setTime(rs.getString("TIME"));

                scheduleSearchList.add(detail);
            }

        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return scheduleSearchList;
    }

    /**
     * �����u�K��R�[�h�A��ʃR�[�h�A�񐔃R�[�h�A�X�P�W���[���R�[�h�A�X�P�W���[���敪���玞�����擾����B
     *
     * @param sknKsuCode �����u�K��R�[�h
     * @param shubetsuCode ��ʃR�[�h
     * @param kaisuCode �񐔃R�[�h
     * @param schedCode �X�P�W���[���R�[�h
     * @param schedKbn �X�P�W���[���敪
     */
    @Override
    public String findTime(String sknKsuCode, String shubetsuCode, String kaisuCode, String schedCode, String schedKbn) {

        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = "";
        String resultTime = "";

        try {
            con = getConnection();
            sql = "SELECT "
                    + "schedule.TIME AS TIME"
                    + " FROM " + getSchemaName() + "." + ScheduleDao.TABLE_NAME + " AS schedule"
                    + " WHERE " + "schedule.SKN_KSU_CODE = ?"
                    + " AND " + "schedule.SHUBETSU_CODE = ?"
                    + " AND " + "schedule.KAISU_CODE = ?"
                    + " AND " + "schedule.SCHEDULE_CODE = ?"
                    + " AND " + "schedule.SCHEDULE_KBN = ?"
                    + " AND " + "schedule.RONRI_SAKUJO_FLG = '0'"
                    + " ORDER BY schedule.NENDO DESC"
                    + " LIMIT 1";

            stmt = con.prepareStatement(sql);
            int i = 1;
            stmt.setString(i++, sknKsuCode);
            stmt.setString(i++, shubetsuCode);
            stmt.setString(i++, kaisuCode);
            stmt.setString(i++, schedCode);
            stmt.setString(i++, schedKbn);
            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();

            if (rs.next()) {
                resultTime = rs.getString("TIME");
            } else {
                resultTime = null;
            }

        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return resultTime;
    }

    /**
     * �����u�K��R�[�h�A��ʃR�[�h�A�񐔃R�[�h�A�X�P�W���[���R�[�h�A�X�P�W���[���敪����������擾����B
     *
     * @param sknKsuCode �����u�K��R�[�h
     * @param shubetsuCode ��ʃR�[�h
     * @param kaisuCode �񐔃R�[�h
     * @param schedCode �X�P�W���[���R�[�h
     * @param schedKbn �X�P�W���[���敪
     */
    @Override
    public String findNissu(String sknKsuCode, String shubetsuCode, String kaisuCode, String schedCode, String schedKbn) {

        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = "";
        String resultNissu = "";

        try {
            con = getConnection();
            sql = "SELECT "
                    + "schedule.NISSU AS NISSU"
                    + " FROM " + getSchemaName() + "." + ScheduleDao.TABLE_NAME + " AS schedule"
                    + " WHERE " + "schedule.SKN_KSU_CODE = ?"
                    + " AND " + "schedule.SHUBETSU_CODE = ?"
                    + " AND " + "schedule.KAISU_CODE = ?"
                    + " AND " + "schedule.SCHEDULE_CODE = ?"
                    + " AND " + "schedule.SCHEDULE_KBN = ?"
                    + " AND " + "schedule.RONRI_SAKUJO_FLG = '0'"
                    + " ORDER BY schedule.NENDO DESC"
                    + " LIMIT 1";

            stmt = con.prepareStatement(sql);
            int i = 1;
            stmt.setString(i++, sknKsuCode);
            stmt.setString(i++, shubetsuCode);
            stmt.setString(i++, kaisuCode);
            stmt.setString(i++, schedCode);
            stmt.setString(i++, schedKbn);
            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();

            if (rs.next()) {
                resultNissu = rs.getString("NISSU");
            } else {
                resultNissu = null;
            }

        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return resultNissu;
    }

    /**
     * �N�x�̕ύX���܂߂čX�V����B
     *
     * @param bo �X�V�f�[�^
     * @param oldNendo �X�V�O�̔N�x
     */
    @Override
    public Boolean updateWithNendo(Schedule bo, String oldNendo) {
        Connection con = null;
        PreparedStatement stmt = null;
        String sql = "";
        try {
            con = getConnection();
            sql = "UPDATE " + getSchemaName() + "." + TABLE_NAME + " SET"
                    + " NENDO = ?"
                    + ",DATE = ?"
                    + ",TIME = ?"
                    + ",NISSU = ?"
                    + ",KOSHIN_KBN = ?"
                    + ",KOSHIN_DATE = ?"
                    + ",KOSHIN_TIME = ?"
                    + ",KOSHIN_USER_ID = ?"
                    + " WHERE"
                    + " NENDO = ?"
                    + " AND SKN_KSU_CODE = ?"
                    + " AND SHUBETSU_CODE = ?"
                    + " AND KAISU_CODE = ?"
                    + " AND SCHEDULE_CODE = ?"
                    + " AND SCHEDULE_KBN = ?";

            stmt = con.prepareStatement(sql);
            int i = 1;
            stmt.setString(i++, bo.getNendo());
            stmt.setString(i++, bo.getDate());
            stmt.setString(i++, bo.getTime());
            stmt.setString(i++, bo.getNissu());
            stmt.setString(i++, bo.getKoshinKbn());
            stmt.setString(i++, bo.getKoshinDate());
            stmt.setString(i++, bo.getKoshinTime());
            stmt.setString(i++, bo.getKoshinUserId());

            stmt.setString(i++, oldNendo);
            stmt.setString(i++, bo.getSknKsuCode());
            stmt.setString(i++, bo.getShubetsuCode());
            stmt.setString(i++, bo.getKaisuCode());
            stmt.setString(i++, bo.getScheduleCode());
            stmt.setString(i++, bo.getScheduleKbn());

            LogGenerate.debugOutput(getSql(stmt));
            if (stmt.executeUpdate() == 0) {
                return false;
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt);
        }
        return true;
    }

    /**
     * �����݂̂̃f�[�^�̃X�P�W���[���R�[�h���擾����B
     *
     * @param nendo �N�x
     * @param sknKsuCode �����u�K��R�[�h
     * @param shubetsuCode ��ʃR�[�h
     * @param kaisuCode �񐔃R�[�h
     * @param schedKbn �X�P�W���[���敪
     */
    @Override
    public List<String> nissuCodesForUpdate(String nendo, String sknKsuCode, String shubetsuCode, String kaisuCode, String schedKbn) {
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = "";
        List<String> nissuCodes = new ArrayList<String>();

        try {
            con = getConnection();
            sql = "SELECT "
                    + "schedule.SCHEDULE_CODE AS SCHEDULE_CODE"
                    + " FROM " + getSchemaName() + "." + ScheduleDao.TABLE_NAME + " AS schedule"
                    + " WHERE " + "schedule.NENDO = ?"
                    + " AND " + "schedule.SKN_KSU_CODE = ?"
                    + " AND " + "schedule.SHUBETSU_CODE = ?"
                    + " AND " + "schedule.KAISU_CODE = ?"
                    + " AND " + "schedule.SCHEDULE_KBN = ?"
                    + " AND " + "schedule.DATE = ''"
                    + " AND " + "schedule.TIME = ''"
                    + " AND " + "schedule.RONRI_SAKUJO_FLG = '0'"
                    + " ORDER BY schedule.SCHEDULE_CODE ASC";

            stmt = con.prepareStatement(sql);
            int i = 1;
            stmt.setString(i++, nendo);
            stmt.setString(i++, sknKsuCode);
            stmt.setString(i++, shubetsuCode);
            stmt.setString(i++, kaisuCode);
            stmt.setString(i++, schedKbn);

            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();

            while (rs.next()) {
                MstKanriScheduleJoho detail = new MstKanriScheduleJoho();
                detail.setScheduleCode(rs.getString("SCHEDULE_CODE"));
                nissuCodes.add(detail.getScheduleCode());
            }

        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return nissuCodes;
    }

    /**
     * �����݂̂̃f�[�^�̔N�x���X�V����B
     *
     * @param bo �X�V�f�[�^
     * @param oldNendo �X�V�O�̔N�x
     */
    @Override
    public Boolean updateNendoOnlyNissu(Schedule bo, String oldNendo) {
        Connection con = null;
        PreparedStatement stmt = null;
        String sql = "";
        try {
            con = getConnection();
            sql = "UPDATE " + getSchemaName() + "." + TABLE_NAME + " SET"
                    + " NENDO = ?"
                    + ",KOSHIN_KBN = ?"
                    + ",KOSHIN_DATE = ?"
                    + ",KOSHIN_TIME = ?"
                    + ",KOSHIN_USER_ID = ?"
                    + " WHERE"
                    + " NENDO = ?"
                    + " AND SKN_KSU_CODE = ?"
                    + " AND SHUBETSU_CODE = ?"
                    + " AND KAISU_CODE = ?"
                    + " AND SCHEDULE_CODE = ?"
                    + " AND SCHEDULE_KBN = ?";

            stmt = con.prepareStatement(sql);
            int i = 1;
            stmt.setString(i++, bo.getNendo());
            stmt.setString(i++, bo.getKoshinKbn());
            stmt.setString(i++, bo.getKoshinDate());
            stmt.setString(i++, bo.getKoshinTime());
            stmt.setString(i++, bo.getKoshinUserId());

            stmt.setString(i++, oldNendo);
            stmt.setString(i++, bo.getSknKsuCode());
            stmt.setString(i++, bo.getShubetsuCode());
            stmt.setString(i++, bo.getKaisuCode());
            stmt.setString(i++, bo.getScheduleCode());
            stmt.setString(i++, bo.getScheduleKbn());

            LogGenerate.debugOutput(getSql(stmt));
            if (stmt.executeUpdate() == 0) {
                return false;
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt);
        }
        return true;
    }

    /**
     * �g�s�b�N���X�g�擾�B
     *
     * @param inSession
     * @return
     */
    @Override
    public List<MgrTopJoho> searchTopicList(MgrTopJoho search) {
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        String sql = "";
        List<String> param = new ArrayList<>();
        List<MgrTopJoho> ret = new ArrayList<>();

        String currentDate = new SystemTime().getymd1();

        try {
            con = getConnection();
            sql = "SELECT distinct"
                    + " sch.skn_ksu_name_ryaku "
                    + " , mei.hanyo_chi"
                    + " FROM "
                    + " bma.schedulekikan_view sch  "
                    + " INNER JOIN bma.sknksu_mst sknksu"
                    + " ON sknksu.skn_ksu_code = sch.skn_ksu_code "
                    + " AND sknksu.shubetsu_code = sch.shubetsu_code"
                    + " AND sknksu.kaisu_code = sch.kaisu_code  "
                    + " INNER JOIN bma.meisho_kanri mei  "
                    + " ON mei.group_code = 'TOPIC_HYOJI_KBN'"
                    + " INNER JOIN bma.moshikomi msk"
                    + " ON sch.skn_ksu_code = msk.skn_ksu_code  "
                    + " AND sch.shubetsu_code = msk.shubetsu_code "
                    + " AND sch.kaisu_code = msk.kaisu_code"
                    + " AND sch.nendo_sch = msk.nendo  "
                    + " INNER JOIN bma.gazo gazo "
                    + " ON msk.uketsuke_no = gazo.uketsuke_no "
                    + " INNER JOIN bma.schedule endsch"
                    + " ON endsch.skn_ksu_code = sch.skn_ksu_code "
                    + " AND endsch.shubetsu_code = sch.shubetsu_code  "
                    + " AND endsch.kaisu_code = sch.kaisu_code "
                    + " AND endsch.schedule_code = '07'  "
                    + " WHERE "
                    + " sch.datestart <= ?"
                    + " AND endsch.date >= ?"
                    + " AND sch.schedule_code = '20'"
                    + " AND gazo.ronri_sakujo_flg = '0'  "
                    + " AND mei.hanyo_code = CASE    "
                    + "   WHEN gazo.HOSEI_IRAI_KBN = '1'  "
                    + "     THEN '101'               "
                    + "   WHEN gazo.HOSEI_IRAI_KBN = '2'  "
                    + "     THEN '102'               "
                    + "   WHEN gazo.HOSEI_IRAI_KBN = '4'  "
                    + "     THEN '103'               "
                    + "   WHEN gazo.HOSEI_IRAI_KBN = '6'  "
                    + "     THEN '104'               "
                    + "   WHEN gazo.HOSEI_IRAI_KBN = '7'  "
                    + "     THEN '105'               "
                    + "   END ";

            param.add(currentDate);
            param.add(currentDate);

            stmt = con.prepareStatement(sql);
            int i = 1;
            for (String pm : param) {
                stmt.setString(i++, pm);
            }

            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();
            while (rs.next()) {
                MgrTopJoho joho = new MgrTopJoho();
                joho.setTopicName(rs.getString("hanyo_chi"));
                joho.setSknKsuName(rs.getString("skn_ksu_name_ryaku"));

                ret.add(joho);
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return ret;

    }
}
