//package jp.co.nii.bma.business.rto.manager;
//
//import java.util.ArrayList;
//import java.util.List;
//import javax.servlet.http.HttpServletRequest;
//import javax.servlet.http.HttpSession;
//import jp.co.nii.bma.business.domain.MskJoho;
//import jp.co.nii.bma.presentation.moshikomi.KaijoOption;
//import jp.co.nii.bma.utility.BmaStringUtility;
//import jp.co.nii.sew.presentation.AbstractRequestTransferObject;
//import jp.co.nii.sew.presentation.Messages;
//import jp.co.nii.sew.presentation.Option;
//import jp.co.nii.sew.utility.StringUtility;
//import org.apache.commons.fileupload.FileItem;
//
///**
// * �^�C�g��: �󌱐\����RTO ����: �󌱐\����RTO
// *
// * ���쌠: Copyright (c) 2016
// *
// * ��Ж�: ���{���Y�Ɗ������
// *
// * @author S.Banka
// */
//public class MgrMskJohoInput extends AbstractRequestTransferObject {
//
//    /**
//     * �\�����
//     */
//    private MskJoho dispJoho;
//    /**
//     * �Ǘ��҂h�c
//     */
//    private String kanrishaId;
//    /**
//     * ���ʃR�[�h
//     */
//    private String sexCode;
//    /**
//     * �␳�敪
//     */
//    private String hoseiKbn;
//    /**
//     * �␳���R
//     */
//    private String hoseiRiyu;
//    /**
//     * �{�Вn�R�[�h
//     */
//    private String honsekichiCode;
//    /**
//     * �ً}�A����d�b�ԍ�
//     */
//    private String kinkyuRenrakusakiTelNo;
//    /**
//     * �Ζ���L���t���O
//     */
//    private String kinmusakiUmuFlg;
//    /**
//     * �Ζ��於��
//     */
//    private String kinmusakiMeisho;
//    /**
//     * �Ζ��敔�ۖ�
//     */
//    private String kinmusakiBukaMei;
//    /**
//     * �Ζ���X�֔ԍ��P
//     */
//    private String kinmusakiYubinNo1;
//    /**
//     * �Ζ���X�֔ԍ��Q
//     */
//    private String kinmusakiYubinNo2;
//    /**
//     * �Ζ���s���{���R�[�h
//     */
//    private String kinmusakiTodofukeCode;
//    /**
//     * �Ζ���s�撬����
//     */
//    private String kinmusakiAddress1;
//    /**
//     * �Ζ���r���}���V�����A�p�[�g
//     */
//    private String kinmusakiAddress2;
//    /**
//     * �Ζ���d�b�ԍ�
//     */
//    private String kinmusakiTelNo;
//    /**
//     * �Ζ��挻��d�b�ԍ�
//     */
//    private String kinmusakiGenbaTelNo;
//    /**
//     * ���t��L���t���O
//     */
//    private String sofusakiUmuFlg;
//    /**
//     * ���t��X�֔ԍ��P
//     */
//    private String sofusakiYubinNo1;
//    /**
//     * ���t��X�֔ԍ��Q
//     */
//    private String sofusakiYubinNo2;
//    /**
//     * ���t��s���{���R�[�h
//     */
//    private String sofusakiTodofukeCode;
//    /**
//     * ���t��s�撬����
//     */
//    private String sofusakiAddress1;
//    /**
//     * ���t��r���}���V�����A�p�[�g
//     */
//    private String sofusakiAddress2;
//    /**
//     * �z���L���t���O
//     */
//    private String hairyoUmuFlg;
//    /**
//     * �J�ڌ��t���O
//     */
//    private String senniMotoFlg;
//    /**
//     * �z�����e
//     */
//    private String hairyoNaiyo;
//    /**
//     * �Ǘ�����
//     */
//    private String kanriMemo;
//    /**
//     * �G���[���b�Z�[�W
//     */
//    private Messages errors;
//    /**
//     * ���[���A�h���X
//     */
//    private String mailAddress;
//    /**
//     * ���[���A�h���X�ǂݕ�
//     */
//    private List<Option> mailAddressYomiList;
//    /**
//     * �t�@�C��
//     */
//    private FileItem fileItem;
//    /**
//     * �t�@�C����
//     */
//    private String kaoShashinGazoId;
//    /**
//     * �t�@�C���敪
//     */
//    private String fileKbn;
//    /**
//     * ���ʐ^�t���O
//     */
//    private String kuroShashinFlg;
//    /**
//     * �m�F�˗����M�t���O
//     */
//    private String kakuninIraiSoshinFlg;
//    /**
//     * �m�F�˗��A�����i�N�j
//     */
//    private String kakuninIraiSoshinNen;
//    /**
//     * �m�F�˗��A�����i���j
//     */
//    private String kakuninIraiSoshinTsuki;
//    /**
//     * �m�F�˗��A�����i���j
//     */
//    private String kakuninIraiSoshinBi;
//    /**
//     * �\���p�N���X�g
//     */
//    private List<Option> yearDisp;
//    /**
//     * �\���p�����X�g
//     */
//    private List<Option> monthDisp;
//    /**
//     * �\���p�����X�g
//     */
//    private List<Option> dayDisp;
//    //<editor-fold defaultstate="collapsed" desc="�t���O/�敪�R�[�h/�\���p�ϐ�">
//    /**
//     *  �ǂݕ��\���{�^��
//     */
//    private String yomikataDispKbn;
//    //</editor-fold>
//    //<editor-fold defaultstate="collapsed" desc="Option���X�g">
//    /**
//     * �s���{�����X�g
//     */
//    private List<Option> todofukeList;
//    /**
//     * �����ꃊ�X�g
//     */
//    private List<KaijoOption> kaijoList;
//    /**
//     * �E�惊�X�g
//     */
//    private List<Option> shokuikiList;
//    /**
//     * �E�����X�g
//     */
//    private List<Option> shokumuList;
//    /**
//     * �閧�̎��⃊�X�g
//     */
//    private List<Option> passwdQuestionList;
//    //</editor-fold>
//    //<editor-fold defaultstate="collapsed" desc="�R�}���h">
//    /**
//     * �R�}���h �\�����ڍ�
//     */
//    private String commandMskJohoDetail;
//    /**
//     * �R�}���h �������ʈꗗ�ɖ߂�
//     */
//    private String commandDetailBack;
//    /**
//     * �R�}���h �\�����̕ύX
//     */
//    private String commandDetailUpdate;
//    /**
//     * �R�}���h ����p�y�[�W
//     */
//    private String commandDetailPrint;
//    /**
//     * �R�}���h �\�����ڍׂ֖߂�
//     */
//    private String commandInputBack;
//    /**
//     * �R�}���h �\�����ύX���͉�� ����
//     */
//    private String commandInputNext;
//    /**
//     * �R�}���h �\�����ύX���͊m�F��� �߂�
//     */
//    private String commandConfirmBack;
//    /**
//     * �R�}���h �\�����ύX���͊m�F��� �߂�L�����Z��
//     */
//    private String commandConfirmBackCancel;
//    /**
//     * �R�}���h �\�����ύX���͊m�F��� �m��
//     */
//    private String commandConfirmNext;
//    /**
//     * �R�}���h �\�����ύX������� �������ʈꗗ�֖߂�
//     */
//    private String commandCompleteBack;
//    /**
//     * �R�}���h �������ʉ��:��ʐ^�ڍ׃{�^��
//     */
//    private String commandKaoPhotoDetail;
//    /**
//     * �R�}���h ���[���A�h���X�ǂݕ�
//     */
//    private String commandMailYomiDisp; 
//    /**
//     * �R�}���h �p�X���[�h�ǂݕ�
//     */
//    private String commandPassYomiDisp; 
//    /**
//     * �R�}���h ���[���A�h���X�ǂݕ�(�X�V��)
//     */
//    private String commandMailYomiUpdDisp; 
//    /**
//    //</editor-fold>
//
//    //<editor-fold defaultstate="collapsed" desc="�R���X�g���N�^/������/���N�G�X�g�擾">
//    /**
//     * �R���X�g���N�^
//     */
//    public MgrMskJohoInput() {
//        clearInfo();
//    }
//
//    /**
//     * ���������\�b�h
//     */
//    public void clearInfo() {
//        this.dispJoho = new MskJoho();
//
//        this.kanrishaId = "";
//
//        this.sexCode = "";
//        this.hoseiKbn = "";
//        this.kuroShashinFlg="";
//        this.hoseiRiyu = "";
//        this.kakuninIraiSoshinFlg = "";
//        this.setKakuninIraiSoshinNen("");
//        this.setKakuninIraiSoshinTsuki("");
//        this.setKakuninIraiSoshinBi("");
//        this.honsekichiCode = "";
//        this.kinkyuRenrakusakiTelNo = "";
//        this.kinmusakiUmuFlg = "";
//        this.kinmusakiMeisho = "";
//        this.kinmusakiBukaMei = "";
//        this.kinmusakiYubinNo1 = "";
//        this.kinmusakiYubinNo2 = "";
//        this.kinmusakiTodofukeCode = "";
//        this.kinmusakiAddress1 = "";
//        this.kinmusakiAddress2 = "";
//        this.kinmusakiTelNo = "";
//        this.kinmusakiGenbaTelNo = "";
//        this.sofusakiUmuFlg = "";
//        this.senniMotoFlg = "";
//        this.sofusakiYubinNo1 = "";
//        this.sofusakiYubinNo2 = "";
//        this.sofusakiTodofukeCode = "";
//        this.sofusakiAddress1 = "";
//        this.sofusakiAddress2 = "";
//        this.hairyoUmuFlg = "";
//        this.hairyoNaiyo = "";
//        this.kanriMemo = "";
//        this.mailAddress = "";
//        
//        this.mailAddressYomiList = new ArrayList<Option>();
//        this.todofukeList = new ArrayList<Option>();
//        this.kaijoList = new ArrayList<KaijoOption>();
//        this.shokuikiList = new ArrayList<Option>();
//        this.shokumuList = new ArrayList<Option>();
//        this.passwdQuestionList = new ArrayList<Option>();
//
//        this.commandMskJohoDetail = "";
//        this.commandDetailBack = "";
//        this.commandDetailUpdate = "";
//        this.commandDetailPrint = "";
//        this.commandInputBack = "";
//        this.commandInputNext = "";
//        this.commandConfirmBack = "";
//        this.commandConfirmBackCancel = "";
//        this.commandConfirmNext = "";
//        this.commandCompleteBack = "";
//        this.commandKaoPhotoDetail = "";
//        this.commandMailYomiDisp = "";
//        this.commandPassYomiDisp = "";
//        this.commandMailYomiUpdDisp = "";
//        this.errors = new Messages();
//        this.kaoShashinGazoId = "";
//        this.fileKbn = "";
//        this.fileItem = null;
//        this.yomikataDispKbn="";
//
//    }
//
//    /**
//     * ���N�G�X�g��������擾���郁�\�b�h
//     *
//     * @param request ���N�G�X�g
//     */
//    @Override
//    public void copyFromRequest(HttpServletRequest request) {
//        setCommandMskJohoDetail((String) request.getAttribute("commandMskJohoDetail"));
//        setCommandDetailBack((String) request.getAttribute("commandDetailBack"));
//        setCommandDetailUpdate((String) request.getAttribute("commandDetailUpdate"));
//        setCommandDetailPrint((String) request.getAttribute("commandDetailPrint"));
//        setCommandInputBack((String) request.getAttribute("commandInputBack"));
//        setCommandInputNext((String) request.getAttribute("commandInputNext"));
//        setCommandConfirmNext((String) request.getAttribute("commandConfirmNext"));
//        setCommandConfirmBack((String) request.getAttribute("commandConfirmBack"));
//        setCommandConfirmBackCancel((String) request.getAttribute("commandConfirmBackCancel"));        
//        setCommandCompleteBack((String) request.getAttribute("commandCompleteBack"));
//        setCommandKaoPhotoDetail((String) request.getAttribute("commandKaoPhotoDetail"));
//        setCommandMailYomiDisp((String) request.getAttribute("commandMailYomiDisp"));
//        setCommandPassYomiDisp((String) request.getAttribute("commandPassYomiDisp"));
//        setCommandMailYomiUpdDisp((String) request.getAttribute("commandMailYomiUpdDisp"));
//        setSexCode((String) request.getAttribute("sexCode"));
//        setHoseiKbn((String) request.getAttribute("hoseiKbn"));
//        setKuroShashinFlg((String) request.getAttribute("kuroShashinFlg"));
//        setHoseiRiyu((String) request.getAttribute("hoseiRiyu"));
//        setKakuninIraiSoshinFlg((String) request.getAttribute("kakuninIraiSoshinFlg"));
//        setKakuninIraiSoshinNen((String) request.getAttribute("kakuninIraiSoshinNen"));
//        setKakuninIraiSoshinTsuki((String) request.getAttribute("kakuninIraiSoshinTsuki"));
//        setKakuninIraiSoshinBi((String) request.getAttribute("kakuninIraiSoshinBi"));
//        setHonsekichiCode((String) request.getAttribute("honsekichiCode"));
//        setKinkyuRenrakusakiTelNo((String) request.getAttribute("kinkyuRenrakusakiTelNo"));
//        setKinmusakiUmuFlg((String) request.getAttribute("kinmusakiUmuFlg"));
//        setKinmusakiMeisho((String) request.getAttribute("kinmusakiMeisho"));
//        setKinmusakiBukaMei((String) request.getAttribute("kinmusakiBukaMei"));
//        setKinmusakiYubinNo1((String) request.getAttribute("kinmusakiYubinNo1"));
//        setKinmusakiYubinNo2((String) request.getAttribute("kinmusakiYubinNo2"));
//        setKinmusakiTodofukeCode((String) request.getAttribute("kinmusakiTodofukeCode"));
//        setKinmusakiAddress1((String) request.getAttribute("kinmusakiAddress1"));
//        setKinmusakiAddress2((String) request.getAttribute("kinmusakiAddress2"));
//        setKinmusakiTelNo((String) request.getAttribute("kinmusakiTelNo"));
//        setKinmusakiGenbaTelNo((String) request.getAttribute("kinmusakiGenbaTelNo"));
//        setSofusakiUmuFlg((String) request.getAttribute("sofusakiUmuFlg"));
//        setSofusakiYubinNo1((String) request.getAttribute("sofusakiYubinNo1"));
//        setSofusakiYubinNo2((String) request.getAttribute("sofusakiYubinNo2"));
//        setSofusakiTodofukeCode((String) request.getAttribute("sofusakiTodofukeCode"));
//        setSofusakiAddress1((String) request.getAttribute("sofusakiAddress1"));
//        setSofusakiAddress2((String) request.getAttribute("sofusakiAddress2"));
//        setHairyoUmuFlg((String) request.getAttribute("hairyoUmuFlg"));
//        setHairyoNaiyo((String) request.getAttribute("hairyoNaiyo"));
//        setKanriMemo((String) request.getAttribute("kanriMemo"));
//        setMailAddress((String) request.getAttribute("mailAddress"));
//        setKaoShashinGazoId((String) request.getAttribute("kaoShashinGazoId"));
//        setFileKbn((String) request.getAttribute("fileKbn"));
//        HttpSession session = request.getSession(false);
//        if (session.getAttribute("MgrLoginJoho") != null) {
//            MgrLoginJoho login = (MgrLoginJoho) session.getAttribute("MgrLoginJoho");
//            setKanrishaId(login.getKanrisha_Id());
//        }
//        setFileItem((FileItem) request.getAttribute("fileData"));
//        setYomikataDispKbn((String) request.getAttribute("yomikataDispKbn"));        
//    }
//
//    /**
//     * ��������͕ϐ��̑Strim
//     */
//    public void trimStringInputField() {
//        this.kanrishaId = BmaStringUtility.trimSpace2(kanrishaId);
//        this.sexCode = BmaStringUtility.trimSpace2(sexCode);
//        this.hoseiKbn = BmaStringUtility.trimSpace2(hoseiKbn);
//        this.kuroShashinFlg = BmaStringUtility.trimSpace2(kuroShashinFlg);
//        this.hoseiRiyu = BmaStringUtility.trimSpace2(hoseiRiyu);
//        this.kakuninIraiSoshinFlg = BmaStringUtility.trimSpace2(kakuninIraiSoshinFlg);
//        this.kakuninIraiSoshinNen = BmaStringUtility.trimSpace2(kakuninIraiSoshinNen);
//        this.kakuninIraiSoshinTsuki = BmaStringUtility.trimSpace2(kakuninIraiSoshinTsuki);
//        this.kakuninIraiSoshinBi = BmaStringUtility.trimSpace2(kakuninIraiSoshinBi);
//        this.honsekichiCode = BmaStringUtility.trimSpace2(honsekichiCode);
//        this.kinkyuRenrakusakiTelNo = BmaStringUtility.trimSpace2(kinkyuRenrakusakiTelNo);
//        this.kinmusakiUmuFlg = BmaStringUtility.trimSpace2(kinmusakiUmuFlg);
//        this.kinmusakiMeisho = BmaStringUtility.trimSpace2(kinmusakiMeisho);
//        this.kinmusakiBukaMei = BmaStringUtility.trimSpace2(kinmusakiBukaMei);
//        this.kinmusakiYubinNo1 = BmaStringUtility.trimSpace2(kinmusakiYubinNo1);
//        this.kinmusakiYubinNo2 = BmaStringUtility.trimSpace2(kinmusakiYubinNo2);
//        this.kinmusakiTodofukeCode = BmaStringUtility.trimSpace2(kinmusakiTodofukeCode);
//        this.kinmusakiAddress1 = BmaStringUtility.trimSpace2(kinmusakiAddress1);
//        this.kinmusakiAddress2 = BmaStringUtility.trimSpace2(kinmusakiAddress2);
//        this.kinmusakiTelNo = BmaStringUtility.trimSpace2(kinmusakiTelNo);
//        this.kinmusakiGenbaTelNo = BmaStringUtility.trimSpace2(kinmusakiGenbaTelNo);
//        this.sofusakiUmuFlg = BmaStringUtility.trimSpace2(sofusakiUmuFlg);
//        this.senniMotoFlg = BmaStringUtility.trimSpace2(senniMotoFlg);
//        this.sofusakiYubinNo1 = BmaStringUtility.trimSpace2(sofusakiYubinNo1);
//        this.sofusakiYubinNo2 = BmaStringUtility.trimSpace2(sofusakiYubinNo2);
//        this.sofusakiTodofukeCode = BmaStringUtility.trimSpace2(sofusakiTodofukeCode);
//        this.sofusakiAddress1 = BmaStringUtility.trimSpace2(sofusakiAddress1);
//        this.sofusakiAddress2 = BmaStringUtility.trimSpace2(sofusakiAddress2);
//        this.hairyoUmuFlg = BmaStringUtility.trimSpace2(hairyoUmuFlg);
//        this.hairyoNaiyo = BmaStringUtility.trimSpace2(hairyoNaiyo);
//        this.kanriMemo = BmaStringUtility.trimSpace2(kanriMemo);
//        this.mailAddress = BmaStringUtility.trimSpace2(mailAddress);
//        this.kaoShashinGazoId = BmaStringUtility.trimSpace2(kaoShashinGazoId);
//        this.fileKbn = BmaStringUtility.trimSpace2(fileKbn);
//    }
//    /**
//     * ��������͕ϐ��i�S�p���ځj�̔��p������S�p�����ɒu��
//     */
//    public void toZenkakuStringInputField(){
//        /*�Ζ���*/
//        this.kinmusakiMeisho = BmaStringUtility.convertHankakuToZenkakuBma(kinmusakiMeisho);
//        this.kinmusakiBukaMei = BmaStringUtility.convertHankakuToZenkakuBma(kinmusakiBukaMei);
//        this.kinmusakiAddress1 = BmaStringUtility.convertHankakuToZenkakuBma(kinmusakiAddress1);
//        this.kinmusakiAddress2 = BmaStringUtility.convertHankakuToZenkakuBma(kinmusakiAddress2);
//        /*���t��*/
//        this.sofusakiAddress1 = BmaStringUtility.convertHankakuToZenkakuBma(sofusakiAddress1);
//        this.sofusakiAddress2 = BmaStringUtility.convertHankakuToZenkakuBma(sofusakiAddress2);
//        /*�z�����e*/
//        this.hairyoNaiyo = BmaStringUtility.convertHankakuToZenkakuBma(hairyoNaiyo);
//        /*�␳�˗�*/
//        this.hoseiRiyu = BmaStringUtility.convertHankakuToZenkakuBma(hoseiRiyu);
//    }
//    //</editor-fold>
//
//    //<editor-fold defaultstate="collapsed" desc="�Q�b�^�[/�Z�b�^�[">
//    /**
//     * �\�����
//     *
//     * @return the dispJoho
//     */
//    public MskJoho getDispJoho() {
//        return dispJoho;
//    }
//
//    /**
//     * �\�����
//     *
//     * @param dispJoho the dispJoho to set
//     */
//    public void setDispJoho(MskJoho dispJoho) {
//        this.dispJoho = dispJoho;
//    }
//
//    /**
//     * �Ǘ��҂h�c
//     *
//     * @return the kanrishaId
//     */
//    public String getKanrishaId() {
//        return kanrishaId;
//    }
//
//    /**
//     * �Ǘ��҂h�c
//     *
//     * @param kanrishaId the kanrishaId to set
//     */
//    public void setKanrishaId(String kanrishaId) {
//        this.kanrishaId = kanrishaId;
//    }
//
//    /**
//     * ���ʃR�[�h
//     *
//     * @return the sexCode
//     */
//    public String getSexCode() {
//        return sexCode;
//    }
//
//    /**
//     * ���ʃR�[�h
//     *
//     * @param sexCode the sexCode to set
//     */
//    public void setSexCode(String sexCode) {
//        this.sexCode = sexCode;
//    }
//
//    /**
//     * �t�@�C��
//     *
//     * @return the fileItem
//     */
//    public FileItem getFileItem() {
//        return fileItem;
//    }
//
//    /**
//     * �t�@�C��
//     *
//     * @param fileItem the fileItem to set
//     */
//    public void setFileItem(FileItem fileItem) {
//        this.fileItem = fileItem;
//    }
//
//    /**
//     * �t�@�C����
//     *
//     * @return the fileName
//     */
//    public String getKaoShashinGazoId() {
//        return kaoShashinGazoId;
//    }
//
//    /**
//     * �t�@�C����
//     *
//     * @param fileName the fileName to set
//     */
//    public void setKaoShashinGazoId(String kaoShashinGazoId) {
//        this.kaoShashinGazoId = kaoShashinGazoId;
//    }
//    
//    /**
//     * �t�@�C���敪
//     *
//     * @return the fileKbn
//     */
//    public String getFileKbn() {
//        return fileKbn;
//    }
//
//    /**
//     * �t�@�C���敪
//     *
//     * @param fileKbn the fileKbn to set
//     */
//    public void setFileKbn(String fileKbn) {
//        this.fileKbn = fileKbn;
//    }
//    
//    /**
//     * �␳�敪
//     *
//     * @return the hoseiKbn
//     */
//    public String getHoseiKbn() {
//        return hoseiKbn;
//    }
//
//    /**
//     * �␳�敪
//     *
//     * @param hoseiKbn the hoseiKbn to set
//     */
//    public void setHoseiKbn(String hoseiKbn) {
//        this.hoseiKbn = hoseiKbn;
//    }
//
//    /**
//         * ���ʐ^�t���O
//     *
//     * @return the kuroShashinFlg
//     */
//    public String getKuroShashinFlg() {
//        return kuroShashinFlg;
//    }
//
//    /**
//     * ���ʐ^�t���O
//     *
//     * @param kuroShashinFlg the kuroShashinFlg to set
//     */
//    public void setKuroShashinFlg(String kuroShashinFlg) {
//        this.kuroShashinFlg = kuroShashinFlg;
//    }
//
//    /**
//     * �␳���R
//     *
//     * @return the hoseiRiyu
//     */
//    public String getHoseiRiyu() {
//        return hoseiRiyu;
//    }
//
//    /**
//     * �␳���R
//     *
//     * @param hoseiRiyu the hoseiRiyu to set
//     */
//    public void setHoseiRiyu(String hoseiRiyu) {
//        this.hoseiRiyu = hoseiRiyu;
//    }
//
//    /**
//     * �m�F�˗����M�t���O
//     *
//     * @return the kakuninIraiSoshinFlg
//     */
//    public String getKakuninIraiSoshinFlg() {
//        return kakuninIraiSoshinFlg;
//    }
//
//    /**
//     * �m�F�˗����M�t���O
//     *
//     * @param kakuninIraiSoshinFlg the kakuninIraiSoshinFlg to set
//     */
//    public void setKakuninIraiSoshinFlg(String kakuninIraiSoshinFlg) {
//        this.kakuninIraiSoshinFlg = kakuninIraiSoshinFlg;
//    }
//
//    /**
//     * �m�F�˗��A�����i�N�j
//     * 
//     * @param kakuninIraiSoshinNen the kakuninIraiSoshinNen to set
//     */
//    public void setKakuninIraiSoshinNen(String kakuninIraiSoshinNen) {
//        this.kakuninIraiSoshinNen = kakuninIraiSoshinNen;
//    }
//
//    /**
//     * �m�F�˗��A�����i�N�j
//     * 
//     * @return the kakuninIraiSoshinNen
//     */
//    public String getKakuninIraiSoshinNen() {
//        return kakuninIraiSoshinNen;
//    }
//
//    /**
//     * �m�F�˗��A�����i���j
//     * 
//     * @param kakuninIraiSoshinTsuki the kakuninIraiSoshinTsuki to set
//     */
//    public void setKakuninIraiSoshinTsuki(String kakuninIraiSoshinTsuki) {
//        this.kakuninIraiSoshinTsuki = kakuninIraiSoshinTsuki;
//    }
//
//    /**
//     * �m�F�˗��A�����i���j
//     * 
//     * @return the kakuninIraiSoshinTsuki
//     */
//    public String getKakuninIraiSoshinTsuki() {
//        return kakuninIraiSoshinTsuki;
//    }
//
//    /**
//     * �m�F�˗��A�����i���j
//     * 
//     * @param kakuninIraiSoshinBi the kakuninIraiSoshinBi to set
//     */
//    public void setKakuninIraiSoshinBi(String kakuninIraiSoshinBi) {
//        this.kakuninIraiSoshinBi = kakuninIraiSoshinBi;
//    }
//
//    /**
//     * �m�F�˗��A�����i���j
//     * 
//     * @return the kakuninIraiSoshinBi
//     */
//    public String getKakuninIraiSoshinBi() {
//        return kakuninIraiSoshinBi;
//    }
//
//    /**
//     * �m�F�˗����M���\���p
//     *
//     * @return
//     */
//    public String getKakuninIraiSoshinBiDisp() {
//        try {
//            if (this.kakuninIraiSoshinNen.isEmpty() && this.kakuninIraiSoshinTsuki.isEmpty() && this.kakuninIraiSoshinBi.isEmpty()) {
//                return "";
//            }
//                return this.kakuninIraiSoshinNen + "/"
//                    + this.kakuninIraiSoshinTsuki + "/"
//                    + this.kakuninIraiSoshinBi;
//        } catch (Exception e) {
//            return "";
//        }
//    }
//
//    /**
//     * �{�Вn�R�[�h
//     *
//     * @return the honsekichiCode
//     */
//    public String getHonsekichiCode() {
//        return honsekichiCode;
//    }
//
//    /**
//     * �{�Вn�R�[�h
//     *
//     * @param honsekichiCode the honsekichiCode to set
//     */
//    public void setHonsekichiCode(String honsekichiCode) {
//        this.honsekichiCode = honsekichiCode;
//    }
//
//    /**
//     * �ً}�A����d�b�ԍ�
//     *
//     * @return the kinkyuRenrakusakiTelNo
//     */
//    public String getKinkyuRenrakusakiTelNo() {
//        return kinkyuRenrakusakiTelNo;
//    }
//
//    /**
//     * �ً}�A����d�b�ԍ�
//     *
//     * @param kinkyuRenrakusakiTelNo the kinkyuRenrakusakiTelNo to set
//     */
//    public void setKinkyuRenrakusakiTelNo(String kinkyuRenrakusakiTelNo) {
//        this.kinkyuRenrakusakiTelNo = kinkyuRenrakusakiTelNo;
//    }
//
//    /**
//     * ���[���A�h���X
//     *
//     * @return the mailAddress
//     */
//    public String getMailAddress() {
//        return mailAddress;
//    }
//
//    /**
//     * ���[���A�h���X
//     *
//     * @param mailAddress the mailAddress to set
//     */
//    public void setMailAddress(String mailAddress) {
//        this.mailAddress = mailAddress;
//    }
//
//    /**
//     * ���[���A�h���X�ǂݕ�
//     *
//     * @return the mailAddressYomiList
//     */
//    public List<Option> getMailAddressYomiList() {
//        return mailAddressYomiList;
//    }
//
//    /**
//     * ���[���A�h���X�ǂݕ�
//     *
//     * @param mailAddressYomiList the mailAddressYomiList to set
//     */
//    public void setMailAddressYomiList(List<Option> mailAddressYomiList) {
//        this.mailAddressYomiList = mailAddressYomiList;
//    }
//
//    /**
//     * �Ζ���L���t���O
//     *
//     * @return the kinmusakiUmuFlg
//     */
//    public String getKinmusakiUmuFlg() {
//        return kinmusakiUmuFlg;
//    }
//
//    /**
//     * �Ζ���L���t���O
//     *
//     * @param kinmusakiUmuFlg the kinmusakiUmuFlg to set
//     */
//    public void setKinmusakiUmuFlg(String kinmusakiUmuFlg) {
//        this.kinmusakiUmuFlg = kinmusakiUmuFlg;
//    }
//
//    /**
//     * �Ζ��於��
//     *
//     * @return the kinmusakiMeisho
//     */
//    public String getKinmusakiMeisho() {
//        return kinmusakiMeisho;
//    }
//
//    /**
//     * �Ζ��於��
//     *
//     * @param kinmusakiMeisho the kinmusakiMeisho to set
//     */
//    public void setKinmusakiMeisho(String kinmusakiMeisho) {
//        this.kinmusakiMeisho = kinmusakiMeisho;
//    }
//
//    /**
//     * �Ζ��敔�ۖ�
//     *
//     * @return the kinmusakiBukaMei
//     */
//    public String getKinmusakiBukaMei() {
//        return kinmusakiBukaMei;
//    }
//
//    /**
//     * �Ζ��敔�ۖ�
//     *
//     * @param kinmusakiBukaMei the kinmusakiBukaMei to set
//     */
//    public void setKinmusakiBukaMei(String kinmusakiBukaMei) {
//        this.kinmusakiBukaMei = kinmusakiBukaMei;
//    }
//
//    /**
//     * �Ζ���X�֔ԍ��P
//     *
//     * @return the kinmusakiYubinNo1
//     */
//    public String getKinmusakiYubinNo1() {
//        return kinmusakiYubinNo1;
//    }
//
//    /**
//     * �Ζ���X�֔ԍ��P
//     *
//     * @param kinmusakiYubinNo1 the kinmusakiYubinNo1 to set
//     */
//    public void setKinmusakiYubinNo1(String kinmusakiYubinNo1) {
//        this.kinmusakiYubinNo1 = kinmusakiYubinNo1;
//    }
//
//    /**
//     * �Ζ���X�֔ԍ��Q
//     *
//     * @return the kinmusakiYubinNo2
//     */
//    public String getKinmusakiYubinNo2() {
//        return kinmusakiYubinNo2;
//    }
//
//    /**
//     * �Ζ���X�֔ԍ��Q
//     *
//     * @param kinmusakiYubinNo2 the kinmusakiYubinNo2 to set
//     */
//    public void setKinmusakiYubinNo2(String kinmusakiYubinNo2) {
//        this.kinmusakiYubinNo2 = kinmusakiYubinNo2;
//    }
//
//    /**
//     * �Ζ���s���{���R�[�h
//     *
//     * @return the kinmusakiTodofukeCode
//     */
//    public String getKinmusakiTodofukeCode() {
//        return kinmusakiTodofukeCode;
//    }
//
//    /**
//     * �Ζ���s���{���R�[�h
//     *
//     * @param kinmusakiTodofukeCode the kinmusakiTodofukeCode to set
//     */
//    public void setKinmusakiTodofukeCode(String kinmusakiTodofukeCode) {
//        this.kinmusakiTodofukeCode = kinmusakiTodofukeCode;
//    }
//
//    /**
//     * �Ζ���s���{���R�[�h�\���p
//     *
//     * @return the kinmusakiTodofukeCode
//     */
//    public String getKinmusakiTodofukeCodeDisp() {
//        for (Option op : todofukeList) {
//            if (op.getValue().equals(kinmusakiTodofukeCode)) {
//                return op.getLabel();
//            }
//        }
//        return "";
//    }
//
//    /**
//     * �Ζ���s�撬����
//     *
//     * @return the kinmusakiAddress1
//     */
//    public String getKinmusakiAddress1() {
//        return kinmusakiAddress1;
//    }
//
//    /**
//     * �Ζ���s�撬����
//     *
//     * @param kinmusakiAddress1 the kinmusakiAddress1 to set
//     */
//    public void setKinmusakiAddress1(String kinmusakiAddress1) {
//        this.kinmusakiAddress1 = kinmusakiAddress1;
//    }
//
//    /**
//     * �Ζ���r���}���V�����A�p�[�g
//     *
//     * @return the kinmusakiAddress2
//     */
//    public String getKinmusakiAddress2() {
//        return kinmusakiAddress2;
//    }
//
//    /**
//     * �Ζ���r���}���V�����A�p�[�g
//     *
//     * @param kinmusakiAddress2 the kinmusakiAddress2 to set
//     */
//    public void setKinmusakiAddress2(String kinmusakiAddress2) {
//        this.kinmusakiAddress2 = kinmusakiAddress2;
//    }
//
//    /**
//     * �Ζ���d�b�ԍ�
//     *
//     * @return the kinmusakiTelNo
//     */
//    public String getKinmusakiTelNo() {
//        return kinmusakiTelNo;
//    }
//
//    /**
//     * �Ζ���d�b�ԍ�
//     *
//     * @param kinmusakiTelNo the kinmusakiTelNo to set
//     */
//    public void setKinmusakiTelNo(String kinmusakiTelNo) {
//        this.kinmusakiTelNo = kinmusakiTelNo;
//    }
//
//    /**
//     * �Ζ��挻��d�b�ԍ�
//     *
//     * @return the kinmusakiGenbaTelNo
//     */
//    public String getKinmusakiGenbaTelNo() {
//        return kinmusakiGenbaTelNo;
//    }
//
//    /**
//     * �Ζ��挻��d�b�ԍ�
//     *
//     * @param kinmusakiGenbaTelNo the kinmusakiGenbaTelNo to set
//     */
//    public void setKinmusakiGenbaTelNo(String kinmusakiGenbaTelNo) {
//        this.kinmusakiGenbaTelNo = kinmusakiGenbaTelNo;
//    }
//
//    /**
//     * ���t��L���t���O
//     *
//     * @return the sofusakiUmuFlg
//     */
//    public String getSofusakiUmuFlg() {
//        return sofusakiUmuFlg;
//    }
//
//    /**
//     * ���t��L���t���O
//     *
//     * @param sofusakiUmuFlg the sofusakiUmuFlg to set
//     */
//    public void setSofusakiUmuFlg(String sofusakiUmuFlg) {
//        this.sofusakiUmuFlg = sofusakiUmuFlg;
//    }
//
//    /**
//     * ���t��X�֔ԍ��P
//     *
//     * @return the sofusakiYubinNo1
//     */
//    public String getSofusakiYubinNo1() {
//        return sofusakiYubinNo1;
//    }
//
//    /**
//     * ���t��X�֔ԍ��P
//     *
//     * @param sofusakiYubinNo1 the sofusakiYubinNo1 to set
//     */
//    public void setSofusakiYubinNo1(String sofusakiYubinNo1) {
//        this.sofusakiYubinNo1 = sofusakiYubinNo1;
//    }
//
//    /**
//     * ���t��X�֔ԍ��Q
//     *
//     * @return the sofusakiYubinNo2
//     */
//    public String getSofusakiYubinNo2() {
//        return sofusakiYubinNo2;
//    }
//
//    /**
//     * ���t��X�֔ԍ��Q
//     *
//     * @param sofusakiYubinNo2 the sofusakiYubinNo2 to set
//     */
//    public void setSofusakiYubinNo2(String sofusakiYubinNo2) {
//        this.sofusakiYubinNo2 = sofusakiYubinNo2;
//    }
//
//    /**
//     * ���t��s���{���R�[�h
//     *
//     * @return the sofusakiTodofukeCode
//     */
//    public String getSofusakiTodofukeCode() {
//        return sofusakiTodofukeCode;
//    }
//
//    /**
//     * ���t��s���{���R�[�h
//     *
//     * @param sofusakiTodofukeCode the sofusakiTodofukeCode to set
//     */
//    public void setSofusakiTodofukeCode(String sofusakiTodofukeCode) {
//        this.sofusakiTodofukeCode = sofusakiTodofukeCode;
//    }
//
//    /**
//     * ���t��s���{���R�[�h�\���p
//     *
//     * @return the sofusakiTodofukeCode
//     */
//    public String getSofusakiTodofukeCodeDisp() {
//        for (Option op : todofukeList) {
//            if (op.getValue().equals(sofusakiTodofukeCode)) {
//                return op.getLabel();
//            }
//        }
//        return "";
//    }
//
//    /**
//     * ���t��s�撬����
//     *
//     * @return the sofusakiAddress1
//     */
//    public String getSofusakiAddress1() {
//        return sofusakiAddress1;
//    }
//
//    /**
//     * ���t��s�撬����
//     *
//     * @param sofusakiAddress1 the sofusakiAddress1 to set
//     */
//    public void setSofusakiAddress1(String sofusakiAddress1) {
//        this.sofusakiAddress1 = sofusakiAddress1;
//    }
//
//    /**
//     * ���t��r���}���V�����A�p�[�g
//     *
//     * @return the sofusakiAddress2
//     */
//    public String getSofusakiAddress2() {
//        return sofusakiAddress2;
//    }
//
//    /**
//     * ���t��r���}���V�����A�p�[�g
//     *
//     * @param sofusakiAddress2 the sofusakiAddress2 to set
//     */
//    public void setSofusakiAddress2(String sofusakiAddress2) {
//        this.sofusakiAddress2 = sofusakiAddress2;
//    }
//
//    /**
//     * �z���L���t���O
//     *
//     * @return the hairyoUmuFlg
//     */
//    public String getHairyoUmuFlg() {
//        return hairyoUmuFlg;
//    }
//
//    /**
//     * �z���L���t���O
//     *
//     * @param hairyoUmuFlg the hairyoUmuFlg to set
//     */
//    public void setHairyoUmuFlg(String hairyoUmuFlg) {
//        this.hairyoUmuFlg = hairyoUmuFlg;
//    }
//    
//    /**
//     * �J�ڌ��t���O
//     *
//     * @return the senniMotoFlg
//     */
//    public String getSenniMotoFlg() {
//        return senniMotoFlg;
//    }
//
//    /**
//     * �J�ڌ��t���O
//     *
//     * @param sofusakiUmuFlg the senniMotoFlg to set
//     */
//    public void setSenniMotoFlg(String senniMotoFlg) {
//        this.senniMotoFlg = senniMotoFlg;
//    }
//
//    /**
//     * �z�����e
//     *
//     * @return the hairyoNaiyo
//     */
//    public String getHairyoNaiyo() {
//        return hairyoNaiyo;
//    }
//
//    /**
//     * �z�����e
//     *
//     * @param hairyoNaiyo the hairyoNaiyo to set
//     */
//    public void setHairyoNaiyo(String hairyoNaiyo) {
//        this.hairyoNaiyo = hairyoNaiyo;
//    }
//
//    /**
//     * �Ǘ�����
//     *
//     * @return the kanriMemo
//     */
//    public String getKanriMemo() {
//        return kanriMemo;
//    }
//
//    /**
//     * �Ǘ�����
//     *
//     * @param kanriMemo the KanriMemo to set
//     */
//    public void setKanriMemo(String kanriMemo) {
//        this.kanriMemo = kanriMemo;
//    }   
//    
//    /**
//     * �ǂݕ��\���{�^���t���O
//     *
//     * @return the yomikataDispKbn
//     */
//    public String getYomikataDispKbn() {
//        return yomikataDispKbn;
//    }
//
//    /**
//     * �ǂݕ��\���{�^���t���O
//     *
//     * @param yomikataDispKbn the yomikataDispKbn to set
//     */
//    public void setYomikataDispKbn(String yomikataDispKbn) {
//        this.yomikataDispKbn = yomikataDispKbn;
//    }
//
//    /**
//     * �G���[���b�Z�[�W
//     *
//     * @return the errors
//     */
//    public Messages getErrors() {
//        return errors;
//    }
//
//    /**
//     * �G���[���b�Z�[�W
//     *
//     * @param errors the errors to set
//     */
//    public void setErrors(Messages errors) {
//        this.errors = errors;
//    }
//
//    /**
//     * �\�����ڍ�
//     *
//     * @return the commandMskJohoDetail
//     */
//    public String getCommandMskJohoDetail() {
//        return commandMskJohoDetail;
//    }
//
//    /**
//     * �\�����ڍ�
//     *
//     * @param commandMskJohoDetail the commandMskJohoDetail to set
//     */
//    public void setCommandMskJohoDetail(String commandMskJohoDetail) {
//        this.commandMskJohoDetail = commandMskJohoDetail;
//    }
//
//    /**
//     * �R�}���h �������ʈꗗ�ɖ߂�
//     *
//     * @return the commandDetailBack
//     */
//    public String getCommandDetailBack() {
//        return commandDetailBack;
//    }
//
//    /**
//     * �R�}���h �������ʈꗗ�ɖ߂�
//     *
//     * @param commandDetailBack the commandDetailBack to set
//     */
//    public void setCommandDetailBack(String commandDetailBack) {
//        this.commandDetailBack = commandDetailBack;
//    }
//
//    /**
//     * �R�}���h �\�����̕ύX
//     *
//     * @return the commandDetailUpdate
//     */
//    public String getCommandDetailUpdate() {
//        return commandDetailUpdate;
//    }
//
//    /**
//     * �R�}���h �\�����̕ύX
//     *
//     * @param commandDetailUpdate the commandDetailUpdate to set
//     */
//    public void setCommandDetailUpdate(String commandDetailUpdate) {
//        this.commandDetailUpdate = commandDetailUpdate;
//    }
//
//    /**
//     * �R�}���h ����p�y�[�W
//     *
//     * @return the commandDetailPrint
//     */
//    public String getCommandDetailPrint() {
//        return commandDetailPrint;
//    }
//
//    /**
//     * �R�}���h ����p�y�[�W
//     *
//     * @param commandDetailPrint the commandDetailPrint to set
//     */
//    public void setCommandDetailPrint(String commandDetailPrint) {
//        this.commandDetailPrint = commandDetailPrint;
//    }
//
//    /**
//     * �R�}���h �\�����ڍׂ֖߂�
//     *
//     * @return the commandInputBack
//     */
//    public String getCommandInputBack() {
//        return commandInputBack;
//    }
//
//    /**
//     * �R�}���h �\�����ڍׂ֖߂�
//     *
//     * @param commandInputBack the commandInputBack to set
//     */
//    public void setCommandInputBack(String commandInputBack) {
//        this.commandInputBack = commandInputBack;
//    }
//
//    /**
//     * �R�}���h �\�����ύX���͉�� ����
//     *
//     * @return the commandInputNext
//     */
//    public String getCommandInputNext() {
//        return commandInputNext;
//    }
//
//    /**
//     * �R�}���h �\�����ύX���͉�� ����
//     *
//     * @param commandInputNext the commandInputNext to set
//     */
//    public void setCommandInputNext(String commandInputNext) {
//        this.commandInputNext = commandInputNext;
//    }
//
//    /**
//     * �R�}���h �\�����ύX���͊m�F��� �߂�
//     *
//     * @return the commandConfirmBack
//     */
//    public String getCommandConfirmBack() {
//        return commandConfirmBack;
//    }
//
//    /**
//     * �R�}���h �\�����ύX���͊m�F��� �߂�
//     *
//     * @param commandConfirmBack the commandConfirmBack to set
//     */
//    public void setCommandConfirmBack(String commandConfirmBack) {
//        this.commandConfirmBack = commandConfirmBack;
//    }
//
//    /**
//     * �R�}���h �\�����ύX���͊m�F��� �߂�L�����Z��
//     *
//     * @return the commandConfirmBackCancel
//     */
//    public String getCommandConfirmBackCancel() {
//        return commandConfirmBackCancel;
//    }
//
//    /**
//     * �R�}���h �\�����ύX���͊m�F��� �߂�L�����Z��
//     *
//     * @param commandConfirmBackCancel the commandConfirmBackCancel to set
//     */
//    public void setCommandConfirmBackCancel(String commandConfirmBackCancel) {
//        this.commandConfirmBackCancel = commandConfirmBackCancel;
//    }
//
//    /**
//     * �R�}���h �\�����ύX���͊m�F��� �m��
//     *
//     * @return the commandConfirmNext
//     */
//    public String getCommandConfirmNext() {
//        return commandConfirmNext;
//    }
//
//    /**
//     * �R�}���h �\�����ύX���͊m�F��� �m��
//     *
//     * @param commandConfirmNext the commandConfirmNext to set
//     */
//    public void setCommandConfirmNext(String commandConfirmNext) {
//        this.commandConfirmNext = commandConfirmNext;
//    }
//
//    /**
//     * �R�}���h �\�����ύX������� �������ʈꗗ�֖߂�
//     *
//     * @return the commandCompleteBack
//     */
//    public String getCommandCompleteBack() {
//        return commandCompleteBack;
//    }
//
//    /**
//     * �R�}���h �\�����ύX������� �������ʈꗗ�֖߂�
//     *
//     * @param commandCompleteBack the commandCompleteBack to set
//     */
//    public void setCommandCompleteBack(String commandCompleteBack) {
//        this.commandCompleteBack = commandCompleteBack;
//    }
//    
//    /**
//     * �\�����ڍ�(�ʐ^�ꗗ����)
//     *
//     * @return the commandMskJohoDetail
//     */
//    public String getCommandKaoPhotoDetail() {
//        return commandKaoPhotoDetail;
//    }
//
//    /**
//     * �\�����ڍ�(�ʐ^�ꗗ����)
//     *
//     * @param setCommandKaoPhotoDetail the setCommandKaoPhotoDetail to set
//     */
//    public void setCommandKaoPhotoDetail(String commandKaoPhotoDetail) {
//        this.commandKaoPhotoDetail = commandKaoPhotoDetail;
//    }
//    
//    /**
//     * �R�}���h ���[���A�h���X�ǂݕ�
//     *
//     * @return the commandMailYomiDisp
//     */
//    public String getCommandMailYomiDisp() {
//        return commandMailYomiDisp;
//    }
//
//    /**
//     * �R�}���h ���[���A�h���X�ǂݕ�
//     *
//     * @param commandMailYomiDisp the commandMailYomiDisp to set
//     */
//    public void setCommandMailYomiDisp(String commandMailYomiDisp) {
//        this.commandMailYomiDisp = commandMailYomiDisp;
//    }
//
//    /**
//     * �R�}���h �p�X���[�h�ǂݕ�
//     *
//     * @return the commandPassYomiDisp
//     */
//    public String getCommandPassYomiDisp() {
//        return commandPassYomiDisp;
//    }
//
//    /**
//     * �R�}���h �p�X���[�h�ǂݕ�
//     *
//     * @param commandPassYomiDisp the commandPassYomiDisp to set
//     */
//    public void setCommandPassYomiDisp(String commandPassYomiDisp) {
//        this.commandPassYomiDisp = commandPassYomiDisp;
//    }
//    
//    /**
//     * �R�}���h ���[���A�h���X�ǂݕ�(�X�V��)
//     *
//     * @return the commandMailYomiUpdDisp
//     */
//    public String getCommandMailYomiUpdDisp() {
//        return commandMailYomiUpdDisp;
//    }
//
//    /**
//     * �R�}���h ���[���A�h���X�ǂݕ�(�X�V��)
//     *
//     * @param commandMailYomiUpdDisp the commandMailYomiUpdDisp to set
//     */
//    public void setCommandMailYomiUpdDisp(String commandMailYomiUpdDisp) {
//        this.commandMailYomiUpdDisp = commandMailYomiUpdDisp;
//    }
//    
//    /**
//     * �s���{�����X�g
//     *
//     * @return the todofukeList
//     */
//    public List<Option> getTodofukeList() {
//        return todofukeList;
//    }
//
//    /**
//     * �s���{�����X�g
//     *
//     * @param todofukeList the todofukeList to set
//     */
//    public void setTodofukeList(List<Option> todofukeList) {
//        this.todofukeList = todofukeList;
//    }
//
//    /**
//     * �����ꃊ�X�g
//     *
//     * @return the kaijoList
//     */
//    public List<KaijoOption> getKaijoList() {
//        return kaijoList;
//    }
//
//    /**
//     * �����ꃊ�X�g
//     *
//     * @param kaijoList the kaijoList to set
//     */
//    public void setKaijoList(List<KaijoOption> kaijoList) {
//        this.kaijoList = kaijoList;
//    }
//
//    /**
//     * �E�惊�X�g
//     *
//     * @return the shokuikiList
//     */
//    public List<Option> getShokuikiList() {
//        return shokuikiList;
//    }
//
//    /**
//     * �E�惊�X�g
//     *
//     * @param shokuikiList the shokuikiList to set
//     */
//    public void setShokuikiList(List<Option> shokuikiList) {
//        this.shokuikiList = shokuikiList;
//    }
//
//    /**
//     * �E�����X�g
//     *
//     * @return the shokumuList
//     */
//    public List<Option> getShokumuList() {
//        return shokumuList;
//    }
//
//    /**
//     * �E�����X�g
//     *
//     * @param shokumuList the shokumuList to set
//     */
//    public void setShokumuList(List<Option> shokumuList) {
//        this.shokumuList = shokumuList;
//    }
//
//    /**
//     * �閧�̎��⃊�X�g
//     *
//     * @return the passwdQuestionList
//     */
//    public List<Option> getPasswdQuestionList() {
//        return passwdQuestionList;
//    }
//
//    /**
//     * �閧�̎��⃊�X�g
//     *
//     * @param passwdQuestionList the passwdQuestionList to set
//     */
//    public void setPasswdQuestionList(List<Option> passwdQuestionList) {
//        this.passwdQuestionList = passwdQuestionList;
//    }
//
//    /**
//     * ����N���X�g
//     * 
//     * @return the yearDisp
//     */
//    public List<Option> getYearDisp() {
//        return yearDisp;
//    }
//
//    /**
//     * ����N���X�g
//     * 
//     * @param yearDisp the yearDisp to set
//     */
//    public void setYearDisp(List<Option> yearDisp) {
//        this.yearDisp = yearDisp;
//    }
//
//    /**
//     * �����X�g
//     * 
//     * @return the monthDisp
//     */
//    public List<Option> getMonthDisp() {
//        return monthDisp;
//    }
//
//    /**
//     * �����X�g
//     * 
//     * @param monthDisp the monthDisp to set
//     */
//    public void setMonthDisp(List<Option> monthDisp) {
//        this.monthDisp = monthDisp;
//    }
//
//    /**
//     * �����X�g
//     * 
//     * @return the dayDisp
//     */
//    public List<Option> getDayDisp() {
//        return dayDisp;
//    }
//
//    /**
//     * �����X�g
//     * 
//     * @param dayDisp the dayDisp to set
//     */
//    public void setDayDisp(List<Option> dayDisp) {
//        this.dayDisp = dayDisp;
//    }
//
//    /**
//     * ���ʕύX�L��
//     *
//     * @return true:�ύX�L
//     */
//    public boolean isSexCodeChange() {
//        return !sexCode.equals(dispJoho.getSexCode());
//    }
//
//    /**
//     * �␳�敪�ύX�L��
//     *
//     * @return true:�ύX�L
//     */
//    public boolean isHoseiKbnChange() {
//        return !hoseiKbn.equals(dispJoho.getHoseiIraiKbn());
//    }
//
//    /**
//     * �m�F�˗����M�t���O�ύX�L��
//     *
//     * @return true:�ύX�L
//     */
//    public boolean isKuroShashinFlgChange() {
//        return !kuroShashinFlg.equals(dispJoho.getKuroShashinFlg());
//    }
//
//    /**
//     * �␳���R�ύX�L��
//     *
//     * @return true:�ύX�L
//     */
//    public boolean isHoseiRiyuChange() {
//        return !hoseiRiyu.equals(dispJoho.getHoseiIraiRiyu());
//    }
//
//    /**
//     * �m�F�˗����M�t���O�ύX�L��
//     *
//     * @return true:�ύX�L
//     */
//    public boolean isKakuninIraiSoshinFlgChange() {
//        return !kakuninIraiSoshinFlg.equals(dispJoho.getKakuninIraiSoshinFlg());
//    }
//
//    /**
//     * �m�F�˗����M���ύX�L��
//     *
//     * @return true:�ύX�L
//     */
//    public boolean isKakuninIraiSoshinBiChange() {
//        return !(kakuninIraiSoshinNen + kakuninIraiSoshinTsuki + kakuninIraiSoshinBi).equals(dispJoho.getKakuninIraiSoshinBi());
//    }
//
//    /**
//     * �{�Вn�R�[�h�ύX�L��
//     *
//     * @return true:�ύX�L
//     */
//    public boolean isHonsekichiCodeChange() {
//        return !honsekichiCode.equals(dispJoho.getHonsekichiCode());
//    }
//
//    /**
//     * �ً}�A����ύX�L��
//     *
//     * @return true:�ύX�L
//     */
//    public boolean isKinkyuRenrakusakiTelNoChange() {
//        return !kinkyuRenrakusakiTelNo.equals(dispJoho.getKinkyuRenrakusakiTelNo());
//    }
//
//    /**
//     * �Ζ���L���t���O�ύX�L��
//     *
//     * @return true:�ύX�L
//     */
//    public boolean isKinmusakiUmuFlgChange() {
//        return !kinmusakiUmuFlg.equals(dispJoho.getKinmusakiUmuFlg());
//    }
//
//    /**
//     * �Ζ��於�̕ύX�L��
//     *
//     * @return true:�ύX�L
//     */
//    public boolean isKinmusakiMeishoChange() {
//        return !kinmusakiMeisho.equals(dispJoho.getKinmusakiMeisho());
//    }
//
//    /**
//     * �Ζ��敔�ۖ��ύX�L��
//     *
//     * @return true:�ύX�L
//     */
//    public boolean isKinmusakiBukaMeiChange() {
//        return !kinmusakiBukaMei.equals(dispJoho.getKinmusakiBukaName());
//    }
//
//    /**
//     * �Ζ���X�֔ԍ��ύX�L��
//     *
//     * @return true:�ύX�L
//     */
//    public boolean isKinmusakiYubinNoChange() {
//        return !(kinmusakiYubinNo1 + kinmusakiYubinNo2).equals(dispJoho.getKinmusakiYubinNo());
//    }
//
//    /**
//     * �Ζ���s���{���R�[�h�ύX�L��
//     *
//     * @return true:�ύX�L
//     */
//    public boolean isKinmusakiTodofukeCodeChange() {
//        return !kinmusakiTodofukeCode.equals(dispJoho.getKinmusakiTodofukenCode());
//    }
//
//    /**
//     * �Ζ���s�撬�����ύX�L��
//     *
//     * @return true:�ύX�L
//     */
//    public boolean isKinmusakiAddress1Change() {
//        return !kinmusakiAddress1.equals(dispJoho.getKinmusakiShikuchosonName());
//    }
//
//    /**
//     * �Ζ���r���}���V�����A�p�[�g���ύX�L��
//     *
//     * @return true:�ύX�L
//     */
//    public boolean isKinmusakiAddress2Change() {
//        return !kinmusakiAddress2.equals(dispJoho.getKinmusakiBuildingMansionApartmentName());
//    }
//
//    /**
//     * �Ζ���d�b�ԍ��ύX�L��
//     *
//     * @return true:�ύX�L
//     */
//    public boolean isKinmusakiTelNoChange() {
//        return !kinmusakiTelNo.equals(dispJoho.getKinmusakiTelNo());
//    }
//
//    /**
//     * �Ζ��挻��A����ύX�L��
//     *
//     * @return true:�ύX�L
//     */
//    public boolean isKinmusakiGenbaTelNoChange() {
//        return !kinmusakiGenbaTelNo.equals(dispJoho.getKinmusakiGenbaTelNo());
//    }
//
//    /**
//     * ���t��L���t���O�ύX�L��
//     *
//     * @return true:�ύX�L
//     */
//    public boolean isSofusakiUmuFlgChange() {
//        return !sofusakiUmuFlg.equals(dispJoho.getJukenhyoSofusakiUmuFlg());
//    }
//
//    /**
//     * ���t��X�֔ԍ��ύX�L��
//     *
//     * @return true:�ύX�L
//     */
//    public boolean isSofusakiYubinNoChange() {
//        return !(sofusakiYubinNo1 + sofusakiYubinNo2).equals(dispJoho.getJukenhyoSofusakiYubinNo());
//    }
//
//    /**
//     * ���t��Ɠ��{���R�[�h�ύX�L��
//     *
//     * @return true:�ύX�L
//     */
//    public boolean isSofusakiTodofukeCodeChange() {
//        return !dispJoho.getJukenhyoSofusakiTodofukenCode().equals(sofusakiTodofukeCode);
//    }
//
//    /**
//     * ���t��s�撬�����ύX�L��
//     *
//     * @return true:�ύX�L
//     */
//    public boolean isSofusakiAddress1Change() {
//        return !dispJoho.getJukenhyoSofusakiShikuchosonName().equals(sofusakiAddress1);
//    }
//
//    /**
//     * ���t��r���}���V�����A�p�[�g���ύX�L��
//     *
//     * @return true:�ύX�L
//     */
//    public boolean isSofusakiAddress2Change() {
//        return !dispJoho.getJukenhyoSofusakiBuildingMansionApartmentName().equals(sofusakiAddress2);
//    }
//
//    /**
//     * �z���L���t���O�ύX�L��
//     *
//     * @return true:�ύX�L
//     */
//    public boolean isHairyoUmuFlgChange() {
//        return !hairyoUmuFlg.equals(dispJoho.getHairyoFlg());
//    }
//
//    /**
//     * �z�����e�ύX�L��
//     *
//     * @return true:�ύX�L
//     */
//    public boolean isHairyoNaiyoChange() {
//        return !dispJoho.getHairyoNaiyo().equals(hairyoNaiyo);
//    }
//
//    /**
//     * �Ǘ��҃����ύX�L��
//     *
//     * @return true:�ύX�L
//     */
//    public boolean isKanriMemoChange() {
//        return !kanriMemo.equals(dispJoho.getKanriMemo());
//    }
//    
//    /**
//     * ���[���A�h���X�ύX�L��
//     *
//     * @return true:�ύX�L
//     */
//    public boolean isMailAddressChange() {
//        return !mailAddress.equals(dispJoho.getMailAddress());
//    }
//    
//    /**
//     * ��ʐ^�ύX�L��
//     *
//     * @return true:�ύX�L
//     */
//    public boolean isKaoShashinChange() {
//        return !fileItem.getName().isEmpty();
//    }  
//    //</editor-fold>
//}