package jp.co.nii.sew.presentation;

import java.io.IOException;
import java.util.Map;
import java.util.Properties;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import jp.co.nii.bma.business.domain.KaiinKanriTsushinLog;
import jp.co.nii.bma.business.service.common.BmaConstants;
import static jp.co.nii.bma.business.service.common.BmaConstants.BUSINESS_CODE;
import jp.co.nii.bma.business.service.common.KaiinKanriSystemCooperateService;
import jp.co.nii.sew.business.service.ApplicationService;
import jp.co.nii.sew.utility.CheckUtility;
import jp.co.nii.sew.utility.DateTimeUtility;
import jp.co.nii.sew.utility.OAuth2Details;
import jp.co.nii.sew.utility.OAuthConstants;
import jp.co.nii.sew.utility.OAuthUtils;
import static jp.co.nii.sew.utility.OAuthUtils.getAuthorizationHeaderForAccessToken;
import jp.co.nii.sew.utility.PropertyUtility;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * ���_�C���N�^�E�T�[�u���b�g
 *
 * SI framework�ł̓��_�C���N�g��񋟂��Ȃ��̂ŁA���_�C���N�g���g���ꍇ�͂����Ɏ�������B
 *
 * @author n-machida
 */
public class Redirector extends HttpServlet {

    private static final String STRING_AND = "&";
    private static final String EQUAL = "=";
    private static final String QUESTION_MARK = "?";
    private static final int LENGTH_OF_CODE = 40;
    private static final int LENGTH_OF_ACCESS_TOKEN = 40;

    /**
     * URL��server�����擾
     */
    private static final String SERVER_URL = PropertyUtility.getProperty(BUSINESS_CODE + "server_url");
    /**
     * ���O�A�E�g��̑J�ڐ�URL�擾
     */
    private static final String LOGOUT_URL = PropertyUtility.getProperty(BUSINESS_CODE + "logout_url");

    Log log = LogFactory.getLog(this.getClass());

    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        log.info("*** RequestURL=" + request.getRequestURL());

        //Load the properties file
        Properties config = OAuthUtils.getClientConfigProps(OAuthConstants.CONFIG_FILE_PATH);
        OAuth2Details oauthDetails = OAuthUtils.createOAuthDetails(config);
        log.debug("oauthDetails.getTokenEndpointUrl=" + oauthDetails.getTokenEndpointUrl()); // check load

        if ("/mgr/init.cgi".equalsIgnoreCase(request.getRequestURI())) {
            processInit(request, response, oauthDetails);

        } else if ("/mgr/authorized.cgi".equalsIgnoreCase(request.getRequestURI())) {
            processAuthorized(request, response, oauthDetails);

        } else if ("/mgr/gat.cgi".equalsIgnoreCase(request.getRequestURI())) {
            processGetAccessToken(request, oauthDetails, response);

        } else if ("/mgr/logout.cgi".equalsIgnoreCase(request.getRequestURI())) {
            processLogout(request, response);

        } else {
            log.error("�s����URI���w�肳��܂����B");
            // do nothing
        }

    }

    private void processInit(HttpServletRequest request, HttpServletResponse response, OAuth2Details oauthDetails) throws IOException {
        log.info("/mgr/init.cgi ����Ǘ��V�X�e����auhorize�Ƀ��_�C���N�g�����܂��B");

        // session �J�n
        HttpSession session = request.getSession();
        String sessionId = session.getId();
        Cookie cookie = new Cookie("JSESSIONID", sessionId);
        response.addCookie(cookie);

        response.sendRedirect(oauthDetails.getAuthenticationServerUrl() + QUESTION_MARK
                + OAuthConstants.RESPONSE_TYPE + EQUAL + oauthDetails.getResponseType() + STRING_AND
                + OAuthConstants.CLIENT_ID + EQUAL + oauthDetails.getClientId() + STRING_AND
                + OAuthConstants.REDIRECT_URI + EQUAL + oauthDetails.getRedirectURI() + STRING_AND
                + OAuthConstants.SCOPE + EQUAL + oauthDetails.getScope() + STRING_AND
                + OAuthConstants.STATE + EQUAL + sessionId
        );
    }

    private void processAuthorized(HttpServletRequest request, HttpServletResponse response, OAuth2Details oauthDetails) throws IOException {
        log.info("/authorized.cgi gat.cgi�Ƀ��_�C���N�g�����܂��B");

        // �F����G���h�|�C���g����擾�����F�R�[�h
        String code = request.getParameter(OAuthConstants.CODE);

        // �F�R�[�h�̃Z�L�����e�B�`�F�b�N
        if (isValidCode(code)) {
            // �Z�L�����e�B�`�F�b�NOK
            log.info("�F����G���h�|�C���g����擾�����F�R�[�h=" + code);

            // ���_�C���N�g���ꂽstate�̒l�̓Z�b�V����ID�Ƃ��ăN�b�L�[�ɍăZ�b�g���āA
            Cookie cookie = new Cookie("JSESSIONID", request.getParameter("state"));
            response.addCookie(cookie);

            // gat.cgi(get access token)�փ��_�C���N�g
            response.sendRedirect(oauthDetails.getTokenClientUrl() + QUESTION_MARK
                    + OAuthConstants.CODE + EQUAL + code
            );

        } else {
            // �Z�L�����e�B�`�F�b�N�G���[
            handleSecurityErrorAboutCode(response);
        }
    }

    private void processGetAccessToken(HttpServletRequest request, OAuth2Details oauthDetails, HttpServletResponse response) throws IOException {
        String code = request.getParameter(OAuthConstants.CODE);
        // �F�R�[�h�̃Z�L�����e�B�`�F�b�N
        if (isValidCode(code)) {

            log.info("/gat.cgi ����Ǘ��V�X�e����get-access-token���Ăяo���܂��B");
            Map<String, String> map = OAuthUtils.getAccessToken(oauthDetails, code);
            // �G���[���X�|���X�ł͂Ȃ����`�F�b�N
            if (!map.containsKey("error_code")) {

                String accessToken = map.get(OAuthConstants.ACCESS_TOKEN);
                // �A�N�Z�X�g�[�N���L�[�̃Z�L�����e�B�`�F�b�N
                if (isValidAccessToken(accessToken)) {
                    oauthDetails.setAccessToken(accessToken);

                    // ����Ǘ��ʐM���O�֕ۑ�-OUT
                    writeGetMemberDataOutLog(oauthDetails);

                    log.info("����Ǘ��V�X�e���̉�����擾�v�����Ăяo���܂��B");
                    Map<String, String> memberDataMap = OAuthUtils.getMemberData(oauthDetails);
                    // �G���[���X�|���X�ł͂Ȃ����`�F�b�N
                    if (!memberDataMap.containsKey("error_code")) {

                        // ������̃Z�L�����e�B�`�F�b�N
                        if (isValidMemberData(memberDataMap)) {
                            // �Z�L�����e�B�`�F�b�NOK
                            // ����Ǘ��ʐM���O�֕ۑ�-IN
                            writeGetMemberDataInLog(oauthDetails, memberDataMap);

                            // OAuth�ȊO�̋Ɩ�����
                            String BPResult = new KaiinKanriSystemCooperateService().doService(memberDataMap, request);

                            if (ApplicationService.FWD_NM_SUCCESS.equals(BPResult)) {
                                // MgrTop.cgi�փ��_�C���N�g
                                log.info("MgrTop.cgi�փ��_�C���N�g���܂��B");
                                response.sendRedirect(SERVER_URL + "MgrTop.cgi");

                            } else if (ApplicationService.FWD_NM_ERROR.equals(BPResult)) {
                                response.sendRedirect(SERVER_URL + "html/SysErr.html"); // @TODO ������G���[��ʂɂ�������

                            } else if (ApplicationService.FWD_NM_EXCEPTION.equals(BPResult)) {
                                response.sendRedirect(SERVER_URL + "html/SysErr.html");

                            } else {
                                log.fatal("�Ɩ������̎��s����" + BPResult + "�ɑ΂����ʑJ�ڂ͒�`����Ă��܂���B");
                                response.sendRedirect(SERVER_URL + "html/SysErr.html");
                            }

                        } else {
                            // ������̃Z�L�����e�B�`�F�b�N�G���[
                            handleSecurityErrorAboutMemberData(response);
                        }
                    } else {
                        handleMBError("����Ǘ��V�X�e���̉�����擾����G���[���Ԃ�܂����B", memberDataMap, response);
                    }
                } else {
                    // �A�N�Z�X�g�[�N���L�[�̃Z�L�����e�B�`�F�b�N�G���[
                    handleSecurityErrorAboutAccessToken(response);
                }
            } else {
                handleMBError("����Ǘ��V�X�e����get-access-token����G���[���Ԃ�܂����B", map, response);
            }
        } else {
            // �F�R�[�h�̃Z�L�����e�B�`�F�b�N�G���[
            handleSecurityErrorAboutCode(response);
        }
    }

    private void processLogout(HttpServletRequest request, HttpServletResponse response) throws IOException {
        log.info("/logout.cgi �Z�b�V������j�����ă��O�A�E�g���܂��B");
        HttpSession session = request.getSession(false);
        if (session != null) {
            session.invalidate();
        }
        response.sendRedirect(LOGOUT_URL);
    }

    private boolean isValidCode(String code) {
        boolean result = false;
        if (code == null) {
            result = false;
            log.error("�F�R�[�h��null�ł�");
        } else {
            if (code.length() == LENGTH_OF_CODE) {
                if (CheckUtility.isAlphabetOrNumber(code)) {
                    result = true;
                    log.debug("�F�R�[�hOK");
                } else {
                    result = false;
                    log.error("�F�R�[�h�ɉp�����ȊO���܂܂�Ă��܂��Bcode=" + code);
                }
            } else {
                result = false;
                log.error("�F�R�[�h�̒������Ⴂ�܂��Bcode=" + code);
            }
        }

        return result;
    }

    private boolean isValidAccessToken(String accessToken) {
        boolean result = false;
        if (accessToken == null) {
            result = false;
            log.error("�A�N�Z�X�g�[�N����null�ł�");
        } else {
            if (accessToken.length() == LENGTH_OF_ACCESS_TOKEN) {
                if (CheckUtility.isAlphabetOrNumber(accessToken)) {
                    result = true;
                    log.debug("�A�N�Z�X�g�[�N��OK");
                } else {
                    result = false;
                    log.error("�A�N�Z�X�g�[�N���ɉp�����ȊO���܂܂�Ă��܂��BaccessToken=" + accessToken);
                }
            } else {
                result = false;
                log.error("�A�N�Z�X�g�[�N���̒������Ⴂ�܂��BaccessToken=" + accessToken);
            }
        }

        return result;
    }

    private boolean isValidMemberData(Map<String, String> memberDataMap) {
        // ������̃Z�L�����e�B�`�F�b�N
        boolean result = true;
        StringBuilder errorLogMessage = new StringBuilder();

        // null�̒l��""�ɒu�������Anull�͌ʂɂ��`�F�b�N���Ȃ����Ƃɂ���
        for (java.util.Map.Entry<java.lang.String, java.lang.String> entry : memberDataMap.entrySet()) {
            if (entry.getValue() == null) {
                entry.setValue("");
            }
        }

        // member_id 
        if (!CheckUtility.isNumber(String.valueOf(memberDataMap.get("member_id")))) {
            result = false;
            errorLogMessage.append("member_id,");
        }

        // member_name
        if (CheckUtility.isWrongChar(memberDataMap.get("member_name"))) {
            result = false;
            errorLogMessage.append("member_name,");
        }

        //member_kana
        if (CheckUtility.isWrongChar(memberDataMap.get("member_kana"))) {
            result = false;
            errorLogMessage.append("member_kana,");
        }

        //birth_date
        if (!DateTimeUtility.isCorrectDateyyyyMMdd(String.valueOf(memberDataMap.get("birth_date")))) {
            result = false;
            errorLogMessage.append("birth_date,");
        }

        //country
        if (CheckUtility.isWrongChar(memberDataMap.get("country"))) {
            result = false;
            errorLogMessage.append("country,");
        }

        //zip_code
        if (!CheckUtility.isNumber(String.valueOf(memberDataMap.get("zip_code")))) {
            result = false;
            errorLogMessage.append("zip_code,");
        }

        //address
        if (CheckUtility.isWrongChar(memberDataMap.get("address"))) {
            result = false;
            errorLogMessage.append("address,");
        }

        //tel
        if (!CheckUtility.isNumber(String.valueOf(memberDataMap.get("tel")))) {
            result = false;
            errorLogMessage.append("tel,");
        }

        //fax
        if (!CheckUtility.isNumber(String.valueOf(memberDataMap.get("fax")))) {
            result = false;
            errorLogMessage.append("fax,");
        }

        //email
        if (!CheckUtility.isHankaku(memberDataMap.get("email"))) {
            result = false;
            errorLogMessage.append("email,");
        }

        //agreement_datetime
        if (!CheckUtility.isHankaku(memberDataMap.get("agreement_datetime"))) {
            result = false;
            errorLogMessage.append("agreement_datetime,");
        }

        //company_code
        if (!CheckUtility.isBlank(memberDataMap.get("company_code"))) {
            if (!CheckUtility.isAlphabetOrNumber(memberDataMap.get("company_code"))) {
                result = false;
                errorLogMessage.append("company_code,");
            }
        }

        //company_name
        if (!CheckUtility.isBlank(memberDataMap.get("company_name"))) {
            if (CheckUtility.isWrongChar(memberDataMap.get("company_name"))) {
                result = false;
                errorLogMessage.append("company_name,");
            }
        }

        //company_kana
        if (!CheckUtility.isBlank(memberDataMap.get("company_kana"))) {
            if (CheckUtility.isWrongChar(memberDataMap.get("company_kana"))) {
                result = false;
                errorLogMessage.append("company_kana,");
            }
        }

        //company_zip_code
        if (!CheckUtility.isBlank(String.valueOf(memberDataMap.get("company_zip_code")))) {
            if (!CheckUtility.isNumber(String.valueOf(memberDataMap.get("company_zip_code")))) {
                result = false;
                errorLogMessage.append("company_zip_code,");
            }
        }

        //company_address
        if (!CheckUtility.isBlank(memberDataMap.get("company_address"))) {
            if (CheckUtility.isWrongChar(memberDataMap.get("company_address"))) {
                result = false;
                errorLogMessage.append("company_address,");
            }
        }

        //company_tel
        if (!CheckUtility.isBlank(String.valueOf(memberDataMap.get("company_tel")))) {
            if (!CheckUtility.isNumber(String.valueOf(memberDataMap.get("company_tel")))) {
                result = false;
                errorLogMessage.append("company_tel,");
            }
        }

        //company_fax
        if (!CheckUtility.isBlank(String.valueOf(memberDataMap.get("company_fax")))) {
            if (!CheckUtility.isNumber(String.valueOf(memberDataMap.get("company_fax")))) {
                result = false;
                errorLogMessage.append("company_fax,");
            }
        }

        //company_member_kbn
        if (!CheckUtility.isBlank(String.valueOf(memberDataMap.get("company_member_kbn")))) {
            if (!CheckUtility.isNumber(String.valueOf(memberDataMap.get("company_member_kbn")))) {
                result = false;
                errorLogMessage.append("company_member_kbn,");
            }
        }

        //kyokai_name
        if (!CheckUtility.isBlank(memberDataMap.get("kyokai_name"))) {
            if (CheckUtility.isWrongChar(memberDataMap.get("kyokai_name"))) {
                result = false;
                errorLogMessage.append("kyokai_name,");
            }
        }

        //authority
        if (!CheckUtility.isBlank(String.valueOf(memberDataMap.get("authority")))) {
            if (!CheckUtility.isNumber(String.valueOf(memberDataMap.get("authority")))) {
                result = false;
                errorLogMessage.append("authority,");
            }
        }

        //corp_kbn
        if (!CheckUtility.isBlank(String.valueOf(memberDataMap.get("corp_kbn")))) {
            if (!CheckUtility.isNumber(String.valueOf(memberDataMap.get("corp_kbn")))) {
                result = false;
                errorLogMessage.append("corp_kbn,");
            }
        }

        //migration_flg
        if (!CheckUtility.isBlank(String.valueOf(memberDataMap.get("migration_flg")))) {
            if (!CheckUtility.isNumber(String.valueOf(memberDataMap.get("migration_flg")))) {
                result = false;
                errorLogMessage.append("migration_flg,");
            }
        }

        //member_entry_kbn
        if (!CheckUtility.isBlank(String.valueOf(memberDataMap.get("member_entry_kbn")))) {
            if (!CheckUtility.isNumber(String.valueOf(memberDataMap.get("member_entry_kbn")))) {
                result = false;
                errorLogMessage.append("member_entry_kbn,");
            }
        }

        if (result) {
            log.info("������Z�L�����e�B�`�F�b�N OK");
        } else {
            log.error("������Z�L�����e�B�`�F�b�N�G���[[" + errorLogMessage + "]");
        }

        return result;
    }

    private void handleMBError(String messageHeader, Map<String, String> map, HttpServletResponse response) throws IOException {
        log.error(messageHeader
                + " error_code=" + map.get("error_code")
                + ", error_description=" + map.get("error_description")
                + ", error_message=" + map.get("error_message"));
        response.sendRedirect(SERVER_URL + "html/SysErr.html");
    }

    private void handleSecurityErrorAboutCode(HttpServletResponse response) throws IOException {
        log.error("�s���ȔF�R�[�h���󂯎��������" + SERVER_URL + "�փ��_�C���N�g���܂�");
        response.sendRedirect(SERVER_URL + "html/SecErr.html");
    }

    private void handleSecurityErrorAboutAccessToken(HttpServletResponse response) throws IOException {
        log.error("�s���ȃA�N�Z�X�g�[�N���L�[���󂯎��������" + SERVER_URL + "�փ��_�C���N�g���܂�");
        response.sendRedirect(SERVER_URL + "html/SecErr.html");
    }

    private void handleSecurityErrorAboutMemberData(HttpServletResponse response) throws IOException {
        log.error("�s���ȉ�������󂯎��������" + SERVER_URL + "�փ��_�C���N�g���܂�");
        response.sendRedirect(SERVER_URL + "html/SecErr.html");
    }

    private void writeGetMemberDataOutLog(OAuth2Details oauthDetails) {
        try {
            KaiinKanriTsushinLog dbLog = new KaiinKanriTsushinLog(BmaConstants.DS_REGISTRANT);
            dbLog.setTsushinTimestamp(DateTimeUtility.formatToStringyyyyMMddHHmmssSSSFromMilliSeconds(
                    DateTimeUtility.getSystemDateTimeMills()));
            dbLog.setTsushinShubetsu(oauthDetails.getResourceServerUrl());
            dbLog.setTsushinHoukou("OUT");
            dbLog.setMessageId(oauthDetails.getAccessToken());
            dbLog.setMessageKensakuKeyword("unknown");
            dbLog.setMessage(OAuthConstants.AUTHORIZATION + ": "
                    + getAuthorizationHeaderForAccessToken(oauthDetails.getAccessToken()));
            dbLog.create();
        } catch (Exception ex) {
            log.warn("����Ǘ��ʐM���O�ւ̕ۑ��ŗ�O���������܂����BGetMemberData-OUT", ex);
        } // ���O�ۑ��Ɏ��s���Ă������͑��s
    }

    private void writeGetMemberDataInLog(OAuth2Details oauthDetails, Map<String, String> memberDataMap) {
        try {
            KaiinKanriTsushinLog dbLog = new KaiinKanriTsushinLog(BmaConstants.DS_REGISTRANT);
            dbLog.setTsushinTimestamp(DateTimeUtility.formatToStringyyyyMMddHHmmssSSSFromMilliSeconds(
                    DateTimeUtility.getSystemDateTimeMills()));
            dbLog.setTsushinShubetsu(oauthDetails.getResourceServerUrl());
            dbLog.setTsushinHoukou("IN");
            dbLog.setMessageId(oauthDetails.getAccessToken());
            dbLog.setMessageKensakuKeyword(String.valueOf(memberDataMap.get("member_id")));
            dbLog.setMessage(memberDataMap.toString());
            dbLog.create();
        } catch (Exception ex) {
            log.warn("����Ǘ��ʐM���O�ւ̕ۑ��ŗ�O���������܂����BGetMemberData-IN", ex);
        } // ���O�ۑ��Ɏ��s���Ă������͑��s
    }

}
