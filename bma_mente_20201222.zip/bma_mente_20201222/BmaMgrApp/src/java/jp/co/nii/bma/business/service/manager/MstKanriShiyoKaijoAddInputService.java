package jp.co.nii.bma.business.service.manager;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;
import jp.co.nii.bma.business.domain.KaijoMst;
import jp.co.nii.bma.business.domain.KaijoTantoMst;
import jp.co.nii.bma.business.domain.Schedule;
import jp.co.nii.bma.business.domain.ShiyoKaijo;
import jp.co.nii.bma.business.rto.manager.MstKanriShiyoKaijoJoho;
import jp.co.nii.bma.business.service.common.BmaConstants;
import jp.co.nii.bma.business.service.common.BmaLogger;
import jp.co.nii.bma.business.service.common.BmaValidator;
import static jp.co.nii.bma.business.service.manager.MstKanriShiyoKaijoSerchService.dateToWeek;
import jp.co.nii.bma.presentation.common.BmaText;
import jp.co.nii.bma.utility.BmaUtility;
import jp.co.nii.sew.business.service.AbstractService;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_BACK;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_EXCEPTION;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_RELOAD;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_SESSION;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_SUCCESS;
import jp.co.nii.sew.presentation.Messages;
import jp.co.nii.sew.presentation.Option;
import jp.co.nii.sew.presentation.RequestTransferObject;
import jp.co.nii.sew.utility.PropertyUtility;

/**
 *
 * @author nii19049
 */
public class MstKanriShiyoKaijoAddInputService extends AbstractService {

    /**
     * DB�ڑ��̃f�[�^�\�[�X
     */
    private static String DATA_SOURCE_NAME;
    /**
     * ���O
     */
    BmaLogger log = (BmaLogger) BmaLogger.getLogger(this.getClass().getName());
    /**
     * �Ɩ��R�[�h
     */
    private static final String BUSINESS_CODE = PropertyUtility.getProperty("business_code");
    /**
     * ���׃e�X�g���[�h
     */
    private static final String STRESS_MODE = PropertyUtility.getProperty(BUSINESS_CODE + "stress_mode");

    /**
     * �R���X�g���N�^
     */
    public MstKanriShiyoKaijoAddInputService() {
        super();
        /* DB�ڑ����̃��[�U�[������ */
        DATA_SOURCE_NAME = BmaConstants.DS_REGISTRANT;
    }

    /**
     * �T�[�r�X�N���X�̎��s���\�b�h
     *
     * @param rto ���N�G�X�g��񂩂�擾����rto
     * @param rtoInSession �Z�b�V�������rto
     * @return foward��
     * @throws Exception ��O
     */
    @Override
    public String doService(RequestTransferObject rto, RequestTransferObject rtoInSession)
            throws Exception {

        MstKanriShiyoKaijoJoho inRequest = (MstKanriShiyoKaijoJoho) rto;
        MstKanriShiyoKaijoJoho inSession = (MstKanriShiyoKaijoJoho) rtoInSession;
        String processName = "";

        /*�G���[���b�Z�[�W������*/
        inSession.setErrors(new Messages());
        try {
            if (!BmaUtility.isNullOrEmpty(inRequest.getShiyoKaijoAddInp())) {
                /*�u�g�p���ǉ����͉�ʁv�J�ڎ�*/
                processName = "MstKanriShiyoKaijoAddInput";
                log.Start(processName);

                /* �u�g�p���ǉ����́v��ʕ\�� */
                return FWD_NM_SUCCESS;

            } else if (!BmaUtility.isNullOrEmpty(inRequest.getShiyoKaijoAddConf())) {
                /*�u�m�F�v�{�^��������*/
                processName = "MstKanriShiyoKaijoAddInput";
                log.Start(processName);

                /* �ϐ������� */
                ShiyoKaijo sKaijo = new ShiyoKaijo(DATA_SOURCE_NAME);
                KaijoTantoMst tanto = new KaijoTantoMst(DATA_SOURCE_NAME);
                String nendo = "";
                String sknKsuCode = "";
                String shubetsuCode = "";
                String kaisuCode = "";

                nendo = inSession.getNendo();
                sknKsuCode = inSession.getSknKsuCode();
                shubetsuCode = inSession.getShubetsuCode();
                kaisuCode = inSession.getKaisuCode();

                inSession.setShiyoKaijoInputList(inRequest.getShiyoKaijoInputList());
                inSession.setKaijoList(inSession.getShiyoKaijoInputList());

                // �g�p�������1�����I�����Ă��Ȃ��ꍇ�G���[
                Boolean checkUseKaijo = false;
                Boolean checkInput = false;
                for (MstKanriShiyoKaijoJoho shiyokaijo : inSession.getShiyoKaijoInputList()) {
                    if ("1".equals(shiyokaijo.getSelectedKaijo())) {
                        checkUseKaijo = true;
                        break;
                    }
                }
                if (!checkUseKaijo) {
                    Messages errors = new Messages();
                    BmaValidator.addMessage(errors, "shiyoKaijoData", BmaText.E00133);
                    inSession.setErrors(errors);
                } else {
                    // ���͒l�`�F�b�N
                    checkInput = validateInput(inSession.getShiyoKaijoInputList(), inSession);
                }

                if (!checkInput || !checkUseKaijo) {
                    // �G���[���������ꍇ�u�g�p���ǉ��v���Reload
                    for (int l = 0; l < inSession.getKaijoList().size(); l++) {
                        List<Option> tantoshaList = new ArrayList<Option>();
                        MstKanriShiyoKaijoJoho shiyoKaijo = inSession.getKaijoList().get(l);

                        shiyoKaijo.setFromYear(shiyoKaijo.getFromYear().replaceFirst("^0+", ""));
                        shiyoKaijo.setFromMonth(shiyoKaijo.getFromMonth().replaceFirst("^0+", ""));
                        shiyoKaijo.setFromDate(shiyoKaijo.getFromDate().replaceFirst("^0+", ""));
                        shiyoKaijo.setToYear(shiyoKaijo.getToYear().replaceFirst("^0+", ""));
                        shiyoKaijo.setToMonth(shiyoKaijo.getToMonth().replaceFirst("^0+", ""));
                        shiyoKaijo.setToDate(shiyoKaijo.getToDate().replaceFirst("^0+", ""));

                        String kaisaichi = shiyoKaijo.getKaisaichiCode();
                        String kaijo = shiyoKaijo.getKaijoCode();
                        tanto.findByOneTantosha(kaisaichi, kaijo, tantoshaList);

                        shiyoKaijo.setKaisaichiCode(kaisaichi);
                        shiyoKaijo.setKaijoCode(kaijo);
                        shiyoKaijo.setTantoshaList(tantoshaList);
                        shiyoKaijo.setTantosha("");
                        shiyoKaijo.setShiyoKaijoAddHukusei(kaisaichi + kaijo);
                        inSession.getKaijoList().set(l, shiyoKaijo);

                    }
                    return FWD_NM_SUCCESS;
                }

                //�\���p�̃��X�g
                List<MstKanriShiyoKaijoJoho> shiyoKaijoUpdateList = new LinkedList<MstKanriShiyoKaijoJoho>();
                List<MstKanriShiyoKaijoJoho> shiyoKaijoSearchList = sKaijo.searchShiyoKaijoList(nendo, sknKsuCode, shubetsuCode, kaisuCode);
                List<MstKanriShiyoKaijoJoho> shiyoKaijoInputList =  new LinkedList<MstKanriShiyoKaijoJoho>();

                for (int k = 0; k < shiyoKaijoSearchList.size(); k++) {
                    MstKanriShiyoKaijoJoho searchResult = shiyoKaijoSearchList.get(k);
                    createShiyoKaijoDetail(searchResult, inSession.getKaisaichiCodeList());
                    shiyoKaijoSearchList.set(k, searchResult);
                }

                //���ID�̂ݐ�Ɍv�Z
                
                // ���ID�擾SQL���s����ԑ傫�����ID��intKaijoId�ɑ��
                int intKaijoId = shiyoKaijoSearchList.size();
                
                String strKaijoId;
                for (MstKanriShiyoKaijoJoho inputShiyoKaijo : inSession.getShiyoKaijoInputList()) {
                    if ("1".equals(inputShiyoKaijo.getSelectedKaijo())) {
                        intKaijoId = intKaijoId + 1;
                        strKaijoId = String.valueOf(intKaijoId);
                        if (strKaijoId.length() < 2) {
                            strKaijoId = String.format("%2s", strKaijoId).replace(' ', '0');
                        }
                        inputShiyoKaijo.setKaijoId(strKaijoId);
                        shiyoKaijoInputList.add(inputShiyoKaijo);
                    }
                }

                int i = 0;
                int j = 0;
                if (shiyoKaijoSearchList != null && shiyoKaijoInputList != null) {
                    MstKanriShiyoKaijoJoho inputKaijo = shiyoKaijoInputList.get(0);
                    MstKanriShiyoKaijoJoho searchKaijo = shiyoKaijoSearchList.get(0);
                    int inputKaisaichiInt = Integer.parseInt(inputKaijo.getKaisaichiCode());
                    int searchKaisaichiInt = Integer.parseInt(searchKaijo.getKaisaichiCode());
                    for (int k = 0; k < shiyoKaijoInputList.size() + shiyoKaijoSearchList.size(); ++k) {

                        if (searchKaisaichiInt <= inputKaisaichiInt) {
                            shiyoKaijoUpdateList.add(searchKaijo);
                            ++j;
                            if (j == shiyoKaijoSearchList.size()) {
                                searchKaijo = new MstKanriShiyoKaijoJoho();
                                searchKaisaichiInt = 100;
                            } else {
                                searchKaijo = shiyoKaijoSearchList.get(j);
                                searchKaisaichiInt = Integer.parseInt(searchKaijo.getKaisaichiCode());
                            }
                        } else {
                            shiyoKaijoUpdateList.add(inputKaijo);
                            ++i;
                            if (i == shiyoKaijoInputList.size()) {
                                inputKaijo = new MstKanriShiyoKaijoJoho();
                                inputKaisaichiInt = 100;
                            } else {
                                inputKaijo = shiyoKaijoInputList.get(i);
                                inputKaisaichiInt = Integer.parseInt(inputKaijo.getKaisaichiCode());
                            }
                        }
                    }
                }
                inSession.setShiyoKaijoUpdateList(shiyoKaijoUpdateList);

                for (int k = 0; k < inSession.getShiyoKaijoUpdateList().size(); k++) {
                    MstKanriShiyoKaijoJoho shiyoKaijo = inSession.getShiyoKaijoUpdateList().get(k);
//                    if ("1".equals(shiyoKaijo.getSelectedKaijo())) {

                        MstKanriShiyoKaijoJoho shiyoKaijoUpdName = createShiyoKaijoAdd(shiyoKaijo);
                        shiyoKaijo.setKaijoShikenName(shiyoKaijoUpdName.getKaijoShikenName());
                        //�j��
                        shiyoKaijo.setNitteiFrom(shiyoKaijo.getFromYear() + shiyoKaijo.getFromMonth() + shiyoKaijo.getFromDate());
                        shiyoKaijo.setNitteiTo(shiyoKaijo.getToYear() + shiyoKaijo.getToMonth() + shiyoKaijo.getToDate());

                        shiyoKaijo.setFromYobi(dateToWeek(shiyoKaijo.getNitteiFrom()));

                        if (!BmaUtility.isNullOrEmpty(shiyoKaijo.getNitteiTo())) {
                            shiyoKaijo.setToYobi(dateToWeek(shiyoKaijo.getNitteiTo()));
                        }

                        //���
                        shiyoKaijo.setTeiin(String.format(shiyoKaijo.getTeiin()).replaceFirst("^0+", ""));

                        //��ꖼ
                        String kaisaichiCode = "";
                        if ("10".equals(shiyoKaijo.getKaisaichiCode())) {
                            kaisaichiCode = shiyoKaijo.getKaisaichiCodeKaijoMst();
                        } else {
                            kaisaichiCode = shiyoKaijo.getKaisaichiCode();
                        }
                        String kaijoCode = shiyoKaijo.getKaijoCode();
                        
                        //�S����
                        String tantoshaCode = shiyoKaijo.getTantoshaCode();
                        String shiyoKaijoTantosha = tanto.searchTantoshaName(kaisaichiCode, kaijoCode, tantoshaCode);

                        shiyoKaijo.setTantosha(shiyoKaijoTantosha);
                        
                        inSession.getShiyoKaijoUpdateList().set(k, shiyoKaijo);
                    }
//                inSession.setKaijoList(inSession.getShiyoKaijoInputList());

                /* �u�g�p���V�K�o�^�m�F�v��ʕ\�� */
                return FWD_NM_NEXT;

            } else if (!BmaUtility.isNullOrEmpty(inRequest.getShiyoKaijoAddHukusei())) {
                /*�u�����v�{�^��������*/
                processName = "MstKanriShiyoKaijoAddInput";
                log.Start(processName);

                /*���͒l���Z�b�V�����ɕۑ�*/
                List<MstKanriShiyoKaijoJoho> kaijoList = inRequest.getShiyoKaijoInputList();
                inSession.setKaijoList(kaijoList);

                // DB�ɓo�^���ꂽ������̐����擾
                ShiyoKaijo sKaijo = new ShiyoKaijo(DATA_SOURCE_NAME);
                ShiyoKaijo shiyoKaijoForDbCount = new ShiyoKaijo();
                shiyoKaijoForDbCount.setNendo(inSession.getNendo());
                shiyoKaijoForDbCount.setSknKsuCode(inSession.getSknKsuCode());
                shiyoKaijoForDbCount.setShubetsuCode(inSession.getShubetsuCode());
                shiyoKaijoForDbCount.setKaisuCode(inSession.getKaisuCode());
                shiyoKaijoForDbCount.setKaisaichiCode(inRequest.getShiyoKaijoAddHukusei().substring(0, 2));
                shiyoKaijoForDbCount.setKaijoCode(inRequest.getShiyoKaijoAddHukusei().substring(2, 5));
                String dbCount = sKaijo.countShiyoKaijoForHukusei(shiyoKaijoForDbCount);

                //����񂪍ő�s�����̏ꍇ�A�������P���ǉ�����.
                int[] listNo = hukuseiSet(inSession.getKaijoList(), inRequest);
                if (listNo[0] + Integer.parseInt(dbCount) < BmaConstants.MAX_KAIJO_COUNT) {
                    MstKanriShiyoKaijoJoho shiyoKaijo = new MstKanriShiyoKaijoJoho();
                    createHukuseiData(shiyoKaijo, kaijoList.get(listNo[1]));
                    kaijoList.add(listNo[1] + 1, shiyoKaijo);
                } else {
                    // �����ꂪ5���ȏ�̏ꍇ�u�g�p���ǉ����́v���Reload */
                    Messages errors = new Messages();
                    BmaValidator.addMessage(errors, "shiyoKaijoData", BmaText.E00131);
                    inSession.setErrors(errors);
                }

                KaijoTantoMst tanto = new KaijoTantoMst(DATA_SOURCE_NAME);
                for (int i = 0; i < kaijoList.size(); ++i) {
                    List<Option> tantoshaList = new ArrayList<Option>();
                    MstKanriShiyoKaijoJoho shiyoKaijo = kaijoList.get(i);

                    String kaisaichi = shiyoKaijo.getKaisaichiCode();
                    String kaijo = shiyoKaijo.getKaijoCode();
                    tanto.findByOneTantosha(kaisaichi, kaijo, tantoshaList);

                    shiyoKaijo.setTantoshaList(tantoshaList);

                    shiyoKaijo.setShiyoKaijoAddHukusei(kaisaichi + kaijo);
                    kaijoList.set(i, shiyoKaijo);
                }

                inSession.setKaijoList(kaijoList);

                /* �u�g�p���ǉ��o�^���́v��ʕ\�� */
                return FWD_NM_RELOAD;

            } else if (!BmaUtility.isNullOrEmpty(inRequest.getBack())) {
                /*�u�߂�v�{�^��������*/
                processName = "MstKanriShiyoKaijoAddInput";
                log.Start(processName);

                /* �u�g�p���ǉ��v��ʕ\�� */
                return FWD_NM_BACK;

            } else {
                /*�ُ�J��*/
                log.IllegalFWD();
                return FWD_NM_SESSION;
            }
        } catch (Exception e) {
            return FWD_NM_EXCEPTION;
        } finally {
            log.End(processName);
        }
    }

    private MstKanriShiyoKaijoJoho createShiyoKaijoAdd(MstKanriShiyoKaijoJoho shiyoKaijo) {

        String kaijoShikenName = "";

        MstKanriShiyoKaijoJoho shiyoKaijoAdd = new MstKanriShiyoKaijoJoho();

        /* ��ꎎ���敪���̂��Z�b�g */
        if (BmaConstants.KAIJO_SHIKEN_KBN_NASHI.equals(shiyoKaijo.getKaijoShikenKbn())) {
            kaijoShikenName = "�敪���g�p���Ȃ�";
        } else if (BmaConstants.KAIJO_SHIKEN_KBN_GAKKA.equals(shiyoKaijo.getKaijoShikenKbn())) {
            kaijoShikenName = "�w�Ȏ����y�ю��Z�y�[�p�[�e�X�g";
        } else if (BmaConstants.KAIJO_SHIKEN_KBN_ZITSUGI.equals(shiyoKaijo.getKaijoShikenKbn())) {
            kaijoShikenName = "���Z��Ǝ���";
        }
        shiyoKaijoAdd.setKaijoShikenName(kaijoShikenName);

        return shiyoKaijoAdd;
    }

    /**
     * �����𐮌`����
     *
     * @param inRequest�@���N�G�X�g���
     * @param inSession�@�Z�b�V�������
     */
    public static void createNittei(MstKanriShiyoKaijoJoho inRequest, MstKanriShiyoKaijoJoho inSession) {
        /* �ϐ������� */
        String nitteiFrom = "";
        String nitteiTo = "";

        // ����From �N
        if (!BmaUtility.isNullOrEmpty(inRequest.getFromYear())) {
            // �����̓��͂�����Γ��t�p�ɘA��
            inSession.setFromYear(String.format("%4s", inRequest.getFromYear()).replace(' ', '0'));
            nitteiFrom = inSession.getFromYear();
        } else {
            // ���͂��Ȃ���΃G���[
            inSession.setFromYear(inRequest.getFromYear());
        }
        // ����From ��
        if (!BmaUtility.isNullOrEmpty(inRequest.getFromMonth())) {
            inSession.setFromMonth(String.format("%2s", inRequest.getFromMonth()).replace(' ', '0'));
            nitteiFrom += inSession.getFromMonth();
        } else {
            inSession.setFromMonth(inRequest.getFromMonth());
        }
        // ����From ��
        if (!BmaUtility.isNullOrEmpty(inRequest.getFromDate())) {
            inSession.setFromDate(String.format("%2s", inRequest.getFromDate()).replace(' ', '0'));
            nitteiFrom += inSession.getFromDate();
        } else {
            inSession.setFromDate(inRequest.getFromDate());
        }
        inSession.setNitteiFrom(nitteiFrom);

        // ����To �N
        if (!BmaUtility.isNullOrEmpty(inRequest.getToYear())) {
            // �����̓��͂�����Γ��t�p�ɘA��
            inSession.setToYear(String.format("%4s", inRequest.getToYear()).replace(' ', '0'));
            nitteiTo = inSession.getToYear();
        } else {
            // ���͂��Ȃ���΃G���[
            inSession.setToYear(inRequest.getToYear());
        }
        // ����To ��
        if (!BmaUtility.isNullOrEmpty(inRequest.getToMonth())) {
            inSession.setToMonth(String.format("%2s", inRequest.getToMonth()).replace(' ', '0'));
            nitteiTo += inSession.getToMonth();
        } else {
            inSession.setToMonth(inRequest.getToMonth());
        }
        // ����To ��
        if (!BmaUtility.isNullOrEmpty(inRequest.getToDate())) {
            inSession.setToDate(String.format("%2s", inRequest.getToDate()).replace(' ', '0'));
            nitteiTo += inSession.getToDate();
        } else {
            inSession.setToDate(inRequest.getToDate());
        }
        inSession.setNitteiTo(nitteiTo);
    }

    /**
     * ���t�ɂ���ėj�����擾����
     *
     * @param datetime�@���t
     * @return �j��
     */
    public static String dateToWeek(String datetime) {

        SimpleDateFormat f = new SimpleDateFormat("yyyyMMdd");
        String[] weekDays = {"��", "��", "��", "��", "��", "��", "�y"};
        Calendar cal = Calendar.getInstance();
        Date date;
        try {
            date = f.parse(datetime);
            cal.setTime(date);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        //the day number of a week
        int w = cal.get(Calendar.DAY_OF_WEEK) - 1;
        if (w < 0) {
            w = 0;
        }
        return weekDays[w];
    }

    /**
     * ���𕡐�����
     *
     * @param
     * @return
     */
    public static int[] hukuseiSet(List<MstKanriShiyoKaijoJoho> kaijoList, MstKanriShiyoKaijoJoho inRequest) {
        int[] hukuseiset = new int[2];
        int count = 0;
        int listNo = 0;
        String kaisaichi = "";
        String kaijo = "";

        kaisaichi = inRequest.getShiyoKaijoAddHukusei().substring(0, 2);
        kaijo = inRequest.getShiyoKaijoAddHukusei().substring(2, 5);

        for (int i = 0; i < kaijoList.size(); ++i) {
            MstKanriShiyoKaijoJoho shiyoKaijo = kaijoList.get(i);
            if (kaisaichi.equals(shiyoKaijo.getKaisaichiCode())) {
                if (kaijo.equals(shiyoKaijo.getKaijoCode())) {
                    count++;
                    listNo = i;
                }
            }
        }
        hukuseiset[0] = count;
        hukuseiset[1] = listNo;

        return hukuseiset;
    }

    /**
     * �����������X�g�̓��͍��ڂ��u�����N�ɂ���
     *
     * @param shiyoKaijo
     * @param hukuseiKaijo
     */
    public static void createHukuseiData(MstKanriShiyoKaijoJoho shiyoKaijo, MstKanriShiyoKaijoJoho hukuseiKaijo) {
        shiyoKaijo.setKaisaichiCode(hukuseiKaijo.getKaisaichiCode());
        shiyoKaijo.setKaisaichiName(hukuseiKaijo.getKaisaichiName());
        shiyoKaijo.setKaijoCode(hukuseiKaijo.getKaijoCode());
        shiyoKaijo.setKaijoName(hukuseiKaijo.getKaijoName());
        shiyoKaijo.setKaijoNameRyaku(hukuseiKaijo.getKaijoNameRyaku());

        hukuseiKaijo.setNitteiFrom("");
        hukuseiKaijo.setNitteiTo("");
    }

    /**
     * �ꗗ�\���p�ɐ��`����
     *
     * @param kaijoMst ��������
     * @return �������ʕ\���p
     */
    private MstKanriShiyoKaijoJoho createShiyoKaijoDetail(MstKanriShiyoKaijoJoho shiyoKaijoDetail, List<Option> kaisaichiCodeList) {
        String teiinBfr = "";
        String teiinAft = "";
        String detailCodes = "";
        String kaijoShikenKbnName = "";
        String kaijoShikenName = "";

//        MstKanriShiyoKaijoJoho shiyoKaijoDetail = new MstKanriShiyoKaijoJoho();
        /**
         * ����̐��`
         */
        teiinBfr = shiyoKaijoDetail.getTeiin();
        teiinAft = teiinBfr.replaceFirst("^0+", "");
        if (teiinAft.isEmpty()) {
            teiinAft = "0";
        } else if (teiinAft.length() > 3) {
            teiinAft = teiinAft.substring(0, teiinAft.length() - 3)
                    + ","
                    + teiinAft.substring(teiinAft.length() - 3);
        }
        shiyoKaijoDetail.setTeiinDisp(teiinAft);

        for (Option kaisaichi : kaisaichiCodeList) {
            if (kaisaichi.getValue().equals(shiyoKaijoDetail.getKaisaichiCode())) {
                /**
                 * �J�Òn���̂��Z�b�g
                 */
                shiyoKaijoDetail.setKaisaichiName(kaisaichi.getLabel());
                break;
            }
        }

        shiyoKaijoDetail.setFromYear(shiyoKaijoDetail.getNitteiFrom().substring(0, 4));
        shiyoKaijoDetail.setFromMonth(shiyoKaijoDetail.getNitteiFrom().substring(4, 6));
        shiyoKaijoDetail.setFromDate(shiyoKaijoDetail.getNitteiFrom().substring(6, 8));
        shiyoKaijoDetail.setFromYobi(dateToWeek(shiyoKaijoDetail.getNitteiFrom()));

        shiyoKaijoDetail.setToYear(shiyoKaijoDetail.getNitteiTo().substring(0, 4));
        shiyoKaijoDetail.setToMonth(shiyoKaijoDetail.getNitteiTo().substring(4, 6));
        shiyoKaijoDetail.setToDate(shiyoKaijoDetail.getNitteiTo().substring(6, 8));
        shiyoKaijoDetail.setToYobi(dateToWeek(shiyoKaijoDetail.getNitteiTo()));

        return shiyoKaijoDetail;
    }

    /**
     * ���̓`�F�b�N
     *
     * @param inSession �Z�b�V����RTO
     * @return true:�G���[��
     */
    private boolean validateInput(List<MstKanriShiyoKaijoJoho> shiyoKaijoList, MstKanriShiyoKaijoJoho inSession) {
        /* �ϐ������� */
        Messages errors = new Messages();
        String groupCode;
        String itemName;

        KaijoTantoMst tanto = new KaijoTantoMst(DATA_SOURCE_NAME);
        // �G���[�`�F�b�N�p���X�g�쐬
        String[] sknKsuKbns = {BmaConstants.KAIJO_SHIKEN_KBN_NASHI, BmaConstants.KAIJO_SHIKEN_KBN_GAKKA, BmaConstants.KAIJO_SHIKEN_KBN_ZITSUGI};

        for (int i = 0; i < shiyoKaijoList.size(); ++i) {
            MstKanriShiyoKaijoJoho shiyoKaijo = shiyoKaijoList.get(i);
            if ("1".equals(shiyoKaijo.getSelectedKaijo())) {

                // �����쐬
                createNittei(shiyoKaijo, shiyoKaijo);

                /* ��ꎎ���敪 */
                groupCode = "kaijoShikenKbn";
                itemName = "���" + String.valueOf(i + 1) + "�̉�ꎎ���敪";
                BmaValidator.validateSelect(shiyoKaijo.getKaijoShikenKbn(), errors, groupCode, itemName);
                BmaValidator.validatePermissionSelect(shiyoKaijo.getKaijoShikenKbn(), sknKsuKbns, errors, groupCode, itemName);

                /* �S���� */
                groupCode = "tantoshaCode";
                itemName = "���" + String.valueOf(i + 1) + "�̒S����";
                List<Option> tantoshaList = new ArrayList<Option>();
                tanto.findByOneTantosha(shiyoKaijo.getKaisaichiCode(), shiyoKaijo.getKaijoCode(), tantoshaList);
                if (BmaValidator.validateSelect(shiyoKaijo.getTantoshaCode(), errors, groupCode, itemName)) {
                    BmaValidator.validatePermissionSelect(shiyoKaijo.getTantoshaCode(), tantoshaList, errors, groupCode, itemName);
                }

                /* ����From */
                groupCode = "date" + shiyoKaijo.getNitteiFrom();
                /* ���t */
                // �N
                itemName = "���" + String.valueOf(i + 1) + "����From�̔N";
                if (BmaValidator.validateRequired(shiyoKaijo.getFromYear(), errors, groupCode, itemName)) {
                    if (BmaValidator.validateNumber(shiyoKaijo.getFromYear(), errors, groupCode, itemName)) {
                        BmaValidator.validateMaxLength(shiyoKaijo.getFromYear(), BmaConstants.EQUAL_LENGTH_SCHED_DATE_YEAR, errors, groupCode, itemName);
                    }
                }
                // ��
                itemName = "���" + String.valueOf(i + 1) + "����From�̌�";
                if (BmaValidator.validateRequired(shiyoKaijo.getFromMonth(), errors, groupCode, itemName)) {
                    if (BmaValidator.validateNumber(shiyoKaijo.getFromMonth(), errors, groupCode, itemName)) {
                        BmaValidator.validateMaxLength(shiyoKaijo.getFromMonth(), BmaConstants.EQUAL_LENGTH_SCHED_DATE_MONTH, errors, groupCode, itemName);
                    }
                }
                // ��
                itemName = "���" + String.valueOf(i + 1) + "����From�̓�";
                if (BmaValidator.validateRequired(shiyoKaijo.getFromDate(), errors, groupCode, itemName)) {
                    if (BmaValidator.validateNumber(shiyoKaijo.getFromDate(), errors, groupCode, itemName)) {
                        BmaValidator.validateMaxLength(shiyoKaijo.getFromDate(), BmaConstants.EQUAL_LENGTH_SCHED_DATE_DAY, errors, groupCode, itemName);
                    }
                }
                // ���t�̐�����
                if (errors.isEmpty()) {
                    itemName = "���" + String.valueOf(i + 1) + "����From";
                    BmaValidator.validateDate2(shiyoKaijo.getNitteiFrom(), errors, groupCode, itemName);
                }

                /* ����To */
                // �N
                itemName = "���" + String.valueOf(i + 1) + "����To�̔N";
                if (BmaValidator.validateRequired(shiyoKaijo.getToYear(), errors, groupCode, itemName)) {
                    if (BmaValidator.validateNumber(shiyoKaijo.getToYear(), errors, groupCode, itemName)) {
                        BmaValidator.validateMaxLength(shiyoKaijo.getToYear(), BmaConstants.EQUAL_LENGTH_SCHED_DATE_YEAR, errors, groupCode, itemName);
                    }
                }
                // ��
                itemName = "���" + String.valueOf(i + 1) + "����To�̌�";
                if (BmaValidator.validateRequired(shiyoKaijo.getToMonth(), errors, groupCode, itemName)) {
                    if (BmaValidator.validateNumber(shiyoKaijo.getToMonth(), errors, groupCode, itemName)) {
                        BmaValidator.validateMaxLength(shiyoKaijo.getToMonth(), BmaConstants.EQUAL_LENGTH_SCHED_DATE_MONTH, errors, groupCode, itemName);
                    }
                }
                // ��
                itemName = "���" + String.valueOf(i + 1) + "����To�̓�";
                if (BmaValidator.validateRequired(shiyoKaijo.getToDate(), errors, groupCode, itemName)) {
                    if (BmaValidator.validateNumber(shiyoKaijo.getToDate(), errors, groupCode, itemName)) {
                        BmaValidator.validateMaxLength(shiyoKaijo.getToDate(), BmaConstants.EQUAL_LENGTH_SCHED_DATE_DAY, errors, groupCode, itemName);
                    }
                }
                // ���t�̐�����
                if (errors.isEmpty()) {
                    itemName = "���" + String.valueOf(i + 1) + "����To";
                    BmaValidator.validateDate2(shiyoKaijo.getNitteiTo(), errors, groupCode, itemName);
                }

                // ����_FROM�Ɠ���_TO�̑O��֌W�`�F�b�N
                if (errors.isEmpty()) {
                    itemName = "�����QFROM�Ɠ����QTO";
                    if (!checkStartEndDate(shiyoKaijo.getNitteiFrom(), shiyoKaijo.getNitteiTo())) {
                        BmaValidator.addMessage(errors, groupCode, BmaText.E00004, itemName);
                    }
                }
                
                 // �X�P�W���[���������ԓ����ǂ����`�F�b�N
                if (errors.isEmpty()) {
                    // �X�P�W���[���������Ԃ��擾
                    String schedStart = "";
                    String schedEnd = "";
                    Schedule sched = new Schedule(DATA_SOURCE_NAME);
                    schedStart = sched.find(inSession.getNendo(), inSession.getSknKsuCode(), inSession.getShubetsuCode(), inSession.getKaisuCode(), BmaConstants.SCHED_CODE_OPEN, BmaConstants.SCHEDULE_KBN_ST).getDate();
                    schedEnd = sched.find(inSession.getNendo(), inSession.getSknKsuCode(), inSession.getShubetsuCode(), inSession.getKaisuCode(), BmaConstants.SCHED_CODE_OPEN, BmaConstants.SCHEDULE_KBN_ED).getDate();

                    if (!checkDaysInTerm(shiyoKaijo.getNitteiFrom(), shiyoKaijo.getNitteiTo(), schedStart, schedEnd)) {
                        String strMsg1 = "����";
                        String strMsg2 = "�������u�K��̃X�P�W���[����������";
                        BmaValidator.addMessage(errors, groupCode, BmaText.E00129, strMsg1, strMsg2);
                    }
                }

                /* ��� */
                groupCode = "teiin";
                itemName = "���" + String.valueOf(i + 1) + "�̒��";
                if (BmaValidator.validateRequired(shiyoKaijo.getTeiin(), errors, groupCode, itemName)) {
                    if (BmaValidator.validateMaxLength(shiyoKaijo.getTeiin(), BmaConstants.MAX_LENGTH_TEIIN, errors, groupCode, itemName)) {
                        BmaValidator.validateNumber(shiyoKaijo.getTeiin(), errors, groupCode, itemName);
                    }
                }

            }
        }
        inSession.setErrors(errors);
        return errors.isEmpty();
    }

    /**
     * ����_TO������_FROM�ȍ~���ǂ����`�F�b�N
     *
     * @param startDate ����_FROM
     * @param endDate ����_TO
     * @return true:�J�n�����O�@false:�I�������O
     */
    private boolean checkStartEndDate(String startDate, String endDate) {
        /* �ϐ������� */
        SimpleDateFormat f = new SimpleDateFormat("yyyyMMdd");

        String checkStart = startDate;
        String checkEnd = endDate;

        try {
            Date dateStart = f.parse(checkStart);
            Date dateEnd = f.parse(checkEnd);
            if (dateStart.compareTo(dateEnd) != 1) {
                return true;
            } else {
                return false;
            }
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return false;
    }
    
    /**
     * �w��̊��ԓ����ǂ����`�F�b�N�i���ԁj �i����OK�j
     *
     * @param startDate �J�n��
     * @param endDate �I����
     * @param standardStartDate �w��̊��Ԃ̊J�n��
     * @param standardEndDate �w��̊��Ԃ̏I����
     * @return true:�������ԓ��@false:�������ԊO
     */
    private boolean checkDaysInTerm(String startDate, String endDate, String standardStartDate, String standardEndDate) {
        /* �ϐ������� */
        SimpleDateFormat f = new SimpleDateFormat("yyyyMMdd");

        try {
            Date dateStart = f.parse(startDate);
            Date dateEnd = f.parse(endDate);
            Date dateStandardStart = f.parse(standardStartDate);
            Date dateStandardEnd = f.parse(standardEndDate);
            if (dateStart.compareTo(dateStandardStart) != -1
                    && dateEnd.compareTo(dateStandardEnd) != 1) {
                return true;
            } else {
                return false;
            }
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return false;
    }
}
