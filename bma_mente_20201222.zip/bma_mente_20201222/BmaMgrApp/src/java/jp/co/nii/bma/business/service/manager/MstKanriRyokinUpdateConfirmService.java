package jp.co.nii.bma.business.service.manager;

import java.util.ArrayList;
import java.util.List;
import jp.co.nii.bma.business.domain.MeishoKanri;
import jp.co.nii.bma.business.domain.Ryokin;
import jp.co.nii.bma.business.rto.manager.MstKanriRyokinJoho;
import jp.co.nii.bma.business.service.common.BmaConstants;
import jp.co.nii.bma.business.service.common.BmaLogger;
import jp.co.nii.bma.business.service.common.BmaValidator;
import jp.co.nii.bma.presentation.common.BmaText;
import jp.co.nii.bma.utility.BmaUtility;
import jp.co.nii.sew.business.SystemTime;
import jp.co.nii.sew.business.service.AbstractService;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_SUCCESS;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_RELOAD;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_BACK;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_EXCEPTION;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_SESSION;
import jp.co.nii.sew.presentation.Messages;
import jp.co.nii.sew.presentation.Option;
import jp.co.nii.sew.presentation.RequestTransferObject;
import jp.co.nii.sew.utility.PropertyUtility;
import org.apache.commons.beanutils.BeanUtils;

/**
 *
 * @author nii19042
 */
public class MstKanriRyokinUpdateConfirmService extends AbstractService {

    /**
     * DB�ڑ��̃f�[�^�\�[�X
     */
    private static String DATA_SOURCE_NAME;
    /**
     * ���O
     */
    BmaLogger log = (BmaLogger) BmaLogger.getLogger(this.getClass().getName());
    /**
     * �Ɩ��R�[�h
     */
    private static final String BUSINESS_CODE = PropertyUtility.getProperty("business_code");
    /**
     * ���׃e�X�g���[�h
     */
    private static final String STRESS_MODE = PropertyUtility.getProperty(BUSINESS_CODE + "stress_mode");

    /**
     * �R���X�g���N�^
     */
    public MstKanriRyokinUpdateConfirmService() {
        super();
        /* DB�ڑ����̃��[�U�[������ */
        DATA_SOURCE_NAME = BmaConstants.DS_REGISTRANT;
    }

    /**
     * �T�[�r�X�N���X�̎��s���\�b�h
     *
     * @param rto ���N�G�X�g��񂩂�擾����rto
     * @param rtoInSession �Z�b�V�������rto
     * @return foward��
     * @throws Exception ��O
     */
    @Override
    public String doService(RequestTransferObject rto, RequestTransferObject rtoInSession)
            throws Exception {

        MstKanriRyokinJoho inRequest = (MstKanriRyokinJoho) rto;
        MstKanriRyokinJoho inSession = (MstKanriRyokinJoho) rtoInSession;
        String processName = "";

        /* �G���[���b�Z�[�W������ */
        inSession.setErrors(new Messages());

        try {
            if (!BmaUtility.isNullOrEmpty(inRequest.getRyokinUpdComp())) {
                /*�u�m��v�{�^�������� */
                processName = "MstKanriRyokinUpdateConfirm_Complete";
                log.Start(processName);

                /* ��L�[�擾 */
                Ryokin ryokinUpd = new Ryokin(DATA_SOURCE_NAME);
                String sknKsuCode = inSession.getSknKsuCode();
                String shubetsuCode = inSession.getShubetsuCode();
                String ryokinKbn = inSession.getRyokinKbn();

                /* ���͒l�`�F�b�N */
                if(!validateInput(inSession)){
                    // �G���[���������ꍇ�u�����ύX�m�F�v���Reload
                    return FWD_NM_RELOAD;
                } else {
                    try {
                        /* �g�����U�N�V�����擾&�J�n */
                        getTransaction();
                        beginTransaction();

                        // �����u�K��R�[�h�A��ʃR�[�h�A�����敪��藿���f�[�^�擾
                        Ryokin ryokinBfr  = ryokinUpd.lockNoWait(sknKsuCode, shubetsuCode, ryokinKbn);

                        if(ryokinBfr != null){
                            /* �����Ɛŗ���o�^�p�ɐ��` */
                            Ryokin arrRyokin = arrangeRyokin(inSession.getRyokinDisp(), inSession.getZeiritsuDisp());
                            /* �ύX�OBO����X�V�pBO�ɒl���R�s�[ */
                            BeanUtils.copyProperties(ryokinUpd, ryokinBfr);
                            /* �V�X�e���������擾 */
                            SystemTime sysTime = new SystemTime();

                            /* �ύX�𗿋��ɃZ�b�g */ 
                            ryokinUpd.setRyokin(arrRyokin.getRyokin());
                            ryokinUpd.setZeiKbn(inSession.getZeiKbn());
                            ryokinUpd.setZeiritsu(arrRyokin.getZeiritsu());

                            /* DB���ʍ��ڃZ�b�g */
                            ryokinUpd.setKoshinKbn(BmaConstants.SHORI_KBN_UPDATE);
                            ryokinUpd.setKoshinDate(sysTime.getymd1());
                            ryokinUpd.setKoshinTime(sysTime.gethms1());
                            ryokinUpd.setKoshinUserId(inRequest.getMoshikomishaId());

                            ryokinUpd.update();
                        } else {
                            /* Update����f�[�^���擾�ł��Ȃ������ꍇ�u�����ύX�m�F�v���Reload */
                            Messages errors = new Messages();
                            BmaValidator.addMessage(errors, "ryokinData", BmaText.E00120, "����");
                            inSession.setErrors(errors);
                            return FWD_NM_RELOAD;
                        }
                        /* �R�~�b�g */
                        commitTransaction();
                    } catch (Exception ex) {
                        ex.printStackTrace();
                        // ���[���o�b�N
                        rollbackTransaction();
                        return FWD_NM_SESSION;
                    }
                /* �u�����ύX�����v��ʕ\�� */
                return FWD_NM_SUCCESS;
                }

            } else if (!BmaUtility.isNullOrEmpty(inRequest.getRyokinUpdConfBack())) {
                /*�u�����v�{�^�������� */
                processName = "MstKanriRyokinUpdateConfirm_BackRyokinUpdInput";
                log.Start(processName);

                /* �\���p��������J���}���폜 */
                String ryokinDisp = inSession.getRyokinDisp();
                inSession.setRyokinDisp(ryokinDisp.replaceAll(",", ""));

                /* �u�����ύX���́v��ʕ\�� */
                return FWD_NM_BACK;

            } else {
                /* �ُ�J�� */
                log.IllegalFWD();
                return FWD_NM_SESSION;
            }
        } catch (Exception e) {
            return FWD_NM_EXCEPTION;
        } finally {
            log.End(processName);
        }
    }

    /**
     * �����Ɛŗ���o�^�p�ɐ��`
     *
     * @param ryokinDisp �\���p����
     * @param zeiritsuDisp �\���p�ŗ�
     * @return foward��
     */
    private Ryokin arrangeRyokin(String ryokinDisp, String zeiritsuDisp) {
        Ryokin arrRyoukin = new Ryokin();
        String ryokinRe = ryokinDisp.replaceAll(",", "");
        ryokinRe = String.format("%6s", ryokinRe).replace(' ', '0');
        String zeiritsuRe = String.format("%2s", zeiritsuDisp).replace(' ', '0');

        arrRyoukin.setRyokin(ryokinRe);
        arrRyoukin.setZeiritsu(zeiritsuRe);

        return arrRyoukin;
    }

    /**
     * ���̓`�F�b�N
     *
     * @param inSession �Z�b�V����RTO
     * @return true:�G���[��
     */
    private boolean validateInput(MstKanriRyokinJoho inSession) {
        /* �ϐ������� */
        Messages errors = new Messages();
        String groupCode;
        String itemName;

        // �G���[�`�F�b�N�p���X�g�쐬
        List<Option> ryokinKbnList = new ArrayList<>();
        // �����敪
        MeishoKanri meishoKanri = new MeishoKanri(BmaConstants.DS_REGISTRANT);
        meishoKanri.findByGroupCode(BmaConstants.MEISHO_KANRI_GROUP_RYOKIN_KBN, ryokinKbnList);
        // �ŋ敪
        String[] zeiKbns = {BmaConstants.ZEI_KBN_ZEINUKI, BmaConstants.ZEI_KBN_ZEIKOMI};

        /* �����敪 */
        groupCode = "ryokinKbn";
        itemName = "�����敪";
        if (BmaValidator.validateSelect(inSession.getRyokinKbn(), errors, groupCode, itemName)) {
            BmaValidator.validatePermissionSelect(inSession.getRyokinKbn(), ryokinKbnList, errors, groupCode, itemName);
        }

        /* ���� */
        groupCode = "ryokin";
        itemName = "����";
        if (BmaValidator.validateRequired(inSession.getRyokin(), errors, groupCode, itemName)) {
            if (BmaValidator.validateNumber(inSession.getRyokin(), errors, groupCode, itemName)) {
                BmaValidator.validateMaxLength(inSession.getRyokin(), BmaConstants.EQUAL_LENGTH_RYOKIN, errors, groupCode, itemName);
            }
        }

        /* �ŋ敪 */
        groupCode = "zeiKbn";
        itemName = "�ŋ敪";
        if (BmaValidator.validateSelect(inSession.getZeiKbn(), errors, groupCode, itemName)) {
            BmaValidator.validatePermissionSelect(inSession.getZeiKbn(), zeiKbns, errors, groupCode, itemName);
        }

        /* �ŗ� */
        groupCode = "zeiritsu";
        itemName = "�ŗ�";
        if (BmaValidator.validateRequired(inSession.getZeiritsu(), errors, groupCode, itemName)) {
            if (BmaValidator.validateNumber(inSession.getZeiritsu(), errors, groupCode, itemName)) {
                BmaValidator.validateMaxLength(inSession.getZeiritsu(), BmaConstants.EQUAL_LENGTH_ZEIRITSU, errors, groupCode, itemName);
            }
        }

        inSession.setErrors(errors);
        return errors.isEmpty();
    }
}