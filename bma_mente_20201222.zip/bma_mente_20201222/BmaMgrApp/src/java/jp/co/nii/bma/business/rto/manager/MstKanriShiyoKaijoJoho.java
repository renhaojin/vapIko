package jp.co.nii.bma.business.rto.manager;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import jp.co.nii.sew.presentation.AbstractRequestTransferObject;
import jp.co.nii.sew.presentation.Messages;
import jp.co.nii.sew.presentation.Option;

/**
 * �^�C�g��: TOP��� ����: TOP���RTO ���쌠: Copyright (c) 2020 ��Ж�: ���{���Y�Ɗ������
 *
 * @author nii19049
 */
public class MstKanriShiyoKaijoJoho extends AbstractRequestTransferObject {

    private Messages errors;
    private Map<Option, Messages> errorJohoMaps;
    private String shiyoKaijoSerchTable;
    private String shiyoKaijoTable;
    private String shiyoKaijoDetail;
    private String moshikomishaId;

    private String mstKanri;
    private String shiyoKaijoshinki;
    private String shiyoKaijoShinkiInp;
    private String shiyoKaijoShinkiConf;
    private String shiyoKaijoSerch;
    private String shiyoKaijoAdd;
    private String shiyoKaijoAddInp;
    private String shiyoKaijoAddConf;
    private String back;

    //��ʑJ��
    private String next;

    //�{�^��
    private String delete;

    //�����E�ꗗ��ʂ̃{�^��
    private String kaijoIdReNo;
    private String kaijoIdReNoBtnFlg;
    private String nendoUpdate;
    private String search;
    private String detail;
    private String update;
    private String[] shiyoKaijoSelect;

    //�g�p���V�K�o�^���
    private String shiyoKaijoHukusei;
    private String shiyoKaijoAddHukusei;

    //�g�p���ύX���͉��
    private String tokanKaijoCode;
    private String shiyoKaijoUpdateInp;
    private String kaijo;
    private String listNo;

    //�g�p���f�[�^(�e�[�u����`��)
    private String nendo;
    private String nendoSched;
    private String sknKsuCode;
    private String sknKsuName;
    private String shubetsuCode;
    private String shubetsuName;
    private String kaisuCode;
    private String kaisuName;
    private String kaijoId;
    private String kaijoShikenKbn;
    private String kaisaichiName;
    private String kaisaichiCode;
    private String kaijoCode;
    private String kaijoName;
    private String kaijoNameRyaku;
    private String yubinNo;
    private String jusho;
    private String tantoshaCode;
    private String nitteiFrom;
    private String nitteiTo;
    private String teiin;
    private String genzaiNinzu;
    private String bikoKaijo;
    private String bikoTanto;
    private String kaisaichiCodeKaijoMst;
    private String bikoKaijoDisp;
    private String bikoTantoDisp;

    private String tantosha;
    private String tantoBusho;
    private String telNo;
    private String faxNo;
    private String tantoshaMailAddress;
    private String teiinDisp;
    //��ꎎ���敪����
    private String kaijoShikenKbnName;
    //��ꎎ���敪��
    private String kaijoShikenName;

    // �����u�K��I��
    private String sknksuKbn;
    private String sknName;
    private String ksuName;
    private String sknksuNameRyaku;
    private List<Option> sknKbnList;
    private List<Option> ksuKbnList;
    
    // �����E�֓��b�M�z�I��
    private String tkyKsnKbn;
    private String tkyAndKsnName;
    private String tkyKsnName;
//    private List<Option> sknKbnList;
//    private List<Option> ksuKbnList;

    /* ��ʕ\���p���� */
    private List<MstKanriShiyoKaijoJoho> nitteiResultList;
    private String fromYear;
    private String fromMonth;
    private String fromDate;
    private String fromYobi;
    private String toYear;
    private String toMonth;
    private String toDate;
    private String toYobi;
    private String marginFlg;
    private String nitteiDisp;

    private String selectedKaijo;
    // DB�ɓo�^���ꂽ��ꎎ���敪�A���R�[�h�ێ��p
    private String dbKaijoShikenKbn;
    private String dbKaijoCode;

    //���X�g
    private List<MstKanriShiyoKaijoJoho> shiyoKaijoResultList;
    private List<MstKanriShiyoKaijoJoho> shiyoKaijoResultTokanList;
    private List<MstKanriShiyoKaijoJoho> shiyoKaijoSearchResultList;
    private List<MstKanriShiyoKaijoJoho> shiyoKaijoInputList;
    private List<MstKanriShiyoKaijoJoho> shiyoKaijoUpdateList;
    private List<MstKanriShiyoKaijoJoho> shiyoKaijoDisplayList;
    //�g�p���V�K�o�^
    private List<MstKanriShiyoKaijoJoho> kaijoList;
    private List<Option> tantoshaCodeList;
    private List<Option> kaisaichiCodeList;
    private String[] kaisaichiSelect;
    private String[] kaijoSelect;
    private String shiyoKaijoSrcListFlg;
    private List<Option> tantoshaList;
    private String shiyoKaijoListCount;
    //�g�p���ύX����
    private List<Option> kaijoByKaisaichiList;
    private List<Option> kaijoByTantoshaList;

    /* ������ʁ@�y�[�W���� */
    private int pageMax;
    private int page;
    private int maxDisp;
    private int firstDisp;
    private int pageBegin;
    private int pageEnd;
    private String CommandPage;
    private String pageIndex;

    /**
     * �R���X�g���N�^
     */
    public MstKanriShiyoKaijoJoho() {
        clearInfo();
    }

    /**
     * ���������\�b�h
     */
    public void clearInfo() {
        setShiyoKaijoSerchTable("");
        setShiyoKaijoTable("");
        String init[] = {""};
        setMoshikomishaId("");
        setErrors(new Messages());
        setErrorJohoMaps(new HashMap<Option, Messages>());
        setMstKanri("");
        setListNo("");
        //��ʑJ��
        setShiyoKaijoShinki("");
        setShiyoKaijoShinkiInp("");
        setShiyoKaijoShinkiConf("");
        setShiyoKaijoSerch("");
        setBack("");
        setNext("");
        setShiyoKaijoHukusei("");
        setShiyoKaijoAddHukusei("");
        setSearch("");
        setDetail("");
        setUpdate("");
        setShiyoKaijoDetail("");
        setShiyoKaijoAdd("");
        setShiyoKaijoAddInp("");
        setShiyoKaijoAddConf("");
        setShiyoKaijoUpdateInp("");
        setKaijo("");
        setKaijoIdReNo("");
        setKaijoIdReNoBtnFlg("0");
        setNendoUpdate("");

        //�폜�{�^��
        setDelete("");

        //�f�[�^
        setNendo("");
        setNendoSched("");
        setSknKsuCode("");
        setSknKsuName("");
        setShubetsuCode("");
        setShubetsuName("");
        setKaisuCode("");
        setKaisuName("");
        setKaijoId("");
        setKaijoShikenKbn("");
        setKaisaichiName("");
        setKaisaichiCode("");
        setKaijoCode("");
        setKaijoName("");
        setKaijoNameRyaku("");
        setYubinNo("");
        setJusho("");
        setTantoshaCode("");
        setNitteiFrom("");
        setNitteiTo("");
        setTeiin("");
        setGenzaiNinzu("");
        setBikoKaijo("");
        setBikoTanto("");
        setKaisaichiCodeKaijoMst("");
        setBikoKaijoDisp("");
        setBikoTantoDisp("");

        setTantosha("");
        setTantoBusho("");
        setTelNo("");
        setFaxNo("");
        setTeiinDisp("");
        setKaijoShikenKbnName("");
        setKaijoShikenName("");
        setTantoshaMailAddress("");
        setSelectedKaijo("1");
        setDbKaijoShikenKbn("");
        setDbKaijoCode("");

        //�����E�ꗗ���
        setShiyoKaijoSelect(init);

        //�u�K��I��
        setSknksuKbn("1");
        setSknName("");
        setKsuName("");
        setSknksuNameRyaku("");
        setSknKbnList(new ArrayList<Option>());
        setKsuKbnList(new ArrayList<Option>());
        
        //�����E�֓��b�M�z�I��
        setTkyKsnKbn("1");
        setTkyAndKsnName("");
        setTkyKsnName("");

        setNitteiResultList(new LinkedList<MstKanriShiyoKaijoJoho>());
        setFromYear("");
        setFromMonth("");
        setFromDate("");
        setFromYobi("");
        setToYear("");
        setToMonth("");
        setToDate("");
        setToYobi("");
        setMarginFlg("");
        setNitteiDisp("");

        //���X�g
        setShiyoKaijoResultList(new ArrayList<MstKanriShiyoKaijoJoho>());
        setShiyoKaijoResultTokanList(new ArrayList<MstKanriShiyoKaijoJoho>());
        setShiyoKaijoSearchResultList(new ArrayList<MstKanriShiyoKaijoJoho>());
        setShiyoKaijoInputList(new LinkedList<MstKanriShiyoKaijoJoho>());
        setShiyoKaijoUpdateList(new LinkedList<MstKanriShiyoKaijoJoho>());
        setKaijoList(new ArrayList<MstKanriShiyoKaijoJoho>());
        setShiyoKaijoDisplayList(new ArrayList<MstKanriShiyoKaijoJoho>());
        setTantoshaCodeList(new ArrayList<Option>());
        setKaisaichiCodeList(new ArrayList<Option>());
        setKaisaichiSelect(init);
        setKaijoSelect(init);
        setShiyoKaijoSrcListFlg("");
        setTantoshaList(new ArrayList<Option>());
        setShiyoKaijoListCount("");
        setKaijoByKaisaichiList(new ArrayList<Option>());
        setKaijoByTantoshaList(new ArrayList<Option>());

        //������ʐ���
        setFirstDisp(0);
        setMaxDisp(0);
        setPage(0);
        setPageBegin(0);
        setPageEnd(0);
        setPageMax(0);
        setCommandPage("");
        setPageIndex("");
    }

    /**
     * @return the errors
     */
    public Messages getErrors() {
        return errors;
    }

    /**
     * @param errors the errors to set
     */
    public void setErrors(Messages errors) {
        this.errors = errors;
    }

    /**
     * @return the mstKanri
     */
    public String getMstKanri() {
        return mstKanri;
    }

    /**
     * @param mstKanri the mstKanri to set
     */
    public void setMstKanri(String mstKanri) {
        this.mstKanri = mstKanri;
    }

    /**
     * @return the shiyoKaijoshiki
     */
    public String getShiyoKaijoShinki() {
        return getShiyoKaijoshinki();
    }

    /**
     * @param shiyoKaijoshiki the shiyoKaijoshiki to set
     */
    public void setShiyoKaijoShinki(String shiyoKaijoshinki) {
        this.setShiyoKaijoshinki(shiyoKaijoshinki);
    }

    /**
     * @return the shiyoKaijoserch
     */
    public String getShiyoKaijoSerch() {
        return shiyoKaijoSerch;
    }

    /**
     * @param shiyoKaijoSerch the shiyoKaijoserch to set
     */
    public void setShiyoKaijoSerch(String shiyoKaijoSerch) {
        this.shiyoKaijoSerch = shiyoKaijoSerch;
    }

    /**
     * @return the back
     */
    public String getBack() {
        return back;
    }

    /**
     * @param back the back to set
     */
    public void setBack(String back) {
        this.back = back;
    }

    @Override
    public void copyFromRequest(HttpServletRequest request) {
        setShiyoKaijoSerchTable((String) request.getAttribute("shiyoKaijoSerchTable"));
        setShiyoKaijoTable((String) request.getAttribute("shiyoKaijoTable"));
        setMstKanri((String) request.getAttribute("mstKanri"));
        setShiyoKaijoShinki((String) request.getAttribute("shiyoKaijoShinki"));
        setShiyoKaijoShinkiInp((String) request.getAttribute("shiyoKaijoShinkiInp"));
        setShiyoKaijoShinkiConf((String) request.getAttribute("shiyoKaijoShinkiConf"));
        setShiyoKaijoSerch((String) request.getAttribute("shiyoKaijoSerch"));
        setBack((String) request.getAttribute("back"));
        setNext((String) request.getAttribute("next"));

        setShiyoKaijoAddHukusei((String) request.getAttribute("shiyoKaijoAddHukusei"));
        setSearch((String) request.getAttribute("search"));
        setDetail((String) request.getAttribute("detail"));
        setUpdate((String) request.getAttribute("update"));
        setShiyoKaijoDetail((String) request.getAttribute("shiyoKaijoDetail"));
        setShiyoKaijoAdd((String) request.getAttribute("shiyoKaijoAdd"));
        setShiyoKaijoAddInp((String) request.getAttribute("shiyoKaijoAddInp"));
        setShiyoKaijoAddConf((String) request.getAttribute("shiyoKaijoAddConf"));
        setShiyoKaijoUpdateInp((String) request.getAttribute("shiyoKaijoUpdateInp"));
        setKaijo((String) request.getAttribute("kaijo"));
        setShiyoKaijoHukusei((String) request.getAttribute("shiyoKaijoHukusei"));
        setKaijoIdReNo((String) request.getAttribute("kaijoIdReNo"));
        setKaijoIdReNoBtnFlg((String) request.getAttribute("kaijoIdReNoBtnFlg"));
        setNendoUpdate((String) request.getAttribute("nendoUpdate"));
        setDelete((String) request.getAttribute("delete"));

        
        setKaijoId((String) request.getAttribute("kaijoId"));
        setDbKaijoShikenKbn((String) request.getAttribute("dbKaijoShikenKbn"));
        setDbKaijoCode((String) request.getAttribute("dbKaijoCode"));
        setKaijoShikenKbn((String) request.getAttribute("kaijoShikenKbn"));
        setBikoKaijo((String) request.getAttribute("bikoKaijo"));
        setBikoTanto((String) request.getAttribute("bikoTanto"));
        
        //�f�[�^
        setNendo((String) request.getAttribute("nendo"));
        setNendoSched((String) request.getAttribute("nendoSched"));
        setSknKsuCode((String) request.getAttribute("sknKsuCode"));
        setSknKsuName((String) request.getAttribute("sknKsuName"));
        setShubetsuCode((String) request.getAttribute("shubetsuCode"));
        setShubetsuName((String) request.getAttribute("shubetsuName"));
        setKaisuCode((String) request.getAttribute("kaisuCode"));
        setKaisuName((String) request.getAttribute("kaisuName"));
        setKaisaichiName((String) request.getAttribute("kaisaichiName"));
        setKaisaichiCode((String) request.getAttribute("kaisaichiCode"));
        setKaijoCode((String) request.getAttribute("kaijoCode"));
        setKaijoName((String) request.getAttribute("KaijoName"));
        setKaijoNameRyaku((String) request.getAttribute("kaijoNameRyaku"));
        setYubinNo((String) request.getAttribute("yubinNo"));
        setJusho((String) request.getAttribute("jusho"));
        setTantoshaCode((String) request.getAttribute("tantoshaCode"));
        setNitteiFrom((String) request.getAttribute("nitteiFrom"));
        setNitteiTo((String) request.getAttribute("nitteiTo"));
        setTeiin((String) request.getAttribute("teiin"));
        setGenzaiNinzu((String) request.getAttribute("genzaiNinzu"));

        setTantosha((String) request.getAttribute("tantosha"));
        setTantoBusho((String) request.getAttribute("tantoBusho"));
        setTelNo((String) request.getAttribute("telNo"));
        setFaxNo((String) request.getAttribute("faxNo"));
        setTantoshaMailAddress((String) request.getAttribute("tantoshaMailAddress"));
        setTeiinDisp((String) request.getAttribute("teiinDisp"));
        setKaijoShikenKbnName((String) request.getAttribute("kaijoShikenKbnName"));
        setKaijoShikenName((String) request.getAttribute("kaijoShikenName"));

        //�����E�ꗗ���
        setShiyoKaijoSelect((String[]) request.getParameterValues("shiyoKaijoSelect"));

        //�u�K��I��
        setSknksuKbn((String) request.getAttribute("sknksuKbn"));
        setSknName((String) request.getAttribute("sknName"));
        setKsuName((String) request.getAttribute("ksuName"));
        setSknksuNameRyaku((String) request.getAttribute("sknksuNameRyaku"));
        setSknKbnList((List<Option>) request.getAttribute("sknKbnList"));
        setKsuKbnList((List<Option>) request.getAttribute("ksuKbnList"));
        
        //�����E�֓��b�M�z�I��
        setTkyKsnKbn((String) request.getAttribute("tkyKsnKbn"));
        setTkyAndKsnName((String) request.getAttribute("tkyAndKsnName"));
        setTkyKsnName((String) request.getAttribute("TkyKsnName"));

        setNitteiResultList((List<MstKanriShiyoKaijoJoho>) request.getAttribute("nitteiResultList"));
        setFromYear((String) request.getAttribute("fromYear"));
        setFromMonth((String) request.getAttribute("fromMonth"));
        setFromDate((String) request.getAttribute("fromDate"));
        setFromYobi((String) request.getAttribute("fromYobi"));
        setToYear((String) request.getAttribute("toYear"));
        setToMonth((String) request.getAttribute("toMonth"));
        setToDate((String) request.getAttribute("toDate"));
        setToYobi((String) request.getAttribute("toYobi"));
        setMarginFlg((String) request.getAttribute("marginFlg"));
        setNitteiDisp((String) request.getAttribute("nitteiDisp"));

        //���X�g
        setShiyoKaijoResultList((List<MstKanriShiyoKaijoJoho>) request.getAttribute("shiyoKaijoResultList"));
        setShiyoKaijoResultTokanList((List<MstKanriShiyoKaijoJoho>) request.getAttribute("shiyoKaijoResultTokanList"));
        setShiyoKaijoSearchResultList((List<MstKanriShiyoKaijoJoho>) request.getAttribute("shiyoKaijoSearchResultList"));
        setShiyoKaijoUpdateList((List<MstKanriShiyoKaijoJoho>) request.getAttribute("shiyoKaijoUpdateList"));
        setKaijoList((List<MstKanriShiyoKaijoJoho>) request.getAttribute("kaijoList"));
        setTantoshaCodeList((List<Option>) request.getAttribute("tantoshaCodeList"));
        setKaisaichiCodeList((List<Option>) request.getAttribute("kaisaichiCodeList"));
        setKaisaichiSelect((String[]) request.getParameterValues("kaisaichiSelect"));
        setKaijoSelect((String[]) request.getParameterValues("kaijoSelect"));
        setShiyoKaijoSrcListFlg((String) request.getAttribute("kaijoMstSrcListFlg"));
        setTantoshaList((List<Option>) request.getAttribute("tantoshaList"));
        setShiyoKaijoDisplayList((List<MstKanriShiyoKaijoJoho>) request.getAttribute("shiyoKaijoDisplayList"));
        setKaijoByKaisaichiList((List<Option>) request.getAttribute("kaijoByKaisaichiList"));
        setKaijoByTantoshaList((List<Option>) request.getAttribute("kaijoByTantoshaList"));
        setListNo((String) request.getAttribute("listNo"));

        //�y�[�W
        setCommandPage((String) request.getAttribute("commandPage"));
        setPageIndex((String) request.getAttribute("pageIndex"));

        MstKanriShiyoKaijoJoho shiyoKaijoJoho;
        int listCount = 0;
        if (request.getAttribute("shiyoKaijoListCount") != null) {
            listCount = Integer.parseInt((String) request.getAttribute("shiyoKaijoListCount"));
        }
        for (int i = 0; i < listCount; i++) {
            shiyoKaijoJoho = new MstKanriShiyoKaijoJoho();
            shiyoKaijoJoho.copyFromRequest_ShiyoKaijoInput(request, i);
            shiyoKaijoInputList.add(shiyoKaijoJoho);
        }

        HttpSession session = request.getSession(false);
        if (session.getAttribute("MgrTopJoho") != null) {
            MgrTopJoho tmp = (MgrTopJoho) session.getAttribute("MgrTopJoho");
            setMoshikomishaId((String) tmp.getMoshikomishaId());
        }
    }

    /**
     * ���N�G�X�g��������擾���� �X�P�W���[���ύX���͉�ʂł̓��͒l
     *
     * @param request ���N�G�X�g
     * @param idx index
     */
    public void copyFromRequest_ShiyoKaijoInput(HttpServletRequest request, int idx) {
        setKaijoId((String) request.getAttribute("kaijoId" + idx));
        setDbKaijoShikenKbn((String) request.getAttribute("dbKaijoShikenKbn" + idx));
        setKaisaichiCode((String) request.getAttribute("kaisaichiCode" + idx));
        setKaisaichiName((String) request.getAttribute("kaisaichiName" + idx));
        setDbKaijoCode((String) request.getAttribute("dbKaijoCode" + idx));
        setKaijoCode((String) request.getAttribute("kaijoCode" + idx));
        setKaijoName((String) request.getAttribute("kaijoName" + idx));
        setKaijoNameRyaku((String) request.getAttribute("kaijoNameRyaku" + idx));

        setKaijoShikenKbn((String) request.getAttribute("kaijoShikenKbn" + idx));
        setKaijoShikenName((String) request.getAttribute("kaijoShikenName" + idx));
        setTantoshaCode((String) request.getAttribute("tantoshaCode" + idx));
        setTantosha((String) request.getAttribute("tantosha" + idx));
        setNitteiFrom((String) request.getAttribute("nitteiFrom" + idx));
        setFromYear((String) request.getAttribute("fromYear" + idx));
        setFromMonth((String) request.getAttribute("fromMonth" + idx));
        setFromDate((String) request.getAttribute("fromDate" + idx));
        setFromYobi((String) request.getAttribute("fromYobi" + idx));
        setNitteiTo((String) request.getAttribute("nitteiTo" + idx));
        setToYear((String) request.getAttribute("toYear" + idx));
        setToMonth((String) request.getAttribute("toMonth" + idx));
        setToDate((String) request.getAttribute("toDate" + idx));
        setToYobi((String) request.getAttribute("toYobi" + idx));
        setTeiin((String) request.getAttribute("teiin" + idx));
        setBikoKaijo((String) request.getAttribute("bikoKaijo" + idx));
        setBikoTanto((String) request.getAttribute("bikoTanto" + idx));
        setMarginFlg((String) request.getAttribute("marginFlg" + idx));
        setSelectedKaijo((String) request.getAttribute("selectedKaijo" + idx));

    }

    /**
     * @return the next
     */
    public String getNext() {
        return next;
    }

    /**
     * @param next the next to set
     */
    public void setNext(String next) {
        this.next = next;
    }

    /**
     * @return the shiyoKaijoHukusei
     */
    public String getShiyoKaijoHukusei() {
        return shiyoKaijoHukusei;
    }

    /**
     * @param shiyoKaijoHukusei the shiyoKaijoHukusei to set
     */
    public void setShiyoKaijoHukusei(String shiyoKaijoHukusei) {
        this.shiyoKaijoHukusei = shiyoKaijoHukusei;
    }

    /**
     * @return the search
     */
    public String getSearch() {
        return search;
    }

    /**
     * @param search the search to set
     */
    public void setSearch(String search) {
        this.search = search;
    }

    /**
     * @return the detail
     */
    public String getDetail() {
        return detail;
    }

    /**
     * @param detail the detail to set
     */
    public void setDetail(String detail) {
        this.detail = detail;
    }

    /**
     * @return the shiyoKaijoshinki
     */
    public String getShiyoKaijoshinki() {
        return shiyoKaijoshinki;
    }

    /**
     * @param shiyoKaijoshinki the shiyoKaijoshinki to set
     */
    public void setShiyoKaijoshinki(String shiyoKaijoshinki) {
        this.shiyoKaijoshinki = shiyoKaijoshinki;
    }

    /**
     * @return the nendo
     */
    public String getNendo() {
        return nendo;
    }

    /**
     * @param nendo the nendo to set
     */
    public void setNendo(String nendo) {
        this.nendo = nendo;
    }

    /**
     * @return the sknKsuCode
     */
    public String getSknKsuCode() {
        return sknKsuCode;
    }

    /**
     * @param sknKsuCode the sknKsuCode to set
     */
    public void setSknKsuCode(String sknKsuCode) {
        this.sknKsuCode = sknKsuCode;
    }

    /**
     * @return the shubetsuCode
     */
    public String getShubetsuCode() {
        return shubetsuCode;
    }

    /**
     * @param shubetsuCode the shubetsuCode to set
     */
    public void setShubetsuCode(String shubetsuCode) {
        this.shubetsuCode = shubetsuCode;
    }

    /**
     * @return the kaisuCode
     */
    public String getKaisuCode() {
        return kaisuCode;
    }

    /**
     * @param kaisuCode the kaisuCode to set
     */
    public void setKaisuCode(String kaisuCode) {
        this.kaisuCode = kaisuCode;
    }

    /**
     * @return the kaijoId
     */
    public String getKaijoId() {
        return kaijoId;
    }

    /**
     * @param kaijoId the kaijoId to set
     */
    public void setKaijoId(String kaijoId) {
        this.kaijoId = kaijoId;
    }

    /**
     * @return the kaijoShikenKbn
     */
    public String getKaijoShikenKbn() {
        return kaijoShikenKbn;
    }

    /**
     * @param kaijoShikenKbn the kaijoShikenKbn to set
     */
    public void setKaijoShikenKbn(String kaijoShikenKbn) {
        this.kaijoShikenKbn = kaijoShikenKbn;
    }

    /**
     * @return the kaisaichiCode
     */
    public String getKaisaichiCode() {
        return kaisaichiCode;
    }

    /**
     * @param kaisaichiCode the kaisaichiCode to set
     */
    public void setKaisaichiCode(String kaisaichiCode) {
        this.kaisaichiCode = kaisaichiCode;
    }

    /**
     * @return the kaijoCode
     */
    public String getKaijoCode() {
        return kaijoCode;
    }

    /**
     * @param kaijoCode the kaijoCode to set
     */
    public void setKaijoCode(String kaijoCode) {
        this.kaijoCode = kaijoCode;
    }

    /**
     * @return the kaijoName
     */
    public String getKaijoName() {
        return kaijoName;
    }

    /**
     * @param kaijoName the kaijoName to set
     */
    public void setKaijoName(String kaijoName) {
        this.kaijoName = kaijoName;
    }

    /**
     * @return the kaijoNameRyaku
     */
    public String getKaijoNameRyaku() {
        return kaijoNameRyaku;
    }

    /**
     * @param kaijoNameRyaku the kaijoNameRyaku to set
     */
    public void setKaijoNameRyaku(String kaijoNameRyaku) {
        this.kaijoNameRyaku = kaijoNameRyaku;
    }

    /**
     * @return the yubinNo
     */
    public String getYubinNo() {
        return yubinNo;
    }

    /**
     * @param yubinNo the yubinNo to set
     */
    public void setYubinNo(String yubinNo) {
        this.yubinNo = yubinNo;
    }

    /**
     * @return the jusho
     */
    public String getJusho() {
        return jusho;
    }

    /**
     * @param jusho the jusho to set
     */
    public void setJusho(String jusho) {
        this.jusho = jusho;
    }

    /**
     * @return the tantoshaCode
     */
    public String getTantoshaCode() {
        return tantoshaCode;
    }

    /**
     * @param tantoshaCode the tantoshaCode to set
     */
    public void setTantoshaCode(String tantoshaCode) {
        this.tantoshaCode = tantoshaCode;
    }

    /**
     * @return the nitteiFrom
     */
    public String getNitteiFrom() {
        return nitteiFrom;
    }

    /**
     * @param nitteiFrom the nitteiFrom to set
     */
    public void setNitteiFrom(String nitteiFrom) {
        this.nitteiFrom = nitteiFrom;
    }

    /**
     * @return the nitteiTo
     */
    public String getNitteiTo() {
        return nitteiTo;
    }

    /**
     * @param nitteiTo the nitteiTo to set
     */
    public void setNitteiTo(String nitteiTo) {
        this.nitteiTo = nitteiTo;
    }

    /**
     * @return the teiin
     */
    public String getTeiin() {
        return teiin;
    }

    /**
     * @param teiin the teiin to set
     */
    public void setTeiin(String teiin) {
        this.teiin = teiin;
    }

    /**
     * @return the genzaiNinzu
     */
    public String getGenzaiNinzu() {
        return genzaiNinzu;
    }

    /**
     * @param genzaiNinzu the genzaiNinzu to set
     */
    public void setGenzaiNinzu(String genzaiNinzu) {
        this.genzaiNinzu = genzaiNinzu;
    }

    /**
     * @return the bikoKaijo
     */
    public String getBikoKaijo() {
        return bikoKaijo;
    }

    /**
     * @param bikoKaijo the bikoKaijo to set
     */
    public void setBikoKaijo(String bikoKaijo) {
        this.bikoKaijo = bikoKaijo;
    }

    /**
     * @return the bikoTanto
     */
    public String getBikoTanto() {
        return bikoTanto;
    }

    /**
     * @param bikoTanto the bikoTanto to set
     */
    public void setBikoTanto(String bikoTanto) {
        this.bikoTanto = bikoTanto;
    }

    /**
     * @return the bikoKaijoDisp
     */
    public String getBikoKaijoDisp() {
        return bikoKaijoDisp;
    }

    /**
     * @param bikoKaijoDisp the bikoKaijoDisp to set
     */
    public void setBikoKaijoDisp(String bikoKaijoDisp) {
        this.bikoKaijoDisp = bikoKaijoDisp;
    }

    /**
     * @return the bikoTantoDisp
     */
    public String getBikoTantoDisp() {
        return bikoTantoDisp;
    }

    /**
     * @param bikoTantoDisp the bikoTantoDisp to set
     */
    public void setBikoTantoDisp(String bikoTantoDisp) {
        this.bikoTantoDisp = bikoTantoDisp;
    }

    /**
     * @return the shiyoKaijoResultList
     */
    public List<MstKanriShiyoKaijoJoho> getShiyoKaijoResultList() {
        return shiyoKaijoResultList;
    }

    /**
     * @param shiyoKaijoResultList the shiyoKaijoResultList to set
     */
    public void setShiyoKaijoResultList(List<MstKanriShiyoKaijoJoho> shiyoKaijoResultList) {
        this.shiyoKaijoResultList = shiyoKaijoResultList;
    }

    /**
     * @return the tantoshaCodeList
     */
    public List<Option> getTantoshaCodeList() {
        return tantoshaCodeList;
    }

    /**
     * @param tantoshaCodeList the tantoshaCodeList to set
     */
    public void setTantoshaCodeList(List<Option> tantoshaCodeList) {
        this.tantoshaCodeList = tantoshaCodeList;
    }

    /**
     * @return the kaisaichiCodeList
     */
    public List<Option> getKaisaichiCodeList() {
        return kaisaichiCodeList;
    }

    /**
     * @param kaisaichiCodeList the kaisaichiCodeList to set
     */
    public void setKaisaichiCodeList(List<Option> kaisaichiCodeList) {
        this.kaisaichiCodeList = kaisaichiCodeList;
    }

    /**
     * @return the kaisaichiSelect
     */
    public String[] getKaisaichiSelect() {
        return kaisaichiSelect;
    }

    /**
     * @param kaisaichiSelect the kaisaichiSelect to set
     */
    public void setKaisaichiSelect(String[] kaisaichiSelect) {
        this.kaisaichiSelect = kaisaichiSelect;
    }

    /**
     * @return the shiyoKaijoSrcListFlg
     */
    public String getShiyoKaijoSrcListFlg() {
        return shiyoKaijoSrcListFlg;
    }

    /**
     * @param shiyoKaijoSrcListFlg the shiyoKaijoSrcListFlg to set
     */
    public void setShiyoKaijoSrcListFlg(String shiyoKaijoSrcListFlg) {
        this.shiyoKaijoSrcListFlg = shiyoKaijoSrcListFlg;
    }

    /**
     * @return the sknksuKbn
     */
    public String getSknksuKbn() {
        return sknksuKbn;
    }

    /**
     * @param sknksuKbn the sknksuKbn to set
     */
    public void setSknksuKbn(String sknksuKbn) {
        this.sknksuKbn = sknksuKbn;
    }

    /**
     * @return the sknName
     */
    public String getSknName() {
        return sknName;
    }

    /**
     * @param sknName the sknName to set
     */
    public void setSknName(String sknName) {
        this.sknName = sknName;
    }

    /**
     * @return the ksuName
     */
    public String getKsuName() {
        return ksuName;
    }

    /**
     * @param ksuName the ksuName to set
     */
    public void setKsuName(String ksuName) {
        this.ksuName = ksuName;
    }

    /**
     * @return the sknksuNameRyaku
     */
    public String getSknksuNameRyaku() {
        return sknksuNameRyaku;
    }

    /**
     * @param sknksuNameRyaku the sknksuNameRyaku to set
     */
    public void setSknksuNameRyaku(String sknksuNameRyaku) {
        this.sknksuNameRyaku = sknksuNameRyaku;
    }

    /**
     * @return the sknKbnList
     */
    public List<Option> getSknKbnList() {
        return sknKbnList;
    }

    /**
     * @param sknKbnList the sknKbnList to set
     */
    public void setSknKbnList(List<Option> sknKbnList) {
        this.sknKbnList = sknKbnList;
    }

    /**
     * @return the ksuKbnList
     */
    public List<Option> getKsuKbnList() {
        return ksuKbnList;
    }

    /**
     * @param ksuKbnList the ksuKbnList to set
     */
    public void setKsuKbnList(List<Option> ksuKbnList) {
        this.ksuKbnList = ksuKbnList;
    }

    /**
     * @return the shiyoKaijoSearchTable
     */
    public String getShiyoKaijoSerchTable() {
        return shiyoKaijoSerchTable;
    }

    /**
     * @param shiyoKaijoSerchTable the shiyoKaijoSearchTable to set
     */
    public void setShiyoKaijoSerchTable(String shiyoKaijoSerchTable) {
        this.shiyoKaijoSerchTable = shiyoKaijoSerchTable;
    }

    /**
     * @return the shiyoKaijoDetail
     */
    public String getShiyoKaijoDetail() {
        return shiyoKaijoDetail;
    }

    /**
     * @param shiyoKaijoDetail the shiyoKaijoDetail to set
     */
    public void setShiyoKaijoDetail(String shiyoKaijoDetail) {
        this.shiyoKaijoDetail = shiyoKaijoDetail;
    }

    /**
     * @return the kaisaichiName
     */
    public String getKaisaichiName() {
        return kaisaichiName;
    }

    /**
     * @param kaisaichiName the kaisaichiName to set
     */
    public void setKaisaichiName(String kaisaichiName) {
        this.kaisaichiName = kaisaichiName;
    }

    /**
     * @return the tantosha
     */
    public String getTantosha() {
        return tantosha;
    }

    /**
     * @param tantosha the tantosha to set
     */
    public void setTantosha(String tantosha) {
        this.tantosha = tantosha;
    }

    /**
     * @return the tantoBusho
     */
    public String getTantoBusho() {
        return tantoBusho;
    }

    /**
     * @param tantoBusho the tantoBusho to set
     */
    public void setTantoBusho(String tantoBusho) {
        this.tantoBusho = tantoBusho;
    }

    /**
     * @return the telNo
     */
    public String getTelNo() {
        return telNo;
    }

    /**
     * @param telNo the telNo to set
     */
    public void setTelNo(String telNo) {
        this.telNo = telNo;
    }

    /**
     * @return the faxNo
     */
    public String getFaxNo() {
        return faxNo;
    }

    /**
     * @param faxNo the faxNo to set
     */
    public void setFaxNo(String faxNo) {
        this.faxNo = faxNo;
    }

    /**
     * @return the teiinDisp
     */
    public String getTeiinDisp() {
        return teiinDisp;
    }

    /**
     * @param teiinDisp the teiinDisp to set
     */
    public void setTeiinDisp(String teiinDisp) {
        this.teiinDisp = teiinDisp;
    }

    /**
     * @return the shiyoKaijoAdd
     */
    public String getShiyoKaijoAdd() {
        return shiyoKaijoAdd;
    }

    /**
     * @param shiyoKaijoAdd the shiyoKaijoAdd to set
     */
    public void setShiyoKaijoAdd(String shiyoKaijoAdd) {
        this.shiyoKaijoAdd = shiyoKaijoAdd;
    }

    /**
     * @return the shiyoKaijoSearchResultList
     */
    public List<MstKanriShiyoKaijoJoho> getShiyoKaijoSearchResultList() {
        return shiyoKaijoSearchResultList;
    }

    /**
     * @param shiyoKaijoSearchResultList the shiyoKaijoSearchResultList to set
     */
    public void setShiyoKaijoSearchResultList(List<MstKanriShiyoKaijoJoho> shiyoKaijoSearchResultList) {
        this.shiyoKaijoSearchResultList = shiyoKaijoSearchResultList;
    }

    /**
     * @return the kaijoShikenKbnName
     */
    public String getKaijoShikenKbnName() {
        return kaijoShikenKbnName;
    }

    /**
     * @param kaijoShikenKbnName the kaijoShikenKbnName to set
     */
    public void setKaijoShikenKbnName(String kaijoShikenKbnName) {
        this.kaijoShikenKbnName = kaijoShikenKbnName;
    }

    /**
     * @return the mailAddress
     */
    public String getTantoshaMailAddress() {
        return tantoshaMailAddress;
    }

    /**
     * @param mailAdress the mailAddress to set
     */
    public void setTantoshaMailAddress(String tantoshaMailAddress) {
        this.tantoshaMailAddress = tantoshaMailAddress;
    }

    /**
     * @return the sknKsuName
     */
    public String getSknKsuName() {
        return sknKsuName;
    }

    /**
     * @param sknKsuName the sknKsuName to set
     */
    public void setSknKsuName(String sknKsuName) {
        this.sknKsuName = sknKsuName;
    }

    /**
     * @return the shubetsuName
     */
    public String getShubetsuName() {
        return shubetsuName;
    }

    /**
     * @param shubetsuName the shubetsuName to set
     */
    public void setShubetsuName(String shubetsuName) {
        this.shubetsuName = shubetsuName;
    }

    /**
     * @return the kaijoShikenName
     */
    public String getKaijoShikenName() {
        return kaijoShikenName;
    }

    /**
     * @param kaijoShikenName the kaijoShikenName to set
     */
    public void setKaijoShikenName(String kaijoShikenName) {
        this.kaijoShikenName = kaijoShikenName;
    }

    /**
     * @return the kaisuName
     */
    public String getKaisuName() {
        return kaisuName;
    }

    /**
     * @param kaisuName the kaisuName to set
     */
    public void setKaisuName(String kaisuName) {
        this.kaisuName = kaisuName;
    }

    /**
     * @return the tantoshaList
     */
    public List<Option> getTantoshaList() {
        return tantoshaList;
    }

    /**
     * @param tantoshaList the tantoshaList to set
     */
    public void setTantoshaList(List<Option> tantoshaList) {
        this.tantoshaList = tantoshaList;
    }

    /**
     * @return the shiyoKaijoUpdateInp
     */
    public String getShiyoKaijoUpdateInp() {
        return shiyoKaijoUpdateInp;
    }

    /**
     * @param shiyoKaijoUpdateInp the shiyoKaijoUpdateInp to set
     */
    public void setShiyoKaijoUpdateInp(String shiyoKaijoUpdateInp) {
        this.shiyoKaijoUpdateInp = shiyoKaijoUpdateInp;
    }

    /**
     * @return the nitteiResultList
     */
    public List<MstKanriShiyoKaijoJoho> getNitteiResultList() {
        return nitteiResultList;
    }

    /**
     * @param nitteiResultList the nitteiResultList to set
     */
    public void setNitteiResultList(List<MstKanriShiyoKaijoJoho> nitteiResultList) {
        this.nitteiResultList = nitteiResultList;
    }

    /**
     * @return the fromYear
     */
    public String getFromYear() {
        return fromYear;
    }

    /**
     * @param fromYear the fromYear to set
     */
    public void setFromYear(String fromYear) {
        this.fromYear = fromYear;
    }

    /**
     * @return the fromMonth
     */
    public String getFromMonth() {
        return fromMonth;
    }

    /**
     * @param fromMonth the fromMonth to set
     */
    public void setFromMonth(String fromMonth) {
        this.fromMonth = fromMonth;
    }

    /**
     * @return the fromDate
     */
    public String getFromDate() {
        return fromDate;
    }

    /**
     * @param fromDate the fromDate to set
     */
    public void setFromDate(String fromDate) {
        this.fromDate = fromDate;
    }

    /**
     * @return the fromYobi
     */
    public String getFromYobi() {
        return fromYobi;
    }

    /**
     * @param fromYobi the fromYobi to set
     */
    public void setFromYobi(String fromYobi) {
        this.fromYobi = fromYobi;
    }

    /**
     * @return the toYear
     */
    public String getToYear() {
        return toYear;
    }

    /**
     * @param toYear the toYear to set
     */
    public void setToYear(String toYear) {
        this.toYear = toYear;
    }

    /**
     * @return the toMonth
     */
    public String getToMonth() {
        return toMonth;
    }

    /**
     * @param toMonth the toMonth to set
     */
    public void setToMonth(String toMonth) {
        this.toMonth = toMonth;
    }

    /**
     * @return the toDate
     */
    public String getToDate() {
        return toDate;
    }

    /**
     * @param toDate the toDate to set
     */
    public void setToDate(String toDate) {
        this.toDate = toDate;
    }

    /**
     * @return the toYobi
     */
    public String getToYobi() {
        return toYobi;
    }

    /**
     * @param toYobi the toYobi to set
     */
    public void setToYobi(String toYobi) {
        this.toYobi = toYobi;
    }

    /**
     * @return the marginFlg
     */
    public String getMarginFlg() {
        return marginFlg;
    }

    /**
     * @param marginFlg the marginFlg to set
     */
    public void setMarginFlg(String marginFlg) {
        this.marginFlg = marginFlg;
    }

    /**
     * @return the nitteiDisp
     */
    public String getNitteiDisp() {
        return nitteiDisp;
    }

    /**
     * @param nitteiDisp the nitteiDisp to set
     */
    public void setNitteiDisp(String nitteiDisp) {
        this.nitteiDisp = nitteiDisp;
    }

    /**
     * @return the shiyoKaijoShinkiInp
     */
    public String getShiyoKaijoShinkiInp() {
        return shiyoKaijoShinkiInp;
    }

    /**
     * @param shiyoKaijoShinkiInp the shiyoKaijoShinkiInp to set
     */
    public void setShiyoKaijoShinkiInp(String shiyoKaijoShinkiInp) {
        this.shiyoKaijoShinkiInp = shiyoKaijoShinkiInp;
    }

    /**
     * @return the shiyoKaijoAddInp
     */
    public String getShiyoKaijoAddInp() {
        return shiyoKaijoAddInp;
    }

    /**
     * @param shiyoKaijoAddInp the shiyoKaijoAddInp to set
     */
    public void setShiyoKaijoAddInp(String shiyoKaijoAddInp) {
        this.shiyoKaijoAddInp = shiyoKaijoAddInp;
    }

    /**
     * @return the kaijoSelect
     */
    public String[] getKaijoSelect() {
        return kaijoSelect;
    }

    /**
     * @param kaijoSelect the kaijoSelect to set
     */
    public void setKaijoSelect(String[] kaijoSelect) {
        this.kaijoSelect = kaijoSelect;
    }

    /**
     * @return the kaijoList
     */
    public List<MstKanriShiyoKaijoJoho> getKaijoList() {
        return kaijoList;
    }

    /**
     * @param kaijoList the kaijoList to set
     */
    public void setKaijoList(List<MstKanriShiyoKaijoJoho> kaijoList) {
        this.kaijoList = kaijoList;
    }

    /**
     * @return the shiyoKaijoAddHukusei
     */
    public String getShiyoKaijoAddHukusei() {
        return shiyoKaijoAddHukusei;
    }

    /**
     * @param shiyoKaijoAddHukusei the shiyoKaijoAddHukusei to set
     */
    public void setShiyoKaijoAddHukusei(String shiyoKaijoAddHukusei) {
        this.shiyoKaijoAddHukusei = shiyoKaijoAddHukusei;
    }

    /**
     * @return the shiyoKaijoInputList
     */
    public List<MstKanriShiyoKaijoJoho> getShiyoKaijoInputList() {
        return shiyoKaijoInputList;
    }

    /**
     * @param shiyoKaijoInputList the shiyoKaijoInputList to set
     */
    public void setShiyoKaijoInputList(List<MstKanriShiyoKaijoJoho> shiyoKaijoInputList) {
        this.shiyoKaijoInputList = shiyoKaijoInputList;
    }

    /**
     * @return the shiyoKaijoShinkiConf
     */
    public String getShiyoKaijoShinkiConf() {
        return shiyoKaijoShinkiConf;
    }

    /**
     * @param shiyoKaijoShinkiConf the shiyoKaijoShinkiConf to set
     */
    public void setShiyoKaijoShinkiConf(String shiyoKaijoShinkiConf) {
        this.shiyoKaijoShinkiConf = shiyoKaijoShinkiConf;
    }

    /**
     * @return the shiyoKaijoListCount
     */
    public String getShiyoKaijoListCount() {
        return shiyoKaijoListCount;
    }

    /**
     * @param shiyoKaijoListCount the shiyoKaijoListCount to set
     */
    public void setShiyoKaijoListCount(String shiyoKaijoListCount) {
        this.shiyoKaijoListCount = shiyoKaijoListCount;
    }

    /**
     * @return the shiyoKaijoAddConf
     */
    public String getShiyoKaijoAddConf() {
        return shiyoKaijoAddConf;
    }

    /**
     * @param shiyoKaijoAddConf the shiyoKaijoAddConf to set
     */
    public void setShiyoKaijoAddConf(String shiyoKaijoAddConf) {
        this.shiyoKaijoAddConf = shiyoKaijoAddConf;
    }

    /**
     * @return the shiyoKaijoUpdateList
     */
    public List<MstKanriShiyoKaijoJoho> getShiyoKaijoUpdateList() {
        return shiyoKaijoUpdateList;
    }

    /**
     * @param shiyoKaijoUpdateList the shiyoKaijoUpdateList to set
     */
    public void setShiyoKaijoUpdateList(List<MstKanriShiyoKaijoJoho> shiyoKaijoUpdateList) {
        this.shiyoKaijoUpdateList = shiyoKaijoUpdateList;
    }

    /**
     * @return the selectedKaijo
     */
    public String getSelectedKaijo() {
        return selectedKaijo;
    }

    /**
     * @param selectedKaijo the selectedKaijo to set
     */
    public void setSelectedKaijo(String selectedKaijo) {
        this.selectedKaijo = selectedKaijo;
    }

    /**
     * @return the dbKaijoShikenKbn
     */
    public String getDbKaijoShikenKbn() {
        return dbKaijoShikenKbn;
    }

    /**
     * @param dbKaijoShikenKbn the dbKaijoShikenKbn to set
     */
    public void setDbKaijoShikenKbn(String dbKaijoShikenKbn) {
        this.dbKaijoShikenKbn = dbKaijoShikenKbn;
    }

    /**
     * @return the pageMax
     */
    public int getPageMax() {
        return pageMax;
    }

    /**
     * @param pageMax the pageMax to set
     */
    public void setPageMax(int pageMax) {
        this.pageMax = pageMax;
    }

    /**
     * @return the page
     */
    public int getPage() {
        return page;
    }

    /**
     * @param page the page to set
     */
    public void setPage(int page) {
        this.page = page;
    }

    /**
     * @return the maxDisp
     */
    public int getMaxDisp() {
        return maxDisp;
    }

    /**
     * @param maxDisp the maxDisp to set
     */
    public void setMaxDisp(int maxDisp) {
        this.maxDisp = maxDisp;
    }

    /**
     * @return the firstDisp
     */
    public int getFirstDisp() {
        return firstDisp;
    }

    /**
     * @param firstDisp the firstDisp to set
     */
    public void setFirstDisp(int firstDisp) {
        this.firstDisp = firstDisp;
    }

    /**
     * @return the pageBegin
     */
    public int getPageBegin() {
        return pageBegin;
    }

    /**
     * @param pageBegin the pageBegin to set
     */
    public void setPageBegin(int pageBegin) {
        this.pageBegin = pageBegin;
    }

    /**
     * @return the pageEnd
     */
    public int getPageEnd() {
        return pageEnd;
    }

    /**
     * @param pageEnd the pageEnd to set
     */
    public void setPageEnd(int pageEnd) {
        this.pageEnd = pageEnd;
    }

    /**
     * @return the CommandPage
     */
    public String getCommandPage() {
        return CommandPage;
    }

    /**
     * @param CommandPage the CommandPage to set
     */
    public void setCommandPage(String CommandPage) {
        this.CommandPage = CommandPage;
    }

    /**
     * @return the pageIndex
     */
    public String getPageIndex() {
        return pageIndex;
    }

    /**
     * @param pageIndex the pageIndex to set
     */
    public void setPageIndex(String pageIndex) {
        this.pageIndex = pageIndex;
    }

    /**
     * @return the shiyoKaijoDisplayList
     */
    public List<MstKanriShiyoKaijoJoho> getShiyoKaijoDisplayList() {
        return shiyoKaijoDisplayList;
    }

    /**
     * @param shiyoKaijoDisplayList the shiyoKaijoDisplayList to set
     */
    public void setShiyoKaijoDisplayList(List<MstKanriShiyoKaijoJoho> shiyoKaijoDisplayList) {
        this.shiyoKaijoDisplayList = shiyoKaijoDisplayList;
    }

    /**
     * @return the moshikomishaId
     */
    public String getMoshikomishaId() {
        return moshikomishaId;
    }

    /**
     * @param moshikomishaId the moshikomishaId to set
     */
    public void setMoshikomishaId(String moshikomishaId) {
        this.moshikomishaId = moshikomishaId;
    }

    /**
     * @return the errorJohoMaps
     */
    public Map<Option, Messages> getErrorJohoMaps() {
        return errorJohoMaps;
    }

    /**
     * @param errorJohoMaps the errorJohoMaps to set
     */
    public void setErrorJohoMaps(Map<Option, Messages> errorJohoMaps) {
        this.errorJohoMaps = errorJohoMaps;
    }

    /**
     * @return the nendoSched
     */
    public String getNendoSched() {
        return nendoSched;
    }

    /**
     * @param nendoSched the nendoSched to set
     */
    public void setNendoSched(String nendoSched) {
        this.nendoSched = nendoSched;
    }

    /**
     * @return the kaijo
     */
    public String getKaijo() {
        return kaijo;
    }

    /**
     * @param kaijo the kaijo to set
     */
    public void setKaijo(String kaijo) {
        this.kaijo = kaijo;
    }

    /**
     * @return the kaijoByKaisaichiList
     */
    public List<Option> getKaijoByKaisaichiList() {
        return kaijoByKaisaichiList;
    }

    /**
     * @param kaijoByKaisaichiList the kaijoByKaisaichiList to set
     */
    public void setKaijoByKaisaichiList(List<Option> kaijoByKaisaichiList) {
        this.kaijoByKaisaichiList = kaijoByKaisaichiList;
    }

    /**
     * @return the kaijoIdReNo
     */
    public String getKaijoIdReNo() {
        return kaijoIdReNo;
    }

    /**
     * @param kaijoIdReNo the kaijoIdReNo to set
     */
    public void setKaijoIdReNo(String kaijoIdReNo) {
        this.kaijoIdReNo = kaijoIdReNo;
    }

    /**
     * @return the nendoUpdate
     */
    public String getNendoUpdate() {
        return nendoUpdate;
    }

    /**
     * @param nendoUpdate the nendoUpdate to set
     */
    public void setNendoUpdate(String nendoUpdate) {
        this.nendoUpdate = nendoUpdate;
    }

    /**
     * @return the shiyoKaijoTable
     */
    public String getShiyoKaijoTable() {
        return shiyoKaijoTable;
    }

    /**
     * @param shiyoKaijoTable the shiyoKaijoTable to set
     */
    public void setShiyoKaijoTable(String shiyoKaijoTable) {
        this.shiyoKaijoTable = shiyoKaijoTable;
    }

    /**
     * @return the dbKaijoCode
     */
    public String getDbKaijoCode() {
        return dbKaijoCode;
    }

    /**
     * @param dbKaijoCode the dbKaijoCode to set
     */
    public void setDbKaijoCode(String dbKaijoCode) {
        this.dbKaijoCode = dbKaijoCode;
    }

    /**
     * @return the delete
     */
    public String getDelete() {
        return delete;
    }

    /**
     * @param delete the delete to set
     */
    public void setDelete(String delete) {
        this.delete = delete;
    }

    /**
     * @return the kaijoIdReNoBtnFlg
     */
    public String getKaijoIdReNoBtnFlg() {
        return kaijoIdReNoBtnFlg;
    }

    /**
     * @param kaijoIdReNoBtnFlg the kaijoIdReNoBtnFlg to set
     */
    public void setKaijoIdReNoBtnFlg(String kaijoIdReNoBtnFlg) {
        this.kaijoIdReNoBtnFlg = kaijoIdReNoBtnFlg;
    }

    /**
     * @return the update
     */
    public String getUpdate() {
        return update;
    }

    /**
     * @param update the update to set
     */
    public void setUpdate(String update) {
        this.update = update;
    }

    /**
     * @return the shiyoKaijoSelect
     */
    public String[] getShiyoKaijoSelect() {
        return shiyoKaijoSelect;
    }

    /**
     * @param shiyoKaijoSelect the shiyoKaijoSelect to set
     */
    public void setShiyoKaijoSelect(String[] shiyoKaijoSelect) {
        this.shiyoKaijoSelect = shiyoKaijoSelect;
    }

    /**
     * @return the listNo
     */
    public String getListNo() {
        return listNo;
    }

    /**
     * @param listNo the listNo to set
     */
    public void setListNo(String listNo) {
        this.listNo = listNo;
    }

    /**
     * @return the tkyKsnKbn
     */
    public String getTkyKsnKbn() {
        return tkyKsnKbn;
    }

    /**
     * @param tkyKsnKbn the tkyKsnKbn to set
     */
    public void setTkyKsnKbn(String tkyKsnKbn) {
        this.tkyKsnKbn = tkyKsnKbn;
    }

    /**
     * @return the tkyAndKsnName
     */
    public String getTkyAndKsnName() {
        return tkyAndKsnName;
    }

    /**
     * @param tkyAndKsnName the tkyAndKsnName to set
     */
    public void setTkyAndKsnName(String tkyAndKsnName) {
        this.tkyAndKsnName = tkyAndKsnName;
    }

    /**
     * @return the tkyKsnName
     */
    public String getTkyKsnName() {
        return tkyKsnName;
    }

    /**
     * @param tkyKsnName the tkyKsnName to set
     */
    public void setTkyKsnName(String tkyKsnName) {
        this.tkyKsnName = tkyKsnName;
    }

    /**
     * @return the shiyoKaijoResultTokanList
     */
    public List<MstKanriShiyoKaijoJoho> getShiyoKaijoResultTokanList() {
        return shiyoKaijoResultTokanList;
    }

    /**
     * @param shiyoKaijoResultTokanList the shiyoKaijoResultTokanList to set
     */
    public void setShiyoKaijoResultTokanList(List<MstKanriShiyoKaijoJoho> shiyoKaijoResultTokanList) {
        this.shiyoKaijoResultTokanList = shiyoKaijoResultTokanList;
    }

    /**
     * @return the tokanKaijoCode
     */
    public String getTokanKaijoCode() {
        return tokanKaijoCode;
    }

    /**
     * @param tokanKaijoCode the tokanKaijoCode to set
     */
    public void setTokanKaijoCode(String tokanKaijoCode) {
        this.tokanKaijoCode = tokanKaijoCode;
    }

    /**
     * @return the kaijoByTantoshaList
     */
    public List<Option> getKaijoByTantoshaList() {
        return kaijoByTantoshaList;
    }

    /**
     * @param kaijoByTantoshaList the kaijoByTantoshaList to set
     */
    public void setKaijoByTantoshaList(List<Option> kaijoByTantoshaList) {
        this.kaijoByTantoshaList = kaijoByTantoshaList;
    }

    /**
     * @return the kaisaichiCodeKaijoMst
     */
    public String getKaisaichiCodeKaijoMst() {
        return kaisaichiCodeKaijoMst;
    }

    /**
     * @param kaisaichiCodeKaijoMst the kaisaichiCodeKaijoMst to set
     */
    public void setKaisaichiCodeKaijoMst(String kaisaichiCodeKaijoMst) {
        this.kaisaichiCodeKaijoMst = kaisaichiCodeKaijoMst;
    }
}
