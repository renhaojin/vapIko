package jp.co.nii.bma.business.service.manager;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.lang.reflect.InvocationTargetException;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import jp.co.nii.bma.business.domain.HanyoKensakuDtlOut;
import jp.co.nii.bma.business.domain.HanyoKensakuHedOut;
import jp.co.nii.bma.business.domain.HanyoKensakuOutMst;
import jp.co.nii.bma.business.domain.Saiban;
import jp.co.nii.bma.business.rto.manager.HanyouSearchJoho;
import jp.co.nii.bma.business.rto.manager.HanyouSelectJoho;
import jp.co.nii.bma.business.service.common.BmaConstants;
import jp.co.nii.bma.business.service.common.BmaLogger;
import jp.co.nii.bma.business.service.common.BmaSaibanService;
import jp.co.nii.bma.business.service.common.BmaValidator;
import jp.co.nii.bma.utility.BmaUtility;
import jp.co.nii.sew.business.SystemTime;
import jp.co.nii.sew.business.service.AbstractService;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_RELOAD;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_SESSION;
import jp.co.nii.sew.presentation.Messages;
import jp.co.nii.sew.presentation.Option;
import jp.co.nii.sew.presentation.RequestTransferObject;
import jp.co.nii.sew.utility.PropertyUtility;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

/**
 * <p>
 * �^�C�g��: �ėp�����I����ʃT�[�r�X</p>
 * <p>
 * ����: �ėp�����I����ʃT�[�r�X</p>
 * <p>
 * ���쌠: Copyright (c) 2020</p>
 * <p>
 * ��Ж�: ���{���Y�Ɗ������</p>
 */
public class HanyouSelectService extends AbstractService {

    /**
     * DB�ڑ��̃f�[�^�\�[�X
     */
    private static String DATA_SOURCE_NAME;
    /**
     * ���O
     */
    BmaLogger log = (BmaLogger) BmaLogger.getLogger(this.getClass().getName());
    /**
     * �Ɩ��R�[�h
     */
    private static final String BUSINESS_CODE = PropertyUtility.getProperty("business_code");

    /**
     * �R���X�g���N�^
     */
    public HanyouSelectService() {
        super();
        /* DB�ڑ����̃��[�U�[������ */
        DATA_SOURCE_NAME = BmaConstants.DS_REGISTRANT;
    }

    /**
     * �T�[�r�X�N���X�̎��s���\�b�h
     *
     * @param rto ���N�G�X�g��񂩂�擾����rto
     * @param rtoinSession �Z�b�V�������rto
     * @return foward��
     * @throws Exception ��O
     */
    @Override
    public String doService(RequestTransferObject rto, RequestTransferObject rtoinSession)
            throws Exception {

        HanyouSearchJoho inRequest = (HanyouSearchJoho) rto;
        HanyouSearchJoho inSession = (HanyouSearchJoho) rtoinSession;
        String processName = "";

        /*�G���[���b�Z�[�W������*/
        inSession.setErrors(new Messages());

        try {
            if (!BmaUtility.isNullOrEmpty(inRequest.getTempSave())) {
                /*�e���v���[�g�ۑ��{�^��������*/
                processName = "tempSave";
                log.Start(processName);

                String SearchChange = inRequest.getSearchChange();

                // ���̓f�[�^���Z�b�V�����f�[�^�ɃZ�b�g����
                setValueRequestToSession(inRequest, inSession);
                inSession.setUserId(inRequest.getUserId());

                inSession.setSrcTempNo(SearchChange);

                /*���̓`�F�b�N*/
                boolean retCheck = ValidatorInputSave(inRequest, inSession);
                // �o�͂��鍀��
                List<Option> listOut = createHanyoKensakuOutListFrmoGmen(inRequest, inSession);
                inSession.setHanyoKensakuOutList(listOut);
                // �o�͂��Ȃ����ڐݒ�
                setHanyoKensakuNoOutListGmen(inSession, listOut);

                // ��肪�Ȃ���� true
                if (retCheck) {
                    //�̔ԃf�[�^�擾
                    Saiban saiban = new BmaSaibanService(DATA_SOURCE_NAME).
                            getSaibanAndUpdateForKeta(BmaConstants.SAIBAN_HANYOKENSAKUHEDOUT_IDX, inSession.getUserId());

                    String hanyoKensakuIndex = "";
                    if (saiban != null) {
                        hanyoKensakuIndex = saiban.getGenzaiNo();
                    }

                    try {
                        //�g�����U�N�V�����J�n
                        getTransaction();
                        beginTransaction();

                        // �ėp�w�b�_�[�e�[�u���ɓo�^����
                        insertHanyoKensakuHedOut(inSession, hanyoKensakuIndex, inRequest);

                        // �ėp�ڍ׃e�[�u���ɓo�^����
                        insertAllDtl(inRequest, inSession, hanyoKensakuIndex);
                        commitTransaction();

                        Messages errors = new Messages();
                        BmaValidator.addMessage(errors, "info", "�ėp�����w�b�__�o��,�ڍ׃e�[�u���Ƀf�[�^��o�^���܂���", "");
                        inSession.setErrors(errors);

                    } catch (Exception e) {
                        rollbackTransaction();
                        log.info("�ėp�ڍ׃e�[�u�������ŗ�O������", e);
                    }
                    // �m�点������o���t���O
                    inSession.setSaveFlag("1");
                }
                /* ��ʕ\�� */
                return FWD_NM_RELOAD;
            } else if (!BmaUtility.isNullOrEmpty(inRequest.getSearchChange())
                    && BmaUtility.isNullOrEmpty(inRequest.getHayoBack())
                    && BmaUtility.isNullOrEmpty(inRequest.getExport())
                    && BmaUtility.isNullOrEmpty(inRequest.getTempSave())
                    && BmaUtility.isNullOrEmpty(inRequest.getTempUpdate())) {
                /*���ID�I��*/
                processName = "searchChange";
                log.Start(processName);

                inSession.setSaveFlag("");
                inSession.setSrcTempNo(inRequest.getSearchChange());

                // ���̓f�[�^���Z�b�V�����f�[�^�ɃZ�b�g����
                setValueRequestToSession(inRequest, inSession);

                inSession.setSearchChange(inRequest.getSearchChange());

                // �o�͂��鍀��
                List<Option> listOut = createHanyoKensakuOutList(inSession);
                inSession.setHanyoKensakuOutList(listOut);

                // �o�͂��Ȃ����ڐݒ�
                setHanyoKensakuNoOutListGmen(inSession, listOut);

                /* ��ʕ\�� */
                return FWD_NM_RELOAD;

            } else if (!BmaUtility.isNullOrEmpty(inRequest.getTempUpdate())) {
                /*�X�V�{�^��������*/
                processName = "tempUpdate";
                log.Start(processName);

                inSession.setSaveFlag("");
                inSession.setUserId(inRequest.getUserId());

                String SearchChange = inRequest.getSearchChange();
                inSession.setSrcTempNo(SearchChange);

                // ���̓f�[�^���Z�b�V�����f�[�^�ɃZ�b�g����
                setValueRequestToSession(inRequest, inSession);

                /*���̓`�F�b�N*/
                boolean retCheck = ValidatorInputSaveUpdate(inRequest, inSession);

                // �o�͂��鍀��
                List<Option> listOut = createHanyoKensakuOutListFrmoGmen(inRequest, inSession);
                inSession.setHanyoKensakuOutList(listOut);
                // �o�͂��Ȃ����ڐݒ�
                setHanyoKensakuNoOutListGmen(inSession, listOut);

                // ��肪�Ȃ���� true
                if (retCheck) {
                    String hanyoKensakuIndex = inRequest.getSearchChange();

                    try {
                        //�g�����U�N�V�����J�n
                        getTransaction();
                        beginTransaction();

                        // �ėp�ڍ׃e�[�u���ɍX�V����
                        updateAllDtl(inSession, hanyoKensakuIndex, inRequest);
                        commitTransaction();

                        Messages errors = new Messages();
                        BmaValidator.addMessage(errors, "info", "�ėp�����ڍ׃e�[�u���ɏ������X�V���܂���", "");
                        inSession.setErrors(errors);

                    } catch (Exception e) {
                        rollbackTransaction();
                        log.info("�ėp�ڍ׃e�[�u�������ŗ�O������", e);
                    }
                }
                /* �������ʈꗗ��ʕ\�� */
                return FWD_NM_RELOAD;
            } else if (!BmaUtility.isNullOrEmpty(inRequest.getHayoBack())) {

                inSession.setSaveFlag("");
                return FWD_NM_BACK;
            } else if (!BmaUtility.isNullOrEmpty(inRequest.getExport())) {
                /*�u�e���v���[�g�_�E�����[�h�v�{�^��������*/
                processName = "export";
                log.Start(processName);

                inSession.setSaveFlag("");
                /*���̓`�F�b�N*/
                boolean retCheck = ValidatorInputExport(inRequest, inSession);

                // ��肪�Ȃ���� true
                if (retCheck) {
                    // �e���v���[�gxcel�_�E�����[�h
                    hanyouExcelDownload(inRequest, inSession);

                    return DOWNLOAD;
                } else {

                    /* �������ʈꗗ��ʕ\�� */
                    return FWD_NM_RELOAD;
                }

            } else {
                /*�ُ�J��*/
                log.IllegalFWD();
                return FWD_NM_SESSION;
            }
        } catch (Exception e) {
            throw e;
        } finally {
            log.End(processName);
        }
    }

    /**
     * �o�͂��Ȃ����ڐݒ�
     *
     * @param inSession �Z�b�V�������
     */
    private void setHanyoKensakuNoOutListGmen(HanyouSearchJoho inSession, List<Option> listOut) {

        // �o�͂��Ȃ�����
        //List<Option> listNoOut = inSession.getHanyoKensakuNoOutList();
        List<Option> listNoOut = createHanyoKensakuNoOutList();
        inSession.setHanyoKensakuNoOutList(listOut);
        // �o�͂��Ȃ����ڂ��폜����
        List<Option> listAllOut = new ArrayList<>();
        for (int i = 0; i < listNoOut.size(); ++i) {
            Option moto = listNoOut.get(i);

            boolean addflg = true;
            for (int j = 0; j < listOut.size(); ++j) {
                Option saki = listOut.get(j);
                if (moto.getValue().equals(saki.getValue())) {
                    addflg = false;
                    break;
                }
            }
            if (addflg) {
                listAllOut.add(moto);
            }
        }
        // �o�͂��Ȃ����ڐݒ�
        inSession.setHanyoKensakuNoOutList(listAllOut);

    }


    /**
     * �����e���v���[�g���X�g�̍쐬
     *
     * @param inSession �Z�b�V�������
     */
    private List<Option> createHanyoKensakuOutListFrmoGmen(HanyouSearchJoho inRequest, HanyouSearchJoho inSession) {
        /* �ϐ������� */
        List<Option> list = new ArrayList<>();

        //String[] outputData = inRequest.getOutputData();
        String outputSelect = inRequest.getOutputSelect();
        String[] outputData = outputSelect.split(",");

        List<Option> listOut = createHanyoKensakuNoOutList();
        for (int i = 0; i < outputData.length; i++) {
            String komokuName = getKomokuName(outputData[i], listOut);
            list.add(new Option(outputData[i], komokuName));
        }
        return list;
    }

    /**
     * ���ږ��擾
     *
     * @param inSession �Z�b�V�������
     */
    private String getKomokuName(String val, List<Option> listOut) {
        String ret = "";
        if (BmaUtility.isNullOrEmpty(val)) {
            return ret;
        }
        for (Option option : listOut) {
            if (option.getValue().equals(val)) {
                ret = option.getLabel();
                break;
            }
        }
        return ret;
    }

    /**
     * �����e���v���[�g���X�g�̍쐬
     *
     * @param inSession �Z�b�V�������
     */
    private List<Option> createHanyoKensakuNoOutList() {
        /* �ϐ������� */
        List<Option> list = new ArrayList<>();
        HanyoKensakuOutMst hedOut = new HanyoKensakuOutMst(BmaConstants.DS_REGISTRANT);

        /* �����e���v���[�g���X�g���X�g��p�� */
        hedOut.findDtlOutMstList(list);
        return list;
    }

    /**
     * �����e���v���[�g���X�g�̍쐬
     *
     * @param inSession �Z�b�V�������
     */
    private List<Option> createHanyoKensakuOutList(HanyouSearchJoho inSession) {
        /* �ϐ������� */
        List<Option> list = new ArrayList<>();
        HanyoKensakuHedOut hedOut = new HanyoKensakuHedOut(BmaConstants.DS_REGISTRANT);

        /* �����e���v���[�g���X�g���X�g��p�� */
        hedOut.findDtlOutHeadDtlList(list, inSession);
        return list;
    }

    /**
     * �e���v���[�gxcel�_�E�����[�h
     */
    private void hanyouExcelDownload(HanyouSearchJoho inRequest, HanyouSearchJoho inSession) throws Exception {

        String fileName;

        fileName = BmaConstants.HANYOU_DATA + ".xlsm";

        String path;
        path = BmaConstants.EXCEL_TEMP_DIRECTORY;
        File file = new File(path + fileName);
        //�e���v���[�g�t�@�C�����擾
        InputStream inputStream = new FileInputStream(file);
        //���[�N�u�b�N�𐶐�
        Workbook wb = WorkbookFactory.create(inputStream);

        //�e���v���[�g�V�[�g���R�s�[
        Sheet sheet = wb.getSheetAt(0);
        //String[] outputData = inRequest.getOutputData();
        String outputSelect = inRequest.getOutputSelect();
        String[] outputData = outputSelect.split(",");

        HanyoKensakuOutMst hedOut = new HanyoKensakuOutMst(BmaConstants.DS_REGISTRANT);
        List<HanyouSelectJoho> allList = hedOut.findDtlAllList(inSession);

        Row row1 = sheet.createRow(0);
        HanyouSelectJoho SelectOneTmp = allList.get(0);
        //  ��ʂ̑I��l���DB�̃��R�[�h���o��
        for (int ii = 0; ii < outputData.length; ii++) {
            String rtn = getSelectValue(outputData[ii], SelectOneTmp);
            String[] out = rtn.split(",");
            if (out.length == 2) {
                row1.createCell(ii).setCellValue(out[1]);
            }
        }

        // �f�[�^���o�͂���
        for (int j = 0; j < allList.size(); j++) {
            HanyouSelectJoho SelectOne = allList.get(j);
            Row row = sheet.createRow(j + 1);
            //  ��ʂ̑I��l���DB�̃��R�[�h���o��
            for (int i = 0; i < outputData.length; i++) {
                String rtn = getSelectValue(outputData[i], SelectOne);
                String[] out = rtn.split(",");
                if (out.length == 2) {
                    row.createCell(i).setCellValue(out[0]);
                }
            }
        }

        Date date = new Date();
        SimpleDateFormat dt = new SimpleDateFormat("yyyyMMdd");
        SimpleDateFormat tm = new SimpleDateFormat("HHmmss");
        String koshinDate = dt.format(date);
        String koshinTime = tm.format(date);

        String fileNameOut = BmaConstants.HANYOU_DATA + "_" + koshinDate + koshinTime + ".xlsm";
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        wb.write(out);

        byte[] barray = out.toByteArray();
        InputStream is = new ByteArrayInputStream(barray);
        out.close();

        inRequest.setInputStream(is);
        inRequest.setHeader(path, path);

        inRequest.setHeader("Content-Type", "charset=UTF-8");
        inRequest.setHeader("Content-Disposition",
                "attachment;filename=\"" + URLEncoder.encode(fileNameOut, BmaConstants.ENCODE_UTF_8) + "\"");
        inRequest.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
    }

    /**
     * ��ʂ̑I��l���DB�̃��R�[�h���o�́B
     *
     * @param selectVal
     * @param SelectOne
     */
    private String getSelectValue(String selectVal, HanyouSelectJoho SelectOne) {
        String rtnVal = "";

        selectVal = "," + selectVal;
        if (SelectOne.getBirthday().contains(selectVal)) {
            rtnVal = SelectOne.getBirthday();
        }
        if (SelectOne.getFurigana().contains(selectVal)) {
            rtnVal = SelectOne.getFurigana();
        }
        if (SelectOne.getFax_no().contains(selectVal)) {
            rtnVal = SelectOne.getFax_no();
        }
        if (SelectOne.getGaiji_flg_nm().contains(selectVal)) {
            rtnVal = SelectOne.getGaiji_flg_nm();
        }
        if (SelectOne.getGaiji_shosai().contains(selectVal)) {
            rtnVal = SelectOne.getGaiji_shosai();
        }
        if (SelectOne.getGenmen_nm().contains(selectVal)) {
            rtnVal = SelectOne.getGenmen_nm();
        }
        if (SelectOne.getGohi_jokyo_nm().contains(selectVal)) {
            rtnVal = SelectOne.getGohi_jokyo_nm();
        }
        if (SelectOne.getGokaku_bi().contains(selectVal)) {
            rtnVal = SelectOne.getGokaku_bi();
        }
        if (SelectOne.getGokaku_no().contains(selectVal)) {
            rtnVal = SelectOne.getGokaku_no();
        }
        if (SelectOne.getGoukaku_no_gakka().contains(selectVal)) {
            rtnVal = SelectOne.getGoukaku_no_gakka();
        }
        if (SelectOne.getGoukaku_no_jitsugi().contains(selectVal)) {
            rtnVal = SelectOne.getGoukaku_no_jitsugi();
        }
        if (SelectOne.getHairyo_flg_nm().contains(selectVal)) {
            rtnVal = SelectOne.getHairyo_flg_nm();
        }
        if (SelectOne.getHairyo_naiyo().contains(selectVal)) {
            rtnVal = SelectOne.getHairyo_naiyo();
        }
        if (SelectOne.getJuken_juko_no().contains(selectVal)) {
            rtnVal = SelectOne.getJuken_juko_no();
        }
        if (SelectOne.getJusho_1().contains(selectVal)) {
            rtnVal = SelectOne.getJusho_1();
        }
        if (SelectOne.getJusho_2().contains(selectVal)) {
            rtnVal = SelectOne.getJusho_2();
        }
        if (SelectOne.getKaiin_kbn_nm().contains(selectVal)) {
            rtnVal = SelectOne.getKaiin_kbn_nm();
        }
        if (SelectOne.getKaiin_shinsei_nm().contains(selectVal)) {
            rtnVal = SelectOne.getKaiin_shinsei_nm();
        }
        if (SelectOne.getKaijo_nm_1().contains(selectVal)) {
            rtnVal = SelectOne.getKaijo_nm_1();
        }
        if (SelectOne.getKaijo_nm_2().contains(selectVal)) {
            rtnVal = SelectOne.getKaijo_nm_2();
        }
        if (SelectOne.getKaisaichi_nm_1().contains(selectVal)) {
            rtnVal = SelectOne.getKaisaichi_nm_1();
        }
        if (SelectOne.getKaisaichi_nm_2().contains(selectVal)) {
            rtnVal = SelectOne.getKaisaichi_nm_2();
        }
        if (SelectOne.getKaisu_code().contains(selectVal)) {
            rtnVal = SelectOne.getKaisu_code();
        }
        if (SelectOne.getKanri_memo().contains(selectVal)) {
            rtnVal = SelectOne.getKanri_memo();
        }
        if (SelectOne.getKessai_bng().contains(selectVal)) {
            rtnVal = SelectOne.getKessai_bng();
        }
        if (SelectOne.getKessai_date().contains(selectVal)) {
            rtnVal = SelectOne.getKessai_date();
        }
        if (SelectOne.getKessai_hoho_nm().contains(selectVal)) {
            rtnVal = SelectOne.getKessai_hoho_nm();
        }
        if (SelectOne.getKessai_kingaku().contains(selectVal)) {
            rtnVal = SelectOne.getKessai_kingaku();
        }
        if (SelectOne.getKessai_kingaku_total().contains(selectVal)) {
            rtnVal = SelectOne.getKessai_kingaku_total();
        }
        if (SelectOne.getKessai_tesuryo().contains(selectVal)) {
            rtnVal = SelectOne.getKessai_tesuryo();
        }
        if (SelectOne.getKessai_time().contains(selectVal)) {
            rtnVal = SelectOne.getKessai_time();
        }
        if (SelectOne.getKigyo_code().contains(selectVal)) {
            rtnVal = SelectOne.getKigyo_code();
        }
        if (SelectOne.getKigyo_hp_url().contains(selectVal)) {
            rtnVal = SelectOne.getKigyo_hp_url();
        }
        if (SelectOne.getKinmusaki_fax_no().contains(selectVal)) {
            rtnVal = SelectOne.getKinmusaki_fax_no();
        }
        if (SelectOne.getKinmusaki_jusho_1().contains(selectVal)) {
            rtnVal = SelectOne.getKinmusaki_jusho_1();
        }
        if (SelectOne.getKinmusaki_jusho_2().contains(selectVal)) {
            rtnVal = SelectOne.getKinmusaki_jusho_2();
        }
        if (SelectOne.getKinmusaki_tatemono().contains(selectVal)) {
            rtnVal = SelectOne.getKinmusaki_tatemono();
        }
        if (SelectOne.getKinmusaki_tel_no().contains(selectVal)) {
            rtnVal = SelectOne.getKinmusaki_tel_no();
        }
        if (SelectOne.getKinmusaki_todofuken_nm().contains(selectVal)) {
            rtnVal = SelectOne.getKinmusaki_todofuken_nm();

        }
        if (SelectOne.getKinmusaki_yubin_no().contains(selectVal)) {
            rtnVal = SelectOne.getKinmusaki_yubin_no();
        }
        if (SelectOne.getKojin_dantai_nm().contains(selectVal)) {
            rtnVal = SelectOne.getKojin_dantai_nm();
        }
        if (SelectOne.getKyokai_name().contains(selectVal)) {
            rtnVal = SelectOne.getKyokai_name();
        }
        if (SelectOne.getMail_address().contains(selectVal)) {
            rtnVal = SelectOne.getMail_address();
        }
        if (SelectOne.getMoshikomi_jokyo_nm().contains(selectVal)) {
            rtnVal = SelectOne.getMoshikomi_jokyo_nm();
        }
        if (SelectOne.getMoshikomi_nm().contains(selectVal)) {
            rtnVal = SelectOne.getMoshikomi_nm();
        }
        if (SelectOne.getMuryo_zan_count().contains(selectVal)) {
            rtnVal = SelectOne.getMuryo_zan_count();
        }
        if (SelectOne.getNendo().contains(selectVal)) {
            rtnVal = SelectOne.getNendo();
        }
        if (SelectOne.getNenrei().contains(selectVal)) {
            rtnVal = SelectOne.getNenrei();
        }
        if (SelectOne.getSex_nm().contains(selectVal)) {
            rtnVal = SelectOne.getSex_nm();
        }
        if (SelectOne.getShiken_naiyo_nm().contains(selectVal)) {
            rtnVal = SelectOne.getShiken_naiyo_nm();
        }
        if (SelectOne.getShimei().contains(selectVal)) {
            rtnVal = SelectOne.getShimei();
        }
        if (SelectOne.getShubetsu_name().contains(selectVal)) {
            rtnVal = SelectOne.getShubetsu_name();
        }
        if (SelectOne.getSkn_ksu_nm().contains(selectVal)) {
            rtnVal = SelectOne.getSkn_ksu_nm();
        }
        if (SelectOne.getSofu_saki_nm().contains(selectVal)) {
            rtnVal = SelectOne.getSofu_saki_nm();
        }
        if (SelectOne.getTatemono().contains(selectVal)) {
            rtnVal = SelectOne.getTatemono();
        }
        if (SelectOne.getTel_no().contains(selectVal)) {
            rtnVal = SelectOne.getTel_no();
        }
        if (SelectOne.getTodofuken_nm().contains(selectVal)) {
            rtnVal = SelectOne.getTodofuken_nm();

        }
        if (SelectOne.getUketsuke_no().contains(selectVal)) {
            rtnVal = SelectOne.getUketsuke_no();
        }
        if (SelectOne.getYubin_no().contains(selectVal)) {
            rtnVal = SelectOne.getYubin_no();
        }
        if (SelectOne.getYuko_kigen_menjo().contains(selectVal)) {
            rtnVal = SelectOne.getYuko_kigen_menjo();
        }
        if (SelectOne.getYuko_kigen_shikaku().contains(selectVal)) {
            rtnVal = SelectOne.getYuko_kigen_shikaku();
        }
        return rtnVal;
    }

    /**
     * �ėp�w�b�_�[�e�[�u���ɓo�^����B
     *
     * @param inSession ���N�G�X�g
     * @param hanyoKensakuIdOut
     */
    public void insertHanyoKensakuHedOut(HanyouSearchJoho inSession, String hanyoKensakuIdOut, HanyouSearchJoho inRequest) {
        String userId = inSession.getUserId();

        SystemTime sysTim = new SystemTime();

        //���[���e���v���[�g�@�I�u�W�F�N�g�쐬
        HanyoKensakuHedOut kensakuHedOutJoho = new HanyoKensakuHedOut(DATA_SOURCE_NAME);

        kensakuHedOutJoho.setHanyoKensakuIdOut(hanyoKensakuIdOut);

        // �ėp������
        String hanyoKensakuName = inRequest.getTempletSave();
        kensakuHedOutJoho.setHanyoKensakuName(hanyoKensakuName);

        //�_���폜�t���O���Z�b�g
        kensakuHedOutJoho.setRonriSakujoFlg(BmaConstants.FLG_OFF);
        //�����敪
        kensakuHedOutJoho.setKoshinKbn(BmaConstants.SHORI_KBN_INSERT);

        //�o�^�����E�o�^��
        kensakuHedOutJoho.setTorokuDate(sysTim.getymd1());
        kensakuHedOutJoho.setTorokuTime(sysTim.gethms1());

        kensakuHedOutJoho.setTorokuUserId(userId);

        //�X�V�����E�X�V��
        kensakuHedOutJoho.setKoshinDate(sysTim.getymd1());
        kensakuHedOutJoho.setKoshinTime(sysTim.gethms1());
        kensakuHedOutJoho.setKoshinUserId(userId);

        //�o�^
        kensakuHedOutJoho.create();
    }

    /**
     * �ėp�ڍ׃e�[�u���ɓo�^����B
     *
     * @param search ���N�G�X�g
     *
     * @return �����ꍇ�Ftrue;���s�Ffalse
     */
    private void insertAllDtl(HanyouSearchJoho inRequest, HanyouSearchJoho search, String hanyoKensakuIndex) {
        //String[] outputData = inRequest.getOutputData();
        String outputSelect = inRequest.getOutputSelect();
        String[] outputData = outputSelect.split(",");

        if (outputData != null) {
            for (int i = 0; i < outputData.length; i++) {
                if (search.getSknksuKbn().equals(BmaConstants.SKN_KBN)
                        || search.getSknksuKbn().equals(BmaConstants.KSU_KBN)) {
                    insertOneLineDtlOut(search, hanyoKensakuIndex, i + 1, outputData[i]);
                }
            }
        }
    }

    /**
     * �ėp�ڍ׃e�[�u���Ɉ�s�f�[�^��o�^����B
     *
     * @param inSession ���N�G�X�g
     * @param hanyoKensakuIdOut
     * @param meisaiGyoNo
     * @param jokenKomokuId
     */
    public void insertOneLineDtlOut(HanyouSearchJoho inSession, String hanyoKensakuIdOut,
            int meisaiGyoNo, String jokenKomokuId) {

        String userId = inSession.getUserId();
        if (userId == null) {
            userId = "";
        }
        SystemTime sysTim = new SystemTime();

        //���[���e���v���[�g�@�I�u�W�F�N�g�쐬
        HanyoKensakuDtlOut kensakuDtlOutJoho = new HanyoKensakuDtlOut(DATA_SOURCE_NAME);

        kensakuDtlOutJoho.setHanyoKensakuIdOut(hanyoKensakuIdOut);

        kensakuDtlOutJoho.setMeisaiGyoNo(String.valueOf(meisaiGyoNo));
        kensakuDtlOutJoho.setViwClmNameJkn(jokenKomokuId);

        //�_���폜�t���O���Z�b�g
        kensakuDtlOutJoho.setRonriSakujoFlg(BmaConstants.FLG_OFF);
        //�����敪
        kensakuDtlOutJoho.setKoshinKbn(BmaConstants.SHORI_KBN_INSERT);

        //�o�^�����E�o�^��
        kensakuDtlOutJoho.setTorokuDate(sysTim.getymd1());
        kensakuDtlOutJoho.setTorokuTime(sysTim.gethms1());

        kensakuDtlOutJoho.setTorokuUserId(userId);

        //�X�V�����E�X�V��
        kensakuDtlOutJoho.setKoshinDate(sysTim.getymd1());
        kensakuDtlOutJoho.setKoshinTime(sysTim.gethms1());
        kensakuDtlOutJoho.setKoshinUserId(userId);

        //�o�^
        kensakuDtlOutJoho.create();
    }

    /**
     * �ėp�ڍ׃e�[�u���ɓo�^����B
     *
     * @param search ���N�G�X�g
     *
     * @return �����ꍇ�Ftrue;���s�Ffalse
     */
    private void updateAllDtl(HanyouSearchJoho search, String hanyoKensakuIndex, HanyouSearchJoho inRequest) throws Exception {

        try {
            //String[] outputData = inRequest.getOutputData();
            String outputSelect = inRequest.getOutputSelect();
            String[] outputData = outputSelect.split(",");

            //���[���e���v���[�g�@�I�u�W�F�N�g�쐬
            HanyoKensakuDtlOut kensakuDtl = new HanyoKensakuDtlOut(DATA_SOURCE_NAME);

            kensakuDtl.deleteByKensakuId(hanyoKensakuIndex);

            if (outputData != null) {
                for (int i = 0; i < outputData.length; i++) {
                    if (search.getSknksuKbn().equals(BmaConstants.SKN_KBN) || search.getSknksuKbn().equals(BmaConstants.KSU_KBN)) {
                        updateOneLineDtlOut(search, hanyoKensakuIndex, i + 1, outputData[i]);
                    }
                }
            }
        } catch (Exception ex) {
            throw ex;
        }
    }

    /**
     * �ėp�ڍ׃e�[�u���Ɉ�s�f�[�^���X�V����B
     *
     * @param inSession ���N�G�X�g
     * @param hanyoKensakuIdOut
     * @param meisaiGyoNo
     * @param jokenKomokuId
     * @throws java.lang.IllegalAccessException
     * @throws java.lang.reflect.InvocationTargetException
     */
    public void updateOneLineDtlOut(HanyouSearchJoho inSession, String hanyoKensakuIdOut,
            int meisaiGyoNo, String jokenKomokuId) throws IllegalAccessException, InvocationTargetException {

        //���[���e���v���[�g�@�I�u�W�F�N�g�쐬
        HanyoKensakuDtlOut kensakuDtl = new HanyoKensakuDtlOut(DATA_SOURCE_NAME);
        /* �X�V�ł���f�[�^�擾 */
        HanyoKensakuDtlOut kensakuDtlOutJohoMoto = kensakuDtl.find(hanyoKensakuIdOut, String.valueOf(meisaiGyoNo));
        if (kensakuDtlOutJohoMoto == null) {
            insertOneLineDtlOut(inSession, hanyoKensakuIdOut, meisaiGyoNo, jokenKomokuId);
        }
    }

    /**
     * ���̓f�[�^���Z�b�V�����f�[�^�ɃZ�b�g����B
     *
     * @param inRequest ���N�G�X�g��̓��̓f�[�^
     * @param inSession �Z�b�V������̓��̓f�[�^
     */
    private void setValueRequestToSession(HanyouSearchJoho inRequest, HanyouSearchJoho inSession) {
        // �ėp������
        inSession.setTempletSave(inRequest.getTempletSave());
    }

    /**
     * ���̓`�F�b�N
     *
     * @param inRequest
     * @return ��肪�Ȃ���� true�A����� false
     */
    private boolean ValidatorInputSave(HanyouSearchJoho inRequest, HanyouSearchJoho inSession) {
        String groupCode = "";
        String itemName = "";

        //���b�Z�[�W�i�[�p
        Messages errors = new Messages();

        groupCode = "";
        itemName = "�o�͂��鍀��";
        // �o�͂��鍀�ځF�K�{�`�F�b�N

        //String[] outputData = inRequest.getOutputData();
        String outputSelect = inRequest.getOutputSelect();
        String[] outputData = outputSelect.split(",");
        if (outputData == null || outputSelect.isEmpty()) {
            BmaValidator.validateSelect("", errors, groupCode, itemName);
        }

        // ���ڃe���v���[�g�V�K�ۑ���
        itemName = "���ڃe���v���[�g�V�K�ۑ���";
        // ���ڃe���v���[�g�V�K�ۑ��F�K�{�`�F�b�N
        String hanyoKensakuName = inRequest.getTempletSave();
        BmaValidator.validateRequired(hanyoKensakuName, errors, groupCode, itemName);

        if (!errors.isEmpty()) {
            inSession.setErrors(errors);
            return false;
        } else {
            return true;
        }
    }

    /**
     * ���̓`�F�b�N
     *
     * @param inRequest
     * @return ��肪�Ȃ���� true�A����� false
     */
    private boolean ValidatorInputExport(HanyouSearchJoho inRequest, HanyouSearchJoho inSession) {
        String groupCode = "";
        String itemName = "";

        //���b�Z�[�W�i�[�p
        Messages errors = new Messages();

        groupCode = "";
        itemName = "�o�͂��鍀��";
        // �o�͂��鍀�ځF�K�{�`�F�b�N

        //String[] outputData = inRequest.getOutputData();
        String outputSelect = inRequest.getOutputSelect();
        String[] outputData = outputSelect.split(",");
        if (outputData == null || outputSelect.isEmpty()) {
            BmaValidator.validateSelect("", errors, groupCode, itemName);
        }

        groupCode = "";
        String path;
        path = BmaConstants.EXCEL_TEMP_DIRECTORY;
        File file = new File(path + BmaConstants.HANYOU_DATA + ".xlsm");
        if (!file.exists()) {
            BmaValidator.addMessage(errors, groupCode, "�e���v���[�g" + file + "�����݂��Ȃ��B", "");
        }
        if (!errors.isEmpty()) {
            inSession.setErrors(errors);
            return false;
        } else {
            return true;
        }
    }

    /**
     * ���̓`�F�b�N
     *
     * @param inRequest
     * @return ��肪�Ȃ���� true�A����� false
     */
    private boolean ValidatorInputSaveUpdate(HanyouSearchJoho inRequest, HanyouSearchJoho inSession) {
        String groupCode = "";
        String itemName = "";

        //���b�Z�[�W�i�[�p
        Messages errors = new Messages();

        groupCode = "";
        itemName = "�o�͂��鍀��";
        // �o�͂��鍀�ځF�K�{�`�F�b�N

        //String[] outputData = inRequest.getOutputData();
        String outputSelect = inRequest.getOutputSelect();
        String[] outputData = outputSelect.split(",");
        if (outputData == null || outputSelect.isEmpty()) {
            BmaValidator.validateSelect("", errors, groupCode, itemName);
        }

        // ���ڃe���v���[�g��
        itemName = "���ڃe���v���[�g��";
        // �����ڃe���v���[�g�F�K�{�`�F�b�N
        String hanyoKensakuName = inRequest.getSearchChange().replace("�I��", "");
        BmaValidator.validateSelect(hanyoKensakuName, errors, groupCode, itemName);

        if (!errors.isEmpty()) {
            inSession.setErrors(errors);
            return false;
        } else {
            return true;
        }
    }

}
