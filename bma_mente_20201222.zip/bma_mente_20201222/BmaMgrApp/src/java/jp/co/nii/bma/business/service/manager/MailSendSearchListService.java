package jp.co.nii.bma.business.service.manager;

import java.io.BufferedWriter;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import jp.co.nii.bma.business.domain.MailTemplate;
import jp.co.nii.bma.business.rto.manager.MgrMailJoho;
import jp.co.nii.bma.business.service.common.BmaConstants;
import jp.co.nii.bma.business.service.common.BmaLogger;
import jp.co.nii.bma.business.service.common.BmaValidator;
import jp.co.nii.bma.presentation.common.BmaText;
import jp.co.nii.bma.utility.BmaUtility;
import jp.co.nii.sew.business.service.AbstractService;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_SESSION;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_SUCCESS;
import jp.co.nii.sew.presentation.Messages;
import jp.co.nii.sew.presentation.RequestTransferObject;
import jp.co.nii.sew.utility.PropertyUtility;

/**
 * <p>
 * �^�C�g��: ���[��������ʃT�[�r�X</p>
 * <p>
 * ����: ���[��������ʃT�[�r�X</p>
 * <p>
 * ���쌠: Copyright (c) 2020</p>
 * <p>
 * ��Ж�: ���{���Y�Ɗ������</p>
 */
public class MailSendSearchListService extends AbstractService {

    /**
     * DB�ڑ��̃f�[�^�\�[�X
     */
    private static String DATA_SOURCE_NAME;
    /**
     * ���O
     */
    BmaLogger log = (BmaLogger) BmaLogger.getLogger(this.getClass().getName());
    /**
     * �Ɩ��R�[�h
     */
    private static final String BUSINESS_CODE = PropertyUtility.getProperty("business_code");
    /**
     * ���׃e�X�g���[�h
     */
    private static final String STRESS_MODE = PropertyUtility.getProperty(BUSINESS_CODE + "stress_mode");

    /**
     * �R���X�g���N�^
     */
    public MailSendSearchListService() {
        super();
        /* DB�ڑ����̃��[�U�[������ */
        DATA_SOURCE_NAME = BmaConstants.DS_REGISTRANT;
    }

    /**
     * �T�[�r�X�N���X�̎��s���\�b�h
     *
     * @param rto ���N�G�X�g��񂩂�擾����rto
     * @param rtoInSession �Z�b�V�������rto
     * @return foward��
     * @throws Exception ��O
     */
    @Override
    public String doService(RequestTransferObject rto, RequestTransferObject rtoInSession)
            throws Exception {

        MgrMailJoho inRequest = (MgrMailJoho) rto;
        MgrMailJoho inSession = (MgrMailJoho) rtoInSession;
        String processName = "";

        /*�G���[���b�Z�[�W������*/
        inSession.setErrors(new Messages());
        try {
            if (!BmaUtility.isNullOrEmpty(inRequest.getSearchKekkaListConfilm())) {
                /*�m�F�{�^��������*/
                processName = "searchKekkaListConfilm";
                log.Start(processName);
                //�G���[������ꍇ�Acsv�f�[�^���_�E�����[�h
                if (!inSession.getErrorLog().isEmpty()) {
                    createCsvLog(inRequest, inSession);
                    log.error("���[���Ǘ��f�[�^�A�b�v���[�h�@�G���[���O�o��");

                    return DOWNLOAD;
                } else {

                    /*���̓f�[�^�Z�b�g*/
                    setValueRequestToSession(inRequest, inSession);

                    List<MgrMailJoho> list = inSession.getMailSendlList();
                    String[] chkList = inRequest.getChkTaishoChoice();

                    if (chkList == null) {
                        Messages errors = new Messages();
                        // ���[���A�h���X��I�����Ă�������
                        BmaValidator.addMessage(errors, "info", BmaText.M00035, "");

                        inSession.setErrors(errors);
                        return FWD_NM_RELOAD;
                    }

                    List<MgrMailJoho> newList = (new ArrayList<>());
                    int count = 0;
                    for (int i = 0; i < list.size(); i++) {
                        MgrMailJoho detail = new MgrMailJoho();
                        if (Arrays.asList(chkList).contains(String.valueOf(i))) {

                            detail.setUketukeNo(list.get(i).getUketukeNo());
                            detail.setSimei(list.get(i).getSimei());
                            detail.setMailaddress(list.get(i).getMailaddress());

                            detail.setCheckFlg(BmaConstants.FLG_ON);

                            newList.add(i, detail);
                            count = count + 1;
                        } else {
                            detail.setUketukeNo(list.get(i).getUketukeNo());
                            detail.setSimei(list.get(i).getSimei());
                            detail.setMailaddress(list.get(i).getMailaddress());

                            detail.setCheckFlg(BmaConstants.FLG_OFF);

                            newList.add(i, detail);
                        }
                    }
                    String mailIndex = inRequest.getSrcTempNo();

                    inSession.setSrcTempNo(mailIndex);

                    //���[���e���v���[�g�擾
                    MailTemplate template = new MailTemplate(DATA_SOURCE_NAME);
                    MailTemplate find = template.find(mailIndex);

                    if (find != null) {
                        inSession.setTmpMailId(find.getMailTemplateIdx());
                        inSession.setKenName(find.getMailKenmei()
                                .replace("\r\n", "\n").replace("\r", "\n").replace("\n", "<br>"));
                        inSession.setTmpName(find.getMailTemplateName()
                                .replace("\r\n", "\n").replace("\r", "\n").replace("\n", "<br>"));

                        inSession.setTmpHonbun(find.getMailHonbun()
                                .replace("\r\n", "\n").replace("\r", "\n").replace("\n", "<br>"));
                        inSession.setTmpFutter(find.getMailFooter()
                                .replace("\r\n", "\n").replace("\r", "\n").replace("\n", "<br>"));

                    }

                    String ninn = String.valueOf(count + "��");

                    inSession.setMailSoshinTaisho(ninn);
                    inSession.setMailSendlList(newList);

                    inSession.setChkTaishoChoice(inRequest.getChkTaishoChoice());

                    return FWD_NM_SUCCESS;
                }
            } else if (!BmaUtility.isNullOrEmpty(inRequest.getSearchKekkaListBack())) {
                /*�߂�{�^��������*/
                processName = "searchKekkaListBack";
                log.Start(processName);

                inSession.setTmpFutter("");
                /* ������ʕ\�� */
                return FWD_NM_BACK;
            } else if (!BmaUtility.isNullOrEmpty(inRequest.getCommandPage())) {
                /*�y�[�W�J��*/
                processName = "setPage";
                log.Start(processName);

                String[] chkList = inRequest.getChkTaishoChoice();

                List<MgrMailJoho> tmp1 = inRequest.getMailSendlList();
                List<MgrMailJoho> tmp2 = inSession.getMailSendlList();

                inSession.setPage(Integer.parseInt(inRequest.getCommandPage()));

                MailIkkatsuSendUploadService mail = new MailIkkatsuSendUploadService();

                inSession.setChkList(chkList);

                mail.pageIndex(inSession, inRequest, inSession.getCsvDataList());

                return FWD_NM_RELOAD;
            } else {
                /*�ُ�J��*/
                log.IllegalFWD();
                return FWD_NM_SESSION;
            }
        } catch (Exception e) {
            throw e;
        } finally {
            log.End(processName);
        }

    }

    /**
     * ���̓f�[�^���Z�b�V�����f�[�^�ɃZ�b�g����B
     *
     * @param inRequest ���N�G�X�g��̓��̓f�[�^
     * @param inSession �Z�b�V������̓��̓f�[�^
     */
    private void setValueRequestToSession(MgrMailJoho inRequest, MgrMailJoho inSession) {
        inSession.setSrcTempNo(inRequest.getSrcTempNo());

        //inSession.setMailSendlList(inRequest.getMailSendlList());
    }

    /**
     * �t�@�C����Csv�`����LOG���o��
     *
     * @param inSession
     */
    private void createCsvLog(MgrMailJoho inRequest, MgrMailJoho inSession) throws IOException {
        Date date = new Date();

        SimpleDateFormat dt = new SimpleDateFormat("yyyyMMdd");
        SimpleDateFormat tm = new SimpleDateFormat("HHmmss");
        String koshinDate = dt.format(date);
        String koshinTime = tm.format(date);

        String fileName = "�e���v���[�g" + "_" + koshinDate + koshinTime + ".csv";
        // �w�b�_�[����
        inRequest.setHeader("Content-Disposition", String.format(Locale.JAPAN, "attachment; filename*=utf-8'jp'%s", URLEncoder.encode(fileName, "utf-8")));
        inRequest.setContentType("application/octet-stream;charset=" + BmaConstants.ENCODE_SHIFT_JIS);
        BufferedWriter bw = null;
        ByteArrayOutputStream outputStream = null;

        try {
            // �X�g���[������
            outputStream = new ByteArrayOutputStream();
            bw = new BufferedWriter(new OutputStreamWriter(outputStream, BmaConstants.ENCODE_SHIFT_JIS));

            for (int i = 0; i < inSession.getErrorLog().size(); i++) {
                if (i == 0) {
                    bw.write("�s�ԍ�");
                    bw.write(",");
                    bw.write("��ԍ�");
                    bw.write(",");
                    bw.write("���ږ�");
                    bw.write(",");
                    bw.write("�G���[���b�Z�[�W");
                    bw.write(",");
                    bw.write("\r\n");
                    bw.write(inSession.getErrorLog().get(i).getLineNo());
                    bw.write(",");
                    bw.write(inSession.getErrorLog().get(i).getColumnNo());
                    bw.write(",");
                    bw.write(inSession.getErrorLog().get(i).getItemName());
                    bw.write(",");
                    bw.write(inSession.getErrorLog().get(i).getMessage());
                    bw.write("\r\n");
                } else {
                    bw.write(inSession.getErrorLog().get(i).getLineNo());
                    bw.write(",");
                    bw.write(inSession.getErrorLog().get(i).getColumnNo());
                    bw.write(",");
                    bw.write(inSession.getErrorLog().get(i).getItemName());
                    bw.write(",");
                    bw.write(inSession.getErrorLog().get(i).getMessage());
                    bw.write("\r\n");
                }
            }
            bw.flush();
        } catch (Exception e) {
            log.error("CSV�o�͏����ŃG���[���������܂����B", e);
        } finally {
            if (bw != null) {
                bw.close();
            }
        }

        InputStream io = new ByteArrayInputStream(outputStream.toByteArray());
        inRequest.setInputStream(io);
        inRequest.setHeader("Content-Type", "charset=" + BmaConstants.ENCODE_SHIFT_JIS);
        inRequest.setContentType("text/csv; charset=" + BmaConstants.ENCODE_SHIFT_JIS);

    }
}
