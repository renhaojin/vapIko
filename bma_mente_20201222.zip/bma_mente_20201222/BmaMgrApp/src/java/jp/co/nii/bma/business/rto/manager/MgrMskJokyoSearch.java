package jp.co.nii.bma.business.rto.manager;

import java.util.List;
import java.util.ArrayList;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import jp.co.nii.sew.presentation.AbstractRequestTransferObject;
import jp.co.nii.sew.presentation.Messages;
import jp.co.nii.sew.presentation.Option;
import jp.co.nii.sew.utility.StringUtility;
import jp.co.nii.bma.business.service.common.BmaConstants;
import jp.co.nii.sew.presentation.DownloadRTO;

/**
 *
 * @author
 */
public class MgrMskJokyoSearch extends DownloadRTO {

    ////////////////////////////////////////////
    //�����i�[����t�B�[���h�E���\�b�h
    ////////////////////////////////////////////
    /**
     * ������ރR�[�h
     */
    private String shikenShuruiCode;

    //�����p
    /**
     * �\�����@�N�@�J�n
     */
    private String searchFromMoshikomibiYear;
    /**
     * �\�����@���@�J�n
     */
    private String searchFromMoshikomibiMonth;
    /**
     * �\�����@���@�J�n
     */
    private String searchFromMoshikomibiDay;
    /**
     * �\�����@���@�J�n
     */
    private String searchFromMoshikomibiHour;
    /**
     * �\�����@�N�@�I��
     */
    private String searchToMoshikomibiYear;
    /**
     * �\�����@���@�I��
     */
    private String searchToMoshikomibiMonth;
    /**
     * �\�����@���@�I��
     */
    private String searchToMoshikomibiDay;
    /**
     * �\�����@���@�I��
     */
    private String searchToMoshikomibiHour;
    /**
     * �\���P��
     */
    private String searchHyojiTani;
    /**
     * �N���W�b�g�J�[�h���ρi��t�ρj
     */
    private String searchCrejitKessaiFlg;
    /**
     * �R���r�j�G���X�X�g�A���ρi��t�ρj
     */
    private String searchConveniKessaiZumiFlg;
    /**
     * �R���r�j�G���X�X�g�A���ρi�����m�F�҂��j
     */
    private String searchConveniKessaiMachiFlg;
    /**
     * ���ϖ��I��
     */
    private String searchKessaiMisentakuFlg;
    /**
     * �󌱕��@
     */
    private String searchJukenHouho;
    /**
     * ���Z���s�s���{��
     */
    private String searchGenjyushoTodoufuken;
    /**
     * ���Z���s�s���{��
     */
    private String searchOrderBy;

    /**
     * �W�v���f���t
     */
    private String shukeiHaneiDate;

    //���X�g
    /**
     * ��������
     */
    private ArrayList<MgrMskJokyoSearchList> searchList;
    /**
     * �\���p�N���X�g
     */
    private List<Option> yearDisp;
    /**
     * �\���p�����X�g
     */
    private List<Option> monthDisp;
    /**
     * �\���p�����X�g
     */
    private List<Option> dayDisp;
    /**
     * �\���p�����X�g
     */
    private List<Option> hourDisp;
    /**
     * �\���p�\���P�ʃ��X�g
     */
    private List<Option> hyojiTaniDisp;
    /**
     * �\���p�󌱕��@���X�g
     */
    private List<Option> jukenHouhoDisp;
    /**
     * �\���p���Z���s�s���{�����X�g
     */
    private List<Option> genjyushoTodoufukenDisp;
    /**
     * ���я����X�g
     */
    private List<Option> orderByDisp;

    //�{�^��
    /**
     * �R�}���h �Ǘ��҃��j���[:�󌱐\���󋵌���
     */
    private String commandSideBarInit;
    /**
     * �R�}���h �����������͉��:�����{�^��
     */
    private String commandSearch;
    /**
     * �R�}���h �����������͉��:���̓N���A�{�^��
     */
    private String commandClear;
    /**
     * �R�}���h �������ʉ��:�������͉�ʂ֖߂�{�^��
     */
    private String commandSearchListBack;
    /**
     * �R�}���h �������ʉ��:CSV�o�̓{�^��
     */
    private String commandCsvOutput;
    /**
     * �R�}���h �������ʉ��:���я��ύX
     */
    private String commandOrderBy;
    /**
     * �R�}���h �������ʉ��:�O�y�[�W�{�^��
     */
    private String commandSearchListBefore;
    /**
     * �R�}���h �������ʉ��:���y�[�W�{�^��
     */
    private String commandSearchListNext;
    /**
     * �R�}���h �������ʉ��:�y�[�W�w��{�^��
     */
    private String commandSearchListPage;
    /**
     * �y�[�W�ԍ�
     */
    private String page;
    /**
     * ���y�[�W��
     */
    private int pageCount;
    /**
     * ������
     */
    private int count;
    /**
     * �\�����錏���̊J�n�ʒu
     */
    private int indexFrom;
    /**
     * �\�����錏���̏I���ʒu
     */
    private int indexTo;
    /**
     * �\������y�[�W���[�̐擪�̃y�[�W��
     */
    private int pagerBegin;
    /**
     * �\������y�[�W���[�̍Ō�̃y�[�W��
     */
    private int pagerEnd;

    ///////////////////////
    //�R���X�g���N�^
    ///////////////////////
    public MgrMskJokyoSearch() {
        this.clearInfo();
    }

    /**
     * ���ׂĂ̍��ڃ��Z�b�g
     */
    public void clearInfo() {

        //�����p
        this.setSearchFromMoshikomibiYear("");
        this.setSearchFromMoshikomibiMonth("");
        this.setSearchFromMoshikomibiDay("");
        this.setSearchFromMoshikomibiHour("");
        this.setSearchToMoshikomibiYear("");
        this.setSearchToMoshikomibiMonth("");
        this.setSearchToMoshikomibiDay("");
        this.setSearchToMoshikomibiHour("");
        this.setSearchHyojiTani("");
        this.setSearchCrejitKessaiFlg("");
        this.setSearchConveniKessaiZumiFlg("");
        this.setSearchConveniKessaiMachiFlg("");
        this.setSearchKessaiMisentakuFlg("");
        this.setSearchJukenHouho("");
        this.setSearchGenjyushoTodoufuken("");
        this.setSearchOrderBy("");
 
        //�R�}���h
        this.setCommandSideBarInit("");
        this.setCommandSearch("");
        this.setCommandClear("");
        this.setCommandSearchListBack("");
        this.setCommandCsvOutput("");
        this.setCommandOrderBy("");
        this.setCommandSearchListBefore("");
        this.setCommandSearchListNext("");
        this.setCommandSearchListPage("");

        this.setPage("");
        this.setPageCount(0);
        this.setCount(0);
        this.setIndexFrom(0);
        this.setIndexTo(0);
        this.pagerBegin = 0;
        this.pagerEnd = 0;
        //�G���[�ӏ��\���p
        this.setErrors(new Messages());
    }

    /**
     * �e�l�̃X�y�[�X���폜����
     */
    public void deleteSpace() {
        this.setSearchFromMoshikomibiYear(StringUtility.removeEdgeSpace(getSearchFromMoshikomibiYear()));
        this.setSearchFromMoshikomibiMonth(StringUtility.removeEdgeSpace(getSearchFromMoshikomibiMonth()));
        this.setSearchFromMoshikomibiDay(StringUtility.removeEdgeSpace(getSearchFromMoshikomibiDay()));
        this.setSearchFromMoshikomibiHour(StringUtility.removeEdgeSpace(getSearchFromMoshikomibiHour()));
        this.setSearchToMoshikomibiYear(StringUtility.removeEdgeSpace(getSearchToMoshikomibiYear()));
        this.setSearchToMoshikomibiMonth(StringUtility.removeEdgeSpace(getSearchToMoshikomibiMonth()));
        this.setSearchToMoshikomibiDay(StringUtility.removeEdgeSpace(getSearchToMoshikomibiDay()));
        this.setSearchToMoshikomibiHour(StringUtility.removeEdgeSpace(getSearchToMoshikomibiHour()));
        this.setSearchHyojiTani(StringUtility.removeEdgeSpace(getSearchHyojiTani()));
        this.setSearchCrejitKessaiFlg(StringUtility.removeEdgeSpace(getSearchCrejitKessaiFlg()));
        this.setSearchConveniKessaiZumiFlg(StringUtility.removeEdgeSpace(getSearchConveniKessaiZumiFlg()));
        this.setSearchConveniKessaiMachiFlg(StringUtility.removeEdgeSpace(getSearchConveniKessaiMachiFlg()));
        this.setSearchKessaiMisentakuFlg(StringUtility.removeEdgeSpace(getSearchKessaiMisentakuFlg()));
        this.setSearchJukenHouho(StringUtility.removeEdgeSpace(getSearchJukenHouho()));
        this.setSearchGenjyushoTodoufuken(StringUtility.removeEdgeSpace(getSearchGenjyushoTodoufuken()));
    }

    /**
     * ���N�G�X�g�Z�b�V������������擾
     *
     * @param request
     */
    @Override
    public void copyFromRequest(HttpServletRequest request) {

        //�����p
        setSearchFromMoshikomibiYear((String) request.getAttribute("searchFromMoshikomibiYear"));
        setSearchFromMoshikomibiMonth((String) request.getAttribute("searchFromMoshikomibiMonth"));
        setSearchFromMoshikomibiDay((String) request.getAttribute("searchFromMoshikomibiDay"));
        setSearchFromMoshikomibiHour((String) request.getAttribute("searchFromMoshikomibiHour"));
        setSearchToMoshikomibiYear((String) request.getAttribute("searchToMoshikomibiYear"));
        setSearchToMoshikomibiMonth((String) request.getAttribute("searchToMoshikomibiMonth"));
        setSearchToMoshikomibiDay((String) request.getAttribute("searchToMoshikomibiDay"));
        setSearchToMoshikomibiHour((String) request.getAttribute("searchToMoshikomibiHour"));
        setSearchHyojiTani((String) request.getAttribute("searchHyojiTani"));
        setSearchCrejitKessaiFlg((String) request.getAttribute("searchCrejitKessaiFlg"));
        setSearchConveniKessaiZumiFlg((String) request.getAttribute("searchConveniKessaiZumiFlg"));
        setSearchConveniKessaiMachiFlg((String) request.getAttribute("searchConveniKessaiMachiFlg"));
        setSearchKessaiMisentakuFlg((String) request.getAttribute("searchKessaiMisentakuFlg"));
        setSearchJukenHouho((String) request.getAttribute("searchJukenHouho"));
        setSearchGenjyushoTodoufuken((String) request.getAttribute("searchGenjyushoTodoufuken"));
        setSearchOrderBy((String) request.getAttribute("searchOrderBy"));

        //�R�}���h
        setCommandSideBarInit((String) request.getAttribute("commandSideBarInit"));
        setCommandSearch((String) request.getAttribute("commandSearch"));
        setCommandClear((String) request.getAttribute("commandClear"));
        setCommandSearchListBack((String) request.getAttribute("commandSearchListBack"));
        setCommandCsvOutput((String) request.getAttribute("commandCsvOutput"));
        setCommandOrderBy((String) request.getAttribute("commandOrderBy"));
        setCommandSearchListBefore((String) request.getAttribute("commandSearchListBefore"));
        setCommandSearchListNext((String) request.getAttribute("commandSearchListNext"));
        setCommandSearchListPage((String) request.getAttribute("commandSearchListPage"));
        
        setPage((String) request.getAttribute("page"));

        HttpSession session = request.getSession(false);
        if(session.getAttribute("MgrLoginJoho") != null){
            MgrLoginJoho lg = (MgrLoginJoho)session.getAttribute("MgrLoginJoho");
            setShikenShuruiCode(lg.getCommandShikenshubetsu());
        }
    }
    /**
     * �G���[���b�Z�[�W
     */
    private Messages errors;

    /**
     * @return the errors
     */
    public Messages getErrors() {
        return errors;
    }

    /**
     * @param errors the errors to set
     */
    public void setErrors(Messages errors) {
        this.errors = errors;
    }

    /**
     * ����ȏꍇ�A�G���[�̏ꍇ��CSS��Ԃ�
     *
     * @return
     */

    //getter,setter

    /**
     * ������ރR�[�h
     *
     * @return the shikenShuruiCode
     */
    public String getShikenShuruiCode() {
        return shikenShuruiCode;
    }

    /**
     * ������ރR�[�h
     *
     * @param shikenShuruiCode the shikenShuruiCode to set
     */
    public void setShikenShuruiCode(String shikenShuruiCode) {
        this.shikenShuruiCode = shikenShuruiCode;
    }

    /**
     * @return the searchFromMoshikomibiYear
     */
    public String getSearchFromMoshikomibiYear() {
        return searchFromMoshikomibiYear;
    }

    /**
     * @param searchFromMoshikomibiYear the searchFromMoshikomibiYear to set
     */
    public void setSearchFromMoshikomibiYear(String searchFromMoshikomibiYear) {
        this.searchFromMoshikomibiYear = searchFromMoshikomibiYear;
    }

    /**
     * @return the searchFromMoshikomibiMonth
     */
    public String getSearchFromMoshikomibiMonth() {
        return searchFromMoshikomibiMonth;
    }

    /**
     * @param searchFromMoshikomibiMonth the searchFromMoshikomibiMonth to set
     */
    public void setSearchFromMoshikomibiMonth(String searchFromMoshikomibiMonth) {
        this.searchFromMoshikomibiMonth = searchFromMoshikomibiMonth;
    }

    /**
     * @return the searchFromMoshikomibiDay
     */
    public String getSearchFromMoshikomibiDay() {
        return searchFromMoshikomibiDay;
    }

    /**
     * @param searchFromMoshikomibiDay the searchFromMoshikomibiDay to set
     */
    public void setSearchFromMoshikomibiDay(String searchFromMoshikomibiDay) {
        this.searchFromMoshikomibiDay = searchFromMoshikomibiDay;
    }
    
    /**
     * @return the searchFromMoshikomibiHour
     */
    public String getSearchFromMoshikomibiHour() {
        return searchFromMoshikomibiHour;
    }

    /**
     * @param searchFromMoshikomibiHour the searchFromMoshikomibiHour to set
     */
    public void setSearchFromMoshikomibiHour(String searchFromMoshikomibiHour) {
        this.searchFromMoshikomibiHour = searchFromMoshikomibiHour;
    }
    
    /**
     * @return the searchToMoshikomibiYear
     */
    public String getSearchToMoshikomibiYear() {
        return searchToMoshikomibiYear;
    }

    /**
     * @param searchToMoshikomibiYear the searchToMoshikomibiYear to set
     */
    public void setSearchToMoshikomibiYear(String searchToMoshikomibiYear) {
        this.searchToMoshikomibiYear = searchToMoshikomibiYear;
    }

    /**
     * @return the searchToMoshikomibiMonth
     */
    public String getSearchToMoshikomibiMonth() {
        return searchToMoshikomibiMonth;
    }

    /**
     * @param searchToMoshikomibiMonth the searchToMoshikomibiMonth to set
     */
    public void setSearchToMoshikomibiMonth(String searchToMoshikomibiMonth) {
        this.searchToMoshikomibiMonth = searchToMoshikomibiMonth;
    }

    /**
     * @return the searchToMoshikomibiDay
     */
    public String getSearchToMoshikomibiDay() {
        return searchToMoshikomibiDay;
    }

    /**
     * @param searchToMoshikomibiDay the searchToMoshikomibiDay to set
     */
    public void setSearchToMoshikomibiDay(String searchToMoshikomibiDay) {
        this.searchToMoshikomibiDay = searchToMoshikomibiDay;
    }
    
    /**
     * @return the searchToMoshikomibiHour
     */
    public String getSearchToMoshikomibiHour() {
        return searchToMoshikomibiHour;
    }

    /**
     * @param searchToMoshikomibiHour the searchToMoshikomibiHour to set
     */
    public void setSearchToMoshikomibiHour(String searchToMoshikomibiHour) {
        this.searchToMoshikomibiHour = searchToMoshikomibiHour;
    }
    
    /**
     * @return the searchHyojiTani
     */
    public String getSearchHyojiTani() {
        return searchHyojiTani;
    }

    /**
     * @param searchHyojiTani the searchHyojiTani to set
     */
    public void setSearchHyojiTani(String searchHyojiTani) {
        this.searchHyojiTani = searchHyojiTani;
    }
    
    /**
     * @return the searchCrejitKessaiFlg
     */
    public String getSearchCrejitKessaiFlg() {
        return searchCrejitKessaiFlg;
    }

    /**
     * @param searchCrejitKessaiFlg the searchCrejitKessaiFlg to set
     */
    public void setSearchCrejitKessaiFlg(String searchCrejitKessaiFlg) {
        this.searchCrejitKessaiFlg = searchCrejitKessaiFlg;
    }

    /**
     * 
     *
     * @return the searchCrejitKessaiFlg
     */
    public boolean isCrejitKessaiFlgOn() {
        return BmaConstants.FLG_ON.equals(this.searchCrejitKessaiFlg);
    }

    /**
     * @return the searchConveniKessaiZumiFlg
     */
    public String getSearchConveniKessaiZumiFlg() {
        return searchConveniKessaiZumiFlg;
    }

    /**
     * @param searchConveniKessaiZumiFlg the searchConveniKessaiZumiFlg to set
     */
    public void setSearchConveniKessaiZumiFlg(String searchConveniKessaiZumiFlg) {
        this.searchConveniKessaiZumiFlg = searchConveniKessaiZumiFlg;
    }

    /**
     * 
     *
     * @return the searchConveniKessaiZumiFlg
     */
    public boolean isConveniKessaiZumiFlgOn() {
        return BmaConstants.FLG_ON.equals(this.searchConveniKessaiZumiFlg);
    }

    /**
     * @return the searchConveniKessaiMachiFlg
     */
    public String getSearchConveniKessaiMachiFlg() {
        return searchConveniKessaiMachiFlg;
    }

    /**
     * @param searchConveniKessaiMachiFlg the searchConveniKessaiMachiFlg to set
     */
    public void setSearchConveniKessaiMachiFlg(String searchConveniKessaiMachiFlg) {
        this.searchConveniKessaiMachiFlg = searchConveniKessaiMachiFlg;
    }
    
    /**
     * 
     *
     * @return the searchConveniKessaiMachiFlg
     */
    public boolean isConveniKessaiMachiFlgOn() {
        return BmaConstants.FLG_ON.equals(this.searchConveniKessaiMachiFlg);
    }

        /**
     * @return the searchKessaiMisentakuFlg
     */
    public String getSearchKessaiMisentakuFlg() {
        return searchKessaiMisentakuFlg;
    }

    /**
     * @param searchKessaiMisentakuFlg the searchKessaiMisentakuFlg to set
     */
    public void setSearchKessaiMisentakuFlg(String searchKessaiMisentakuFlg) {
        this.searchKessaiMisentakuFlg = searchKessaiMisentakuFlg;
    }
    
    /**
     * @return the searchKessaiMisentakuFlg
     */
    public boolean isKessaiMisentakuFlgOn() {
        return BmaConstants.FLG_ON.equals(this.searchKessaiMisentakuFlg);
    }

    /**
     * @return the searchJukenHouho
     */
    public String getSearchJukenHouho() {
        return searchJukenHouho;
    }

    /**
     * @param searchJukenHouho the searchJukenHouho to set
     */
    public void setSearchJukenHouho(String searchJukenHouho) {
        this.searchJukenHouho = searchJukenHouho;
    }
    
    /**
     * @return the searchGenjyushoTodoufuken
     */
    public String getSearchGenjyushoTodoufuken() {
        return searchGenjyushoTodoufuken;
    }

    /**
     * @param searchGenjyushoTodoufuken the searchGenjyushoTodoufuken to set
     */
    public void setSearchGenjyushoTodoufuken(String searchGenjyushoTodoufuken) {
        this.searchGenjyushoTodoufuken = searchGenjyushoTodoufuken;
    }
    
    /**
     * @return the searchOrderBy
     */
    public String getSearchOrderBy() {
        return searchOrderBy;
    }

    /**
     * @param searchOrderBy the searchOrderBy to set
     */
    public void setSearchOrderBy(String searchOrderBy) {
        this.searchOrderBy = searchOrderBy;
    }

    /**
     * �W�v���f���t
     *
     * @return the shukeiHaneiDate
     */
    public String getShukeiHaneiDate() {
        return shukeiHaneiDate;
    }

    /**
     * �W�v���f���t
     *
     * @param shukeiHaneiDate the shukeiHaneiDate to set
     */
    public void setShukeiHaneiDate(String shukeiHaneiDate) {
        this.shukeiHaneiDate = shukeiHaneiDate;
    }

    /**
     * @return the searchList
     */
    public ArrayList<MgrMskJokyoSearchList> getSearchList() {
        return searchList;
    }

    /**
     * @param searchList the searchList to set
     */
    public void setSearchList(ArrayList<MgrMskJokyoSearchList> searchList) {
        this.searchList = searchList;
    }

    /**
     * @return the yearDisp
     */
    public List<Option> getYearDisp() {
        return yearDisp;
    }

    /**
     * @param yearDisp the yearDisp to set
     */
    public void setYearDisp(List<Option> yearDisp) {
        this.yearDisp = yearDisp;
    }

    /**
     * @return the monthDisp
     */
    public List<Option> getMonthDisp() {
        return monthDisp;
    }

    /**
     * @param monthDisp the monthDisp to set
     */
    public void setMonthDisp(List<Option> monthDisp) {
        this.monthDisp = monthDisp;
    }

    /**
     * @return the dayDisp
     */
    public List<Option> getDayDisp() {
        return dayDisp;
    }

    /**
     * @param dayDisp the dayDisp to set
     */
    public void setDayDisp(List<Option> dayDisp) {
        this.dayDisp = dayDisp;
    }

    /**
     * @return the hourDisp
     */
    public List<Option> getHourDisp() {
        return hourDisp;
    }

    /**
     * @param hourDisp the hourDisp to set
     */
    public void setHourDisp(List<Option> hourDisp) {
        this.hourDisp = hourDisp;
    }

    /**
     * @return the hyojiTaniDisp
     */
    public List<Option> getHyojiTaniDisp() {
        return hyojiTaniDisp;
    }

    /**
     * @param hyojiTaniDisp the hyojiTaniDisp to set
     */
    public void setHyojiTaniDisp(List<Option> hyojiTaniDisp) {
        this.hyojiTaniDisp = hyojiTaniDisp;
    }

    /**
     * @return the jukenHouhoDisp
     */
    public List<Option> getJukenHouhoDisp() {
        return jukenHouhoDisp;
    }

    /**
     * @param jukenHouhoDisp the jukenHouhoDisp to set
     */
    public void setJukenHouhoDisp(List<Option> jukenHouhoDisp) {
        this.jukenHouhoDisp = jukenHouhoDisp;
    }

    /**
     * @return the genjyushoTodoufukenDisp
     */
    public List<Option> getGenjyushoTodoufukenDisp() {
        return genjyushoTodoufukenDisp;
    }

    /**
     * @param genjyushoTodoufukenDisp the genjyushoTodoufukenDisp to set
     */
    public void setGenjyushoTodoufukenDisp(List<Option> genjyushoTodoufukenDisp) {
        this.genjyushoTodoufukenDisp = genjyushoTodoufukenDisp;
    }

    /**
     * @return the orderByDisp
     */
    public List<Option> getOrderByDisp() {
        return orderByDisp;
    }

    /**
     * @param orderByDisp the orderByDisp to set
     */
    public void setOrderByDisp(List<Option> orderByDisp) {
        this.orderByDisp = orderByDisp;
    }

    /**
     * @return the commandSideBarInit
     */
    public String getCommandSideBarInit() {
        return commandSideBarInit;
    }

    /**
     * @param commandSideBarInit the commandSideBarInit to set
     */
    public void setCommandSideBarInit(String commandSideBarInit) {
        this.commandSideBarInit = commandSideBarInit;
    }

    /**
     * @return the commandSearch
     */
    public String getCommandSearch() {
        return commandSearch;
    }

    /**
     * @param commandSearch the commandSearch to set
     */
    public void setCommandSearch(String commandSearch) {
        this.commandSearch = commandSearch;
    }

    /**
     * @return the commandClear
     */
    public String getCommandClear() {
        return commandClear;
    }

    /**
     * @param commandClear the commandClear to set
     */
    public void setCommandClear(String commandClear) {
        this.commandClear = commandClear;
    }

    /**
     * @return the commandSearchListBack
     */
    public String getCommandSearchListBack() {
        return commandSearchListBack;
    }

    /**
     * @param commandSearchListBack the commandSearchListBack to set
     */
    public void setCommandSearchListBack(String commandSearchListBack) {
        this.commandSearchListBack = commandSearchListBack;
    }

    /**
     * @return the commandCsvOutput
     */
    public String getCommandCsvOutput() {
        return commandCsvOutput;
    }

    /**
     * @param commandCsvOutput the commandCsvOutput to set
     */
    public void setCommandCsvOutput(String commandCsvOutput) {
        this.commandCsvOutput = commandCsvOutput;
    }

    /**
     * @return the commandOrderBy
     */
    public String getCommandOrderBy() {
        return commandOrderBy;
    }

    /**
     * @param commandOrderBy the commandOrderBy to set
     */
    public void setCommandOrderBy(String commandOrderBy) {
        this.commandOrderBy = commandOrderBy;
    }

    /**
     * @return the commandSearchListBefore
     */
    public String getCommandSearchListBefore() {
        return commandSearchListBefore;
    }

    /**
     * @param commandSearchListBefore the commandSearchListBefore to set
     */
    public void setCommandSearchListBefore(String commandSearchListBefore) {
        this.commandSearchListBefore = commandSearchListBefore;
    }

    /**
     * @return the commandSearchListNext
     */
    public String getCommandSearchListNext() {
        return commandSearchListNext;
    }

    /**
     * @param commandSearchListNext the commandSearchListNext to set
     */
    public void setCommandSearchListNext(String commandSearchListNext) {
        this.commandSearchListNext = commandSearchListNext;
    }

    /**
     * @return the commandSearchListPage
     */
    public String getCommandSearchListPage() {
        return commandSearchListPage;
    }

    /**
     * @param commandSearchListPage the commandSearchListPage to set
     */
    public void setCommandSearchListPage(String commandSearchListPage) {
        this.commandSearchListPage = commandSearchListPage;
    }


    /**
     * @return the nowPage
     */
    public String getPage() {
        return page;
    }

    /**
     * @param nowPage the nowPage to set
     */
    public void setPage(String page) {
        this.page = page;
    }

    /**
     * @return the totalHit
     */
    public Integer getPageCount() {
        return pageCount;
    }

    /**
     * @param totalHit the totalHit to set
     */
    public void setPageCount(Integer pageCount) {
        this.pageCount = pageCount;
    }

    /**
     * @return the count
     */
    public int getCount() {
        return count;
    }

    /**
     * @param count the count to set
     */
    public void setCount(int count) {
        this.count = count;
    }

    /**
     * @return the indexFrom
     */
    public int getIndexFrom() {
        return indexFrom;
    }

    /**
     * @param indexFrom the indexFrom to set
     */
    public void setIndexFrom(int indexFrom) {
        this.indexFrom = indexFrom;
    }

    /**
     * @return the indexTo
     */
    public int getIndexTo() {
        return indexTo;
    }

    /**
     * @param indexTo the indexTo to set
     */
    public void setIndexTo(int indexTo) {
        this.indexTo = indexTo;
    }
    
    /**
     * @return the pagerBegin
     */
    public int getPagerBegin() {
        return pagerBegin;
    }

    /**
     * @param pagerBegin the pagerBegin to set
     */
    public void setPagerBegin(int pagerBegin) {
        this.pagerBegin = pagerBegin;
    }
    
    /**
     * @return the pagerEnd
     */
    public int getPagerEnd() {
        return pagerEnd;
    }

    /**
     * @param pagerEnd the pagerEnd to set
     */
    public void setPagerEnd(int pagerEnd) {
        this.pagerEnd = pagerEnd;
    }

}
