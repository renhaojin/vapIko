package jp.co.nii.bma.business.service.manager;

import jp.co.nii.bma.business.rto.manager.MgrLoginJoho;
import jp.co.nii.bma.business.service.common.BmaConstants;
import jp.co.nii.bma.business.service.common.BmaLogger;
import jp.co.nii.sew.business.service.AbstractService;
import jp.co.nii.sew.presentation.RequestTransferObject;

/**
 * Document : MypageLoginService Created on : 2016/08/02, 09:29:32 Author :
 * H.Matsutaka
 */
public class MgrLogoutService extends AbstractService {

    /**
     * DB�ڑ��̃f�[�^�\�[�X
     */
    private static String DATA_SOURCE_NAME;
    /**
     * ���O
     */
    BmaLogger log = (BmaLogger) BmaLogger.getLogger(this.getClass().getName());

    public MgrLogoutService() {
        super();
        /* DB�ڑ����̃��[�U�[������ */
        DATA_SOURCE_NAME = BmaConstants.DS_REGISTRANT;
    }

    @Override
    public String doService(RequestTransferObject rto, RequestTransferObject rtoInSession)
            throws Exception {

        MgrLoginJoho MypageLogoutInRequest = (MgrLoginJoho) rto;
        MgrLoginJoho MypageLogoutInSession = (MgrLoginJoho) rtoInSession;

        ////////////////////////
        //���O�A�E�g��ʂ�
        ////////////////////////

        /* �J�n���O */
        log.Start("MgrLogout");

        log.info("���O�A�E�g�����@�Ǘ���ID:" + MypageLogoutInSession.getKanrisha_Id());

        /* �������O */
        log.End("MgrLogout");

        return FWD_NM_SUCCESS;

    }
}
