package jp.co.nii.bma.business.service.manager;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import jp.co.nii.bma.business.domain.KaijoMst;
import jp.co.nii.bma.business.domain.KaijoTantoMst;
import jp.co.nii.bma.business.domain.ShiyoKaijo;
import jp.co.nii.bma.business.rto.manager.MstKanriShiyoKaijoJoho;
import jp.co.nii.bma.business.service.common.BmaConstants;
import jp.co.nii.bma.business.service.common.BmaLogger;
import jp.co.nii.bma.business.service.common.BmaValidator;
import static jp.co.nii.bma.business.service.manager.MstKanriShiyoKaijoShinkiInputService.dateToWeek;
import jp.co.nii.bma.presentation.common.BmaText;
import jp.co.nii.bma.utility.BmaUtility;
import jp.co.nii.sew.business.SystemTime;
import jp.co.nii.sew.business.service.AbstractService;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_BACK;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_EXCEPTION;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_SESSION;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_SUCCESS;
import jp.co.nii.sew.presentation.Messages;
import jp.co.nii.sew.presentation.Option;
import jp.co.nii.sew.presentation.RequestTransferObject;
import jp.co.nii.sew.utility.PropertyUtility;

/**
 *
 * @author nii19049
 */
public class MstKanriShiyoKaijoShinkiConfirmService extends AbstractService {

    /**
     * DB�ڑ��̃f�[�^�\�[�X
     */
    private static String DATA_SOURCE_NAME;
    /**
     * ���O
     */
    BmaLogger log = (BmaLogger) BmaLogger.getLogger(this.getClass().getName());
    /**
     * �Ɩ��R�[�h
     */
    private static final String BUSINESS_CODE = PropertyUtility.getProperty("business_code");
    /**
     * ���׃e�X�g���[�h
     */
    private static final String STRESS_MODE = PropertyUtility.getProperty(BUSINESS_CODE + "stress_mode");

    /**
     * �R���X�g���N�^
     */
    public MstKanriShiyoKaijoShinkiConfirmService() {
        super();
        /* DB�ڑ����̃��[�U�[������ */
        DATA_SOURCE_NAME = BmaConstants.DS_REGISTRANT;
    }

    /**
     * �T�[�r�X�N���X�̎��s���\�b�h
     *
     * @param rto ���N�G�X�g��񂩂�擾����rto
     * @param rtoInSession �Z�b�V�������rto
     * @return foward��
     * @throws Exception ��O
     */
    @Override
    public String doService(RequestTransferObject rto, RequestTransferObject rtoInSession)
            throws Exception {

        MstKanriShiyoKaijoJoho inRequest = (MstKanriShiyoKaijoJoho) rto;
        MstKanriShiyoKaijoJoho inSession = (MstKanriShiyoKaijoJoho) rtoInSession;
        String processName = "";

        /*�G���[���b�Z�[�W������*/
        inSession.setErrors(new Messages());
        try {
            if (!BmaUtility.isNullOrEmpty(inRequest.getShiyoKaijoShinkiConf())) {
                /*�u�g�p���V�K�o�^�m�F�v��ʑJ�ڎ�*/
                processName = "MstKanriShiyoKaijoShinkiConfirm";
                log.Start(processName);

                
                /* �u�g�p���V�K�o�^�m�F�v��ʕ\�� */
                return FWD_NM_SUCCESS;

            } else if (!BmaUtility.isNullOrEmpty(inRequest.getNext())) {
                /*�u�m��v�{�^��������*/
                processName = "MstKanriShiyoKaijoShinkiConfirm";
                log.Start(processName);
                
                /* ��L�[�擾 */
                ShiyoKaijo shiyoKaijoInp = new ShiyoKaijo(DATA_SOURCE_NAME);
                ShiyoKaijo shiyoKaijoDel = new ShiyoKaijo(DATA_SOURCE_NAME);
                String nendo = inSession.getNendo();
                String sknKsuCode = inSession.getSknKsuCode();
                String shubetsuCode = inSession.getShubetsuCode();
                String kaisuCode = inSession.getKaisuCode();

                /* ���͒l�`�F�b�N */
                if(!validateInput(inSession.getShiyoKaijoUpdateList(), inSession)){
                    // �G���[���������ꍇ�u���}�X�^�V�K�o�^�m�F�v���Reload
                    return FWD_NM_SUCCESS;
                } else {
                    try{
                    /* �g�����U�N�V�����擾&�J�n */
                    getTransaction();
                    beginTransaction();
                    
                    // �O�N�x���폜
//                    List<MstKanriShiyoKaijoJoho> deleteList =  shiyoKaijoDel.searchShiyoKaijoList(inSession.getNendoBefore(),sknKsuCode,shubetsuCode,kaisuCode);
//                    for(MstKanriShiyoKaijoJoho shiyoKaijo : deleteList){
//                        shiyoKaijoDel.setNendo(inSession.getNendoBefore());
//                        shiyoKaijoDel.setSknKsuCode(shiyoKaijo.getSknKsuCode());
//                        shiyoKaijoDel.setShubetsuCode(shiyoKaijo.getShubetsuCode());
//                        shiyoKaijoDel.setKaisuCode(shiyoKaijo.getKaisuCode());
//                        shiyoKaijoDel.setKaijoId(shiyoKaijo.getKaijoId());
//                        shiyoKaijoDel.setKaijoShikenKbn(shiyoKaijo.getKaijoShikenKbn());
//                        shiyoKaijoDel.setKaisaichiCode(shiyoKaijo.getKaisaichiCode());
//                        shiyoKaijoDel.setKaijoCode(shiyoKaijo.getKaijoCode());
//                        
//                        shiyoKaijoDel.remove();
//                    }
//                    
                    // ���N�x��S���o�^
                    for(MstKanriShiyoKaijoJoho shiyoKaijo : inSession.getShiyoKaijoUpdateList()){

                    /* �V�X�e���������擾 */
                    SystemTime sysTime = new SystemTime();

                    /* �o�^�����g�p���ɃZ�b�g */
                    shiyoKaijoInp.setNendo(nendo);
                    shiyoKaijoInp.setSknKsuCode(sknKsuCode);
                    shiyoKaijoInp.setShubetsuCode(shubetsuCode);
                    shiyoKaijoInp.setKaisuCode(kaisuCode);
                    shiyoKaijoInp.setKaijoId(shiyoKaijo.getKaijoId());
                    shiyoKaijoInp.setKaijoShikenKbn(shiyoKaijo.getKaijoShikenKbn());
                    shiyoKaijoInp.setKaisaichiCode(shiyoKaijo.getKaisaichiCode());
                    shiyoKaijoInp.setKaijoCode(shiyoKaijo.getKaijoCode());
                    shiyoKaijoInp.setKaijoName(shiyoKaijo.getKaijoName());
                    shiyoKaijoInp.setKaijoNameRyaku(shiyoKaijo.getKaijoNameRyaku());
                    shiyoKaijoInp.setTantoshaCode(shiyoKaijo.getTantoshaCode());
                    shiyoKaijoInp.setNitteiFrom(shiyoKaijo.getNitteiFrom());
                    shiyoKaijoInp.setNitteiTo(shiyoKaijo.getNitteiTo());
                    shiyoKaijoInp.setTeiin(shiyoKaijo.getTeiin());
                    shiyoKaijoInp.setGenzaiNinzu("0");
                    
                    // ���}�X�^����K�v�ȏ����擾
                    KaijoMst kaijoM = new KaijoMst(DATA_SOURCE_NAME);
                    KaijoMst kaijo = kaijoM.kaijoJohoForShiyoKaijo(shiyoKaijo.getKaisaichiCode(),shiyoKaijo.getKaijoCode());
                    shiyoKaijoInp.setYubinNo(kaijo.getYubinNo());
                    shiyoKaijoInp.setJusho(kaijo.getJusho());
                    shiyoKaijoInp.setBikoKaijo(kaijo.getBiko());
                    
                    // ���S���҃}�X�^����K�v�ȏ����擾
                    KaijoTantoMst kaijoT = new KaijoTantoMst(DATA_SOURCE_NAME);
                    KaijoTantoMst tanto = kaijoT.kaijoTantoJohoForShiyoKaijo(shiyoKaijo.getKaisaichiCode(),shiyoKaijo.getKaijoCode(),shiyoKaijo.getTantoshaCode());
                    shiyoKaijoInp.setBikoTanto(tanto.getBiko());

                    /* DB���ʍ��ڃZ�b�g */
                    shiyoKaijoInp.setKoshinKbn(BmaConstants.SHORI_KBN_INSERT);
                    shiyoKaijoInp.setTorokuDate(sysTime.getymd1());
                    shiyoKaijoInp.setTorokuTime(sysTime.gethms1());
                    shiyoKaijoInp.setTorokuUserId(inRequest.getMoshikomishaId());
                    shiyoKaijoInp.setKoshinDate("");
                    shiyoKaijoInp.setKoshinTime("");
                    shiyoKaijoInp.setKoshinUserId("");
                    shiyoKaijoInp.setRonriSakujoFlg(BmaConstants.FLG_OFF);

                    shiyoKaijoInp.create();
                    }
                    /* �R�~�b�g */
                    commitTransaction();
                }catch (Exception ex) {
                        ex.printStackTrace();
                        // ���[���o�b�N
                        rollbackTransaction();
                        return FWD_NM_SESSION;
                    }

                /* �u�g�p���V�K�o�^�����v��ʕ\�� */
                return FWD_NM_NEXT;
            }
                                
            } else if (!BmaUtility.isNullOrEmpty(inRequest.getBack())) {
                /*�u�����v�{�^��������*/
                processName = "MstKanriShiyoKaijoShinkiConfirm";
                log.Start(processName);

                List<MstKanriShiyoKaijoJoho> kaijoList = inSession.getShiyoKaijoInputList();
                
                KaijoTantoMst tanto = new KaijoTantoMst(DATA_SOURCE_NAME);
                for (int i = 0; i < kaijoList.size(); ++i) {
                    List<Option> tantoshaList = new ArrayList<Option>();
                    MstKanriShiyoKaijoJoho shiyoKaijo = kaijoList.get(i);

                    String kaisaichi = shiyoKaijo.getKaisaichiCode();
                    String kaijo = shiyoKaijo.getKaijoCode();
                    tanto.findByOneTantosha(kaisaichi, kaijo, tantoshaList);

                    shiyoKaijo.setTantoshaList(tantoshaList);

                    shiyoKaijo.setShiyoKaijoHukusei(kaisaichi + kaijo);
                    shiyoKaijo.setKaijoId("");
                    kaijoList.set(i, shiyoKaijo);
                }
                inSession.setKaijoList(kaijoList);
                
                inSession.setShiyoKaijoUpdateList(new LinkedList<MstKanriShiyoKaijoJoho>());
                
                /* �u�g�p���V�K�o�^�i���́j�v��ʕ\�� */
                return FWD_NM_BACK;
                
            } else {
                /*�ُ�J��*/
                log.IllegalFWD();
                return FWD_NM_SESSION;
            }
        } catch (Exception e) {
            return FWD_NM_EXCEPTION;
        } finally {
            log.End(processName);
        }
    }
     
    /**
     * ���̓`�F�b�N
     *
     * @param inSession �Z�b�V����RTO
     * @return true:�G���[��
     */
    private boolean validateInput(List<MstKanriShiyoKaijoJoho> shiyoKaijoList, MstKanriShiyoKaijoJoho inSession) {
        /* �ϐ������� */
        Messages errors = new Messages();
        String groupCode;
        String itemName;

        // �G���[�`�F�b�N�p���X�g�쐬
        String[] kaijoShikenKbns = {BmaConstants.KAIJO_SHIKEN_KBN_NASHI, BmaConstants.KAIJO_SHIKEN_KBN_GAKKA, BmaConstants.KAIJO_SHIKEN_KBN_ZITSUGI};
        
        for (int i = 0; i < shiyoKaijoList.size(); ++i) {
            MstKanriShiyoKaijoJoho shiyoKaijo = shiyoKaijoList.get(i);

        /* ��ꎎ���敪 */
        groupCode = "kaijoShikenKbn";
        itemName = "��ꎎ���敪";
        if (BmaValidator.validateSelect(shiyoKaijo.getKaijoShikenKbn(), errors, groupCode, itemName)) {
            BmaValidator.validatePermissionSelect(shiyoKaijo.getKaijoShikenKbn(), kaijoShikenKbns, errors, groupCode, itemName);
        }
        
        /* ����From */
        groupCode = "nitteiFrom";
        // �N
        itemName =  "�����QFROM�̔N";
        if (BmaValidator.validateRequired(shiyoKaijo.getFromYear(), errors, groupCode, itemName)) {
            if (BmaValidator.validateNumber(shiyoKaijo.getFromYear(), errors, groupCode, itemName)) {
                BmaValidator.validateMaxLength(shiyoKaijo.getFromYear(), BmaConstants.EQUAL_LENGTH_SCHED_DATE_YEAR, errors, groupCode, itemName);
            }
        }
        // ��
        itemName = "�����QFROM�̌�";
        if (BmaValidator.validateRequired(shiyoKaijo.getFromMonth(), errors, groupCode, itemName)) {
            if (BmaValidator.validateNumber(shiyoKaijo.getFromMonth(), errors, groupCode, itemName)) {
                BmaValidator.validateMaxLength(shiyoKaijo.getFromMonth(), BmaConstants.EQUAL_LENGTH_SCHED_DATE_MONTH, errors, groupCode, itemName);
            }
        }
        // ��
        itemName = "�����QFROM�̓�";
        if (BmaValidator.validateRequired(shiyoKaijo.getFromDate(), errors, groupCode, itemName)) {
            if (BmaValidator.validateNumber(shiyoKaijo.getFromDate(), errors, groupCode, itemName)) {
                BmaValidator.validateMaxLength(shiyoKaijo.getFromDate(), BmaConstants.EQUAL_LENGTH_SCHED_DATE_DAY, errors, groupCode, itemName);
            }
        }
        // ���t�̐�����
        if (errors.isEmpty()) {
            itemName = "�����QFROM";
            BmaValidator.validateDate2(shiyoKaijo.getNitteiFrom(), errors, groupCode, itemName);
        }
        
        /* ����To */
        groupCode = "nitteiTo";
        // �N
        itemName =  "�����QTO�̔N";
        if (BmaValidator.validateRequired(shiyoKaijo.getToYear(), errors, groupCode, itemName)) {
            if (BmaValidator.validateNumber(shiyoKaijo.getToYear(), errors, groupCode, itemName)) {
                BmaValidator.validateMaxLength(shiyoKaijo.getToYear(), BmaConstants.EQUAL_LENGTH_SCHED_DATE_YEAR, errors, groupCode, itemName);
            }
        }
        // ��
        itemName = "�����QTO�̌�";
        if (BmaValidator.validateRequired(shiyoKaijo.getToMonth(), errors, groupCode, itemName)) {
            if (BmaValidator.validateNumber(shiyoKaijo.getToMonth(), errors, groupCode, itemName)) {
                BmaValidator.validateMaxLength(shiyoKaijo.getToMonth(), BmaConstants.EQUAL_LENGTH_SCHED_DATE_MONTH, errors, groupCode, itemName);
            }
        }
        // ��
        itemName = "�����QTO�̓�";
        if (BmaValidator.validateRequired(shiyoKaijo.getToDate(), errors, groupCode, itemName)) {
            if (BmaValidator.validateNumber(shiyoKaijo.getToDate(), errors, groupCode, itemName)) {
                BmaValidator.validateMaxLength(shiyoKaijo.getToDate(), BmaConstants.EQUAL_LENGTH_SCHED_DATE_DAY, errors, groupCode, itemName);
            }
        }
        // ���t�̐�����
        if (errors.isEmpty()) {
            itemName = "�����QTO";
            BmaValidator.validateDate2(shiyoKaijo.getNitteiTo(), errors, groupCode, itemName);
        }

        /* ��� */
        groupCode = "teiin";
        itemName = "���";
        if (BmaValidator.validateRequired(shiyoKaijo.getTeiin(), errors, groupCode, itemName)) {
            if (BmaValidator.validateMaxLength(shiyoKaijo.getTeiin(), BmaConstants.MAX_LENGTH_TEIIN, errors, groupCode, itemName)) {
                BmaValidator.validateNumber(shiyoKaijo.getTeiin(), errors, groupCode, itemName);
            }
        }
        
        /* �S���҃R�[�h */
        groupCode = "tantosha";
        itemName = "�S����";
        BmaValidator.validateSelect(shiyoKaijo.getTantoshaCode(), errors, groupCode, itemName);
        
        }
        inSession.setErrors(errors);
        return errors.isEmpty();
    }
    
}