package jp.co.nii.sew.presentation;

import java.io.Serializable;
import java.io.UnsupportedEncodingException;
import java.util.Enumeration;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

/**
 * ����RTO
 *
 * @author n-machida
 */
public abstract class AbstractRequestTransferObject implements RequestTransferObject, Serializable {

    /**
     * request��Attribute��request��parameter���Z�b�g����
     *
     * parameter����attribute��set���Amultipart/�ʏ�̂ǂ���̃��N�G�X�g�ł�
     * �ꗥ��attribute�ɑS���ڂ����悤�ɋώ���
     *
     * @param request
     * @throws java.io.UnsupportedEncodingException
     * @throws org.apache.commons.fileupload.FileUploadException
     */
    @Override
    public void setAttribute(HttpServletRequest request) throws UnsupportedEncodingException, FileUploadException {
        String contentType = request.getContentType();
        if (contentType != null && contentType.toLowerCase().startsWith("multipart/")) {
            // multipart request�i�t�@�C���A�b�v���[�h�j�̏ꍇ
            ServletFileUpload fu = new ServletFileUpload(new DiskFileItemFactory());
            List<FileItem> itemList = fu.parseRequest(request);
            for (FileItem item : itemList) {
                if (item.isFormField()) {
                    //�t�@�C���ȊO�̏ꍇ
                    request.setAttribute(item.getFieldName(), item.getString(request.getCharacterEncoding()));
                } else {
                    //�t�@�C���̏ꍇ
                    request.setAttribute(item.getFieldName(), item);
                }
            }

        } else {
            // �ʏ�̃��N�G�X�g�̏ꍇ
            Enumeration<String> itemEnum = request.getParameterNames();
            while (itemEnum.hasMoreElements()) {
                String itemName = itemEnum.nextElement();
                request.setAttribute(itemName, request.getParameter(itemName));
            }

            // avoid overhead
//            List<String> itemList = Collections.list(itemEnum);
//            for (String item : itemList) {
//                request.setAttribute(item, request.getParameter(item));
//            }
        }

    }
}
