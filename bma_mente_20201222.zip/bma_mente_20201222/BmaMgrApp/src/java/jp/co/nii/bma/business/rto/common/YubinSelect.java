package jp.co.nii.bma.business.rto.common;

import java.util.ArrayList;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import jp.co.nii.bma.business.domain.YubinBangoJisho;
import jp.co.nii.sew.presentation.AbstractRequestTransferObject;

/**
 * �X�֔ԍ��I��RTO
 *
 * @author S.Banka
 */
public class YubinSelect extends AbstractRequestTransferObject {

    /**
     * �X�֔ԍ��P
     */
    private String zipCode1;
    /**
     * �X�֔ԍ��Q
     */
    private String zipCode2;
    /**
     * �s���{���R�[�hID
     */
    private String kenCodeID;
    /**
     * �s�撬���R�[�hID
     */
    private String addressID;
    /**
     * �Z�����X�g
     */
    private List<YubinBangoJisho> addressList;

    /**
     * �R���X�g���N�^
     */
    public YubinSelect() {
        this.zipCode1 = "";
        this.zipCode2 = "";
        this.kenCodeID = "";
        this.addressID = "";
        this.addressList = new ArrayList<YubinBangoJisho>();
    }

    /**
     * ���N�G�X�g����l���擾����B
     *
     * @param request
     */
    @Override
    public void copyFromRequest(HttpServletRequest request) {
        setZipCode1((String) request.getAttribute("zipCode1"));
        setZipCode2((String) request.getAttribute("zipCode2"));
        setKenCodeID((String) request.getAttribute("kenCodeID"));
        setAddressID((String) request.getAttribute("addressID"));
    }

    /**
     * �X�֔ԍ��P
     *
     * @return the zipCode1
     */
    public String getZipCode1() {
        return zipCode1;
    }

    /**
     * �X�֔ԍ��P
     *
     * @param zipCode1 the zipCode1 to set
     */
    public void setZipCode1(String zipCode1) {
        this.zipCode1 = zipCode1;
    }

    /**
     * �X�֔ԍ��Q
     *
     * @return the zipCode2
     */
    public String getZipCode2() {
        return zipCode2;
    }

    /**
     * �X�֔ԍ��Q
     *
     * @param zipCode2 the zipCode2 to set
     */
    public void setZipCode2(String zipCode2) {
        this.zipCode2 = zipCode2;
    }

    /**
     * �s���{���R�[�hID
     *
     * @return the kenCodeID
     */
    public String getKenCodeID() {
        return kenCodeID;
    }

    /**
     * �s���{���R�[�hID
     *
     * @param kenCodeID the kenCodeID to set
     */
    public void setKenCodeID(String kenCodeID) {
        this.kenCodeID = kenCodeID;
    }

    /**
     * �s�撬���R�[�hID
     *
     * @return the addressID
     */
    public String getAddressID() {
        return addressID;
    }

    /**
     * �s�撬���R�[�hID
     *
     * @param addressID the addressID to set
     */
    public void setAddressID(String addressID) {
        this.addressID = addressID;
    }

    /**
     * �Z�����X�g
     *
     * @return the addressList
     */
    public List<YubinBangoJisho> getAddressList() {
        return addressList;
    }

    /**
     * �Z�����X�g
     *
     * @param addressList the addressList to set
     */
    public void setAddressList(List<YubinBangoJisho> addressList) {
        this.addressList = addressList;
    }

    /**
     * �Z�����X�g���󂩂ǂ���
     *
     * @return
     */
    public boolean isAddresNone() {
        return getAddressList().isEmpty();
    }
}
