package jp.co.nii.bma.integration;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import jp.co.nii.bma.business.domain.Shokureki;
import jp.co.nii.bma.business.domain.ShokurekiDao;
import jp.co.nii.sew.common.LogGenerate;
import static jp.co.nii.sew.integration.AbstractDao.getSchemaName;
import jp.co.nii.sew.integration.SQLStateSQLExceptionTranslater;

/**
 * �E�� DAO�����N���X
 *
 * @author DB�Ǘ��c�[��
 */
public class ShokurekiDaoImpl extends GeneratedShokurekiDaoImpl implements ShokurekiDao {

    /**
     * �C���X�^���X�𐶐�����B
     *
     * @param datasource �f�[�^�\�[�X��
     */
    public ShokurekiDaoImpl(String datasource) {
        super(datasource);
    }

    /**
     * �摜���ޏڍׂ��擾����B
     *
     * @param bo
     * @return �摜���ޏڍ׃��X�g
     */
    @Override
    public List<Shokureki> searchGazoShoruiShosai(Shokureki bo) {
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = "";
        List<String> param = new ArrayList<>();
        Shokureki shokureki = null;
        String uketsukeNo = bo.getUketsukeNo();
        String nendo = bo.getNendo();
        List<Shokureki> shoruiList = new ArrayList<>();
        try {
            con = getConnection();
            sql = "SELECT KINMUSAKI_KAISHA_NAME,"
                    + " BUSHO_YAKUSHOKU_NAME,"
                    + " ZAISEKIKIKAN_FROM,"
                    + " ZAISEKIKIKAN_TO,"
                    + " SHOKUREKI_KBN"
                    + " FROM " + getSchemaName() + "." + TABLE_NAME
                    + " WHERE UKETSUKE_NO = ?"
                    + " AND NENDO = ?"
                    + " AND SHOKUREKI_KBN IN ('3', '4')"
                    + " AND RONRI_SAKUJO_FLG = '0'"
                    + " ORDER BY SHOKUREKI_KBN ASC, SHOKUREKI_SEQ ASC";
            param.add(uketsukeNo);
            param.add(nendo);
            stmt = con.prepareStatement(sql);
            int i = 1;
            for (String pm : param) {
                stmt.setString(i++, pm);
            }

            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();
            while (rs.next()) {
                shokureki = new Shokureki();
                shokureki.setKinmusakiKaishaName(rs.getString("KINMUSAKI_KAISHA_NAME"));
                shokureki.setBushoYakushokuName(rs.getString("BUSHO_YAKUSHOKU_NAME"));
                shokureki.setZaisekikikanFrom(rs.getString("ZAISEKIKIKAN_FROM"));
                shokureki.setZaisekikikanTo(rs.getString("ZAISEKIKIKAN_TO"));
                shokureki.setShokurekiKbn(rs.getString("SHOKUREKI_KBN"));
                shoruiList.add(shokureki);
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return shoruiList;
    }

    @Override
    public List<Shokureki> findByNendoUke(String nendo, String uketsukeNo) {

        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = "";

        List<Shokureki> ret = new ArrayList<Shokureki>();
        try {
            con = getConnection();
            sql = "SELECT " + FIELDS_DECRYPT
                    + " FROM " + getSchemaName() + "." + TABLE_NAME
                    + " WHERE"
                    + " NENDO = ?"
                    + " AND UKETSUKE_NO = ?";

            stmt = con.prepareStatement(sql);
            int i = 1;
            stmt.setString(i++, nendo);
            stmt.setString(i++, uketsukeNo);

            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();
            while (rs.next()) {
                Shokureki bo = new Shokureki();
                setBoFromResultSet(bo, rs);
                ret.add(bo);
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return ret;
    }
}
