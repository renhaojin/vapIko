package jp.co.nii.bma.business.service.manager;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import jp.co.nii.bma.business.domain.KaijoTantoMst;
import jp.co.nii.bma.business.domain.ShiyoKaijo;
import jp.co.nii.bma.business.rto.manager.MstKanriShiyoKaijoJoho;
import jp.co.nii.bma.business.service.common.BmaConstants;
import jp.co.nii.bma.business.service.common.BmaLogger;
import jp.co.nii.bma.business.service.common.BmaValidator;
import jp.co.nii.bma.presentation.common.BmaText;
import jp.co.nii.bma.utility.BmaUtility;
import jp.co.nii.sew.business.service.AbstractService;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_BACK;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_EXCEPTION;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_RELOAD;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_SESSION;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_SUCCESS;
import jp.co.nii.sew.presentation.Messages;
import jp.co.nii.sew.presentation.Option;
import jp.co.nii.sew.presentation.RequestTransferObject;
import jp.co.nii.sew.utility.PropertyUtility;

/**
 *
 * @author nii19049
 */
public class MstKanriShiyoKaijoShinkiInputService extends AbstractService {

    /**
     * DB�ڑ��̃f�[�^�\�[�X
     */
    private static String DATA_SOURCE_NAME;
    /**
     * ���O
     */
    BmaLogger log = (BmaLogger) BmaLogger.getLogger(this.getClass().getName());
    /**
     * �Ɩ��R�[�h
     */
    private static final String BUSINESS_CODE = PropertyUtility.getProperty("business_code");
    /**
     * ���׃e�X�g���[�h
     */
    private static final String STRESS_MODE = PropertyUtility.getProperty(BUSINESS_CODE + "stress_mode");

    /**
     * �R���X�g���N�^
     */
    public MstKanriShiyoKaijoShinkiInputService() {
        super();
        /* DB�ڑ����̃��[�U�[������ */
        DATA_SOURCE_NAME = BmaConstants.DS_REGISTRANT;
    }

    /**
     * �T�[�r�X�N���X�̎��s���\�b�h
     *
     * @param rto ���N�G�X�g��񂩂�擾����rto
     * @param rtoInSession �Z�b�V�������rto
     * @return foward��
     * @throws Exception ��O
     */
    @Override
    public String doService(RequestTransferObject rto, RequestTransferObject rtoInSession)
            throws Exception {

        MstKanriShiyoKaijoJoho inRequest = (MstKanriShiyoKaijoJoho) rto;
        MstKanriShiyoKaijoJoho inSession = (MstKanriShiyoKaijoJoho) rtoInSession;
        String processName = "";

        /*�G���[���b�Z�[�W������*/
        inSession.setErrors(new Messages());
        try {
            if (!BmaUtility.isNullOrEmpty(inRequest.getShiyoKaijoShinkiInp())) {
                /*�u�g�p���V�K�o�^���́v�J�ڎ�*/
                processName = "MstKanriShiyoKaijoShinkiInput";
                log.Start(processName);
                
                MstKanriShiyoKaijoJoho shiyoKaijo = new MstKanriShiyoKaijoJoho();
                MstKanriShiyoKaijoJoho shiyoKaijoUpdName = createShiyoKaijoShinki(shiyoKaijo);
                // ��ꎎ���敪
                if ("2".equals(inSession.getSknksuKbn())) {
                    shiyoKaijo.setKaijoShikenName(shiyoKaijoUpdName.getKaijoShikenName());
                }

                /* �u�g�p���V�K�o�^���́v��ʕ\�� */
                return FWD_NM_SUCCESS;

            } else if (!BmaUtility.isNullOrEmpty(inRequest.getShiyoKaijoShinkiConf())) {
                /*�u�m�F�v�{�^��������*/
                processName = "MstKanriShiyoKaijoShinkiInput";
                log.Start(processName);

                KaijoTantoMst tanto = new KaijoTantoMst(DATA_SOURCE_NAME);

                inSession.setShiyoKaijoInputList(inRequest.getShiyoKaijoInputList());
                inSession.setKaijoList(inSession.getShiyoKaijoInputList());

                // �g�p�������1�����I�����Ă��Ȃ��ꍇ�G���[
                Boolean checkUseKaijo = false;
                Boolean checkInput = false;
                for (MstKanriShiyoKaijoJoho shiyokaijo : inSession.getShiyoKaijoInputList()) {
                    if ("1".equals(shiyokaijo.getSelectedKaijo())) {
                        checkUseKaijo = true;
                        break;
                    }
                }
                if (!checkUseKaijo) {
                    Messages errors = new Messages();
                    BmaValidator.addMessage(errors, "shiyoKaijoData", BmaText.E00133);
                    inSession.setErrors(errors);
                } else {
                    // ���͒l�`�F�b�N
                    checkInput = validateInput(inSession.getShiyoKaijoInputList(), inSession);
                }

                if (!checkInput || !checkUseKaijo) {
                    // �G���[���������ꍇ�u�g�p���V�K�v���Reload
                    for (int l = 0; l < inSession.getKaijoList().size(); l++) {
                        List<Option> tantoshaList = new ArrayList<Option>();
                        MstKanriShiyoKaijoJoho shiyoKaijo = inSession.getKaijoList().get(l);

                        shiyoKaijo.setFromYear(shiyoKaijo.getFromYear().replaceFirst("^0+", ""));
                        shiyoKaijo.setFromMonth(shiyoKaijo.getFromMonth().replaceFirst("^0+", ""));
                        shiyoKaijo.setFromDate(shiyoKaijo.getFromDate().replaceFirst("^0+", ""));
                        shiyoKaijo.setToYear(shiyoKaijo.getToYear().replaceFirst("^0+", ""));
                        shiyoKaijo.setToMonth(shiyoKaijo.getToMonth().replaceFirst("^0+", ""));
                        shiyoKaijo.setToDate(shiyoKaijo.getToDate().replaceFirst("^0+", ""));

                        String kaisaichi = shiyoKaijo.getKaisaichiCode();
                        String kaijo = shiyoKaijo.getKaijoCode();
                        tanto.findByOneTantosha(kaisaichi, kaijo, tantoshaList);

                        shiyoKaijo.setKaisaichiCode(kaisaichi);
                        shiyoKaijo.setKaijoCode(kaijo);
                        shiyoKaijo.setTantoshaList(tantoshaList);
                        shiyoKaijo.setTantosha("");
                        shiyoKaijo.setShiyoKaijoHukusei(kaisaichi + kaijo);
                        inSession.getKaijoList().set(l, shiyoKaijo);

                    }
                    return FWD_NM_SUCCESS;
                }

                int intKaijoId = 0;
                String strKaijoId;
                Boolean errFlg = false;
                for (int i = 0; i < inSession.getShiyoKaijoInputList().size(); i++) {
                    MstKanriShiyoKaijoJoho shiyoKaijo = inSession.getShiyoKaijoInputList().get(i);
                    if ("1".equals(shiyoKaijo.getSelectedKaijo())) {

                        MstKanriShiyoKaijoJoho shiyoKaijoUpdName = createShiyoKaijoShinki(shiyoKaijo);
                        // ��ꎎ���敪
                        if (!"2".equals(shiyoKaijo.getSknksuKbn())) {
                            shiyoKaijo.setKaijoShikenName(shiyoKaijoUpdName.getKaijoShikenName());
                        }

                        // ���ID
                        intKaijoId = intKaijoId + 1;
                        strKaijoId = String.valueOf(intKaijoId);
                        if (strKaijoId.length() < 2) {
                            strKaijoId = String.format("%2s", strKaijoId).replace(' ', '0');
                        }
                        shiyoKaijo.setKaijoId(strKaijoId);

                        //�j��
                        shiyoKaijo.setNitteiFrom(shiyoKaijo.getFromYear() + shiyoKaijo.getFromMonth() + shiyoKaijo.getFromDate());
                        shiyoKaijo.setNitteiTo(shiyoKaijo.getToYear() + shiyoKaijo.getToMonth() + shiyoKaijo.getToDate());

                        shiyoKaijo.setFromYobi(dateToWeek(shiyoKaijo.getNitteiFrom()));

                        if (!BmaUtility.isNullOrEmpty(shiyoKaijo.getNitteiTo())) {
                            shiyoKaijo.setToYobi(dateToWeek(shiyoKaijo.getNitteiTo()));
                        }

                        //���
                        shiyoKaijo.setTeiin(String.format(shiyoKaijo.getTeiin()).replaceFirst("^0+", ""));

                        //�S����
                        String kaisaichiCode = shiyoKaijo.getKaisaichiCode();
                        String kaijoCode = shiyoKaijo.getKaijoCode();
                        String tantoshaCode = shiyoKaijo.getTantoshaCode();

                        String shiyoKaijoTantosha = tanto.searchTantoshaName(kaisaichiCode, kaijoCode, tantoshaCode);

                        shiyoKaijo.setTantosha(shiyoKaijoTantosha);

                        inSession.getShiyoKaijoUpdateList().add(shiyoKaijo);
                    }
                }

                inSession.setKaijoList(inSession.getShiyoKaijoInputList());


                /* �u�g�p���V�K�o�^�m�F�v��ʕ\�� */
                return FWD_NM_NEXT;

            } else if (!BmaUtility.isNullOrEmpty(inRequest.getShiyoKaijoHukusei())) {
                /*�u�����v�{�^��������*/
                processName = "MstKanriShiyoKaijoShinkiInput";
                log.Start(processName);

                /*���͒l���Z�b�V�����ɕۑ�*/
                List<MstKanriShiyoKaijoJoho> kaijoList = inRequest.getShiyoKaijoInputList();
                inSession.setKaijoList(kaijoList);

                //����񂪍ő�s�����̏ꍇ�A�������P���ǉ�����.
                int[] listNo = hukuseiSet(inSession.getKaijoList(), inRequest);
                if (listNo[0] < BmaConstants.MAX_KAIJO_COUNT) {
                    MstKanriShiyoKaijoJoho shiyoKaijo = new MstKanriShiyoKaijoJoho();
                    createHukuseiData(shiyoKaijo, kaijoList.get(listNo[1]));
                    kaijoList.add(listNo[1] + 1, shiyoKaijo);
                } else {
                    // �����ꂪ5���ȏ�̏ꍇ�u�g�p���V�K�o�^�v���Reload */
                    Messages errors = new Messages();
                    BmaValidator.addMessage(errors, "shiyoKaijoData", BmaText.E00131);
                    inSession.setErrors(errors);
                }

                KaijoTantoMst tanto = new KaijoTantoMst(DATA_SOURCE_NAME);
                for (int i = 0; i < kaijoList.size(); ++i) {
                    List<Option> tantoshaList = new ArrayList<Option>();
                    MstKanriShiyoKaijoJoho shiyoKaijo = kaijoList.get(i);

                    String kaisaichi = shiyoKaijo.getKaisaichiCode();
                    String kaijo = shiyoKaijo.getKaijoCode();
                    tanto.findByOneTantosha(kaisaichi, kaijo, tantoshaList);

                    shiyoKaijo.setTantoshaList(tantoshaList);

                    shiyoKaijo.setShiyoKaijoHukusei(kaisaichi + kaijo);
                    kaijoList.set(i, shiyoKaijo);
                }

                inSession.setKaijoList(kaijoList);

                /* �u�g�p���V�K�o�^���́v��ʕ\�� */
                return FWD_NM_RELOAD;

            } else if (!BmaUtility.isNullOrEmpty(inRequest.getBack())) {
                /*�u�߂�v�{�^��������*/
                processName = "MstKanriShiyoKaijoShinkiInput";
                log.Start(processName);

                //�Z�b�V�����j��
                inSession.setSknksuKbn("1");
                inSession.setSknName("");
                inSession.setKsuName("");

                /* �u�g�p���V�K�o�^�v��ʕ\�� */
                return FWD_NM_BACK;

            } else {
                /*�ُ�J��*/
                log.IllegalFWD();
                return FWD_NM_SESSION;
            }
        } catch (Exception e) {
            return FWD_NM_EXCEPTION;
        } finally {
            log.End(processName);
        }
    }

    private MstKanriShiyoKaijoJoho createShiyoKaijoShinki(MstKanriShiyoKaijoJoho shiyoKaijo) {

        String kaijoShikenName = "";
        String tantosha = "";

        MstKanriShiyoKaijoJoho shiyoKaijoShinki = new MstKanriShiyoKaijoJoho();

        /* ��ꎎ���敪���̂��Z�b�g */
        if (BmaConstants.KAIJO_SHIKEN_KBN_NASHI.equals(shiyoKaijo.getKaijoShikenKbn())) {
            kaijoShikenName = "�敪���g�p���Ȃ�";
        } else if (BmaConstants.KAIJO_SHIKEN_KBN_GAKKA.equals(shiyoKaijo.getKaijoShikenKbn())) {
            kaijoShikenName = "�w�Ȏ����y�ю��Z�y�[�p�[�e�X�g";
        } else if (BmaConstants.KAIJO_SHIKEN_KBN_ZITSUGI.equals(shiyoKaijo.getKaijoShikenKbn())) {
            kaijoShikenName = "���Z��Ǝ���";
        }
        shiyoKaijoShinki.setKaijoShikenName(kaijoShikenName);

        /* �S���Җ��̂��Z�b�g */
        shiyoKaijoShinki.setTantoshaCode(tantosha);

        return shiyoKaijoShinki;
    }

    /**
     * ���t�ɂ���ėj�����擾����
     *
     * @param datetime�@���t
     * @return �j��
     */
    public static String dateToWeek(String datetime) {

        SimpleDateFormat f = new SimpleDateFormat("yyyyMMdd");
        String[] weekDays = {"��", "��", "��", "��", "��", "��", "�y"};
        Calendar cal = Calendar.getInstance();
        Date date;
        try {
            date = f.parse(datetime);
            cal.setTime(date);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        //the day number of a week
        int w = cal.get(Calendar.DAY_OF_WEEK) - 1;
        if (w < 0) {
            w = 0;
        }
        return weekDays[w];
    }

    /**
     * �����𐮌`����
     *
     * @param inRequest�@���N�G�X�g���
     * @param inSession�@�Z�b�V�������
     */
    public static void createNittei(MstKanriShiyoKaijoJoho inRequest, MstKanriShiyoKaijoJoho inSession) {
        /* �ϐ������� */
        String nitteiFrom = "";
        String nitteiTo = "";

        // ����From �N
        if (!BmaUtility.isNullOrEmpty(inRequest.getFromYear())) {
            // �����̓��͂�����Γ��t�p�ɘA��
            inSession.setFromYear(String.format("%4s", inRequest.getFromYear()).replace(' ', '0'));
            nitteiFrom = inSession.getFromYear();
        } else {
            // ���͂��Ȃ���΃G���[
            inSession.setFromYear(inRequest.getFromYear());
        }
        // ����From ��
        if (!BmaUtility.isNullOrEmpty(inRequest.getFromMonth())) {
            inSession.setFromMonth(String.format("%2s", inRequest.getFromMonth()).replace(' ', '0'));
            nitteiFrom += inSession.getFromMonth();
        } else {
            inSession.setFromMonth(inRequest.getFromMonth());
        }
        // ����From ��
        if (!BmaUtility.isNullOrEmpty(inRequest.getFromDate())) {
            inSession.setFromDate(String.format("%2s", inRequest.getFromDate()).replace(' ', '0'));
            nitteiFrom += inSession.getFromDate();
        } else {
            inSession.setFromDate(inRequest.getFromDate());
        }
        inSession.setNitteiFrom(nitteiFrom);

        // ����To �N
        if (!BmaUtility.isNullOrEmpty(inRequest.getToYear())) {
            // �����̓��͂�����Γ��t�p�ɘA��
            inSession.setToYear(String.format("%4s", inRequest.getToYear()).replace(' ', '0'));
            nitteiTo = inSession.getToYear();
        } else {
            // ���͂��Ȃ���΃G���[
            inSession.setToYear(inRequest.getToYear());
        }
        // ����To ��
        if (!BmaUtility.isNullOrEmpty(inRequest.getToMonth())) {
            inSession.setToMonth(String.format("%2s", inRequest.getToMonth()).replace(' ', '0'));
            nitteiTo += inSession.getToMonth();
        } else {
            inSession.setToMonth(inRequest.getToMonth());
        }
        // ����To ��
        if (!BmaUtility.isNullOrEmpty(inRequest.getToDate())) {
            inSession.setToDate(String.format("%2s", inRequest.getToDate()).replace(' ', '0'));
            nitteiTo += inSession.getToDate();
        } else {
            inSession.setToDate(inRequest.getToDate());
        }
        inSession.setNitteiTo(nitteiTo);
    }

    /**
     * ����
     *
     * @param kaijoList
     * @param inRequest
     */
    public static int[] hukuseiSet(List<MstKanriShiyoKaijoJoho> kaijoList, MstKanriShiyoKaijoJoho inRequest) {
        int[] hukuseiset = new int[2];
        int count = 0;
        int listNo = 0;
        String kaisaichi = "";
        String kaijo = "";

        kaisaichi = inRequest.getShiyoKaijoHukusei().substring(0, 2);
        kaijo = inRequest.getShiyoKaijoHukusei().substring(2, 5);

        for (int i = 0; i < kaijoList.size(); ++i) {
            MstKanriShiyoKaijoJoho shiyoKaijo = kaijoList.get(i);
            if (kaisaichi.equals(shiyoKaijo.getKaisaichiCode())) {
                if (kaijo.equals(shiyoKaijo.getKaijoCode())) {
                    count++;
                    listNo = i;
                }
            }
        }
        hukuseiset[0] = count;
        hukuseiset[1] = listNo;

        return hukuseiset;
    }

    /**
     * �����������X�g�̓��͍��ڂ��u�����N�ɂ���
     *
     * @param shiyoKaijo
     * @param hukuseiKaijo
     */
    public static void createHukuseiData(MstKanriShiyoKaijoJoho shiyoKaijo, MstKanriShiyoKaijoJoho hukuseiKaijo) {
        shiyoKaijo.setKaisaichiCode(hukuseiKaijo.getKaisaichiCode());
        shiyoKaijo.setKaisaichiName(hukuseiKaijo.getKaisaichiName());
        shiyoKaijo.setKaijoCode(hukuseiKaijo.getKaijoCode());
        shiyoKaijo.setKaijoName(hukuseiKaijo.getKaijoName());
        shiyoKaijo.setKaijoNameRyaku(hukuseiKaijo.getKaijoNameRyaku());

        hukuseiKaijo.setNitteiFrom("");
        hukuseiKaijo.setNitteiTo("");
    }

    /**
     * ���̓`�F�b�N
     *
     * @param inSession �Z�b�V����RTO
     * @return true:�G���[��
     */
    private boolean validateInput(List<MstKanriShiyoKaijoJoho> shiyoKaijoList, MstKanriShiyoKaijoJoho inSession) {
        /* �ϐ������� */
        Messages errors = new Messages();
        String groupCode;
        String itemName;

        // �G���[�`�F�b�N�p���X�g�쐬
        String[] sknKsuKbns = {BmaConstants.KAIJO_SHIKEN_KBN_NASHI, BmaConstants.KAIJO_SHIKEN_KBN_GAKKA, BmaConstants.KAIJO_SHIKEN_KBN_ZITSUGI};

        for (int i = 0; i < shiyoKaijoList.size(); ++i) {
            MstKanriShiyoKaijoJoho shiyoKaijo = shiyoKaijoList.get(i);
            if ("1".equals(shiyoKaijo.getSelectedKaijo())) {

                // �����쐬
                createNittei(shiyoKaijo, shiyoKaijo);

                /* ��ꎎ���敪 */
                groupCode = "kaijoShikenKbn";
                itemName = "���" + String.valueOf(i + 1) + "�̉�ꎎ���敪";
                BmaValidator.validateSelect(shiyoKaijo.getKaijoShikenKbn(), errors, groupCode, itemName);
                BmaValidator.validatePermissionSelect(shiyoKaijo.getKaijoShikenKbn(), sknKsuKbns, errors, groupCode, itemName);

                /* �S���� */
                groupCode = "tantosha";
                itemName = "���" + String.valueOf(i + 1) + "�̒S����";
                if (BmaValidator.validateSelect(shiyoKaijo.getTantoshaCode(), errors, groupCode, itemName)) {
                    BmaValidator.validatePermissionSelect(shiyoKaijo.getTantosha(), inSession.getTantoshaList(), errors, groupCode, itemName);
                }

                /* ����From */
                groupCode = "date" + shiyoKaijo.getNitteiFrom();
                /* ���t */
                // �N
                itemName = "���" + String.valueOf(i + 1) + "����From�̔N";
                if (BmaValidator.validateRequired(shiyoKaijo.getFromYear(), errors, groupCode, itemName)) {
                    if (BmaValidator.validateNumber(shiyoKaijo.getFromYear(), errors, groupCode, itemName)) {
                        BmaValidator.validateMaxLength(shiyoKaijo.getFromYear(), BmaConstants.EQUAL_LENGTH_SCHED_DATE_YEAR, errors, groupCode, itemName);
                    }
                }
                // ��
                itemName = "���" + String.valueOf(i + 1) + "����From�̌�";
                if (BmaValidator.validateRequired(shiyoKaijo.getFromMonth(), errors, groupCode, itemName)) {
                    if (BmaValidator.validateNumber(shiyoKaijo.getFromMonth(), errors, groupCode, itemName)) {
                        BmaValidator.validateMaxLength(shiyoKaijo.getFromMonth(), BmaConstants.EQUAL_LENGTH_SCHED_DATE_MONTH, errors, groupCode, itemName);
                    }
                }
                // ��
                itemName = "���" + String.valueOf(i + 1) + "����From�̓�";
                if (BmaValidator.validateRequired(shiyoKaijo.getFromDate(), errors, groupCode, itemName)) {
                    if (BmaValidator.validateNumber(shiyoKaijo.getFromDate(), errors, groupCode, itemName)) {
                        BmaValidator.validateMaxLength(shiyoKaijo.getFromDate(), BmaConstants.EQUAL_LENGTH_SCHED_DATE_DAY, errors, groupCode, itemName);
                    }
                }
                // ���t�̐�����
                if (errors.isEmpty()) {
                    itemName = "���" + String.valueOf(i + 1) + "����From";
                    BmaValidator.validateDate2(shiyoKaijo.getNitteiFrom(), errors, groupCode, itemName);
                }

                /* ����To */
                // �N
                itemName = "���" + String.valueOf(i + 1) + "����To�̔N";
                if (BmaValidator.validateRequired(shiyoKaijo.getToYear(), errors, groupCode, itemName)) {
                    if (BmaValidator.validateNumber(shiyoKaijo.getToYear(), errors, groupCode, itemName)) {
                        BmaValidator.validateMaxLength(shiyoKaijo.getToYear(), BmaConstants.EQUAL_LENGTH_SCHED_DATE_YEAR, errors, groupCode, itemName);
                    }
                }
                // ��
                itemName = "���" + String.valueOf(i + 1) + "����To�̌�";
                if (BmaValidator.validateRequired(shiyoKaijo.getToMonth(), errors, groupCode, itemName)) {
                    if (BmaValidator.validateNumber(shiyoKaijo.getToMonth(), errors, groupCode, itemName)) {
                        BmaValidator.validateMaxLength(shiyoKaijo.getToMonth(), BmaConstants.EQUAL_LENGTH_SCHED_DATE_MONTH, errors, groupCode, itemName);
                    }
                }
                // ��
                itemName = "���" + String.valueOf(i + 1) + "����To�̓�";
                if (BmaValidator.validateRequired(shiyoKaijo.getToDate(), errors, groupCode, itemName)) {
                    if (BmaValidator.validateNumber(shiyoKaijo.getToDate(), errors, groupCode, itemName)) {
                        BmaValidator.validateMaxLength(shiyoKaijo.getToDate(), BmaConstants.EQUAL_LENGTH_SCHED_DATE_DAY, errors, groupCode, itemName);
                    }
                }
                // ���t�̐�����
                if (errors.isEmpty()) {
                    itemName = "���" + String.valueOf(i + 1) + "����To";
                    BmaValidator.validateDate2(shiyoKaijo.getNitteiTo(), errors, groupCode, itemName);
                }

                // ����_FROM�Ɠ���_TO�̑O��֌W�`�F�b�N
                if (errors.isEmpty()) {
                    itemName = "�����QFROM�Ɠ����QTO";
                    if (!checkStartEndDate(shiyoKaijo.getNitteiFrom(), shiyoKaijo.getNitteiTo())) {
                        BmaValidator.addMessage(errors, groupCode, BmaText.E00004, itemName);
                    }
                }

                /* ��� */
                groupCode = "teiin";
                itemName = "���" + String.valueOf(i + 1) + "�̒��";
                if (BmaValidator.validateRequired(shiyoKaijo.getTeiin(), errors, groupCode, itemName)) {
                    if (BmaValidator.validateMaxLength(shiyoKaijo.getTeiin(), BmaConstants.MAX_LENGTH_TEIIN, errors, groupCode, itemName)) {
                        BmaValidator.validateNumber(shiyoKaijo.getTeiin(), errors, groupCode, itemName);
                    }
                }
            }
        }
        inSession.setErrors(errors);
        return errors.isEmpty();
    }

    /**
     * ����_TO������_FROM�ȍ~���ǂ����`�F�b�N
     *
     * @param startDate ����_FROM
     * @param endDate ����_TO
     * @return true:�J�n�����O�@false:�I�������O
     */
    private boolean checkStartEndDate(String startDate, String endDate) {
        /* �ϐ������� */
        SimpleDateFormat f = new SimpleDateFormat("yyyyMMdd");

        String checkStart = startDate;
        String checkEnd = endDate;

        try {
            Date dateStart = f.parse(checkStart);
            Date dateEnd = f.parse(checkEnd);
            if (dateStart.compareTo(dateEnd) != 1) {
                return true;
            } else {
                return false;
            }
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return false;
    }
}
