package jp.co.nii.bma.integration;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import jp.co.nii.bma.business.domain.HanyoKensakuDtlOutDao;
import jp.co.nii.sew.business.domain.NoSuchDataException;
import jp.co.nii.sew.common.LogGenerate;
import jp.co.nii.sew.integration.SQLStateSQLExceptionTranslater;

/**
 * �ėp��������_�o�� DAO�����N���X
 *
 * @author DB�Ǘ��c�[��
 */
public class HanyoKensakuDtlOutDaoImpl extends GeneratedHanyoKensakuDtlOutDaoImpl implements HanyoKensakuDtlOutDao {

    /**
     * �C���X�^���X�𐶐�����B
     *
     * @param datasource �f�[�^�\�[�X��
     */
    public HanyoKensakuDtlOutDaoImpl(String datasource) {
        super(datasource);
    }

    @Override
    public void deleteByKensakuId(String hanyoKensakuIdOut) {
        Connection con = null;
        PreparedStatement stmt = null;
        String sql = "";
        try {
            con = getConnection();
            sql = "DELETE FROM " + getSchemaName() + "." + TABLE_NAME
                    + " WHERE"
                    + " HANYO_KENSAKU_ID_OUT = ?";

            stmt = con.prepareStatement(sql);
            int i = 1;
            stmt.setString(i++, hanyoKensakuIdOut);

            LogGenerate.debugOutput(getSql(stmt));
            if (stmt.executeUpdate() == 0) {
                throw new NoSuchDataException(getSql(stmt));
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt);
        }

    }
}
