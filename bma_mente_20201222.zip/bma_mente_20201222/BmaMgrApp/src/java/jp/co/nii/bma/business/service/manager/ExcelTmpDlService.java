package jp.co.nii.bma.business.service.manager;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import jp.co.nii.bma.business.domain.Moshikomi;
import jp.co.nii.bma.business.rto.manager.FileDownLoad;
import jp.co.nii.bma.business.service.common.BmaConstants;
import jp.co.nii.bma.utility.BmaUtility;
import jp.co.nii.sew.business.SystemTime;
import jp.co.nii.sew.business.service.AbstractService;
import jp.co.nii.sew.presentation.RequestTransferObject;
import jp.co.nii.sew.utility.CheckUtility;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFPrintSetup;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

/**
 *
 * @author nii07779
 */
public class ExcelTmpDlService extends AbstractService {
    Log log = LogFactory.getLog(this.getClass());
    private String fileName;
    private String tempFileName;
    OutputStream out;
    XSSFWorkbook workbook;
    XSSFSheet writeSheet;
    XSSFSheet tempSheet;
    public final static String VALUE_TYPE_CALENDER = "0";
    public final static String VALUE_TYPE_DATE = "1";
    public final static String VALUE_TYPE_RICHTEXTSTRING = "2";
    public final static String VALUE_TYPE_STRING = "3";
    public final static String VALUE_TYPE_BOOLEAN = "4";
    public final static String VALUE_TYPE_DOUBLE = "5";
    
    //DB�ڑ����̃��[�U�[������
    public ExcelTmpDlService() {
        super();
    }

    @Override
    public String doService(RequestTransferObject rto, RequestTransferObject rtoInSession) throws Exception {
        // �J�n���O
        log.info("ExcelTmpDlService, Start");

        FileDownLoad requestRTO = (FileDownLoad) rto;
        FileDownLoad sessionRTO = (FileDownLoad) rtoInSession;

        if (!BmaUtility.isNullOrEmpty(requestRTO.getJknJkuNoTmpDl())) {

            // �J�n���O
            log.info("outputExcelNumJkoJkn, Start");
            //�󌟎�u�ԍ��A�b�v���[�h��ʁ@�_�E�����[�h�{�^���������̏���

            //���l�[��
            //Excel�o��
            outputExcelNumJkoJkn(requestRTO);
            // �������O
            log.info("outputExcelNumJkoJkn, End");
            return DOWNLOAD;

        } else if (!BmaUtility.isNullOrEmpty(requestRTO.getGokakuNoTmpDl())) {

            // �J�n���O
            log.info("outputExcelGokakuNo, Start");
            //���i�ԍ��A�b�v���[�h��ʁ@�_�E�����[�h�{�^���������̏���
            //Excel�o��
            outputExcelGokakuNo(requestRTO);
            // �������O
            log.info("outputExcelGokakuNo, End");

            return DOWNLOAD;
        } else {
            return FWD_NM_SESSION;
        }
    }
    
    /**
     * �G�N�X�|�[�g�̏����������s��
     *
     * @param requestRTO
     * @throws Exception
     */
    public void initExport(FileDownLoad requestRTO) throws Exception {

        // �t�@�C���_�E�����[�h
        fileName = java.net.URLEncoder.encode(fileName, "UTF-8");
        requestRTO.setContentType("application/octet-stream");
        requestRTO.setHeader("Content-Disposition", "attachment;filename*=UTF-8''" + fileName);

        //xlsx��mime�^�C�v�ݒ�
        requestRTO.setContentType("application/vnd.ms-excel.sheet.macroEnabled.12");

        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        this.out = outputStream;
        this.workbook = new XSSFWorkbook(new FileInputStream(BmaConstants.EXCEL_TEMP_DIRECTORY + tempFileName));

        //�e���v���[�g�V�[�g���擾
        this.tempSheet = this.workbook.getSheetAt(0);

    }

    /**
     * �p���̌��������ɂ���
     */
    public void setUpPrintSideways() {
        //�p���̐ݒ�
        XSSFPrintSetup printSetting = this.tempSheet.getPrintSetup();
        //������
        printSetting.setLandscape(true);
        printSetting.setValidSettings(true);
    }

    /**
     * 1�s�̊e�Z���ɓ��͂��Ă��� �`�����w�肵�Đݒ�i������A���l�j
     *
     * @param clumnList�i1:�l�A2:�`���j
     * @param writeRowIndex
     * @param startWriteCellIndex
     * @param tempRowIndex
     */
    public void writeRowFormatSpecified(ArrayList<String[]> clumnList, int writeRowIndex, int startWriteCellIndex, int tempRowIndex) {
        Row rowTemp = this.tempSheet.getRow(tempRowIndex);
//        Row row = this.tempSheet.createRow(writeRowIndex);
        Row row = this.tempSheet.getRow(writeRowIndex);
        int cellIndex = startWriteCellIndex;
        for (String value[] : clumnList) {
            this.createCellFormatSpecified(rowTemp, row, cellIndex++, value);
        }
    }

    /**
     * �Z���Ƀe�L�X�g����͂��Ă����B�X�^�C���̓e���v���[�g����ݒ� �`�����w�肵�Đݒ�i������A���l�j
     *
     * @param rowTemp
     * @param row
     * @param column
     * @param value�i1:�l�A2:�`���j
     */
    private void createCellFormatSpecified(Row rowTemp, Row row, int column, String value[]) {
        CellStyle styleTemp = rowTemp.getCell(column).getCellStyle();
//        Cell cell = row.createCell(column);
        Cell cell = row.getCell(column);
        cell.setCellStyle(styleTemp);
        String columnValue = value[0];
        String columnType = value[1];
        if (columnValue.equals("")) {
            cell.setCellValue(columnValue);
        } else if (columnType.equals(VALUE_TYPE_STRING)) {
            cell.setCellValue(columnValue);
        } else if (columnType.equals(VALUE_TYPE_DOUBLE)) {
            if (CheckUtility.isNumber(columnValue)) {
                cell.setCellValue(Double.parseDouble(columnValue));
            } else {
                cell.setCellValue(columnValue);
            }
        } else {
            cell.setCellValue(columnValue);
        }
    }

    /**
     * �G�N�X�|�[�g���I������
     *
     * @param requestRTO
     * @throws Exception
     */
    public void closeExport(FileDownLoad requestRTO) throws Exception {
        try {
//            //�e���v���[�g�V�[�g���폜
//            this.workbook.removeSheetAt(0);
            //��������
            this.workbook.write(out);
            
            //FrontController�ɓn��InputStream�𐶐�
            ByteArrayOutputStream outputStream = (ByteArrayOutputStream) this.out;
            InputStream io = new ByteArrayInputStream(outputStream.toByteArray());
            requestRTO.setInputStream(io);
            
        } finally {
            if (out != null) {
                out.close();
            }
        }
    }
    
    /**
     * �󌟔ԍ��f�[�^�e���v���[�g��Excel�ŏo�͂���
     * @param requestRTO
     * @return
     * @throws Exception 
     */
    public boolean outputExcelNumJkoJkn(FileDownLoad requestRTO)
            throws Exception {
        boolean state = false;
        SystemTime systime = new SystemTime();

        try {
            //�o�̓t�@�C�����ݒ�i�^�C�g�����j
            String fileName = requestRTO.getSknKsuNameChi() + "_" + systime.getymd1() + systime.gethms1() + "_�󌟔ԍ��f�[�^" + BmaConstants.EXCEL_EXTENSION;
            //�g�p����e���v���[�g�t�@�C���ݒ�
            String tempFileName = BmaConstants.EXCEL_TEMP_FILE_NAME_NUM_JKO_JKN;
            this.fileName = fileName;
            this.tempFileName = tempFileName;
            //�����ݒ�
            initExport(requestRTO);

            //������^�C�g���s�̐ݒ�
            workbook.setRepeatingRowsAndColumns(1, -1, -1, 0, 3);
            //�p�����������Ɂi�^�C�g���s�ݒ�̌�łȂ��Ƃ��܂������Ȃ��j
            setUpPrintSideways();

            for (int i = 0; i < requestRTO.getResultDetailList().size(); i++) {
                Moshikomi moshikomi = requestRTO.getResultDetailList().get(i);
                //���ڂ��Z�b�g����
                int row = i + 4;
                ArrayList<String[]> columnValueList = new ArrayList<String[]>();
                String[] value = new String[2];
                value[0] = moshikomi.getSknKsuCode();
                value[1] = VALUE_TYPE_STRING;
                columnValueList.add(value);
                value = new String[2];
                value[0] = String.valueOf(moshikomi.getShubetsuCode());
                value[1] = VALUE_TYPE_STRING;
                columnValueList.add(value);
                value = new String[2];
                value[0] = String.valueOf(moshikomi.getKaisuCode());
                value[1] = VALUE_TYPE_STRING;
                columnValueList.add(value);
                value = new String[2];
                value[0] = String.valueOf(moshikomi.getNendo());
                value[1] = VALUE_TYPE_STRING;
                columnValueList.add(value);
                value = new String[2];
                value[0] = String.valueOf(moshikomi.getUketsukeNo());
                value[1] = VALUE_TYPE_STRING;
                columnValueList.add(value);
                value = new String[2];
                value[0] = String.valueOf(moshikomi.getShimei());
                value[1] = VALUE_TYPE_STRING;
                columnValueList.add(value);

                //1�s��������
                writeRowFormatSpecified(columnValueList, i + 3, 2, row);

            }

            closeExport(requestRTO);

            state = true;
        } catch (Exception e) {
//            response.reset();
//            response.sendError(HttpURLConnection.HTTP_INTERNAL_ERROR, e.toString());
            throw e;

        } finally {
        }
        return state;
    }
    
    
    
    /**
     * ���i�ԍ��f�[�^�e���v���[�g��Excel�ŏo�͂���
     * @param requestRTO
     * @return
     * @throws Exception 
     */
    public boolean outputExcelGokakuNo(FileDownLoad requestRTO)
            throws Exception {
        boolean state = false;
        SystemTime systime = new SystemTime();

        try {
            //�o�̓t�@�C�����ݒ�i�^�C�g�����j
            String fileName = requestRTO.getSknKsuNameChi() + "_" + systime.getymd1() + systime.gethms1() + "_���i�ԍ��f�[�^" + BmaConstants.EXCEL_EXTENSION;
            //�g�p����e���v���[�g�t�@�C���ݒ�
            String tempFileName = BmaConstants.EXCEL_TEMP_FILE_NAME_NUM_GOKAKU;
            this.fileName = fileName;
            this.tempFileName = tempFileName;
            //�����ݒ�
            initExport(requestRTO);

            //������^�C�g���s�̐ݒ�
            workbook.setRepeatingRowsAndColumns(1, -1, -1, 0, 3);
            //�p�����������Ɂi�^�C�g���s�ݒ�̌�łȂ��Ƃ��܂������Ȃ��j
            setUpPrintSideways();

            for (int i = 0; i < requestRTO.getResultDetailList().size(); i++) {
                Moshikomi moshikomi = requestRTO.getResultDetailList().get(i);
                //���ڂ��Z�b�g����
                int row = i + 4;

                ArrayList<String[]> columnValueList = new ArrayList<String[]>();
                String[] value = new String[2];
                value[0] = moshikomi.getSknKsuCode();
                value[1] = VALUE_TYPE_STRING;
                columnValueList.add(value);
                value = new String[2];
                value[0] = String.valueOf(moshikomi.getShubetsuCode());
                value[1] = VALUE_TYPE_STRING;
                columnValueList.add(value);
                value = new String[2];
                value[0] = String.valueOf(moshikomi.getKaisuCode());
                value[1] = VALUE_TYPE_STRING;
                columnValueList.add(value);
                value = new String[2];
                value[0] = String.valueOf(moshikomi.getNendo());
                value[1] = VALUE_TYPE_STRING;
                columnValueList.add(value);
                value = new String[2];
                value[0] = String.valueOf(moshikomi.getJukenJukoNo());
                value[1] = VALUE_TYPE_STRING;
                columnValueList.add(value);
                value = new String[2];
                value[0] = String.valueOf(moshikomi.getShimei());
                value[1] = VALUE_TYPE_STRING;
                columnValueList.add(value);

                //1�s��������
                writeRowFormatSpecified(columnValueList, i + 3, 2, row);

            }

            closeExport(requestRTO);

            state = true;
        } catch (Exception e) {
//            response.reset();
//            response.sendError(HttpURLConnection.HTTP_INTERNAL_ERROR, e.toString());
            throw e;

        } finally {
        }
        return state;
    }
    
}
