package jp.co.nii.bma.business.service.manager;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import jp.co.nii.bma.business.domain.HanyoKensakuDtlJkn;
import jp.co.nii.bma.business.domain.HanyoKensakuHedJkn;
import jp.co.nii.bma.business.domain.Torokusha;
import jp.co.nii.bma.business.domain.MeishoKanri;
import jp.co.nii.bma.business.domain.Saiban;
import jp.co.nii.bma.business.domain.Schedule;
import jp.co.nii.bma.business.rto.manager.HanyouSearchJoho;
import jp.co.nii.bma.business.service.common.BmaConstants;
import jp.co.nii.bma.business.service.common.BmaLogger;
import jp.co.nii.bma.business.service.common.BmaSaibanService;
import jp.co.nii.bma.business.service.common.BmaValidator;
import jp.co.nii.bma.presentation.common.BmaText;
import jp.co.nii.bma.utility.BmaStringUtility;
import jp.co.nii.bma.utility.BmaUtility;
import jp.co.nii.sew.business.SystemTime;
import jp.co.nii.sew.business.Validator;
import jp.co.nii.sew.business.service.AbstractService;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_SESSION;
import jp.co.nii.sew.presentation.Messages;
import jp.co.nii.sew.presentation.Option;
import jp.co.nii.sew.presentation.RequestTransferObject;
import jp.co.nii.sew.utility.PropertyUtility;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.validator.GenericValidator;

/**
 * <p>
 * �^�C�g��: �ėp������ʃT�[�r�X</p>
 * <p>
 * ����: �ėp������ʃT�[�r�X</p>
 * <p>
 * ���쌠: Copyright (c) 2020</p>
 * <p>
 * ��Ж�: ���{���Y�Ɗ������</p>
 */
public class HanyouSearchThisYearService extends AbstractService {

    /**
     * DB�ڑ��̃f�[�^�\�[�X
     */
    private static String DATA_SOURCE_NAME;
    /**
     * ���O
     */
    BmaLogger log = (BmaLogger) BmaLogger.getLogger(this.getClass().getName());
    /**
     * �Ɩ��R�[�h
     */
    private static final String BUSINESS_CODE = PropertyUtility.getProperty("business_code");
    /**
     * ���׃e�X�g���[�h
     */
    private static final String STRESS_MODE = PropertyUtility.getProperty(BUSINESS_CODE + "stress_mode");

    /**
     * �R���X�g���N�^
     */
    public HanyouSearchThisYearService() {
        super();
        /* DB�ڑ����̃��[�U�[������ */
        DATA_SOURCE_NAME = BmaConstants.DS_REGISTRANT;
    }

    /**
     * �T�[�r�X�N���X�̎��s���\�b�h
     *
     * @param rto ���N�G�X�g��񂩂�擾����rto
     * @param rtoinSession �Z�b�V�������rto
     * @return foward��
     * @throws Exception ��O
     */
    @Override
    public String doService(RequestTransferObject rto, RequestTransferObject rtoinSession)
            throws Exception {

        HanyouSearchJoho inRequest = (HanyouSearchJoho) rto;
        HanyouSearchJoho inSession = (HanyouSearchJoho) rtoinSession;
        String processName = "";

        /*�G���[���b�Z�[�W������*/
        inSession.setErrors(new Messages());

        try {
            if (!BmaUtility.isNullOrEmpty(inRequest.getInpClear())) {
                processName = "inpClear";

                log.Start(processName);
                /*��ʃ��Z�b�g*/
                inSession.clearInfo();
                inSession.clearInfoHairetu();

                return FWD_NM_RELOAD;
            } else if (!BmaUtility.isNullOrEmpty(inRequest.getHanyouSearchWhe())) {
                /*�����{�^��������*/
                processName = "hanyouSearchWhe";
                log.Start(processName);

                String forword = "";

                List<Option> list;
                /* ���̊Ǘ��I�u�W�F�N�g�擾 */
                MeishoKanri meisho = new MeishoKanri(DATA_SOURCE_NAME);
                /*�^�p�󋵃��X�g�擾*/
                list = new ArrayList<>();
                meisho.findByGroupCode(BmaConstants.UNYO_JOKYO_KBN, list);
                inSession.setUnyouList(list);

                // ���̓f�[�^���Z�b�V�����f�[�^�ɃZ�b�g
                HanyouSearchJoho taihi = new HanyouSearchJoho();
                setValueRequestToTaihi(inRequest, inSession, taihi);
                inSession.setTaihi(taihi);

                // ���̓f�[�^���Z�b�V�����f�[�^�ɃZ�b�g����
                setValueRequestToSession(inRequest, inSession);

                /*���̓`�F�b�N*/
                boolean retCheck = ValidatorSearch(inRequest, inSession);

                // ��肪�Ȃ���� true
                if (!retCheck) {
                    return FWD_NM_RELOAD;
                }
                // �N�x�̐ݒu
                /* �ϐ������� */
                Schedule schedule = new Schedule(DATA_SOURCE_NAME);
                String nendo = "";
                String sknKsuCode = "";
                String shubetsuCode = "";
                String kaisuCode = "";
                if (inRequest.getSknName() != null && inRequest.getSknName().length() >= 6) {
                    /* �e�R�[�h���Z�b�V�����ɕێ� */
                    if (BmaConstants.SKN_KBN.equals(inRequest.getSknksuKbn())) {
                        sknKsuCode = inRequest.getSknName().substring(0, 2);
                        shubetsuCode = inRequest.getSknName().substring(2, 4);
                        kaisuCode = inRequest.getSknName().substring(4, 6);
                    } else if (BmaConstants.KSU_KBN.equals(inRequest.getSknksuKbn())) {
                        sknKsuCode = inRequest.getKsuName().substring(0, 2);
                        shubetsuCode = inRequest.getKsuName().substring(2, 4);
                        kaisuCode = inRequest.getKsuName().substring(4, 6);
                    }
                }
                //�N�x �X�P�W���[�������J�n���̍ŐV�N�x���擾
                nendo = schedule.findNendoKojiKikan(sknKsuCode, shubetsuCode, kaisuCode, BmaConstants.SCHED_CODE_OPEN, BmaConstants.SCHEDULE_KBN_ST);
                inRequest.setNendoFrm(nendo);
                inRequest.setNendoTo(nendo);

                /* ���X�g��������t�ԍ��̃f�[�^�𒊏o */
                Torokusha torokusha = new Torokusha(DATA_SOURCE_NAME);
                List<HanyouSearchJoho> allList = torokusha.findHanyouList(inRequest, inSession);
                inSession.setHanyouAllList(allList);

                // ��肪�Ȃ���� true
                if (retCheck && !allList.isEmpty()) {
                    /* �������������� */
                    clearSearchInput(inSession);
                    // �߂�{�^���p�t���O
                    inSession.setBackFlag("1");
                    // �y�[�W����
                    inSession.setPage(0);
                    setPage(inSession);
                    setDisplayList(inSession);

                    forword = FWD_NM_NEXT;
                } else {
                    if (allList.isEmpty()) {
                        Messages errors = new Messages();
                        BmaValidator.addMessage(errors, "info", BmaText.M00034, "");
                        inSession.setErrors(errors);
                    }
                    forword = FWD_NM_RELOAD;
                }
                /* ����������ʍĕ\�� */
                return forword;
            } else if (!BmaUtility.isNullOrEmpty(inRequest.getSearchChange())
                    && BmaUtility.isNullOrEmpty(inRequest.getTempSave()) && BmaUtility.isNullOrEmpty(inRequest.getTempUpdate())) {

                /*�����e���v���[�g�I��*/
                processName = "searchChange";
                log.Start(processName);

                inSession.clearInfo();

                String value = inRequest.getSearchChange();
                if ("�I��".equals(value)) {
                    // ���� �u�K��̑I��
                    inSession.setSknksuKbn("1");
                    // ����
                    inSession.setSknName(BmaConstants.SKN_CHECK);
                    // �u�K��
                    inSession.setKsuName(BmaConstants.KSU_CHECK);

                    /*��ʃ��Z�b�g*/
                    inSession.clearInfo();
                    inSession.clearInfoHairetu();
                } else {
                    inSession.setUpdateFlag("1");

                    inSession.setSrcTempNo(value);
                    // �ڍׂ�������擾���A��ʂɃZ�b�g����
                    setDtlJknList(inSession, value);
                }
                return FWD_NM_RELOAD;
            } else if (!BmaUtility.isNullOrEmpty(inRequest.getTempSave())) {
                /*���������e���v���[�g�ۑ��{�^��������*/
                processName = "tempSave";
                log.Start(processName);

                inSession.setUserId(inRequest.getUserId());
                // ���̓f�[�^���Z�b�V�����f�[�^�ɃZ�b�g����
                setValueRequestToSession(inRequest, inSession);

                String SearchChange = inRequest.getSearchChange();

                /*���̓`�F�b�N*/
                boolean retCheck = ValidatorSearch(inRequest, inSession);
                inSession.setSrcTempNo(SearchChange);

                // ��肪�Ȃ���� true
                if (retCheck) {
                    //�̔ԃf�[�^�擾
                    Saiban saiban = new BmaSaibanService(DATA_SOURCE_NAME).
                            getSaibanAndUpdateForKeta(BmaConstants.SAIBAN_HANYOKENSAKUHEDJKN_IDX, inSession.getUserId());
                    String hanyoKensakuIndex = "";
                    if (saiban != null) {
                        hanyoKensakuIndex = saiban.getGenzaiNo();
                    }

                    try {
                        //�g�����U�N�V�����J�n
                        getTransaction();
                        beginTransaction();

                        // �ėp�w�b�_�[�e�[�u���ɓo�^����
                        insertHanyoKensakuHedJkn(inSession, hanyoKensakuIndex);

                        // �ėp�ڍ׃e�[�u���ɓo�^����
                        insertAllDtl(inRequest, inSession, hanyoKensakuIndex);

                        commitTransaction();

                        Messages errors = new Messages();
                        BmaValidator.addMessage(errors, "info", "�ėp�����w�b�_�[,�ڍ׃e�[�u���ɏ�����o�^���܂���", "");
                        inSession.setErrors(errors);

                    } catch (Exception e) {
                        rollbackTransaction();
                        log.info("�ėp�ڍ׃e�[�u�������ŗ�O������", e);
                    }
                }
                /* ��ʕ\�� */
                return FWD_NM_RELOAD;

            } else if (!BmaUtility.isNullOrEmpty(inRequest.getTempUpdate())) {
                /*���������e���v���[�g�X�V�{�^��������*/
                processName = "tempUpdate";
                log.Start(processName);

                inSession.setUserId(inRequest.getUserId());

                String SearchChange = inRequest.getSearchChange();
                // ���̓f�[�^���Z�b�V�����f�[�^�ɃZ�b�g����
                setValueRequestToSession(inRequest, inSession);

                inSession.setSrcTempNo(SearchChange);

                /*���̓`�F�b�N*/
                boolean retCheck = ValidatorSearch(inRequest, inSession);

                // ��肪�Ȃ���� true
                if (retCheck) {
                    String hanyoKensakuIndex = inRequest.getSearchChange();

                    try {
                        //�g�����U�N�V�����J�n
                        getTransaction();
                        beginTransaction();

                        // �ėp�ڍ׃e�[�u���ɍX�V����
                        updateAllDtl(inSession, hanyoKensakuIndex);

                        commitTransaction();

                        Messages errors = new Messages();
                        BmaValidator.addMessage(errors, "info", "�ėp�����ڍ׃e�[�u���ɏ������X�V���܂���", "");
                        inSession.setErrors(errors);

                    } catch (Exception e) {
                        rollbackTransaction();
                        log.info("�ėp�ڍ׃e�[�u�������ŗ�O������", e);
                    }
                }
                /* �������ʈꗗ��ʕ\�� */
                return FWD_NM_RELOAD;
            } else {
                /*�ُ�J��*/
                log.IllegalFWD();
                return FWD_NM_SESSION;
            }
        } catch (Exception e) {
            throw e;
        } finally {
            log.End(processName);
        }
    }

    /**
     * �ėp�w�b�_�[�e�[�u���ɓo�^����B
     *
     * @param inSession ���N�G�X�g
     * @param hanyoKensakuIdJkn
     */
    public void insertHanyoKensakuHedJkn(HanyouSearchJoho inSession, String hanyoKensakuIdJkn) {
        String userId = inSession.getUserId();

        SystemTime sysTim = new SystemTime();

        //���[���e���v���[�g�@�I�u�W�F�N�g�쐬
        HanyoKensakuHedJkn kensakuHedJknJoho = new HanyoKensakuHedJkn(DATA_SOURCE_NAME);

        kensakuHedJknJoho.setHanyoKensakuIdJkn(hanyoKensakuIdJkn);

        String tempNoDisp = inSession.getTempletSave();
        kensakuHedJknJoho.setHanyoKensakuName(tempNoDisp);

        //�_���폜�t���O���Z�b�g
        kensakuHedJknJoho.setRonriSakujoFlg(BmaConstants.FLG_OFF);
        //�����敪
        kensakuHedJknJoho.setKoshinKbn(BmaConstants.SHORI_KBN_INSERT);

        //�o�^�����E�o�^��
        kensakuHedJknJoho.setTorokuDate(sysTim.getymd1());
        kensakuHedJknJoho.setTorokuTime(sysTim.gethms1());

        kensakuHedJknJoho.setTorokuUserId(userId);

        //�X�V�����E�X�V��
        kensakuHedJknJoho.setKoshinDate(sysTim.getymd1());
        kensakuHedJknJoho.setKoshinTime(sysTim.gethms1());
        kensakuHedJknJoho.setKoshinUserId(userId);

        //�o�^
        kensakuHedJknJoho.create();
    }

    /**
     * �ėp�ڍ׃e�[�u���ɓo�^����B
     *
     * @param search ���N�G�X�g
     *
     * @return �����ꍇ�Ftrue;���s�Ffalse
     */
    private void insertAllDtl(HanyouSearchJoho inRequest, HanyouSearchJoho search, String hanyoKensakuIndex) {

        int allLineCount = 0;
        if (search.getSknksuKbn().equals(BmaConstants.SKN_KBN) || search.getSknksuKbn().equals(BmaConstants.KSU_KBN)) {
            insertOneLineDtlJkn(search, hanyoKensakuIndex, 1, "SKN_KSU_KBN", 1, search.getSknksuKbn());
        }
        // �����̏ꍇ
        if (!search.getSknName().isEmpty() && search.getSknksuKbn().equals(BmaConstants.SKN_KBN)) {
            String sknksucode = search.getSknName().substring(0, 2);
            String shubetsucode = search.getSknName().substring(2, 4);
            String kaisucode = search.getSknName().substring(4, 6);

            int count = 0;
            count++;
            insertOneLineDtlJkn(search, hanyoKensakuIndex, 2, "SKN_NM", count, sknksucode);

            count++;
            insertOneLineDtlJkn(search, hanyoKensakuIndex, 3, "SKN_NM", count, shubetsucode);

            count++;
            insertOneLineDtlJkn(search, hanyoKensakuIndex, 4, "SKN_NM", count, kaisucode);

        } // �u�K��̏ꍇ
        else if (!search.getKsuName().isEmpty() && search.getSknksuKbn().equals(BmaConstants.KSU_KBN)) {
            String sknksucode = search.getKsuName().substring(0, 2);
            String shubetsucode = search.getKsuName().substring(2, 4);
            String kaisucode = search.getKsuName().substring(4, 6);

            int count = 0;
            count++;
            insertOneLineDtlJkn(search, hanyoKensakuIndex, 5, "KSU_NM", count, sknksucode);

            count++;
            insertOneLineDtlJkn(search, hanyoKensakuIndex, 6, "KSU_NM", count, shubetsucode);

            count++;
            insertOneLineDtlJkn(search, hanyoKensakuIndex, 7, "KSU_NM", count, kaisucode);
        }
        // �N�x
        if (!search.getNendoFrm().isEmpty() && !search.getNendoTo().isEmpty()) {
            int count = 0;
            count++;
            insertOneLineDtlJkn(search, hanyoKensakuIndex, 8, "NENDO_FRM", count, search.getNendoFrm());

            count++;
            insertOneLineDtlJkn(search, hanyoKensakuIndex, 9, "NENDO_TO", count, search.getNendoTo());

        }
        // �t���K�i
        if (!search.getFurigana().isEmpty()) {
            int count = 0;
            count++;
            insertOneLineDtlJkn(search, hanyoKensakuIndex, 10, "FURIGANA", count, search.getFurigana());
        }
        // ���N����
        if (!search.getBirthYear().isEmpty() && !search.getBirthMonth().isEmpty() && !search.getBirthDay().isEmpty()) {
            String birthy = search.getBirthYear() + search.getBirthMonth() + search.getBirthDay();
            int count = 0;
            count++;
            insertOneLineDtlJkn(search, hanyoKensakuIndex, 11, "BIRTHDAY", count, birthy);
        }
        // ����敪
        if (search.getKaiinKbn() != null) {
            int count = 0;
            count++;
            insertOneLineDtlJkn(search, hanyoKensakuIndex, 12, "KAIIN_KBN", count, search.getKaiinKbn());
        }
        // ��ƃR�[�h
        if (!search.getKigyocode().isEmpty()) {
            int count = 0;
            count++;
            insertOneLineDtlJkn(search, hanyoKensakuIndex, 13, "KIGYOCODE", count, search.getKigyocode());
        }
        // �Ζ��於
        if (!search.getKinmusakiName().isEmpty()) {
            int count = 0;
            count++;
            insertOneLineDtlJkn(search, hanyoKensakuIndex, 14, "KINMUSAKI_NAME", count, search.getKinmusakiName());
        }
        // �ԍ�����
        String key = search.getBangoInput();
        // �ԍ��I��
        if (search.getBangoNyuryoku() != null) {
            int count = 0;
            count++;
            insertOneLineDtlJkn(search, hanyoKensakuIndex, 15, "BANGO_NYURYOKU", count, search.getBangoNyuryoku());
        }

        // �������e
        List<Option> tmp = search.getShikennaiyoList();
        List<String> shikennaiyo = null;
        if (search.getShikennaiyo() != null) {
            shikennaiyo = Arrays.asList(search.getShikennaiyo());
        }
        if (shikennaiyo != null) {
            if (shikennaiyo.size() > 0) {
                allLineCount = 15;
                for (int j = 0; j < tmp.size(); j++) {
                    allLineCount++;
                    String fromList = tmp.get(j).getValue();
                    if (shikennaiyo.contains(fromList)) {
                        insertOneLineDtlJkn(search, hanyoKensakuIndex, allLineCount, "SHIKEN_NAIYO", j + 1, fromList);
                    } else {
                        insertOneLineDtlJkn(search, hanyoKensakuIndex, allLineCount, "SHIKEN_NAIYO", j + 1, "");
                    }
                }
            }
        }

        // �\�����@22
        List<Option> tmp1 = search.getMoshikomiKbnList();
        List<String> moshikomiKbn = null;
        if (search.getMoshikomiKbn() != null) {
            moshikomiKbn = Arrays.asList(search.getMoshikomiKbn());
        }

        if (moshikomiKbn != null) {
            if (moshikomiKbn.size() > 0) {
                for (int j = 0; j < tmp1.size(); j++) {
                    allLineCount++;
                    String fromList = tmp1.get(j).getValue();
                    if (moshikomiKbn.contains(fromList)) {
                        insertOneLineDtlJkn(search, hanyoKensakuIndex, allLineCount, "MOSHIKOMI_HOHO", j + 1, fromList);
                    } else {
                        insertOneLineDtlJkn(search, hanyoKensakuIndex, allLineCount, "MOSHIKOMI_HOHO", j + 1, "");
                    }
                }
            }
        }

        // �\���敪
        List<Option> tmp2 = search.getKojinDantaiKbnList();
        List<String> kojinDantaiKbn = null;
        if (search.getKojinDantaiKbn() != null) {
            kojinDantaiKbn = Arrays.asList(search.getKojinDantaiKbn());
        }
        if (kojinDantaiKbn != null) {
            if (kojinDantaiKbn.size() > 0) {
                for (int j = 0; j < tmp2.size(); j++) {
                    allLineCount++;
                    String fromList = tmp2.get(j).getValue();
                    if (kojinDantaiKbn.contains(fromList)) {
                        insertOneLineDtlJkn(search, hanyoKensakuIndex, allLineCount, "MOSHIKOMI_KBN", j + 1, fromList);
                    } else {
                        insertOneLineDtlJkn(search, hanyoKensakuIndex, allLineCount, "MOSHIKOMI_KBN", j + 1, "");
                    }
                }
            }
        }

        // �\����
        List<Option> tmp3 = search.getMoshikomiJokyoKbnList();
        List<String> moshikomiJokyoKbn = null;
        if (search.getMoshikomiJokyoKbn() != null) {
            moshikomiJokyoKbn = Arrays.asList(search.getMoshikomiJokyoKbn());
        }
        if (moshikomiJokyoKbn != null) {
            if (moshikomiJokyoKbn.size() > 0) {
                for (int j = 0; j < tmp3.size(); j++) {
                    allLineCount++;
                    String fromList = tmp3.get(j).getValue();
                    if (moshikomiJokyoKbn.contains(fromList)) {
                        insertOneLineDtlJkn(search, hanyoKensakuIndex, allLineCount, "MOSHIKOMI_JOKYO", j + 1, fromList);
                    } else {
                        insertOneLineDtlJkn(search, hanyoKensakuIndex, allLineCount, "MOSHIKOMI_JOKYO", j + 1, "");
                    }
                }
            }
        }

        // �z���\�� ComUmFlg
        List<Option> tmp4 = search.getHairyoFlgList();
        List<String> comUmFlg = null;
        if (search.getComUmFlg() != null) {
            comUmFlg = Arrays.asList(search.getComUmFlg());
        }
        if (comUmFlg != null) {
            if (comUmFlg.size() > 0) {
                for (int j = 0; j < tmp4.size(); j++) {
                    allLineCount++;
                    String fromList = tmp4.get(j).getValue();
                    if (comUmFlg.contains(fromList)) {
                        insertOneLineDtlJkn(search, hanyoKensakuIndex, allLineCount, "HAIRYO_SHINSEI", j + 1, fromList);
                    } else {
                        insertOneLineDtlJkn(search, hanyoKensakuIndex, allLineCount, "HAIRYO_SHINSEI", j + 1, "");
                    }
                }
            }
        }

        // ����t��
        String KariuketsukeBiFrom = "";
        String KariuketsukeBiTo = "";
        if (!search.getKariuketsukeBiFromYear().isEmpty() && !search.getKariuketsukeBiFromMonth().isEmpty() && !search.getKariuketsukeBiFromDay().isEmpty()) {
            KariuketsukeBiFrom = search.getKariuketsukeBiFromYear() + search.getKariuketsukeBiFromMonth() + search.getKariuketsukeBiFromDay();
            int count = 0;
            allLineCount++;
            count++;
            insertOneLineDtlJkn(search, hanyoKensakuIndex, allLineCount, "KARIUKETSUKE_BI_FROM", count, KariuketsukeBiFrom);

        }
        if (!search.getKariuketsukeBiToYear().isEmpty() && !search.getKariuketsukeBiToMonth().isEmpty() && !search.getKariuketsukeBiToDay().isEmpty()) {
            KariuketsukeBiTo = search.getKariuketsukeBiToYear() + search.getKariuketsukeBiToMonth() + search.getKariuketsukeBiToDay();
            int count = 0;
            allLineCount++;
            count++;
            insertOneLineDtlJkn(search, hanyoKensakuIndex, allLineCount, "KARIUKETSUKE_BI_TO", count, KariuketsukeBiTo);
        }

        // �\��(����)������
        String MoshikomikanryoBiFrom = "";
        String MoshikomikanryoBiTo = "";
        if (!search.getMoshikomikanryoBiFromYear().isEmpty() && !search.getMoshikomikanryoBiFromMonth().isEmpty() && !search.getMoshikomikanryoBiFromDay().isEmpty()) {
            MoshikomikanryoBiFrom = search.getMoshikomikanryoBiFromYear() + search.getMoshikomikanryoBiFromMonth() + search.getMoshikomikanryoBiFromDay();
            int count = 0;
            allLineCount++;
            count++;
            insertOneLineDtlJkn(search, hanyoKensakuIndex, allLineCount, "MOSHIKOMIKANRYO_BI_FROM", count, MoshikomikanryoBiFrom);
        }
        if (!search.getMoshikomikanryoBiToYear().isEmpty() && !search.getMoshikomikanryoBiToMonth().isEmpty() && !search.getMoshikomikanryoBiToDay().isEmpty()) {
            MoshikomikanryoBiTo = search.getMoshikomikanryoBiToYear() + search.getMoshikomikanryoBiToMonth() + search.getMoshikomikanryoBiToDay();
            int count = 0;
            allLineCount++;
            count++;
            insertOneLineDtlJkn(search, hanyoKensakuIndex, allLineCount, "MOSHIKOMIKANRYO_BI_TO", count, MoshikomikanryoBiTo);

        }

        // ���ϕ��@
        List<Option> tmp5 = search.getKessaiHohoList();
        List<String> kessaiHoho = null;
        if (search.getKessaiHoho() != null) {
            kessaiHoho = Arrays.asList(search.getKessaiHoho());
        }
        if (kessaiHoho != null) {
            if (kessaiHoho.size() > 0) {
                for (int j = 0; j < tmp5.size(); j++) {
                    allLineCount++;
                    String fromList = tmp5.get(j).getValue();
                    if (kessaiHoho.contains(fromList)) {
                        insertOneLineDtlJkn(search, hanyoKensakuIndex, allLineCount, "KESSAI_HOHO", j + 1, fromList);
                    } else {
                        insertOneLineDtlJkn(search, hanyoKensakuIndex, allLineCount, "KESSAI_HOHO", j + 1, "");
                    }
                }
            }
        }

        // ���Ϗ�
        List<Option> tmp6 = search.getKessaiJokyoKbnList();
        List<String> kessaiJokyoKbn = null;
        if (search.getKessaiJokyoKbn() != null) {
            kessaiJokyoKbn = Arrays.asList(search.getKessaiJokyoKbn());
        }
        if (kessaiJokyoKbn != null) {
            if (kessaiJokyoKbn.size() > 0) {
                for (int j = 0; j < tmp6.size(); j++) {
                    allLineCount++;
                    String fromList = tmp6.get(j).getValue();
                    if (kessaiJokyoKbn.contains(fromList)) {
                        insertOneLineDtlJkn(search, hanyoKensakuIndex, allLineCount, "KESSAI_JOKYO", j + 1, fromList);
                    } else {
                        insertOneLineDtlJkn(search, hanyoKensakuIndex, allLineCount, "KESSAI_JOKYO", j + 1, "");
                    }
                }
            }
        }

        // �摜�␳�˗���
        List<Option> tmp7 = search.getHoseiIraiKbnList();
        List<String> hoseiIraiKbn = null;
        if (search.getHoseiIraiKbn() != null) {
            hoseiIraiKbn = Arrays.asList(search.getHoseiIraiKbn());
        }
        if (hoseiIraiKbn != null) {
            if (hoseiIraiKbn.size() > 0) {
                for (int j = 0; j < tmp7.size(); j++) {
                    allLineCount++;
                    String fromList = tmp7.get(j).getValue();
                    if (hoseiIraiKbn.contains(fromList)) {
                        insertOneLineDtlJkn(search, hanyoKensakuIndex, allLineCount, "HOSEI_IRAI_KBN", j + 1, fromList);
                    } else {
                        insertOneLineDtlJkn(search, hanyoKensakuIndex, allLineCount, "HOSEI_IRAI_KBN", j + 1, "");
                    }

                }
            }
        }

        // ���ۏ�
        List<Option> tmp8 = search.getGohiJokyoKbnList();
        List<String> gohiJokyoKbn = null;
        if (search.getGohiJokyoKbn() != null) {
            gohiJokyoKbn = Arrays.asList(search.getGohiJokyoKbn());
        }
        if (gohiJokyoKbn != null) {
            if (gohiJokyoKbn.size() > 0) {
                for (int j = 0; j < tmp8.size(); j++) {
                    allLineCount++;
                    String fromList = tmp8.get(j).getValue();
                    if (gohiJokyoKbn.contains(fromList)) {
                        insertOneLineDtlJkn(search, hanyoKensakuIndex, allLineCount, "GOHI_JOKYO", j + 1, fromList);
                    } else {
                        insertOneLineDtlJkn(search, hanyoKensakuIndex, allLineCount, "GOHI_JOKYO", j + 1, "");
                    }

                }
            }
        }
    }

    /**
     * �ėp�ڍ׃e�[�u���Ɉ�s�f�[�^��o�^����B
     *
     * @param inSession ���N�G�X�g
     * @param hanyoKensakuIdJkn
     * @param meisaiGyoNo
     * @param jokenKomokuId
     * @param jokenGyoNo
     */
    public void insertOneLineDtlJkn(HanyouSearchJoho inSession, String hanyoKensakuIdJkn,
            int meisaiGyoNo, String jokenKomokuId, int jokenGyoNo, String jokenChi) {

        String userId = inSession.getUserId();
        if (userId == null) {
            userId = "";
        }
        SystemTime sysTim = new SystemTime();

        //���[���e���v���[�g�@�I�u�W�F�N�g�쐬
        HanyoKensakuDtlJkn kensakuDtlJknJoho = new HanyoKensakuDtlJkn(DATA_SOURCE_NAME);

        kensakuDtlJknJoho.setHanyoKensakuIdJkn(hanyoKensakuIdJkn);

        kensakuDtlJknJoho.setMeisaiGyoNo(String.valueOf(meisaiGyoNo));
        kensakuDtlJknJoho.setJokenKomokuId(jokenKomokuId);
        kensakuDtlJknJoho.setJokenGyoNo(String.valueOf(jokenGyoNo));
        kensakuDtlJknJoho.setJokenChi(jokenChi);

        //�_���폜�t���O���Z�b�g
        kensakuDtlJknJoho.setRonriSakujoFlg(BmaConstants.FLG_OFF);
        //�����敪
        kensakuDtlJknJoho.setKoshinKbn(BmaConstants.SHORI_KBN_INSERT);

        //�o�^�����E�o�^��
        kensakuDtlJknJoho.setTorokuDate(sysTim.getymd1());
        kensakuDtlJknJoho.setTorokuTime(sysTim.gethms1());

        kensakuDtlJknJoho.setTorokuUserId(userId);

        //�X�V�����E�X�V��
        kensakuDtlJknJoho.setKoshinDate(sysTim.getymd1());
        kensakuDtlJknJoho.setKoshinTime(sysTim.gethms1());
        kensakuDtlJknJoho.setKoshinUserId(userId);

        //�o�^
        kensakuDtlJknJoho.create();
    }

    /**
     * �ėp�ڍ׃e�[�u���ɓo�^����B
     *
     * @param search ���N�G�X�g
     *
     * @return �����ꍇ�Ftrue;���s�Ffalse
     */
    private void updateAllDtl(HanyouSearchJoho search, String hanyoKensakuIndex) throws Exception {

        int allLineCount = 1;
        try {
            if (search.getSknksuKbn().equals(BmaConstants.SKN_KBN) || search.getSknksuKbn().equals(BmaConstants.KSU_KBN)) {
                updateOneLineDtlJkn(search, hanyoKensakuIndex, 1, "SKN_KSU_KBN", 1, search.getSknksuKbn());
            }
            // �����̏ꍇ
            if (!search.getSknName().isEmpty() && search.getSknksuKbn().equals(BmaConstants.SKN_KBN)) {
                String sknksucode = search.getSknName().substring(0, 2);
                String shubetsucode = search.getSknName().substring(2, 4);
                String kaisucode = search.getSknName().substring(4, 6);

                int count = 0;
                count++;
                updateOneLineDtlJkn(search, hanyoKensakuIndex, 2, "SKN_NM", count, sknksucode);

                count++;
                updateOneLineDtlJkn(search, hanyoKensakuIndex, 3, "SKN_NM", count, shubetsucode);

                count++;
                updateOneLineDtlJkn(search, hanyoKensakuIndex, 4, "SKN_NM", count, kaisucode);

            } // �u�K��̏ꍇ
            else if (!search.getKsuName().isEmpty() && search.getSknksuKbn().equals(BmaConstants.KSU_KBN)) {
                String sknksucode = search.getKsuName().substring(0, 2);
                String shubetsucode = search.getKsuName().substring(2, 4);
                String kaisucode = search.getKsuName().substring(4, 6);

                int count = 0;
                count++;
                updateOneLineDtlJkn(search, hanyoKensakuIndex, 5, "KSU_NM", count, sknksucode);

                count++;
                updateOneLineDtlJkn(search, hanyoKensakuIndex, 6, "KSU_NM", count, shubetsucode);

                count++;
                updateOneLineDtlJkn(search, hanyoKensakuIndex, 7, "KSU_NM", count, kaisucode);
            }
            // �N�x
            if (!search.getNendoFrm().isEmpty() && !search.getNendoTo().isEmpty()) {
                int count = 0;
                count++;
                updateOneLineDtlJkn(search, hanyoKensakuIndex, 8, "NENDO_FRM", count, search.getNendoFrm());

                count++;
                updateOneLineDtlJkn(search, hanyoKensakuIndex, 9, "NENDO_TO", count, search.getNendoTo());

            }
            // �t���K�i
            if (!search.getFurigana().isEmpty()) {
                int count = 0;

                count++;
                updateOneLineDtlJkn(search, hanyoKensakuIndex, 10, "FURIGANA", count, search.getFurigana());
            }
            // ���N����
            if (!search.getBirthYear().isEmpty() && !search.getBirthMonth().isEmpty() && !search.getBirthDay().isEmpty()) {
                String birthy = search.getBirthYear() + search.getBirthMonth() + search.getBirthDay();
                int count = 0;
                count++;
                updateOneLineDtlJkn(search, hanyoKensakuIndex, 11, "BIRTHDAY", count, birthy);
            }
            // ����敪
            if (search.getKaiinKbn() != null) {
                int count = 0;

                count++;
                updateOneLineDtlJkn(search, hanyoKensakuIndex, 12, "KAIIN_KBN", count, search.getKaiinKbn());
            }
            // ��ƃR�[�h
            if (!search.getKigyocode().isEmpty()) {
                int count = 0;
                count++;
                updateOneLineDtlJkn(search, hanyoKensakuIndex, 13, "KIGYOCODE", count, search.getKigyocode());
            }
            // �Ζ��於
            if (!search.getKinmusakiName().isEmpty()) {
                int count = 0;
                count++;
                updateOneLineDtlJkn(search, hanyoKensakuIndex, 14, "KINMUSAKI_NAME", count, search.getKinmusakiName());
            }
            // �ԍ�����
            String key = search.getBangoInput();
            // �ԍ��I��
            if (search.getBangoNyuryoku() != null) {
                int count = 0;

                count++;
                updateOneLineDtlJkn(search, hanyoKensakuIndex, 15, "BANGO_NYURYOKU", count, search.getBangoNyuryoku());
            }

            // �������e
            List<Option> tmp = search.getShikennaiyoList();
            List<String> shikennaiyo = null;
            if (search.getShikennaiyo() != null) {
                shikennaiyo = Arrays.asList(search.getShikennaiyo());
            }
            if (shikennaiyo != null) {
                if (shikennaiyo.size() > 0) {
                    allLineCount = 15;
                    for (int j = 0; j < tmp.size(); j++) {
                        allLineCount++;
                        String fromList = tmp.get(j).getValue();
                        if (shikennaiyo.contains(fromList)) {
                            updateOneLineDtlJkn(search, hanyoKensakuIndex, allLineCount, "SHIKEN_NAIYO", j + 1, fromList);
                        } else {
                            updateOneLineDtlJkn(search, hanyoKensakuIndex, allLineCount, "SHIKEN_NAIYO", j + 1, "");
                        }
                    }
                }
            }

            // �\�����@22
            List<Option> tmp1 = search.getMoshikomiKbnList();
            List<String> moshikomiKbn = null;
            if (search.getMoshikomiKbn() != null) {
                moshikomiKbn = Arrays.asList(search.getMoshikomiKbn());
            }

            if (moshikomiKbn != null) {
                if (moshikomiKbn.size() > 0) {
                    for (int j = 0; j < tmp1.size(); j++) {
                        allLineCount++;
                        String fromList = tmp1.get(j).getValue();
                        if (moshikomiKbn.contains(fromList)) {
                            updateOneLineDtlJkn(search, hanyoKensakuIndex, allLineCount, "MOSHIKOMI_HOHO", j + 1, fromList);
                        } else {
                            updateOneLineDtlJkn(search, hanyoKensakuIndex, allLineCount, "MOSHIKOMI_HOHO", j + 1, "");
                        }
                    }
                }
            }

            // �\���敪
            List<Option> tmp2 = search.getKojinDantaiKbnList();
            List<String> kojinDantaiKbn = null;
            if (search.getKojinDantaiKbn() != null) {
                kojinDantaiKbn = Arrays.asList(search.getKojinDantaiKbn());
            }
            if (kojinDantaiKbn != null) {
                if (kojinDantaiKbn.size() > 0) {
                    for (int j = 0; j < tmp2.size(); j++) {
                        allLineCount++;
                        String fromList = tmp2.get(j).getValue();
                        if (kojinDantaiKbn.contains(fromList)) {
                            updateOneLineDtlJkn(search, hanyoKensakuIndex, allLineCount, "MOSHIKOMI_KBN", j + 1, fromList);
                        } else {
                            updateOneLineDtlJkn(search, hanyoKensakuIndex, allLineCount, "MOSHIKOMI_KBN", j + 1, "");
                        }
                    }
                }
            }

            // �\����
            List<Option> tmp3 = search.getMoshikomiJokyoKbnList();
            List<String> moshikomiJokyoKbn = null;
            if (search.getMoshikomiJokyoKbn() != null) {
                moshikomiJokyoKbn = Arrays.asList(search.getMoshikomiJokyoKbn());
            }
            if (moshikomiJokyoKbn != null) {
                if (moshikomiJokyoKbn.size() > 0) {
                    for (int j = 0; j < tmp3.size(); j++) {
                        allLineCount++;
                        String fromList = tmp3.get(j).getValue();
                        if (moshikomiJokyoKbn.contains(fromList)) {
                            updateOneLineDtlJkn(search, hanyoKensakuIndex, allLineCount, "MOSHIKOMI_JOKYO", j + 1, fromList);
                        } else {
                            updateOneLineDtlJkn(search, hanyoKensakuIndex, allLineCount, "MOSHIKOMI_JOKYO", j + 1, "");
                        }
                    }
                }
            }

            // �z���\��
            List<Option> tmp4 = search.getHairyoFlgList();
            List<String> comUmFlg = null;
            if (search.getComUmFlg() != null) {
                comUmFlg = Arrays.asList(search.getComUmFlg());
            }
            if (comUmFlg != null) {
                if (comUmFlg.size() > 0) {
                    for (int j = 0; j < tmp4.size(); j++) {
                        allLineCount++;
                        String fromList = tmp4.get(j).getValue();
                        if (comUmFlg.contains(fromList)) {
                            updateOneLineDtlJkn(search, hanyoKensakuIndex, allLineCount, "HAIRYO_SHINSEI", j + 1, fromList);
                        } else {
                            updateOneLineDtlJkn(search, hanyoKensakuIndex, allLineCount, "HAIRYO_SHINSEI", j + 1, "");
                        }
                    }
                }
            }

            // ����t��
            String KariuketsukeBiFrom = "";
            String KariuketsukeBiTo = "";
            if (!search.getKariuketsukeBiFromYear().isEmpty() && !search.getKariuketsukeBiFromMonth().isEmpty() && !search.getKariuketsukeBiFromDay().isEmpty()) {
                KariuketsukeBiFrom = search.getKariuketsukeBiFromYear() + search.getKariuketsukeBiFromMonth() + search.getKariuketsukeBiFromDay();
                int count = 0;
                allLineCount++;
                count++;
                updateOneLineDtlJkn(search, hanyoKensakuIndex, allLineCount, "KARIUKETSUKE_BI_FROM", count, KariuketsukeBiFrom);

            }
            if (!search.getKariuketsukeBiToYear().isEmpty() && !search.getKariuketsukeBiToMonth().isEmpty() && !search.getKariuketsukeBiToDay().isEmpty()) {
                KariuketsukeBiTo = search.getKariuketsukeBiToYear() + search.getKariuketsukeBiToMonth() + search.getKariuketsukeBiToDay();
                int count = 0;
                allLineCount++;
                count++;
                updateOneLineDtlJkn(search, hanyoKensakuIndex, allLineCount, "KARIUKETSUKE_BI_TO", count, KariuketsukeBiTo);
            }

            // �\��(����)������
            String MoshikomikanryoBiFrom = "";
            String MoshikomikanryoBiTo = "";
            if (!search.getMoshikomikanryoBiFromYear().isEmpty() && !search.getMoshikomikanryoBiFromMonth().isEmpty() && !search.getMoshikomikanryoBiFromDay().isEmpty()) {
                MoshikomikanryoBiFrom = search.getMoshikomikanryoBiFromYear() + search.getMoshikomikanryoBiFromMonth() + search.getMoshikomikanryoBiFromDay();
                int count = 0;
                allLineCount++;
                count++;
                updateOneLineDtlJkn(search, hanyoKensakuIndex, allLineCount, "MOSHIKOMIKANRYO_BI_FROM", count, MoshikomikanryoBiFrom);
            }
            if (!search.getMoshikomikanryoBiToYear().isEmpty() && !search.getMoshikomikanryoBiToMonth().isEmpty() && !search.getMoshikomikanryoBiToDay().isEmpty()) {
                MoshikomikanryoBiTo = search.getMoshikomikanryoBiToYear() + search.getMoshikomikanryoBiToMonth() + search.getMoshikomikanryoBiToDay();
                int count = 0;
                allLineCount++;
                count++;
                updateOneLineDtlJkn(search, hanyoKensakuIndex, allLineCount, "MOSHIKOMIKANRYO_BI_TO", count, MoshikomikanryoBiTo);

            }

            // ���ϕ��@
            List<Option> tmp5 = search.getKessaiHohoList();
            List<String> kessaiHoho = null;
            if (search.getKessaiHoho() != null) {
                kessaiHoho = Arrays.asList(search.getKessaiHoho());
            }
            if (kessaiHoho != null) {
                if (kessaiHoho.size() > 0) {
                    for (int j = 0; j < tmp5.size(); j++) {
                        allLineCount++;
                        String fromList = tmp5.get(j).getValue();
                        if (kessaiHoho.contains(fromList)) {
                            updateOneLineDtlJkn(search, hanyoKensakuIndex, allLineCount, "KESSAI_HOHO", j + 1, fromList);
                        } else {
                            updateOneLineDtlJkn(search, hanyoKensakuIndex, allLineCount, "KESSAI_HOHO", j + 1, "");
                        }
                    }
                }
            }

            // ���Ϗ�
            List<Option> tmp6 = search.getKessaiJokyoKbnList();
            List<String> kessaiJokyoKbn = null;
            if (search.getKessaiJokyoKbn() != null) {
                kessaiJokyoKbn = Arrays.asList(search.getKessaiJokyoKbn());
            }
            if (kessaiJokyoKbn != null) {
                if (kessaiJokyoKbn.size() > 0) {
                    for (int j = 0; j < tmp6.size(); j++) {
                        allLineCount++;
                        String fromList = tmp6.get(j).getValue();
                        if (kessaiJokyoKbn.contains(fromList)) {
                            updateOneLineDtlJkn(search, hanyoKensakuIndex, allLineCount, "KESSAI_JOKYO", j + 1, fromList);
                        } else {
                            updateOneLineDtlJkn(search, hanyoKensakuIndex, allLineCount, "KESSAI_JOKYO", j + 1, "");
                        }
                    }
                }
            }

            // �摜�␳�˗���
            List<Option> tmp7 = search.getHoseiIraiKbnList();
            List<String> hoseiIraiKbn = null;
            if (search.getHoseiIraiKbn() != null) {
                hoseiIraiKbn = Arrays.asList(search.getHoseiIraiKbn());
            }
            if (hoseiIraiKbn != null) {
                if (hoseiIraiKbn.size() > 0) {
                    for (int j = 0; j < tmp7.size(); j++) {
                        allLineCount++;
                        String fromList = tmp7.get(j).getValue();
                        if (hoseiIraiKbn.contains(fromList)) {
                            updateOneLineDtlJkn(search, hanyoKensakuIndex, allLineCount, "HOSEI_IRAI_KBN", j + 1, fromList);
                        } else {
                            updateOneLineDtlJkn(search, hanyoKensakuIndex, allLineCount, "HOSEI_IRAI_KBN", j + 1, "");
                        }

                    }
                }
            }

            // ���ۏ�
            List<Option> tmp8 = search.getGohiJokyoKbnList();
            List<String> gohiJokyoKbn = null;
            if (search.getGohiJokyoKbn() != null) {
                gohiJokyoKbn = Arrays.asList(search.getGohiJokyoKbn());
            }
            if (gohiJokyoKbn != null) {
                if (gohiJokyoKbn.size() > 0) {
                    for (int j = 0; j < tmp8.size(); j++) {
                        allLineCount++;
                        String fromList = tmp8.get(j).getValue();
                        if (gohiJokyoKbn.contains(fromList)) {
                            updateOneLineDtlJkn(search, hanyoKensakuIndex, allLineCount, "GOHI_JOKYO", j + 1, fromList);
                        } else {
                            updateOneLineDtlJkn(search, hanyoKensakuIndex, allLineCount, "GOHI_JOKYO", j + 1, "");
                        }

                    }
                }
            }
        } catch (Exception ex) {
            throw ex;
        }
    }

    /**
     * �ėp�ڍ׃e�[�u���Ɉ�s�f�[�^���X�V����B
     *
     * @param inSession ���N�G�X�g
     * @param hanyoKensakuIdJkn
     * @param meisaiGyoNo
     * @param jokenKomokuId
     * @param jokenGyoNo
     * @return �����ꍇ�Ftrue;���s�Ffalse
     */
    public void updateOneLineDtlJkn(HanyouSearchJoho inSession, String hanyoKensakuIdJkn,
            int meisaiGyoNo, String jokenKomokuId, int jokenGyoNo, String jokenChi) throws IllegalAccessException, InvocationTargetException {

        String userId = inSession.getUserId();
        if (userId == null) {
            userId = "";
        }
        SystemTime sysTim = new SystemTime();
        try {
            //���[���e���v���[�g�@�I�u�W�F�N�g�쐬
            HanyoKensakuDtlJkn kensakuDtl = new HanyoKensakuDtlJkn(DATA_SOURCE_NAME);
            /* �X�V�ł���f�[�^�擾 */
            HanyoKensakuDtlJkn kensakuDtlJknJohoMoto = kensakuDtl.find(hanyoKensakuIdJkn, String.valueOf(meisaiGyoNo));
            if (kensakuDtlJknJohoMoto == null) {
                insertOneLineDtlJkn(inSession, hanyoKensakuIdJkn, meisaiGyoNo, jokenKomokuId, jokenGyoNo, jokenChi);
            } else {
                HanyoKensakuDtlJkn kensakuDtlJknJoho = new HanyoKensakuDtlJkn(DATA_SOURCE_NAME);
                /* ���݂̂ݍX�V���� */
                // �o�^�҂��X�V����
                BeanUtils.copyProperties(kensakuDtlJknJoho, kensakuDtlJknJohoMoto);

                kensakuDtlJknJoho.setHanyoKensakuIdJkn(hanyoKensakuIdJkn);

                kensakuDtlJknJoho.setJokenKomokuId(jokenKomokuId);
                kensakuDtlJknJoho.setJokenGyoNo(String.valueOf(jokenGyoNo));
                kensakuDtlJknJoho.setJokenChi(jokenChi);

                //�_���폜�t���O���Z�b�g
                kensakuDtlJknJoho.setRonriSakujoFlg(BmaConstants.FLG_OFF);
                //�����敪
                kensakuDtlJknJoho.setKoshinKbn(BmaConstants.SHORI_KBN_UPDATE);

                //�X�V�����E�X�V��
                kensakuDtlJknJoho.setKoshinDate(sysTim.getymd1());
                kensakuDtlJknJoho.setKoshinTime(sysTim.gethms1());
                kensakuDtlJknJoho.setKoshinUserId(userId);

                // �X�V
                kensakuDtlJknJoho.update();

            }
        } catch (InvocationTargetException ex) {
            throw ex;
        }

    }

    /**
     * �w��y�[�W���ɍ��킹�āA�\�������ꃊ�X�g���쐬
     *
     * @param inSession�@�Z�b�V�������X�g
     */
    public void setDisplayList(HanyouSearchJoho inSession) {
        /* �ϐ������� */
        List<HanyouSearchJoho> displayList = new ArrayList<>();
        HanyouSearchJoho kaijo;

        List<HanyouSearchJoho> resultList = inSession.getHanyouAllList();
        /* �y�[�W���ɍ��킹�ĕ\���p���X�g�쐬 */
        for (int i = inSession.getFirstDisp() - 1; i < inSession.getMaxDisp(); ++i) {
            kaijo = resultList.get(i);
            displayList.add(kaijo);
        }
        inSession.setHanyouDetailList(displayList);
    }

    /**
     * �y�[�W����
     *
     * @param inSession�@�Z�b�V�������X�g
     */
    public void setPage(HanyouSearchJoho inSession) {
        /* �ϐ������� */
        int idx;
        int max;
        int maxLenDisp = inSession.getHanyouAllList().size();
        int pageMax;

        /* ��ʂɕ\������ő匏�����擾 */
        int page = inSession.getPage();
        idx = page * BmaConstants.MAX_PAGE_NUM_HANYO_SEARCH;

        max = idx + BmaConstants.MAX_PAGE_NUM_HANYO_SEARCH;
        inSession.setFirstDisp(idx + 1);

        /* �������ʂ̌��� */
        if (maxLenDisp < max) {
            inSession.setMaxDisp(maxLenDisp);
        } else {
            /* �ő匏����茟�����ʂ������ꍇ */
            inSession.setMaxDisp(max);
        }

        /* �y�[�W�ԍ��̍ő���v�Z */
        pageMax = (int) (Math.ceil((double) maxLenDisp / (double) (BmaConstants.MAX_PAGE_NUM_HANYO_SEARCH)));
        inSession.setPageMax(pageMax + 1);

        /* �y�[�W�ԍ��ݒ� */
        int now = 0;
        now = inSession.getPage();

        /* �Œጏ�� */
        if (now == 0) {
            inSession.setPageBegin(now + 1);
        } else if (now == 1) {
            inSession.setPageBegin(now);
        } else if (now == 2) {
            inSession.setPageBegin(now - 1);
        } else {
            inSession.setPageBegin(now - 2);
        }
        /* �ő匏�����\������ő匏����3�{�ȉ��������ꍇ�̕\���p�y�[�W�ԍ� */
        if (now == pageMax) {
            inSession.setPageEnd(now + 1);
        } else if (now == pageMax - 1) {
            inSession.setPageEnd(now + 2);
        } else if (now == pageMax - 2) {
            inSession.setPageEnd(now + 3);
        } else {
            inSession.setPageEnd(now + 4);
        }
        inSession.setPage(now + 1);
    }

    /**
     * �������������Z�b�g����B
     *
     * @param inSession �Z�b�V����RTO
     */
    private void clearSearchInput(HanyouSearchJoho inSession) {
        inSession.setPage(0);
        inSession.setPageMax(0);
        inSession.setFirstDisp(0);
        inSession.setMaxDisp(0);
        inSession.setSearchOutIndex(null);

        inSession.setDispKeyList(null);

        inSession.setErrors(new Messages());
    }

    /**
     * ���̓f�[�^���Z�b�V�����f�[�^�ɃZ�b�g����B
     *
     * @param inRequest ���N�G�X�g��̓��̓f�[�^
     * @param inSession �Z�b�V������̓��̓f�[�^
     */
    private void setValueRequestToSession(HanyouSearchJoho inRequest, HanyouSearchJoho inSession) {
        inSession.setSknksuKbn(inRequest.getSknksuKbn());

        inSession.setSknName(inRequest.getSknName());
        inSession.setKaiinKbn(inRequest.getKaiinKbn());
        inSession.setKsuName(inRequest.getKsuName());

        inSession.setNendoFrm(inRequest.getNendoFrm());
        inSession.setNendoTo(inRequest.getNendoTo());

        inSession.setFurigana(inRequest.getFurigana());
        inSession.setBirthYear(inRequest.getBirthYear());
        inSession.setBirthMonth(inRequest.getBirthMonth());
        inSession.setBirthDay(inRequest.getBirthDay());

        inSession.setKaiinKbn(inRequest.getKaiinKbn());
        inSession.setKigyocode(inRequest.getKigyocode());
        inSession.setKinmusakiName(inRequest.getKinmusakiName());
        inSession.setBangoNyuryoku(inRequest.getBangoNyuryoku());
        inSession.setBangoInput(inRequest.getBangoInput());

        inSession.setSrcTempNo(inRequest.getSearchChange());
        inSession.setSearchChange(inRequest.getSearchChange());

        inSession.setKariuketsukeBiFromYear(inRequest.getKariuketsukeBiFromYear());
        inSession.setKariuketsukeBiFromMonth(inRequest.getKariuketsukeBiFromMonth());
        inSession.setKariuketsukeBiFromDay(inRequest.getKariuketsukeBiFromDay());

        inSession.setKariuketsukeBiToYear(inRequest.getKariuketsukeBiToYear());
        inSession.setKariuketsukeBiToMonth(inRequest.getKariuketsukeBiToMonth());
        inSession.setKariuketsukeBiToDay(inRequest.getKariuketsukeBiToDay());

        inSession.setMoshikomikanryoBiFromYear(inRequest.getMoshikomikanryoBiFromYear());
        inSession.setMoshikomikanryoBiFromMonth(inRequest.getMoshikomikanryoBiFromMonth());
        inSession.setMoshikomikanryoBiFromDay(inRequest.getMoshikomikanryoBiFromDay());

        inSession.setMoshikomikanryoBiToYear(inRequest.getMoshikomikanryoBiToYear());
        inSession.setMoshikomikanryoBiToMonth(inRequest.getMoshikomikanryoBiToMonth());
        inSession.setMoshikomikanryoBiToDay(inRequest.getMoshikomikanryoBiToDay());

        inSession.setTempletSave(inRequest.getTempletSave());
        inSession.setUpdateFlag(inRequest.getUpdateFlag());

        // �������e
        String strNayo[] = new String[6];
        List<Option> tmp = inSession.getShikennaiyoList();
        List<String> shikennaiyo = null;
        if (inRequest.getShikennaiyo() != null) {
            shikennaiyo = Arrays.asList(inRequest.getShikennaiyo());
        }
        if (shikennaiyo != null) {
            if (shikennaiyo.size() > 0) {
                for (int j = 0; j < tmp.size(); j++) {
                    String fromList = tmp.get(j).getValue();
                    if (shikennaiyo.contains(fromList)) {
                        strNayo[j] = fromList;
                    } else {
                        strNayo[j] = "";
                    }
                }
            }
        }
        inSession.setShikennaiyo(strNayo);

        // �\�����@
        String strMoshi[] = new String[2];
        List<Option> tmp1 = inSession.getMoshikomiKbnList();
        List<String> moshikomiKbn = null;
        if (inRequest.getMoshikomiKbn() != null) {
            moshikomiKbn = Arrays.asList(inRequest.getMoshikomiKbn());
        }
        if (moshikomiKbn != null) {
            if (moshikomiKbn.size() > 0) {
                for (int j = 0; j < tmp1.size(); j++) {
                    String fromList = tmp1.get(j).getValue();
                    if (moshikomiKbn.contains(fromList)) {
                        strMoshi[j] = fromList;
                    } else {
                        strMoshi[j] = "";
                    }
                }
            }
        }
        inSession.setMoshikomiKbn(strMoshi);

        // �\���敪
        String strMoshiKbn[] = new String[2];
        List<Option> tmp2 = inSession.getKojinDantaiKbnList();
        List<String> kojinDantaiKbn = null;
        if (inRequest.getKojinDantaiKbn() != null) {
            kojinDantaiKbn = Arrays.asList(inRequest.getKojinDantaiKbn());
        }
        if (kojinDantaiKbn != null) {
            if (kojinDantaiKbn.size() > 0) {
                for (int j = 0; j < tmp2.size(); j++) {
                    String fromList = tmp2.get(j).getValue();
                    if (kojinDantaiKbn.contains(fromList)) {
                        strMoshiKbn[j] = fromList;
                    } else {
                        strMoshiKbn[j] = "";
                    }
                }
            }
        }
        inSession.setKojinDantaiKbn(strMoshiKbn);

        // �\����
        String strMoshiJyo[] = new String[4];
        List<Option> tmp3 = inSession.getMoshikomiJokyoKbnList();
        List<String> moshikomiJokyoKbn = null;
        if (inRequest.getMoshikomiJokyoKbn() != null) {
            moshikomiJokyoKbn = Arrays.asList(inRequest.getMoshikomiJokyoKbn());
        }
        if (moshikomiJokyoKbn != null) {
            if (moshikomiJokyoKbn.size() > 0) {
                for (int j = 0; j < tmp3.size(); j++) {
                    String fromList = tmp3.get(j).getValue();
                    if (moshikomiJokyoKbn.contains(fromList)) {
                        strMoshiJyo[j] = fromList;
                    } else {
                        strMoshiJyo[j] = "";
                    }
                }
            }
        }
        inSession.setMoshikomiJokyoKbn(strMoshiJyo);

        // �z���\��
        String strComUmFlg[] = new String[2];
        List<Option> tmp4 = inSession.getHairyoFlgList();
        List<String> comUmFlg = null;
        if (inRequest.getComUmFlg() != null) {
            comUmFlg = Arrays.asList(inRequest.getComUmFlg());
        }
        if (comUmFlg != null) {
            if (comUmFlg.size() > 0) {
                for (int j = 0; j < tmp4.size(); j++) {
                    String fromList = tmp4.get(j).getValue();
                    if (comUmFlg.contains(fromList)) {
                        strComUmFlg[j] = fromList;
                    } else {
                        strComUmFlg[j] = "";
                    }
                }
            }
        }
        inSession.setComUmFlg(strComUmFlg);

        // ���ϕ��@
        String strKessaiHoho[] = new String[6];
        List<Option> tmp5 = inSession.getKessaiHohoList();
        List<String> kessaiHoho = null;
        if (inRequest.getKessaiHoho() != null) {
            kessaiHoho = Arrays.asList(inRequest.getKessaiHoho());
        }
        if (kessaiHoho != null) {
            if (kessaiHoho.size() > 0) {
                for (int j = 0; j < tmp5.size(); j++) {
                    String fromList = tmp5.get(j).getValue();
                    if (kessaiHoho.contains(fromList)) {
                        strKessaiHoho[j] = fromList;
                    } else {
                        strKessaiHoho[j] = "";
                    }
                }
            }
        }
        inSession.setKessaiHoho(strKessaiHoho);

        // ���Ϗ�
        String strKessaiJokyoKbn[] = new String[3];
        List<Option> tmp6 = inSession.getKessaiJokyoKbnList();
        List<String> kessaiJokyoKbn = null;
        if (inRequest.getKessaiJokyoKbn() != null) {
            kessaiJokyoKbn = Arrays.asList(inRequest.getKessaiJokyoKbn());
        }
        if (kessaiJokyoKbn != null) {
            if (kessaiJokyoKbn.size() > 0) {
                for (int j = 0; j < tmp6.size(); j++) {

                    String fromList = tmp6.get(j).getValue();
                    if (kessaiJokyoKbn.contains(fromList)) {
                        strKessaiJokyoKbn[j] = fromList;
                    } else {
                        strKessaiJokyoKbn[j] = "";
                    }
                }
            }
        }
        inSession.setKessaiJokyoKbn(strKessaiJokyoKbn);

        // �摜�␳�˗���
        String strHoseiIraiKbn[] = new String[7];
        List<Option> tmp7 = inSession.getHoseiIraiKbnList();
        List<String> hoseiIraiKbn = null;
        if (inRequest.getHoseiIraiKbn() != null) {
            hoseiIraiKbn = Arrays.asList(inRequest.getHoseiIraiKbn());
        }
        if (hoseiIraiKbn != null) {
            if (hoseiIraiKbn.size() > 0) {
                for (int j = 0; j < tmp7.size(); j++) {
                    String fromList = tmp7.get(j).getValue();
                    if (hoseiIraiKbn.contains(fromList)) {
                        strHoseiIraiKbn[j] = fromList;
                    } else {
                        strHoseiIraiKbn[j] = "";
                    }
                }
            }
        }
        inSession.setHoseiIraiKbn(strHoseiIraiKbn);

        // ���ۏ�
        String strGohiJokyoKbn[] = new String[4];
        List<Option> tmp8 = inSession.getGohiJokyoKbnList();
        List<String> gohiJokyoKbn = null;
        if (inRequest.getGohiJokyoKbn() != null) {
            gohiJokyoKbn = Arrays.asList(inRequest.getGohiJokyoKbn());
        }
        if (gohiJokyoKbn != null) {
            if (gohiJokyoKbn.size() > 0) {
                for (int j = 0; j < tmp8.size(); j++) {

                    String fromList = tmp8.get(j).getValue();
                    if (gohiJokyoKbn.contains(fromList)) {
                        strGohiJokyoKbn[j] = fromList;
                    } else {
                        strGohiJokyoKbn[j] = "";
                    }
                }
            }
        }
        inSession.setGohiJokyoKbn(strGohiJokyoKbn);
    }

    /**
     * ���̓f�[�^���Z�b�V�����f�[�^�ɃZ�b�g����B
     *
     * @param inRequest ���N�G�X�g��̓��̓f�[�^
     * @param inSession �Z�b�V������̓��̓f�[�^
     */
    private void setValueRequestToTaihi(HanyouSearchJoho inRequest, HanyouSearchJoho inSession, HanyouSearchJoho taihi) {
        taihi.setSknksuKbn(inRequest.getSknksuKbn());

        taihi.setSknName(inRequest.getSknName());
        taihi.setKsuName(inRequest.getKsuName());

        taihi.setNendoFrm(inRequest.getNendoFrm());
        taihi.setNendoTo(inRequest.getNendoTo());

        taihi.setFurigana(inRequest.getFurigana());
        taihi.setBirthYear(inRequest.getBirthYear());
        taihi.setBirthMonth(inRequest.getBirthMonth());
        taihi.setBirthDay(inRequest.getBirthDay());

        taihi.setKaiinKbn(inRequest.getKaiinKbn());
        taihi.setKigyocode(inRequest.getKigyocode());
        taihi.setKinmusakiName(inRequest.getKinmusakiName());
        taihi.setBangoNyuryoku(inRequest.getBangoNyuryoku());
        taihi.setBangoInput(inRequest.getBangoInput());

        taihi.setSrcTempNo(inRequest.getSearchChange());
        taihi.setSearchChange(inRequest.getSearchChange());

        taihi.setKariuketsukeBiFromYear(inRequest.getKariuketsukeBiFromYear());
        taihi.setKariuketsukeBiFromMonth(inRequest.getKariuketsukeBiFromMonth());
        taihi.setKariuketsukeBiFromDay(inRequest.getKariuketsukeBiFromDay());

        taihi.setKariuketsukeBiToYear(inRequest.getKariuketsukeBiToYear());
        taihi.setKariuketsukeBiToMonth(inRequest.getKariuketsukeBiToMonth());
        taihi.setKariuketsukeBiToDay(inRequest.getKariuketsukeBiToDay());

        taihi.setMoshikomikanryoBiFromYear(inRequest.getMoshikomikanryoBiFromYear());
        taihi.setMoshikomikanryoBiFromMonth(inRequest.getMoshikomikanryoBiFromMonth());
        taihi.setMoshikomikanryoBiFromDay(inRequest.getMoshikomikanryoBiFromDay());

        taihi.setMoshikomikanryoBiToYear(inRequest.getMoshikomikanryoBiToYear());
        taihi.setMoshikomikanryoBiToMonth(inRequest.getMoshikomikanryoBiToMonth());
        taihi.setMoshikomikanryoBiToDay(inRequest.getMoshikomikanryoBiToDay());

        taihi.setTempletSave(inRequest.getTempletSave());
        taihi.setUpdateFlag(inRequest.getUpdateFlag());

        // �������e
        String strNayo[] = new String[6];
        List<Option> tmp = inSession.getShikennaiyoList();
        List<String> shikennaiyo = null;
        if (inRequest.getShikennaiyo() != null) {
            shikennaiyo = Arrays.asList(inRequest.getShikennaiyo());
        }
        if (shikennaiyo != null) {
            if (shikennaiyo.size() > 0) {
                for (int j = 0; j < tmp.size(); j++) {
                    String fromList = tmp.get(j).getValue();
                    if (shikennaiyo.contains(fromList)) {
                        strNayo[j] = fromList;
                    } else {
                        strNayo[j] = "";
                    }
                }
            }
        }
        taihi.setShikennaiyo(strNayo);

        // �\�����@
        String strMoshi[] = new String[2];
        List<Option> tmp1 = inSession.getMoshikomiKbnList();
        List<String> moshikomiKbn = null;
        if (inRequest.getMoshikomiKbn() != null) {
            moshikomiKbn = Arrays.asList(inRequest.getMoshikomiKbn());
        }
        if (moshikomiKbn != null) {
            if (moshikomiKbn.size() > 0) {
                for (int j = 0; j < tmp1.size(); j++) {
                    String fromList = tmp1.get(j).getValue();
                    if (moshikomiKbn.contains(fromList)) {
                        strMoshi[j] = fromList;
                    } else {
                        strMoshi[j] = "";
                    }
                }
            }
        }
        taihi.setMoshikomiKbn(strMoshi);

        // �\���敪
        String strMoshiKbn[] = new String[2];
        List<Option> tmp2 = inSession.getKojinDantaiKbnList();
        List<String> kojinDantaiKbn = null;
        if (inRequest.getKojinDantaiKbn() != null) {
            kojinDantaiKbn = Arrays.asList(inRequest.getKojinDantaiKbn());
        }
        if (kojinDantaiKbn != null) {
            if (kojinDantaiKbn.size() > 0) {
                for (int j = 0; j < tmp2.size(); j++) {
                    String fromList = tmp2.get(j).getValue();
                    if (kojinDantaiKbn.contains(fromList)) {
                        strMoshiKbn[j] = fromList;
                    } else {
                        strMoshiKbn[j] = "";
                    }
                }
            }
        }
        taihi.setKojinDantaiKbn(strMoshiKbn);

        // �\����
        String strMoshiJyo[] = new String[4];
        List<Option> tmp3 = inSession.getMoshikomiJokyoKbnList();
        List<String> moshikomiJokyoKbn = null;
        if (inRequest.getMoshikomiJokyoKbn() != null) {
            moshikomiJokyoKbn = Arrays.asList(inRequest.getMoshikomiJokyoKbn());
        }
        if (moshikomiJokyoKbn != null) {
            if (moshikomiJokyoKbn.size() > 0) {
                for (int j = 0; j < tmp3.size(); j++) {
                    String fromList = tmp3.get(j).getValue();
                    if (moshikomiJokyoKbn.contains(fromList)) {
                        strMoshiJyo[j] = fromList;
                    } else {
                        strMoshiJyo[j] = "";
                    }
                }
            }
        }
        taihi.setMoshikomiJokyoKbn(strMoshiJyo);

        // �z���\��
        String strComUmFlg[] = new String[2];
        List<Option> tmp4 = inSession.getHairyoFlgList();
        List<String> comUmFlg = null;
        if (inRequest.getComUmFlg() != null) {
            comUmFlg = Arrays.asList(inRequest.getComUmFlg());
        }
        if (comUmFlg != null) {
            if (comUmFlg.size() > 0) {
                for (int j = 0; j < tmp4.size(); j++) {
                    String fromList = tmp4.get(j).getValue();
                    if (comUmFlg.contains(fromList)) {
                        strComUmFlg[j] = fromList;
                    } else {
                        strComUmFlg[j] = "";
                    }
                }
            }
        }
        taihi.setComUmFlg(strComUmFlg);

        // ���ϕ��@
        String strKessaiHoho[] = new String[6];
        List<Option> tmp5 = inSession.getKessaiHohoList();
        List<String> kessaiHoho = null;
        if (inRequest.getKessaiHoho() != null) {
            kessaiHoho = Arrays.asList(inRequest.getKessaiHoho());
        }
        if (kessaiHoho != null) {
            if (kessaiHoho.size() > 0) {
                for (int j = 0; j < tmp5.size(); j++) {
                    String fromList = tmp5.get(j).getValue();
                    if (kessaiHoho.contains(fromList)) {
                        strKessaiHoho[j] = fromList;
                    } else {
                        strKessaiHoho[j] = "";
                    }
                }
            }
        }
        taihi.setKessaiHoho(strKessaiHoho);

        // ���Ϗ�
        String strKessaiJokyoKbn[] = new String[3];
        List<Option> tmp6 = inSession.getKessaiJokyoKbnList();
        List<String> kessaiJokyoKbn = null;
        if (inRequest.getKessaiJokyoKbn() != null) {
            kessaiJokyoKbn = Arrays.asList(inRequest.getKessaiJokyoKbn());
        }
        if (kessaiJokyoKbn != null) {
            if (kessaiJokyoKbn.size() > 0) {
                for (int j = 0; j < tmp6.size(); j++) {

                    String fromList = tmp6.get(j).getValue();
                    if (kessaiJokyoKbn.contains(fromList)) {
                        strKessaiJokyoKbn[j] = fromList;
                    } else {
                        strKessaiJokyoKbn[j] = "";
                    }
                }
            }
        }
        taihi.setKessaiJokyoKbn(strKessaiJokyoKbn);

        // �摜�␳�˗���
        String strHoseiIraiKbn[] = new String[7];
        List<Option> tmp7 = inSession.getHoseiIraiKbnList();
        List<String> hoseiIraiKbn = null;
        if (inRequest.getHoseiIraiKbn() != null) {
            hoseiIraiKbn = Arrays.asList(inRequest.getHoseiIraiKbn());
        }
        if (hoseiIraiKbn != null) {
            if (hoseiIraiKbn.size() > 0) {
                for (int j = 0; j < tmp7.size(); j++) {
                    String fromList = tmp7.get(j).getValue();
                    if (hoseiIraiKbn.contains(fromList)) {
                        strHoseiIraiKbn[j] = fromList;
                    } else {
                        strHoseiIraiKbn[j] = "";
                    }
                }
            }
        }
        taihi.setHoseiIraiKbn(strHoseiIraiKbn);

        // ���ۏ�
        String strGohiJokyoKbn[] = new String[4];
        List<Option> tmp8 = inSession.getGohiJokyoKbnList();
        List<String> gohiJokyoKbn = null;
        if (inRequest.getGohiJokyoKbn() != null) {
            gohiJokyoKbn = Arrays.asList(inRequest.getGohiJokyoKbn());
        }
        if (gohiJokyoKbn != null) {
            if (gohiJokyoKbn.size() > 0) {
                for (int j = 0; j < tmp8.size(); j++) {

                    String fromList = tmp8.get(j).getValue();
                    if (gohiJokyoKbn.contains(fromList)) {
                        strGohiJokyoKbn[j] = fromList;
                    } else {
                        strGohiJokyoKbn[j] = "";
                    }
                }
            }
        }
        taihi.setGohiJokyoKbn(strGohiJokyoKbn);
    }

    /**
     * ���̓`�F�b�N(����)
     *
     * @param inRequest
     * @return ��肪�Ȃ���� true�A����� false
     */
    private boolean ValidatorSearch(HanyouSearchJoho inRequest, HanyouSearchJoho inSession) throws Exception {
        String groupCode = "";
        String itemName = "";

        //�t���K�i�̑S�p�ϊ����s
        inSession.setFurigana(BmaStringUtility.convertHankakuToZenkakuBma(inSession.getFurigana()));
        inSession.setKinmusakiName(BmaStringUtility.convertHankakuToZenkakuBma(inSession.getKinmusakiName()));

        inRequest.setFurigana(BmaStringUtility.convertHankakuToZenkakuBma(inSession.getFurigana()));
        inRequest.setKinmusakiName(BmaStringUtility.convertHankakuToZenkakuBma(inSession.getKinmusakiName()));
        
        //���b�Z�[�W�i�[�p
        Messages errors = new Messages();
        String sknksuKbn = inRequest.getSknksuKbn();
        if (sknksuKbn == null) {
            sknksuKbn = "";
        }
        String sknksuName = (sknksuKbn.equals(BmaConstants.SKN_KBN))
                ? inRequest.getSknName() : inRequest.getKsuName();

        String nendoFrm = inRequest.getNendoFrm();
        String nendoTo = inRequest.getNendoTo();

        groupCode = "";
        itemName = "����/�u�K��";
        // ����/�u�K��F�K�{�`�F�b�N
        BmaValidator.validateSelect(sknksuKbn, errors, groupCode, itemName);
        // ����/�u�K��F�����`�F�b�N
        Validator.validateMaxLength(sknksuKbn, 1, errors, groupCode, itemName);

        groupCode = "sknksuName";
        itemName = "����/�u�K�";
        // ����/�u�K��F�K�{�`�F�b�N
        if (sknksuName == null) {
            sknksuName = "";
        }
        BmaValidator.validateSelect(sknksuName, errors, groupCode, itemName);

        // ����/�u�K��F�����`�F�b�N
        Validator.validateMaxLength(sknksuName, 6, errors, groupCode, itemName);

        groupCode = "nendoFrm";
        itemName = "�N�xFROM��";
        // �N�xFROM�F�����`�F�b�N
        BmaValidator.validateNumber(nendoFrm, errors, groupCode, itemName);
        // �N�x�F�����`�F�b�N
        Validator.validateMaxLength(nendoFrm, 4, errors, groupCode, itemName);

        groupCode = "nendoTo";
        itemName = "�N�xTO��";
        // �N�xFROM�F�����`�F�b�N
        BmaValidator.validateNumber(nendoTo, errors, groupCode, itemName);
        // �N�x�F�����`�F�b�N
        Validator.validateMaxLength(nendoTo, 4, errors, groupCode, itemName);

        // �t���K�i�F�����`�F�b�N
        groupCode = "furigana";
        itemName = "�t���K�i";
        if (BmaValidator.validateMessageCheck(errors, itemName)) {
            // �t���K�i�F�����`�F�b�N
            Validator.validateMaxLength(inSession.getFurigana(), 200, errors, groupCode, itemName);
        }

        /*���N����*/
        groupCode = "birthYear";
        /*�N*/
        itemName = "���N�����̔N";
        BmaValidator.validatePermissionSelect(inSession.getBirthYear(), inSession.getBirthYearList(), errors, groupCode, itemName);
        /*��*/
        itemName = "���N�����̌�";
        BmaValidator.validatePermissionSelect(inSession.getBirthMonth(), inSession.getBirthMonthList(), errors, groupCode, itemName);

        /*��*/
        itemName = "���N�����̓�";
        BmaValidator.validatePermissionSelect(inSession.getBirthDay(), inSession.getBirthDayList(), errors, groupCode, itemName);
        /*���N����*/
        itemName = "���N����";
        if (!BmaUtility.isNullOrEmpty(inSession.getBirthDay())
                && !BmaUtility.isNullOrEmpty(inSession.getBirthMonth())
                && !BmaUtility.isNullOrEmpty(inSession.getBirthYear())) {
            /*�N�������I������Ă���Ƃ����ݓ��`�F�b�N*/
            String strBirthDay = inSession.getBirthYear() + inSession.getBirthMonth() + inSession.getBirthDay();
            if (BmaValidator.validateDate(strBirthDay, errors, groupCode, itemName)) {
                inSession.setBirthYear(strBirthDay.substring(0, 4));
                inSession.setBirthMonth(strBirthDay.substring(4, 6));
                inSession.setBirthDay(strBirthDay.substring(6, 8));
            }
        }

        /*���*/
        groupCode = "kaiinKbn";
        itemName = "���";
        //BmaValidator.validatePermissionSelect(inSession.getKaiinKbn(), inSession.getKaiinKbnList(), errors, groupCode, itemName);

        /*��ƃR�[�h*/
        groupCode = "kigyocode";
        itemName = "��ƃR�[�h";
        // ��ƃR�[�h�F�����`�F�b�N
        BmaValidator.validateNumber(inSession.getKigyocode(), errors, groupCode, itemName);
        Validator.validateMaxLength(inSession.getKigyocode(), 10, errors, groupCode, itemName);

        // �Ζ��於�̃`�F�b�N
        groupCode = "KinmusakiName";
        itemName = "�Ζ��於";
        BmaValidator.validateMojiCode3(inSession.getKinmusakiName(), errors, groupCode, itemName);
        BmaValidator.validateMaxLength(inSession.getKinmusakiName(), 200, errors, groupCode, itemName);

        /*�ԍ��I��*/
        groupCode = "bangoNyuryoku";
        itemName = "�ԍ��I��";
        //BmaValidator.validateSelect(inSession.getBangoNyuryoku(), errors, groupCode, itemName);
        BmaValidator.validatePermissionSelect(inSession.getBangoNyuryoku(), inSession.getBangoNyuryokuList(), errors, groupCode, itemName);

        if ("����".equals(inRequest.getHanyouSearchWhe())) {
            // �ԍ��I�� �ԍ�����
            if (inSession.getBangoNyuryoku() != null) {
                groupCode = "";
                itemName = "�ԍ����̗͂�";
                BmaValidator.validateRequired(inSession.getBangoInput(), errors, groupCode, itemName);
                BmaValidator.validateMaxLength(inSession.getBangoInput(), 20, errors, groupCode, itemName);
            }
        }

        if (inSession.getShikennaiyo() != null) {
            /*�������e*/
            groupCode = "Shikennaiyo";
            itemName = "�������e";
            for (String komiKbn : inSession.getShikennaiyo()) {
                BmaValidator.validatePermissionSelect(komiKbn, inSession.getShikennaiyoList(), errors, groupCode, itemName);
                Validator.validateMaxLength(komiKbn, 2, errors, groupCode, itemName);
                break;
            }
        }

        if (inSession.getMoshikomiKbn() != null) {
            /*�\�����@ �C���^�[�l�b�g�\�� �X���\��*/
            groupCode = "moshikomiKbn";
            itemName = "�\�����@";
            for (String komiKbn : inSession.getMoshikomiKbn()) {
                BmaValidator.validatePermissionSelect(komiKbn, inSession.getMoshikomiKbnList(), errors, groupCode, itemName);
                Validator.validateMaxLength(komiKbn, 1, errors, groupCode, itemName);
                break;
            }
        }

        if (inSession.getKojinDantaiKbn() != null) {
            /*�\���敪*/
            groupCode = "kojinDantaiKbn";
            itemName = "�\���敪";
            for (String kojiKbn : inSession.getKojinDantaiKbn()) {
                BmaValidator.validatePermissionSelect(kojiKbn, inSession.getKojinDantaiKbnList(), errors, groupCode, itemName);
                Validator.validateMaxLength(kojiKbn, 1, errors, groupCode, itemName);
                break;
            }
        }

        if (inSession.getMoshikomiJokyoKbn() != null) {
            /*�\����*/
            groupCode = "moshikomiJokyoKbn";
            itemName = "�\����";
            for (String komiKbn : inSession.getMoshikomiJokyoKbn()) {
                BmaValidator.validatePermissionSelect(komiKbn, inSession.getMoshikomiJokyoKbnList(), errors, groupCode, itemName);
                Validator.validateMaxLength(komiKbn, 2, errors, groupCode, itemName);
                break;
            }
        }
        if (inSession.getComUmFlg() != null) {
            /*�z���\��*/
            groupCode = "ComUmFlgn";
            itemName = "�z���\��";
            for (String komiKbn : inSession.getComUmFlg()) {
                BmaValidator.validatePermissionSelect(komiKbn, inSession.getHairyoFlgList(), errors, groupCode, itemName);
                Validator.validateMaxLength(komiKbn, 2, errors, groupCode, itemName);
                break;
            }
        }
        /*����t��FROM*/
        groupCode = "KariuketsukeBiFromDay";
        /*�N*/
        itemName = "����t��FROM�̔N";
        BmaValidator.validatePermissionSelect(inSession.getKariuketsukeBiFromYear(), inSession.getYearList(), errors, groupCode, itemName);
        /*��*/
        itemName = "����t��FROM�̌�";
        BmaValidator.validatePermissionSelect(inSession.getKariuketsukeBiFromMonth(), inSession.getMonthList(), errors, groupCode, itemName);
        /*��*/
        itemName = "����t��FROM�̓�";
        BmaValidator.validatePermissionSelect(inSession.getKariuketsukeBiFromDay(), inSession.getDayList(), errors, groupCode, itemName);
        /*����t��FROM*/
        itemName = "����t��FROM";
        if (!BmaUtility.isNullOrEmpty(inSession.getKariuketsukeBiFromDay())
                && !BmaUtility.isNullOrEmpty(inSession.getKariuketsukeBiFromMonth())
                && !BmaUtility.isNullOrEmpty(inSession.getKariuketsukeBiFromYear())) {
            /*�N�������I������Ă���Ƃ����ݓ��`�F�b�N*/
            String strKariuketsukeBiFromDay = inSession.getKariuketsukeBiFromYear() + inSession.getKariuketsukeBiFromMonth() + inSession.getKariuketsukeBiFromDay();
            if (BmaValidator.validateDate(strKariuketsukeBiFromDay, errors, groupCode, itemName)) {
                inSession.setKariuketsukeBiFromYear(strKariuketsukeBiFromDay.substring(0, 4));
                inSession.setKariuketsukeBiFromMonth(strKariuketsukeBiFromDay.substring(4, 6));
                inSession.setKariuketsukeBiFromDay(strKariuketsukeBiFromDay.substring(6, 8));
            }
        }
        /*����t��TO*/
        groupCode = "KariuketsukeBiToDay";
        /*�N*/
        itemName = "����t��TO�̔N";
        BmaValidator.validatePermissionSelect(inSession.getKariuketsukeBiToYear(), inSession.getYearList(), errors, groupCode, itemName);
        /*��*/
        itemName = "����t��TO�̌�";
        BmaValidator.validatePermissionSelect(inSession.getKariuketsukeBiToMonth(), inSession.getMonthList(), errors, groupCode, itemName);

        /*��*/
        itemName = "����t��TO�̓�";
        BmaValidator.validatePermissionSelect(inSession.getKariuketsukeBiToDay(), inSession.getDayList(), errors, groupCode, itemName);
        /*����t��TO*/
        itemName = "����t��TO";
        if (!BmaUtility.isNullOrEmpty(inSession.getKariuketsukeBiToDay())
                && !BmaUtility.isNullOrEmpty(inSession.getKariuketsukeBiToMonth())
                && !BmaUtility.isNullOrEmpty(inSession.getKariuketsukeBiToYear())) {
            /*�N�������I������Ă���Ƃ����ݓ��`�F�b�N*/
            String strKariuketsukeBiToDay = inSession.getKariuketsukeBiToYear() + inSession.getKariuketsukeBiToMonth() + inSession.getKariuketsukeBiToDay();
            if (BmaValidator.validateDate(strKariuketsukeBiToDay, errors, groupCode, itemName)) {
                inSession.setKariuketsukeBiToYear(strKariuketsukeBiToDay.substring(0, 4));
                inSession.setKariuketsukeBiToMonth(strKariuketsukeBiToDay.substring(4, 6));
                inSession.setKariuketsukeBiToDay(strKariuketsukeBiToDay.substring(6, 8));
            }
        }

        /*�\��(����)������FROM*/
        groupCode = "moshikomikanryoBiFromDay";
        /*�N*/
        itemName = "�\��(����)������FROM�̔N";
        BmaValidator.validatePermissionSelect(inSession.getMoshikomikanryoBiFromYear(), inSession.getYearList(), errors, groupCode, itemName);
        /*��*/
        itemName = "�\��(����)������FROM�̌�";
        BmaValidator.validatePermissionSelect(inSession.getMoshikomikanryoBiFromMonth(), inSession.getMonthList(), errors, groupCode, itemName);
        /*��*/
        itemName = "�\��(����)������FROM�̓�";
        BmaValidator.validatePermissionSelect(inSession.getMoshikomikanryoBiFromDay(), inSession.getDayList(), errors, groupCode, itemName);
        /*�\��(����)������FROM*/
        itemName = "�\��(����)������FROM";
        if (!BmaUtility.isNullOrEmpty(inSession.getMoshikomikanryoBiFromDay())
                && !BmaUtility.isNullOrEmpty(inSession.getMoshikomikanryoBiFromMonth())
                && !BmaUtility.isNullOrEmpty(inSession.getMoshikomikanryoBiFromYear())) {
            /*�N�������I������Ă���Ƃ����ݓ��`�F�b�N*/
            String strMoshikomikanryoBiFromDay = inSession.getMoshikomikanryoBiFromYear() + inSession.getMoshikomikanryoBiFromMonth() + inSession.getMoshikomikanryoBiFromDay();
            if (BmaValidator.validateDate(strMoshikomikanryoBiFromDay, errors, groupCode, itemName)) {
                inSession.setMoshikomikanryoBiFromYear(strMoshikomikanryoBiFromDay.substring(0, 4));
                inSession.setMoshikomikanryoBiFromMonth(strMoshikomikanryoBiFromDay.substring(4, 6));
                inSession.setMoshikomikanryoBiFromDay(strMoshikomikanryoBiFromDay.substring(6, 8));
            }
        }
        /*�\��(����)������TO*/
        groupCode = "moshikomikanryoBiToDay";
        /*�N*/
        itemName = "�\��(����)������TO�̔N";
        BmaValidator.validatePermissionSelect(inSession.getMoshikomikanryoBiToYear(), inSession.getYearList(), errors, groupCode, itemName);
        /*��*/
        itemName = "�\��(����)������TO�̌�";
        BmaValidator.validatePermissionSelect(inSession.getMoshikomikanryoBiToMonth(), inSession.getMonthList(), errors, groupCode, itemName);

        /*��*/
        itemName = "�\��(����)������TO�̓�";
        BmaValidator.validatePermissionSelect(inSession.getMoshikomikanryoBiToDay(), inSession.getDayList(), errors, groupCode, itemName);
        /*�\��(����)������TO*/
        itemName = "�\��(����)������TO";
        if (!BmaUtility.isNullOrEmpty(inSession.getMoshikomikanryoBiToDay())
                && !BmaUtility.isNullOrEmpty(inSession.getMoshikomikanryoBiToMonth())
                && !BmaUtility.isNullOrEmpty(inSession.getMoshikomikanryoBiToYear())) {
            /*�N�������I������Ă���Ƃ����ݓ��`�F�b�N*/
            String strMoshikomikanryoBiToDay = inSession.getMoshikomikanryoBiToYear() + inSession.getMoshikomikanryoBiToMonth() + inSession.getMoshikomikanryoBiToDay();
            if (BmaValidator.validateDate(strMoshikomikanryoBiToDay, errors, groupCode, itemName)) {
                inSession.setMoshikomikanryoBiToYear(strMoshikomikanryoBiToDay.substring(0, 4));
                inSession.setMoshikomikanryoBiToMonth(strMoshikomikanryoBiToDay.substring(4, 6));
                inSession.setMoshikomikanryoBiToDay(strMoshikomikanryoBiToDay.substring(6, 8));
            }
        }

        if (inSession.getKessaiHoho() != null) {
            /*���ϕ��@*/
            groupCode = "KessaiHoho";
            itemName = "���ϕ��@";
            for (String komiKbn : inSession.getKessaiHoho()) {
                BmaValidator.validatePermissionSelect(komiKbn, inSession.getKessaiHohoList(), errors, groupCode, itemName);
                Validator.validateMaxLength(komiKbn, 1, errors, groupCode, itemName);
                break;
            }
        }

        if (inSession.getKessaiJokyoKbn() != null) {
            /*���Ϗ�*/
            groupCode = "KessaiJokyoKbn";
            itemName = "���Ϗ�";
            for (String komiKbn : inSession.getKessaiJokyoKbn()) {
                BmaValidator.validatePermissionSelect(komiKbn, inSession.getKessaiJokyoKbnList(), errors, groupCode, itemName);
                Validator.validateMaxLength(komiKbn, 1, errors, groupCode, itemName);
                break;
            }
        }

        if (inSession.getHoseiIraiKbn() != null) {
            /*�摜�␳�˗���*/
            groupCode = "HoseiIraiKbn";
            itemName = "�摜�␳�˗���";
            for (String komiKbn : inSession.getHoseiIraiKbn()) {
                BmaValidator.validatePermissionSelect(komiKbn, inSession.getHoseiIraiKbnList(), errors, groupCode, itemName);
                Validator.validateMaxLength(komiKbn, 1, errors, groupCode, itemName);
                break;
            }
        }

        if (inSession.getGohiJokyoKbn() != null) {
            /*���ۏ�*/
            groupCode = "gohiJokyoKbn";
            itemName = "���ۏ�";
            for (String komiKbn : inSession.getGohiJokyoKbn()) {
                BmaValidator.validatePermissionSelect(komiKbn, inSession.getGohiJokyoKbnList(), errors, groupCode, itemName);
                Validator.validateMaxLength(komiKbn, 2, errors, groupCode, itemName);
                break;
            }
        }

        if ("���������ۑ�".equals(inRequest.getTempSave())) {
            groupCode = "";
            itemName = "���������e���v���[�g�V�K�ۑ���";
            BmaValidator.validateRequired(inSession.getTempletSave(), errors, groupCode, itemName);
            Validator.validateMaxLength(inSession.getTempletSave(), 100, errors, groupCode, itemName);
        }

        if ("���������X�V".equals(inRequest.getTempUpdate())) {
            groupCode = "";
            itemName = "�����e���v���[�g";
            if (GenericValidator.isBlankOrNull(inRequest.getSearchChange()) || "�I��".equals(inRequest.getSearchChange())) {
                BmaValidator.addMessage(errors, "info", "�����e���v���[�g��I�����Ă��������B", "");
            }
            Validator.validateMaxLength(inRequest.getSearchChange(), 5, errors, groupCode, itemName);
        }

        if (!errors.isEmpty()) {
            inSession.setErrors(errors);
            return false;
        } else {
            return true;
        }
    }

    /**
     * ���̃��X�g���擾����
     *
     * @param groupCode
     * @return
     */
    public List<Option> findMeishoList(String groupCode) {
        List<Option> list = new ArrayList<>();
        //���̃��X�g��p�ӂ���
        MeishoKanri meishoKanri = new MeishoKanri(BmaConstants.DS_REGISTRANT);
        meishoKanri.findByGroupCode(groupCode, list);
        return list;
    }

    /**
     * �ڍׂ�������擾���A��ʂɃZ�b�g����
     *
     * @param groupCode
     * @return
     */
    private void setDtlJknList(HanyouSearchJoho inSession, String value) {

        HanyoKensakuDtlJkn hanyoKensakuDtlJkn = new HanyoKensakuDtlJkn(BmaConstants.DS_REGISTRANT);

        List<HanyouSearchJoho> dtlJknList = hanyoKensakuDtlJkn.findByKensakuId(value);
        String sknKsuKbnJokenChi = "";
        // ����
        String sknNmJokenChi = "";
        // �u�K��
        String ksuNmJokenChi = "";
        String strNayo[] = new String[6];
        String strMoshi[] = new String[2];
        String strMoshiKbn[] = new String[2];
        String strMoshiJyo[] = new String[4];
        // �z���\��
        String strComUmFlg[] = new String[2];
        String strKessaiHoho[] = new String[6];
        String strKessaiJokyoKbn[] = new String[3];
        String strHoseiIraiKbn[] = new String[7];
        String strGohiJokyoKbn[] = new String[4];

        for (int i = 0; i < dtlJknList.size(); ++i) {
            HanyouSearchJoho oneLine = dtlJknList.get(i);

            String jokenKomokuId = oneLine.getJokenKomokuId();
            switch (jokenKomokuId) {
                case "SKN_KSU_KBN":
                    sknKsuKbnJokenChi = sknKsuKbnJokenChi + oneLine.getJokenChi();
                    break;
                case "SKN_NM":
                    sknNmJokenChi = sknNmJokenChi + oneLine.getJokenChi();
                    break;
                case "KSU_NM":
                    ksuNmJokenChi = ksuNmJokenChi + oneLine.getJokenChi();
                    break;
                case "NENDO_FRM":
                    inSession.setNendoFrm(oneLine.getJokenChi());
                    break;
                case "NENDO_TO":
                    inSession.setNendoTo(oneLine.getJokenChi());
                    break;
                case "FURIGANA":
                    inSession.setFurigana(oneLine.getJokenChi());
                    break;
                case "BIRTHDAY":
                    String birthday = oneLine.getJokenChi();
                    inSession.setBirthYear(birthday.substring(0, 4));
                    inSession.setBirthMonth(birthday.substring(4, 6));
                    inSession.setBirthDay(birthday.substring(6));
                    break;
                case "KAIIN_KBN":
                    inSession.setKaiinKbn(oneLine.getJokenChi());
                    break;
                case "KIGYOCODE":
                    inSession.setKigyocode(oneLine.getJokenChi());
                    break;
                case "KINMUSAKI_NAME":
                    inSession.setKinmusakiName(oneLine.getJokenChi());
                    break;
                case "BANGO_NYURYOKU":
                    inSession.setBangoNyuryoku(oneLine.getJokenChi());
                    break;
                case "SHIKEN_NAIYO":
                    int num1 = Integer.parseInt(oneLine.getJokenGyoNo()) - 1;
                    if (num1 >= 0) {
                        strNayo[num1] = oneLine.getJokenChi();
                    }
                    break;
                case "MOSHIKOMI_HOHO":
                    int num2 = Integer.parseInt(oneLine.getJokenGyoNo()) - 1;
                    if (num2 >= 0) {
                        strMoshi[num2] = oneLine.getJokenChi();
                    }
                    break;
                case "MOSHIKOMI_KBN":
                    int num3 = Integer.parseInt(oneLine.getJokenGyoNo()) - 1;
                    if (num3 >= 0) {
                        strMoshiKbn[num3] = oneLine.getJokenChi();
                    }
                    break;
                case "MOSHIKOMI_JOKYO":
                    int num4 = Integer.parseInt(oneLine.getJokenGyoNo()) - 1;
                    if (num4 >= 0) {
                        strMoshiJyo[num4] = oneLine.getJokenChi();
                    }
                    break;
                case "HAIRYO_SHINSEI":
                    int num5 = Integer.parseInt(oneLine.getJokenGyoNo()) - 1;
                    if (num5 >= 0) {
                        strComUmFlg[num5] = oneLine.getJokenChi();
                    }
                    break;
                case "KARIUKETSUKE_BI_FROM":
                    String kariuketsukeBiFrom = oneLine.getJokenChi();
                    inSession.setKariuketsukeBiFromYear(kariuketsukeBiFrom.substring(0, 4));
                    inSession.setKariuketsukeBiFromMonth(kariuketsukeBiFrom.substring(4, 6));
                    inSession.setKariuketsukeBiFromDay(kariuketsukeBiFrom.substring(6));
                    break;
                case "KARIUKETSUKE_BI_TO":
                    String kariuketsukeBiTo = oneLine.getJokenChi();
                    inSession.setKariuketsukeBiToYear(kariuketsukeBiTo.substring(0, 4));
                    inSession.setKariuketsukeBiToMonth(kariuketsukeBiTo.substring(4, 6));
                    inSession.setKariuketsukeBiToDay(kariuketsukeBiTo.substring(6));
                    break;
                case "MOSHIKOMIKANRYO_BI_FROM":
                    String moshikomikanryoBiFrom = oneLine.getJokenChi();
                    inSession.setMoshikomikanryoBiFromYear(moshikomikanryoBiFrom.substring(0, 4));
                    inSession.setMoshikomikanryoBiFromMonth(moshikomikanryoBiFrom.substring(4, 6));
                    inSession.setMoshikomikanryoBiFromDay(moshikomikanryoBiFrom.substring(6));
                    break;
                case "MOSHIKOMIKANRYO_BI_TO":
                    String moshikomikanryoBiTo = oneLine.getJokenChi();
                    inSession.setMoshikomikanryoBiToYear(moshikomikanryoBiTo.substring(0, 4));
                    inSession.setMoshikomikanryoBiToMonth(moshikomikanryoBiTo.substring(4, 6));
                    inSession.setMoshikomikanryoBiToDay(moshikomikanryoBiTo.substring(6));
                    break;
                case "KESSAI_HOHO":
                    int num6 = Integer.parseInt(oneLine.getJokenGyoNo()) - 1;
                    if (num6 >= 0) {
                        strKessaiHoho[num6] = oneLine.getJokenChi();
                    }
                    break;
                case "KESSAI_JOKYO":
                    int num7 = Integer.parseInt(oneLine.getJokenGyoNo()) - 1;
                    if (num7 >= 0) {
                        strKessaiJokyoKbn[num7] = oneLine.getJokenChi();
                    }
                    break;
                case "HOSEI_IRAI_KBN":
                    int num8 = Integer.parseInt(oneLine.getJokenGyoNo()) - 1;
                    if (num8 >= 0) {
                        strHoseiIraiKbn[num8] = oneLine.getJokenChi();
                    }
                    break;
                case "GOHI_JOKYO":
                    int num9 = Integer.parseInt(oneLine.getJokenGyoNo()) - 1;
                    if (num9 >= 0) {
                        strGohiJokyoKbn[num9] = oneLine.getJokenChi();
                    }
                    break;
                default:
                    break;
            }
        }

        // �����@�u�K��̑I��
        inSession.setSknksuKbn(sknKsuKbnJokenChi);

        // ����
        inSession.setSknName(sknNmJokenChi);
        // �u�K��
        inSession.setKsuName(ksuNmJokenChi);
        // �������e
        inSession.setShikennaiyo(strNayo);
        // �\�����@
        inSession.setMoshikomiKbn(strMoshi);
        // �\���敪
        inSession.setKojinDantaiKbn(strMoshiKbn);
        // �\����
        inSession.setMoshikomiJokyoKbn(strMoshiJyo);
        // �z���\��
        inSession.setComUmFlg(strComUmFlg);
        // ���ϕ��@
        inSession.setKessaiHoho(strKessaiHoho);
        // ���Ϗ�
        inSession.setKessaiJokyoKbn(strKessaiJokyoKbn);
        // �摜�␳�˗���
        inSession.setHoseiIraiKbn(strHoseiIraiKbn);
        // ���ۏ�
        inSession.setGohiJokyoKbn(strGohiJokyoKbn);
    }
}
