package jp.co.nii.bma.integration;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import jp.co.nii.bma.business.domain.Gazo;
import jp.co.nii.bma.business.domain.GazoDao;
import static jp.co.nii.bma.business.domain.GeneratedGazoDao.TABLE_NAME;
import jp.co.nii.bma.business.rto.manager.GazoKanriJoho;
import jp.co.nii.bma.business.rto.manager.SmnMskJoho;
import jp.co.nii.bma.business.service.common.BmaConstants;
import static jp.co.nii.bma.integration.GeneratedGazoDaoImpl.FIELDS_DECRYPT;
import jp.co.nii.sew.common.LogGenerate;
import static jp.co.nii.sew.integration.AbstractDao.getSchemaName;
import jp.co.nii.sew.integration.SQLStateSQLExceptionTranslater;
import org.apache.commons.validator.GenericValidator;

/**
 * �摜 DAO�����N���X
 *
 * @author DB�Ǘ��c�[��
 */
public class GazoDaoImpl extends GeneratedGazoDaoImpl implements GazoDao {

    /**
     * �C���X�^���X�𐶐�����B
     *
     * @param datasource �f�[�^�\�[�X��
     */
    public GazoDaoImpl(String datasource) {
        super(datasource);
    }

    /**
     * �ꗗ�̏����擾����B
     *
     * @return �摜�ꗗ��񃊃X�g
     */
    @Override
    public List<GazoKanriJoho> searchGazoList(GazoKanriJoho bo) {
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = "";
        int intCD = 0;
        List<String> param = new ArrayList<>();
        GazoKanriJoho gazoKanriJoho = null;
        String sknKsuCode = bo.getSknKsuCode();
        String nendo = bo.getNendo();
        String shubetsuCode = bo.getShubetsuCode();
        String kaisuCode = bo.getKaisuCode();
        String gazoShuruiChoice = bo.getGazoShuruiChoice();
        List<String> gazoStatus = null;
        if (bo.getChkGazoStatusChoice() != null) {
            gazoStatus = Arrays.asList(bo.getChkGazoStatusChoice()).stream().filter(str->str != null && !"".equals(str)).collect(Collectors.toList());
        }
        String uketukeNo = bo.getUketukeNo();
        String hoseiKigenBi = bo.getHoseiKigenBi();
        String hoseiKigen = bo.getHoseiKigen();
        String jknJkuNo = bo.getJknJkuNo();
        String furigana = bo.getFurigana();
        String max = String.valueOf(BmaConstants.MAX_DISP_NUM_MSK_JOHO_SEARCH);
        String pagemax = String.valueOf(BmaConstants.MAX_PAGE_NUM_MSK_JOHO_SEARCH);
        String first = String.valueOf(bo.getPage() * BmaConstants.MAX_PAGE_NUM_MSK_JOHO_SEARCH);
        String searchFlag = bo.getSearchFlg();
        List<String> mskKbn = null;
        if (bo.getChkMskKbn() != null) {
            mskKbn = Arrays.asList(bo.getChkMskKbn()).stream().filter(str->str != null && !"".equals(str)).collect(Collectors.toList());
        }
        List<String> kojinDantai = null;
        if (bo.getChkKojinDantai() != null) {
            kojinDantai = Arrays.asList(bo.getChkKojinDantai()).stream().filter(str->str != null && !"".equals(str)).collect(Collectors.toList());
        }
        String sqlAnd = "";
        String limit = "";
        if (gazoStatus != null) {
            if (gazoStatus.size() > 0) {
                sqlAnd = sqlAnd + " AND G1.HOSEI_IRAI_KBN IN (";
                for (intCD = 0; intCD < gazoStatus.size(); intCD++) {
                    if (intCD > 0) {
                        sqlAnd = sqlAnd + ", ";
                    }
                    sqlAnd = sqlAnd + "?";
                }
                sqlAnd = sqlAnd + ") ";
            }
        } else {
        }
        if (!GenericValidator.isBlankOrNull(hoseiKigen)) {
                sqlAnd = sqlAnd + " AND G1.HOSEI_KIGEN_BI <= ?";
                sqlAnd = sqlAnd + " AND G1.HOSEI_IRAI_KBN IN (";
                for (intCD = 0; intCD < 2; intCD++) {
                    if (intCD > 0) {
                        sqlAnd = sqlAnd + ", ";
                    }
                    sqlAnd = sqlAnd + "?";
                }
                sqlAnd = sqlAnd + ") ";
        }
        if (!GenericValidator.isBlankOrNull(uketukeNo)) {
            sqlAnd = sqlAnd + " AND M1.UKETSUKE_NO = ?";
        }
        if (!GenericValidator.isBlankOrNull(jknJkuNo)) {
            sqlAnd = sqlAnd + " AND M1.JUKEN_JUKO_NO = ?";
        }
        if (!GenericValidator.isBlankOrNull(furigana)) {
            sqlAnd = sqlAnd + " AND " + getSQLForDecryptByUTF8NotAs("T1.FURIGANA") + " LIKE ?";
        }
        if (mskKbn != null) {
            if (mskKbn.size() > 0) {
                sqlAnd = sqlAnd + " AND M1.MOSHIKOMI_KBN IN (";
                for (intCD = 0; intCD < mskKbn.size(); intCD++) {
                    if (intCD > 0) {
                        sqlAnd = sqlAnd + ", ";
                    }
                    sqlAnd = sqlAnd + "?";
                }
                sqlAnd = sqlAnd + ") ";
            }
        } else {
        }
        if (kojinDantai != null) {
            if (kojinDantai.size() > 0) {
                sqlAnd = sqlAnd + " AND M1.KOJIN_DANTAI_KBN IN (";
                for (intCD = 0; intCD < kojinDantai.size(); intCD++) {
                    if (intCD > 0) {
                        sqlAnd = sqlAnd + ", ";
                    }
                    sqlAnd = sqlAnd + "?";
                }
                sqlAnd = sqlAnd + ") ";
            }
        } else {
        }
//        if (searchFlag.equals("0")) {
//            limit = limit + " LIMIT " + max;
//        } else {
//            limit = limit + " LIMIT " + pagemax + " OFFSET " + first;
//        }
        List<GazoKanriJoho> gazoList = new ArrayList<>();
        try {
            con = getConnection();
            sql = "SELECT GAZO_IDX,SEQ,GAZO_KBN,M1.NENDO,M1.MOSHIKOMISHA_ID,M1.UKETSUKE_NO,M1.JUKEN_JUKO_NO,"
                    + getSQLForDecryptByUTF8("FURIGANA") + ","
                    + getSQLForDecryptByUTF8("SHIMEI") + ","
                    + getSQLForDecryptByUTF8("BIRTHDAY") + ","
                    + " HOSEI_IRAI_CODE_1,HOSEI_IRAI_CODE_2,HOSEI_IRAI_CODE_3,"
                    + " KOJIN_DANTAI.HANYO_CODE AS KOJIN_DANTAI_KBN,"
                    + " KOJIN_DANTAI.HANYO_CHI AS KOJIN_DANTAI_CHI,"
                    + " YUUSOU_NET.HANYO_CODE AS YUUSOU_NET_KBN,"
                    + " YUUSOU_NET.HANYO_CHI AS YUUSOU_NET_CHI,"
                    + " STATUS.HANYO_CODE AS STATUS,"
                    + " STATUS.HANYO_CHI AS STATUSCHI,"
                    + " CASE WHEN GAZO_HYOJI_KBN = '2' THEN '2'"
                    + " WHEN GAZO_HYOJI_KBN = '1' THEN '1'"
                    + " ELSE '' END AS SHINSHA,"
                    + " G1.KOSHIN_DATE, G1.KOSHIN_TIME,"
                    + " M2.MENJO_CODE, M2.SHIKAKU_CODE,"
                    + " M2.SHINSEI_SHIKAKU_NO, M2.SHINSEI_MENJO_NO"
                    + " FROM " + getSchemaName() + "." + TABLE_NAME + " AS G1"
                    + " INNER JOIN BMA.MOSHIKOMI AS M1"
                    + " ON G1.UKETSUKE_NO = M1.UKETSUKE_NO"
                    + " AND G1.NENDO = M1.NENDO"
                    + " INNER JOIN BMA.TOROKUSHA AS T1"
                    + " ON M1.MOSHIKOMISHA_ID = T1.MOSHIKOMISHA_ID"
                    + " LEFT JOIN BMA.SKNKSU_MST AS S1"
                    + " ON M1.SKN_KSU_CODE = S1.SKN_KSU_CODE"
                    + " AND M1.SHUBETSU_CODE = S1.SHUBETSU_CODE"
                    + " AND M1.KAISU_CODE = S1.KAISU_CODE"
                    + " LEFT JOIN BMA.MEISHO_KANRI AS KOJIN_DANTAI"
                    + " ON KOJIN_DANTAI.GROUP_CODE = 'KOJIN_DANTAI_KBN'"
                    + " AND KOJIN_DANTAI.HANYO_CODE = M1.KOJIN_DANTAI_KBN"
                    + " LEFT JOIN BMA.MEISHO_KANRI AS YUUSOU_NET"
                    + " ON YUUSOU_NET.GROUP_CODE = 'MOSHIKOMI_KBN'"
                    + " AND YUUSOU_NET.HANYO_CODE = M1.MOSHIKOMI_KBN"
                    + " LEFT JOIN BMA.MEISHO_KANRI AS STATUS"
                    + " ON STATUS.GROUP_CODE = 'HOSEI_IRAI_KBN'"
                    + " AND STATUS.HANYO_CODE = G1.HOSEI_IRAI_KBN"
                    + " LEFT JOIN BMA.M_SKK_MNJ_KANRI AS M2"
                    + " ON M2.UKETSUKE_NO = M1.UKETSUKE_NO"
                    + " AND M2.NENDO = M1.NENDO"
                    + " WHERE S1.SKN_KSU_CODE = ?"
                    + " AND S1.SHUBETSU_CODE = ?"
                    + " AND S1.KAISU_CODE = ?"
                    + " AND GAZO_KBN = ?"
                    + sqlAnd
                    + " AND M1.NENDO = ?"
                    + " ORDER BY G1.UKETSUKE_NO ASC, G1.SEQ ASC";
//                    + limit;
            param.add(sknKsuCode);
            param.add(shubetsuCode);
            param.add(kaisuCode);
            param.add(gazoShuruiChoice);
            if (gazoStatus != null) {
                for (intCD = 0; intCD < gazoStatus.size(); intCD++) {
                    param.add(gazoStatus.get(intCD));
                }
            } else {
            }
            if (!GenericValidator.isBlankOrNull(hoseiKigen)) {
                param.add(hoseiKigenBi);
            }
            if (!GenericValidator.isBlankOrNull(hoseiKigen)) {
                param.add("1");
                param.add("6");
            }
            if (!GenericValidator.isBlankOrNull(uketukeNo)) {
                param.add(uketukeNo);
            }
            if (!GenericValidator.isBlankOrNull(jknJkuNo)) {
                param.add(jknJkuNo);
            }
            if (!GenericValidator.isBlankOrNull(furigana)) {
                param.add("%" + furigana + "%");
            }
            if (mskKbn != null) {
                for (intCD = 0; intCD < mskKbn.size(); intCD++) {
                    param.add(mskKbn.get(intCD));
                }
            } else {
            }
            if (kojinDantai != null) {
                for (intCD = 0; intCD < kojinDantai.size(); intCD++) {
                    param.add(kojinDantai.get(intCD));
                }
            } else {
            }
            param.add(nendo);

            stmt = con.prepareStatement(sql);
            int i = 1;
            for (String pm : param) {
                stmt.setString(i++, pm);
            }

            LogGenerate.debugOutput(getSql(stmt));
            
            // for test
            LogGenerate.infoOutput(getSql(stmt));
            
            rs = stmt.executeQuery();
            while (rs.next()) {
                gazoKanriJoho = new GazoKanriJoho();
                gazoKanriJoho.setMoshikomishaId(rs.getString("MOSHIKOMISHA_ID"));
                gazoKanriJoho.setNendo(rs.getString("NENDO"));
                gazoKanriJoho.setGazo_idx(rs.getString("GAZO_IDX"));
                gazoKanriJoho.setSeq(rs.getString("SEQ"));
                gazoKanriJoho.setGazoKbn(rs.getString("GAZO_KBN"));
                gazoKanriJoho.setUketukeNo(rs.getString("UKETSUKE_NO"));
                gazoKanriJoho.setJknJkuNo(rs.getString("JUKEN_JUKO_NO"));
                gazoKanriJoho.setFurigana(rs.getString("FURIGANA"));
                gazoKanriJoho.setBirthday(rs.getString("BIRTHDAY"));
                gazoKanriJoho.setShimei(rs.getString("SHIMEI"));
                gazoKanriJoho.setFubiRiyu1(rs.getString("HOSEI_IRAI_CODE_1"));
                gazoKanriJoho.setFubiRiyu2(rs.getString("HOSEI_IRAI_CODE_2"));
                gazoKanriJoho.setFubiRiyu3(rs.getString("HOSEI_IRAI_CODE_3"));
                gazoKanriJoho.setKojinDantaiKbn(rs.getString("KOJIN_DANTAI_KBN"));
                gazoKanriJoho.setKojinDantaiChi(rs.getString("KOJIN_DANTAI_CHI"));
                gazoKanriJoho.setYusounetKbn(rs.getString("YUUSOU_NET_KBN"));
                gazoKanriJoho.setYusounetChi(rs.getString("YUUSOU_NET_CHI"));
                gazoKanriJoho.setGazoStatus(rs.getString("STATUS"));
                gazoKanriJoho.setGazoStatusChi(rs.getString("STATUSCHI"));
                gazoKanriJoho.setKoshin_date(rs.getString("KOSHIN_DATE"));
                gazoKanriJoho.setKoshin_time(rs.getString("KOSHIN_TIME"));
                gazoList.add(gazoKanriJoho);
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return gazoList;
    }

    /**
     * �摜�ڍׂ��擾����B
     *
     * @return �摜�ڍ׃��X�g
     */
    @Override
    public List<GazoKanriJoho> searchGazoShosai(GazoKanriJoho bo) {
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = "";
        List<String> param = new ArrayList<>();
        GazoKanriJoho gazoKanriJoho = null;
        String nendo = bo.getNendo();
        String uketsukeNo = bo.getUketukeNo();
        String gazoKbn = bo.getGazoKbn();
        String seq = bo.getSeq();
        List<GazoKanriJoho> gazoList = new ArrayList<>();
        try {
            con = getConnection();
            sql = "SELECT GAZO_KBN,SEQ,M1.MOSHIKOMISHA_ID,M1.NENDO,M1.UKETSUKE_NO,M1.JUKEN_JUKO_NO,"
                    + getSQLForDecryptByUTF8("FURIGANA") + ","
                    + getSQLForDecryptByUTF8("SHIMEI") + ","
                    + " GENMEN.HANYO_CODE AS GENMEN,"
                    + getSQLForDecryptByUTF8("BIRTHDAY") + ","
                    + " M1.NENREI,GAZO_IDX,"
                    + " CASE WHEN GAZO_HYOJI_KBN = '2' THEN '2'"
                    + " WHEN GAZO_HYOJI_KBN = '1' THEN '1'"
                    + " ELSE '' END AS SHINSHA,"
                    + " G1.HOSEI_IRAI_CODE_1 AS FUBIRIYU1,"
                    + " G1.HOSEI_IRAI_CODE_2 AS FUBIRIYU2,"
                    + " G1.HOSEI_IRAI_CODE_3 AS FUBIRIYU3,"
                    + " M2.MENJO_CODE, M2.SHIKAKU_CODE,"
                    + " M2.SHINSEI_SHIKAKU_NO, M2.SHINSEI_MENJO_NO,"
                    + " M1.KANRI_MEMO AS BIKO,G1.KOSHIN_DATE,G1.KOSHIN_TIME"
                    + " FROM " + getSchemaName() + "." + TABLE_NAME + " AS G1"
                    + " INNER JOIN BMA.MOSHIKOMI AS M1"
                    + " ON G1.UKETSUKE_NO = M1.UKETSUKE_NO"
                    + " AND G1.NENDO = M1.NENDO"
                    + " LEFT JOIN BMA.M_SKK_MNJ_KANRI AS M2"
                    + " ON M2.UKETSUKE_NO = M1.UKETSUKE_NO"
                    + " AND M2.NENDO = M1.NENDO"
                    + " INNER JOIN BMA.TOROKUSHA AS T1"
                    + " ON M1.MOSHIKOMISHA_ID = T1.MOSHIKOMISHA_ID"
                    + " LEFT JOIN BMA.MEISHO_KANRI AS GENMEN"
                    + " ON GENMEN.GROUP_CODE = 'COM_UMU_FLG'"
                    + " AND GENMEN.HANYO_CODE = M1.GENMEN_FLG"
                    + " WHERE G1.NENDO = ?"
                    + " AND G1.UKETSUKE_NO= ?"
                    + " AND G1.GAZO_KBN= ?"
                    + " AND G1.SEQ= ?";
            param.add(nendo);
            param.add(uketsukeNo);
            param.add(gazoKbn);
            param.add(seq);
            stmt = con.prepareStatement(sql);
            int i = 1;
            for (String pm : param) {
                stmt.setString(i++, pm);
            }

            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();
            while (rs.next()) {
                gazoKanriJoho = new GazoKanriJoho();
                gazoKanriJoho.setMoshikomishaId(rs.getString("MOSHIKOMISHA_ID"));
                gazoKanriJoho.setNendo(rs.getString("NENDO"));
                gazoKanriJoho.setGazoKbn(rs.getString("GAZO_KBN"));
                gazoKanriJoho.setSeq(rs.getString("SEQ"));
                gazoKanriJoho.setUketukeNo(rs.getString("UKETSUKE_NO"));
                gazoKanriJoho.setJknJkuNo(rs.getString("JUKEN_JUKO_NO"));
                gazoKanriJoho.setFurigana(rs.getString("FURIGANA"));
                gazoKanriJoho.setShimei(rs.getString("SHIMEI"));
                gazoKanriJoho.setFubiRiyu1(rs.getString("FUBIRIYU1"));
                gazoKanriJoho.setFubiRiyu2(rs.getString("FUBIRIYU2"));
                gazoKanriJoho.setFubiRiyu3(rs.getString("FUBIRIYU3"));
                gazoKanriJoho.setShinsaKekka(rs.getString("SHINSHA"));
                gazoKanriJoho.setBirthday(rs.getString("BIRTHDAY"));
                gazoKanriJoho.setNenrei(rs.getString("NENREI"));
                gazoKanriJoho.setGazo_idx(rs.getString("GAZO_IDX"));
                gazoKanriJoho.setGenmen(rs.getString("GENMEN"));
                gazoKanriJoho.setShikakuCode(rs.getString("SHIKAKU_CODE"));
                gazoKanriJoho.setMenjoCode(rs.getString("MENJO_CODE"));
                gazoKanriJoho.setShinseiShikakuNo(rs.getString("SHINSEI_SHIKAKU_NO"));
                gazoKanriJoho.setShinseiMenjoNo(rs.getString("SHINSEI_MENJO_NO"));
                gazoKanriJoho.setBiko(rs.getString("BIKO"));
                gazoKanriJoho.setKoshin_date(rs.getString("KOSHIN_DATE"));
                gazoKanriJoho.setKoshin_time(rs.getString("KOSHIN_TIME"));
                gazoList.add(gazoKanriJoho);
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return gazoList;
    }

    /**
     * �摜�A�b�v���[�h�f�[�^�̏����擾����B
     *
     * @param bo
     * @return �摜�ꗗ��񃊃X�g
     */
    @Override
    public List<SmnMskJoho> searchGazoDateList(SmnMskJoho bo) {
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = "";
        int intCD = 0;
        List<String> param = new ArrayList<>();
        SmnMskJoho smnMskJoho = null;
        String max = String.valueOf(BmaConstants.MAX_DISP_NUM_MSK_JOHO_SEARCH);
        String pagemax = String.valueOf(BmaConstants.MAX_PAGE_NUM_MSK_JOHO_SEARCH);
        String first = String.valueOf(bo.getPage() * BmaConstants.MAX_PAGE_NUM_MSK_JOHO_SEARCH);
        String sqlAnd = "";
        String limit = "";
//        if (bo.getSearchFlg().equals("0")) {
//            limit = limit + " LIMIT " + max;
//        } else {
//            limit = limit + " LIMIT " + pagemax + " OFFSET " + first;
//        }
        List<SmnMskJoho> gazoDateList = new ArrayList<>();
        try {
            con = getConnection();
            sql = "SELECT GAZO_KBN,GAZO_IDX,SEQ,M1.MOSHIKOMISHA_ID,M1.NENDO,M1.UKETSUKE_NO,M1.JUKEN_JUKO_NO,"
                    + getSQLForDecryptByUTF8("FURIGANA") + ","
                    + getSQLForDecryptByUTF8("SHIMEI") + ","
                    + " CASE WHEN GAZO_HYOJI_KBN = '4' THEN '��'"
                    + " ELSE '��' END AS GAZO_UI_FLG"
                    + " FROM " + getSchemaName() + "." + TABLE_NAME + " AS G1"
                    + " INNER JOIN BMA.MOSHIKOMI AS M1"
                    + " ON G1.UKETSUKE_NO = M1.UKETSUKE_NO"
                    + " AND G1.NENDO = M1.NENDO"
                    + " INNER JOIN BMA.TOROKUSHA AS T1"
                    + " ON M1.MOSHIKOMISHA_ID = T1.MOSHIKOMISHA_ID"
                    + " WHERE M1.SKN_KSU_CODE = ?"
                    + " AND M1.SHUBETSU_CODE = ?"
                    + " AND M1.KAISU_CODE = ?"
                    + " AND G1.GAZO_HYOJI_KBN = '4'"
                    + " AND G1.GAZO_KBN = '00'"
                    + " AND M1.NENDO = ?"
                    + " ORDER BY G1.UKETSUKE_NO ASC,"
                    + " G1.SEQ ASC";
//                    + limit;

            param.add(bo.getSknKsuCode());
            param.add(bo.getShubetsuCode());
            param.add(bo.getKaisuCode());
            param.add(bo.getNendo());

            stmt = con.prepareStatement(sql);
            int i = 1;
            for (String pm : param) {
                stmt.setString(i++, pm);
            }

            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();
            while (rs.next()) {
                smnMskJoho = new SmnMskJoho();
                smnMskJoho.setMoshikomishaId(rs.getString("MOSHIKOMISHA_ID"));
                smnMskJoho.setNendo(rs.getString("NENDO"));
                smnMskJoho.setGazoKbn(rs.getString("GAZO_KBN"));
                smnMskJoho.setSeq(rs.getString("SEQ"));
                smnMskJoho.setGazo_idx(rs.getString("GAZO_IDX"));
                smnMskJoho.setGazoUlUketsukeNo(rs.getString("UKETSUKE_NO"));
                smnMskJoho.setGazoUlJknJkuNo(rs.getString("JUKEN_JUKO_NO"));
                smnMskJoho.setGazoUlFurigana(rs.getString("FURIGANA"));
                smnMskJoho.setGazoUlSimei(rs.getString("SHIMEI"));
                smnMskJoho.setGazoUlFlg(rs.getString("GAZO_UI_FLG"));
                gazoDateList.add(smnMskJoho);
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return gazoDateList;
    }

    /**
     * �摜�A�b�v���[�h�f�[�^�̏����擾����B
     *
     * @param bo
     * @return �摜�ꗗ��񃊃X�g
     */
    @Override
    public List<SmnMskJoho> searchGazoListShomen(SmnMskJoho bo) {
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = "";
        int intCD = 0;
        List<String> param = new ArrayList<>();
        SmnMskJoho smnMskJoho = null;
        String max = String.valueOf(BmaConstants.MAX_DISP_NUM_MSK_JOHO_SEARCH);
        String pagemax = String.valueOf(BmaConstants.MAX_PAGE_NUM_MSK_JOHO_SEARCH);
        String first = String.valueOf(bo.getPage() * BmaConstants.MAX_PAGE_NUM_MSK_JOHO_SEARCH);
        String sqlAnd = "";
        String limit = "";
//        if (bo.getSearchFlg().equals("0")) {
//            limit = limit + " LIMIT " + max;
//        } else {
//            limit = limit + " LIMIT " + pagemax + " OFFSET " + first;
//        }
        List<String> uketsukeNos = null;
        if (bo.getUketsukeNos() != null) {
            uketsukeNos = Arrays.asList(bo.getUketsukeNos());
        }
        if (uketsukeNos != null) {
            if (uketsukeNos.size() > 0) {
                sqlAnd = sqlAnd + " AND G1.UKETSUKE_NO IN (";
                for (intCD = 0; intCD < uketsukeNos.size(); intCD++) {
                    if (intCD > 0) {
                        sqlAnd = sqlAnd + ", ";
                    }
                    sqlAnd = sqlAnd + "?";
                }
                sqlAnd = sqlAnd + ") ";
            }
        } else {
        }
        List<SmnMskJoho> gazoDateList = new ArrayList<>();
        try {
            con = getConnection();
            sql = "SELECT GAZO_KBN,GAZO_IDX,SEQ,M1.UKETSUKE_NO,M1.MOSHIKOMISHA_ID,M1.NENDO,M1.JUKEN_JUKO_NO,"
                    + getSQLForDecryptByUTF8("FURIGANA") + ","
                    + getSQLForDecryptByUTF8("SHIMEI") + ","
                    + " CASE WHEN GAZO_HYOJI_KBN = '4' THEN '��'"
                    + " ELSE '��' END AS GAZO_UI_FLG"
                    + " FROM " + getSchemaName() + "." + TABLE_NAME + " AS G1"
                    + " INNER JOIN BMA.MOSHIKOMI AS M1"
                    + " ON G1.UKETSUKE_NO = M1.UKETSUKE_NO"
                    + " AND G1.NENDO = M1.NENDO"
                    + " INNER JOIN BMA.TOROKUSHA AS T1"
                    + " ON M1.MOSHIKOMISHA_ID = T1.MOSHIKOMISHA_ID"
                    + " WHERE G1.NENDO = ?"
                    + sqlAnd
                    + " ORDER BY G1.UKETSUKE_NO ASC,"
                    + " G1.SEQ ASC";
//                    + limit;

            param.add(bo.getNendo());
            if (uketsukeNos != null) {
                for (intCD = 0; intCD < uketsukeNos.size(); intCD++) {
                    param.add(uketsukeNos.get(intCD));
                }
            }

            stmt = con.prepareStatement(sql);
            int i = 1;
            for (String pm : param) {
                stmt.setString(i++, pm);
            }

            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();
            while (rs.next()) {
                smnMskJoho = new SmnMskJoho();
                smnMskJoho.setGazoKbn(rs.getString("GAZO_KBN"));
                smnMskJoho.setMoshikomishaId(rs.getString("MOSHIKOMISHA_ID"));
                smnMskJoho.setNendo(rs.getString("NENDO"));
                smnMskJoho.setSeq(rs.getString("SEQ"));
                smnMskJoho.setGazo_idx(rs.getString("GAZO_IDX"));
                smnMskJoho.setGazoUlUketsukeNo(rs.getString("UKETSUKE_NO"));
                smnMskJoho.setGazoUlJknJkuNo(rs.getString("JUKEN_JUKO_NO"));
                smnMskJoho.setGazoUlFurigana(rs.getString("FURIGANA"));
                smnMskJoho.setGazoUlSimei(rs.getString("SHIMEI"));
                smnMskJoho.setGazoUlFlg(rs.getString("GAZO_UI_FLG"));
                gazoDateList.add(smnMskJoho);
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return gazoDateList;
    }
    
    @Override
    public List<Gazo> findByNendoUke(String nendo, String uketsukeNo) {
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = "";

        List<Gazo> ret = new ArrayList<>();
        try {
            con = getConnection();
            sql = "SELECT " + FIELDS_DECRYPT
                    + " FROM " + getSchemaName() + "." + TABLE_NAME
                    + " WHERE"
                    + " NENDO = ?"
                    + " AND UKETSUKE_NO = ?"
                    + " ORDER BY gazo_kbn";
            stmt = con.prepareStatement(sql);
            int i = 1;
            stmt.setString(i++, nendo);
            stmt.setString(i++, uketsukeNo);

            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();
            while (rs.next()) {
                Gazo bo = new Gazo();
                setBoFromResultSet(bo, rs);
                ret.add(bo);
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return ret;
    }
}
