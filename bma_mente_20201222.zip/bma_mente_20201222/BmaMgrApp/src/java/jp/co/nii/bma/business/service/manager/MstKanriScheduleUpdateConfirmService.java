package jp.co.nii.bma.business.service.manager;

import java.util.Arrays;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import jp.co.nii.bma.business.domain.Schedule;
import jp.co.nii.bma.business.rto.manager.MstKanriScheduleJoho;
import jp.co.nii.bma.business.service.common.BmaConstants;
import jp.co.nii.bma.business.service.common.BmaLogger;
import jp.co.nii.bma.business.service.common.BmaValidator;
import jp.co.nii.bma.presentation.common.BmaText;
import jp.co.nii.bma.utility.BmaUtility;
import jp.co.nii.sew.business.SystemTime;
import jp.co.nii.sew.business.service.AbstractService;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_SUCCESS;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_RELOAD;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_BACK;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_EXCEPTION;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_SESSION;
import jp.co.nii.sew.presentation.Messages;
import jp.co.nii.sew.presentation.RequestTransferObject;
import jp.co.nii.sew.utility.PropertyUtility;
import org.apache.commons.beanutils.BeanUtils;

/**
 *
 * @author nii19042
 */
public class MstKanriScheduleUpdateConfirmService extends AbstractService {

    /**
     * DB�ڑ��̃f�[�^�\�[�X
     */
    private static String DATA_SOURCE_NAME;
    /**
     * ���O
     */
    BmaLogger log = (BmaLogger) BmaLogger.getLogger(this.getClass().getName());
    /**
     * �Ɩ��R�[�h
     */
    private static final String BUSINESS_CODE = PropertyUtility.getProperty("business_code");
    /**
     * ���׃e�X�g���[�h
     */
    private static final String STRESS_MODE = PropertyUtility.getProperty(BUSINESS_CODE + "stress_mode");

    /**
     * �R���X�g���N�^
     */
    public MstKanriScheduleUpdateConfirmService() {
        super();
        /* DB�ڑ����̃��[�U�[������ */
        DATA_SOURCE_NAME = BmaConstants.DS_REGISTRANT;
    }

    /**
     * �T�[�r�X�N���X�̎��s���\�b�h
     *
     * @param rto ���N�G�X�g��񂩂�擾����rto
     * @param rtoInSession �Z�b�V�������rto
     * @return foward��
     * @throws Exception ��O
     */
    @Override
    public String doService(RequestTransferObject rto, RequestTransferObject rtoInSession)
            throws Exception {

        MstKanriScheduleJoho inRequest = (MstKanriScheduleJoho) rto;
        MstKanriScheduleJoho inSession = (MstKanriScheduleJoho) rtoInSession;
        String processName = "";

        /*�G���[���b�Z�[�W������*/
        inSession.setErrors(new Messages());
        try {
        if (!BmaUtility.isNullOrEmpty(inRequest.getScheduleUpdComp())) {
                /*�u�m��v�{�^��������*/
                processName = "MstKanriScheduleUpdateConfirm";
                log.Start(processName);

                /* �ϐ������� */
                Messages errors = new Messages();
                Boolean getNendoNow = false;
                String nendoNowIn = "";
                Schedule scheduleStart  = null;
                Schedule scheduleEnd  = null;
                Schedule scheduleBase  = null;
                String scheduleKbnStart = "";
                String scheduleKbnEnd = "";

                /* ��L�[�擾 */
                Schedule scheduleUpd = new Schedule(DATA_SOURCE_NAME);
                String nendo = inSession.getNendo();
                String sknKsuCode = inSession.getSknKsuCode();
                String shubetsuCode = inSession.getShubetsuCode();
                String kaisuCode = inSession.getKaisuCode();

                /* �o�^����Ă���f�[�^�̔N�x���擾 */
                try {
                    nendoNowIn = scheduleUpd.findNendoKojiKikan(sknKsuCode, shubetsuCode, kaisuCode, BmaConstants.SCHED_CODE_OPEN, BmaConstants.SCHEDULE_KBN_ST);
                    getNendoNow = true;
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
                if (BmaUtility.isNullOrEmpty(nendoNowIn) || !getNendoNow) {
                    /* �N�x���擾�ł��Ȃ������ꍇ�u�X�P�W���[���ύX�m�F�v���Reload */
                    BmaValidator.addMessage(errors, "scheduleData", BmaText.E00120, "�N�x");
                    inSession.setErrors(errors);
                    return FWD_NM_RELOAD;
                }

                /* ���͒l�`�F�b�N */
                if(!validateInput(inSession)){
                    // �G���[���������ꍇ�u�X�P�W���[���ύX�m�F�v���Reload
                    return FWD_NM_RELOAD;
                } else {
                    try {
                        /* �g�����U�N�V�����擾&�J�n */
                        getTransaction();
                        beginTransaction();

                        if (nendoNowIn.equals(nendo)) {
                            // �N�x��v �� �X�V����
                            for (MstKanriScheduleJoho schedule : inSession.getScheduleInputList()) {
                                /* �X�P�W���[���敪���� */
                                if (   !BmaUtility.isNullOrEmpty(schedule.getStartYear())
                                    && !BmaUtility.isNullOrEmpty(schedule.getEndYear())) {
                                    // �J�n���E�I����������ꍇ
                                    scheduleKbnStart = BmaConstants.SCHEDULE_KBN_ST;
                                    scheduleKbnEnd = BmaConstants.SCHEDULE_KBN_ED;

                                    // ��L�[���X�P�W���[���f�[�^�擾
                                    scheduleStart  = scheduleUpd.lockNoWait(nendo, sknKsuCode, shubetsuCode, kaisuCode, schedule.getScheduleCode(), scheduleKbnStart);
                                    scheduleEnd  = scheduleUpd.lockNoWait(nendo, sknKsuCode, shubetsuCode, kaisuCode, schedule.getScheduleCode(), scheduleKbnEnd);

                                    if (   scheduleStart != null
                                        && scheduleEnd != null) {
                                        /* �J�n���E�I�����Ƃ��Ɏ擾�ł�����X�V������ */
                                        // �J�n��
                                        BeanUtils.copyProperties(scheduleUpd, scheduleStart);
                                        setScheduleUpdate(scheduleUpd, schedule, inRequest);
                                        scheduleUpd.update();
                                        // �I����
                                        BeanUtils.copyProperties(scheduleUpd, scheduleEnd);
                                        setScheduleUpdate(scheduleUpd, schedule, inRequest);
                                        scheduleUpd.update();
                                    } else if (   BmaConstants.SCHED_CODE_CANT_UPD1.equals(schedule.getScheduleCode())
                                               || BmaConstants.SCHED_CODE_CANT_UPD2.equals(schedule.getScheduleCode())) {
                                        // �C���s���Ԃ��V�K���͂��ꂽ�ꍇ �� �V�K�o�^
                                        // �J�n��
                                        setScheduleInsert(scheduleUpd, schedule, inRequest, inSession, scheduleKbnStart);
                                        scheduleUpd.create();
                                        // �I����
                                        setScheduleInsert(scheduleUpd, schedule, inRequest, inSession, scheduleKbnEnd);
                                        scheduleUpd.create();
                                    } else {
                                        /* Update����f�[�^���擾�ł��Ȃ������ꍇ�u�X�P�W���[���ύX�m�F�v���Reload */
                                        BmaValidator.addMessage(errors, "scheduleData", BmaText.E00120, schedule.getScheduleName());
                                        inSession.setErrors(errors);
                                        return FWD_NM_RELOAD;
                                    }
                                } else if (   !BmaUtility.isNullOrEmpty(schedule.getStartYear())
                                           && BmaUtility.isNullOrEmpty(schedule.getEndYear())) {
                                    // ����̏ꍇ
                                    scheduleKbnStart = BmaConstants.SCHEDULE_KBN_BS;
                                    scheduleKbnEnd = "";

                                    // ��L�[���X�P�W���[���f�[�^�擾
                                    scheduleBase  = scheduleUpd.lockNoWait(nendo, sknKsuCode, shubetsuCode, kaisuCode, schedule.getScheduleCode(), scheduleKbnStart);

                                    if (scheduleBase != null) {
                                        // �擾�ł�����X�V������
                                        BeanUtils.copyProperties(scheduleUpd, scheduleBase);
                                        setScheduleUpdate(scheduleUpd, schedule, inRequest);
                                        scheduleUpd.update();
                                    } else {
                                        /* Update����f�[�^���擾�ł��Ȃ������ꍇ�u�X�P�W���[���ύX�m�F�v���Reload */
                                        BmaValidator.addMessage(errors, "scheduleData", BmaText.E00120, schedule.getScheduleName());
                                        inSession.setErrors(errors);
                                        return FWD_NM_RELOAD;
                                    }
                                } else if (   BmaConstants.SCHED_CODE_CANT_UPD1.equals(schedule.getScheduleCode())
                                           || BmaConstants.SCHED_CODE_CANT_UPD2.equals(schedule.getScheduleCode())) {
                                    // �C���s���Ԃ������͂ɂȂ����ꍇ �� �����f�[�^���폜
                                    // ��L�[���X�P�W���[���f�[�^�擾
                                    scheduleStart  = scheduleUpd.lockNoWait(nendo, sknKsuCode, shubetsuCode, kaisuCode, schedule.getScheduleCode(), BmaConstants.SCHEDULE_KBN_ST);
                                    // �J�n�������݂���΁A�폜������
                                    if (scheduleStart != null) {
                                        // �J�n���폜
                                        Schedule scheduleRemove = new Schedule(DATA_SOURCE_NAME);
                                        scheduleRemove.setNendo(nendo);
                                        scheduleRemove.setSknKsuCode(sknKsuCode);
                                        scheduleRemove.setShubetsuCode(shubetsuCode);
                                        scheduleRemove.setKaisuCode(kaisuCode);
                                        scheduleRemove.setScheduleCode(schedule.getScheduleCode());
                                        scheduleRemove.setScheduleKbn(BmaConstants.SCHEDULE_KBN_ST);
                                        scheduleRemove.remove();
                                        // �I�����폜
                                        scheduleRemove = new Schedule(DATA_SOURCE_NAME);
                                        scheduleRemove.setNendo(nendo);
                                        scheduleRemove.setSknKsuCode(sknKsuCode);
                                        scheduleRemove.setShubetsuCode(shubetsuCode);
                                        scheduleRemove.setKaisuCode(kaisuCode);
                                        scheduleRemove.setScheduleCode(schedule.getScheduleCode());
                                        scheduleRemove.setScheduleKbn(BmaConstants.SCHEDULE_KBN_ED);
                                        scheduleRemove.remove();
                                    }
                                }
                            }
                        } else {
                            // �N�x�s��v �� �N�x�ύX���܂߂��X�V�����@�Ō�ɓ����݂̂̃f�[�^���N�x���X�V����
                            /* ���̓��X�g����N�x���܂߂čX�V */
                            for (MstKanriScheduleJoho schedule : inSession.getScheduleInputList()) {
                                // �X�P�W���[���敪����
                                if (   !BmaUtility.isNullOrEmpty(schedule.getStartYear())
                                    && !BmaUtility.isNullOrEmpty(schedule.getEndYear())) {
                                    // �J�n���E�I����������ꍇ
                                    scheduleKbnStart = BmaConstants.SCHEDULE_KBN_ST;
                                    scheduleKbnEnd = BmaConstants.SCHEDULE_KBN_ED;

                                    // ��L�[���X�P�W���[���f�[�^�擾
                                    scheduleStart  = scheduleUpd.lockNoWait(nendo, sknKsuCode, shubetsuCode, kaisuCode, schedule.getScheduleCode(), scheduleKbnStart);
                                    scheduleEnd  = scheduleUpd.lockNoWait(nendo, sknKsuCode, shubetsuCode, kaisuCode, schedule.getScheduleCode(), scheduleKbnEnd);

                                    if (   scheduleStart == null
                                        && scheduleEnd == null) {
                                        /* �J�n���E�I�����Ƃ��Ɋ����f�[�^�����݂��Ȃ���΍X�V������ */
                                        scheduleStart  = scheduleUpd.lockNoWait(nendoNowIn, sknKsuCode, shubetsuCode, kaisuCode, schedule.getScheduleCode(), scheduleKbnStart);
                                        scheduleEnd  = scheduleUpd.lockNoWait(nendoNowIn, sknKsuCode, shubetsuCode, kaisuCode, schedule.getScheduleCode(), scheduleKbnEnd);

                                        if (   scheduleStart != null
                                            && scheduleEnd != null) {
                                            // �O�N�x�̃f�[�^�����ƂɍX�V����
                                            // �J�n��
                                            BeanUtils.copyProperties(scheduleUpd, scheduleStart);
                                            setScheduleUpdate(scheduleUpd, schedule, inRequest);
                                            scheduleUpd.setNendo(inSession.getNendo());
                                            scheduleUpd.updateWithNendo(scheduleUpd, nendoNowIn);
                                            // �I����
                                            BeanUtils.copyProperties(scheduleUpd, scheduleEnd);
                                            setScheduleUpdate(scheduleUpd, schedule, inRequest);
                                            scheduleUpd.setNendo(inSession.getNendo());
                                            scheduleUpd.updateWithNendo(scheduleUpd, nendoNowIn);
                                        } else if (   BmaConstants.SCHED_CODE_CANT_UPD1.equals(schedule.getScheduleCode())
                                                   || BmaConstants.SCHED_CODE_CANT_UPD2.equals(schedule.getScheduleCode())) {
                                            // �C���s���Ԃ��V�N�x�ŐV�K���͂��ꂽ�ꍇ �� �V�K�o�^
                                            // �J�n��
                                            setScheduleInsert(scheduleUpd, schedule, inRequest, inSession, scheduleKbnStart);
                                            scheduleUpd.create();
                                            // �I����
                                            setScheduleInsert(scheduleUpd, schedule, inRequest, inSession, scheduleKbnEnd);
                                            scheduleUpd.create();
                                        } else {
                                            /* Update����O�N�x�f�[�^���擾�ł��Ȃ������ꍇ�u�X�P�W���[���ύX�m�F�v���Reload */
                                            BmaValidator.addMessage(errors, "scheduleData", BmaText.E00120, schedule.getScheduleName());
                                            inSession.setErrors(errors);
                                            return FWD_NM_RELOAD;
                                        }
                                    } else {
                                        /* ��L�[����v����f�[�^�����݂����ꍇ�u�X�P�W���[���ύX�m�F�v���Reload */
                                        BmaValidator.addMessage(errors, "scheduleData", BmaText.E00056, schedule.getScheduleName());
                                        inSession.setErrors(errors);
                                        return FWD_NM_RELOAD;
                                    }
                                } else if (   !BmaUtility.isNullOrEmpty(schedule.getStartYear())
                                           && BmaUtility.isNullOrEmpty(schedule.getEndYear())) {
                                    // ����̏ꍇ
                                    scheduleKbnStart = BmaConstants.SCHEDULE_KBN_BS;
                                    scheduleKbnEnd = "";
//
                                    // ��L�[���X�P�W���[���f�[�^�擾
                                    scheduleBase  = scheduleUpd.lockNoWait(nendo, sknKsuCode, shubetsuCode, kaisuCode, schedule.getScheduleCode(), scheduleKbnStart);

                                    if (scheduleBase == null) {
                                        // �����f�[�^�����݂��Ȃ���΍X�V������
                                        scheduleStart  = scheduleUpd.lockNoWait(nendoNowIn, sknKsuCode, shubetsuCode, kaisuCode, schedule.getScheduleCode(), scheduleKbnStart);
                                        BeanUtils.copyProperties(scheduleUpd, scheduleStart);
                                        setScheduleUpdate(scheduleUpd, schedule, inRequest);
                                        scheduleUpd.setNendo(inSession.getNendo());
                                        scheduleUpd.updateWithNendo(scheduleUpd, nendoNowIn);
                                    } else {
                                        /* ��L�[����v����f�[�^�����݂����ꍇ�u�X�P�W���[���ύX�m�F�v���Reload */
                                        BmaValidator.addMessage(errors, "scheduleData", BmaText.E00056, schedule.getScheduleName());
                                        inSession.setErrors(errors);
                                        return FWD_NM_RELOAD;
                                    }
                                } else if (   BmaConstants.SCHED_CODE_CANT_UPD1.equals(schedule.getScheduleCode())
                                           || BmaConstants.SCHED_CODE_CANT_UPD2.equals(schedule.getScheduleCode())) {
                                    // �C���s���Ԃ������͂ɂȂ����ꍇ �� �����f�[�^���폜
                                    // ��L�[���X�P�W���[���f�[�^�擾
                                    scheduleStart  = scheduleUpd.lockNoWait(nendoNowIn, sknKsuCode, shubetsuCode, kaisuCode, schedule.getScheduleCode(), BmaConstants.SCHEDULE_KBN_ST);
                                    // �J�n�������݂���΁A�폜������
                                    if (scheduleStart != null) {
                                        // �J�n���폜
                                        Schedule scheduleRemove = new Schedule(DATA_SOURCE_NAME);
                                        scheduleRemove.setNendo(nendoNowIn);
                                        scheduleRemove.setSknKsuCode(sknKsuCode);
                                        scheduleRemove.setShubetsuCode(shubetsuCode);
                                        scheduleRemove.setKaisuCode(kaisuCode);
                                        scheduleRemove.setScheduleCode(schedule.getScheduleCode());
                                        scheduleRemove.setScheduleKbn(BmaConstants.SCHEDULE_KBN_ST);
                                        scheduleRemove.remove();
                                        // �I�����폜
                                        scheduleRemove = new Schedule(DATA_SOURCE_NAME);
                                        scheduleRemove.setNendo(nendoNowIn);
                                        scheduleRemove.setSknKsuCode(sknKsuCode);
                                        scheduleRemove.setShubetsuCode(shubetsuCode);
                                        scheduleRemove.setKaisuCode(kaisuCode);
                                        scheduleRemove.setScheduleCode(schedule.getScheduleCode());
                                        scheduleRemove.setScheduleKbn(BmaConstants.SCHEDULE_KBN_ED);
                                        scheduleRemove.remove();
                                    }
                                }
                            }

                            /* �����݂̂̃f�[�^�̔N�x���X�V */
                            // �����݂̂����X�P�W���[���R�[�h�Z�b�g
                              List<String> nissuCodes  = scheduleUpd.nissuCodesForUpdate(nendoNowIn, sknKsuCode, shubetsuCode, kaisuCode, BmaConstants.SCHEDULE_KBN_BS);
                            for (int i=0; i < nissuCodes.size(); ++i) {
                                // �O�N�x�̃f�[�^����A�����݂̂����f�[�^���擾
                                Schedule schedNissuBfr = scheduleUpd.find(nendoNowIn, sknKsuCode, shubetsuCode, kaisuCode, nissuCodes.get(i), BmaConstants.SCHEDULE_KBN_BS);

                                // �_���폜����Ă��Ȃ���΍X�V
                                if (BmaConstants.FLG_OFF.equals(schedNissuBfr.getRonriSakujoFlg())) {
                                    BeanUtils.copyProperties(scheduleUpd, schedNissuBfr);
                                    // �X�V����l���Z�b�g
                                    SystemTime sysTime = new SystemTime();
                                    scheduleUpd.setNendo(inSession.getNendo());
                                    scheduleUpd.setKoshinKbn(BmaConstants.SHORI_KBN_UPDATE);
                                    scheduleUpd.setKoshinDate(sysTime.getymd1());
                                    scheduleUpd.setKoshinTime(sysTime.gethms1());
                                    scheduleUpd.setKoshinUserId(inRequest.getMoshikomishaId());
                                    scheduleUpd.updateNendoOnlyNissu(scheduleUpd, nendoNowIn);
                                }
                            }
                        }
                        /* �R�~�b�g */
                        commitTransaction();
                    } catch (Exception ex) {
                        ex.printStackTrace();
                        // ���[���o�b�N
                        rollbackTransaction();
                        return FWD_NM_SESSION;
                    }

                /* �u�X�P�W���[���ύX�����v��ʕ\�� */
                return FWD_NM_SUCCESS;
                }

        } else if (!BmaUtility.isNullOrEmpty(inRequest.getScheduleUpdConfBack())) {
                /*�u�����v�{�^��������*/
                processName = "MstKanriScheduleUpdateConfirm";
                log.Start(processName);

                /* �u�X�P�W���[���ύX���́v��ʕ\�� */
                return FWD_NM_BACK;
                
        } else {
                /*�ُ�J��*/
                log.IllegalFWD();
                return FWD_NM_SESSION;
            }
        } catch (Exception e) {
            return FWD_NM_EXCEPTION;
        } finally {
            log.End(processName);
        }
    }

    /**
     * �X�P�W���[�������X�V����
     *
     * @param scheduleUpd �X�V����X�P�W���[��
     * @param schedJoho �X�P�W���[�����͒l
     * @param inRequest ���N�G�X�g���
     */
    public void setScheduleUpdate(Schedule scheduleUpd, MstKanriScheduleJoho schedJoho, MstKanriScheduleJoho inRequest) {
        /* �V�X�e���������擾 */
        SystemTime sysTime = new SystemTime();

        /* �ύX���X�P�W���[���ɃZ�b�g */ 
        if (   BmaConstants.SCHEDULE_KBN_ST.equals(scheduleUpd.getScheduleKbn())
            || BmaConstants.SCHEDULE_KBN_BS.equals(scheduleUpd.getScheduleKbn())) {
            scheduleUpd.setDate(schedJoho.getStartDate());
            scheduleUpd.setTime(schedJoho.getStartTime());
        } else if (BmaConstants.SCHEDULE_KBN_ED.equals(scheduleUpd.getScheduleKbn())) {
            scheduleUpd.setDate(schedJoho.getEndDate());
            scheduleUpd.setTime(schedJoho.getEndTime());
        }

        /* DB���ʍ��ڃZ�b�g */
        scheduleUpd.setKoshinKbn(BmaConstants.SHORI_KBN_UPDATE);
        scheduleUpd.setKoshinDate(sysTime.getymd1());
        scheduleUpd.setKoshinTime(sysTime.gethms1());
        scheduleUpd.setKoshinUserId(inRequest.getMoshikomishaId());
    }

    /**
     * �X�P�W���[������V�K�o�^����
     *
     * @param scheduleUpd �o�^����X�P�W���[��
     * @param schedJoho �X�P�W���[�����͒l
     * @param inRequest ���N�G�X�g���
     * @param inSession �Z�b�V�������
     * @param scheduleKbn �X�P�W���[���敪
     */
    public void setScheduleInsert(Schedule scheduleUpd, MstKanriScheduleJoho schedJoho, MstKanriScheduleJoho inRequest, MstKanriScheduleJoho inSession, String scheduleKbn) {
        /* �ϐ������� */
        Schedule sched = new Schedule(DATA_SOURCE_NAME);
        String nissu = "";

        /* �V�X�e���������擾 */
        SystemTime sysTime = new SystemTime();

        /* ���͒l���X�P�W���[���ɃZ�b�g */ 
        // �����u�K��
        scheduleUpd.setNendo(inSession.getNendo());
        scheduleUpd.setSknKsuCode(inSession.getSknKsuCode());
        scheduleUpd.setShubetsuCode(inSession.getShubetsuCode());
        scheduleUpd.setKaisuCode(inSession.getKaisuCode());

        // �X�P�W���[��
        scheduleUpd.setScheduleCode(schedJoho.getScheduleCode());
        scheduleUpd.setScheduleKbn(scheduleKbn);
        if (   BmaConstants.SCHEDULE_KBN_ST.equals(scheduleKbn)
            || BmaConstants.SCHEDULE_KBN_BS.equals(scheduleKbn)) {
            scheduleUpd.setDate(schedJoho.getStartDate());
            scheduleUpd.setTime(schedJoho.getStartTime());
        } else if (BmaConstants.SCHEDULE_KBN_ED.equals(scheduleKbn)) {
            scheduleUpd.setDate(schedJoho.getEndDate());
            scheduleUpd.setTime(schedJoho.getEndTime());
        }
        nissu = sched.findNissu(inSession.getSknKsuCode(), inSession.getShubetsuCode(), inSession.getKaisuCode(), schedJoho.getScheduleCode(), scheduleKbn);
        if (nissu != null) {
            scheduleUpd.setNissu(nissu);
        } else {
            // �f�[�^���Ȃ��ꍇ�̓u�����N�o�^
            scheduleUpd.setNissu("");
        }

        /* DB���ʍ��ڃZ�b�g */
        scheduleUpd.setKoshinKbn(BmaConstants.SHORI_KBN_INSERT);
        scheduleUpd.setTorokuDate(sysTime.getymd1());
        scheduleUpd.setTorokuTime(sysTime.gethms1());
        scheduleUpd.setTorokuUserId(inRequest.getMoshikomishaId());
        scheduleUpd.setKoshinDate("");
        scheduleUpd.setKoshinTime("");
        scheduleUpd.setKoshinUserId("");
        scheduleUpd.setRonriSakujoFlg(BmaConstants.FLG_OFF);
    }

    /**
     * ���̓`�F�b�N�i�e�l�̃`�F�b�N�̂݁j
     *
     * @param inSession �Z�b�V����RTO
     * @return true:�G���[��
     */
    private boolean validateInput(MstKanriScheduleJoho inSession) {
        /* �ϐ������� */
        Messages errors = new Messages();
        String groupCode = "";
        String itemName = "";

        /* �G���[�`�F�b�N�p���X�g�쐬 */
        // �I�����̓��͂��s�v�ȃR�[�h�ꗗ
        String[] noEndDateCodes = {BmaConstants.SCHED_CODE_JUKENHYO_SEND, BmaConstants.SCHED_CODE_SKN_GAKKA, BmaConstants.SCHED_CODE_GOUHATSU, BmaConstants.SCHED_CODE_GOKAKU_SEND, BmaConstants.SCHED_CODE_NENREI_CALC, BmaConstants.SCHED_CODE_JITSUMU_CALC};

        /* �N�x */
        groupCode = "nendo";
        itemName = "�N�x";
        BmaValidator.validateRequired(inSession.getNendo(), errors, groupCode, itemName);
        BmaValidator.validateMaxLength(inSession.getNendo(), BmaConstants.EQUAL_LENGTH_SCHEDULE_NENDO, errors, groupCode, itemName);
        BmaValidator.validateNumber(inSession.getNendo(), errors, groupCode, itemName);

        for (MstKanriScheduleJoho schedule : inSession.getScheduleInputList()) {
            // �C���s���Ԃ͓��͂Ȃ��ł�OK
            if (   (BmaConstants.SCHED_CODE_CANT_UPD1.equals(schedule.getScheduleCode()) || BmaConstants.SCHED_CODE_CANT_UPD2.equals(schedule.getScheduleCode()))
                       && (BmaUtility.isNullOrEmpty(schedule.getStartDate()) && BmaUtility.isNullOrEmpty(schedule.getStartTime()))
                       && (BmaUtility.isNullOrEmpty(schedule.getEndDate()) && BmaUtility.isNullOrEmpty(schedule.getEndTime()))) {
                continue;
            // �C���y�N�y�V�K�z�ȊO�̍u�K��́A�u�K��i�C���ۑ�j�̃`�F�b�N�Ȃ�
            } else if (   !("IP".equals(inSession.getSknKsuCode()) && "11".equals(inSession.getShubetsuCode()))
                       && BmaConstants.SCHED_CODE_KSU_SHURYO.equals(schedule.getScheduleCode())) {
                continue;
            } else {
                /* �J�n���E��� */
                groupCode = "date" + schedule.getScheduleCode();
                /* ���t */
                // �N
                itemName = schedule.getScheduleName() + "�J�n���̔N";
                if (BmaValidator.validateRequired(schedule.getStartYear(), errors, groupCode, itemName)) {
                    if (BmaValidator.validateNumber(schedule.getStartYear(), errors, groupCode, itemName)) {
                        BmaValidator.validateMaxLength(schedule.getStartYear(), BmaConstants.EQUAL_LENGTH_SCHED_DATE_YEAR, errors, groupCode, itemName);
                    }
                }
                // ��
                itemName = schedule.getScheduleName() + "�J�n���̌�";
                if (BmaValidator.validateRequired(schedule.getStartMonth(), errors, groupCode, itemName)) {
                    if (BmaValidator.validateNumber(schedule.getStartMonth(), errors, groupCode, itemName)) {
                        BmaValidator.validateMaxLength(schedule.getStartMonth(), BmaConstants.EQUAL_LENGTH_SCHED_DATE_MONTH, errors, groupCode, itemName);
                    }
                }
                // ��
                itemName = schedule.getScheduleName() + "�J�n���̓�";
                if (BmaValidator.validateRequired(schedule.getStartDay(), errors, groupCode, itemName)) {
                    if (BmaValidator.validateNumber(schedule.getStartDay(), errors, groupCode, itemName)) {
                        BmaValidator.validateMaxLength(schedule.getStartDay(), BmaConstants.EQUAL_LENGTH_SCHED_DATE_DAY, errors, groupCode, itemName);
                    }
                }
                // ���t�̐�����
                if (errors.isEmpty()) {
                    itemName = schedule.getScheduleName() + "�J�n��";
                    BmaValidator.validateDate2(schedule.getStartDate(), errors, groupCode, itemName);
                }

                /* ���� */
                groupCode = "time" + schedule.getScheduleCode();
                // ��
                itemName = schedule.getScheduleName() + "�J�n�����̎�";
                if (BmaValidator.validateRequired(schedule.getStartHour(), errors, groupCode, itemName)) {
                    if (BmaValidator.validateNumber(schedule.getStartHour(), errors, groupCode, itemName)) {
                        BmaValidator.validateMaxLength(schedule.getStartHour(), BmaConstants.EQUAL_LENGTH_SCHED_TIME_HOUR, errors, groupCode, itemName);
                    }
                }
                // ��
                itemName = schedule.getScheduleName() + "�J�n�����̕�";
                if (BmaValidator.validateRequired(schedule.getStartMinute(), errors, groupCode, itemName)) {
                    if (BmaValidator.validateNumber(schedule.getStartMinute(), errors, groupCode, itemName)) {
                        BmaValidator.validateMaxLength(schedule.getStartMinute(), BmaConstants.EQUAL_LENGTH_SCHED_TIME_MINUTE, errors, groupCode, itemName);
                    }
                }
                // �����̐�����
                if (errors.isEmpty()) {
                    itemName = schedule.getScheduleName() + "�J�n����";
                    if (!checkTime(schedule.getStartTime())) {
                        BmaValidator.addMessage(errors, groupCode, BmaText.E00123, itemName);
                    }
                }

                /* �I���� */
                if (!Arrays.asList(noEndDateCodes).contains(schedule.getScheduleCode())) {
                    /* ���t */
                    // �N
                    itemName = schedule.getScheduleName() + "�I�����̔N";
                    if (BmaValidator.validateRequired(schedule.getEndYear(), errors, groupCode, itemName)) {
                        if (BmaValidator.validateNumber(schedule.getEndYear(), errors, groupCode, itemName)) {
                            BmaValidator.validateMaxLength(schedule.getEndYear(), BmaConstants.EQUAL_LENGTH_SCHED_DATE_YEAR, errors, groupCode, itemName);
                        }
                    }
                    // ��
                    itemName = schedule.getScheduleName() + "�I�����̌�";
                    if (BmaValidator.validateRequired(schedule.getEndMonth(), errors, groupCode, itemName)) {
                        if (BmaValidator.validateNumber(schedule.getEndMonth(), errors, groupCode, itemName)) {
                            BmaValidator.validateMaxLength(schedule.getEndMonth(), BmaConstants.EQUAL_LENGTH_SCHED_DATE_MONTH, errors, groupCode, itemName);
                        }
                    }
                    // ��
                    itemName = schedule.getScheduleName() + "�I�����̓�";
                    if (BmaValidator.validateRequired(schedule.getEndDay(), errors, groupCode, itemName)) {
                        if (BmaValidator.validateNumber(schedule.getEndDay(), errors, groupCode, itemName)) {
                            BmaValidator.validateMaxLength(schedule.getEndDay(), BmaConstants.EQUAL_LENGTH_SCHED_DATE_DAY, errors, groupCode, itemName);
                        }
                    }
                    // ���t�̐�����
                    if (errors.isEmpty()) {
                        itemName = schedule.getScheduleName() + "�I����";
                        BmaValidator.validateDate2(schedule.getEndDate(), errors, groupCode, itemName);
                    }

                    /* ���� */
                    groupCode = "time" + schedule.getScheduleCode();
                    // ��
                    itemName = schedule.getScheduleName() + "�I�������̎�";
                    if (BmaValidator.validateRequired(schedule.getEndHour(), errors, groupCode, itemName)) {
                        if (BmaValidator.validateNumber(schedule.getEndHour(), errors, groupCode, itemName)) {
                            BmaValidator.validateMaxLength(schedule.getEndHour(), BmaConstants.EQUAL_LENGTH_SCHED_TIME_HOUR, errors, groupCode, itemName);
                        }
                    }
                    // ��
                    itemName = schedule.getScheduleName() + "�I�������̕�";
                    if (BmaValidator.validateRequired(schedule.getEndMinute(), errors, groupCode, itemName)) {
                        if (BmaValidator.validateNumber(schedule.getEndMinute(), errors, groupCode, itemName)) {
                            BmaValidator.validateMaxLength(schedule.getEndMinute(), BmaConstants.EQUAL_LENGTH_SCHED_TIME_MINUTE, errors, groupCode, itemName);
                        }
                    }
                    // �����̐�����
                    if (errors.isEmpty()) {
                        itemName = schedule.getScheduleName() + "�I������";
                        if (!checkTime(schedule.getEndTime())) {
                            BmaValidator.addMessage(errors, groupCode, BmaText.E00123, itemName);
                        }
                    }
                }
            }
        }

        inSession.setErrors(errors);
        return errors.isEmpty();
    }

    /**
     * ���͎����̐������`�F�b�N
     *
     * @param value ����
     * @return true:�G���[�� false:�s���ȕ�����
     */
    private boolean checkTime(String value) {
        if (BmaUtility.isNullOrEmpty(value)) {
            return false;
        } else {
            Pattern p = Pattern.compile("^([0-1][0-9]|[2][0-3])[0-5][0-9][0-9][0-9]$");
            Matcher m = p.matcher(value);
            if (!m.find()) {
                return false;
            } else {
                return true;
            }
        }
    }
}