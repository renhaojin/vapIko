package jp.co.nii.bma.integration;

import java.util.ArrayList;
import java.util.List;
import jp.co.nii.bma.business.domain.Moshikomi;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import jp.co.nii.bma.business.domain.MoshikomiDao;
import jp.co.nii.bma.business.rto.manager.HanyouSearchJoho;
import jp.co.nii.bma.business.rto.manager.NumKanriJoho;
import jp.co.nii.bma.business.service.common.BmaConstants;
import jp.co.nii.sew.common.LogGenerate;
import static jp.co.nii.sew.integration.AbstractDao.getSchemaName;
import jp.co.nii.sew.integration.SQLStateSQLExceptionTranslater;

/**
 * �\�� DAO�����N���X
 *
 * @author DB�Ǘ��c�[��
 */
public class MoshikomiDaoImpl extends GeneratedMoshikomiDaoImpl implements MoshikomiDao {

    /**
     * �C���X�^���X�𐶐�����B
     *
     * @param datasource �f�[�^�\�[�X��
     */
    public MoshikomiDaoImpl(String datasource) {
        super(datasource);
    }

    /**
     * �O���[�v�R�[�h,�ėp�R�[�h����ėp�����擾����
     *
     * @return
     */
    @Override
    public List<String> searchShomenUketsukeNo() {

        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql;
        ArrayList<String> paramList = new ArrayList<String>();
        List<String> list = new ArrayList<>();
        try {
            con = getConnection();
            sql = "SELECT SHOMEN_UKETSUKE_NO"
                    + " FROM " + getSchemaName() + "." + TABLE_NAME;

            stmt = con.prepareStatement(sql);

            int i = 1;
            for (String param : paramList) {
                stmt.setString(i++, param);
            }
            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();

            while (rs.next()) {
                list.add(rs.getString("SHOMEN_UKETSUKE_NO"));
            }

        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return list;
    }

    /**
     * �\�������擾����B
     *
     * @param bo
     * @return
     */
    @Override
    public Moshikomi searchMoshikomiJoho(Moshikomi bo) {
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql;
        try {
            con = getConnection();
            sql = "SELECT " + FIELDS_DECRYPT
                    + " FROM " + getSchemaName() + "." + TABLE_NAME
                    + " WHERE"
                    + " SHOMEN_UKETSUKE_NO = ?";
            stmt = con.prepareStatement(sql);
            int i = 1;
            stmt.setString(i++, bo.getShomenUketsukeNo());

            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();
            if (rs.next()) {
                setBoFromResultSet(bo, rs);
            } else {
                bo = null;
            }

        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return bo;
    }

    @Override
    public ArrayList<Moshikomi> findTmpJohoList(NumKanriJoho inSession) {
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = "";
        ArrayList<Moshikomi> list = new ArrayList<>();
        try {
            con = getConnection();
            sql = "SELECT A.SKN_KSU_CODE "
                    + " ,A.SHUBETSU_CODE "
                    + " ,A.KAISU_CODE "
                    + " ,A.NENDO "
                    + " ,A.UKETSUKE_NO "
                    + " ," + getSQLForDecryptJoinByUTF8("B", "SHIMEI")
                    + " ,A.JUKEN_JUKO_NO "
                    + " FROM " + getSchemaName() + "." + TABLE_NAME + " A "
                    + " INNER JOIN  " + getSchemaName() + ".TOROKUSHA B ON "
                    + "     B.MOSHIKOMISHA_ID = A.MOSHIKOMISHA_ID "
                    + " WHERE "
                    + "     A.SKN_KSU_CODE = ? "
                    + " AND A.SHUBETSU_CODE = ? "
                    + " AND A.KAISU_CODE = ? "
                    + " AND A.NENDO = ? "
                    + " AND A.MOSHIKOMI_JOKYO_KBN = ? "
                    + " AND A.RONRI_SAKUJO_FLG = ? "
                    + " ORDER BY "
                    + " A.NENDO "
                    + ",A.SKN_KSU_CODE "
                    + ",A.SHUBETSU_CODE "
                    + ",A.KAISU_CODE ";

            stmt = con.prepareStatement(sql);
            int i = 1;
            stmt.setString(i++, inSession.getSknKsuCode());
            stmt.setString(i++, inSession.getShubetsuCode());
            stmt.setString(i++, inSession.getKaisuCode());
            stmt.setString(i++, inSession.getNendo());
            stmt.setString(i++, "03");
            stmt.setString(i++, BmaConstants.FLG_OFF);

            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();
            while (rs.next()) {
                Moshikomi bo = new Moshikomi();
                bo.setSknKsuCode(rs.getString("SKN_KSU_CODE"));
                bo.setShubetsuCode(rs.getString("SHUBETSU_CODE"));
                bo.setKaisuCode(rs.getString("KAISU_CODE"));
                bo.setNendo(rs.getString("NENDO"));
                bo.setUketsukeNo(rs.getString("UKETSUKE_NO"));
                bo.setShimei(rs.getString("SHIMEI"));
                bo.setJukenJukoNo(rs.getString("JUKEN_JUKO_NO"));
                list.add(bo);
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return list;
    }

    @Override
    public Moshikomi findShikakuMenjo(String nendo, String jukenJukoNo) {
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = "";
        Moshikomi bo = new Moshikomi();
        try {
            con = getConnection();
            sql = "SELECT A.NENDO "
                    + " ,A.JUKEN_JUKO_NO "
                    + " ,A.MOSHIKOMISHA_ID "
                    + " ,A.SKN_KSU_CODE "
                    + " ,A.SHUBETSU_CODE "
                    + " ,A.KAISU_CODE "
                    + " ," + getSQLForDecryptJoinByUTF8("B", "FURIGANA")
                    + " ," + getSQLForDecryptJoinByUTF8("B", "BIRTHDAY")
                    + " FROM " + getSchemaName() + "." + TABLE_NAME + " A "
                    + " INNER JOIN  " + getSchemaName() + ".TOROKUSHA B ON "
                    + "     B.MOSHIKOMISHA_ID = A.MOSHIKOMISHA_ID "
                    + " WHERE "
                    + "     A.NENDO = ? "
                    + " AND A.JUKEN_JUKO_NO = ? ";

            stmt = con.prepareStatement(sql);
            int i = 1;
            stmt.setString(i++, nendo);
            stmt.setString(i++, jukenJukoNo);
            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();
            if (rs.next()) {
                bo.setNendo(rs.getString("NENDO"));
                bo.setJukenJukoNo(rs.getString("JUKEN_JUKO_NO"));
                bo.setMoshikomishaId(rs.getString("MOSHIKOMISHA_ID"));
                bo.setSknKsuCode(rs.getString("SKN_KSU_CODE"));
                bo.setShubetsuCode(rs.getString("SHUBETSU_CODE"));
                bo.setKaisuCode(rs.getString("KAISU_CODE"));
                bo.setFurigana(rs.getString("FURIGANA"));
                bo.setBirthday(rs.getString("BIRTHDAY"));
            } else {
                bo = null;
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return bo;
    }

    @Override
    public Moshikomi findByJukenJukoNo(String sknKsuCode, String shubetsuCode, String kaisuCode, String nendo, String jukenJukoNo) {
        Moshikomi bo = new Moshikomi();

        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = "";
        try {
            con = getConnection();
            sql = "SELECT " + FIELDS_DECRYPT
                    + " FROM " + getSchemaName() + "." + TABLE_NAME
                    + " WHERE"
                    + " RONRI_SAKUJO_FLG = ?"
                    + " AND SKN_KSU_CODE = ?"
                    + " AND SHUBETSU_CODE = ?"
                    + " AND KAISU_CODE = ?"
                    + " AND NENDO = ?"
                    + " AND JUKEN_JUKO_NO = ?";

            stmt = con.prepareStatement(sql);
            int i = 1;
            stmt.setString(i++, BmaConstants.FLG_OFF);
            stmt.setString(i++, sknKsuCode);
            stmt.setString(i++, shubetsuCode);
            stmt.setString(i++, kaisuCode);
            stmt.setString(i++, nendo);
            stmt.setString(i++, jukenJukoNo);

            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();
            if (rs.next()) {
                setBoFromResultSet(bo, rs);
            } else {
                bo = null;
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return bo;
    }

    @Override
    public List<HanyouSearchJoho> findGroupByMoshkomiId(HanyouSearchJoho inSession) {
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = "";
        ArrayList<HanyouSearchJoho> list = new ArrayList<>();
        try {
            con = getConnection();
            sql = "SELECT mc.KAISU_CODE AS KAISU_CODE"
                    + "  , mc.NENDO AS NENDO "
                    + " , mc.SKN_KSU_CODE AS SKN_KSU_CODE "
                    + " , mc.SHUBETSU_CODE AS SHUBETSU_CODE"
                    + " , sknksu.SKN_KSU_NAME AS SKN_KSU_NAME  "
                    + " , sknksu.SKN_KSU_KBN AS SKN_KSU_KBN  "
                    + " , mc.JUKEN_JUKO_NO AS JUKEN_JUKO_NO "
                    + " , mc.UKETSUKE_NO AS UKETSUKE_NO "
                    + " , mc.UNYO_JOKYO_KBN AS UNYO_JOKYO_KBN "
                    + " , mc.GOHI_JOKYO_KBN AS GOHI_JOKYO_KBN "
                    + " FROM " + getSchemaName() + "." + TABLE_NAME + " mc "
                    + " INNER JOIN  " + getSchemaName() + ".SKNKSU_MST sknksu ON "
                    + "   sknksu.skn_ksu_code = mc.skn_ksu_code "
                    + " AND  sknksu.shubetsu_code = mc.shubetsu_code "
                    + " AND  sknksu.kaisu_code = mc.kaisu_code  "
                    + " WHERE"
                    + " mc.RONRI_SAKUJO_FLG = ?"
                    + " And mc.MOSHIKOMISHA_ID = ?"
                    + " ORDER BY  "
                    + "  NENDO DESC,SKN_KSU_CODE, SHUBETSU_CODE ";

            stmt = con.prepareStatement(sql);
            int i = 1;
            stmt.setString(i++, BmaConstants.FLG_OFF);
            stmt.setString(i++, inSession.getMoshikomishaId());

            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();
            while (rs.next()) {
                HanyouSearchJoho bo = new HanyouSearchJoho();

                bo.setSknKsuCode(rs.getString("SKN_KSU_CODE"));
                bo.setShubetsuCode(rs.getString("SHUBETSU_CODE"));
                bo.setKaisuCode(rs.getString("KAISU_CODE"));
                bo.setSknKsuKbn(rs.getString("SKN_KSU_KBN"));
                bo.setNendo(rs.getString("NENDO"));
                bo.setSknName(rs.getString("SKN_KSU_NAME"));
                bo.setUketsukeNo(rs.getString("UKETSUKE_NO"));
                bo.setJukenJukoNo(rs.getString("JUKEN_JUKO_NO"));
                bo.setUnyoJokyoKbn(rs.getString("UNYO_JOKYO_KBN"));
                bo.setGohiJokyoKbnMoshi(rs.getString("GOHI_JOKYO_KBN"));

                bo.setUnyouList(inSession.getUnyouList());
                bo.setGohiJokyoKbnList(inSession.getGohiJokyoKbnList());
                list.add(bo);
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return list;

    }

    /**
     * �\�������擾����B
     *
     * @param bo
     * @return �\�����
     */
    @Override
    public Moshikomi findRonriFlg(Moshikomi bo) {
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = "";
        try {
            con = getConnection();
            sql = "SELECT " + FIELDS_DECRYPT
                    + " FROM " + getSchemaName() + "." + TABLE_NAME
                    + " WHERE"
                    + " NENDO = ?"
                    + " AND UKETSUKE_NO = ?"
                    + " AND RONRI_SAKUJO_FLG = '0'";

            stmt = con.prepareStatement(sql);
            int i = 1;
            stmt.setString(i++, bo.getNendo());
            stmt.setString(i++, bo.getUketsukeNo());

            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();
            if (rs.next()) {
                setBoFromResultSet(bo, rs);
            } else {
                bo = null;
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return bo;
    }
}
