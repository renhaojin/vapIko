package jp.co.nii.bma.business.rto.manager;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import jp.co.nii.bma.business.domain.Moshikomi;
import jp.co.nii.sew.presentation.DownloadRTO;
import jp.co.nii.sew.presentation.Messages;
import jp.co.nii.sew.presentation.Option;

/**
 *
 * @author nii07779
 */
public class FileDownLoad extends DownloadRTO {
    
    /**
     * �t�@�C����
     */
    String fileName;
    /**
     * �e���v���[�g�t�@�C����
     */
    String templateFileName;

    ////////////////////////////////////////////
    //�����i�[����t�B�[���h�E���\�b�h
    ///////////////////////////////////////////
    
    private String sknksuKbn; 
    private String sknName; 
    private String ksuName; 
    private String jknJkuNoFileChoice; 
    private String jknJkuNoTmpDl; 
    private String jknJkuNoUl; 
    private List<Option> sknKbnList;
    private List<Option> ksuKbnList;
    private String sknKsuCode;
    private String shubetsuCode;
    private String kaisuCode;
    private String nendo;
    private ArrayList<Moshikomi> resultDetailList;
    private String sknKsuNameChi;  
    private String gokakuNoTmpDl; 
    private String gokakuNoUl;

    /**
     * �R���X�g���N�^
     */
    public FileDownLoad() {
        // ���ڂ̏���������
        this.clearInfo();
    }
    
    /**
     * @return the sknksuKbn
     */
    public String getSknksuKbn() {
        return sknksuKbn;
    }

    /**
     * @param sknksuKbn the sknksuKbn to set
     */
    public void setSknksuKbn(String sknksuKbn) {
        this.sknksuKbn = sknksuKbn;
    }

    /**
     * @return the sknName
     */
    public String getSknName() {
        return sknName;
    }

    /**
     * @param sknName the sknName to set
     */
    public void setSknName(String sknName) {
        this.sknName = sknName;
    }

    /**
     * @return the ksuName
     */
    public String getKsuName() {
        return ksuName;
    }

    /**
     * @param ksuName the ksuName to set
     */
    public void setKsuName(String ksuName) {
        this.ksuName = ksuName;
    }

    /**
     * @return the jknJkuNoFileChoice
     */
    public String getJknJkuNoFileChoice() {
        return jknJkuNoFileChoice;
    }

    /**
     * @param jknJkuNoFileChoice the jknJkuNoFileChoice to set
     */
    public void setJknJkuNoFileChoice(String jknJkuNoFileChoice) {
        this.jknJkuNoFileChoice = jknJkuNoFileChoice;
    }

    /**
     * @return the jknJkuNoTmpDl
     */
    public String getJknJkuNoTmpDl() {
        return jknJkuNoTmpDl;
    }

    /**
     * @param jknJkuNoTmpDl the jknJkuNoTmpDl to set
     */
    public void setJknJkuNoTmpDl(String jknJkuNoTmpDl) {
        this.jknJkuNoTmpDl = jknJkuNoTmpDl;
    }

    /**
     * @return the jknJkuNoUl
     */
    public String getJknJkuNoUl() {
        return jknJkuNoUl;
    }

    /**
     * @param jknJkuNoUl the jknJkuNoUl to set
     */
    public void setJknJkuNoUl(String jknJkuNoUl) {
        this.jknJkuNoUl = jknJkuNoUl;
    }

    /**
     * @return the sknKbnList
     */
    public List<Option> getSknKbnList() {
        return sknKbnList;
    }

    /**
     * @param sknKbnList the sknKbnList to set
     */
    public void setSknKbnList(List<Option> sknKbnList) {
        this.sknKbnList = sknKbnList;
    }

    /**
     * @return the ksuKbnList
     */
    public List<Option> getKsuKbnList() {
        return ksuKbnList;
    }

    /**
     * @param ksuKbnList the ksuKbnList to set
     */
    public void setKsuKbnList(List<Option> ksuKbnList) {
        this.ksuKbnList = ksuKbnList;
    }

    /**
     * @return the sknKsuCode
     */
    public String getSknKsuCode() {
        return sknKsuCode;
    }

    /**
     * @param sknKsuCode the sknKsuCode to set
     */
    public void setSknKsuCode(String sknKsuCode) {
        this.sknKsuCode = sknKsuCode;
    }

    /**
     * @return the shubetsuCode
     */
    public String getShubetsuCode() {
        return shubetsuCode;
    }

    /**
     * @param shubetsuCode the shubetsuCode to set
     */
    public void setShubetsuCode(String shubetsuCode) {
        this.shubetsuCode = shubetsuCode;
    }

    /**
     * @return the kaisuCode
     */
    public String getKaisuCode() {
        return kaisuCode;
    }

    /**
     * @param kaisuCode the kaisuCode to set
     */
    public void setKaisuCode(String kaisuCode) {
        this.kaisuCode = kaisuCode;
    }

    /**
     * @return the nendo
     */
    public String getNendo() {
        return nendo;
    }

    /**
     * @param nendo the nendo to set
     */
    public void setNendo(String nendo) {
        this.nendo = nendo;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getTemplateFileName() {
        return templateFileName;
    }

    public void setTemplateFileName(String templateFileName) {
        this.templateFileName = templateFileName;
    }

    /**
     * @return the resultDetailList
     */
    public ArrayList<Moshikomi> getResultDetailList() {
        return resultDetailList;
    }

    /**
     * @param resultDetailList the resultDetailList to set
     */
    public void setResultDetailList(ArrayList<Moshikomi> resultDetailList) {
        this.resultDetailList = resultDetailList;
    }
    
    /**
     * @return the sknKsuNameChi
     */
    public String getSknKsuNameChi() {
        return sknKsuNameChi;
    }

    /**
     * @param sknKsuNameChi the sknKsuNameChi to set
     */
    public void setSknKsuNameChi(String sknKsuNameChi) {
        this.sknKsuNameChi = sknKsuNameChi;
    }
    
    /**
     * �������J���}��؂�ɂ��ĕԂ�
     * @param kensu
     * @return 
     */
    public String getKanmaSuchi(String kensu) {
        if (kensu.isEmpty()) {
            kensu = "0";
        }
        NumberFormat nfNum = NumberFormat.getNumberInstance();
        String ret = nfNum.format(Integer.parseInt(kensu));
        return ret;
    }
    
    /**
     * �������J���}��؂�ɂ��ĕԂ�
     * @param kensu
     * @return 
     */
    public String getKanmaSuchi(int kensu) {
        NumberFormat nfNum = NumberFormat.getNumberInstance();
        String ret = nfNum.format(kensu);
        return ret;
    }
    
    /**
     * @return the gokakuNoTmpDl
     */
    public String getGokakuNoTmpDl() {
        return gokakuNoTmpDl;
    }

    /**
     * @param gokakuNoTmpDl the gokakuNoTmpDl to set
     */
    public void setGokakuNoTmpDl(String gokakuNoTmpDl) {
        this.gokakuNoTmpDl = gokakuNoTmpDl;
    }

    /**
     * @return the gokakuNoUl
     */
    public String getGokakuNoUl() {
        return gokakuNoUl;
    }

    /**
     * @param gokakuNoUl the gokakuNoUl to set
     */
    public void setGokakuNoUl(String gokakuNoUl) {
        this.gokakuNoUl = gokakuNoUl;
    }

    ////////////////////////////////////////////
    //�l���`���\�b�h
    ///////////////////////////////////////////
    /**
     * �e�l�̃X�y�[�X���폜����
     */
    public void deleteSpace() {
//        this.userId = StringUtility.removeSpace(this.userId);
//        this.inpPasswd = StringUtility.removeEdgeSpace(this.inpPasswd);
    }

    ////////////////////////////////////////////
    //�G���[�ӏ��\���p
    ///////////////////////////////////////////
    /**
     * �G���[
     */
    private Messages errors;

    /**
     * @return the errors
     */
    public Messages getErrors() {
        return errors;
    }

    /**
     * @param errors the errors to set
     */
    public void setErrors(Messages errors) {
        this.errors = errors;
    }

    @Override
    public void copyFromRequest(HttpServletRequest request) {
        
        HttpSession session = request.getSession(false);
        if (session != null) {
            NumKanriJoho numKanriJoho = (NumKanriJoho) session.getAttribute("NumKanriJoho");
            if (numKanriJoho != null) {
                setJknJkuNoTmpDl(numKanriJoho.getJknJkuNoTmpDl());
                setSknKsuNameChi(numKanriJoho.getSknKsuNameChi());
                setResultDetailList(numKanriJoho.getResultDetailList());
                setGokakuNoTmpDl(numKanriJoho.getGokakuNoTmpDl());
            }
        }
    }
    
    /**
     * �S�t�B�[���h�̏���������
     *
     */
    public final void clearInfo() {
        //�����i�[����t�B�[���h�E���\�b�h
        this.sknksuKbn = "";
        this.sknName = "";
        this.ksuName = "";
        this.jknJkuNoFileChoice = "";
        this.jknJkuNoUl = "";
        this.sknKsuCode = "";
        this.shubetsuCode = "";
        this.kaisuCode = "";
        this.nendo= "";
        this.sknKsuNameChi = "";
        this.gokakuNoUl = "";

        //�G���[�ӏ��\���p
        this.errors = new Messages();
        
        this.jknJkuNoTmpDl = "";
        this.gokakuNoTmpDl = "";
    }

}
