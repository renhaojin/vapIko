package jp.co.nii.bma.integration;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import jp.co.nii.bma.business.domain.ShiyoKaijo;
import jp.co.nii.bma.business.domain.ShiyoKaijoDao;
import jp.co.nii.bma.business.domain.MeishoKanriDao;
import jp.co.nii.bma.business.rto.manager.HanyouKaisaiTiJoho;
import jp.co.nii.bma.business.rto.manager.HanyouSearchJoho;
import jp.co.nii.bma.business.rto.manager.SmnMskJoho;
import jp.co.nii.sew.common.LogGenerate;
import jp.co.nii.sew.integration.SQLStateSQLExceptionTranslater;
import jp.co.nii.bma.business.rto.manager.MstKanriShiyoKaijoJoho;
import jp.co.nii.bma.business.service.common.BmaConstants;
import static jp.co.nii.sew.integration.AbstractDao.getSchemaName;
import jp.co.nii.sew.presentation.Option;

/**
 * �g�p��� DAO�����N���X
 *
 * @author DB�Ǘ��c�[��
 */
public class ShiyoKaijoDaoImpl extends GeneratedShiyoKaijoDaoImpl implements ShiyoKaijoDao {

    /**
     * �C���X�^���X�𐶐�����B
     *
     * @param datasource �f�[�^�\�[�X��
     */
    public ShiyoKaijoDaoImpl(String datasource) {
        super(datasource);
    }

    /**
     * �����u�K��̏����擾����B
     *
     * @param bo
     * @return ���I����񃊃X�g
     */
    @Override
    public List<SmnMskJoho> searchKaijoList(ShiyoKaijo bo) {
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = "";
        List<String> param = new ArrayList<>();
        List<SmnMskJoho> kaijoList = new ArrayList<>();
        try {
            con = getConnection();
            sql = "SELECT K1.KAISAICHI_CODE,M1.HANYO_CHI AS KAISAICHI,K1.NITTEI_FROM,K1.NITTEI_TO,"
                    + " K1.KAIJO_ID,K1.KAIJO_CODE,K1.KAIJO_NAME_RYAKU AS KAIJO_NAME,K1.JUSHO,"
                    + " TO_NUMBER(K1.TEIIN,'9999999999')-TO_NUMBER(K1.GENZAI_NINZU,'9999999999') AS KUSEKI"
                    + " FROM BMA.SHIYO_KAIJO AS K1"
                    + " LEFT JOIN BMA.MEISHO_KANRI AS M1"
                    + " ON K1.KAISAICHI_CODE = M1.HANYO_CODE"
                    + " AND M1.GROUP_CODE = 'KAISAICHI_CODE'"
                    + " WHERE K1.NENDO = ?"
                    + " AND K1.SKN_KSU_CODE = ?"
                    + " AND K1.SHUBETSU_CODE = ?"
                    + " AND K1.KAISU_CODE = ?"
                    + " AND K1.KAIJO_SHIKEN_KBN = ?"
                    + " AND K1.RONRI_SAKUJO_FLG = '0'"
                    + " ORDER BY K1.KAISAICHI_CODE ASC, K1.NITTEI_FROM ASC";
            param.add(bo.getNendo());
            param.add(bo.getSknKsuCode());
            param.add(bo.getShubetsuCode());
            param.add(bo.getKaisuCode());
            param.add(bo.getKaijoShikenKbn());

            stmt = con.prepareStatement(sql);
            int i = 1;
            for (String pm : param) {
                stmt.setString(i++, pm);
            }

            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();
            while (rs.next()) {
                SmnMskJoho smnMskJoho = new SmnMskJoho();
                smnMskJoho.setKaisaichiCode(rs.getString("KAISAICHI_CODE"));
                smnMskJoho.setKaijoId(rs.getString("KAIJO_ID"));
                smnMskJoho.setKaisaichi(rs.getString("KAISAICHI"));
                smnMskJoho.setDate_From(rs.getString("NITTEI_FROM"));
                smnMskJoho.setDate_To(rs.getString("NITTEI_TO"));
                smnMskJoho.setKaijoCode(rs.getString("KAIJO_CODE"));
                smnMskJoho.setKaijoName(rs.getString("KAIJO_NAME"));
                smnMskJoho.setKaijoJusho(rs.getString("JUSHO"));
                smnMskJoho.setKuusekiSuu(rs.getString("KUSEKI"));
                kaijoList.add(smnMskJoho);
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return kaijoList;
    }

    @Override
    public ShiyoKaijo findKaijo(ShiyoKaijo bo) {
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = "";
        try {
            con = getConnection();
            sql = "SELECT " + FIELDS_DECRYPT
                    + " FROM " + getSchemaName() + "." + TABLE_NAME
                    + " WHERE"
                    + " NENDO = ?"
                    + " AND SKN_KSU_CODE = ?"
                    + " AND SHUBETSU_CODE = ?"
                    + " AND KAISU_CODE = ?"
                    + " AND KAIJO_ID = ?"
                    + " AND KAIJO_SHIKEN_KBN = ?";

            stmt = con.prepareStatement(sql);
            int i = 1;
            stmt.setString(i++, bo.getNendo());
            stmt.setString(i++, bo.getSknKsuCode());
            stmt.setString(i++, bo.getShubetsuCode());
            stmt.setString(i++, bo.getKaisuCode());
            stmt.setString(i++, bo.getKaijoId());
            stmt.setString(i++, bo.getKaijoShikenKbn());

            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();
            if (rs.next()) {
                setBoFromResultSet(bo, rs);
            } else {
                bo = null;
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return bo;
    }

    @Override
    public List<ShiyoKaijo> findByKaisaichi(String sknKsuCode, String shubetsuCode, String kaisuCode, String[] kaisaichiCodes) {

        /**
         * �����J�Òn��������擾����B
         *
         * @param kaisaichiCodes �J�Òn�R�[�h
         */
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = "";
        List<String> param = new ArrayList<>();
        List<ShiyoKaijo> kaijoByKaisaichiList = new ArrayList<>();

        try {
            con = getConnection();
            sql = "SELECT "
                    + "shiyoKaijo.NENDO AS NENDO"
                    + ", " + "shiyoKaijo.SKN_KSU_CODE AS SKN_KSU_CODE"
                    + ", " + "shiyoKaijo.SHUBETSU_CODE AS SHUBETSU_CODE"
                    + ", " + "shiyoKaijo.KAISU_CODE AS KAISU_CODE"
                    + ", " + "shiyoKaijo.KAIJO_ID AS KAIJO_ID"
                    + ", " + "shiyoKaijo.KAISAICHI_CODE AS KAISAICHI_CODE"
                    + ", " + "shiyoKaijo.KAIJO_CODE AS KAIJO_CODE"
                    + ", " + "shiyoKaijo.KAIJO_NAME AS KAIJO_NAME"
                    + ", " + "shiyoKaijo.KAIJO_NAME_RYAKU AS KAIJO_NAME_RYAKU"
                    + ", " + "shiyoKaijo.KAIJO_SHIKEN_KBN AS KAIJO_SHIKEN_KBN"
                    + ", " + "shiyoKaijo.NITTEI_FROM AS NITTEI_FROM"
                    + ", " + "shiyoKaijo.NITTEI_TO AS NITTEI_TO"
                    + ", " + "shiyoKaijo.TEIIN AS TEIIN"
                    + ", " + "shiyoKaijo.GENZAI_NINZU AS GENZAI_NINZU"
                    + " FROM " + getSchemaName() + "." + ShiyoKaijoDao.TABLE_NAME + " AS shiyoKaijo"
                    + " WHERE SKN_KSU_CODE = ?"
                    + " AND SHUBETSU_CODE = ?"
                    + " AND KAISU_CODE = ?"
                    + " AND shiyoKaijo.KAISAICHI_CODE IN ( ";

            for (int i = 0; i < kaisaichiCodes.length; i++) {
                if (i > 0) {
                    sql += ", ";
                }
                sql += "?";
            }
            sql += " )";
            sql += " AND " + "shiyoKaijo.RONRI_SAKUJO_FLG = '0'"
                    + " ORDER BY shiyoKaijo.KAIJO_ID ASC ,shiyoKaijo.KAISAICHI_CODE ASC , shiyoKaijo.KAIJO_CODE ASC";

            stmt = con.prepareStatement(sql);
            param.add(sknKsuCode);
            param.add(shubetsuCode);
            param.add(kaisuCode);
            for (int i = 0; i < kaisaichiCodes.length; i++) {
                param.add(kaisaichiCodes[i]);
            }
            int j = 1;
            for (String kaisaichi : param) {
                stmt.setString(j++, kaisaichi);
            }

            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();

            while (rs.next()) {
                ShiyoKaijo detail = new ShiyoKaijo();
                // �N�x	
                detail.setNendo(rs.getString("NENDO"));
                // ����/�u�K��	
                detail.setSknKsuCode(rs.getString("SKN_KSU_CODE"));
                // ���	
                detail.setShubetsuCode(rs.getString("SHUBETSU_CODE"));
                // ��	
                detail.setKaisuCode(rs.getString("KAISU_CODE"));
                //���ID
                detail.setKaijoId(rs.getString("KAIJO_ID"));
                // �J�Òn
                detail.setKaisaichiCode(rs.getString("KAISAICHI_CODE"));
                detail.setKaijoCode(rs.getString("KAIJO_CODE"));
                detail.setKaijoName(rs.getString("KAIJO_NAME"));
                detail.setKaijoNameRyaku(rs.getString("KAIJO_NAME_RYAKU"));
                // �w�ȁE���Z
                detail.setKaijoShikenKbn(rs.getString("KAIJO_SHIKEN_KBN"));
                // ����
                detail.setNitteiFrom(rs.getString("NITTEI_FROM"));
                detail.setNitteiTo(rs.getString("NITTEI_TO"));
                // ���
                detail.setTeiin(rs.getString("TEIIN"));
                // ���ݐl��
                detail.setGenzaiNinzu(rs.getString("GENZAI_NINZU"));

                kaijoByKaisaichiList.add(detail);
            }

        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return kaijoByKaisaichiList;
    }

    @Override
    public MstKanriShiyoKaijoJoho findDetail(String nendo, String sknKsuCode, String shubetsuCode, String kaisuCode, String kaijoId, String kaijoShikenKbn, String kaisaichiCode, String kaijoCode) {

        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = "";
        MstKanriShiyoKaijoJoho shiyoKaijoDetail = new MstKanriShiyoKaijoJoho();

        try {
            con = getConnection();
            sql = "SELECT "
                    + "skd.NENDO AS NENDO"
                    + ", " + "skd.SKN_KSU_CODE AS SKN_KSU_CODE"
                    + ", " + "skd.SHUBETSU_CODE AS SHUBETSU_CODE"
                    + ", " + "skd.KAISU_CODE AS KAISU_CODE"
                    + ", " + "skd.KAIJO_ID AS KAIJO_ID"
                    + ", " + "skd.KAIJO_SHIKEN_KBN AS KAIJO_SHIKEN_KBN"
                    + ", " + "skd.KAISAICHI_NAME AS KAISAICHI_NAME"
                    + ", " + "skd.KAISAICHI_CODE AS KAISAICHI_CODE"
                    + ", " + "skd.KAIJO_CODE AS KAIJO_CODE"
                    + ", " + "skd.KAIJO_NAME AS KAIJO_NAME"
                    + ", " + "skd.KAIJO_NAME_RYAKU AS KAIJO_NAME_RYAKU"
                    + ", " + "skd.YUBIN_NO AS YUBIN_NO"
                    + ", " + "skd.JUSHO AS JUSHO"
                    + ", " + "skd.TANTOSHA_CODE AS TANTOSHA_CODE"
                    + ", " + "skd.TANTOSHA AS TANTOSHA"
                    + ", " + "skd.TANTO_BUSHO AS TANTO_BUSHO"
                    + ", " + "skd.TEL_NO AS TEL_NO"
                    + ", " + "skd.FAX_NO AS FAX_NO"
                    + ", " + "skd.TANTOSHA_MAIL_ADDRESS AS TANTOSHA_MAIL_ADDRESS"
                    + ", " + "skd.NITTEI_FROM AS NITTEI_FROM"
                    + ", " + "skd.NITTEI_TO AS NITTEI_TO"
                    + ", " + "skd.TEIIN AS TEIIN"
                    + ", " + "skd.GENZAI_NINZU AS GENZAI_NINZU"
                    + ", " + "skd.BIKO_KAIJO AS BIKO_KAIJO"
                    + ", " + "skd.BIKO_TANTOSHA AS BIKO_TANTOSHA"
                    + " FROM " + getSchemaName() + "." + ShiyoKaijoDao.TABLE_NAME + " AS skd"
                    + " LEFT JOIN " + getSchemaName() + "." + MeishoKanriDao.TABLE_NAME + " AS kaisaichi_code"
                    + " ON " + "skd.KAISAICHI_CODE = kaisaichi_code.HANYO_CODE "
                    + " AND " + "kaisaichi_code.GROUP_CODE = 'KAISAICHI_CODE' "
                    + " WHERE " + "skd.KAISAICHI_CODE = ?"
                    + " AND " + "skd.KAIJO_CODE = ?"
                    + " ORDER BY skd.KAISAICHI_CODE ASC "
                    + " LIMIT 1 ";

            stmt = con.prepareStatement(sql);
            int i = 1;
            stmt.setString(i++, nendo);
            stmt.setString(i++, sknKsuCode);
            stmt.setString(i++, shubetsuCode);
            stmt.setString(i++, kaisuCode);
            stmt.setString(i++, kaijoId);
            stmt.setString(i++, kaijoShikenKbn);
            stmt.setString(i++, kaisaichiCode);
            stmt.setString(i++, kaijoCode);
            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();

            if (rs.next()) {
                // �N�x	
                shiyoKaijoDetail.setNendo(rs.getString("NENDO"));
                // ����/�u�K��	
                shiyoKaijoDetail.setSknKsuCode(rs.getString("SKN_KSU_CODE"));
                // ���	
                shiyoKaijoDetail.setShubetsuCode(rs.getString("SHUBETSU_CODE"));
                // ��	
                shiyoKaijoDetail.setKaisuCode(rs.getString("KAISU_CODE"));
                // ���ID	
                shiyoKaijoDetail.setKaijoId(rs.getString("KAIJO_ID"));
                //��ꎎ���敪
                shiyoKaijoDetail.setKaijoShikenKbn(rs.getString("KAIJO_SHIKEN_KBN"));
                // ��ꖼ	
                shiyoKaijoDetail.setKaisaichiCode(rs.getString("KAISAICHI_CODE"));
                shiyoKaijoDetail.setKaijoCode(rs.getString("KAIJO_CODE"));
                shiyoKaijoDetail.setKaijoName(rs.getString("KAIJO_NAME"));
                shiyoKaijoDetail.setKaijoNameRyaku(rs.getString("KAIJO_NAME_RYAKU"));
                //�X�֔ԍ�
                shiyoKaijoDetail.setYubinNo(rs.getString("YUBIN_NO"));
                // �Z��
                shiyoKaijoDetail.setJusho(rs.getString("JUSHO"));
                // �S���҃R�[�h
                shiyoKaijoDetail.setTantoshaCode(rs.getString("TANTOSHA_CODE"));
                shiyoKaijoDetail.setTantosha(rs.getString("TANTOSHA"));
                shiyoKaijoDetail.setTantoBusho(rs.getString("TANTO_BUSHO"));
                shiyoKaijoDetail.setTelNo(rs.getString("TEL_NO"));
                shiyoKaijoDetail.setFaxNo(rs.getString("FAX_NO"));
                shiyoKaijoDetail.setTantoshaMailAddress(rs.getString("TANTOSHA_MAIL_ADDRESS"));
                // ����
                shiyoKaijoDetail.setNitteiFrom(rs.getString("NITTEI_FROM"));
                shiyoKaijoDetail.setNitteiTo(rs.getString("NITTEI_TO"));
                // ���
                shiyoKaijoDetail.setTeiin(rs.getString("TEIIN"));
                // ���ݐl��
                shiyoKaijoDetail.setGenzaiNinzu(rs.getString("GENZAI_NINZU"));
                //���l
                shiyoKaijoDetail.setBikoKaijo(rs.getString("BIKO_KAIJO"));
                shiyoKaijoDetail.setBikoTanto(rs.getString("BIKO_TANTO"));
            } else {
                shiyoKaijoDetail = null;
            }

        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return shiyoKaijoDetail;
    }

    /**
     * �����u�K��R�[�h�A��ʃR�[�h�A�񐔃R�[�h����v����g�p�����擾����B
     *
     * @param sknKsuCode �����u�K��R�[�h
     * @param shubetsuCode ��ʃR�[�h
     * @param kaisuCode �񐔃R�[�h
     */
    @Override
    public List<MstKanriShiyoKaijoJoho> searchShiyoKaijoList(String nendo, String sknKsuCode, String shubetsuCode, String kaisuCode) {
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = "";
        List<MstKanriShiyoKaijoJoho> shiyoKaijoList = new LinkedList<MstKanriShiyoKaijoJoho>();

        try {
            con = getConnection();
            sql = "SELECT "
                    + "shiyoKaijo.SKN_KSU_CODE AS SKN_KSU_CODE"
                    + ", " + "shiyoKaijo.SHUBETSU_CODE AS SHUBETSU_CODE"
                    + ", " + "shiyoKaijo.KAISU_CODE AS KAISU_CODE"
                    + ", " + "shiyoKaijo.KAISAICHI_CODE AS KAISAICHI_CODE"
                    + ", " + "shiyoKaijo.KAIJO_ID AS KAIJO_ID"
                    + ", " + "shiyoKaijo.KAIJO_SHIKEN_KBN AS KAIJO_SHIKEN_KBN"
                    + ", " + "shiyoKaijo.KAIJO_CODE AS KAIJO_CODE"
                    + ", " + "shiyoKaijo.KAIJO_NAME AS KAIJO_NAME"
                    + ", " + "shiyoKaijo.KAIJO_NAME_RYAKU AS KAIJO_NAME_RYAKU"
                    + ", " + "shiyoKaijo.NITTEI_FROM AS NITTEI_FROM"
                    + ", " + "shiyoKaijo.NITTEI_TO AS NITTEI_TO"
                    + ", " + "shiyoKaijo.TEIIN AS TEIIN"
                    + ", " + "shiyoKaijo.TANTOSHA_CODE AS TANTOSHA_CODE"
                    + ", " + "shiyoKaijo.KAISAICHI_CODE_KAIJO_MST AS KAISAICHI_CODE_KAIJO_MST"
                    + " FROM " + getSchemaName() + "." + ShiyoKaijoDao.TABLE_NAME + " AS shiyoKaijo"
                    + " WHERE shiyoKaijo.NENDO = ?"
                    + " AND shiyoKaijo.SKN_KSU_CODE = ?"
                    + " AND shiyoKaijo.SHUBETSU_CODE = ?"
                    + " AND shiyoKaijo.KAISU_CODE = ?"
                    + " AND shiyoKaijo.RONRI_SAKUJO_FLG = '0'"
                    + " ORDER BY shiyoKaijo.KAISAICHI_CODE ASC , shiyoKaijo.KAIJO_ID ASC";

            stmt = con.prepareStatement(sql);
            int i = 1;
            stmt.setString(i++, nendo);
            stmt.setString(i++, sknKsuCode);
            stmt.setString(i++, shubetsuCode);
            stmt.setString(i++, kaisuCode);
            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();

            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();

            while (rs.next()) {
                MstKanriShiyoKaijoJoho detail = new MstKanriShiyoKaijoJoho();
                // ����/�u�K��	
                detail.setSknKsuCode(rs.getString("SKN_KSU_CODE"));
                // ���	
                detail.setShubetsuCode(rs.getString("SHUBETSU_CODE"));
                // ��	
                detail.setKaisuCode(rs.getString("KAISU_CODE"));
                // �J�Òn
                detail.setKaisaichiCode(rs.getString("KAISAICHI_CODE"));
                detail.setKaijoCode(rs.getString("KAIJO_CODE"));
                detail.setKaijoName(rs.getString("KAIJO_NAME"));
                detail.setKaijoNameRyaku(rs.getString("KAIJO_NAME_RYAKU"));
                // ���ID
                detail.setKaijoId(rs.getString("KAIJO_ID"));
                // ��ꎎ���敪
                detail.setKaijoShikenKbn(rs.getString("KAIJO_SHIKEN_KBN"));
                // ����
                detail.setNitteiFrom(rs.getString("NITTEI_FROM"));
                detail.setNitteiTo(rs.getString("NITTEI_TO"));
                // ���
                detail.setTeiin(rs.getString("TEIIN"));
                // �S����
                detail.setTantoshaCode(rs.getString("TANTOSHA_CODE"));
                // �J�Òn�R�[�h�i���}�X�^�j
                detail.setKaisaichiCodeKaijoMst(rs.getString("KAISAICHI_CODE_KAIJO_MST"));

                shiyoKaijoList.add(detail);
            }

        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return shiyoKaijoList;
    }

    /**
     * �g�p�����X�V����B
     *
     * @param bo �X�V�f�[�^
     * @param oldKaijoShikenKbn �X�V�O�̉�ꎎ���敪
     * @param oldKaijoCode �X�V�O�̉��R�[�h
     */
    @Override
    public Boolean updateShiyoKaijo(ShiyoKaijo bo, String oldKaijoShikenKbn, String oldKaijoCode) {
        Connection con = null;
        PreparedStatement stmt = null;
        String sql = "";
        try {
            con = getConnection();
            sql = "UPDATE " + getSchemaName() + "." + TABLE_NAME + " SET"
                    + " KAIJO_SHIKEN_KBN = ?"
                    + ",KAIJO_CODE = ?"
                    + ",KAIJO_NAME = ?"
                    + ",KAIJO_NAME_RYAKU = ?"
                    + ",YUBIN_NO = ?"
                    + ",JUSHO = ?"
                    + ",TANTOSHA_CODE = ?"
                    + ",NITTEI_FROM = ?"
                    + ",NITTEI_TO = ?"
                    + ",TEIIN = ?"
                    + ",BIKO_KAIJO = ?"
                    + ",BIKO_TANTO = ?"
                    + ",KAISAICHI_CODE_KAIJO_MST = ?"
                    + ",KOSHIN_KBN = ?"
                    + ",KOSHIN_DATE = ?"
                    + ",KOSHIN_TIME = ?"
                    + ",KOSHIN_USER_ID = ?"
                    + " WHERE"
                    + " NENDO = ?"
                    + " AND SKN_KSU_CODE = ?"
                    + " AND SHUBETSU_CODE = ?"
                    + " AND KAISU_CODE = ?"
                    + " AND KAIJO_ID = ?"
                    + " AND KAIJO_SHIKEN_KBN = ?"
                    + " AND KAISAICHI_CODE = ?"
                    + " AND KAIJO_CODE = ?";

            stmt = con.prepareStatement(sql);
            int i = 1;
            stmt.setString(i++, bo.getKaijoShikenKbn());
            stmt.setString(i++, bo.getKaijoCode());
            stmt.setString(i++, bo.getKaijoName());
            stmt.setString(i++, bo.getKaijoNameRyaku());
            stmt.setString(i++, bo.getYubinNo());
            stmt.setString(i++, bo.getJusho());
            stmt.setString(i++, bo.getTantoshaCode());
            stmt.setString(i++, bo.getNitteiFrom());
            stmt.setString(i++, bo.getNitteiTo());
            stmt.setString(i++, bo.getTeiin());
            stmt.setString(i++, bo.getBikoKaijo());
            stmt.setString(i++, bo.getBikoTanto());
            stmt.setString(i++, bo.getKaisaichiCodeKaijoMst());
            stmt.setString(i++, bo.getKoshinKbn());
            stmt.setString(i++, bo.getKoshinDate());
            stmt.setString(i++, bo.getKoshinTime());
            stmt.setString(i++, bo.getKoshinUserId());

            stmt.setString(i++, bo.getNendo());
            stmt.setString(i++, bo.getSknKsuCode());
            stmt.setString(i++, bo.getShubetsuCode());
            stmt.setString(i++, bo.getKaisuCode());
            stmt.setString(i++, bo.getKaijoId());
            stmt.setString(i++, oldKaijoShikenKbn);
            stmt.setString(i++, bo.getKaisaichiCode());
            stmt.setString(i++, oldKaijoCode);

            LogGenerate.debugOutput(getSql(stmt));
            if (stmt.executeUpdate() == 0) {
                return false;
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt);
        }
        return true;
    }

    /**
     * �g�p�����X�V����B�N�x�X�V�p
     *
     * @param bo �X�V�f�[�^
     * @param oldNendo �X�V�O�̉�ꎎ���敪
     */
    @Override
    public Boolean updateShiyoKaijoNendo(ShiyoKaijo bo, String oldNendo) {
        Connection con = null;
        PreparedStatement stmt = null;
        String sql = "";
        try {
            con = getConnection();
            sql = "UPDATE " + getSchemaName() + "." + TABLE_NAME + " SET"
                    + " NENDO = ?"
                    + ",KOSHIN_KBN = ?"
                    + ",KOSHIN_DATE = ?"
                    + ",KOSHIN_TIME = ?"
                    + ",KOSHIN_USER_ID = ?"
                    + " WHERE"
                    + " NENDO = ?"
                    + " AND SKN_KSU_CODE = ?"
                    + " AND SHUBETSU_CODE = ?"
                    + " AND KAISU_CODE = ?"
                    + " AND KAIJO_ID = ?"
                    + " AND KAIJO_SHIKEN_KBN = ?"
                    + " AND KAISAICHI_CODE = ?"
                    + " AND KAIJO_CODE = ?";

            stmt = con.prepareStatement(sql);
            int i = 1;
            stmt.setString(i++, bo.getNendo());
            stmt.setString(i++, bo.getKoshinKbn());
            stmt.setString(i++, bo.getKoshinDate());
            stmt.setString(i++, bo.getKoshinTime());
            stmt.setString(i++, bo.getKoshinUserId());

            stmt.setString(i++, oldNendo);
            stmt.setString(i++, bo.getSknKsuCode());
            stmt.setString(i++, bo.getShubetsuCode());
            stmt.setString(i++, bo.getKaisuCode());
            stmt.setString(i++, bo.getKaijoId());
            stmt.setString(i++, bo.getKaijoShikenKbn());
            stmt.setString(i++, bo.getKaisaichiCode());
            stmt.setString(i++, bo.getKaijoCode());

            LogGenerate.debugOutput(getSql(stmt));
            if (stmt.executeUpdate() == 0) {
                return false;
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt);
        }
        return true;
    }

    @Override
    public String nendoForDelete(String sknKsuCode, String shubetsuCode, String kaisuCode) {

        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = "";
        String nendo = "";

        try {
            con = getConnection();
            sql = "SELECT "
                    + "shiyoKaijo.NENDO AS NENDO"
                    + " FROM " + getSchemaName() + "." + ShiyoKaijoDao.TABLE_NAME + " AS shiyoKaijo"
                    + " WHERE " + "shiyoKaijo.SKN_KSU_CODE = ?"
                    + " AND " + "shiyoKaijo.SHUBETSU_CODE  = ?"
                    + " AND " + "shiyoKaijo.KAISU_CODE  = ?"
                    + " AND " + "shiyoKaijo.RONRI_SAKUJO_FLG = '0'"
                    + " ORDER BY shiyoKaijo.NENDO DESC "
                    + " LIMIT 1 ";

            stmt = con.prepareStatement(sql);
            int i = 1;
            stmt.setString(i++, sknKsuCode);
            stmt.setString(i++, shubetsuCode);
            stmt.setString(i++, kaisuCode);
            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();

            if (rs.next()) {
                nendo = rs.getString("NENDO");
            } else {
                nendo = null;
            }

        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return nendo;
    }

    /**
     * ���ID���ĕt�Ԃ���B
     *
     * @param bo �X�V�f�[�^
     * @param oldKaijoId �X�V�O�̉��ID
     */
//    @Override
//    public Boolean updateKaijoId(ShiyoKaijo bo, String oldKaijoId) {
//        Connection con = null;
//        PreparedStatement stmt = null;
//        String sql = "";
//        try {
//            con = getConnection();
//            sql = "UPDATE " + getSchemaName() + "." + TABLE_NAME + " SET"
//                    + " KAIJO_ID = ?"
//                    + ",KOSHIN_KBN = ?"
//                    + ",KOSHIN_DATE = ?"
//                    + ",KOSHIN_TIME = ?"
//                    + ",KOSHIN_USER_ID = ?"
//                    + " WHERE"
//                    + " NENDO = ?"
//                    + " AND SKN_KSU_CODE = ?"
//                    + " AND SHUBETSU_CODE = ?"
//                    + " AND KAISU_CODE = ?"
//                    + " AND KAIJO_ID = ?"
//                    + " AND KAIJO_SHIKEN_KBN = ?"
//                    + " AND KAISAICHI_CODE = ?"
//                    + " AND KAIJO_CODE = ?";
//
//            stmt = con.prepareStatement(sql);
//            int i = 1;
//            stmt.setString(i++, bo.getKaijoId());
//            stmt.setString(i++, bo.getKoshinKbn());
//            stmt.setString(i++, bo.getKoshinDate());
//            stmt.setString(i++, bo.getKoshinTime());
//            stmt.setString(i++, bo.getKoshinUserId());
//
//            stmt.setString(i++, bo.getNendo());
//            stmt.setString(i++, bo.getSknKsuCode());
//            stmt.setString(i++, bo.getShubetsuCode());
//            stmt.setString(i++, bo.getKaisuCode());
//            stmt.setString(i++, oldKaijoId);
//            stmt.setString(i++, bo.getKaijoShikenKbn());
//            stmt.setString(i++, bo.getKaisaichiCode());
//            stmt.setString(i++, bo.getKaijoCode());
//
//            LogGenerate.debugOutput(getSql(stmt));
//            if (stmt.executeUpdate() == 0) {
//                return false;
//            }
//        } catch (SQLException ex) {
//            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
//        } finally {
//            close(con, stmt);
//        }
//        return true;
//    }
    /**
     * �N�x�A�����u�K��R�[�h�A��ʃR�[�h�A�񐔃R�[�h����v����g�p�����擾����B
     *
     * @param nendo �N�x
     * @param sknKsuCode �����u�K��R�[�h
     * @param shubetsuCode ��ʃR�[�h
     * @param kaisuCode �񐔃R�[�h
     */
    @Override
    public List<ShiyoKaijo> searchShiyoKaijoListForKaijoId(String nendo, String sknKsuCode, String shubetsuCode, String kaisuCode) {
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = "";
        List<ShiyoKaijo> shiyoKaijoList = new LinkedList<ShiyoKaijo>();

        try {
            con = getConnection();
            sql = "SELECT "
                    + FIELDS_DECRYPT
                    + " FROM " + getSchemaName() + "." + ShiyoKaijoDao.TABLE_NAME + " AS shiyoKaijo"
                    + " WHERE shiyoKaijo.NENDO = ?"
                    + " AND shiyoKaijo.SKN_KSU_CODE = ?"
                    + " AND shiyoKaijo.SHUBETSU_CODE = ?"
                    + " AND shiyoKaijo.KAISU_CODE = ?"
                    + " AND shiyoKaijo.RONRI_SAKUJO_FLG = '0'"
                    + " ORDER BY shiyoKaijo.KAISAICHI_CODE ASC, shiyoKaijo.KAIJO_CODE ASC, shiyoKaijo.NITTEI_FROM ASC, shiyoKaijo.KAIJO_SHIKEN_KBN ASC";

            stmt = con.prepareStatement(sql);
            int i = 1;
            stmt.setString(i++, nendo);
            stmt.setString(i++, sknKsuCode);
            stmt.setString(i++, shubetsuCode);
            stmt.setString(i++, kaisuCode);
            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();

            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();

            while (rs.next()) {
                ShiyoKaijo detail = new ShiyoKaijo();
                // �N�x	
                detail.setNendo(rs.getString("NENDO"));
                // ����/�u�K��	
                detail.setSknKsuCode(rs.getString("SKN_KSU_CODE"));
                // ���	
                detail.setShubetsuCode(rs.getString("SHUBETSU_CODE"));
                // ��	
                detail.setKaisuCode(rs.getString("KAISU_CODE"));
                // ���ID	
                detail.setKaijoId(rs.getString("KAIJO_ID"));
                //��ꎎ���敪
                detail.setKaijoShikenKbn(rs.getString("KAIJO_SHIKEN_KBN"));
                // �J�Òn	
                detail.setKaisaichiCode(rs.getString("KAISAICHI_CODE"));
                //��ꖼ
                detail.setKaijoCode(rs.getString("KAIJO_CODE"));
                detail.setKaijoName(rs.getString("KAIJO_NAME"));
                //��ꖼ�i���j
                detail.setKaijoNameRyaku(rs.getString("KAIJO_NAME_RYAKU"));
                //�X�֔ԍ�
                detail.setYubinNo(rs.getString("YUBIN_NO"));
                // �Z��
                detail.setJusho(rs.getString("JUSHO"));
                // �S���҃R�[�h
                detail.setTantoshaCode(rs.getString("TANTOSHA_CODE"));
                // ����
                detail.setNitteiFrom(rs.getString("NITTEI_FROM"));
                detail.setNitteiTo(rs.getString("NITTEI_TO"));
                // ���
                detail.setTeiin(rs.getString("TEIIN"));
                // ���ݐl��
                detail.setGenzaiNinzu(rs.getString("GENZAI_NINZU"));
                //���l
                detail.setBikoKaijo(rs.getString("BIKO_KAIJO"));
                detail.setBikoTanto(rs.getString("BIKO_TANTO"));
                //�J�Òn�R�[�h�i���}�X�^�j
                detail.setKaisaichiCodeKaijoMst(rs.getString("KAISAICHI_CODE_KAIJO_MST"));
                // �V�X�e�����
                detail.setKoshinKbn(rs.getString("KOSHIN_KBN"));
                detail.setTorokuDate(rs.getString("TOROKU_DATE"));
                detail.setTorokuTime(rs.getString("TOROKU_TIME"));
                detail.setTorokuUserId(rs.getString("TOROKU_USER_ID"));
                detail.setKoshinDate(rs.getString("KOSHIN_DATE"));
                detail.setKoshinTime(rs.getString("KOSHIN_TIME"));
                detail.setKoshinUserId(rs.getString("KOSHIN_USER_ID"));
                detail.setRonriSakujoFlg(rs.getString("RONRI_SAKUJO_FLG"));

                shiyoKaijoList.add(detail);
            }

        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return shiyoKaijoList;
    }

    /**
     * �����\��������p
     *
     * @param bo ������̎g�p���f�[�^
     */
    @Override
    public String countShiyoKaijoForHukusei(ShiyoKaijo bo) {
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = "";
        String count = "";

        try {
            con = getConnection();
            sql = "SELECT "
                    + " COUNT(*) AS SHIYO_KAIJO_COUNT"
                    + " FROM " + getSchemaName() + "." + ShiyoKaijoDao.TABLE_NAME + " AS shiyoKaijo"
                    + " WHERE shiyoKaijo.NENDO = ?"
                    + " AND shiyoKaijo.SKN_KSU_CODE = ?"
                    + " AND shiyoKaijo.SHUBETSU_CODE = ?"
                    + " AND shiyoKaijo.KAISU_CODE = ?"
                    + " AND shiyoKaijo.KAISAICHI_CODE = ?"
                    + " AND shiyoKaijo.KAIJO_CODE = ?"
                    + " AND shiyoKaijo.RONRI_SAKUJO_FLG = '0'";

            stmt = con.prepareStatement(sql);
            int i = 1;
            stmt.setString(i++, bo.getNendo());
            stmt.setString(i++, bo.getSknKsuCode());
            stmt.setString(i++, bo.getShubetsuCode());
            stmt.setString(i++, bo.getKaisuCode());
            stmt.setString(i++, bo.getKaisaichiCode());
            stmt.setString(i++, bo.getKaijoCode());
            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();

            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();

            if (rs.next()) {
                count = rs.getString("SHIYO_KAIJO_COUNT");
            } else {
                count = null;
            }

        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return count;
    }

    /**
     * ��ꃊ�X�g�擾
     *
     * @param list
     * @param inSession
     */
    @Override
    public void findKaijoIdList(List<Option> list, HanyouSearchJoho bo) {

        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = "";

        String limit = "";

        limit = " LIMIT " + "100";
        try {
            con = getConnection();
            sql = "SELECT " + FIELDS_DECRYPT
                    + " FROM " + getSchemaName() + "." + TABLE_NAME
                    + " WHERE NENDO = ?"
                    + " AND SKN_KSU_CODE = ?"
                    + " AND SHUBETSU_CODE = ?"
                    + " AND KAISU_CODE = ?"
                    + " AND RONRI_SAKUJO_FLG = '0'"
                    + " ORDER BY KAIJO_ID ASC ";

            stmt = con.prepareStatement(sql);
            int i = 1;
            stmt.setString(i++, bo.getNendo());
            stmt.setString(i++, bo.getSknKsuCode());
            stmt.setString(i++, bo.getShubetsuCode());
            stmt.setString(i++, bo.getKaisuCode());

            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();

            while (rs.next()) {
                if (list != null) {
                    list.add(new Option(rs.getString("KAIJO_ID"), rs.getString("KAIJO_ID")));
                }

            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }

    }

    /**
     * ��ꃊ�X�g�擾
     *
     * @param list
     * @param inSession
     */
    @Override
    public void findKaijoIdAllList(List<Option> list, HanyouSearchJoho bo) {

        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = "";

        String limit = "";

        limit = " LIMIT " + "100";
        try {
            con = getConnection();
            sql = "SELECT " + FIELDS_DECRYPT
                    + " FROM " + getSchemaName() + "." + TABLE_NAME
                    + " WHERE NENDO = ?"
                    + " AND SKN_KSU_CODE = ?"
                    + " AND SHUBETSU_CODE = ?"
                    + " AND KAISU_CODE = ?"
                    + " AND RONRI_SAKUJO_FLG = '0'";

            stmt = con.prepareStatement(sql);
            int i = 1;
            stmt.setString(i++, bo.getNendo());
            stmt.setString(i++, bo.getSknKsuCode());
            stmt.setString(i++, bo.getShubetsuCode());
            stmt.setString(i++, bo.getKaisuCode());

            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();

            while (rs.next()) {
                if (list != null) {
                    list.add(new Option(rs.getString("KAIJO_ID"), rs.getString("KAIJO_SHIKEN_KBN")
                            + "," + rs.getString("KAISAICHI_CODE")
                            + "," + rs.getString("KAIJO_CODE")
                            + "," + rs.getString("KAIJO_NAME")
                            + "," + rs.getString("JUSHO")
                            + "," + rs.getString("NITTEI_FROM")
                            + "," + rs.getString("NITTEI_TO")
                            + "," + rs.getString("KAISAICHI_CODE")
                            + "," + rs.getString("KAIJO_CODE")
                    ));
                }

            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }

    }

    /**
     * �����u�K��̏����擾����B
     *
     * @param bo
     * @return ���I����񃊃X�g
     */
    @Override
    public List<HanyouKaisaiTiJoho> searchHanyoKaijoList(ShiyoKaijo bo) {
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = "";
        List<String> param = new ArrayList<>();
        List<HanyouKaisaiTiJoho> kaijoList = new ArrayList<>();
        try {
            con = getConnection();
            sql = "SELECT K1.KAISAICHI_CODE,M1.HANYO_CHI AS KAISAICHI,K1.NITTEI_FROM,K1.NITTEI_TO,"
                    + " K1.KAIJO_ID,K1.KAIJO_CODE,K1.KAIJO_NAME_RYAKU AS KAIJO_NAME,K1.JUSHO,"
                    + " TO_NUMBER(K1.TEIIN,'9999999999')-TO_NUMBER(K1.GENZAI_NINZU,'9999999999') AS KUSEKI"
                    + " FROM BMA.SHIYO_KAIJO AS K1"
                    + " LEFT JOIN BMA.MEISHO_KANRI AS M1"
                    + " ON K1.KAISAICHI_CODE = M1.HANYO_CODE"
                    + " AND M1.GROUP_CODE = 'KAISAICHI_CODE'"
                    + " WHERE K1.NENDO = ?"
                    + " AND K1.SKN_KSU_CODE = ?"
                    + " AND K1.SHUBETSU_CODE = ?"
                    + " AND K1.KAISU_CODE = ?"
                    + " AND K1.KAIJO_SHIKEN_KBN IN('0','1' )"
                    + " AND K1.RONRI_SAKUJO_FLG = '0'"
                    + " ORDER BY K1.KAISAICHI_CODE ASC, K1.NITTEI_FROM ASC";
            param.add(bo.getNendo());
            param.add(bo.getSknKsuCode());
            param.add(bo.getShubetsuCode());
            param.add(bo.getKaisuCode());

            stmt = con.prepareStatement(sql);
            int i = 1;
            for (String pm : param) {
                stmt.setString(i++, pm);
            }

            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();
            while (rs.next()) {
                HanyouKaisaiTiJoho HanyouKaisaiTiJoho = new HanyouKaisaiTiJoho();

                HanyouKaisaiTiJoho.setKaisaichiCode(rs.getString("KAISAICHI_CODE"));
                HanyouKaisaiTiJoho.setKaijoId(rs.getString("KAIJO_ID"));
                HanyouKaisaiTiJoho.setKaisaichi(rs.getString("KAISAICHI"));
                HanyouKaisaiTiJoho.setDateFrom(rs.getString("NITTEI_FROM"));
                HanyouKaisaiTiJoho.setDateTo(rs.getString("NITTEI_TO"));
                HanyouKaisaiTiJoho.setKaijoCode(rs.getString("KAIJO_CODE"));
                HanyouKaisaiTiJoho.setKaijoName(rs.getString("KAIJO_NAME"));
                HanyouKaisaiTiJoho.setKaijoJusho(rs.getString("JUSHO"));
                HanyouKaisaiTiJoho.setKuusekiSuu(rs.getString("KUSEKI"));

                kaijoList.add(HanyouKaisaiTiJoho);
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return kaijoList;

    }
     /**
     * ���I���̏����擾����B
     * @param bo
     * @return ���I�����
     */
    @Override
    public ShiyoKaijo findRonriFlg(ShiyoKaijo bo) {
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = "";
        try {
            con = getConnection();
            sql = "SELECT " + FIELDS_DECRYPT
                    + " FROM " + getSchemaName() + "." + TABLE_NAME
                    + " WHERE"
                    + " NENDO = ?"
                    + " AND SKN_KSU_CODE = ?"
                    + " AND SHUBETSU_CODE = ?"
                    + " AND KAISU_CODE = ?"
                    + " AND KAIJO_ID = ?"
                    + " AND KAIJO_SHIKEN_KBN = ?"
                    + " AND KAISAICHI_CODE = ?"
                    + " AND KAIJO_CODE = ?"
                    + " AND RONRI_SAKUJO_FLG = '0'";

            stmt = con.prepareStatement(sql);
            int i = 1;
            stmt.setString(i++, bo.getNendo());
            stmt.setString(i++, bo.getSknKsuCode());
            stmt.setString(i++, bo.getShubetsuCode());
            stmt.setString(i++, bo.getKaisuCode());
            stmt.setString(i++, bo.getKaijoId());
            stmt.setString(i++, bo.getKaijoShikenKbn());
            stmt.setString(i++, bo.getKaisaichiCode());
            stmt.setString(i++, bo.getKaijoCode());

            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();
            if (rs.next()) {
                setBoFromResultSet(bo, rs);
            } else {
                bo = null;
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return bo;

    }
    
    /**
     * �\���\�Ȋ�]�J�Òn���擾����B�i���ʐ\���j
     *
     * @return ��]�J�Òn���X�g
     */
    @Override
    public List<Option> findKiboKaisaichiList(ShiyoKaijo bo) {
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = "";
        List<Option> kiboKaisaichiList = new ArrayList<>();
        try {
            con = getConnection();
            sql = "SELECT"
                    + " shiyokaijo.KAISAICHI_CODE AS KAISAICHI_CODE"
                    + " , " + " kaisaichi.HANYO_CHI AS KAISAICHI_NAME"
                    + " , " + " kaisaichi.HYOJI_JUNJO AS HYOJI_JUNJO"
                    + " FROM " + getSchemaName() + "." + TABLE_NAME + " AS shiyokaijo"
                    + " LEFT JOIN " + getSchemaName() + "." + MeishoKanriDao.TABLE_NAME + " AS kaisaichi"
                    + " ON " + " kaisaichi.GROUP_CODE = '"  + BmaConstants.MEISHO_KANRI_GROUP_KAISAICHI_CODE + "'"
                    + " AND " + " kaisaichi.HANYO_CODE = KAISAICHI_CODE"
                    + " WHERE shiyokaijo.NENDO = ?"
                    + " AND shiyokaijo.SKN_KSU_CODE = ?"
                    + " AND shiyokaijo.SHUBETSU_CODE = ?"
                    + " AND shiyokaijo.KAISU_CODE = ?"
                    + " AND shiyokaijo.RONRI_SAKUJO_FLG = '0'"
                    + " GROUP BY "
                    + " KAISAICHI_CODE"
                    + " , KAISAICHI_NAME"
                    + " , HYOJI_JUNJO"
                    + " ORDER BY to_number(HYOJI_JUNJO,'999') ASC";
            stmt = con.prepareStatement(sql);
            int i = 1;
            stmt.setString(i++, bo.getNendo());
            stmt.setString(i++, bo.getSknKsuCode());
            stmt.setString(i++, bo.getShubetsuCode());
            stmt.setString(i++, bo.getKaisuCode());

            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();
            while (rs.next()) {
                Option kaisaichi = new Option(rs.getString("KAISAICHI_CODE"),rs.getString("KAISAICHI_NAME"));
                kiboKaisaichiList.add(kaisaichi);
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return kiboKaisaichiList;
    }
}
