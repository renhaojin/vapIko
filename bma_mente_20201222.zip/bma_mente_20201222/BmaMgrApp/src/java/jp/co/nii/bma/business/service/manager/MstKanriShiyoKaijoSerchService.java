package jp.co.nii.bma.business.service.manager;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import jp.co.nii.bma.business.domain.KaijoMst;
import jp.co.nii.bma.business.domain.KaijoTantoMst;
import jp.co.nii.bma.business.domain.MeishoKanri;
import jp.co.nii.bma.business.domain.Schedule;
import jp.co.nii.bma.business.domain.ShiyoKaijo;
import jp.co.nii.bma.business.domain.SknksuMst;
import jp.co.nii.bma.business.rto.manager.MstKanriShiyoKaijoJoho;
import jp.co.nii.bma.business.service.common.BmaConstants;
import jp.co.nii.bma.business.service.common.BmaLogger;
import jp.co.nii.bma.business.service.common.BmaValidator;
import jp.co.nii.bma.presentation.common.BmaText;
import jp.co.nii.bma.utility.BmaUtility;
import jp.co.nii.sew.business.SystemTime;
import jp.co.nii.sew.business.service.AbstractService;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_EXCEPTION;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_RELOAD;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_SESSION;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_SUCCESS;
import jp.co.nii.sew.presentation.Messages;
import jp.co.nii.sew.presentation.Option;
import jp.co.nii.sew.presentation.RequestTransferObject;
import jp.co.nii.sew.utility.PropertyUtility;
import org.apache.commons.beanutils.BeanUtils;

/**
 *
 * @author nii19049
 */
public class MstKanriShiyoKaijoSerchService extends AbstractService {

    /**
     * DB�ڑ��̃f�[�^�\�[�X
     */
    private static String DATA_SOURCE_NAME;
    /**
     * ���O
     */
    BmaLogger log = (BmaLogger) BmaLogger.getLogger(this.getClass().getName());
    /**
     * �Ɩ��R�[�h
     */
    private static final String BUSINESS_CODE = PropertyUtility.getProperty("business_code");
    /**
     * ���׃e�X�g���[�h
     */
    private static final String STRESS_MODE = PropertyUtility.getProperty(BUSINESS_CODE + "stress_mode");

    /**
     * �R���X�g���N�^
     */
    public MstKanriShiyoKaijoSerchService() {
        super();
        /* DB�ڑ����̃��[�U�[������ */
        DATA_SOURCE_NAME = BmaConstants.DS_REGISTRANT;
    }

    /**
     * �T�[�r�X�N���X�̎��s���\�b�h
     *
     * @param rto ���N�G�X�g��񂩂�擾����rto
     * @param rtoInSession �Z�b�V�������rto
     * @return foward��
     * @throws Exception ��O
     */
    @Override
    public String doService(RequestTransferObject rto, RequestTransferObject rtoInSession)
            throws Exception {

        MstKanriShiyoKaijoJoho inRequest = (MstKanriShiyoKaijoJoho) rto;
        MstKanriShiyoKaijoJoho inSession = (MstKanriShiyoKaijoJoho) rtoInSession;
        String processName = "";

        /*�G���[���b�Z�[�W������*/
        inSession.setErrors(new Messages());
        try {
            if (!BmaUtility.isNullOrEmpty(inRequest.getShiyoKaijoTable())) {
                /*�u�g�p���v�{�^���œ���ʂɑJ�ڎ�*/
                processName = "MstKanriShiyoKaijoSearch";
                log.Start(processName);

                /* �c���Ă���Z�b�V������j�� */
                inSession.clearInfo();

                /**
                 * �����u�K��X�g���쐬
                 */
                inSession.setSknKbnList(findSknKsuList(BmaConstants.SKN_KBN));
                inSession.setKsuKbnList(findSknKsuList(BmaConstants.KSU_KBN));

                /**
                 * �J�Òn���X�g���쐬
                 */
                List<Option> list = createKaisaichiCodeList();
                inSession.setKaisaichiCodeList(list);


                /* �u���}�X�^�V�K�o�^�v��ʕ\�� */
                return "search";

            } else if (!BmaUtility.isNullOrEmpty(inRequest.getShiyoKaijoAdd())) {
                /*�u�ǉ��v�{�^��������*/
                processName = "MstKanriShiyoKaijoSearch";
                log.Start(processName);

                /* �ϐ������� */
                String sknKsuCode = "";
                String shubetsuCode = "";
                String kaisuCode = "";
                Schedule sced = new Schedule(DATA_SOURCE_NAME);
                ShiyoKaijo shiyoKaijo = new ShiyoKaijo(DATA_SOURCE_NAME);

                /* �I��l�ێ� */
                inSession.setSknksuKbn(inRequest.getSknksuKbn());
                if (BmaConstants.SKN_KBN.equals(inRequest.getSknksuKbn())) {
                    inSession.setSknName(inRequest.getSknName());
                    inSession.setKsuName("");
                } else if (BmaConstants.KSU_KBN.equals(inRequest.getSknksuKbn())) {
                    inSession.setSknName("");
                    inSession.setKsuName(inRequest.getKsuName());
                }
                String[] kaisaichiCodes = inRequest.getKaisaichiSelect();

                // �J�Òn��I�����Ă��Ȃ��ꍇ�A�S�J�Òn���擾
                if (kaisaichiCodes == null) {
                    List<Option> kaisaichiCodeList = inSession.getKaisaichiCodeList();
                    kaisaichiCodes = new String[kaisaichiCodeList.size()];

                    int i = 0;
                    for (Option kaisaichi : kaisaichiCodeList) {
                        kaisaichiCodes[i] = kaisaichi.getValue();
                        ++i;
                    }
                }
                inSession.setKaisaichiSelect(kaisaichiCodes);
                // �I��l�`�F�b�N
                if (!validateInput(inSession)) {
                    // �G���[���������ꍇ�u�g�p��ꌟ���v���Reload
                    return FWD_NM_RELOAD;
                }

                // �I�����������u�K��ɍ��킹�āA�e�R�[�h���Z�b�V�����ɕێ�
                if (BmaConstants.SKN_KBN.equals(inSession.getSknksuKbn())) {
                    sknKsuCode = inSession.getSknName().substring(0, 2);
                    shubetsuCode = inSession.getSknName().substring(2, 4);
                    kaisuCode = inSession.getSknName().substring(4, 6);
                } else if (BmaConstants.KSU_KBN.equals(inSession.getSknksuKbn())) {
                    sknKsuCode = inSession.getKsuName().substring(0, 2);
                    shubetsuCode = inSession.getKsuName().substring(2, 4);
                    kaisuCode = inSession.getKsuName().substring(4, 6);
                }

                String nendo = sced.findNendoKojiKikan(sknKsuCode, shubetsuCode, kaisuCode, BmaConstants.SCHED_CODE_OPEN, BmaConstants.SCHEDULE_KBN_ST);

                //�g�p���ɔN�x����񐔃R�[�h�܂ň�v����f�[�^��1���ł����݂��邩�ǂ���
                List<MstKanriShiyoKaijoJoho> listNendo = shiyoKaijo.searchShiyoKaijoList(nendo, sknKsuCode, shubetsuCode, kaisuCode);

//                if (listNendo.isEmpty()) {
//                    // �G���[���������ꍇ�u�g�p��ꌟ���v���Reload
//                    Messages errors = new Messages();
//                    BmaValidator.addMessage(errors, "nendo", BmaText.E00135);
//                    inSession.setErrors(errors);
//                    return FWD_NM_RELOAD;
//                }
                inSession.setNendo(nendo);
                inSession.setSknKsuCode(sknKsuCode);
                inSession.setShubetsuCode(shubetsuCode);
                inSession.setKaisuCode(kaisuCode);

                /* �����u�K��@���̎擾 */
                SknksuMst sknksuMst = new SknksuMst(BmaConstants.DS_REGISTRANT);
                inSession.setSknksuNameRyaku(sknksuMst.findSknKsuNameRyaku(sknKsuCode, shubetsuCode, kaisuCode).getSknKsuNameRyaku());

                /* �u�g�p���ǉ��v��ʕ\�� */
                return FWD_NM_SUCCESS;

            } else if (!BmaUtility.isNullOrEmpty(inRequest.getSearch())) {
                /*�u�����v�{�^��������*/
                processName = "MstKanriShiyoKaijoSearch";
                log.Start(processName);

                /*���X�g�擾*/
                ShiyoKaijo shiyoKaijo = new ShiyoKaijo(DATA_SOURCE_NAME);
                String[] kaisaichiCodes = inRequest.getKaisaichiSelect();

                // �J�Òn��I�����Ă��Ȃ��ꍇ�A�S�J�Òn���擾
                if (kaisaichiCodes == null) {
                    List<Option> kaisaichiCodeList = inSession.getKaisaichiCodeList();
                    kaisaichiCodes = new String[kaisaichiCodeList.size()];

                    int i = 0;
                    for (Option kaisaichi : kaisaichiCodeList) {
                        kaisaichiCodes[i] = kaisaichi.getValue();
                        ++i;
                    }
                }
                inSession.setKaisaichiSelect(kaisaichiCodes);

                /* �ϐ������� */
                String sknKsuCode = "";
                String shubetsuCode = "";
                String kaisuCode = "";

                /* �I��l�ێ� */
                inSession.setSknksuKbn(inRequest.getSknksuKbn());
                if (BmaConstants.SKN_KBN.equals(inRequest.getSknksuKbn())) {
                    inSession.setSknName(inRequest.getSknName());
                    inSession.setKsuName("");
                } else if (BmaConstants.KSU_KBN.equals(inRequest.getSknksuKbn())) {
                    inSession.setSknName("");
                    inSession.setKsuName(inRequest.getKsuName());
                }

                // �I��l�`�F�b�N
                if (!validateInput(inSession)) {
                    // �G���[���������ꍇ�u�g�p��ꌟ���v���Reload
                    return FWD_NM_RELOAD;
                }

                // �I�����������u�K��ɍ��킹�āA�e�R�[�h���Z�b�V�����ɕێ�
                if (BmaConstants.SKN_KBN.equals(inSession.getSknksuKbn())) {
                    sknKsuCode = inSession.getSknName().substring(0, 2);
                    shubetsuCode = inSession.getSknName().substring(2, 4);
                    kaisuCode = inSession.getSknName().substring(4, 6);
                } else if (BmaConstants.KSU_KBN.equals(inSession.getSknksuKbn())) {
                    sknKsuCode = inSession.getKsuName().substring(0, 2);
                    shubetsuCode = inSession.getKsuName().substring(2, 4);
                    kaisuCode = inSession.getKsuName().substring(4, 6);
                }
                inSession.setSknKsuCode(sknKsuCode);
                inSession.setShubetsuCode(shubetsuCode);
                inSession.setKaisuCode(kaisuCode);

                //�X�P�W���[�������J�n���̔N�x�擾
                /* �ϐ������� */
                Schedule schedule = new Schedule(DATA_SOURCE_NAME);
                String nendoSched = "";
                nendoSched = schedule.findNendoKojiKikan(sknKsuCode, shubetsuCode, kaisuCode, BmaConstants.SCHED_CODE_OPEN, BmaConstants.SCHEDULE_KBN_ST);
                if (nendoSched != null){
                    inSession.setNendoSched(nendoSched);
                } else {
                    inSession.setNendoSched("");
                }
                

                /**
                 * �J�Òn�����Ƃɉ�ꃊ�X�g�擾
                 */
                List<ShiyoKaijo> shiyoKaijoSearchList = shiyoKaijo.findByKaisaichi(sknKsuCode, shubetsuCode, kaisuCode, kaisaichiCodes);

                if (!shiyoKaijoSearchList.isEmpty()) {
                    inSession.setNendo(shiyoKaijoSearchList.get(0).getNendo());
                    List<MstKanriShiyoKaijoJoho> shiyoKaijoSearchResultList = new ArrayList<>();
                    for (ShiyoKaijo element : shiyoKaijoSearchList) {
                        MstKanriShiyoKaijoJoho shiyoKaijoDetail = createShiyoKaijoDetail(element, inSession.getKaisaichiCodeList());
                        saveShiyoKaijoSession(element, shiyoKaijoDetail);
                        setNitteiDisp(element, shiyoKaijoDetail);
                        shiyoKaijoSearchResultList.add(shiyoKaijoDetail);
                    }
                    inSession.setShiyoKaijoSearchResultList(shiyoKaijoSearchResultList);
                    inSession.setShiyoKaijoSrcListFlg(BmaConstants.FLG_ON);

                    // �y�[�W����
                    inSession.setPage(0);
                    setPage(inSession);
                    setDisplayList(inSession);

                    // error �X�P�W���[���������Ԃ̊J�n�E�I�����Ƃ�B�V�X�e�����t�Ɣ�r�B��������������s��
                    // ���ID�ĕt�ԃ{�^�������E�񊈐�����ǉ�
                    // �X�P�W���[�����������擾
                    Schedule schedStart = schedule.find(nendoSched, sknKsuCode, shubetsuCode, kaisuCode, BmaConstants.SCHED_CODE_OPEN, BmaConstants.SCHEDULE_KBN_ST);
                    Schedule schedEnd = schedule.find(nendoSched, sknKsuCode, shubetsuCode, kaisuCode, BmaConstants.SCHED_CODE_OPEN, BmaConstants.SCHEDULE_KBN_ED);
                    String sysTime = new SystemTime().getymd1();

                    if (schedStart.getDate().compareTo(sysTime) <= 0 && schedEnd.getDate().compareTo(sysTime) >= 0) {
                        // �񊈐���
                        inSession.setKaijoIdReNoBtnFlg(BmaConstants.FLG_OFF);
                    } else {
                        // ������
                        inSession.setKaijoIdReNoBtnFlg(BmaConstants.FLG_ON);
                    }
                } else {
                    // �������ʂ��Ȃ��ꍇ
                    inSession.setNendo(inSession.getNendoSched());
                    inSession.setShiyoKaijoSrcListFlg(BmaConstants.FLG_OFF);
                }
                /* �u�g�p��ꌟ���v��ʕ\�� */
                return "search";

            } else if (!BmaUtility.isNullOrEmpty(inRequest.getCommandPage())) {
                /*�y�[�W�J��*/
                processName = "MstKanriShiyoKaijoSearch_setPage";
                log.Start(processName);
                inSession.setPage(Integer.parseInt(inRequest.getCommandPage()));
                setPage(inSession);
                setDisplayList(inSession);

                return FWD_NM_RELOAD;

            } else if (!BmaUtility.isNullOrEmpty(inRequest.getNendoUpdate())) {
                /*�N�x�X�V*/
                processName = "MstKanriShiyoKaijoSearch_setPage";
                log.Start(processName);

                /*���X�g�擾*/
                ShiyoKaijo nendoUpd = new ShiyoKaijo(DATA_SOURCE_NAME);
                /* �V�X�e���������擾 */
                SystemTime sysTime = new SystemTime();
                String nendoSched = inSession.getNendoSched();
                String nendoBefore = inSession.getNendo();

                List<MstKanriShiyoKaijoJoho> shiyoKaijoSearchResultList = inSession.getShiyoKaijoSearchResultList();
                try {
                    /* �g�����U�N�V�����擾&�J�n */
                    getTransaction();
                    beginTransaction();
                    for (MstKanriShiyoKaijoJoho shiyoKaijo : shiyoKaijoSearchResultList) {
                        nendoUpd = new ShiyoKaijo(DATA_SOURCE_NAME);
                        BeanUtils.copyProperties(nendoUpd, shiyoKaijo);
                        nendoUpd.setNendo(nendoSched);
                        /* DB���ʍ��ڃZ�b�g */
                        nendoUpd.setKoshinKbn(BmaConstants.SHORI_KBN_UPDATE);
                        nendoUpd.setKoshinDate(sysTime.getymd1());
                        nendoUpd.setKoshinTime(sysTime.gethms1());
                        nendoUpd.setKoshinUserId(inRequest.getMoshikomishaId());
                        nendoUpd.updateShiyoKaijoNendo(nendoUpd, nendoBefore);
                    }
                    /* �R�~�b�g */
                    commitTransaction();
                } catch (Exception ex) {
                    ex.printStackTrace();
                    // ���[���o�b�N
                    rollbackTransaction();
                    return FWD_NM_SESSION;
                }

                ShiyoKaijo shiyoKaijo = new ShiyoKaijo(DATA_SOURCE_NAME);
                String sknKsuCode = inSession.getSknKsuCode();
                String shubetsuCode = inSession.getShubetsuCode();
                String kaisuCode = inSession.getKaisuCode();
                List<ShiyoKaijo> shiyoKaijoSearchList = shiyoKaijo.findByKaisaichi(sknKsuCode, shubetsuCode, kaisuCode, inSession.getKaisaichiSelect());
                if (!shiyoKaijoSearchList.isEmpty()) {
                    inSession.setNendo(shiyoKaijoSearchList.get(0).getNendo());
                    shiyoKaijoSearchResultList = new ArrayList<>();
                    for (ShiyoKaijo element : shiyoKaijoSearchList) {
                        MstKanriShiyoKaijoJoho shiyoKaijoDetail = createShiyoKaijoDetail(element, inSession.getKaisaichiCodeList());
                        saveShiyoKaijoSession(element, shiyoKaijoDetail);
                        setNitteiDisp(element, shiyoKaijoDetail);
                        shiyoKaijoSearchResultList.add(shiyoKaijoDetail);
                    }
                    inSession.setShiyoKaijoSearchResultList(shiyoKaijoSearchResultList);
                    inSession.setShiyoKaijoSrcListFlg(BmaConstants.FLG_ON);

                    // �y�[�W����
                    inSession.setPage(0);
                    setPage(inSession);
                    setDisplayList(inSession);
                } else {
                    // �������ʂ��Ȃ��ꍇ
                    inSession.setShiyoKaijoSrcListFlg(BmaConstants.FLG_OFF);
                }

                return FWD_NM_RELOAD;

            } else if (!BmaUtility.isNullOrEmpty(inRequest.getShiyoKaijoDetail())) {
                /*�u�ڍׁv�{�^��������*/
                processName = "MstKanriShiyoKaijoSearch";
                log.Start(processName);

                /**
                 * ��L�[�̊e�R�[�h���擾
                 *
                 */
                ShiyoKaijo shiyoKaijo = new ShiyoKaijo(DATA_SOURCE_NAME);
                KaijoTantoMst tanto = new KaijoTantoMst(DATA_SOURCE_NAME);
                SknksuMst skm = new SknksuMst(DATA_SOURCE_NAME);

                //�ڍ׃{�^���̒l�`�F�b�N
                if (inRequest.getShiyoKaijoDetail().length() < 18 && inRequest.getShiyoKaijoDetail().length() > 18) {
                    Messages errors = new Messages();
                    BmaValidator.addMessage(errors, "shiyoKaijoDetail", BmaText.E00013, "�I�������l");
                    inSession.setErrors(errors);
                    return FWD_NM_RELOAD;
                }

                String nendo = inRequest.getShiyoKaijoDetail().substring(0, 4);
                String sknKsuCode = inRequest.getShiyoKaijoDetail().substring(4, 6);
                String shubetsuCode = inRequest.getShiyoKaijoDetail().substring(6, 8);
                String kaisuCode = inRequest.getShiyoKaijoDetail().substring(8, 10);
                String kaijoId = inRequest.getShiyoKaijoDetail().substring(10, 12);
                String kaijoShikenKbn = inRequest.getShiyoKaijoDetail().substring(12, 13);
                String kaisaichiCode = inRequest.getShiyoKaijoDetail().substring(13, 15);
                String kaijoCode = inRequest.getShiyoKaijoDetail().substring(15, 18);

                /**
                 * �ڍ׃f�[�^���擾���A�Z�b�V�����ɕێ�
                 */
                String kaisaichiCodeKaijoMst = "";
                KaijoTantoMst kaijoTantoResult = new KaijoTantoMst();
                ShiyoKaijo shiyoKaijoResult = shiyoKaijo.lockNoWait(nendo, sknKsuCode, shubetsuCode, kaisuCode, kaijoId, kaijoShikenKbn, kaisaichiCode, kaijoCode);
                if (!(shiyoKaijoResult == null)) {
                    if (!BmaUtility.isNullOrEmpty(shiyoKaijoResult.getKaisaichiCodeKaijoMst())) {
                        kaisaichiCodeKaijoMst = shiyoKaijoResult.getKaisaichiCodeKaijoMst();
                        kaijoTantoResult = tanto.lockNoWait(kaisaichiCodeKaijoMst, kaijoCode, shiyoKaijoResult.getTantoshaCode());
                    } else {
                        kaijoTantoResult = tanto.lockNoWait(kaisaichiCode, kaijoCode, shiyoKaijoResult.getTantoshaCode());
                    }
                } else {
                    Messages errors = new Messages();
                    BmaValidator.addMessage(errors, "shiyoKaijoDetail", BmaText.E00013, "�I�������l");
                    inSession.setErrors(errors);
                    return FWD_NM_RELOAD;
                }

                SknksuMst sknKsuMst = skm.lockNoWait(sknKsuCode, shubetsuCode, kaisuCode);
                saveShiyoKaijoSession(shiyoKaijoResult, inSession);

                /**
                 * �\���p�̃f�[�^�𐮌`���āA�Z�b�V�����ɕێ�
                 */
                MstKanriShiyoKaijoJoho kaijoForName = createShiyoKaijoDetail(shiyoKaijoResult, inSession.getKaisaichiCodeList());

                inSession.setKaisaichiName(kaijoForName.getKaisaichiName());
                inSession.setSknKsuName(sknKsuMst.getSknKsuNameNosbt());
                inSession.setShubetsuName(sknKsuMst.getShubetsuName());
                inSession.setKaisuName(sknKsuMst.getKaisuName());
                inSession.setKaijoShikenName(kaijoForName.getKaijoShikenName());
                inSession.setFromYear(kaijoForName.getFromYear());
                inSession.setFromMonth(kaijoForName.getFromMonth());
                inSession.setFromDate(kaijoForName.getFromDate());
                inSession.setFromYobi(kaijoForName.getFromYobi());
                inSession.setToYear(kaijoForName.getToYear());
                inSession.setToMonth(kaijoForName.getToMonth());
                inSession.setToDate(kaijoForName.getToDate());
                inSession.setToYobi(kaijoForName.getToYobi());

                inSession.setTantosha(kaijoTantoResult.getTantosha());
                inSession.setTantoBusho(kaijoTantoResult.getTantoBusho());
                inSession.setTelNo(kaijoTantoResult.getTelNo());
                inSession.setFaxNo(kaijoTantoResult.getFaxNo());
                inSession.setTantoshaMailAddress(kaijoTantoResult.getTantoshaMailAddress());

                // �߂�J�ڗp�̉�ꎎ���敪��ێ�
                inSession.setDbKaijoShikenKbn(kaijoShikenKbn);
                inSession.setDbKaijoCode(kaijoCode);

                /* �u�g�p���ڍׁv��ʕ\�� */
                return "detail";

            } else if (!BmaUtility.isNullOrEmpty(inRequest.getKaijoIdReNo())) {
                /*�u���ID�ĕt�ԁv�{�^��������*/
                processName = "MstKanriShiyoKaijoSearch";
                log.Start(processName);

                ShiyoKaijo shiyoKaijo = new ShiyoKaijo(DATA_SOURCE_NAME);
                ShiyoKaijo shiyoKaijoRem = new ShiyoKaijo(DATA_SOURCE_NAME);
                inSession.setShiyoKaijoSearchResultList(new ArrayList<MstKanriShiyoKaijoJoho>());

                String nendo = inSession.getNendo();
                String sknKsuCode = inSession.getSknKsuCode();
                String shubetsuCode = inSession.getShubetsuCode();
                String kaisuCode = inSession.getKaisuCode();

                // �V�X�e�������擾
                SystemTime sysTime = new SystemTime();

                List<ShiyoKaijo> shiyoKaijoList = shiyoKaijo.searchShiyoKaijoListForKaijoId(nendo, sknKsuCode, shubetsuCode, kaisuCode);

                int intKaijoId = 0;
                String strKaijoId;
                try {
                    /* �g�����U�N�V�����擾&�J�n */
                    getTransaction();
                    beginTransaction();
                    for (ShiyoKaijo shiyoKaijoDel : shiyoKaijoList) {
                        BeanUtils.copyProperties(shiyoKaijoRem, shiyoKaijoDel);
//                    
//                        shiyoKaijoDel.setNendo(inSession.getNendoBefore());
//                        shiyoKaijoDel.setSknKsuCode(shiyoKaijo.getSknKsuCode());
//                        shiyoKaijoDel.setShubetsuCode(shiyoKaijo.getShubetsuCode());
//                        shiyoKaijoDel.setKaisuCode(shiyoKaijo.getKaisuCode());
//                        shiyoKaijoDel.setKaijoId(shiyoKaijo.getKaijoId());
//                        shiyoKaijoDel.setKaijoShikenKbn(shiyoKaijo.getKaijoShikenKbn());
//                        shiyoKaijoDel.setKaisaichiCode(shiyoKaijo.getKaisaichiCode());
//                        shiyoKaijoDel.setKaijoCode(shiyoKaijo.getKaijoCode());

                        shiyoKaijoRem.remove();
                    }

                    for (int i = 0; i < shiyoKaijoList.size(); i++) {
                        ShiyoKaijo shiyo = shiyoKaijoList.get(i);
                        BeanUtils.copyProperties(shiyoKaijo, shiyo);

//                    String oldKaijoId = shiyo.getKaijoId();
                        // ���ID
                        intKaijoId = intKaijoId + 1;
                        strKaijoId = String.valueOf(intKaijoId);
                        if (strKaijoId.length() < 2) {
                            strKaijoId = String.format("%2s", strKaijoId).replace(' ', '0');
                        }
                        shiyoKaijo.setKaijoId(strKaijoId);

                        // �g�p���Update
                        shiyoKaijo.setKoshinKbn(BmaConstants.SHORI_KBN_UPDATE);
                        shiyoKaijo.setKoshinDate(sysTime.getymd1());
                        shiyoKaijo.setKoshinTime(sysTime.gethms1());
                        shiyoKaijo.setKoshinUserId(inRequest.getMoshikomishaId());
                        shiyoKaijo.create();

                        // �\���p���X�g�ɒǉ�
                        MstKanriShiyoKaijoJoho shiyoJoho = createShiyoKaijoDetail(shiyoKaijo, inSession.getKaisaichiCodeList());
                        saveShiyoKaijoSession(shiyoKaijo, shiyoJoho);
                        inSession.getShiyoKaijoSearchResultList().add(shiyoJoho);
                    }
                    setDisplayList(inSession);

                } catch (Exception ex) {
                    ex.printStackTrace();
                    // ���[���o�b�N
                    rollbackTransaction();
                    return FWD_NM_SESSION;
                }

                /* �u�g�p��ꌟ���E�ꗗ�v��ʕ\�� */
                return FWD_NM_RELOAD;

            } else if (!BmaUtility.isNullOrEmpty(inRequest.getShiyoKaijoUpdateInp())) {
                /*�u�ύX�v�{�^��������*/
                processName = "MstKanriShiyoKaijoDetail_ShiyoKaijoUpdInput";
                log.Start(processName);

                /* �ϐ������� */
                String sknKsuCode = "";
                String shubetsuCode = "";
                String kaisuCode = "";

                // ���I��ێ�
                inSession.setShiyoKaijoSelect(inRequest.getShiyoKaijoSelect());
                // �I��l�`�F�b�N
                if (!validateInput(inSession)) {
                    // �G���[���������ꍇ�u�g�p���ꗗ�v���Reload
                    return FWD_NM_RELOAD;
                }
                if (!validateInputUpd(inSession)) {
                    // �G���[���������ꍇ�u�g�p���ꗗ�v���Reload
                    return FWD_NM_RELOAD;
                }
                //���W�I�{�^���̒l�`�F�b�N
//                if (inRequest.getShiyoKaijoSelect()[0].length() < 18 && inRequest.getShiyoKaijoSelect()[0].length() > 18) {
//                    Messages errors = new Messages();
//                    BmaValidator.addMessage(errors, "shiyoKaijoUpdateInp", BmaText.E00013, "�I�������l");
//                    inSession.setErrors(errors);
//                    return FWD_NM_RELOAD;
//                }

                // �I�����������u�K��ɍ��킹�āA�e�R�[�h���Z�b�V�����ɕێ�
                if (BmaConstants.SKN_KBN.equals(inSession.getSknksuKbn())) {
                    sknKsuCode = inSession.getSknName().substring(0, 2);
                    shubetsuCode = inSession.getSknName().substring(2, 4);
                    kaisuCode = inSession.getSknName().substring(4, 6);
                } else if (BmaConstants.KSU_KBN.equals(inSession.getSknksuKbn())) {
                    sknKsuCode = inSession.getKsuName().substring(0, 2);
                    shubetsuCode = inSession.getKsuName().substring(2, 4);
                    kaisuCode = inSession.getKsuName().substring(4, 6);
                }
                inSession.setSknKsuCode(sknKsuCode);
                inSession.setShubetsuCode(shubetsuCode);
                inSession.setKaisuCode(kaisuCode);

                /* �����u�K��@���̎擾 */
                SknksuMst sknksuMst = new SknksuMst(BmaConstants.DS_REGISTRANT);
                inSession.setSknksuNameRyaku(sknksuMst.findSknKsuNameRyaku(sknKsuCode, shubetsuCode, kaisuCode).getSknKsuNameRyaku());

                ShiyoKaijo shiyoKaijo = new ShiyoKaijo(DATA_SOURCE_NAME);
                KaijoTantoMst tanto = new KaijoTantoMst(DATA_SOURCE_NAME);

                MstKanriShiyoKaijoJoho shiyoKaijoEle;
                List<MstKanriShiyoKaijoJoho> shiyoKaijoList = new ArrayList<>();
                List<Option> tantoshaList = new ArrayList<Option>();
                String nendo = "";
                String kaijoId = "";
                String kaijoShikenKbn = "";
                String kaisaichiCode = "";
                String kaijoCode = "";

                for (int i = 0; i < inSession.getShiyoKaijoSelect().length; ++i) {
                    shiyoKaijoEle = new MstKanriShiyoKaijoJoho();
                    nendo = inSession.getShiyoKaijoSelect()[i].substring(0, 4);
                    kaijoId = inSession.getShiyoKaijoSelect()[i].substring(10, 12);
                    kaijoShikenKbn = inSession.getShiyoKaijoSelect()[i].substring(12, 13);
                    kaisaichiCode = inSession.getShiyoKaijoSelect()[i].substring(13, 15);
                    kaijoCode = inSession.getShiyoKaijoSelect()[i].substring(15, 18);

                    ShiyoKaijo shiyoKaijoResult = shiyoKaijo.lockNoWait(nendo, sknKsuCode, shubetsuCode, kaisuCode, kaijoId, kaijoShikenKbn, kaisaichiCode, kaijoCode);
                    // �\���p�Ƀf�[�^���H
                    saveShiyoKaijoSession(shiyoKaijoResult, shiyoKaijoEle);

                    /* �J�Òn�����ƂɁA��ꃊ�X�g���쐬 */
                    KaijoMst kaijoList = new KaijoMst(DATA_SOURCE_NAME);
                    List<Option> kaijoByKaisaichiList = new ArrayList<Option>();
                    List<Option> kaijoByTantoshaList = new ArrayList<Option>();
                    String kaisaichi = kaisaichiCode;
                    String kaijo = kaijoCode;

                    // �\�������ւ̏ꍇ
                    if ("10".equals(kaisaichi)) {
                        String[] kaisaichies = {"03", "04"};
                        kaijoList.findByKaisaichies(kaisaichies, kaijoByKaisaichiList);
                        shiyoKaijoEle.setTokanKaijoCode(shiyoKaijoResult.getKaisaichiCodeKaijoMst() + shiyoKaijoResult.getKaijoCode());
                        tanto.findByOneTantosha(shiyoKaijoResult.getKaisaichiCodeKaijoMst(), kaijoCode, kaijoByTantoshaList);
                    } else {
                        kaijoList.findByOneKaisaichi(kaisaichi, kaijoByKaisaichiList);
                        tanto.findByOneTantosha(kaisaichiCode, kaijoCode, kaijoByTantoshaList);
                    }

                    shiyoKaijoEle.setKaijoByKaisaichiList(kaijoByKaisaichiList);
                    shiyoKaijoEle.setKaijoByTantoshaList(kaijoByTantoshaList);

                    //��ꖼ�A�����̕\��
                    MstKanriShiyoKaijoJoho kaijoForName = createShiyoKaijoDetail(shiyoKaijoResult, inSession.getKaisaichiCodeList());

                    shiyoKaijoEle.setKaisaichiName(kaijoForName.getKaisaichiName());
                    shiyoKaijoEle.setKaijoCode(kaijo);
                    shiyoKaijoEle.setKaijoShikenName(kaijoForName.getKaijoShikenName());
                    shiyoKaijoEle.setFromYear(kaijoForName.getFromYear());
                    shiyoKaijoEle.setFromMonth(kaijoForName.getFromMonth());
                    shiyoKaijoEle.setFromDate(kaijoForName.getFromDate());
                    shiyoKaijoEle.setFromYobi(kaijoForName.getFromYobi());
                    shiyoKaijoEle.setToYear(kaijoForName.getToYear());
                    shiyoKaijoEle.setToMonth(kaijoForName.getToMonth());
                    shiyoKaijoEle.setToDate(kaijoForName.getToDate());
                    shiyoKaijoEle.setToYobi(kaijoForName.getToYobi());
                    inSession.setTeiin(kaijoForName.getTeiin());

                    shiyoKaijoEle.setTantoshaList(tantoshaList);

                    // �X�V�p�̌��f�[�^��ꎎ���敪�E���R�[�h��ێ�
                    shiyoKaijoEle.setDbKaijoShikenKbn(kaijoShikenKbn);
                    shiyoKaijoEle.setDbKaijoCode(kaijoCode);
                    shiyoKaijoList.add(shiyoKaijoEle);
                }
                inSession.setKaijoList(shiyoKaijoList);

                /* �u�g�p���ύX���́v��ʕ\�� */
                return "update";

            } else if (!BmaUtility.isNullOrEmpty(inRequest.getDelete())) {
                /*�u�폜�v�{�^��������*/
                processName = "MstKanriShiyoKaijoSearch";
                log.Start(processName);

                // ���I��ێ�
                ShiyoKaijo shiyoKaijoDel = new ShiyoKaijo(DATA_SOURCE_NAME);

                String nendo = "";
                String sknKsuCode = "";
                String shubetsuCode = "";
                String kaisuCode = "";
                String kaijoId = "";
                String kaijoShikenKbn = "";
                String kaisaichiCode = "";
                String kaijoCode = "";

                inSession.setShiyoKaijoSelect(inRequest.getShiyoKaijoSelect());
                // �I��l�`�F�b�N
                if (!validateInput(inSession)) {
                    // �G���[���������ꍇ�u�g�p���ꗗ�v���Reload
                    return FWD_NM_RELOAD;
                }
                if (!validateInputDel(inSession)) {
                    // �G���[���������ꍇ�u�g�p���ꗗ�v���Reload
                    return FWD_NM_RELOAD;
                }
                //���W�I�{�^���̒l�`�F�b�N
//                if (inRequest.getShiyoKaijoSelect()[0].length() < 18 && inRequest.getShiyoKaijoSelect()[0].length() > 18) {
//                    Messages errors = new Messages();
//                    BmaValidator.addMessage(errors, "shiyoKaijoUpdateInp", BmaText.E00013, "�I�������l");
//                    inSession.setErrors(errors);
//                    return FWD_NM_RELOAD;
//                }

                for (int i = 0; i < inSession.getShiyoKaijoSelect().length; ++i) {
                    nendo = inSession.getShiyoKaijoSelect()[i].substring(0, 4);
                    sknKsuCode = inSession.getShiyoKaijoSelect()[i].substring(4, 6);
                    shubetsuCode = inSession.getShiyoKaijoSelect()[i].substring(6, 8);
                    kaisuCode = inSession.getShiyoKaijoSelect()[i].substring(8, 10);
                    kaijoId = inSession.getShiyoKaijoSelect()[i].substring(10, 12);
                    kaijoShikenKbn = inSession.getShiyoKaijoSelect()[i].substring(12, 13);
                    kaisaichiCode = inSession.getShiyoKaijoSelect()[i].substring(13, 15);
                    kaijoCode = inSession.getShiyoKaijoSelect()[i].substring(15, 18);

                    shiyoKaijoDel.setNendo(nendo);
                    shiyoKaijoDel.setSknKsuCode(sknKsuCode);
                    shiyoKaijoDel.setShubetsuCode(shubetsuCode);
                    shiyoKaijoDel.setKaisuCode(kaisuCode);
                    shiyoKaijoDel.setKaijoId(kaijoId);
                    shiyoKaijoDel.setKaijoShikenKbn(kaijoShikenKbn);
                    shiyoKaijoDel.setKaisaichiCode(kaisaichiCode);
                    shiyoKaijoDel.setKaijoCode(kaijoCode);

                    shiyoKaijoDel.remove();
                }

                String[] kaisaichiCodes = inRequest.getKaisaichiSelect();

                // �J�Òn��I�����Ă��Ȃ��ꍇ�A�S�J�Òn���擾
                if (kaisaichiCodes == null) {
                    List<Option> kaisaichiCodeList = inSession.getKaisaichiCodeList();
                    kaisaichiCodes = new String[kaisaichiCodeList.size()];

                    int j = 0;
                    for (Option kaisaichi : kaisaichiCodeList) {
                        kaisaichiCodes[j] = kaisaichi.getValue();
                        ++j;
                    }
                }
                inSession.setKaisaichiSelect(kaisaichiCodes);

                List<ShiyoKaijo> shiyoKaijoSearchList = shiyoKaijoDel.findByKaisaichi(sknKsuCode, shubetsuCode, kaisuCode, kaisaichiCodes);

                if (!shiyoKaijoSearchList.isEmpty()) {
                    List<MstKanriShiyoKaijoJoho> shiyoKaijoSearchResultList = new ArrayList<>();
                    for (ShiyoKaijo element : shiyoKaijoSearchList) {
                        MstKanriShiyoKaijoJoho shiyoKaijoDetail = createShiyoKaijoDetail(element, inSession.getKaisaichiCodeList());
                        saveShiyoKaijoSession(element, shiyoKaijoDetail);
                        setNitteiDisp(element, shiyoKaijoDetail);
                        shiyoKaijoSearchResultList.add(shiyoKaijoDetail);
                    }
                    inSession.setShiyoKaijoSearchResultList(shiyoKaijoSearchResultList);
                    inSession.setShiyoKaijoSrcListFlg(BmaConstants.FLG_ON);

                    // �y�[�W����
                    inSession.setPage(0);
                    setPage(inSession);
                    setDisplayList(inSession);
                }

                /* �u�g�p��ꌟ���E�ꗗ�v��ʕ\�� */
                return FWD_NM_RELOAD;

            } else if (!BmaUtility.isNullOrEmpty(inRequest.getBack())) {
                /*�u�߂�v�{�^��������*/
                processName = "MstKanriShiyoKaijoSearch";
                log.Start(processName);

                /* �u�g�p��ꌟ���E�ꗗ�v��ʕ\�� */
                return FWD_NM_BACK;

            } else {
                /*�ُ�J��*/
                log.IllegalFWD();
                return FWD_NM_SESSION;
            }
        } catch (Exception e) {
            return FWD_NM_EXCEPTION;
        } finally {
            log.End(processName);
        }
    }

    /**
     * �J�Òn���X�g�̍쐬
     *
     * @param inSession �Z�b�V�������
     */
    private List<Option> createKaisaichiCodeList() {
        List<Option> list = new ArrayList<>();
        //���̃��X�g��p�ӂ���
        MeishoKanri meishoKanri = new MeishoKanri(BmaConstants.DS_REGISTRANT);
        meishoKanri.findByGroupCode(BmaConstants.MEISHO_KANRI_GROUP_KAISAICHI_CODE, list);
        return list;
    }

    /**
     * �����u�K���X�g���擾����
     *
     * @param sknksuKbn
     * @return
     */
    public List<Option> findSknKsuList(String sknksuKbn) {
        List<Option> list = new ArrayList<>();
        //�����u�K���X�g��p�ӂ���
        SknksuMst sknksuMst = new SknksuMst(BmaConstants.DS_REGISTRANT);
        sknksuMst.findBySknKsuKbn(sknksuKbn, list);
        return list;
    }

    /**
     * �ꗗ�\���p�ɐ��`����
     *
     * @param kaijoMst ��������
     * @return �������ʕ\���p
     */
    private MstKanriShiyoKaijoJoho createShiyoKaijoDetail(ShiyoKaijo shiyoKaijo, List<Option> kaisaichiCodeList) {
        String teiinBfr = "";
        String teiinAft = "";
        String detailCodes = "";
        String kaijoShikenKbnName = "";
        String kaijoShikenName = "";

        MstKanriShiyoKaijoJoho shiyoKaijoDetail = new MstKanriShiyoKaijoJoho();

        /**
         * ����̐��`
         */
        teiinBfr = shiyoKaijo.getTeiin();
        teiinAft = teiinBfr.replaceFirst("^0+", "");
        if (teiinAft.isEmpty()) {
            teiinAft = "0";
        } else if (teiinAft.length() > 3) {
            teiinAft = teiinAft.substring(0, teiinAft.length() - 3)
                    + ","
                    + teiinAft.substring(teiinAft.length() - 3);
        }
        shiyoKaijoDetail.setTeiinDisp(teiinAft);

        /* ��ꎎ���敪���́i���́j���Z�b�g */
        if (BmaConstants.KAIJO_SHIKEN_KBN_NASHI.equals(shiyoKaijo.getKaijoShikenKbn())) {
            kaijoShikenKbnName = "-";
        } else if (BmaConstants.KAIJO_SHIKEN_KBN_GAKKA.equals(shiyoKaijo.getKaijoShikenKbn())) {
            kaijoShikenKbnName = "�w��";
        } else if (BmaConstants.KAIJO_SHIKEN_KBN_ZITSUGI.equals(shiyoKaijo.getKaijoShikenKbn())) {
            kaijoShikenKbnName = "���Z";
        }
        shiyoKaijoDetail.setKaijoShikenKbnName(kaijoShikenKbnName);

        /* ��ꎎ���敪���̂��Z�b�g */
        if (BmaConstants.KAIJO_SHIKEN_KBN_NASHI.equals(shiyoKaijo.getKaijoShikenKbn())) {
            kaijoShikenName = "�敪���g�p���Ȃ�";
        } else if (BmaConstants.KAIJO_SHIKEN_KBN_GAKKA.equals(shiyoKaijo.getKaijoShikenKbn())) {
            kaijoShikenName = "�w�Ȏ����y�ю��Z�y�[�p�[�e�X�g";
        } else if (BmaConstants.KAIJO_SHIKEN_KBN_ZITSUGI.equals(shiyoKaijo.getKaijoShikenKbn())) {
            kaijoShikenName = "���Z��Ǝ���";
        }
        shiyoKaijoDetail.setKaijoShikenName(kaijoShikenName);

        // �ڍ׃{�^���p
        detailCodes = shiyoKaijo.getNendo()
                + shiyoKaijo.getSknKsuCode()
                + shiyoKaijo.getShubetsuCode()
                + shiyoKaijo.getKaisuCode()
                + shiyoKaijo.getKaijoId()
                + shiyoKaijo.getKaijoShikenKbn()
                + shiyoKaijo.getKaisaichiCode()
                + shiyoKaijo.getKaijoCode();
        shiyoKaijoDetail.setShiyoKaijoDetail(detailCodes);

        for (Option kaisaichi : kaisaichiCodeList) {
            if (kaisaichi.getValue().equals(shiyoKaijo.getKaisaichiCode())) {
                /**
                 * �J�Òn���̂��Z�b�g
                 */
                shiyoKaijoDetail.setKaisaichiName(kaisaichi.getLabel());
                break;
            }
        }

        shiyoKaijoDetail.setFromYear(shiyoKaijo.getNitteiFrom().substring(0, 4));
        shiyoKaijoDetail.setFromMonth(shiyoKaijo.getNitteiFrom().substring(4, 6));
        shiyoKaijoDetail.setFromDate(shiyoKaijo.getNitteiFrom().substring(6, 8));
        shiyoKaijoDetail.setFromYobi(dateToWeek(shiyoKaijo.getNitteiFrom()));

        shiyoKaijoDetail.setToYear(shiyoKaijo.getNitteiTo().substring(0, 4));
        shiyoKaijoDetail.setToMonth(shiyoKaijo.getNitteiTo().substring(4, 6));
        shiyoKaijoDetail.setToDate(shiyoKaijo.getNitteiTo().substring(6, 8));
        shiyoKaijoDetail.setToYobi(dateToWeek(shiyoKaijo.getNitteiTo()));

        return shiyoKaijoDetail;
    }

    private void setNitteiDisp(ShiyoKaijo nittei, MstKanriShiyoKaijoJoho nitteiDisp) {

        nitteiDisp.setFromYear(nittei.getNitteiFrom().substring(0, 4));
        nitteiDisp.setFromMonth(nittei.getNitteiFrom().substring(4, 6));
        nitteiDisp.setFromDate(nittei.getNitteiFrom().substring(6, 8));
        nitteiDisp.setFromYobi(dateToWeek(nittei.getNitteiFrom()));

        nitteiDisp.setToYear(nittei.getNitteiTo().substring(0, 4));
        nitteiDisp.setToMonth(nittei.getNitteiTo().substring(4, 6));
        nitteiDisp.setToDate(nittei.getNitteiTo().substring(6, 8));
        nitteiDisp.setToYobi(dateToWeek(nittei.getNitteiTo()));

    }

    /**
     * ���t�ɂ���ėj�����擾����
     *
     * @param datetime�@���t
     * @return �j��
     */
    public static String dateToWeek(String datetime) {

        SimpleDateFormat f = new SimpleDateFormat("yyyyMMdd");
        String[] weekDays = {"��", "��", "��", "��", "��", "��", "�y"};
        Calendar cal = Calendar.getInstance();
        Date date;
        try {
            date = f.parse(datetime);
            cal.setTime(date);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        //the day number of a week
        int w = cal.get(Calendar.DAY_OF_WEEK) - 1;
        if (w < 0) {
            w = 0;
        }
        return weekDays[w];
    }

    /**
     * �W���f�[�^��MstKanriShiyoKaijoJoho�ɕێ�
     *
     * @param shiyoKaijo ���f�[�^
     * @param saveObject �ۑ���
     */
    private void saveShiyoKaijoSession(ShiyoKaijo shiyoKaijo, MstKanriShiyoKaijoJoho saveObject) {
        saveObject.setNendo(shiyoKaijo.getNendo());
        saveObject.setSknKsuCode(shiyoKaijo.getSknKsuCode());
        saveObject.setShubetsuCode(shiyoKaijo.getShubetsuCode());
        saveObject.setKaisuCode(shiyoKaijo.getKaisuCode());
        saveObject.setKaijoId(shiyoKaijo.getKaijoId());
        saveObject.setKaijoShikenKbn(shiyoKaijo.getKaijoShikenKbn());
        saveObject.setKaisaichiCode(shiyoKaijo.getKaisaichiCode());
        saveObject.setKaijoCode(shiyoKaijo.getKaijoCode());
        saveObject.setKaijoName(shiyoKaijo.getKaijoName());
        saveObject.setKaijoNameRyaku(shiyoKaijo.getKaijoNameRyaku());
        saveObject.setYubinNo(shiyoKaijo.getYubinNo());
        saveObject.setJusho(shiyoKaijo.getJusho());
        saveObject.setTantoshaCode(shiyoKaijo.getTantoshaCode());
        saveObject.setNitteiFrom(shiyoKaijo.getNitteiFrom());
        saveObject.setNitteiTo(shiyoKaijo.getNitteiTo());
        saveObject.setTeiin(shiyoKaijo.getTeiin());
        saveObject.setGenzaiNinzu(shiyoKaijo.getGenzaiNinzu());
        saveObject.setBikoKaijo(shiyoKaijo.getBikoKaijo());
        saveObject.setBikoTanto(shiyoKaijo.getBikoTanto());
        saveObject.setBikoKaijoDisp(shiyoKaijo.getBikoKaijo().replaceAll("\n", "<br>"));
        saveObject.setBikoTantoDisp(shiyoKaijo.getBikoTanto().replaceAll("\n", "<br>"));
    }

    /**
     * �w��y�[�W���ɍ��킹�āA�\������S���҃��X�g���쐬
     *
     * @param inSession�@�Z�b�V�������X�g
     */
    private void setDisplayList(MstKanriShiyoKaijoJoho inSession) {
        /* �ϐ������� */
        List<MstKanriShiyoKaijoJoho> displayList = new ArrayList<MstKanriShiyoKaijoJoho>();
        MstKanriShiyoKaijoJoho shiyoKaijo;

        List<MstKanriShiyoKaijoJoho> resultList = inSession.getShiyoKaijoSearchResultList();
        /* �y�[�W���ɍ��킹�ĕ\���p���X�g�쐬 */
        for (int i = inSession.getFirstDisp() - 1; i < inSession.getMaxDisp(); ++i) {
            shiyoKaijo = resultList.get(i);
            displayList.add(shiyoKaijo);
        }
        inSession.setShiyoKaijoDisplayList(displayList);
    }

    /**
     * �y�[�W����
     *
     * @param inSession�@�Z�b�V�������X�g
     */
    private void setPage(MstKanriShiyoKaijoJoho inSession) {
        /* �ϐ������� */
        int idx;
        int max;
        int maxLenDisp = inSession.getShiyoKaijoSearchResultList().size();
        int pageMax;

        /* ��ʂɕ\������ő匏�����擾 */
        int page = inSession.getPage();
        idx = page * BmaConstants.MAX_PAGE_NUM_SHIYOKAIJO_SEARCH;

        max = idx + BmaConstants.MAX_PAGE_NUM_SHIYOKAIJO_SEARCH;
        inSession.setFirstDisp(idx + 1);

        /* �������ʂ̌��� */
        if (maxLenDisp < max) {
            inSession.setMaxDisp(maxLenDisp);
        } else {
            /* �ő匏����茟�����ʂ������ꍇ */
            inSession.setMaxDisp(max);
        }

        /* �y�[�W�ԍ��̍ő���v�Z */
        pageMax = (int) (Math.ceil((double) maxLenDisp / (double) (BmaConstants.MAX_PAGE_NUM_SHIYOKAIJO_SEARCH)));
        inSession.setPageMax(pageMax + 1);

        /* �y�[�W�ԍ��ݒ� */
        int now = 0;
        now = inSession.getPage();

        /* �Œጏ�� */
        if (now == 0) {
            inSession.setPageBegin(now + 1);
        } else if (now == 1) {
            inSession.setPageBegin(now);
        } else if (now == 2) {
            inSession.setPageBegin(now - 1);
        } else {
            inSession.setPageBegin(now - 2);
        }
        /* �ő匏�����\������ő匏����3�{�ȉ��������ꍇ�̕\���p�y�[�W�ԍ� */
        if (now == pageMax) {
            inSession.setPageEnd(now + 1);
        } else if (now == pageMax - 1) {
            inSession.setPageEnd(now + 2);
        } else if (now == pageMax - 2) {
            inSession.setPageEnd(now + 3);
        } else {
            inSession.setPageEnd(now + 4);
        }
        inSession.setPage(now + 1);
    }

    /**
     * ���̓`�F�b�N
     *
     * @param inSession �Z�b�V����RTO
     * @return true:�G���[��
     */
    private boolean validateInput(MstKanriShiyoKaijoJoho inSession) {
        /* �ϐ������� */
        Messages errors = new Messages();
        String groupCode;
        String itemName;

        // �G���[�`�F�b�N�p���X�g�쐬
        String[] sknKsuKbns = {BmaConstants.SKN_KBN, BmaConstants.KSU_KBN};

        /* �����u�K��敪 */
        groupCode = "sknksuKbn";
        itemName = "�����u�K��敪";
        BmaValidator.validateSelect(inSession.getSknksuKbn(), errors, groupCode, itemName);
        BmaValidator.validatePermissionSelect(inSession.getSknksuKbn(), sknKsuKbns, errors, groupCode, itemName);

        /* �����u�K�� */
        groupCode = "sknKsuCode";
        itemName = "�����^�u�K�";
        if (BmaConstants.SKN_KBN.equals(inSession.getSknksuKbn())) {
            BmaValidator.validateSelect(inSession.getSknName(), errors, groupCode, itemName);
            BmaValidator.validatePermissionSelect(inSession.getSknName(), inSession.getSknKbnList(), errors, groupCode, itemName);
        } else if (BmaConstants.KSU_KBN.equals(inSession.getSknksuKbn())) {
            BmaValidator.validateSelect(inSession.getKsuName(), errors, groupCode, itemName);
            BmaValidator.validatePermissionSelect(inSession.getKsuName(), inSession.getKsuKbnList(), errors, groupCode, itemName);
        }

        /* �J�Òn�R�[�h */
        if (inSession.getKaisaichiSelect() != null) {
            groupCode = "kaisaichiCode";
            itemName = "�J�Òn�R�[�h";
            for (String element : inSession.getKaisaichiSelect()) {
                BmaValidator.validatePermissionSelect(element, inSession.getKaisaichiCodeList(), errors, groupCode, itemName);
                if (!errors.isEmpty()) {
                    break;
                }
            }
        }

        inSession.setErrors(errors);
        return errors.isEmpty();
    }

    /**
     * �I���`�F�b�N�i�ύX�j
     *
     * @param inSession �Z�b�V����RTO
     * @return true:�G���[��
     */
    private boolean validateInputUpd(MstKanriShiyoKaijoJoho inSession) {
        /* �ϐ������� */
        Messages errors = new Messages();
        String groupCode;
        String itemName;

        // �G���[�`�F�b�N�p���X�g�쐬
//        String[] sknKsuKbns = {BmaConstants.SKN_KBN, BmaConstants.KSU_KBN};
        List<Option> kaijoIdList = new ArrayList<Option>();
        for (MstKanriShiyoKaijoJoho shiyoKaijo : inSession.getShiyoKaijoSearchResultList()) {
            kaijoIdList.add(new Option(shiyoKaijo.getKaijoId(), shiyoKaijo.getKaijoId()));
        }

        /* �J�Òn�R�[�h */
        groupCode = "kaisaichiCode";
        itemName = "�ύX������";
        String kaijoId;

        if (inSession.getShiyoKaijoSelect() == null) {
            BmaValidator.addMessage(errors, groupCode, BmaText.E00003, itemName);
        } else {

            for (String element : inSession.getShiyoKaijoSelect()) {
                if (17 < element.length() && element.length() < 19) {
                    kaijoId = element.substring(10, 12);
                    BmaValidator.validatePermissionSelect(kaijoId, kaijoIdList, errors, groupCode, itemName);
                    if (!errors.isEmpty()) {
                        break;
                    }
                } else {
                    BmaValidator.addMessage(errors, groupCode, BmaText.E00013, itemName);
                    break;
                }
            }
        }
        inSession.setErrors(errors);
        return errors.isEmpty();
    }

    /**
     * �I���`�F�b�N�i�폜)
     *
     * @param inSession �Z�b�V����RTO
     * @return true:�G���[��
     */
    private boolean validateInputDel(MstKanriShiyoKaijoJoho inSession) {
        /* �ϐ������� */
        Messages errors = new Messages();
        String groupCode;
        String itemName;

        // �G���[�`�F�b�N�p���X�g�쐬
//        String[] sknKsuKbns = {BmaConstants.SKN_KBN, BmaConstants.KSU_KBN};
        List<Option> kaijoIdList = new ArrayList<Option>();
        for (MstKanriShiyoKaijoJoho shiyoKaijo : inSession.getShiyoKaijoSearchResultList()) {
            kaijoIdList.add(new Option(shiyoKaijo.getKaijoId(), shiyoKaijo.getKaijoId()));
        }

        /* �J�Òn�R�[�h */
        groupCode = "kaisaichiCode";
        itemName = "�폜������";
        String kaijoId;

        if (inSession.getShiyoKaijoSelect() == null) {
            BmaValidator.addMessage(errors, groupCode, BmaText.E00003, itemName);
        } else {

            for (String element : inSession.getShiyoKaijoSelect()) {
                if (17 < element.length() && element.length() < 19) {
                    kaijoId = element.substring(10, 12);
                    BmaValidator.validatePermissionSelect(kaijoId, kaijoIdList, errors, groupCode, itemName);
                    if (!errors.isEmpty()) {
                        break;
                    }
                } else {
                    BmaValidator.addMessage(errors, groupCode, BmaText.E00013, itemName);
                    break;
                }
            }
        }
        inSession.setErrors(errors);
        return errors.isEmpty();
    }
}
