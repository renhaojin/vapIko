package jp.co.nii.bma.integration;


import jp.co.nii.bma.business.domain.SknksuMstDao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import jp.co.nii.bma.business.domain.SknksuMst;
import jp.co.nii.sew.common.LogGenerate;
import jp.co.nii.sew.integration.SQLStateSQLExceptionTranslater;
import jp.co.nii.sew.presentation.Option;

/**
 * �����u�K��}�X�^ DAO�����N���X
 * @author DB�Ǘ��c�[��
 */
public class SknksuMstDaoImpl extends GeneratedSknksuMstDaoImpl implements SknksuMstDao {

    /**
     * �C���X�^���X�𐶐�����B
     * @param datasource �f�[�^�\�[�X��
     */
    public SknksuMstDaoImpl(String datasource) {
        super(datasource);
    }
    /**
     * �����u�K���烊�X�g�ƃ}�b�v���擾����
     *
     * @param sknksuKbn
     * @param list
     * @param map
     */
    @Override
    public void findBySknKsuKbn(String sknksuKbn, List<Option> list, Map<String, String> map) {

        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql;
        ArrayList<String> paramList = new ArrayList<String>();

        try {
            con = getConnection();
            sql = "SELECT SKN_KSU_CODE || SHUBETSU_CODE || KAISU_CODE AS SKN_KSU_SENTAKU_CODE,"
                    + " SKN_KSU_NAME_RYAKU AS SKN_KSU_NAME"
                    + " FROM " + getSchemaName() + "." + TABLE_NAME
                    + " WHERE"
                    + " SKN_KSU_KBN = ?"
                    + " AND HYOJI_FLG = '1'"
                    + " AND RONRI_SAKUJO_FLG = '0'"
                    + " ORDER BY to_number(HYOJI_JUNJO,'999')";

            paramList.add(sknksuKbn);
            stmt = con.prepareStatement(sql);

            int i = 1;
            for (String param : paramList) {
                stmt.setString(i++, param);
            }
            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();

            while (rs.next()) {
                if (list != null) {
                    list.add(new Option(rs.getString("SKN_KSU_SENTAKU_CODE"), rs.getString("SKN_KSU_NAME")));
                }
                if (map != null) {
                    map.put(rs.getString("SKN_KSU_SENTAKU_CODE"), rs.getString("SKN_KSU_NAME"));
                }
            }

        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
    }
    
    /**
     * �����u�K�R�[�h�A��ʃR�[�h�A�񐔃R�[�h���玎���u�K���̂��擾����
     *
     * @param bo
     * @return
     */
    @Override
    public SknksuMst findSknKsuNameRyaku(SknksuMst bo) {

        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql;
        ArrayList<String> paramList = new ArrayList<String>();

        try {
            con = getConnection();
            sql = "SELECT SKN_KSU_NAME_RYAKU AS SKN_KSU_NAME"
                    + " FROM " + getSchemaName() + "." + TABLE_NAME
                    + " WHERE"
                    + " SKN_KSU_CODE = ?"
                    + " AND SHUBETSU_CODE = ?"
                    + " AND KAISU_CODE = ?"
                    + " AND RONRI_SAKUJO_FLG = '0'";

            paramList.add(bo.getSknKsuCode());
            paramList.add(bo.getShubetsuCode());
            paramList.add(bo.getKaisuCode());
            stmt = con.prepareStatement(sql);

            int i = 1;
            for (String param : paramList) {
                stmt.setString(i++, param);
            }
            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();

            if (rs.next()) {
                bo.setSknKsuNameRyaku(rs.getString("SKN_KSU_NAME"));;
            }

        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return bo;
    }
}
