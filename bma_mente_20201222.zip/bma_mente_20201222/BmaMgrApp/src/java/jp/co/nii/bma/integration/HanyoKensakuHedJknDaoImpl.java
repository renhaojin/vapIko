package jp.co.nii.bma.integration;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import jp.co.nii.bma.business.domain.HanyoKensakuHedJknDao;
import jp.co.nii.sew.common.LogGenerate;
import jp.co.nii.sew.integration.SQLStateSQLExceptionTranslater;
import jp.co.nii.sew.presentation.Option;

/**
 * �ėp�����w�b�__���� DAO�����N���X
 *
 * @author DB�Ǘ��c�[��
 */
public class HanyoKensakuHedJknDaoImpl extends GeneratedHanyoKensakuHedJknDaoImpl implements HanyoKensakuHedJknDao {

    /**
     * �C���X�^���X�𐶐�����B
     *
     * @param datasource �f�[�^�\�[�X��
     */
    public HanyoKensakuHedJknDaoImpl(String datasource) {
        super(datasource);
    }

    @Override
    public void findHanyoListSearch(List<Option> list) {

        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = "";

        String limit = "";

        limit = " LIMIT " + "100";
        try {
            con = getConnection();
            sql = "SELECT " + FIELDS_DECRYPT
                    + " FROM " + getSchemaName() + "." + TABLE_NAME
                    + " WHERE " + " RONRI_SAKUJO_FLG = '0'"
                    + " ORDER BY hanyo_kensaku_id_jkn ASC "
                    + limit;

            stmt = con.prepareStatement(sql);

            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();

            while (rs.next()) {
                if (list != null) {
                    list.add(new Option(rs.getString("hanyo_kensaku_id_jkn"), rs.getString("hanyo_kensaku_name")));
                }

            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
    }
}
