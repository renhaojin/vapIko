//package jp.co.nii.bma.business.service.manager;
//
//import java.io.BufferedWriter;
//import java.io.ByteArrayInputStream;
//import java.io.ByteArrayOutputStream;
//import java.io.IOException;
//import java.io.InputStream;
//import java.io.OutputStreamWriter;
//import java.net.URLEncoder;
//import java.text.ParseException;
//import java.text.SimpleDateFormat;
//import java.util.ArrayList;
//import java.util.Arrays;
//import java.util.Calendar;
//import java.util.Collections;
//import java.util.Date;
//import java.util.Iterator;
//import java.util.List;
//import java.util.Locale;
//import jp.co.nii.bma.business.domain.Kaijo;
//import jp.co.nii.bma.business.domain.MeishoKanri;
//import jp.co.nii.bma.business.domain.MenuControl;
//import jp.co.nii.bma.business.domain.Moshikomi;
//import jp.co.nii.bma.business.rto.manager.MgrMskJokyoJoho;
//import jp.co.nii.bma.business.service.common.BmaConstants;
//import jp.co.nii.bma.business.service.common.BmaLogger;
//import jp.co.nii.bma.business.service.common.BmaValidator;
//import jp.co.nii.bma.presentation.common.BmaText;
//import jp.co.nii.bma.presentation.moshikomi.KaijoOption;
//import jp.co.nii.bma.utility.BmaUtility;
//import jp.co.nii.sew.business.SystemTime;
//import jp.co.nii.sew.business.service.AbstractService;
//import jp.co.nii.sew.presentation.Option;
//import jp.co.nii.sew.presentation.RequestTransferObject;
//import jp.co.nii.sew.utility.DateUtility;
//import jp.co.nii.sew.utility.PropertyUtility;
//import jp.co.nii.sew.utility.StringUtility;
//import org.apache.commons.beanutils.BeanUtils;
//
///**
// * <p>�^�C�g��: �\���󋵃��X�g�T�[�r�X</p> <p>����: �\�����ݏ󋵃��X�g�T�[�r�X</p> <p>���쌠:Copyright (c)
// * 2016</p> <p>��Ж�: ���{���Y�Ɗ������</p>
// */
//public class MgrMskJokyoListService extends AbstractService {
//
//    /**
//     * DB�ڑ��̃f�[�^�\�[�X
//     */
//    private static String DATA_SOURCE_NAME;
//    /**
//     * ���O
//     */
//    BmaLogger log = (BmaLogger) BmaLogger.getLogger(this.getClass().getName());
//    /**
//     * �Ɩ��R�[�h
//     */
//    private static final String BUSINESS_CODE = PropertyUtility.getProperty("business_code");
//    /**
//     * ���׃e�X�g���[�h
//     */
//    private static final String STRESS_MODE = PropertyUtility.getProperty(BUSINESS_CODE + "stress_mode");
//    /**
//     * ���ڂ̋�؂蕶��
//     */
//    static String KANMA = ",";
//
//    /**
//     * �R���X�g���N�^
//     */
//    public MgrMskJokyoListService() {
//        super();
//        /* DB�ڑ����̃��[�U�[������ */
//        DATA_SOURCE_NAME = BmaConstants.DS_REGISTRANT;
//    }
//
//    /**
//     * �T�[�r�X�N���X�̎��s���\�b�h
//     *
//     * @param rto ���N�G�X�g��񂩂�擾����rto
//     * @param rtoInSession �Z�b�V�������rto
//     * @return foward��
//     * @throws Exception ��O
//     */
//    @Override
//    public String doService(RequestTransferObject rto, RequestTransferObject rtoInSession) throws Exception {
//
//        MgrMskJokyoJoho MgrMskJokyoJohoInRequest = (MgrMskJokyoJoho) rto;
//        MgrMskJokyoJoho MgrMskJokyoJohoInSession = (MgrMskJokyoJoho) rtoInSession;
//
//        String processName = "";
//        try {            
//            if (!BmaUtility.isNullOrEmpty(MgrMskJokyoJohoInRequest.getCommandMoshikomijokyokubun())
//                    && (MgrMskJokyoJohoInRequest.getCommandMoshikomijokyokubun().equals(BmaConstants.MOSHIKOMIJOKYOHYOJI_TODOFUKEN_GAKKA)
//                    || MgrMskJokyoJohoInRequest.getCommandMoshikomijokyokubun().equals(BmaConstants.MOSHIKOMIJOKYOHYOJI_TODOFUKEN_SEKKEI))) {
//                processName = "MgrMskJokyoListTodofuken";
//                log.Start(processName);
//
//                copyToSession(MgrMskJokyoJohoInSession, MgrMskJokyoJohoInRequest);
//                MgrMskJokyoJohoInSession.setShutsuryokuTaishosha(MgrMskJokyoJohoInRequest.getShutsuryokuTaishosha());
//                MgrMskJokyoJohoInSession.setShukeiHouhou(MgrMskJokyoJohoInRequest.getCommandMoshikomijokyokubun());
//
//                /* �s���{�����X�g�擾 */
//                List<Option> todofukenList = new ArrayList<Option>();
//                MeishoKanri meisho = new MeishoKanri(DATA_SOURCE_NAME);
//                meisho.findByGroupCode(BmaConstants.NEN, BmaConstants.MEISHO_KANRI_GROUP_CODE_TODOFUKE, todofukenList);
//                Iterator ite = todofukenList.iterator();
//                while (ite.hasNext()) {
//                    if (BmaConstants.TODOFUKE_CODE_GAIKOKU.equals(((Option) ite.next()).getValue())) {
//                        ite.remove();
//                        break;
//                    }
//                }
//                MgrMskJokyoJohoInSession.setTodofukenList(todofukenList);
//
//                //���j���[�R���g���[�����擾
//                MenuControl menuControlBo = getMenuControl(MgrMskJokyoJohoInSession);
//
//                //���t���X�g��ێ�
//                List<Date> dateList = setMohikomiKikan(MgrMskJokyoJohoInSession, menuControlBo.getKaishiDate(), menuControlBo.getShuryoDate());
//
//                //�\���󋵂��擾
//                List<MgrMskJokyoJoho> mskJokyoList = getMoshikomiJokyo(MgrMskJokyoJohoInSession, menuControlBo);
//
//                //�\���������X�g�֊i�[����
//                setTodofukenCount(MgrMskJokyoJohoInSession, todofukenList, dateList, mskJokyoList);
//
//                return FWD_NM_SUCCESS;
//
//            } else if (!BmaUtility.isNullOrEmpty(MgrMskJokyoJohoInRequest.getCommandMoshikomijokyokubun())
//                    && (MgrMskJokyoJohoInRequest.getCommandMoshikomijokyokubun().equals(BmaConstants.MOSHIKOMIJOKYOHYOJI_KAIJO_GAKKA)
//                    || MgrMskJokyoJohoInRequest.getCommandMoshikomijokyokubun().equals(BmaConstants.MOSHIKOMIJOKYOHYOJI_KAIJO_SEKKEI))) {
//                processName = "MgrMskJokyoListShikenkaijo";
//                log.Start(processName);
//
//                copyToSession(MgrMskJokyoJohoInSession, MgrMskJokyoJohoInRequest);
//                MgrMskJokyoJohoInSession.setShutsuryokuTaishosha(MgrMskJokyoJohoInRequest.getShutsuryokuTaishosha());
//                MgrMskJokyoJohoInSession.setShukeiHouhou(MgrMskJokyoJohoInRequest.getCommandMoshikomijokyokubun());
//
//                /* ��ꃊ�X�g���擾 */
//                Kaijo kaijoBo = new Kaijo(DATA_SOURCE_NAME);
//                List<KaijoOption> kaijoList = kaijoBo.findKaijoJoho(BmaConstants.NEN, MgrMskJokyoJohoInRequest.getShikenShuruiCode(),
//                        MgrMskJokyoJohoInRequest.getCommandMoshikomijokyokubun().equals(BmaConstants.MOSHIKOMIJOKYOHYOJI_KAIJO_GAKKA)
//                        ? BmaConstants.SHIKEN_KBN_CODE_GAKKA : BmaConstants.SHIKEN_KBN_CODE_SEIZU);
//
//                //���j���[�R���g���[�����擾
//                MenuControl menuControlBo = getMenuControl(MgrMskJokyoJohoInSession);
//
//                //���t���X�g��ێ�
//                List<Date> dateList = setMohikomiKikan(MgrMskJokyoJohoInSession, menuControlBo.getKaishiDate(), menuControlBo.getShuryoDate());
//
//                //�\���󋵂��擾
//                List<MgrMskJokyoJoho> mskJokyoList = getMoshikomiJokyo(MgrMskJokyoJohoInSession, menuControlBo);
//
//                //�\���������X�g�֊i�[����
//                setShikenkaijoCount(MgrMskJokyoJohoInSession, kaijoList, dateList, mskJokyoList);
//
//                return FWD_NM_SUCCESS + "2";
//
//            } else if (!BmaUtility.isNullOrEmpty(MgrMskJokyoJohoInRequest.getCommandBack())) {
//                //���������֖߂�
//                processName = "back";
//                log.Start(processName);
//
//                return FWD_NM_BACK;
//
//            } else if (!BmaUtility.isNullOrEmpty(MgrMskJokyoJohoInRequest.getCommandCsv())) {
//                //CSV�_�E�����[�h
//                processName = "CSVDownload";
//                log.Start(processName);
//
//                if (MgrMskJokyoJohoInSession.getCount().equals("0")) {
//                    //�W�v���ʂ��O���̏ꍇ
//                    //�G���[���b�Z�[�W���Z�b�g
//                    BmaValidator.addMessage(MgrMskJokyoJohoInSession.getErrors(), "nodata", BmaText.E00037);
//
//                    if (MgrMskJokyoJohoInSession.getShukeiHouhou().equals(BmaConstants.MOSHIKOMIJOKYOHYOJI_TODOFUKEN_GAKKA)
//                            || MgrMskJokyoJohoInSession.getShukeiHouhou().equals(BmaConstants.MOSHIKOMIJOKYOHYOJI_TODOFUKEN_SEKKEI)) {
//                        return FWD_NM_RELOAD;
//                    } else {
//                        return FWD_NM_RELOAD + "2";
//                    }
//                }
//
//                String ret = createCsv(MgrMskJokyoJohoInRequest, MgrMskJokyoJohoInSession);
//
//                return ret;
//
//            } else {
//                /*�ُ�J��*/
//                log.IllegalFWD();
//                return FWD_NM_EXCEPTION;
//            }
//        } catch (Exception ex) {
//            log.error(processName + " �ŗ�O���������܂����B", ex);
//            return FWD_NM_EXCEPTION;
//        } finally {
//            if (!BmaUtility.isNullOrEmpty(processName)) {
//                log.End(processName);
//            }
//        }
//    }
//
//    /**
//     * �t�H�[���̓��e���Z�b�V�����p�I�u�W�F�N�g�ɃR�s�[����B
//     *
//     * @param MgrMskJokyoJohoInSession
//     * @param MgrMskJokyoJohoInRequest
//     */
//    private void copyToSession(MgrMskJokyoJoho MgrMskJokyoJohoInSession, MgrMskJokyoJoho MgrMskJokyoJohoInRequest) throws Exception {
//
//        //�㏑�����ꂽ���Ȃ�����ޔ�
//        MgrMskJokyoJoho tmp = new MgrMskJokyoJoho();
//        BeanUtils.copyProperties(tmp, MgrMskJokyoJohoInSession);
//
//        //�Z�b�V�����pRTO �� ���N�G�X�g�̓��e�ŏ㏑��
//        BeanUtils.copyProperties(MgrMskJokyoJohoInSession, MgrMskJokyoJohoInRequest);
//
//        //�ޔ�������񂩂�K�v�ȏ��𕜌�
//        MgrMskJokyoJohoInSession.setShikenShuruiCode(tmp.getShikenShuruiCode());
//        MgrMskJokyoJohoInSession.setShukeiHouhou(tmp.getShukeiHouhou());
//        MgrMskJokyoJohoInSession.setShukeiHaneiDate(tmp.getShukeiHaneiDate());
//        MgrMskJokyoJohoInSession.setMgrMskJokyoJohoList(tmp.getMgrMskJokyoJohoList());
//        MgrMskJokyoJohoInSession.setMoshikomiKikan(tmp.getMoshikomiKikan());
//        MgrMskJokyoJohoInSession.setCount(tmp.getCount());
//        MgrMskJokyoJohoInSession.setShutsuryokuTaishosha(tmp.getShutsuryokuTaishosha());
//
//    }
//
//    /**
//     * ���j���[�R���g���[�����擾����
//     *
//     * @param MgrMskJokyoJohoInSession
//     * @return menuControlBo
//     */
//    private MenuControl getMenuControl(MgrMskJokyoJoho MgrMskJokyoJohoInSession) {
//
//        //�I��������ʂɑΉ������C�x���g�R�[�h���擾
//        String eventCode = "";
//        if (MgrMskJokyoJohoInSession.getShikenShuruiCode().equals(BmaConstants.SHIKEN_SHURUI_CODE_IKKYU)) {
//            eventCode = BmaConstants.EVENT_CODE_IKKYU_SHIKEN;
//        } else if (MgrMskJokyoJohoInSession.getShikenShuruiCode().equals(BmaConstants.SHIKEN_SHURUI_CODE_NIKYU)) {
//            eventCode = BmaConstants.EVENT_CODE_NIKYU_SHIKEN;
//        } else if (MgrMskJokyoJohoInSession.getShikenShuruiCode().equals(BmaConstants.SHIKEN_SHURUI_CODE_MOKUZO)) {
//            eventCode = BmaConstants.EVENT_CODE_MOKUZO_SHIKEN;
//        }
//
//        //�\�����Ԃ��擾
//        MenuControl menuControlBo = new MenuControl(DATA_SOURCE_NAME);
//        menuControlBo = menuControlBo.find(BmaConstants.NEN, eventCode, BmaConstants.MENU_CODE_WEB_MOSHIKOMI);
//
//        return menuControlBo;
//
//    }
//
//    /**
//     * ���ԏ����Z�b�g����
//     *
//     * @param MgrMskJokyoJohoInSession
//     * @param kaishiDate
//     * @param shuryoDate
//     * @return dateList
//     */
//    private List<Date> setMohikomiKikan(MgrMskJokyoJoho MgrMskJokyoJohoInSession, String kaishiDate, String shuryoDate) throws Exception {
//
//        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
//        Date fromDate = sdf.parse(kaishiDate);
//        Date toDate = sdf.parse(shuryoDate);
//        Date calDate = sdf.parse(kaishiDate);
//        String yobi = "";
//        Calendar cal = Calendar.getInstance();
//        List<String> kikanList = new ArrayList<String>();
//        List<Date> dateList = new ArrayList<Date>();
//
//        while (isRangeDate(fromDate, toDate, calDate)) {
//            //������ݒ�
//            cal.setTime(calDate);
//            //�j�����擾
//            yobi = DateUtility.getYobiJP(calDate);
//            //���t�����X�g�֒ǉ�
//            kikanList.add(new SimpleDateFormat("d").format((calDate)) + "(" + yobi + ")");
//            //�v�Z�p���X�g
//            dateList.add(calDate);
//            // 1�������Z
//            cal.add(Calendar.DATE, 1);
//            calDate = cal.getTime();
//        }
//
//        //�\����t���Ԃ��Z�b�g
//        MgrMskJokyoJohoInSession.setMoshikomiKikan(kikanList);
//
//        return dateList;
//    }
//
//    /**
//     * �w�肵�����t���A�w�肵�����ԓ����ǂ������`�F�b�N���� ���ԓ��ł����true,�����łȂ����false��Ԃ�
//     *
//     * @param fromDate
//     * @param toDate
//     * @param mskDate
//     * @return boolean
//     * @throws ParseException
//     */
//    private boolean isRangeDate(final Date fromDate, final Date toDate, Date mskDate) throws ParseException {
//
//        // ����������Calender�^��
//        Calendar calFrom = Calendar.getInstance();
//        Calendar calTo = Calendar.getInstance();
//        Calendar calMskDate = Calendar.getInstance();
//        calFrom.setTime(fromDate);
//        calTo.setTime(toDate);
//        calMskDate.setTime(mskDate);
//
//        // �������r
//        int retFrom = calFrom.compareTo(calMskDate);
//        int retTo = calTo.compareTo(calMskDate);
//
//        // �\���o�^���t���w����ԓ��łȂ�������G���[
//        if (retFrom > 0 || retTo < 0) {
//            return false;
//        } else {
//            return true;
//        }
//    }
//
//    /**
//     * �\���󋵂��擾����
//     *
//     * @param MgrMskJokyoJohoInSession
//     * @param menuControlBo
//     * @return mskJokyoList
//     * @throws ParseException
//     */
//    private List<MgrMskJokyoJoho> getMoshikomiJokyo(MgrMskJokyoJoho MgrMskJokyoJohoInSession, MenuControl menuControlBo) throws ParseException {
//        Moshikomi moshikomiBo = new Moshikomi(DATA_SOURCE_NAME);
//        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
//        SimpleDateFormat sdfSlash = new SimpleDateFormat("yyyy/MM/dd");
//        String kaishiDate = menuControlBo.getKaishiDate();
//        List<MgrMskJokyoJoho> mskJokyoList = new ArrayList<MgrMskJokyoJoho>();
//        String shikenKbnCode = "";
//
//        //�\�����Ԓ��͌��ݓ��t�̑O����\���I�����t�Ƃ���
//        String shuryoDate = isRangeDate(sdf.parse(menuControlBo.getKaishiDate()), sdf.parse(menuControlBo.getShuryoDate()),
//                sdfSlash.parse(MgrMskJokyoJohoInSession.getShukeiHaneiDate())) ? MgrMskJokyoJohoInSession.getShukeiHaneiDate().replaceAll("/", "") : menuControlBo.getShuryoDate();
//
//        //�I�������W�v���@�̎����敪�R�[�h���Z�b�g
//        if (MgrMskJokyoJohoInSession.getCommandMoshikomijokyokubun().equals(BmaConstants.MOSHIKOMIJOKYOHYOJI_TODOFUKEN_GAKKA)
//                || MgrMskJokyoJohoInSession.getCommandMoshikomijokyokubun().equals(BmaConstants.MOSHIKOMIJOKYOHYOJI_KAIJO_GAKKA)) {
//            shikenKbnCode = BmaConstants.SHIKEN_KBN_CODE_GAKKA;
//
//        } else if (MgrMskJokyoJohoInSession.getCommandMoshikomijokyokubun().equals(BmaConstants.MOSHIKOMIJOKYOHYOJI_TODOFUKEN_SEKKEI)
//                || MgrMskJokyoJohoInSession.getCommandMoshikomijokyokubun().equals(BmaConstants.MOSHIKOMIJOKYOHYOJI_KAIJO_SEKKEI)) {
//            shikenKbnCode = BmaConstants.SHIKEN_KBN_CODE_SEIZU;
//        }
//
//
//        if (MgrMskJokyoJohoInSession.getCommandMoshikomijokyokubun().equals(BmaConstants.MOSHIKOMIJOKYOHYOJI_TODOFUKEN_GAKKA)
//                || MgrMskJokyoJohoInSession.getCommandMoshikomijokyokubun().equals(BmaConstants.MOSHIKOMIJOKYOHYOJI_TODOFUKEN_SEKKEI)) {
//            //�s���{����
//            mskJokyoList = moshikomiBo.findMoshikomiJokyoByTodofuken(
//                    MgrMskJokyoJohoInSession.getShikenShuruiCode(), shikenKbnCode, kaishiDate, shuryoDate, MgrMskJokyoJohoInSession);
//        } else if (MgrMskJokyoJohoInSession.getCommandMoshikomijokyokubun().equals(BmaConstants.MOSHIKOMIJOKYOHYOJI_KAIJO_GAKKA)
//                || MgrMskJokyoJohoInSession.getCommandMoshikomijokyokubun().equals(BmaConstants.MOSHIKOMIJOKYOHYOJI_KAIJO_SEKKEI)) {
//            //��������
//            mskJokyoList = moshikomiBo.findMoshikomiJokyoByShikenkaijo(
//                    MgrMskJokyoJohoInSession.getShikenShuruiCode(), shikenKbnCode, kaishiDate, shuryoDate, MgrMskJokyoJohoInSession);
//        }
//
//        return mskJokyoList;
//
//    }
//
//    /**
//     * �s���{���ʁA���t���Ƃ̐\���������X�g���쐬
//     *
//     * @param MgrMskJokyoJohoInSession
//     * @param todofukenList
//     * @param dateList
//     * @param mskJokyoList
//     */
//    private void setTodofukenCount(MgrMskJokyoJoho MgrMskJokyoJohoInSession, List<Option> todofukenList, List<Date> dateList, List<MgrMskJokyoJoho> mskJokyoList) throws ParseException {
//
//        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
//        List<MgrMskJokyoJoho> list = new ArrayList<MgrMskJokyoJoho>();
//        MgrMskJokyoJoho tmp = new MgrMskJokyoJoho();
//        int total_all = 0;
//        int[] total_date_i = new int[dateList.size()];
//        String[] total_date = new String[dateList.size()];
//        for(int i = 0; i<dateList.size(); i++) {
//            total_date_i[i] =0;
//        }
//        
//        for (Option todofuken : todofukenList) {
//            MgrMskJokyoJoho bean = new MgrMskJokyoJoho();
//            List<String> emptyList = Arrays.asList(new String[dateList.size()]);
//            Collections.fill(emptyList, "");
//
//            int total = 0;
//
//            for (MgrMskJokyoJoho mskJoho : mskJokyoList) {
//                int i = 0;
//                for (Date date : dateList) {
//                    //�s���{���R�[�h�Ɠ��t�������ꍇ�������i�[
//                    if (todofuken.getValue().equals(mskJoho.getTodofukenCode()) && date.equals(sdf.parse(mskJoho.getMoshikomiTorokuDate()))) {
//                        emptyList.set(i, mskJoho.getCount());
//                        //���v�l���J�E���g�A�b�v
//                        total += Integer.parseInt(mskJoho.getCount());
//                        total_date_i[i] += Integer.parseInt(mskJoho.getCount());
//                    }
//                    i++;
//                }
//            }
//            //�S���v�ɃJ�E���g�A�b�v
//            total_all += total;
//            //�s���{�������Z�b�g
//            bean.setTodofukenName(todofuken.getLabel());
//            //���v�l���Z�b�g
//            bean.setTotal(total == 0 ? "" : Integer.toString(total));
//            //�������X�g���Z�b�g
//            bean.setCountList(emptyList);
//            list.add(bean);
//        }
//        //���v�l���Z�b�g
//        for(int i = 0; i<dateList.size(); i++) {
//            total_date[i] = total_date_i[i] == 0 ? "" : Integer.toString(total_date_i[i]);
//        }
//        tmp.setCountList(Arrays.asList(total_date));
//        tmp.setTotal(total_all == 0 ? "" : Integer.toString(total_all));
//        tmp.setTodofukenName("���v");
//        //���X�g�ɃZ�b�g
//        list.add(tmp);
//        //�W�v���ʂ��Z�b�g
//        MgrMskJokyoJohoInSession.setMgrMskJokyoJohoList(list);
//        //�������Z�b�g
//        MgrMskJokyoJohoInSession.setCount(Integer.toString(mskJokyoList.size()));
//
//    }
//
//    /**
//     * �������ʁA���t���Ƃ̐\���������X�g���쐬
//     *
//     * @param MgrMskJokyoJohoInSession
//     * @param kaijoList
//     * @param dateList
//     * @param mskJokyoList
//     */
//    private void setShikenkaijoCount(MgrMskJokyoJoho MgrMskJokyoJohoInSession, List<KaijoOption> kaijoList, List<Date> dateList, List<MgrMskJokyoJoho> mskJokyoList) throws ParseException {
//
//        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
//        List<MgrMskJokyoJoho> list = new ArrayList<MgrMskJokyoJoho>();
//        MgrMskJokyoJoho tmp = new MgrMskJokyoJoho();
//        int total_all = 0;
//        int[] total_date_i = new int[dateList.size()];
//        String[] total_date = new String[dateList.size()];
//        for(int i = 0; i<dateList.size(); i++) {
//            total_date_i[i] =0;
//        }       
//        for (KaijoOption kaijo : kaijoList) {
//            MgrMskJokyoJoho bean = new MgrMskJokyoJoho();
//            List<String> emptyList = Arrays.asList(new String[dateList.size()]);
//            Collections.fill(emptyList, "");
//            int total = 0;
//
//            for (MgrMskJokyoJoho mskJoho : mskJokyoList) {
//                int i = 0;
//                for (Date date : dateList) {
//                    //�s���{���R�[�h�Ɠ��t�������ꍇ�������i�[
//                    if (kaijo.getValue().equals(mskJoho.getKaijoCode()) && date.equals(sdf.parse(mskJoho.getMoshikomiTorokuDate()))) {
//                        emptyList.set(i, mskJoho.getCount());
//                        //���v�l���J�E���g�A�b�v
//                        total += Integer.parseInt(mskJoho.getCount());
//                        total_date_i[i] += Integer.parseInt(mskJoho.getCount());
//                    }
//                    i++;
//                }
//            }
//            //�S���v�ɃJ�E���g�A�b�v
//            total_all += total;
//            //�s���{�������Z�b�g
//            bean.setTodofukenName(kaijo.getLabel());
//            //������ꖼ���Z�b�g
//            bean.setShikenKaijoName(kaijo.getLabel2());
//
//            //���v�l���Z�b�g
//            bean.setTotal(total == 0 ? "" : Integer.toString(total));
//            bean.setCountList(emptyList);
//            list.add(bean);
//        }
//
//        //���v�l���Z�b�g
//        for(int i = 0; i<dateList.size(); i++) {
//            total_date[i] = total_date_i[i] == 0 ? "" : Integer.toString(total_date_i[i]);
//        }
//        tmp.setCountList(Arrays.asList(total_date));
//        tmp.setTotal(total_all == 0 ? "" : Integer.toString(total_all));
//        tmp.setTodofukenName("���v");
//        //���X�g�ɃZ�b�g
//        list.add(tmp);
//        //�W�v���ʂ��Z�b�g
//        MgrMskJokyoJohoInSession.setMgrMskJokyoJohoList(list);
//        //�������Z�b�g
//        MgrMskJokyoJohoInSession.setCount(Integer.toString(mskJokyoList.size()));
//
//    }
//
//    /**
//     * CSV�o��
//     *
//     * @param MgrMskJokyoJohoInRequest
//     * @param MgrMskJokyoJohoInSession
//     * @return foward��
//     */
//    private String createCsv(MgrMskJokyoJoho MgrMskJokyoJohoInRequest, MgrMskJokyoJoho MgrMskJokyoJohoInSession) throws IOException {
//
//        String shikenKbnName = "";
//        boolean isShikenkaijo = false;
//        String shikenShuruiName = "";
//        if(BmaConstants.SHIKEN_SHURUI_CODE_IKKYU.equals(MgrMskJokyoJohoInSession.getShikenShuruiCode())){
//            shikenShuruiName = "�i�ꋉ�j";
//        }else if(BmaConstants.SHIKEN_SHURUI_CODE_NIKYU.equals(MgrMskJokyoJohoInSession.getShikenShuruiCode())){
//            shikenShuruiName = "�i�񋉁j";
//        }else if(BmaConstants.SHIKEN_SHURUI_CODE_MOKUZO.equals(MgrMskJokyoJohoInSession.getShikenShuruiCode())){    
//            shikenShuruiName = "�i�ؑ��j";
//        }
//
//        if (MgrMskJokyoJohoInSession.getShukeiHouhou().equals(BmaConstants.MOSHIKOMIJOKYOHYOJI_TODOFUKEN_GAKKA)) {
//            shikenKbnName = "�y�w�ȁz�s���{���ʐ\���󋵕\��";
//            isShikenkaijo = false;
//        } else if (MgrMskJokyoJohoInSession.getShukeiHouhou().equals(BmaConstants.MOSHIKOMIJOKYOHYOJI_TODOFUKEN_SEKKEI)) {
//            shikenKbnName = "�y�݌v�z�s���{���ʐ\���󋵕\��";
//            isShikenkaijo = false;
//        } else if (MgrMskJokyoJohoInSession.getShukeiHouhou().equals(BmaConstants.MOSHIKOMIJOKYOHYOJI_KAIJO_GAKKA)) {
//            shikenKbnName = "�y�w�ȁz�������ʐ\���󋵕\��";
//            isShikenkaijo = true;
//        } else if (MgrMskJokyoJohoInSession.getShukeiHouhou().equals(BmaConstants.MOSHIKOMIJOKYOHYOJI_KAIJO_SEKKEI)) {
//            shikenKbnName = "�y�݌v�z�������ʐ\���󋵕\��";
//            isShikenkaijo = true;
//        }
//
//        String fileName = shikenKbnName + shikenShuruiName + (new SystemTime()).getymd1() + "_" + (new SystemTime()).gethms1() + ".csv";
//
//        // �w�b�_�[����
//        MgrMskJokyoJohoInRequest.setHeader("Content-Disposition", String.format(Locale.JAPAN, "attachment; filename*=utf-8'jp'%s", URLEncoder.encode(fileName, "utf-8")));
//        MgrMskJokyoJohoInRequest.setContentType("application/octet-stream;charset=" + BmaConstants.ENCODE_SHIFT_JIS);
//
//        // �X�g���[������
//        BufferedWriter bw = null;
//        ByteArrayOutputStream outputStream = null;
//        try {
//            outputStream = new ByteArrayOutputStream();
//            bw = new BufferedWriter(new OutputStreamWriter(outputStream, BmaConstants.ENCODE_SHIFT_JIS));
//
//            // �o�͏���
//            writeCSV(MgrMskJokyoJohoInSession, bw, isShikenkaijo);
//
//        } catch (Exception e) {
//            log.error("CSV�o�͏����ŃG���[���������܂����B", e);
//            return FWD_NM_EXCEPTION;
//
//        } finally {
//            if (bw != null) {
//                bw.close();
//            }
//        }
//
//        InputStream io = new ByteArrayInputStream(outputStream.toByteArray());
//        MgrMskJokyoJohoInRequest.setInputStream(io);
//        MgrMskJokyoJohoInRequest.setHeader("Content-Type", "charset=" + BmaConstants.ENCODE_SHIFT_JIS);
//        MgrMskJokyoJohoInRequest.setContentType("text/csv; charset=" + BmaConstants.ENCODE_SHIFT_JIS);
//
//        return DOWNLOAD;
//
//    }
//
//    /**
//     * CSV�f�[�^����������
//     *
//     * @param MgrMskJokyoJohoInRequest
//     * @param bw
//     * @param isShikenkaijo
//     * @throws Exception
//     */
//    private void writeCSV(MgrMskJokyoJoho MgrMskJokyoJohoInRequest, BufferedWriter bw, boolean isShikenkaijo) throws Exception {
//
//        try {
//            //�w�b�_�[
//            bw.write("�s���{��");
//            if (isShikenkaijo) {
//                bw.write(KANMA + "������ꖼ");
//            }
//            bw.write(KANMA + "�v");
//            for (String kikan : MgrMskJokyoJohoInRequest.getMoshikomiKikan()) {
//                bw.write(KANMA + kikan);
//            }
//
//            //���s
//            bw.write(StringUtility.NEW_LINE);
//
//            //�P�s�����o��
//            bw.flush();
//
//            for (MgrMskJokyoJoho list : MgrMskJokyoJohoInRequest.getMgrMskJokyoJohoList()) {
//                bw.write(list.getTodofukenName());
//                //���ʂ̏ꍇ�A��ꖼ�������o��
//                if (isShikenkaijo) {
//                    bw.write(KANMA + list.getShikenKaijoName());
//                }
//                bw.write(KANMA + list.getTotal());
//                for (String count : list.getCountList()) {
//                    bw.write(KANMA + count);
//                }
//                //���s
//                bw.write(StringUtility.NEW_LINE);
//            }
//
//            //��������
//            bw.flush();
//
//        } catch (Exception ioe) {
//            throw ioe;
//        }
//    }
//}
