package jp.co.nii.bma.business.service.manager;

import java.util.ArrayList;
import java.util.List;
import jp.co.nii.bma.business.domain.KaijoMst;
import jp.co.nii.bma.business.domain.KaijoTantoMst;
import jp.co.nii.bma.business.domain.MeishoKanri;
import jp.co.nii.bma.business.domain.ShiyoKaijo;
import jp.co.nii.bma.business.domain.SknksuMst;
import jp.co.nii.bma.business.rto.manager.MstKanriScheduleJoho;
import jp.co.nii.bma.business.rto.manager.MstKanriShiyoKaijoJoho;
import jp.co.nii.bma.business.service.common.BmaConstants;
import jp.co.nii.bma.business.service.common.BmaLogger;
import jp.co.nii.bma.business.service.common.BmaValidator;
import jp.co.nii.bma.presentation.common.BmaText;
import jp.co.nii.bma.utility.BmaUtility;
import jp.co.nii.sew.business.service.AbstractService;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_EXCEPTION;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_BACK;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_SESSION;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_SUCCESS;
import jp.co.nii.sew.presentation.Messages;
import jp.co.nii.sew.presentation.Option;
import jp.co.nii.sew.presentation.RequestTransferObject;
import jp.co.nii.sew.utility.PropertyUtility;
import org.apache.commons.beanutils.BeanUtils;

/**
 *
 * @author nii19049
 */
public class MstKanriShiyoKaijoAddService extends AbstractService {

    /**
     * DB�ڑ��̃f�[�^�\�[�X
     */
    private static String DATA_SOURCE_NAME;
    /**
     * ���O
     */
    BmaLogger log = (BmaLogger) BmaLogger.getLogger(this.getClass().getName());
    /**
     * �Ɩ��R�[�h
     */
    private static final String BUSINESS_CODE = PropertyUtility.getProperty("business_code");
    /**
     * ���׃e�X�g���[�h
     */
    private static final String STRESS_MODE = PropertyUtility.getProperty(BUSINESS_CODE + "stress_mode");

    /**
     * �R���X�g���N�^
     */
    public MstKanriShiyoKaijoAddService() {
        super();
        /* DB�ڑ����̃��[�U�[������ */
        DATA_SOURCE_NAME = BmaConstants.DS_REGISTRANT;
    }

    /**
     * �T�[�r�X�N���X�̎��s���\�b�h
     *
     * @param rto ���N�G�X�g��񂩂�擾����rto
     * @param rtoInSession �Z�b�V�������rto
     * @return foward��
     * @throws Exception ��O
     */
    @Override
    public String doService(RequestTransferObject rto, RequestTransferObject rtoInSession)
            throws Exception {

        MstKanriShiyoKaijoJoho inRequest = (MstKanriShiyoKaijoJoho) rto;
        MstKanriShiyoKaijoJoho inSession = (MstKanriShiyoKaijoJoho) rtoInSession;
        String processName = "";

        /*�G���[���b�Z�[�W������*/
        inSession.setErrors(new Messages());

        try {
            if (!BmaUtility.isNullOrEmpty(inRequest.getShiyoKaijoAdd())) {
                /*�u�g�p���ǉ��v��ʑJ�ڎ�*/
                processName = "MstKanriShiyoKaijoAdd";
                log.Start(processName);

                /**
                 * �����u�K��X�g���쐬
                 */
                inSession.setSknKbnList(findSknKsuList(BmaConstants.SKN_KBN));
                inSession.setKsuKbnList(findSknKsuList(BmaConstants.KSU_KBN));

                /* �J�Òn���X�g���쐬 */
                List<Option> list = createKaisaichiList();
                inSession.setKaisaichiCodeList(list);

                /**
                 * �g�p��ꃊ�X�g���쐬
                 */
                KaijoMst kaijoMst = new KaijoMst(DATA_SOURCE_NAME);
                List<MstKanriShiyoKaijoJoho> shiyoKaijoSearchResultList = kaijoMst.findAllKaijo();
                String detailCodes = "";
                List<MstKanriShiyoKaijoJoho> shiyoKaijoResultList = new ArrayList<MstKanriShiyoKaijoJoho>();
                for (MstKanriShiyoKaijoJoho shiyoKaijo : shiyoKaijoSearchResultList) {
                    detailCodes = shiyoKaijo.getKaisaichiCode()
                            + shiyoKaijo.getKaijoCode();
                    shiyoKaijo.setShiyoKaijoDetail(detailCodes);
                    shiyoKaijoResultList.add(shiyoKaijo);
                }
                inSession.setShiyoKaijoResultList(shiyoKaijoResultList);

                /* ���֗p���X�g�쐬 */
                List<MstKanriShiyoKaijoJoho> shiyoKaijoResultTokanList = new ArrayList<MstKanriShiyoKaijoJoho>();
                for (MstKanriShiyoKaijoJoho shiyoaKaijo : inSession.getShiyoKaijoResultList()) {
                    if ("03".equals(shiyoaKaijo.getKaisaichiCode())
                            || "04".equals(shiyoaKaijo.getKaisaichiCode())) {
                        MstKanriShiyoKaijoJoho newShiyoKaijo = new MstKanriShiyoKaijoJoho();
                        BeanUtils.copyProperties(newShiyoKaijo, shiyoaKaijo);
                        newShiyoKaijo.setKaisaichiName("�����E�֓��b�M�z");
                        shiyoKaijoResultTokanList.add(newShiyoKaijo);
                    } else {
                        shiyoKaijoResultTokanList.add(shiyoaKaijo);
                    }
                }
                inSession.setShiyoKaijoResultTokanList(shiyoKaijoResultTokanList);

                /* �u�g�p���ǉ��v��ʕ\�� */
                return FWD_NM_SUCCESS;

            } else if (!BmaUtility.isNullOrEmpty(inRequest.getShiyoKaijoAddInp())) {
                /*�u���ցv�{�^��������*/
                processName = "MstKanriShiyoKaijoAdd";
                log.Start(processName);

                // ���I��ێ�
                inSession.setTkyKsnKbn(inRequest.getTkyKsnKbn());
                inSession.setKaijoSelect(inRequest.getKaijoSelect());
                // �I��l�`�F�b�N
                if (!validateInput(inSession)) {
                    // �G���[���������ꍇ�u�g�p���ǉ��v���Reload
                    return FWD_NM_SUCCESS;
                }

                KaijoMst kaijoMst = new KaijoMst(DATA_SOURCE_NAME);

                String[] kaisaichiCodes = new String[inSession.getKaijoSelect().length];
                String[] kaijoCodes = new String[inSession.getKaijoSelect().length];
                for (int i = 0; i < inSession.getKaijoSelect().length; ++i) {
                    kaisaichiCodes[i] = inSession.getKaijoSelect()[i].substring(0, 2);
                    kaijoCodes[i] = inSession.getKaijoSelect()[i].substring(2, 5);
                }

                List<MstKanriShiyoKaijoJoho> kaijoResult = kaijoMst.findByKaijo(kaisaichiCodes, kaijoCodes);
                /**
                 * �J�Òn�����ƂɁA�S���҃��X�g���쐬
                 */
                KaijoTantoMst tanto = new KaijoTantoMst(DATA_SOURCE_NAME);
                for (int i = 0; i < kaijoResult.size(); ++i) {
                    List<Option> tantoshaList = new ArrayList<Option>();
                    MstKanriShiyoKaijoJoho shiyoKaijo = kaijoResult.get(i);

                    String kaisaichi = shiyoKaijo.getKaisaichiCode();
                    String kaijo = shiyoKaijo.getKaijoCode();
                    tanto.findByOneTantosha(kaisaichi, kaijo, tantoshaList);

                    // ���֕\���̏ꍇ
                    if ("2".equals(inSession.getTkyKsnKbn())) {
                        if ("03".equals(shiyoKaijo.getKaisaichiCode())
                                || "04".equals(shiyoKaijo.getKaisaichiCode())) {
                            shiyoKaijo.setKaisaichiName("�����E�֓��b�M�z");
                        }
                    }

                    shiyoKaijo.setKaisaichiCode(kaisaichi);
                    shiyoKaijo.setKaijoCode(kaijo);
                    shiyoKaijo.setTantoshaList(tantoshaList);
                    shiyoKaijo.setTantosha("");
                    shiyoKaijo.setShiyoKaijoAddHukusei(kaisaichi + kaijo);
                    kaijoResult.set(i, shiyoKaijo);
                }

                inSession.setKaijoList(kaijoResult);

                /* �u�g�p���ǉ����́v��ʕ\�� */
                return FWD_NM_NEXT;

            } else if (!BmaUtility.isNullOrEmpty(inRequest.getBack())) {
                /*�u�߂�v�{�^��������*/
                processName = "MstKanriShiyoKaijoAdd";
                log.Start(processName);

                /* �c���Ă���I��l��j�� */
                inSession.setSknKsuCode("");
                inSession.setShubetsuCode("");
                inSession.setKaisuCode("");
//                inSession.setSknksuKbn("1");
//                inSession.setSknName("");
//                inSession.setKsuName("");
                if (!"1".equals(inSession.getShiyoKaijoSrcListFlg())) {
                    inSession.setShiyoKaijoSrcListFlg("");
                } else {
                    inSession.setShiyoKaijoSrcListFlg("1");
                    setDisplayList(inSession);
                }

                /* �u�g�p��ꌟ���v��ʕ\�� */
                return FWD_NM_BACK;

            } else {
                /*�ُ�J��*/
                log.IllegalFWD();
                return FWD_NM_SESSION;
            }
        } catch (Exception e) {
            return FWD_NM_EXCEPTION;
        } finally {
            log.End(processName);
        }
    }

    /**
     * �����u�K���X�g���擾����
     *
     * @param sknksuKbn
     * @return
     */
    public List<Option> findSknKsuList(String sknksuKbn) {
        List<Option> list = new ArrayList<>();
        //�����u�K���X�g��p�ӂ���
        SknksuMst sknksuMst = new SknksuMst(BmaConstants.DS_REGISTRANT);
        sknksuMst.findBySknKsuKbn(sknksuKbn, list);
        return list;
    }

    /**
     * �J�Òn���X�g�̍쐬
     *
     * @param inSession �Z�b�V�������
     */
    private List<Option> createKaisaichiList() {
        /* �ϐ������� */
        List<Option> list = new ArrayList<>();
        MeishoKanri meishoKanri = new MeishoKanri(BmaConstants.DS_REGISTRANT);

        /* �J�Òn���̃��X�g��p�� */
        meishoKanri.findByGroupCode(BmaConstants.MEISHO_KANRI_GROUP_KAISAICHI_CODE, list);
        return list;
    }

    /**
     * ���̓`�F�b�N
     *
     * @param inSession �Z�b�V����RTO
     * @return true:�G���[��
     */
    private boolean validateInput(MstKanriShiyoKaijoJoho inSession) {
        Messages errors = new Messages();

        String groupCode;
        String itemName;

        /**
         * ���I��
         */
        groupCode = "kaijoCode";
        itemName = "�J�Òn";
        String kaisaichiCode;

        if (inSession.getKaijoSelect() == null) {
            errors = new Messages();
            BmaValidator.addMessage(errors, groupCode, BmaText.E00003, itemName);
            inSession.setErrors(errors);
        } else {

            for (String element : inSession.getKaijoSelect()) {
                kaisaichiCode = element.substring(0, 2);
                BmaValidator.validatePermissionSelect(kaisaichiCode, inSession.getKaisaichiCodeList(), errors, groupCode, itemName);
                if (!errors.isEmpty()) {
                    break;
                }
            }
        }

        inSession.setErrors(errors);
        return errors.isEmpty();
    }

    /**
     * �w��y�[�W���ɍ��킹�āA�\������S���҃��X�g���쐬
     *
     * @param inSession�@�Z�b�V�������X�g
     */
    private void setDisplayList(MstKanriShiyoKaijoJoho inSession) {
        /* �ϐ������� */
        List<MstKanriShiyoKaijoJoho> displayList = new ArrayList<MstKanriShiyoKaijoJoho>();
        MstKanriShiyoKaijoJoho shiyoKaijo;

        List<MstKanriShiyoKaijoJoho> resultList = inSession.getShiyoKaijoSearchResultList();
        /* �y�[�W���ɍ��킹�ĕ\���p���X�g�쐬 */
        for (int i = inSession.getFirstDisp() - 1; i < inSession.getMaxDisp(); ++i) {
            shiyoKaijo = resultList.get(i);
            displayList.add(shiyoKaijo);
        }
        inSession.setShiyoKaijoDisplayList(displayList);
    }

}
