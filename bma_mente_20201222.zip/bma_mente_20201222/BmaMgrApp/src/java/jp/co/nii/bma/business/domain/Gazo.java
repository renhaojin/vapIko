package jp.co.nii.bma.business.domain;

import java.util.List;
import jp.co.nii.bma.business.rto.manager.GazoKanriJoho;
import jp.co.nii.bma.business.rto.manager.SmnMskJoho;

/**
 * �摜 BO�N���X
 *
 * @author DB�Ǘ��c�[��
 */
public class Gazo extends GeneratedGazo {

    /**
     * �C���X�^���X�𐶐�����B
     */
    public Gazo() {
        super();
    }

    /**
     * �C���X�^���X�𐶐�����B
     *
     * @param connectionUser �f�[�^�\�[�X��
     */
    public Gazo(String connectionUser) {
        super(connectionUser);
    }

    /**
     * �摜�̏����擾����B
     *
     * @param sknKsuCode
     * @param shubetsuCode
     * @param kaisuCode
     * @param gazoShuruiChoice
     * @param chkGazoStatusChoice
     * @param uketukeNo
     * @param jknJkuNo
     * @param furigana
     * @param chkMskKbn
     * @param chkKojinDantai
     * @param page
     * @param searchFlg
     * @param nendo
     * @param hoseiKigenBi
     * @return list
     */
    public List<GazoKanriJoho> searchGazoList(String sknKsuCode, String shubetsuCode,
            String kaisuCode, String gazoShuruiChoice, String[] chkGazoStatusChoice, String uketukeNo,
            String jknJkuNo, String furigana, String[] chkMskKbn, String[] chkKojinDantai, int page, String searchFlg, String nendo,String hoseiKigenBi) {
        GazoKanriJoho bo = new GazoKanriJoho();
        bo.setSknKsuCode(sknKsuCode);
        bo.setShubetsuCode(shubetsuCode);
        bo.setKaisuCode(kaisuCode);
        bo.setGazoShuruiChoice(gazoShuruiChoice);
        bo.setChkGazoStatusChoice(chkGazoStatusChoice);
        bo.setUketukeNo(uketukeNo);
        bo.setJknJkuNo(jknJkuNo);
        bo.setFurigana(furigana);
        bo.setChkMskKbn(chkMskKbn);
        bo.setChkKojinDantai(chkKojinDantai);
        bo.setPage(page);
        bo.setSearchFlg(searchFlg);
        bo.setNendo(nendo);
        bo.setHoseiKigenBi(hoseiKigenBi);
        return dao.searchGazoList(bo);
    }

    /**
     * �摜�ڍׂ��擾����B
     *
     * @param uketsukeNo
     * @param gazoKbn
     * @param nendo
     * @param Seq
     * @return
     */
    public List<GazoKanriJoho> searchGazoShosai(String nendo, String uketsukeNo, String gazoKbn, String Seq) {
        GazoKanriJoho bo = new GazoKanriJoho();
        bo.setNendo(nendo);
        bo.setUketukeNo(uketsukeNo);
        bo.setGazoKbn(gazoKbn);
        bo.setSeq(Seq);
        return dao.searchGazoShosai(bo);
    }

    /**
     * �摜�A�b�v���[�h�f�[�^�̏����擾����B
     *
     * @param sknKsuCode
     * @param shubetsuCode
     * @param kaisuCode
     * @param searchFlg
     * @param nendo
     * @param page
     * @return list
     */
    public List<SmnMskJoho> searchGazoDateList(String sknKsuCode, String shubetsuCode,
            String kaisuCode, String searchFlg, String nendo,int page) {
        SmnMskJoho bo = new SmnMskJoho();
        bo.setSknKsuCode(sknKsuCode);
        bo.setShubetsuCode(shubetsuCode);
        bo.setKaisuCode(kaisuCode);
        bo.setSearchFlg(searchFlg);
        bo.setNendo(nendo);
        bo.setPage(page);
        return dao.searchGazoDateList(bo);
    }

    /**
     * ���ʃA�b�v���[�h����摜�����擾����B
     *
     * @param uketsukeNos
     * @param nendo
     * @return list
     */
    public List<SmnMskJoho> searchGazoListShomen(String[] uketsukeNos, String nendo) {
        SmnMskJoho bo = new SmnMskJoho();
        bo.setUketsukeNos(uketsukeNos);
        bo.setNendo(nendo);
        return dao.searchGazoListShomen(bo);
    }
    
    public List<Gazo> findByNendoUke(String nendo, String uketsukeNo) {
        return dao.findByNendoUke(nendo, uketsukeNo);
    }
}
