//package jp.co.nii.bma.business.service.manager;
//
//import java.text.SimpleDateFormat;
//import java.util.List;
//import java.util.ArrayList;
//import java.util.Date;
//import jp.co.nii.bma.business.domain.Moshikomi;
//import jp.co.nii.bma.business.rto.manager.MgrKaoPhotoSearch;
//import jp.co.nii.bma.business.rto.manager.MgrKaoPhotoSearchList;
//import jp.co.nii.bma.business.service.common.BmaConstants;
//import jp.co.nii.bma.business.service.common.BmaLogger;
//import jp.co.nii.bma.business.service.common.BmaValidator;
//import jp.co.nii.bma.presentation.common.BmaText;
//import jp.co.nii.bma.utility.BmaStringUtility;
//import jp.co.nii.bma.utility.BmaUtility;
//import jp.co.nii.sew.business.SystemTime;
//import jp.co.nii.sew.business.service.AbstractService;
//import jp.co.nii.sew.presentation.Messages;
//import jp.co.nii.sew.presentation.RequestTransferObject;
//import jp.co.nii.sew.utility.StringUtility;
//import jp.co.nii.sew.presentation.Option;
//import jp.co.nii.sew.utility.DateUtility;
//import org.apache.commons.beanutils.BeanUtils;
//
///**
// *
// * @author ouen13
// */
//public class MgrKaoPhotoSearchService extends AbstractService {
//
//    /**
//     * DB�ڑ��̃f�[�^�\�[�X
//     */
//    private static String DATA_SOURCE_NAME;
//    BmaLogger log = (BmaLogger) BmaLogger.getLogger(this.getClass().getName());
//
//    /**
//     * �R���X�g���N�^
//     */
//    public MgrKaoPhotoSearchService() {
//        super();
//        //DB�ڑ����̃��[�U�[������
//        DATA_SOURCE_NAME = BmaConstants.DS_REGISTRANT;
//    }
//
//    @Override
//    public String doService(RequestTransferObject rto, RequestTransferObject rtoInSession) throws Exception {
//
//        MgrKaoPhotoSearch mskInRequest = (MgrKaoPhotoSearch) rto;
//        MgrKaoPhotoSearch mskInSession = (MgrKaoPhotoSearch) rtoInSession;
//        String processName = "";
//
//        /*�G���[���b�Z�[�W������*/
//        mskInSession.setErrors(new Messages());
//
//        //�T�C�h�o�[������
//        if (mskInRequest.getCommandSideBarInit() != null) {
//
//            // �J�n���O
//            processName = "MenuKaoPhotoSearch";
//            log.Start(processName);
//
//            //�Z�b�V������������
//            mskInSession.clearInfo();
//
//            //�}�b�v�ƃ��X�g���擾
//            initFormList(mskInSession);
//
//            // �������O
//            log.End(processName);
//
//            return FWD_NM_SUCCESS;
//
//        }
//
//        //�����������͉��:�����{�^������
//        if (mskInRequest.getCommandSearch() != null) {
//
//            // �J�n���O
//            processName = "Search";
//            log.Start(processName);
//
//            /*���͒l���Z�b�V�����ɕۑ�*/
//            setValueRequestToSession(mskInRequest, mskInSession);
//
//            //null���u�����N��
//            this.formatNullToBlank(mskInSession);
//
//            //���̓`�F�b�N
//            if (!searchValidator(mskInSession)) {
//                return FWD_NM_ERROR;
//            }
//
//            /* �W�v���f���t */
//            SystemTime now = new SystemTime();
//            String shukeihaneidate;
//            shukeihaneidate = now.getymd2() + " " + now.gethm2();
//
//            /* rto�̏����Z�b�V�����ɃZ�b�g */
//            mskInSession.setShukeiHaneiDate(shukeihaneidate);
//            /* ���я��̏����l�Z�b�g */
//            mskInSession.setSearchOrderBy("1");
//
//            //�������s
//            Moshikomi bomoshikomi = new Moshikomi(DATA_SOURCE_NAME);
//
//            List<String> idList = bomoshikomi.getKaoPhotoSearchListIndex(mskInSession);
//
//            if (idList.isEmpty()) {
//                /*�L�[���X�g����̎��G���[*/
//                Messages errors = new Messages();
//                BmaValidator.addMessage(errors, "info", BmaText.E00022, "");
//                mskInSession.setErrors(errors);
//                return FWD_NM_ERROR;
//            }
//
//            //�L�[���X�g���Z�b�V�����ɕۑ�
//            mskInSession.setMoshikomiUketsukeNoList(idList);
//
//            /*�C���f�b�N�X�ݒ�*/
//            mskInSession.setListIndex(0);
//
//            /*�C���f�b�N�X�ƃL�[���X�g������擾*/
//            List<MgrKaoPhotoSearchList> resultList = new ArrayList<MgrKaoPhotoSearchList>();
//
//            resultList = bomoshikomi.getKaoPhotoSearchList(getDispKeyList(idList, mskInSession.getListIndex()), mskInSession.getSearchOrderBy());
//
//            mskInSession.setSearchList(resultList);
//
//            log.End(processName);
//
//            return FWD_NM_SUCCESS;
//
//        }
//
//        //�����������͉��:���̓N���A�{�^������
//        if (mskInRequest.getCommandClear() != null) {
//
//            // �J�n���O
//            processName = "clearSearchInput";
//            log.Start(processName);
//
//            //�Z�b�V������������
//            mskInSession.clearInfo();
//
//            // �������O
//            log.End(processName);
//
//            return FWD_NM_RELOAD;
//
//        }
//
//        //�������ʉ��:���я��{�^������
//        if (mskInRequest.getCommandOrderBy() != null) {
//
//            // �J�n���O
//            processName = "orderBy";
//            log.Start(processName);
//
//            /* ���я��l�Z�b�g */
//            mskInSession.setSearchOrderBy(mskInRequest.getSearchOrderBy());
//
//            //�������s
//            Moshikomi bomoshikomi = new Moshikomi(DATA_SOURCE_NAME);
//
//            List<String> idList = bomoshikomi.getKaoPhotoSearchListIndex(mskInSession);
//
//            //�L�[���X�g���Z�b�V�����ɕۑ�
//            mskInSession.setMoshikomiUketsukeNoList(idList);
//
//            /*�C���f�b�N�X�ݒ�*/
//            mskInSession.setListIndex(0);
//
//            /*�C���f�b�N�X�ƃL�[���X�g������擾*/
//            List<MgrKaoPhotoSearchList> resultList = new ArrayList<MgrKaoPhotoSearchList>();
//
//            resultList = bomoshikomi.getKaoPhotoSearchList(getDispKeyList(idList, mskInSession.getListIndex()), mskInSession.getSearchOrderBy());
//
//            mskInSession.setSearchList(resultList);
//
//            log.End(processName);
//
//            return FWD_NM_RELOAD;
//
//        }
//
//        if (mskInRequest.getCommandSearchListPage() != null) {
//
//            // �J�n���O
//            processName = "page";
//            log.Start(processName);
//
//            int page;
//            try {
//                page = Integer.parseInt(mskInRequest.getCommandSearchListPage());
//            } catch (NumberFormatException nfe) {
//                /*�y�[�W�ԍ��p�̃p�����[�^�������łȂ��ꍇ�A
//                 �s���ȑJ�ڂł���Ƒz�肳��邽�߁A�Z�b�V�����G���[��ʂɑJ�ڂ�����*/
//                return FWD_NM_SESSION;
//            }
//            if (page < 1 || mskInSession.getMaxPage() < page) {
//                /*�w��y�[�W�ԍ����s���ȏꍇ�A�Z�b�V�����G���[*/
//                return FWD_NM_SESSION;
//            }
//
//            changePage(mskInSession, page);
//
//            log.End(processName);
//
//            return FWD_NM_RELOAD;
//
//        }
//
//        //�������ʉ��:��ʐ^�ڍ׃{�^������
//        if (mskInRequest.getCommandKaoPhotoDetail() != null) {
//
//            // �J�n���O
//            processName = "photoDeatil";
//            log.Start(processName);
//
//            int idx;
//            try {
//                idx = Integer.parseInt(mskInRequest.getCommandKaoPhotoDetail());
//            } catch (NumberFormatException nfe) {
//                return FWD_NM_SESSION;
//            }
//            //�Ǘ��Ҏ擾
//            mskInSession.setKanrishaId(mskInRequest.getKanrishaId());
//
//            /* ��ʐ^�h�c�A�\����t�m�n�Z�b�g */
//            MgrKaoPhotoSearchList result = new MgrKaoPhotoSearchList();
//            result = mskInSession.getSearchList().get(idx);
//
//            mskInSession.setKaoShasinGazoId(result.getKaoShasinGazoId());
//            mskInSession.setMoshikomiUketsukeNo(result.getMoshikomiUketsukeNo());
//            mskInSession.setJuken_no(result.getJuken_no());
//            mskInSession.setUserId(result.getUserId());
//            //�␳���̎擾
//            setHoseiDetailJoho(mskInSession);
//            
//            log.End(processName);
//
//            return FWD_NM_SUCCESS;
//
//        }
//
//        //��ʐ^�ڍ׉��:�X�V�{�^������
//        if (mskInRequest.getCommandPhotoDetailUpdate() != null) {
//
//            // �J�n���O
//            processName = "photoDetailUpdate";
//            log.Start(processName);
//            
//            //�Z�b�V�����������ꍇ�ɍX�V���悤�Ƃ������̑Ή�
//            if (BmaUtility.isNullOrEmpty(mskInSession.getKanrishaId())){
//                return FWD_NM_SESSION;
//            }
//            
//            //�ύX���m�F
//            if (!validateModify(mskInRequest,mskInSession)){
//                /* �G���[�̎����͉�ʍĕ\�� */
//                return FWD_NM_RELOAD;
//            }
//
//            /*���͒l���Z�b�V�����ɕۑ�*/
//            setHoseiIraiInputDataToSession(mskInRequest, mskInSession);
//            
//            if (!validateHoseiIrai(mskInSession)) {
//                /* �G���[�̎����͉�ʍĕ\�� */
//                return FWD_NM_RELOAD;
//            }
//            
//            if (!updateHoseiIraiMoshikomiData(mskInSession)) {
//                /*�X�V���s*/
//                return FWD_NM_EXCEPTION;
//            }
//
//            //�\�����ڍĎ擾
//            setHoseiDetailJoho(mskInSession);
//            
//            // �������O
//            log.End(processName);
//            
//            return FWD_NM_RELOAD;
//        }
//        //��ʐ^�ڍ׉��:�������ʉ�ʂ֖߂�{�^������
//        if (mskInRequest.getCommandListBack() != null) {
//
//            // �J�n���O
//            processName = "backList";
//            log.Start(processName);
//
//            // �������O
//            log.End(processName);
//
//            return FWD_NM_BACK;
//        }
//
//        //�������ʉ��:�����X�V����{�^������
//        if (mskInRequest.getCommandJohoUpdate() != null) {
//
//            // �J�n���O
//            processName = "updateJoho";
//            log.Start(processName);
//
//            //�Z�b�V�����������ꍇ�ɍX�V���悤�Ƃ������̑Ή�
//            if (BmaUtility.isNullOrEmpty(mskInRequest.getKanrishaId())){
//                return FWD_NM_SESSION;
//            }
//            
//            if (!updateMoshikomiData(mskInRequest)) {
//                /*�X�V���s*/
//                return FWD_NM_EXCEPTION;
//            }
//
//            //�ēǂݍ���
//            Moshikomi bomoshikomi = new Moshikomi(DATA_SOURCE_NAME);
//            /*�C���f�b�N�X�ƃL�[���X�g������擾*/
//            mskInSession.setSearchList(bomoshikomi.getKaoPhotoSearchList(getDispKeyList(mskInSession.getMoshikomiUketsukeNoList(), mskInSession.getListIndex()), mskInSession.getSearchOrderBy()));
//
//            // �������O
//            log.End(processName);
//
//            return FWD_NM_SUCCESS;
//
//        }
//
//        //�������ʉ��:�������͉�ʂ֖߂�{�^������
//        if (mskInRequest.getCommandSearchListBack() != null) {
//            // �J�n���O
//            processName = "backSearchInput";
//            log.Start(processName);
//
//            // �������O
//            log.End(processName);
//
//            return FWD_NM_BACK;
//        }
//
//        // �ُ�ȑJ��
//        log.IllegalFWD();
//        return FWD_NM_EXCEPTION;
//
//    }
//
//    /**
//     * �t�H�[���̏����\���ɕK�v�ȏ������s���B �Z���N�g�{�b�N�X���X�g�Ƃ��̃}�b�v
//     *
//     * @param requestRTO
//     */
//    private void initFormList(MgrKaoPhotoSearch sessionRTO) throws Exception {
//
//        List<Option> list = new ArrayList<Option>();
//
//        /* ����N���X�g */
//        list = new ArrayList<Option>();
//        list.add(new Option(BmaConstants.NEN, BmaConstants.NEN));
//        sessionRTO.setYearDisp(list);
//
//        /* �����X�g */
//        list = new ArrayList<Option>();
//        list.add(new Option("", ""));
//
//        for (int i = 1; i <= 12; i++) {
//            list.add(new Option(i >= 10 ? "" + i : "0" + i, "" + i));
//        }
//        sessionRTO.setMonthDisp(list);
//
//        /* �����X�g */
//        list = new ArrayList<Option>();
//        list.add(new Option("", ""));
//        for (int i = 1; i <= 31; i++) {
//            list.add(new Option(i >= 10 ? "" + i : "0" + i, "" + i));
//        }
//        sessionRTO.setDayDisp(list);
//
//        /* �����X�g */
//        list = new ArrayList<Option>();
//        list.add(new Option("", ""));
//        for (int i = 0; i <= 23; i++) {
//            list.add(new Option(i >= 10 ? "" + i : "0" + i, "" + i));
//        }
//        sessionRTO.setHourDisp(list);
//
//        /* ���я����X�g */
//        list = new ArrayList<Option>();
//        list.add(new Option("1", "�o�^���i�����j"));
//        list.add(new Option("2", "�o�^���i�~���j"));
//        sessionRTO.setOrderByDisp(list);
//
//    }
//
//    /**
//     * ���̓f�[�^���Z�b�V�����f�[�^�ɃZ�b�g����B
//     *
//     * @param InputInRequest ���N�G�X�g��̓��̓f�[�^
//     * @param InputInSession �Z�b�V������̓��̓f�[�^
//     */
//    private void setValueRequestToSession(MgrKaoPhotoSearch inRequest, MgrKaoPhotoSearch inSession) {
//        inSession.setSearchFromMoshikomibiYear(inRequest.getSearchFromMoshikomibiYear());
//        inSession.setSearchFromMoshikomibiMonth(inRequest.getSearchFromMoshikomibiMonth());
//        inSession.setSearchFromMoshikomibiDay(inRequest.getSearchFromMoshikomibiDay());
//        inSession.setSearchFromMoshikomibiHour(inRequest.getSearchFromMoshikomibiHour());
//        inSession.setSearchToMoshikomibiYear(inRequest.getSearchToMoshikomibiYear());
//        inSession.setSearchToMoshikomibiMonth(inRequest.getSearchToMoshikomibiMonth());
//        inSession.setSearchToMoshikomibiDay(inRequest.getSearchToMoshikomibiDay());
//        inSession.setSearchToMoshikomibiHour(inRequest.getSearchToMoshikomibiHour());
//
//        inSession.setSearchPhotoHanteiOkFlg(inRequest.getSearchPhotoHanteiOkFlg());
//        inSession.setSearchPhotoHanteiNgFlg(inRequest.getSearchPhotoHanteiNgFlg());
//        inSession.setSearchPhotoJokyoMikakuninFlg(inRequest.getSearchPhotoJokyoMikakuninFlg());
//        inSession.setSearchPhotoJokyoIraiNashiFlg(inRequest.getSearchPhotoJokyoIraiNashiFlg());
//        inSession.setSearchPhotoJokyoIraiChuFlg(inRequest.getSearchPhotoJokyoIraiChuFlg());
//        inSession.setSearchPhotoJokyoSumiFlg(inRequest.getSearchPhotoJokyoSumiFlg());
//        inSession.setSearchPhotoJokyoKakuninSumiFlg(inRequest.getSearchPhotoJokyoKakuninSumiFlg());
//        inSession.setSearchPhotoJokyoBlackFlg(inRequest.getSearchPhotoJokyoBlackFlg());
//        inSession.setSearchPhotoJokyoRiyuFlg(inRequest.getSearchPhotoJokyoRiyuFlg());
//
//        inSession.setShikenShuruiCode(inRequest.getShikenShuruiCode());
//    }
//
//    /**
//     * NULL���u�����N��
//     *
//     * @param useRTO
//     */
//    private void formatNullToBlank(MgrKaoPhotoSearch useRTO) {
//        useRTO.setSearchFromMoshikomibiYear(StringUtility.convertNullToBlank(useRTO.getSearchFromMoshikomibiYear()));
//        useRTO.setSearchFromMoshikomibiMonth(StringUtility.convertNullToBlank(useRTO.getSearchFromMoshikomibiMonth()));
//        useRTO.setSearchFromMoshikomibiDay(StringUtility.convertNullToBlank(useRTO.getSearchFromMoshikomibiDay()));
//        useRTO.setSearchFromMoshikomibiHour(StringUtility.convertNullToBlank(useRTO.getSearchFromMoshikomibiHour()));
//        useRTO.setSearchToMoshikomibiYear(StringUtility.convertNullToBlank(useRTO.getSearchToMoshikomibiYear()));
//        useRTO.setSearchToMoshikomibiMonth(StringUtility.convertNullToBlank(useRTO.getSearchToMoshikomibiMonth()));
//        useRTO.setSearchToMoshikomibiDay(StringUtility.convertNullToBlank(useRTO.getSearchToMoshikomibiDay()));
//        useRTO.setSearchToMoshikomibiHour(StringUtility.convertNullToBlank(useRTO.getSearchToMoshikomibiHour()));
//
//        useRTO.setSearchPhotoHanteiOkFlg(StringUtility.convertNullToBlank(useRTO.getSearchPhotoHanteiOkFlg()));
//        useRTO.setSearchPhotoHanteiNgFlg(StringUtility.convertNullToBlank(useRTO.getSearchPhotoHanteiNgFlg()));
//        useRTO.setSearchPhotoJokyoMikakuninFlg(StringUtility.convertNullToBlank(useRTO.getSearchPhotoJokyoMikakuninFlg()));
//        useRTO.setSearchPhotoJokyoIraiNashiFlg(StringUtility.convertNullToBlank(useRTO.getSearchPhotoJokyoIraiNashiFlg()));
//        useRTO.setSearchPhotoJokyoIraiChuFlg(StringUtility.convertNullToBlank(useRTO.getSearchPhotoJokyoIraiChuFlg()));
//        useRTO.setSearchPhotoJokyoSumiFlg(StringUtility.convertNullToBlank(useRTO.getSearchPhotoJokyoSumiFlg()));
//        useRTO.setSearchPhotoJokyoBlackFlg(StringUtility.convertNullToBlank(useRTO.getSearchPhotoJokyoBlackFlg()));
//        useRTO.setSearchPhotoJokyoKakuninSumiFlg(StringUtility.convertNullToBlank(useRTO.getSearchPhotoJokyoKakuninSumiFlg()));
//        useRTO.setSearchPhotoJokyoRiyuFlg(StringUtility.convertNullToBlank(useRTO.getSearchPhotoJokyoRiyuFlg()));
//
//    }
//
//    /**
//     * ���̓`�F�b�N
//     *
//     * @param ListRTO
//     * @return
//     * @throws Exception
//     */
//    private boolean searchValidator(MgrKaoPhotoSearch searchRTO) throws Exception {
//        Messages errors = searchValidatorCaller(searchRTO);
//        if (!errors.isEmpty()) {
//            //�G���[��rto�Ɋi�[
//            searchRTO.setErrors(errors);
//            return false;
//        }
//        return true;
//    }
//
//    /**
//     * ���̓`�F�b�N�ڍ�
//     *
//     * @param mntListRTO
//     * @return
//     * @throws Exception
//     */
//    private Messages searchValidatorCaller(MgrKaoPhotoSearch searchRTO) throws Exception {
//        //������
//        Messages errors = new Messages();
//        String itemName;
//        String groupCode;
//
//        /*�\����*/
//        groupCode = "mskDate";
//        itemName = "�N";
//        BmaValidator.validatePermissionSelect(searchRTO.getSearchFromMoshikomibiYear(), searchRTO.getYearDisp(), errors, groupCode, itemName);
//        BmaValidator.validatePermissionSelect(searchRTO.getSearchToMoshikomibiYear(), searchRTO.getYearDisp(), errors, groupCode, itemName);
//        itemName = "��";
//        BmaValidator.validatePermissionSelect(searchRTO.getSearchFromMoshikomibiMonth(), searchRTO.getMonthDisp(), errors, groupCode, itemName);
//        BmaValidator.validatePermissionSelect(searchRTO.getSearchToMoshikomibiMonth(), searchRTO.getMonthDisp(), errors, groupCode, itemName);
//        itemName = "��";
//        BmaValidator.validatePermissionSelect(searchRTO.getSearchFromMoshikomibiDay(), searchRTO.getDayDisp(), errors, groupCode, itemName);
//        BmaValidator.validatePermissionSelect(searchRTO.getSearchToMoshikomibiDay(), searchRTO.getDayDisp(), errors, groupCode, itemName);
//        itemName = "��";
//        BmaValidator.validatePermissionSelect(searchRTO.getSearchFromMoshikomibiHour(), searchRTO.getHourDisp(), errors, groupCode, itemName);
//        BmaValidator.validatePermissionSelect(searchRTO.getSearchToMoshikomibiHour(), searchRTO.getHourDisp(), errors, groupCode, itemName);
//
//        itemName = "�\����";
//        if (!BmaUtility.isNullOrEmpty(searchRTO.getSearchFromMoshikomibiMonth()) && !BmaUtility.isNullOrEmpty(searchRTO.getSearchFromMoshikomibiDay())) {
//            /*�J�n���������I������Ă���Ƃ����ݓ��`�F�b�N*/
//            BmaValidator.validateDate(searchRTO.getSearchFromMoshikomibiYear() + searchRTO.getSearchFromMoshikomibiMonth() + searchRTO.getSearchFromMoshikomibiDay(), errors, groupCode, itemName);
//        }
//        if (!BmaUtility.isNullOrEmpty(searchRTO.getSearchToMoshikomibiMonth()) && !BmaUtility.isNullOrEmpty(searchRTO.getSearchToMoshikomibiDay())) {
//            /*�I�����������I������Ă���Ƃ����ݓ��`�F�b�N*/
//            BmaValidator.validateDate2(searchRTO.getSearchToMoshikomibiYear() + searchRTO.getSearchToMoshikomibiMonth() + searchRTO.getSearchToMoshikomibiDay(), errors, groupCode, itemName);
//        }
//
//        /*��ʐ^�̔���*/
//        itemName = "��ʐ^�̔���";
//        groupCode = "photoHantei";
//        BmaValidator.validatePermissionSelect(searchRTO.getSearchPhotoHanteiOkFlg(), new String[]{BmaConstants.FLG_ON}, errors, groupCode, itemName);
//        BmaValidator.validatePermissionSelect(searchRTO.getSearchPhotoHanteiNgFlg(), new String[]{BmaConstants.FLG_ON}, errors, groupCode, itemName);
//
//        /*��ʐ^�̏�*/
//        itemName = "��ʐ^�̏�";
//        groupCode = "photoJokyo";
//        BmaValidator.validatePermissionSelect(searchRTO.getSearchPhotoJokyoIraiNashiFlg(), new String[]{BmaConstants.FLG_ON}, errors, groupCode, itemName);
//        BmaValidator.validatePermissionSelect(searchRTO.getSearchPhotoJokyoIraiChuFlg(), new String[]{BmaConstants.FLG_ON}, errors, groupCode, itemName);
//        BmaValidator.validatePermissionSelect(searchRTO.getSearchPhotoJokyoSumiFlg(), new String[]{BmaConstants.FLG_ON}, errors, groupCode, itemName);
//        BmaValidator.validatePermissionSelect(searchRTO.getSearchPhotoJokyoKakuninSumiFlg(), new String[]{BmaConstants.FLG_ON}, errors, groupCode, itemName);
//        BmaValidator.validatePermissionSelect(searchRTO.getSearchPhotoJokyoBlackFlg(), new String[]{BmaConstants.FLG_ON}, errors, groupCode, itemName);
//        BmaValidator.validatePermissionSelect(searchRTO.getSearchPhotoJokyoRiyuFlg(), new String[]{BmaConstants.FLG_ON}, errors, groupCode, itemName);
//
//        return errors;
//    }
//
//    /**
//     * �C���f�b�N�X�ƃL�[���X�g����\������L�[���X�g���擾����B
//     *
//     * @param searchKeyList�@�L�[���X�g
//     * @param idx �C���f�b�N�X
//     * @return �\���p�L�[���X�g
//     */
//    private List<String> getDispKeyList(List<String> searchKeyList, int idx) {
//        List<String> ret = new ArrayList<String>();
//
//        int max = searchKeyList.size() < idx + BmaConstants.MAX_DISP_NUM_KAO_PHOTO_SEARCH
//                ? searchKeyList.size() : idx + BmaConstants.MAX_DISP_NUM_KAO_PHOTO_SEARCH;
//        for (int i = idx; i < max; i++) {
//            ret.add(searchKeyList.get(i));
//        }
//        return ret;
//    }
//
//    /**
//     * �y�[�W��ύX����B
//     *
//     * @param inSession �Z�b�V����RTO
//     * @param page �y�[�W�ԍ�
//     */
//    private void changePage(MgrKaoPhotoSearch inSession, int page) {
//
//        Moshikomi moshikomi = new Moshikomi(DATA_SOURCE_NAME);
//
//        /*�C���f�b�N�X�ݒ�*/
//        inSession.setListIndex((page - 1) * BmaConstants.MAX_DISP_NUM_KAO_PHOTO_SEARCH);
//
//        /*�C���f�b�N�X�ƃL�[���X�g������擾*/
//        inSession.setSearchList(moshikomi.getKaoPhotoSearchList(getDispKeyList(inSession.getMoshikomiUketsukeNoList(), inSession.getListIndex()), inSession.getSearchOrderBy()));
//    }
//
//    /**
//     * �󌱐\�����X�V����
//     *
//     * @param inSession �Z�b�V����RTO
//     * @return true:����
//     * @throws Exception ��O
//     */
//    private boolean updateMoshikomiData(MgrKaoPhotoSearch inSession) throws Exception {
//
//        Moshikomi moshikomi = new Moshikomi(DATA_SOURCE_NAME);
//
//        try {
//            getTransaction();
//            beginTransaction();
//
//            SystemTime sysTime = new SystemTime();
//            String uketsukeNo;
//            String hanteiFlg;
//            StringBuilder sb = new StringBuilder();
//
//            for (int i = 0; i < 100; i++) {
//
//                if (!BmaUtility.isNullOrEmpty(inSession.getUpdateMoshikomiUketsukeNoList().get(i).getValue())
//                        && !BmaUtility.isNullOrEmpty(inSession.getUpdateMoshikomiUketsukeNoList().get(i).getLabel())) {
//
//                    uketsukeNo = inSession.getUpdateMoshikomiUketsukeNoList().get(i).getValue();
//                    /*�@hanteiFlg��"1"���n�j�@hanteiFlg��"0"���m�f*/
//                    hanteiFlg = inSession.getUpdateMoshikomiUketsukeNoList().get(i).getLabel();
//
//                    /*�\���e�[�u�������b�N���Ď擾*/
//                    BeanUtils.copyProperties(moshikomi, moshikomi.findRetry(BmaConstants.NEN, uketsukeNo));
//
//                    /*�␳�˗��敪����*/
//                    if (BmaConstants.HOSEI_IRAI_KBN_MIKAKUNIN.equals(moshikomi.getHoseiIraiKbn())) {
//                        /*�@�X�V�O�␳�˗��敪���u���m�F�v�Ł@�u�n�j�v�̏ꍇ�@���@�u�␳�˗��Ȃ��v*/
//                        if (BmaConstants.FLG_ON.equals(hanteiFlg)) {
//                            moshikomi.setHoseiIraiKbn(BmaConstants.HOSEI_IRAI_KBN_IRAI_NASHI);
//                            moshikomi.setKoshinNaiyoKbn(BmaConstants.KOSHIN_NAIYO_KBN_MOSHIKOMI_UPDATE);
//                            moshikomi.setHoseiFinishBi(sysTime.getymd1());
//                            moshikomi.setHoseiFinishTime(sysTime.gethms1());
//                        }
//                        /*�@�X�V�O�␳�˗��敪���u���m�F�v�Ł@�u�m�f�v�̏ꍇ�@���@�u�␳�˗����v*/
//                        if (BmaConstants.FLG_OFF.equals(hanteiFlg)) {
//                            moshikomi.setHoseiIraiKbn(BmaConstants.HOSEI_IRAI_KBN_HOSEI_IRAI);
//                            moshikomi.setKoshinNaiyoKbn(BmaConstants.KOSHIN_NAIYO_KBN_HOSEI_IRAI);
//                            moshikomi.setHoseiIraiBi(sysTime.getymd1());
//                            moshikomi.setHoseiIraiTime(sysTime.gethms1());
//                        }
//                    } else if (BmaConstants.HOSEI_IRAI_KBN_IRAI_NASHI.equals(moshikomi.getHoseiIraiKbn())) {
//                        /*�@�X�V�O�␳�˗��敪���u�␳�˗��Ȃ��v�Ł@�u�n�j�v�̏ꍇ�@���@�u�␳�˗��Ȃ��v�i�X�V�Ȃ��j*/
//                        if (BmaConstants.FLG_ON.equals(hanteiFlg)) {
//                            moshikomi.setHoseiIraiKbn(BmaConstants.HOSEI_IRAI_KBN_IRAI_NASHI);
//                            moshikomi.setKoshinNaiyoKbn(BmaConstants.KOSHIN_NAIYO_KBN_MOSHIKOMI_UPDATE);
//                        }
//                        /*�@�X�V�O�␳�˗��敪���u�␳�˗��Ȃ��v�Ł@�u�m�f�v�̏ꍇ�@���@�u�␳�˗����v*/
//                        if (BmaConstants.FLG_OFF.equals(hanteiFlg)) {
//                            moshikomi.setHoseiIraiKbn(BmaConstants.HOSEI_IRAI_KBN_HOSEI_IRAI);
//                            moshikomi.setKoshinNaiyoKbn(BmaConstants.KOSHIN_NAIYO_KBN_HOSEI_IRAI);
//                            moshikomi.setHoseiIraiBi(sysTime.getymd1());
//                            moshikomi.setHoseiIraiTime(sysTime.gethms1());
//                        }
//                    } else if (BmaConstants.HOSEI_IRAI_KBN_HOSEI_IRAI.equals(moshikomi.getHoseiIraiKbn())) {
//                        /*�@�X�V�O�␳�˗��敪���u�␳�˗����v�Ł@�u�n�j�v�̏ꍇ�@���@�u�␳�˗����v�i�X�V�Ȃ��jerror*/
//                        if (BmaConstants.FLG_ON.equals(hanteiFlg)) {
//                            moshikomi.setHoseiIraiKbn(BmaConstants.HOSEI_IRAI_KBN_HOSEI_IRAI);
//                            moshikomi.setKoshinNaiyoKbn(BmaConstants.KOSHIN_NAIYO_KBN_MOSHIKOMI_UPDATE);
//                        }
//                        /*�@�X�V�O�␳�˗��敪���u�␳�˗����v�Ł@�u�m�f�v�̏ꍇ�@���@�u�␳�˗����v�i�X�V�Ȃ��j*/
//                        if (BmaConstants.FLG_OFF.equals(hanteiFlg)) {
//                            moshikomi.setHoseiIraiKbn(BmaConstants.HOSEI_IRAI_KBN_HOSEI_IRAI);
//                            moshikomi.setKoshinNaiyoKbn(BmaConstants.KOSHIN_NAIYO_KBN_MOSHIKOMI_UPDATE);
//                        }
//                    } else if (BmaConstants.HOSEI_IRAI_KBN_HOSEI_ZUMI.equals(moshikomi.getHoseiIraiKbn())) {
//                        /*�@�X�V�O�␳�˗��敪���u�␳�ς݁v�Ł@�u�n�j�v�̏ꍇ�@���@�u�␳�˗��m�F�ς݁v*/
//                        if (BmaConstants.FLG_ON.equals(hanteiFlg)) {
//                            moshikomi.setHoseiIraiKbn(BmaConstants.HOSEI_IRAI_KBN_KAKUNIN_ZUMI);
//                            moshikomi.setKoshinNaiyoKbn(BmaConstants.KOSHIN_NAIYO_KBN_HOSEI_KAKUNIN_ZUMI);
//                            moshikomi.setHoseiFinishBi(sysTime.getymd1());
//                            moshikomi.setHoseiFinishTime(sysTime.gethms1());
//                        }
//                        /*�@�X�V�O�␳�˗��敪���u�␳�ς݁v�Ł@�u�m�f�v�̏ꍇ�@���@�u�␳�ς݁v�i�X�V�Ȃ��j*/
//                        if (BmaConstants.FLG_OFF.equals(hanteiFlg)) {
//                            moshikomi.setHoseiIraiKbn(BmaConstants.HOSEI_IRAI_KBN_HOSEI_ZUMI);
//                            moshikomi.setKoshinNaiyoKbn(BmaConstants.KOSHIN_NAIYO_KBN_MOSHIKOMI_UPDATE);
//                        }
//                    } else if (BmaConstants.HOSEI_IRAI_KBN_KAKUNIN_ZUMI.equals(moshikomi.getHoseiIraiKbn())) {
//                        /*�@�X�V�O�␳�˗��敪���u�␳�˗��m�F�ς݁v�Ł@�u�n�j�v�̏ꍇ�@���@�u�␳�˗��m�F�ς݁v�i�X�V�Ȃ��j*/
//                        if (BmaConstants.FLG_ON.equals(hanteiFlg)) {
//                            moshikomi.setHoseiIraiKbn(BmaConstants.HOSEI_IRAI_KBN_KAKUNIN_ZUMI);
//                            moshikomi.setKoshinNaiyoKbn(BmaConstants.KOSHIN_NAIYO_KBN_MOSHIKOMI_UPDATE);
//                        }
//                        /*�@�X�V�O�␳�˗��敪���u�␳�˗��m�F�ς݁v�Ł@�u�m�f�v�̏ꍇ�@���@�u�␳�˗��m�F�ς݁v�i�X�V�Ȃ��jerror*/
//                        if (BmaConstants.FLG_OFF.equals(hanteiFlg)) {
//                            moshikomi.setHoseiIraiKbn(BmaConstants.HOSEI_IRAI_KBN_KAKUNIN_ZUMI);
//                            moshikomi.setKoshinNaiyoKbn(BmaConstants.KOSHIN_NAIYO_KBN_MOSHIKOMI_UPDATE);
//                        }
//                    }
//
//                    /*���̑��l���Z�b�g*/
//                    moshikomi.setShoriKbn(BmaConstants.SHORI_KBN_UPDATE);
//                    moshikomi.setKoshinDate(sysTime.getymd1());
//                    moshikomi.setKoshinTime(sysTime.gethms1());
//                    moshikomi.setKoshinProgramId(this.getClass().getSimpleName());
//                    moshikomi.setKoshinUserId(inSession.getKanrishaId());
//                    /* ���X�V */
//                    moshikomi.update();
//                    sb.append(moshikomi.getUserId()).append(" ");
//                }
//
//            }
//
//            /*�R�~�b�g*/
//            commitTransaction();
//            
//            log.Update(sb.toString());
//
//            return true;
//
//        } catch (Exception e) {
//            /*���[���o�b�N*/
//            rollbackTransaction();
//            throw e;
//        }
//    }
//    
//    /**
//     * �ύX�`�F�b�N������B
//     *
//     * @param inRequest
//     * @param inSession
//     */
//    private boolean validateModify(MgrKaoPhotoSearch inRequest, MgrKaoPhotoSearch inSession) {
//        
//        Messages errors = new Messages();
//
//        int changeCount = 0;
//        
//        changeCount += !StringUtility.convertNullToBlank(inRequest.getHoseiIraiKbn()).equals(inSession.getHoseiIraiKbn()) ? 1 : 0;
//        changeCount += !StringUtility.convertNullToBlank(inRequest.getKuroShashinFlg()).equals(inSession.getKuroShashinFlg()) ? 1 : 0;
//        changeCount += !StringUtility.convertNullToBlank(inRequest.getHoseiIraiRiyu()).equals(inSession.getHoseiIraiRiyu()) ? 1 : 0;
//        changeCount += !StringUtility.convertNullToBlank(inRequest.getKakuninIraiSoshinFlg()).equals(inSession.getKakuninIraiSoshinFlg()) ? 1 : 0;
//        changeCount += !StringUtility.convertNullToBlank(inRequest.getKakuninIraiSoshinNen()).equals(inSession.getKakuninIraiSoshinNen()) ? 1 : 0;
//        changeCount += !StringUtility.convertNullToBlank(inRequest.getKakuninIraiSoshinTsuki()).equals(inSession.getKakuninIraiSoshinTsuki()) ? 1 : 0;
//        changeCount += !StringUtility.convertNullToBlank(inRequest.getKakuninIraiSoshinBi()).equals(inSession.getKakuninIraiSoshinBi()) ? 1 : 0;
//        
//        if (changeCount == 0) {
//            /*�ύX������Ȃ������Ƃ��G���[*/
//            BmaValidator.addMessage(errors, "info", BmaText.E00038, "");
//            inSession.setErrors(errors);
//            return false;
//        }
//
//        return true;
//
//    }
//
//    /**
//     * ���͒l���Z�b�V����RTO�ɃZ�b�g����B
//     *
//     * @param inRequest
//     * @param inSession
//     */
//    private void setHoseiIraiInputDataToSession(MgrKaoPhotoSearch inRequest, MgrKaoPhotoSearch inSession) {
//        
//        inSession.setHoseiIraiKbn(StringUtility.convertNullToBlank(inRequest.getHoseiIraiKbn()));
//        inSession.setKuroShashinFlg(StringUtility.convertNullToBlank(inRequest.getKuroShashinFlg()));
//        inSession.setHoseiIraiRiyu(StringUtility.convertNullToBlank(inRequest.getHoseiIraiRiyu()));
//        inSession.setKakuninIraiSoshinFlg(StringUtility.convertNullToBlank(inRequest.getKakuninIraiSoshinFlg()));
//        if(BmaConstants.KAKUNIN_IRAI_SOSHIN_ZUMI.equals(inSession.getKakuninIraiSoshinFlg())) {
//            inSession.setKakuninIraiSoshinNen(StringUtility.convertNullToBlank(inRequest.getKakuninIraiSoshinNen()));
//            inSession.setKakuninIraiSoshinTsuki(StringUtility.convertNullToBlank(inRequest.getKakuninIraiSoshinTsuki()));
//            inSession.setKakuninIraiSoshinBi(StringUtility.convertNullToBlank(inRequest.getKakuninIraiSoshinBi()));
//        } else {
//            inSession.setKakuninIraiSoshinNen("");
//            inSession.setKakuninIraiSoshinTsuki("");
//            inSession.setKakuninIraiSoshinBi("");
//        }
//        
//        /*���p��S�p�ɒ���*/
//        inSession.setHoseiIraiRiyu(BmaStringUtility.convertHankakuToZenkakuBma(inSession.getHoseiIraiRiyu()));
//
//    }
//
//    /**
//     * ��ʐ^�␳�˗����̓`�F�b�N
//     *
//     * @param InputInSession
//     * @param errors
//     * @return
//     */
//    private boolean validateHoseiIrai(MgrKaoPhotoSearch inSession) {
//        Messages errors = new Messages();
//        /*���͏�񂩂痼�[�̋󔒂��폜*/
//        inSession.trimStringInputHoseiIraiField();
//        
//        String groupCode;
//        String itemName;
//        /*�␳�˗��敪*/
//        groupCode = "hoseiIraiKbn";
//        itemName = "�␳�˗��敪";
//        String kbnList[] = new String[]{BmaConstants.HOSEI_IRAI_KBN_IRAI_NASHI, BmaConstants.HOSEI_IRAI_KBN_HOSEI_IRAI, BmaConstants.HOSEI_IRAI_KBN_HOSEI_ZUMI, BmaConstants.HOSEI_IRAI_KBN_KAKUNIN_ZUMI};
//        BmaValidator.validatePermissionSelect(inSession.getHoseiIraiKbn(), kbnList, errors, groupCode, itemName);
//        /*���ʐ^�t���O*/
//        itemName = "���ʐ^";
//        groupCode = "kuroShashinFlg";
//        BmaValidator.validatePermissionSelect(inSession.getKuroShashinFlg(), new String[]{BmaConstants.KURO_SHASHIN_FLG_OFF, BmaConstants.KURO_SHASHIN_FLG_ON}, errors, groupCode, itemName);
//        /*�␳�˗����R*/
//        groupCode = "hoseiIraiRiyu";
//        itemName = "�␳���R";
//        BmaValidator.validateMojiCodeBmaVarious(inSession.getHoseiIraiRiyu(), errors, groupCode, itemName);
//        BmaValidator.validateMaxLength(inSession.getHoseiIraiRiyu(), BmaConstants.MAX_LENGTH_HOSEI_RIYU, errors, groupCode, itemName);
//        /*�m�F�˗��A��*/
//        itemName = "�m�F�˗��A��";
//        groupCode = "kakuninIraiSoshin";
//        BmaValidator.validatePermissionSelect(inSession.getKakuninIraiSoshinFlg(), new String[]{BmaConstants.KAKUNIN_IRAI_MI_SOSHIN, BmaConstants.KAKUNIN_IRAI_SOSHIN_ZUMI}, errors, groupCode, itemName);
//        itemName = "�m�F�˗��A���N";
//        BmaValidator.validatePermissionSelect(inSession.getKakuninIraiSoshinNen(), inSession.getYearDisp(), errors, groupCode, itemName);
//        itemName = "�m�F�˗��A����";
//        BmaValidator.validatePermissionSelect(inSession.getKakuninIraiSoshinTsuki(), inSession.getMonthDisp(), errors, groupCode, itemName);
//        itemName = "�m�F�˗��A����";
//        BmaValidator.validatePermissionSelect(inSession.getKakuninIraiSoshinBi(), inSession.getDayDisp(), errors, groupCode, itemName);
//        BmaValidator.validateDate(inSession.getKakuninIraiSoshinNen()+inSession.getKakuninIraiSoshinTsuki()+inSession.getKakuninIraiSoshinBi(), errors, groupCode, itemName);
//        if(BmaConstants.KAKUNIN_IRAI_SOSHIN_ZUMI.equals(inSession.getKakuninIraiSoshinFlg())) {
//            BmaValidator.validateRequired(inSession.getKakuninIraiSoshinNen()+inSession.getKakuninIraiSoshinTsuki()+inSession.getKakuninIraiSoshinBi(), errors, groupCode, itemName);
//        }
//        
//        inSession.setErrors(errors);
//        return errors.isEmpty();
//    }
//
//    /**
//     * �\���e�[�u���X�V�����i�␳�˗��敪�E�␳�˗����R�j
//     *
//     * @param inSession �Z�b�V����RTO
//     * @return true:����
//     * @throws Exception ��O
//     */
//    private boolean updateHoseiIraiMoshikomiData(MgrKaoPhotoSearch inSession) throws Exception {
//
//        Moshikomi beforeMoshikomi = new Moshikomi(DATA_SOURCE_NAME);
//        Moshikomi updMoshikomi = new Moshikomi(DATA_SOURCE_NAME);
//
//        try {
//            getTransaction();
//            beginTransaction();
//
//            /*�\���A�\���҃e�[�u�������b�N���Ď擾*/
//            BeanUtils.copyProperties(beforeMoshikomi, beforeMoshikomi.findRetry(BmaConstants.NEN, inSession.getMoshikomiUketsukeNo()));
//
//            /* �ύX�OBO����X�V�pBO�ɒl���R�s�[ */
//            BeanUtils.copyProperties(updMoshikomi, beforeMoshikomi);
//
//            /*�ύX�l���Z�b�g*/
//            updMoshikomi.setHoseiIraiKbn(inSession.getHoseiIraiKbn());
//            updMoshikomi.setHoseiIraiRiyu(inSession.getHoseiIraiRiyu());
//            updMoshikomi.setKuroShashinFlg(inSession.getKuroShashinFlg());
//            updMoshikomi.setKakuninIraiSoshinFlg(inSession.getKakuninIraiSoshinFlg());
//            updMoshikomi.setKakuninIraiSoshinBi(inSession.getKakuninIraiSoshinNen()+inSession.getKakuninIraiSoshinTsuki()+inSession.getKakuninIraiSoshinBi());
//
//            SystemTime sysTime = new SystemTime();
//
//            if (!updMoshikomi.getHoseiIraiKbn().equals(beforeMoshikomi.getHoseiIraiKbn())) {
//                /*�␳�˗��ɕύX���������ꍇ*/
//                if (inSession.getHoseiIraiKbn().equals(BmaConstants.HOSEI_IRAI_KBN_HOSEI_IRAI)) {
//                    /*�␳�˗����o�����ꍇ�͕␳�˗�����ݒ�*/
//                    updMoshikomi.setHoseiIraiBi(sysTime.getymd1());
//                    updMoshikomi.setHoseiIraiTime(sysTime.gethms1());
//                } else if (inSession.getHoseiIraiKbn().equals(BmaConstants.HOSEI_IRAI_KBN_HOSEI_ZUMI)) {
//                    /*�␳�ςɂ����ꍇ�͕␳�Ή�����ݒ�*/
//                    updMoshikomi.setHoseiTaioBi(sysTime.getymd1());
//                    updMoshikomi.setHoseiTaioTime(sysTime.gethms1());
//                } else if (inSession.getHoseiIraiKbn().equals(BmaConstants.HOSEI_IRAI_KBN_KAKUNIN_ZUMI)) {
//                    /*�␳�m�F�ςɂ����ꍇ�͕␳�m�F����ݒ�*/
//                    updMoshikomi.setHoseiFinishBi(sysTime.getymd1());
//                    updMoshikomi.setHoseiFinishTime(sysTime.gethms1());
//                }
//            }
//
//            /*���̑��l���Z�b�g*/
//            updMoshikomi.setKoshinNaiyoKbn(BmaConstants.KOSHIN_NAIYO_KBN_MOSHIKOMI_UPDATE);
//            updMoshikomi.setShoriKbn(BmaConstants.SHORI_KBN_UPDATE);
//            updMoshikomi.setKoshinDate(sysTime.getymd1());
//            updMoshikomi.setKoshinTime(sysTime.gethms1());
//            updMoshikomi.setKoshinProgramId(this.getClass().getSimpleName());
//            updMoshikomi.setKoshinUserId(inSession.getKanrishaId());
//
//            /* ���X�V */
//            updMoshikomi.update();
//
//            /*�R�~�b�g*/
//            commitTransaction();
//
//            log.Update(inSession.getKanrishaId());
//
//        } catch (Exception e) {
//            /*���[���o�b�N*/
//            rollbackTransaction();
//            throw e;
//        }
//        return true;
//    }
//    
//    
//    /**
//     * �␳�����Ď擾����B
//     *
//     * @param inSession �Z�b�V����RTO
//     * @param moshikomiUketsukeNo �\����t�ԍ�
//     * @throws Exception ��O
//     */
//    private void setHoseiDetailJoho(MgrKaoPhotoSearch inSession) throws Exception {
//        String moshikomiUketsukeNo = inSession.getMoshikomiUketsukeNo();
//        Moshikomi moshikomi = new Moshikomi(DATA_SOURCE_NAME);
//        moshikomi = moshikomi.find(BmaConstants.NEN, moshikomiUketsukeNo);
//        
//        BeanUtils.copyProperties(inSession, moshikomi);
//        
//        if (!BmaUtility.isNullOrEmpty(inSession.getKakuninIraiSoshinBi())) {
//            /* �m�F�˗����M��������� */
//            String date  = inSession.getKakuninIraiSoshinBi();
//            inSession.setKakuninIraiSoshinNen(date.substring(0,4));
//            inSession.setKakuninIraiSoshinTsuki(date.substring(4,6));
//            inSession.setKakuninIraiSoshinBi(date.substring(6,8));
//        }
//        
//        
//    }
//
//}
