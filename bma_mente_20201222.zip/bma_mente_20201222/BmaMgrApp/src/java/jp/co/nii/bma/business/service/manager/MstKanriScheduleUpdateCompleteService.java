package jp.co.nii.bma.business.service.manager;

import java.util.List;
import java.util.ArrayList;
import java.util.LinkedList;
import jp.co.nii.bma.business.domain.Ryokin;
import jp.co.nii.bma.business.rto.manager.MstKanriScheduleJoho;
import jp.co.nii.bma.business.domain.SknksuMst;
import jp.co.nii.bma.business.service.common.BmaConstants;
import jp.co.nii.bma.business.service.common.BmaLogger;
import jp.co.nii.bma.utility.BmaUtility;
import jp.co.nii.sew.business.service.AbstractService;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_SESSION;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_SUCCESS;
import jp.co.nii.sew.presentation.Messages;
import jp.co.nii.sew.presentation.Option;
import jp.co.nii.sew.presentation.RequestTransferObject;
import jp.co.nii.sew.utility.PropertyUtility;

/**
 *
 * @author nii19042
 */
public class MstKanriScheduleUpdateCompleteService extends AbstractService {

    /**
     * DB�ڑ��̃f�[�^�\�[�X
     */
    private static String DATA_SOURCE_NAME;
    /**
     * ���O
     */
    BmaLogger log = (BmaLogger) BmaLogger.getLogger(this.getClass().getName());
    /**
     * �Ɩ��R�[�h
     */
    private static final String BUSINESS_CODE = PropertyUtility.getProperty("business_code");
    /**
     * ���׃e�X�g���[�h
     */
    private static final String STRESS_MODE = PropertyUtility.getProperty(BUSINESS_CODE + "stress_mode");

    /**
     * �R���X�g���N�^
     */
    public MstKanriScheduleUpdateCompleteService() {
        super();
        /* DB�ڑ����̃��[�U�[������ */
        DATA_SOURCE_NAME = BmaConstants.DS_REGISTRANT;
    }

    /**
     * �T�[�r�X�N���X�̎��s���\�b�h
     *
     * @param rto ���N�G�X�g��񂩂�擾����rto
     * @param rtoInSession �Z�b�V�������rto
     * @return foward��
     * @throws Exception ��O
     */
    @Override
    public String doService(RequestTransferObject rto, RequestTransferObject rtoInSession)
            throws Exception {

        MstKanriScheduleJoho inRequest = (MstKanriScheduleJoho) rto;
        MstKanriScheduleJoho inSession = (MstKanriScheduleJoho) rtoInSession;
        String processName = "";

        /*�G���[���b�Z�[�W������*/
        inSession.setErrors(new Messages());
        try {
        if (!BmaUtility.isNullOrEmpty(inRequest.getScheduleUpdCompBack())) {
                /*�u�ꗗ�֖߂�v�{�^��������*/
                processName = "MstKanriScheduleUpdateComplete";
                log.Start(processName);

                /* �c���Ă���Z�b�V������j�� */
                inSession.setSknksuKbn("1");
                inSession.setSknName("");
                inSession.setKsuName("");
                inSession.setNendo("");
                inSession.setScheduleSrcListFlg("");
                inSession.setScheduleSearchList(new LinkedList<MstKanriScheduleJoho>());
                inSession.setScheduleResultList(new LinkedList<MstKanriScheduleJoho>());
                inSession.setScheduleInputList(new LinkedList<MstKanriScheduleJoho>());
                inSession.setScheduleUpdateList(new LinkedList<MstKanriScheduleJoho>());
                
                /* �u�X�P�W���[�������v��ʕ\�� */
                return FWD_NM_SUCCESS;
        } else {
                /*�ُ�J��*/
                log.IllegalFWD();
                return FWD_NM_SESSION;
            }
        } catch (Exception e) {
            return FWD_NM_EXCEPTION;
        } finally {
            log.End(processName);
        }
    }
}