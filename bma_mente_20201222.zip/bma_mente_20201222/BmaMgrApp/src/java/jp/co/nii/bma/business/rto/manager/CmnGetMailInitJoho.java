package jp.co.nii.bma.business.rto.manager;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import jp.co.nii.bma.business.service.common.BmaConstants;
import jp.co.nii.bma.utility.BmaDateTimeUtility;
import jp.co.nii.sew.presentation.DownloadRTO;
import jp.co.nii.sew.presentation.Messages;
import jp.co.nii.sew.presentation.Option;
import jp.co.nii.sew.utility.StringUtility;
import org.apache.commons.fileupload.disk.DiskFileItem;

/**
 * �^�C�g��: TOP��� ����: TOP���RTO ���쌠: Copyright (c) 2020 ��Ж�: ���{���Y�Ɗ������
 */
public class CmnGetMailInitJoho {
    /** 
     * 2015-11-09 add
     * ��ԋ敪 */
    private String jotaiKbn= "";
    /** �ӔC�҂h�c */
    private String sekininshaId= "";
    /** �\���҂h�c */
    private String moshikomishaId= "";
    /** ���O�\���҂h�c */
    private String jizenMoshikomishaId= "";
    /** �Ǘ��҂h�c */
    private String kanrishaId= "";
    /**
     * ���[���R�[�h
     */
    private String mailCode = "";
    /**
     * ���惁�[���A�h���X
     */
    private String mailAddress = "";
    /**
     * ���[�����M����
     */
    private String mailKenmei = "";    
    /**
     * ��������01
     */
    private String impParam01 = "";
    /**
     * ��������02
     */
    private String impParam02 = "";
    /**
     * ��������03
     */
    private String impParam03 = "";
    /**
     * ��������04
     */
    private String impParam04 = "";
    /**
     * ��������05
     */
    private String impParam05 = "";
    /**
     * ��������06
     */
    private String impParam06 = "";
    /**
     * ��������07
     */
    private String impParam07 = "";
    /**
     * ��������08
     */
    private String impParam08 = "";
    /**
     * ��������09
     */
    private String impParam09 = "";
    /**
     * ��������10
     */
    private String impParam10 = "";
    /**
     * ��������11
     */
    private String impParam11 = "";
    /**
     * ��������12
     */
    private String impParam12 = "";
    /**
     * ��������13
     */
    private String impParam13 = "";
    /**
     * ��������14
     */
    private String impParam14 = "";
    /**
     * ��������15
     */
    private String impParam15 = "";
    /**
     * ��������16
     */
    private String impParam16 = "";
    /**
     * ��������17
     */
    private String impParam17 = "";
    /**
     * ��������18
     */
    private String impParam18 = "";
    /**
     * ��������19
     */
    private String impParam19 = "";
    /**
     * ��������20
     */
    private String impParam20 = "";    
    /**
     * ��������21
     */
    private String impParam21 = "";    
    /**
     * ��������22
     */
    private String impParam22 = "";    
    /**
     * ��������23
     */
    private String impParam23 = "";    
    /**
     * ��������24
     */
    private String impParam24 = "";    
    /**
     * ��������25
     */
    private String impParam25 = "";    
    /**
     * ��������26
     */
    private String impParam26 = "";    
    /**
     * ��������27
     */
    private String impParam27 = "";    
    /**
     * ��������28
     */
    private String impParam28 = "";    
    /**
     * ��������29
     */
    private String impParam29 = "";    
    /**
     * ��������30
     */
    private String impParam30 = "";    
    /**
     * ��������31
     */
    private String impParam31 = "";    
    /**
     * ��������32
     */
    private String impParam32 = "";    
    /**
     * ��������33
     */
    private String impParam33 = "";    
    /**
     * ��������34
     */
    private String impParam34 = "";    
    /**
     * ��������35
     */
    private String impParam35 = "";    
    /**
     * ��������36
     */
    private String impParam36 = "";    
    /**
     * ��������37
     */
    private String impParam37 = "";    
    /**
     * ��������38
     */
    private String impParam38 = "";    
    /**
     * ��������39
     */
    private String impParam39 = "";    
    /**
     * ��������40
     */
    private String impParam40 = "";    
    /**
     * ��������41
     */
    private String impParam41 = "";    
    /**
     * ��������42
     */
    private String impParam42 = "";    
    /**
     * ��������43
     */
    private String impParam43 = "";    
    /**
     * ��������44
     */
    private String impParam44 = "";    
    /**
     * ��������45
     */
    private String impParam45 = "";    
    /**
     * ��������46
     */
    private String impParam46 = "";    
    /**
     * ��������47
     */
    private String impParam47 = "";    
    /**
     * ��������48
     */
    private String impParam48 = "";    
    /**
     * ��������49
     */
    private String impParam49 = "";    
    /**
     * ��������50
     */
    private String impParam50 = "";    
    /**
     * ��������51
     */
    private String impParam51 = "";    
    /**
     * ��������52
     */
    private String impParam52 = "";    
    /**
     * ��������53
     */
    private String impParam53 = "";    
    /**
     * ��������54
     */
    private String impParam54 = "";    
    /**
     * ��������55
     */
    private String impParam55 = "";    
    /**
     * ��������56
     */
    private String impParam56 = "";    
    /**
     * ��������57
     */
    private String impParam57 = "";    
    /**
     * ��������58
     */
    private String impParam58 = "";    
    /**
     * ��������59
     */
    private String impParam59 = "";    
    /**
     * ��������60
     */
    private String impParam60 = "";    
    /**
     * ��������61
     */
    private String impParam61 = "";    
    /**
     * ��������62
     */
    private String impParam62 = "";    
    /**
     * ��������63
     */
    private String impParam63 = "";    
    /**
     * ��������64
     */
    private String impParam64 = "";    
    /**
     * ��������65
     */
    private String impParam65 = "";    
    /**
     * ��������66
     */
    private String impParam66 = "";    
    /**
     * ��������67
     */
    private String impParam67 = "";    
    /**
     * ��������68
     */
    private String impParam68 = "";    
    /**
     * ��������69
     */
    private String impParam69 = "";    
    /**
     * ��������70
     */
    private String impParam70 = "";    
    /**
     * ���M����
     */
    private Timestamp soshinNichiji = null;    
    /**
     * ���M�σt���O
     */
    private String SentFlg = "";   
    /**
     * �{��
     */
    private String mailHonbun = "";    
    /**
     * �t�b�^�[
     */
    private String mailFooter= "";    
    /**
     * �u������01
     */
    private String mailParam01 = "";
    /**
     * �u������02
     */
    private String mailParam02 = "";
    /**
     * �u������03
     */
    private String mailParam03 = "";
    /**
     * �u������04
     */
    private String mailParam04 = "";
    /**
     * �u������05
     */
    private String mailParam05 = "";
    /**
     * �u������06
     */
    private String mailParam06 = "";
    /**
     * �u������07
     */
    private String mailParam07 = "";
    /**
     * �u������08
     */
    private String mailParam08 = "";
    /**
     * �u������09
     */
    private String mailParam09 = "";
    /**
     * �u������10
     */
    private String mailParam10 = "";
    /**
     * �u������11
     */
    private String mailParam11 = "";
    /**
     * �u������12
     */
    private String mailParam12 = "";
    /**
     * �u������13
     */
    private String mailParam13 = "";
    /**
     * �u������14
     */
    private String mailParam14 = "";
    /**
     * �u������15
     */
    private String mailParam15 = "";
    /**
     * �u������16
     */
    private String mailParam16 = "";
    /**
     * �u������17
     */
    private String mailParam17 = "";
    /**
     * �u������18
     */
    private String mailParam18 = "";
    /**
     * �u������19
     */
    private String mailParam19 = "";
    /**
     * �u������20
     */
    private String mailParam20 = "";    
    /**
     * �u������21
     */
    private String mailParam21 = "";    
    /**
     * �u������22
     */
    private String mailParam22 = "";    
    /**
     * �u������23
     */
    private String mailParam23 = "";    
    /**
     * �u������24
     */
    private String mailParam24 = "";    
    /**
     * �u������25
     */
    private String mailParam25 = "";    
    /**
     * �u������26
     */
    private String mailParam26 = "";    
    /**
     * �u������27
     */
    private String mailParam27 = "";    
    /**
     * �u������28
     */
    private String mailParam28 = "";    
    /**
     * �u������29
     */
    private String mailParam29 = "";    
    /**
     * �u������30
     */
    private String mailParam30 = "";    
    /**
     * �u������31
     */
    private String mailParam31 = "";    
    /**
     * �u������32
     */
    private String mailParam32 = "";    
    /**
     * �u������33
     */
    private String mailParam33 = "";    
    /**
     * �u������34
     */
    private String mailParam34 = "";    
    /**
     * �u������35
     */
    private String mailParam35 = "";    
    /**
     * �u������36
     */
    private String mailParam36 = "";    
    /**
     * �u������37
     */
    private String mailParam37 = "";    
    /**
     * �u������38
     */
    private String mailParam38 = "";    
    /**
     * �u������39
     */
    private String mailParam39 = "";    
    /**
     * �u������40
     */
    private String mailParam40 = "";    
    /**
     * �u������41
     */
    private String mailParam41 = "";    
    /**
     * �u������42
     */
    private String mailParam42 = "";    
    /**
     * �u������43
     */
    private String mailParam43 = "";    
    /**
     * �u������44
     */
    private String mailParam44 = "";    
    /**
     * �u������45
     */
    private String mailParam45 = "";    
    /**
     * �u������46
     */
    private String mailParam46 = "";    
    /**
     * �u������47
     */
    private String mailParam47 = "";    
    /**
     * �u������48
     */
    private String mailParam48 = "";    
    /**
     * �u������49
     */
    private String mailParam49 = "";    
    /**
     * �u������50
     */
    private String mailParam50 = "";    
    /**
     * �u������51
     */
    private String mailParam51 = "";    
    /**
     * �u������52
     */
    private String mailParam52 = "";    
    /**
     * �u������53
     */
    private String mailParam53 = "";    
    /**
     * �u������54
     */
    private String mailParam54 = "";    
    /**
     * �u������55
     */
    private String mailParam55 = "";    
    /**
     * �u������56
     */
    private String mailParam56 = "";    
    /**
     * �u������57
     */
    private String mailParam57 = "";    
    /**
     * �u������58
     */
    private String mailParam58 = "";    
    /**
     * �u������59
     */
    private String mailParam59 = "";    
    /**
     * �u������60
     */
    private String mailParam60 = "";    
    /**
     * �u������61
     */
    private String mailParam61 = "";    
    /**
     * �u������62
     */
    private String mailParam62 = "";    
    /**
     * �u������63
     */
    private String mailParam63 = "";    
    /**
     * �u������64
     */
    private String mailParam64 = "";    
    /**
     * �u������65
     */
    private String mailParam65 = "";    
    /**
     * �u������66
     */
    private String mailParam66 = "";    
    /**
     * �u������67
     */
    private String mailParam67 = "";    
    /**
     * �u������68
     */
    private String mailParam68 = "";    
    /**
     * �u������69
     */
    private String mailParam69 = "";    
    /**
     * �u������70
     */
    private String mailParam70 = "";    

    /**
     * 2015-11-09 add
     * ��ԋ敪 ���擾����B
     * @return ��ԋ敪
     */
    public String getJotaiKbn() {
        return jotaiKbn;
    }

    /**
     * 2015-11-09 add
     * ��ԋ敪 ���Z�b�g����B
     * @param jotaiKbn ��ԋ敪
     */
    public void setJotaiKbn(String jotaiKbn) {
        this.jotaiKbn = jotaiKbn;
    }
    
    public String getMailCode() {
        return mailCode;
    }

    public void setMailCode(String mailCode) {
        this.mailCode = mailCode;
    }

    public String getMailAddress() {
        return mailAddress;
    }

    public void setMailAddress(String mailAddress) {
        this.mailAddress = mailAddress;
    }

    public String getMailKenmei() {
        return mailKenmei;
    }

    public void setMailKenmei(String mailKenmei) {
        this.mailKenmei = mailKenmei;
    }

    public String getMailHonbun() {
        return mailHonbun;
    }

    public void setMailHonbun(String mailHonbun) {
        this.mailHonbun = mailHonbun;
    }

    public String getMailFooter() {
        return mailFooter;
    }

    public void setMailFooter(String mailFooter) {
        this.mailFooter = mailFooter;
    }

    public String getImpParam01() {
        return impParam01;
    }

    public void setImpParam01(String impParam01) {
        this.impParam01 = impParam01;
    }

    public String getImpParam02() {
        return impParam02;
    }

    public void setImpParam02(String impParam02) {
        this.impParam02 = impParam02;
    }

    public String getImpParam03() {
        return impParam03;
    }

    public void setImpParam03(String impParam03) {
        this.impParam03 = impParam03;
    }

    public String getImpParam04() {
        return impParam04;
    }

    public void setImpParam04(String impParam04) {
        this.impParam04 = impParam04;
    }

    public String getImpParam05() {
        return impParam05;
    }

    public void setImpParam05(String impParam05) {
        this.impParam05 = impParam05;
    }

    public String getImpParam06() {
        return impParam06;
    }

    public void setImpParam06(String impParam06) {
        this.impParam06 = impParam06;
    }

    public String getImpParam07() {
        return impParam07;
    }

    public void setImpParam07(String impParam07) {
        this.impParam07 = impParam07;
    }

    public String getImpParam08() {
        return impParam08;
    }

    public void setImpParam08(String impParam08) {
        this.impParam08 = impParam08;
    }

    public String getImpParam09() {
        return impParam09;
    }

    public void setImpParam09(String impParam09) {
        this.impParam09 = impParam09;
    }

    public String getImpParam10() {
        return impParam10;
    }

    public void setImpParam10(String impParam10) {
        this.impParam10 = impParam10;
    }

    public String getImpParam11() {
        return impParam11;
    }

    public void setImpParam11(String impParam11) {
        this.impParam11 = impParam11;
    }

    public String getImpParam12() {
        return impParam12;
    }

    public void setImpParam12(String impParam12) {
        this.impParam12 = impParam12;
    }

    public String getImpParam13() {
        return impParam13;
    }

    public void setImpParam13(String impParam13) {
        this.impParam13 = impParam13;
    }

    public String getImpParam14() {
        return impParam14;
    }

    public void setImpParam14(String impParam14) {
        this.impParam14 = impParam14;
    }

    public String getImpParam15() {
        return impParam15;
    }

    public void setImpParam15(String impParam15) {
        this.impParam15 = impParam15;
    }

    public String getImpParam16() {
        return impParam16;
    }

    public void setImpParam16(String impParam16) {
        this.impParam16 = impParam16;
    }

    public String getImpParam17() {
        return impParam17;
    }

    public void setImpParam17(String impParam17) {
        this.impParam17 = impParam17;
    }

    public String getImpParam18() {
        return impParam18;
    }

    public void setImpParam18(String impParam18) {
        this.impParam18 = impParam18;
    }

    public String getImpParam19() {
        return impParam19;
    }

    public void setImpParam19(String impParam19) {
        this.impParam19 = impParam19;
    }

    public String getImpParam20() {
        return impParam20;
    }

    public void setImpParam20(String impParam20) {
        this.impParam20 = impParam20;
    }

    public String getImpParam21() {
        return impParam21;
    }

    public void setImpParam21(String impParam21) {
        this.impParam21 = impParam21;
    }

    public String getImpParam22() {
        return impParam22;
    }

    public void setImpParam22(String impParam22) {
        this.impParam22 = impParam22;
    }

    public String getImpParam23() {
        return impParam23;
    }

    public void setImpParam23(String impParam23) {
        this.impParam23 = impParam23;
    }

    public String getImpParam24() {
        return impParam24;
    }

    public void setImpParam24(String impParam24) {
        this.impParam24 = impParam24;
    }

    public String getImpParam25() {
        return impParam25;
    }

    public void setImpParam25(String impParam25) {
        this.impParam25 = impParam25;
    }

    public String getImpParam26() {
        return impParam26;
    }

    public void setImpParam26(String impParam26) {
        this.impParam26 = impParam26;
    }

    public String getImpParam27() {
        return impParam27;
    }

    public void setImpParam27(String impParam27) {
        this.impParam27 = impParam27;
    }

    public String getImpParam28() {
        return impParam28;
    }

    public void setImpParam28(String impParam28) {
        this.impParam28 = impParam28;
    }

    public String getImpParam29() {
        return impParam29;
    }

    public void setImpParam29(String impParam29) {
        this.impParam29 = impParam29;
    }

    public String getImpParam30() {
        return impParam30;
    }

    public void setImpParam30(String impParam30) {
        this.impParam30 = impParam30;
    }

    public String getImpParam31() {
        return impParam31;
    }

    public void setImpParam31(String impParam31) {
        this.impParam31 = impParam31;
    }

    public String getImpParam32() {
        return impParam32;
    }

    public void setImpParam32(String impParam32) {
        this.impParam32 = impParam32;
    }

    public String getImpParam33() {
        return impParam33;
    }

    public void setImpParam33(String impParam33) {
        this.impParam33 = impParam33;
    }

    public String getImpParam34() {
        return impParam34;
    }

    public void setImpParam34(String impParam34) {
        this.impParam34 = impParam34;
    }

    public String getImpParam35() {
        return impParam35;
    }

    public void setImpParam35(String impParam35) {
        this.impParam35 = impParam35;
    }

    public String getImpParam36() {
        return impParam36;
    }

    public void setImpParam36(String impParam36) {
        this.impParam36 = impParam36;
    }

    public String getImpParam37() {
        return impParam37;
    }

    public void setImpParam37(String impParam37) {
        this.impParam37 = impParam37;
    }

    public String getImpParam38() {
        return impParam38;
    }

    public void setImpParam38(String impParam38) {
        this.impParam38 = impParam38;
    }

    public String getImpParam39() {
        return impParam39;
    }

    public void setImpParam39(String impParam39) {
        this.impParam39 = impParam39;
    }

    public String getImpParam40() {
        return impParam40;
    }

    public void setImpParam40(String impParam40) {
        this.impParam40 = impParam40;
    }

    public String getImpParam41() {
        return impParam41;
    }

    public void setImpParam41(String impParam41) {
        this.impParam41 = impParam41;
    }

    public String getImpParam42() {
        return impParam42;
    }

    public void setImpParam42(String impParam42) {
        this.impParam42 = impParam42;
    }

    public String getImpParam43() {
        return impParam43;
    }

    public void setImpParam43(String impParam43) {
        this.impParam43 = impParam43;
    }

    public String getImpParam44() {
        return impParam44;
    }

    public void setImpParam44(String impParam44) {
        this.impParam44 = impParam44;
    }

    public String getImpParam45() {
        return impParam45;
    }

    public void setImpParam45(String impParam45) {
        this.impParam45 = impParam45;
    }

    public String getImpParam46() {
        return impParam46;
    }

    public void setImpParam46(String impParam46) {
        this.impParam46 = impParam46;
    }

    public String getImpParam47() {
        return impParam47;
    }

    public void setImpParam47(String impParam47) {
        this.impParam47 = impParam47;
    }

    public String getImpParam48() {
        return impParam48;
    }

    public void setImpParam48(String impParam48) {
        this.impParam48 = impParam48;
    }

    public String getImpParam49() {
        return impParam49;
    }

    public void setImpParam49(String impParam49) {
        this.impParam49 = impParam49;
    }

    public String getImpParam50() {
        return impParam50;
    }

    public void setImpParam50(String impParam50) {
        this.impParam50 = impParam50;
    }

    public String getImpParam51() {
        return impParam51;
    }

    public void setImpParam51(String impParam51) {
        this.impParam51 = impParam51;
    }

    public String getImpParam52() {
        return impParam52;
    }

    public void setImpParam52(String impParam52) {
        this.impParam52 = impParam52;
    }

    public String getImpParam53() {
        return impParam53;
    }

    public void setImpParam53(String impParam53) {
        this.impParam53 = impParam53;
    }

    public String getImpParam54() {
        return impParam54;
    }

    public void setImpParam54(String impParam54) {
        this.impParam54 = impParam54;
    }

    public String getImpParam55() {
        return impParam55;
    }

    public void setImpParam55(String impParam55) {
        this.impParam55 = impParam55;
    }

    public String getImpParam56() {
        return impParam56;
    }

    public void setImpParam56(String impParam56) {
        this.impParam56 = impParam56;
    }

    public String getImpParam57() {
        return impParam57;
    }

    public void setImpParam57(String impParam57) {
        this.impParam57 = impParam57;
    }

    public String getImpParam58() {
        return impParam58;
    }

    public void setImpParam58(String impParam58) {
        this.impParam58 = impParam58;
    }

    public String getImpParam59() {
        return impParam59;
    }

    public void setImpParam59(String impParam59) {
        this.impParam59 = impParam59;
    }

    public String getImpParam60() {
        return impParam60;
    }

    public void setImpParam60(String impParam60) {
        this.impParam60 = impParam60;
    }

    public String getImpParam61() {
        return impParam61;
    }

    public void setImpParam61(String impParam61) {
        this.impParam61 = impParam61;
    }

    public String getImpParam62() {
        return impParam62;
    }

    public void setImpParam62(String impParam62) {
        this.impParam62 = impParam62;
    }

    public String getImpParam63() {
        return impParam63;
    }

    public void setImpParam63(String impParam63) {
        this.impParam63 = impParam63;
    }

    public String getImpParam64() {
        return impParam64;
    }

    public void setImpParam64(String impParam64) {
        this.impParam64 = impParam64;
    }

    public String getImpParam65() {
        return impParam65;
    }

    public void setImpParam65(String impParam65) {
        this.impParam65 = impParam65;
    }

    public String getImpParam66() {
        return impParam66;
    }

    public void setImpParam66(String impParam66) {
        this.impParam66 = impParam66;
    }

    public String getImpParam67() {
        return impParam67;
    }

    public void setImpParam67(String impParam67) {
        this.impParam67 = impParam67;
    }

    public String getImpParam68() {
        return impParam68;
    }

    public void setImpParam68(String impParam68) {
        this.impParam68 = impParam68;
    }

    public String getImpParam69() {
        return impParam69;
    }

    public void setImpParam69(String impParam69) {
        this.impParam69 = impParam69;
    }

    public String getImpParam70() {
        return impParam70;
    }

    public void setImpParam70(String impParam70) {
        this.impParam70 = impParam70;
    }

    public String getMailParam01() {
        return mailParam01;
    }

    public void setMailParam01(String mailParam01) {
        this.mailParam01 = mailParam01;
    }

    public String getMailParam02() {
        return mailParam02;
    }

    public void setMailParam02(String mailParam02) {
        this.mailParam02 = mailParam02;
    }

    public String getMailParam03() {
        return mailParam03;
    }

    public void setMailParam03(String mailParam03) {
        this.mailParam03 = mailParam03;
    }

    public String getMailParam04() {
        return mailParam04;
    }

    public void setMailParam04(String mailParam04) {
        this.mailParam04 = mailParam04;
    }

    public String getMailParam05() {
        return mailParam05;
    }

    public void setMailParam05(String mailParam05) {
        this.mailParam05 = mailParam05;
    }

    public String getMailParam06() {
        return mailParam06;
    }

    public void setMailParam06(String mailParam06) {
        this.mailParam06 = mailParam06;
    }

    public String getMailParam07() {
        return mailParam07;
    }

    public void setMailParam07(String mailParam07) {
        this.mailParam07 = mailParam07;
    }

    public String getMailParam08() {
        return mailParam08;
    }

    public void setMailParam08(String mailParam08) {
        this.mailParam08 = mailParam08;
    }

    public String getMailParam09() {
        return mailParam09;
    }

    public void setMailParam09(String mailParam09) {
        this.mailParam09 = mailParam09;
    }

    public String getMailParam10() {
        return mailParam10;
    }

    public void setMailParam10(String mailParam10) {
        this.mailParam10 = mailParam10;
    }

    public String getMailParam11() {
        return mailParam11;
    }

    public void setMailParam11(String mailParam11) {
        this.mailParam11 = mailParam11;
    }

    public String getMailParam12() {
        return mailParam12;
    }

    public void setMailParam12(String mailParam12) {
        this.mailParam12 = mailParam12;
    }

    public String getMailParam13() {
        return mailParam13;
    }

    public void setMailParam13(String mailParam13) {
        this.mailParam13 = mailParam13;
    }

    public String getMailParam14() {
        return mailParam14;
    }

    public void setMailParam14(String mailParam14) {
        this.mailParam14 = mailParam14;
    }

    public String getMailParam15() {
        return mailParam15;
    }

    public void setMailParam15(String mailParam15) {
        this.mailParam15 = mailParam15;
    }

    public String getMailParam16() {
        return mailParam16;
    }

    public void setMailParam16(String mailParam16) {
        this.mailParam16 = mailParam16;
    }

    public String getMailParam17() {
        return mailParam17;
    }

    public void setMailParam17(String mailParam17) {
        this.mailParam17 = mailParam17;
    }

    public String getMailParam18() {
        return mailParam18;
    }

    public void setMailParam18(String mailParam18) {
        this.mailParam18 = mailParam18;
    }

    public String getMailParam19() {
        return mailParam19;
    }

    public void setMailParam19(String mailParam19) {
        this.mailParam19 = mailParam19;
    }

    public String getMailParam20() {
        return mailParam20;
    }

    public void setMailParam20(String mailParam20) {
        this.mailParam20 = mailParam20;
    }

    public String getMailParam21() {
        return mailParam21;
    }

    public void setMailParam21(String mailParam21) {
        this.mailParam21 = mailParam21;
    }

    public String getMailParam22() {
        return mailParam22;
    }

    public void setMailParam22(String mailParam22) {
        this.mailParam22 = mailParam22;
    }

    public String getMailParam23() {
        return mailParam23;
    }

    public void setMailParam23(String mailParam23) {
        this.mailParam23 = mailParam23;
    }

    public String getMailParam24() {
        return mailParam24;
    }

    public void setMailParam24(String mailParam24) {
        this.mailParam24 = mailParam24;
    }

    public String getMailParam25() {
        return mailParam25;
    }

    public void setMailParam25(String mailParam25) {
        this.mailParam25 = mailParam25;
    }

    public String getMailParam26() {
        return mailParam26;
    }

    public void setMailParam26(String mailParam26) {
        this.mailParam26 = mailParam26;
    }

    public String getMailParam27() {
        return mailParam27;
    }

    public void setMailParam27(String mailParam27) {
        this.mailParam27 = mailParam27;
    }

    public String getMailParam28() {
        return mailParam28;
    }

    public void setMailParam28(String mailParam28) {
        this.mailParam28 = mailParam28;
    }

    public String getMailParam29() {
        return mailParam29;
    }

    public void setMailParam29(String mailParam29) {
        this.mailParam29 = mailParam29;
    }

    public String getMailParam30() {
        return mailParam30;
    }

    public void setMailParam30(String mailParam30) {
        this.mailParam30 = mailParam30;
    }

    public String getMailParam31() {
        return mailParam31;
    }

    public void setMailParam31(String mailParam31) {
        this.mailParam31 = mailParam31;
    }

    public String getMailParam32() {
        return mailParam32;
    }

    public void setMailParam32(String mailParam32) {
        this.mailParam32 = mailParam32;
    }

    public String getMailParam33() {
        return mailParam33;
    }

    public void setMailParam33(String mailParam33) {
        this.mailParam33 = mailParam33;
    }

    public String getMailParam34() {
        return mailParam34;
    }

    public void setMailParam34(String mailParam34) {
        this.mailParam34 = mailParam34;
    }

    public String getMailParam35() {
        return mailParam35;
    }

    public void setMailParam35(String mailParam35) {
        this.mailParam35 = mailParam35;
    }

    public String getMailParam36() {
        return mailParam36;
    }

    public void setMailParam36(String mailParam36) {
        this.mailParam36 = mailParam36;
    }

    public String getMailParam37() {
        return mailParam37;
    }

    public void setMailParam37(String mailParam37) {
        this.mailParam37 = mailParam37;
    }

    public String getMailParam38() {
        return mailParam38;
    }

    public void setMailParam38(String mailParam38) {
        this.mailParam38 = mailParam38;
    }

    public String getMailParam39() {
        return mailParam39;
    }

    public void setMailParam39(String mailParam39) {
        this.mailParam39 = mailParam39;
    }

    public String getMailParam40() {
        return mailParam40;
    }

    public void setMailParam40(String mailParam40) {
        this.mailParam40 = mailParam40;
    }

    public String getMailParam41() {
        return mailParam41;
    }

    public void setMailParam41(String mailParam41) {
        this.mailParam41 = mailParam41;
    }

    public String getMailParam42() {
        return mailParam42;
    }

    public void setMailParam42(String mailParam42) {
        this.mailParam42 = mailParam42;
    }

    public String getMailParam43() {
        return mailParam43;
    }

    public void setMailParam43(String mailParam43) {
        this.mailParam43 = mailParam43;
    }

    public String getMailParam44() {
        return mailParam44;
    }

    public void setMailParam44(String mailParam44) {
        this.mailParam44 = mailParam44;
    }

    public String getMailParam45() {
        return mailParam45;
    }

    public void setMailParam45(String mailParam45) {
        this.mailParam45 = mailParam45;
    }

    public String getMailParam46() {
        return mailParam46;
    }

    public void setMailParam46(String mailParam46) {
        this.mailParam46 = mailParam46;
    }

    public String getMailParam47() {
        return mailParam47;
    }

    public void setMailParam47(String mailParam47) {
        this.mailParam47 = mailParam47;
    }

    public String getMailParam48() {
        return mailParam48;
    }

    public void setMailParam48(String mailParam48) {
        this.mailParam48 = mailParam48;
    }

    public String getMailParam49() {
        return mailParam49;
    }

    public void setMailParam49(String mailParam49) {
        this.mailParam49 = mailParam49;
    }

    public String getMailParam50() {
        return mailParam50;
    }

    public void setMailParam50(String mailParam50) {
        this.mailParam50 = mailParam50;
    }

    public String getMailParam51() {
        return mailParam51;
    }

    public void setMailParam51(String mailParam51) {
        this.mailParam51 = mailParam51;
    }

    public String getMailParam52() {
        return mailParam52;
    }

    public void setMailParam52(String mailParam52) {
        this.mailParam52 = mailParam52;
    }

    public String getMailParam53() {
        return mailParam53;
    }

    public void setMailParam53(String mailParam53) {
        this.mailParam53 = mailParam53;
    }

    public String getMailParam54() {
        return mailParam54;
    }

    public void setMailParam54(String mailParam54) {
        this.mailParam54 = mailParam54;
    }

    public String getMailParam55() {
        return mailParam55;
    }

    public void setMailParam55(String mailParam55) {
        this.mailParam55 = mailParam55;
    }

    public String getMailParam56() {
        return mailParam56;
    }

    public void setMailParam56(String mailParam56) {
        this.mailParam56 = mailParam56;
    }

    public String getMailParam57() {
        return mailParam57;
    }

    public void setMailParam57(String mailParam57) {
        this.mailParam57 = mailParam57;
    }

    public String getMailParam58() {
        return mailParam58;
    }

    public void setMailParam58(String mailParam58) {
        this.mailParam58 = mailParam58;
    }

    public String getMailParam59() {
        return mailParam59;
    }

    public void setMailParam59(String mailParam59) {
        this.mailParam59 = mailParam59;
    }

    public String getMailParam60() {
        return mailParam60;
    }

    public void setMailParam60(String mailParam60) {
        this.mailParam60 = mailParam60;
    }

    public String getMailParam61() {
        return mailParam61;
    }

    public void setMailParam61(String mailParam61) {
        this.mailParam61 = mailParam61;
    }

    public String getMailParam62() {
        return mailParam62;
    }

    public void setMailParam62(String mailParam62) {
        this.mailParam62 = mailParam62;
    }

    public String getMailParam63() {
        return mailParam63;
    }

    public void setMailParam63(String mailParam63) {
        this.mailParam63 = mailParam63;
    }

    public String getMailParam64() {
        return mailParam64;
    }

    public void setMailParam64(String mailParam64) {
        this.mailParam64 = mailParam64;
    }

    public String getMailParam65() {
        return mailParam65;
    }

    public void setMailParam65(String mailParam65) {
        this.mailParam65 = mailParam65;
    }

    public String getMailParam66() {
        return mailParam66;
    }

    public void setMailParam66(String mailParam66) {
        this.mailParam66 = mailParam66;
    }

    public String getMailParam67() {
        return mailParam67;
    }

    public void setMailParam67(String mailParam67) {
        this.mailParam67 = mailParam67;
    }

    public String getMailParam68() {
        return mailParam68;
    }

    public void setMailParam68(String mailParam68) {
        this.mailParam68 = mailParam68;
    }

    public String getMailParam69() {
        return mailParam69;
    }

    public void setMailParam69(String mailParam69) {
        this.mailParam69 = mailParam69;
    }

    public String getMailParam70() {
        return mailParam70;
    }

    public void setMailParam70(String mailParam70) {
        this.mailParam70 = mailParam70;
    }

    public String getSentFlg() {
        return SentFlg;
    }

    public void setSentFlg(String SentFlg) {
        this.SentFlg = SentFlg;
    }

    public Timestamp getsoshinNichiji() {
        return soshinNichiji;
    }

    public void setsoshinNichiji(Timestamp soshinNichiji) {
        this.soshinNichiji = soshinNichiji;
    }
    
    /**
     * 2015-11-09 add
     * @return the moshikomishaId
     */
    public String getMoshikomishaId() {
        return moshikomishaId;
    }

    /**
     * @param moshikomishaId the moshikomishaId to set
     */
    public void setMoshikomishaId(String moshikomishaId) {
        this.moshikomishaId = moshikomishaId;
    }

    /**
     * @return the jizenMoshikomishaId
     */
    public String getJizenMoshikomishaId() {
        return jizenMoshikomishaId;
    }

    /**
     * @param jizenMoshikomishaId the jizenMoshikomishaId to set
     */
    public void setJizenMoshikomishaId(String jizenMoshikomishaId) {
        this.jizenMoshikomishaId = jizenMoshikomishaId;
    }
    
    /**
     * @return the sekininshaId
     */
    public String getSekininshaId() {
        return sekininshaId;
    }

    /**
     * @param sekininshaId the sekininshaId to set
     */
    public void setSekininshaId(String sekininshaId) {
        this.sekininshaId = sekininshaId;
    }

    /**
     * @return the kanrishaId
     */
    public String getKanrishaId() {
        return kanrishaId;
    }

    /**
     * @param kanrishaId the kanrishaId to set
     */
    public void setKanrishaId(String kanrishaId) {
        this.kanrishaId = kanrishaId;
    }
    
}

