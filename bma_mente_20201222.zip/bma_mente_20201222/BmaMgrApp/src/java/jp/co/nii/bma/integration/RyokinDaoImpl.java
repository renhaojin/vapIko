package jp.co.nii.bma.integration;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.ArrayList;
import jp.co.nii.bma.business.domain.RyokinDao;
import jp.co.nii.bma.business.domain.MeishoKanriDao;
import jp.co.nii.bma.business.rto.manager.MstKanriRyokinJoho;
import jp.co.nii.sew.common.LogGenerate;
import static jp.co.nii.sew.integration.AbstractDao.getSchemaName;
import jp.co.nii.sew.integration.SQLStateSQLExceptionTranslater;

/**
 * ���� DAO�����N���X
 * @author DB�Ǘ��c�[��
 */
public class RyokinDaoImpl extends GeneratedRyokinDaoImpl implements RyokinDao {

    /**
     * �C���X�^���X�𐶐�����B
     * @param datasource �f�[�^�\�[�X��
     */
    public RyokinDaoImpl(String datasource) {
        super(datasource);
    }

    /**
     * �����u�K��R�[�h�A��ʃR�[�h����v���闿����S���擾����B
     * @param sknKsuCode �����u�K��R�[�h
     * @param shubetsuCode ��ʃR�[�h
     */
    @Override
    public List<MstKanriRyokinJoho> findBySknKsu(String sknKsuCode, String shubetsuCode) {
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = "";
        List<MstKanriRyokinJoho> ryokinSearchList = new ArrayList<>();

        try {
            con = getConnection();
            sql = "SELECT "
                    + "rkn.SKN_KSU_CODE AS SKN_KSU_CODE"
                    + ", " + "rkn.SHUBETSU_CODE AS SHUBETSU_CODE"
                    + ", " + "rkn.RYOKIN_KBN AS RYOKIN_KBN"
                    + ", " + "rkn.RYOKIN AS RYOKIN"
                    + ", " + "rkn.ZEI_KBN AS ZEI_KBN"
                    + ", " + "rkn.ZEIRITSU AS ZEIRITSU"
                    + ", " + "rkn_kbn.HANYO_CHI AS RYOKIN_KBN_NAME"
                    + " FROM " + getSchemaName() + "." + RyokinDao.TABLE_NAME + " AS rkn"
                    + " LEFT JOIN " + getSchemaName() + "." + MeishoKanriDao.TABLE_NAME + " AS rkn_kbn"
                    + " ON " + "rkn.RYOKIN_KBN = rkn_kbn.HANYO_CODE "
                    + " AND " + "rkn_kbn.GROUP_CODE = 'RYOKIN_KBN' "
                    + " WHERE " + "rkn.SKN_KSU_CODE = ?"
                    + " AND " + "rkn.SHUBETSU_CODE = ?"
                    + " AND " + "rkn.RONRI_SAKUJO_FLG = '0'"
                    + " ORDER BY rkn.RYOKIN_KBN ASC ";

            stmt = con.prepareStatement(sql);
            int i = 1;
            stmt.setString(i++, sknKsuCode);
            stmt.setString(i++, shubetsuCode);
            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();

            while (rs.next()) {
                MstKanriRyokinJoho detail = new MstKanriRyokinJoho();
                // �����u�K��敪	
                detail.setSknKsuCode(rs.getString("SKN_KSU_CODE"));
                detail.setShubetsuCode(rs.getString("SHUBETSU_CODE"));
                // ����
                detail.setRyokinKbn(rs.getString("RYOKIN_KBN"));
                detail.setRyokinKbnName(rs.getString("RYOKIN_KBN_NAME"));
                detail.setRyokin(rs.getString("RYOKIN"));
                //��
                detail.setZeiKbn(rs.getString("ZEI_KBN"));
                detail.setZeiritsu(rs.getString("ZEIRITSU"));

                ryokinSearchList.add(detail);
            }

        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return ryokinSearchList;
    }

    /**
     * ��L�[���痿��1�����擾����B
     * @param sknKsuCode �����u�K��R�[�h
     * @param shubetsuCode ��ʃR�[�h
     * @param ryokinKbn �����敪
     */
    @Override
    public MstKanriRyokinJoho findDetail(String sknKsuCode, String shubetsuCode, String ryokinKbn) {
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = "";
        MstKanriRyokinJoho ryokinDetail = new MstKanriRyokinJoho();

        try {
            con = getConnection();
            sql = "SELECT "
                    + "rkn.SKN_KSU_CODE AS SKN_KSU_CODE"
                    + ", " + "rkn.SHUBETSU_CODE AS SHUBETSU_CODE"
                    + ", " + "rkn.RYOKIN_KBN AS RYOKIN_KBN"
                    + ", " + "rkn.RYOKIN AS RYOKIN"
                    + ", " + "rkn.ZEI_KBN AS ZEI_KBN"
                    + ", " + "rkn.ZEIRITSU AS ZEIRITSU"
                    + ", " + "rkn_kbn.HANYO_CHI AS RYOKIN_KBN_NAME"
                    + " FROM " + getSchemaName() + "." + RyokinDao.TABLE_NAME + " AS rkn"
                    + " LEFT JOIN " + getSchemaName() + "." + MeishoKanriDao.TABLE_NAME + " AS rkn_kbn"
                    + " ON " + "rkn.RYOKIN_KBN = rkn_kbn.HANYO_CODE "
                    + " AND " + "rkn_kbn.GROUP_CODE = 'RYOKIN_KBN' "
                    + " WHERE " + "rkn.SKN_KSU_CODE = ?"
                    + " AND " + "rkn.SHUBETSU_CODE = ?"
                    + " AND " + "rkn.RYOKIN_KBN = ?"
                    + " AND " + "rkn.RONRI_SAKUJO_FLG = '0'"
                    + " ORDER BY rkn.RYOKIN_KBN ASC "
                    + " LIMIT 1 ";

            stmt = con.prepareStatement(sql);
            int i = 1;
            stmt.setString(i++, sknKsuCode);
            stmt.setString(i++, shubetsuCode);
            stmt.setString(i++, ryokinKbn);
            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();

            if (rs.next()) {
                // �����u�K��敪	
                ryokinDetail.setSknKsuCode(rs.getString("SKN_KSU_CODE"));
                ryokinDetail.setShubetsuCode(rs.getString("SHUBETSU_CODE"));
                // ����
                ryokinDetail.setRyokinKbn(rs.getString("RYOKIN_KBN"));
                ryokinDetail.setRyokinKbnName(rs.getString("RYOKIN_KBN_NAME"));
                ryokinDetail.setRyokin(rs.getString("RYOKIN"));
                //��
                ryokinDetail.setZeiKbn(rs.getString("ZEI_KBN"));
                ryokinDetail.setZeiritsu(rs.getString("ZEIRITSU"));
            } else {
                ryokinDetail = null;
            }

        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return ryokinDetail;
    }
}