package jp.co.nii.bma.business.service.manager;

import jp.co.nii.bma.business.domain.KaijoMst;
import jp.co.nii.bma.business.rto.manager.MstKanriKaijoMstJoho;
import jp.co.nii.bma.business.service.common.BmaConstants;
import jp.co.nii.bma.business.service.common.BmaLogger;
import jp.co.nii.bma.business.service.common.BmaValidator;
import jp.co.nii.bma.utility.BmaStringUtility;
import jp.co.nii.bma.utility.BmaUtility;
import jp.co.nii.sew.business.service.AbstractService;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_BACK;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_EXCEPTION;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_SESSION;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_SUCCESS;
import jp.co.nii.sew.presentation.Messages;
import jp.co.nii.sew.presentation.RequestTransferObject;
import jp.co.nii.sew.utility.PropertyUtility;

/**
 *
 * @author NII19049
 */
public class MstKanriKaijoMstUpdateInputService extends AbstractService {

    /**
     * DB�ڑ��̃f�[�^�\�[�X
     */
    private static String DATA_SOURCE_NAME;
    /**
     * ���O
     */
    BmaLogger log = (BmaLogger) BmaLogger.getLogger(this.getClass().getName());
    /**
     * �Ɩ��R�[�h
     */
    private static final String BUSINESS_CODE = PropertyUtility.getProperty("business_code");
    /**
     * ���׃e�X�g���[�h
     */
    private static final String STRESS_MODE = PropertyUtility.getProperty(BUSINESS_CODE + "stress_mode");

    /**
     * �R���X�g���N�^
     */
    public MstKanriKaijoMstUpdateInputService() {
        super();
        /* DB�ڑ����̃��[�U�[������ */
        DATA_SOURCE_NAME = BmaConstants.DS_REGISTRANT;
    }

    /**
     * �T�[�r�X�N���X�̎��s���\�b�h
     *
     * @param rto ���N�G�X�g��񂩂�擾����rto
     * @param rtoInSession �Z�b�V�������rto
     * @return foward��
     * @throws Exception ��O
     */
    @Override
    public String doService(RequestTransferObject rto, RequestTransferObject rtoInSession)
            throws Exception {

        MstKanriKaijoMstJoho inRequest = (MstKanriKaijoMstJoho) rto;
        MstKanriKaijoMstJoho inSession = (MstKanriKaijoMstJoho) rtoInSession;
        String processName = "";

        /*�G���[���b�Z�[�W������*/
        inSession.setErrors(new Messages());
        try {
            if (!BmaUtility.isNullOrEmpty(inRequest.getNext())) {
                /*�u�m�F�v�{�^�������� */
                processName = "MstKanriKaijoMstUpDateInput_Confirm";
                log.Start(processName);

                /* �Z�b�V�����ɕێ� */
                inSession.setKaijoName(inRequest.getKaijoName());
                inSession.setKaijoNameRyaku(inRequest.getKaijoNameRyaku());
                inSession.setYubinNoFront(inRequest.getYubinNoFront());
                inSession.setYubinNoBack(inRequest.getYubinNoBack());
                inSession.setJusho(inRequest.getJusho());
                inSession.setTeiin(inRequest.getTeiin());
                inSession.setKaijoHenkoFlg(inRequest.getKaijoHenkoFlg());
                inSession.setChushajoFlg(inRequest.getChushajoFlg());
                inSession.setChizuData(inRequest.getChizuData());
                inSession.setBiko(inRequest.getBiko());
                
                /* ���͒l�`�F�b�N */
                if (!validateInput(inSession)) {
                    // �G���[���������ꍇ�u���}�X�^�ύX���́v���Reload
                    return FWD_NM_RELOAD;
                }

                /* ���͒l��\���p�ɐ��` */
                MstKanriKaijoMstJoho kaijoMstDetail = createKaijoMstDetail(inSession);
                inSession.setYubinNo(inSession.getYubinNoFront() + inSession.getYubinNoBack());
                inSession.setKaijoHenkoFlgName(kaijoMstDetail.getKaijoHenkoFlgName());
                inSession.setChushajoFlgName(kaijoMstDetail.getChushajoFlgName());

                /* �u���}�X�^�ύX�m�F�v��ʕ\�� */
                return FWD_NM_SUCCESS;

            }  else if (!BmaUtility.isNullOrEmpty(inRequest.getBack())) {
                /*�u�߂�v�{�^��������*/
                processName = "MstKanriKaijoMstUpDataInput_BackKaijoMstDetail";
                log.Start(processName);

                /* ���͏���j�����ēo�^�f�[�^���ĕ\�� */
                KaijoMst kaijo = new KaijoMst(DATA_SOURCE_NAME);
                String kaisaichiCode = inSession.getKaisaichiCode();
                String kaijoCode = inSession.getKaijoCode();

                /* �ڍ׃f�[�^���擾���A�Z�b�V�����ɕێ� */
                KaijoMst kaijoResult  = kaijo.lockNoWait(kaisaichiCode, kaijoCode);
                inSession.setKaijoName(kaijoResult.getKaijoName());
                inSession.setKaijoNameRyaku(kaijoResult.getKaijoNameRyaku());
                inSession.setYubinNo(kaijoResult.getYubinNo());
                inSession.setJusho(kaijoResult.getJusho());
                inSession.setTeiin(kaijoResult.getTeiin());
                inSession.setKaijoHenkoFlg(kaijoResult.getKaijoHenkoFlg());
                inSession.setChushajoFlg(kaijoResult.getChushajoFlg());
                inSession.setChizuData(kaijoResult.getChizuData());
                inSession.setBiko(kaijoResult.getBiko());
                inSession.setBikoDisp(kaijoResult.getBiko().replaceAll("\n", "<br>"));

                /* �u�g�p���ڍׁv��ʕ\�� */
                return FWD_NM_BACK;

            } else {
                /*�ُ�J��*/
                log.IllegalFWD();
                return FWD_NM_SESSION;
            }
        } catch (Exception e) {
            return FWD_NM_EXCEPTION;
        } finally {
            log.End(processName);
        }
    }

    /**
     * �ꗗ�\���p�ɐ��`����
     *
     * @param kaijoMst ���͏��
     * @return �m�F��ʕ\���p
     */
    private MstKanriKaijoMstJoho createKaijoMstDetail(MstKanriKaijoMstJoho kaijoMst){
        String kaijoChangeFlgName = "";
        String chushajoFlgName = "";
        MstKanriKaijoMstJoho kaijoMstDetail = new MstKanriKaijoMstJoho();

        /* ���ύX�敪���̂��Z�b�g */
        if (BmaConstants.FLG_OFF.equals(kaijoMst.getKaijoHenkoFlg())) {
            kaijoChangeFlgName = "��";
        } else if (BmaConstants.FLG_ON.equals(kaijoMst.getKaijoHenkoFlg())) {
            kaijoChangeFlgName = "�L";
        }
        kaijoMstDetail.setKaijoHenkoFlgName(kaijoChangeFlgName);
    
        /* ���ԏ�敪���̂��Z�b�g */
        if (BmaConstants.FLG_OFF.equals(kaijoMst.getChushajoFlg())) {
            chushajoFlgName = "��";
        } else if (BmaConstants.FLG_ON.equals(kaijoMst.getChushajoFlg())) {
            chushajoFlgName = "�L";
        }
        kaijoMstDetail.setChushajoFlgName(chushajoFlgName);

        return kaijoMstDetail;
    }
    
    /**
     * ���̓`�F�b�N
     *
     * @param inSession �Z�b�V����RTO
     * @return true:�G���[��
     */
    private boolean validateInput(MstKanriKaijoMstJoho inSession) {
        /* �ϐ������� */
        Messages errors = new Messages();
        String groupCode;
        String itemName;

        // �G���[�`�F�b�N�p���X�g�쐬
        String[] comUmuFlgs = {BmaConstants.FLG_ON, BmaConstants.FLG_OFF};

        //�S�p�ϊ����s
        inSession.setKaijoName(BmaStringUtility.convertHankakuToZenkakuBma(inSession.getKaijoName()));
        inSession.setKaijoNameRyaku(BmaStringUtility.convertHankakuToZenkakuBma(inSession.getKaijoNameRyaku()));
        inSession.setJusho(BmaStringUtility.convertHankakuToZenkakuBma(inSession.getJusho()));

        /* ��ꖼ */
        groupCode = "kaijoName";
        itemName = "��ꖼ";
        if (BmaValidator.validateRequired(inSession.getKaijoName(), errors, groupCode, itemName)) {
            if (BmaValidator.validateMojiCode3(inSession.getKaijoName(), errors, groupCode, itemName)) {
                BmaValidator.validateMaxLength(inSession.getKaijoName(), BmaConstants.MAX_LENGTH_KAIJO_NAME, errors, groupCode, itemName);
            }
        }

        /* ��ꖼ�i���j */
        groupCode = "kaijoNameRyaku";
        itemName = "��ꖼ�i���j";
        if (BmaValidator.validateRequired(inSession.getKaijoNameRyaku(), errors, groupCode, itemName)) {
            if (BmaValidator.validateMojiCode3(inSession.getKaijoNameRyaku(), errors, groupCode, itemName)) {
                BmaValidator.validateMaxLength(inSession.getKaijoNameRyaku(), BmaConstants.MAX_LENGTH_KAIJO_NAME_RYAKU, errors, groupCode, itemName);
            }
        }

        /* �X�֔ԍ� */
        groupCode = "yubinNo";
        itemName = "�X�֔ԍ��̑O����";
        if (BmaValidator.validateRequired(inSession.getYubinNoFront(), errors, groupCode, itemName)) {
            if (BmaValidator.validateNumber(inSession.getYubinNoFront(), errors, groupCode, itemName)) {
                BmaValidator.validateEqualLength(inSession.getYubinNoFront(), BmaConstants.EQUAL_LENGTH_YUBIN_NO1, errors, groupCode, itemName);
            }
        }
        itemName = "�X�֔ԍ��̌㔼��";
        if (BmaValidator.validateRequired(inSession.getYubinNoBack(), errors, groupCode, itemName)) {
            if (BmaValidator.validateNumber(inSession.getYubinNoBack(), errors, groupCode, itemName)) {
                BmaValidator.validateEqualLength(inSession.getYubinNoBack(), BmaConstants.EQUAL_LENGTH_YUBIN_NO2, errors, groupCode, itemName);
            }
        }
        
        /* �Z�� */
        groupCode = "jusho";
        itemName = "�Z��";
        if (BmaValidator.validateRequired(inSession.getJusho(), errors, groupCode, itemName)) {
            if (BmaValidator.validateMaxLength(inSession.getJusho(), BmaConstants.MAX_LENGTH_JUSHO, errors, groupCode, itemName)) {
                BmaValidator.validateMojiCode3(inSession.getJusho(), errors, groupCode, itemName);
            }
        }
        
        /* ��� */
        groupCode = "teiin";
        itemName = "���";
        if (BmaValidator.validateRequired(inSession.getTeiin(), errors, groupCode, itemName)) {
            if (BmaValidator.validateMaxLength(inSession.getTeiin(), BmaConstants.MAX_LENGTH_TEIIN, errors, groupCode, itemName)) {
                BmaValidator.validateNumber(inSession.getTeiin(), errors, groupCode, itemName);
            }
        }
        
        /* ���ύX�L�� */
        groupCode = "kaijoChangeFlg";
        itemName = "���ύX�L��";
        if (BmaValidator.validateSelect(inSession.getKaijoHenkoFlg(), errors, groupCode, itemName)) {
            BmaValidator.validatePermissionSelect(inSession.getKaijoHenkoFlg(), comUmuFlgs, errors, groupCode, itemName);
        }
        
        /* ���ԏ�L�� */
        groupCode = "chushajoFlg";
        itemName = "���ԏ�L��";
        if (BmaValidator.validateSelect(inSession.getChushajoFlg(), errors, groupCode, itemName)) {
            BmaValidator.validatePermissionSelect(inSession.getChushajoFlg(), comUmuFlgs, errors, groupCode, itemName);
        }
        
        /* �n�}�f�[�^ */
        groupCode = "chizuData";
        itemName = "�n�}�f�[�^";
        if (BmaValidator.validateMaxLength(inSession.getChizuData(), BmaConstants.MAX_LENGTH_CHIZU_DATA, errors, groupCode, itemName)) {
            BmaValidator.validateAlphabetOrNumber(inSession.getChizuData(), errors, groupCode, itemName);
        }

        /* ���l */
        groupCode = "biko";
        itemName = "���l";
        if (BmaValidator.validateMaxLength(inSession.getBiko(), BmaConstants.MAX_LENGTH_BIKO, errors, groupCode, itemName)) {
            String replaced = inSession.getBiko().replaceAll("\r\n", "\n");
            replaced = replaced.replaceAll("\r", "\n");
            if (BmaValidator.validateMojiCodeForBiko(replaced, errors, groupCode, itemName)) {
                // �G���[���Ȃ���΁A�\���p�ɃZ�b�V�����ێ�
                inSession.setBikoDisp(replaced.replaceAll("\n", "<br>"));
            }
        }

        inSession.setErrors(errors);
        return errors.isEmpty();
    }
}
