package jp.co.nii.sew.presentation;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author n-machida
 */
public class RTOFactory {

    public static RequestTransferObject getRTO(Config config) {
        Object o = null;
        try {
            Class<RequestTransferObject> c;
            c = (Class<RequestTransferObject>) Class.forName(config.getTransferObjectFQCN());
            o = c.newInstance();
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(RTOFactory.class.getName()).log(Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            Logger.getLogger(RTOFactory.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            Logger.getLogger(RTOFactory.class.getName()).log(Level.SEVERE, null, ex);
        }
        return (RequestTransferObject) o;
    }
}
