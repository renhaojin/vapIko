//package jp.co.nii.bma.business.rto.manager;
//
//import java.io.Serializable;
//import jp.co.nii.bma.business.service.common.BmaConstants;
//
///**
// * �������ʈꗗ�̏o�͗p�N���X��蒼�񉻂̂ݎ���
// *
// * @author
// */
//public class MgrKaoPhotoSearchList implements Serializable {
//
//    /**
//     * �\����t�ԍ�
//     */
//    private String moshikomiUketsukeNo;
//
//    /**
//     * ��ʐ^�摜�h�c
//     */
//    private String kaoShasinGazoId;
//
//    /**
//     * �␳�˗��敪
//     */
//    private String hoseiIraiKbn;
//    /**
//     * �󌱂m�n
//     */
//    private String juken_no;
//    /**
//     * ���[�U�[ID
//     */
//    private String userId;
//
//    public MgrKaoPhotoSearchList() {
//        this.moshikomiUketsukeNo = "";
//        this.kaoShasinGazoId = "";
//        this.hoseiIraiKbn = "";
//        this.juken_no = "";
//        this.userId = "";
//    }
//
//    /**
//     * @return the moshikomiUketsukeNo
//     */
//    public String getMoshikomiUketsukeNo() {
//        return moshikomiUketsukeNo;
//    }
//
//    /**
//     * @param moshikomiUketsukeNo the moshikomiUketsukeNo to set
//     */
//    public void setMoshikomiUketsukeNo(String moshikomiUketsukeNo) {
//        this.moshikomiUketsukeNo = moshikomiUketsukeNo;
//    }
//
//    /**
//     * @return the kaoShasinGazoId
//     */
//    public String getKaoShasinGazoId() {
//        return kaoShasinGazoId;
//    }
//
//    /**
//     * @param kaoShasinGazoId the kaoShasinGazoId to set
//     */
//    public void setKaoShasinGazoId(String kaoShasinGazoId) {
//        this.kaoShasinGazoId = kaoShasinGazoId;
//    }
//
//    /**
//     * @return the hoseiIraiKbn
//     */
//    public String getHoseiIraiKbn() {
//        return hoseiIraiKbn;
//    }
//
//    /**
//     * @param hoseiIraiKbn the hoseiIraiKbn to set
//     */
//    public void setHoseiIraiKbn(String hoseiIraiKbn) {
//        this.hoseiIraiKbn = hoseiIraiKbn;
//    }
//
//    /**
//     * @return the juken_no
//     */
//    public String getJuken_no() {
//        return juken_no;
//    }
//
//    /**
//     * @param juken_no the juken_no to set
//     */
//    public void setJuken_no(String juken_no) {
//        this.juken_no = juken_no;
//    }
//
//    /**
//     * ���[�U�[ID
//     * @return the userId
//     */
//    public String getUserId() {
//        return userId;
//    }
//
//    /**
//     * ���[�U�[ID
//     * @param userId the userId to set
//     */
//    public void setUserId(String userId) {
//        this.userId = userId;
//    }
//
//    /**
//     * @return the photoHanteiFlg
//     */
//    public boolean isPhotoHanteiDisp() {
//        try {
//            if ((this.hoseiIraiKbn.equals(BmaConstants.HOSEI_IRAI_KBN_IRAI_NASHI)) || (this.hoseiIraiKbn.equals(BmaConstants.HOSEI_IRAI_KBN_KAKUNIN_ZUMI))
//                    || (this.hoseiIraiKbn.equals(BmaConstants.HOSEI_IRAI_KBN_MIKAKUNIN))) {
//                return true;
//            } else if ((this.hoseiIraiKbn.equals(BmaConstants.HOSEI_IRAI_KBN_HOSEI_IRAI)) || (this.hoseiIraiKbn.equals(BmaConstants.HOSEI_IRAI_KBN_HOSEI_ZUMI))) {
//                return false;
//            } else {
//                return false;
//            }
//        } catch (Exception ex) {
//            return false;
//        }
//    }
//    
//    /**
//     * �␳�\�� OK
//     * @return 
//     */
//    public boolean isPhotoHanteiOK(){
//        return (this.hoseiIraiKbn.equals(BmaConstants.HOSEI_IRAI_KBN_IRAI_NASHI)) || (this.hoseiIraiKbn.equals(BmaConstants.HOSEI_IRAI_KBN_KAKUNIN_ZUMI));
//    }
//    
//    /**
//     * �␳�\�� NG
//     * @return 
//     */
//    public boolean isPhotoHanteiNG(){
//        return (this.hoseiIraiKbn.equals(BmaConstants.HOSEI_IRAI_KBN_HOSEI_IRAI)) || (this.hoseiIraiKbn.equals(BmaConstants.HOSEI_IRAI_KBN_HOSEI_ZUMI));
//    }
//    
//    /**
//     * �␳�\�� �u�����N
//     * @return 
//     */
//    public boolean isPhotoHanteiBlank(){
//        return this.hoseiIraiKbn.equals(BmaConstants.HOSEI_IRAI_KBN_MIKAKUNIN);
//    }
//
//}
