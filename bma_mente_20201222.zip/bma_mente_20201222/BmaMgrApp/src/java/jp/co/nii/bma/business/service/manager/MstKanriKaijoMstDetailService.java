
package jp.co.nii.bma.business.service.manager;

import java.util.ArrayList;
import jp.co.nii.bma.business.rto.manager.MstKanriKaijoMstJoho;
import jp.co.nii.bma.business.service.common.BmaConstants;
import jp.co.nii.bma.business.service.common.BmaLogger;
import jp.co.nii.bma.utility.BmaUtility;
import jp.co.nii.sew.business.service.AbstractService;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_BACK;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_EXCEPTION;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_SESSION;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_SUCCESS;
import jp.co.nii.sew.presentation.Messages;
import jp.co.nii.sew.presentation.RequestTransferObject;
import jp.co.nii.sew.utility.PropertyUtility;

/**
 *
 * @author NII19049
 */
public class MstKanriKaijoMstDetailService extends AbstractService {

    /**
     * DB�ڑ��̃f�[�^�\�[�X
     */
    private static String DATA_SOURCE_NAME;
    /**
     * ���O
     */
    BmaLogger log = (BmaLogger) BmaLogger.getLogger(this.getClass().getName());
    /**
     * �Ɩ��R�[�h
     */
    private static final String BUSINESS_CODE = PropertyUtility.getProperty("business_code");
    /**
     * ���׃e�X�g���[�h
     */
    private static final String STRESS_MODE = PropertyUtility.getProperty(BUSINESS_CODE + "stress_mode");

    /**
     * �R���X�g���N�^
     */
    public MstKanriKaijoMstDetailService() {
        super();
        /* DB�ڑ����̃��[�U�[������ */
        DATA_SOURCE_NAME = BmaConstants.DS_REGISTRANT;
    }

    /**
     * �T�[�r�X�N���X�̎��s���\�b�h
     *
     * @param rto ���N�G�X�g��񂩂�擾����rto
     * @param rtoInSession �Z�b�V�������rto
     * @return foward��
     * @throws Exception ��O
     */
    @Override
    public String doService(RequestTransferObject rto, RequestTransferObject rtoInSession)
            throws Exception {

        MstKanriKaijoMstJoho inRequest = (MstKanriKaijoMstJoho) rto;
        MstKanriKaijoMstJoho inSession = (MstKanriKaijoMstJoho) rtoInSession;
        String processName = "";

        /*�G���[���b�Z�[�W������*/
        inSession.setErrors(new Messages());
        try {
            if (!BmaUtility.isNullOrEmpty(inRequest.getNext())) {
                /*�u�ύX�v�{�^�������� */
                processName = "MstKanriKaijoMstDetail";
                log.Start(processName);

                /* ���͗p�ɗX�֔ԍ��𕪊� */
                inSession.setYubinNoFront(inSession.getYubinNo().substring(0,3));
                inSession.setYubinNoBack(inSession.getYubinNo().substring(3,7));
                
                /* �u���}�X�^�ύX���́v��ʕ\�� */
                return FWD_NM_SUCCESS;
                
            }  else if (!BmaUtility.isNullOrEmpty(inRequest.getBack())) {
                /*�u�߂�v�{�^��������*/
                processName = "MstKanriShiyoKaijoDetail";
                log.Start(processName);
                
                /* �c���Ă���I��l��j�� */
                String initKaisaichi[] = {""};
                inSession.setKaisaichiSelect(initKaisaichi);
                inSession.setKaijoMstSrcListFlg("");
                inSession.setKaijoMstResultList(new ArrayList<MstKanriKaijoMstJoho>());
                inSession.setKaijoDisplayList(new ArrayList<MstKanriKaijoMstJoho>());
                
                /* �u�g�p��ꌟ���E�ꗗ�v��ʕ\�� */
                return FWD_NM_BACK;
                
            } else {
                /*�ُ�J��*/
                log.IllegalFWD();
                return FWD_NM_SESSION;
            }
        } catch (Exception e) {
            return FWD_NM_EXCEPTION;
        } finally {
            log.End(processName);
        }
    }
}