package jp.co.nii.bma.business.service.manager;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import jp.co.nii.bma.business.domain.KaijoMst;
import jp.co.nii.bma.business.domain.KaijoTantoMst;
import jp.co.nii.bma.business.domain.ShiyoKaijo;
import jp.co.nii.bma.business.domain.Schedule;
import jp.co.nii.bma.business.rto.manager.MstKanriShiyoKaijoJoho;
import jp.co.nii.bma.business.service.common.BmaConstants;
import jp.co.nii.bma.business.service.common.BmaLogger;
import jp.co.nii.bma.business.service.common.BmaValidator;
import jp.co.nii.bma.presentation.common.BmaText;
import jp.co.nii.bma.utility.BmaUtility;
import jp.co.nii.sew.business.service.AbstractService;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_BACK;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_EXCEPTION;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_RELOAD;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_SESSION;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_SUCCESS;
import jp.co.nii.sew.presentation.Messages;
import jp.co.nii.sew.presentation.Option;
import jp.co.nii.sew.presentation.RequestTransferObject;
import jp.co.nii.sew.utility.PropertyUtility;

/**
 *
 * @author nii19049
 */
public class MstKanriShiyoKaijoUpdateInputService extends AbstractService {

    /**
     * DB�ڑ��̃f�[�^�\�[�X
     */
    private static String DATA_SOURCE_NAME;
    /**
     * ���O
     */
    BmaLogger log = (BmaLogger) BmaLogger.getLogger(this.getClass().getName());
    /**
     * �Ɩ��R�[�h
     */
    private static final String BUSINESS_CODE = PropertyUtility.getProperty("business_code");
    /**
     * ���׃e�X�g���[�h
     */
    private static final String STRESS_MODE = PropertyUtility.getProperty(BUSINESS_CODE + "stress_mode");

    /**
     * �R���X�g���N�^
     */
    public MstKanriShiyoKaijoUpdateInputService() {
        super();
        /* DB�ڑ����̃��[�U�[������ */
        DATA_SOURCE_NAME = BmaConstants.DS_REGISTRANT;
    }

    /**
     * �T�[�r�X�N���X�̎��s���\�b�h
     *
     * @param rto ���N�G�X�g��񂩂�擾����rto
     * @param rtoInSession �Z�b�V�������rto
     * @return foward��
     * @throws Exception ��O
     */
    @Override
    public String doService(RequestTransferObject rto, RequestTransferObject rtoInSession)
            throws Exception {

        MstKanriShiyoKaijoJoho inRequest = (MstKanriShiyoKaijoJoho) rto;
        MstKanriShiyoKaijoJoho inSession = (MstKanriShiyoKaijoJoho) rtoInSession;
        String processName = "";

        /*�G���[���b�Z�[�W������*/
        inSession.setErrors(new Messages());
        try {
            if (!BmaUtility.isNullOrEmpty(inRequest.getShiyoKaijoUpdateInp())) {
                /*�u�g�p���ύX���́v�J�ڎ�*/
                processName = "MstKanriShiyoKaijoUpdateInput_First";
                log.Start(processName);

                return FWD_NM_SUCCESS;

            } else if (!BmaUtility.isNullOrEmpty(inRequest.getNext())) {
                /*�u�m�F�v�{�^��������*/
                processName = "MstKanriShiyoKaijoUpdateInput_Confirm";
                log.Start(processName);

                /* �ϐ������� */
                KaijoTantoMst tanto = new KaijoTantoMst(DATA_SOURCE_NAME);
                KaijoMst kaijoM = new KaijoMst(DATA_SOURCE_NAME);

                inSession.setShiyoKaijoInputList(inRequest.getShiyoKaijoInputList());
                inSession.setKaijoList(inSession.getShiyoKaijoInputList());
                inSession.setKaijo(inRequest.getKaijo());

                // �ύX�������1�����I�����Ă��Ȃ��ꍇ�G���[
//                Boolean checkInput = false;
//                Boolean checkUseKaijo = false;
//                for (MstKanriShiyoKaijoJoho shiyokaijo : inSession.getShiyoKaijoInputList()) {
//                    if ("1".equals(shiyokaijo.getSelectedKaijo())) {
//                        checkUseKaijo = true;
//                        break;
//                    }
//                }
//                if (!checkUseKaijo) {
//                    Messages errors = new Messages();
//                    BmaValidator.addMessage(errors, "shiyoKaijoData", BmaText.E00136);
//                    inSession.setErrors(errors);
//                } else {
//                    // ���͒l�`�F�b�N
//                    checkInput = validateInput(inSession.getShiyoKaijoInputList(), inSession);
//                }
                /* ���͒l�`�F�b�N */
                if (!validateInput(inSession.getShiyoKaijoInputList(), inSession)) {
                    // �G���[���������ꍇ�u�g�p���V�K�v���Reload
                    for (int l = 0; l < inSession.getKaijoList().size(); l++) {
                        List<Option> tantoshaList = new ArrayList<Option>();
                        MstKanriShiyoKaijoJoho shiyoKaijo = inSession.getKaijoList().get(l);

                        shiyoKaijo.setFromYear(shiyoKaijo.getFromYear().replaceFirst("^0+", ""));
                        shiyoKaijo.setFromMonth(shiyoKaijo.getFromMonth().replaceFirst("^0+", ""));
                        shiyoKaijo.setFromDate(shiyoKaijo.getFromDate().replaceFirst("^0+", ""));
                        shiyoKaijo.setToYear(shiyoKaijo.getToYear().replaceFirst("^0+", ""));
                        shiyoKaijo.setToMonth(shiyoKaijo.getToMonth().replaceFirst("^0+", ""));
                        shiyoKaijo.setToDate(shiyoKaijo.getToDate().replaceFirst("^0+", ""));

                        String kaisaichi = shiyoKaijo.getKaisaichiCode();
                        String kaijo = inSession.getKaijo();

                        /* �J�Òn�����ƂɁA��ꃊ�X�g���쐬 */
                        KaijoMst kaijoL = new KaijoMst(DATA_SOURCE_NAME);
                        List<Option> kaijoByKaisaichiList = new ArrayList<Option>();
                        List<Option> kaijoByTantoshaList = new ArrayList<Option>();

                        // �\�������ւ̏ꍇ
                        if ("10".equals(kaisaichi)) {
                            String[] kaisaichies = {"03", "04"};
                            kaijoL.findByKaisaichies(kaisaichies, kaijoByKaisaichiList);
                            shiyoKaijo.setTokanKaijoCode(kaijo);
                            tanto.findByOneTantosha(kaijo.substring(0, 2), kaijo.substring(2, 5), kaijoByTantoshaList);
                        } else {
                            kaijoL.findByOneKaisaichi(kaisaichi, kaijoByKaisaichiList);
                            tanto.findByOneTantosha(kaisaichi, kaijo, kaijoByTantoshaList);
                        }
                        shiyoKaijo.setKaijoByKaisaichiList(kaijoByKaisaichiList);
                        shiyoKaijo.setKaijoByTantoshaList(kaijoByTantoshaList);

                        shiyoKaijo.setKaisaichiCode(kaisaichi);
                        shiyoKaijo.setKaijoCode(kaijo);
                        shiyoKaijo.setTantoshaList(tantoshaList);
                        shiyoKaijo.setTantosha("");
                        inSession.getKaijoList().set(l, shiyoKaijo);

                    }
                    return FWD_NM_SUCCESS;
                }

//                if (!checkInput || !checkUseKaijo) {
//                    // �G���[���������ꍇ�u�g�p���V�K�v���Reload
//                    for (int l = 0; l < inSession.getKaijoList().size(); l++) {
//                        List<Option> tantoshaList = new ArrayList<Option>();
//                        MstKanriShiyoKaijoJoho shiyoKaijo = inSession.getKaijoList().get(l);
//
//                        shiyoKaijo.setFromYear(shiyoKaijo.getFromYear().replaceFirst("^0+", ""));
//                        shiyoKaijo.setFromMonth(shiyoKaijo.getFromMonth().replaceFirst("^0+", ""));
//                        shiyoKaijo.setFromDate(shiyoKaijo.getFromDate().replaceFirst("^0+", ""));
//                        shiyoKaijo.setToYear(shiyoKaijo.getToYear().replaceFirst("^0+", ""));
//                        shiyoKaijo.setToMonth(shiyoKaijo.getToMonth().replaceFirst("^0+", ""));
//                        shiyoKaijo.setToDate(shiyoKaijo.getToDate().replaceFirst("^0+", ""));
//
//                        String kaisaichi = shiyoKaijo.getKaisaichiCode();
//                        String kaijo = shiyoKaijo.getKaijoCode();
////                        tanto.findByOneTantosha(kaisaichi, kaijo, tantoshaList);
//
//                        /* �J�Òn�����ƂɁA��ꃊ�X�g���쐬 */
//                        KaijoMst kaijoL = new KaijoMst(DATA_SOURCE_NAME);
//                        List<Option> kaijoByKaisaichiList = new ArrayList<Option>();
//                        List<Option> kaijoByTantoshaList = new ArrayList<Option>();
//
//                        // �\�������ւ̏ꍇ
//                        if ("10".equals(kaisaichi)) {
//                            String[] kaisaichies = {"03", "04"};
//                            kaijoL.findByKaisaichies(kaisaichies, kaijoByKaisaichiList);
//                            shiyoKaijo.setTokanKaijoCode(kaijo);
//                            tanto.findByOneTantosha(kaijo.substring(0, 2), kaijo.substring(2, 5), kaijoByTantoshaList);
//                        } else {
//                            kaijoL.findByOneKaisaichi(kaisaichi, kaijoByKaisaichiList);
//                            tanto.findByOneTantosha(kaisaichi, kaijo, kaijoByTantoshaList);
//                        }
//                        shiyoKaijo.setKaijoByKaisaichiList(kaijoByKaisaichiList);
//                        shiyoKaijo.setKaijoByTantoshaList(kaijoByTantoshaList);
//
//                        shiyoKaijo.setKaisaichiCode(kaisaichi);
//                        shiyoKaijo.setKaijoCode(kaijo);
//                        shiyoKaijo.setTantoshaList(tantoshaList);
//                        shiyoKaijo.setTantosha("");
//                        inSession.getKaijoList().set(l, shiyoKaijo);
//
//                    }
//                    return FWD_NM_SUCCESS;
//                }
                Boolean errFlg = false;
                List<MstKanriShiyoKaijoJoho> shiyoKaijoList = new ArrayList<>();
                for (int i = 0; i < inSession.getShiyoKaijoInputList().size(); i++) {
                    MstKanriShiyoKaijoJoho shiyoKaijo = inSession.getShiyoKaijoInputList().get(i);
//                    if ("1".equals(shiyoKaijo.getSelectedKaijo())) {

                    List<Option> kaijoByKaisaichiList = new ArrayList<Option>();
                    String kaisaichiCode = shiyoKaijo.getKaisaichiCode();
                    String kaijoCode = inRequest.getKaijo();
                    shiyoKaijo.setKaijoCode(kaijoCode);
//                        List<Option> kaijoByKaisaichiList = new ArrayList<Option>();

                    //��ꖼ
//                        kaijoM.findByOneKaisaichi(kaisaichiCode, kaijoByKaisaichiList);
//                        shiyoKaijo.setKaijoByKaisaichiList(kaijoByKaisaichiList);
//                        shiyoKaijo.setKaijoCode(inRequest.getKaijoCode());
                    if ("10".equals(kaisaichiCode)) {
                        //��ꖼ
                        String kaisaichiCodeKaijoMst = kaijoCode.substring(0, 2);
                        shiyoKaijo.setKaisaichiCodeKaijoMst(kaisaichiCodeKaijoMst);
                        String shiyoKaijoName = kaijoM.findKaijoNameRyaku(kaisaichiCodeKaijoMst, kaijoCode.substring(2, 5));
                        shiyoKaijo.setKaijoName(shiyoKaijoName);
                        //�S����
                        String tantoshaCode = shiyoKaijo.getTantoshaCode();
                        String shiyoKaijoTantosha = tanto.searchTantoshaName(kaisaichiCodeKaijoMst, kaijoCode.substring(2, 5), tantoshaCode);
                        shiyoKaijo.setTantosha(shiyoKaijoTantosha);
                    } else {
                        //��ꖼ
                        String shiyoKaijoName = kaijoM.findKaijoNameRyaku(kaisaichiCode, kaijoCode);
                        shiyoKaijo.setKaijoName(shiyoKaijoName);
                        //�S����
                        String tantoshaCode = shiyoKaijo.getTantoshaCode();
                        String shiyoKaijoTantosha = tanto.searchTantoshaName(kaisaichiCode, kaijoCode, tantoshaCode);
                        shiyoKaijo.setTantosha(shiyoKaijoTantosha);
                    }

                    MstKanriShiyoKaijoJoho shiyoKaijoUpdName = createShiyoKaijoDetail(shiyoKaijo);
                    // ��ꎎ���敪
                    if (!"2".equals(shiyoKaijo.getSknksuKbn())) {
                        shiyoKaijo.setKaijoShikenName(shiyoKaijoUpdName.getKaijoShikenName());
                    }

                    //�j��
                    shiyoKaijo.setNitteiFrom(shiyoKaijo.getFromYear() + shiyoKaijo.getFromMonth() + shiyoKaijo.getFromDate());
                    shiyoKaijo.setNitteiTo(shiyoKaijo.getToYear() + shiyoKaijo.getToMonth() + shiyoKaijo.getToDate());

                    shiyoKaijo.setFromYobi(dateToWeek(shiyoKaijo.getNitteiFrom()));

                    if (!BmaUtility.isNullOrEmpty(shiyoKaijo.getNitteiTo())) {
                        shiyoKaijo.setToYobi(dateToWeek(shiyoKaijo.getNitteiTo()));
                    }

                    //���
                    shiyoKaijo.setTeiin(String.format(shiyoKaijo.getTeiin()).replaceFirst("^0+", ""));

                    // ���l
                    shiyoKaijo.setBikoKaijo(shiyoKaijo.getBikoKaijo());
                    shiyoKaijo.setBikoTanto(shiyoKaijo.getBikoTanto());
                    shiyoKaijo.setBikoKaijoDisp(shiyoKaijo.getBikoKaijo().replaceAll("\r\n", "\n").replaceAll("\r", "\n").replaceAll("\n", "<br>"));
                    shiyoKaijo.setBikoTantoDisp(shiyoKaijo.getBikoTanto().replaceAll("\r\n", "\n").replaceAll("\r", "\n").replaceAll("\n", "<br>"));

                    shiyoKaijoList.add(shiyoKaijo);
//                    }
                    inSession.setShiyoKaijoUpdateList(shiyoKaijoList);
                }

                inSession.setKaijoList(inSession.getShiyoKaijoInputList());
                /* �u�g�p���ύX�m�F�v��ʕ\�� */
                return FWD_NM_NEXT;

            } else if (!BmaUtility.isNullOrEmpty(inRequest.getBack())) {
                /*�u�߂�v�{�^��������*/
                processName = "MstKanriShiyoKaijoUpdateInput_BackDetail";
                log.Start(processName);

                /* ���̓��X�g��j�� */
                inSession.setKaijoList(new ArrayList<MstKanriShiyoKaijoJoho>());

                /* �u�g�p��ꌟ���E�ꗗ�v��ʕ\�� */
                return FWD_NM_BACK;

            } else if (!BmaUtility.isNullOrEmpty(inRequest.getKaijo())) {
                /* ����ύX�����ꍇ */
                processName = "MstKanriShiyoKaijoUpdateInput_ChangeKaisaichi";
                log.Start(processName);

                List<MstKanriShiyoKaijoJoho> kaijoList = inSession.getKaijoList();
                MstKanriShiyoKaijoJoho kaijoChangeKaijo = kaijoList.get(0);
                /* ���R�[�h�����ƂɁA�S���҃��X�g���쐬 */
                KaijoTantoMst tanto = new KaijoTantoMst(DATA_SOURCE_NAME);
                List<Option> tantoshaList = new ArrayList<Option>();
                String kaisaichi = kaijoChangeKaijo.getKaisaichiCode();
                String kaijo = inRequest.getKaijo();

                /* �J�Òn�����ƂɁA��ꃊ�X�g���쐬 */
                KaijoMst kaijoL = new KaijoMst(DATA_SOURCE_NAME);
                List<Option> kaijoByKaisaichiList = new ArrayList<Option>();
                List<Option> kaijoByTantoshaList = new ArrayList<Option>();

                // �\�������ւ̏ꍇ
                if ("10".equals(kaisaichi)) {
                    String[] kaisaichies = {"03", "04"};
                    kaijoL.findByKaisaichies(kaisaichies, kaijoByKaisaichiList);
                    kaijoChangeKaijo.setTokanKaijoCode(kaijo);
                    tanto.findByOneTantosha(kaijo.substring(0, 2), kaijo.substring(2, 5), kaijoByTantoshaList);
                } else {
                    kaijoL.findByOneKaisaichi(kaisaichi, kaijoByKaisaichiList);
                    tanto.findByOneTantosha(kaisaichi, kaijo, kaijoByTantoshaList);
                }

                kaijoChangeKaijo.setKaijoByKaisaichiList(kaijoByKaisaichiList);
                kaijoChangeKaijo.setKaijoByTantoshaList(kaijoByTantoshaList);

                /* �I��l�ƒS���҃��X�g��ێ� */
                kaijoChangeKaijo.setKaijoCode(kaijo);
                kaijoChangeKaijo.setTantoshaList(tantoshaList);
                kaijoChangeKaijo.setTantoshaCode("");
//                inRequest.setKaijo("");


                /* �u�g�p���ύX���́v���reload */
                return FWD_NM_SUCCESS;

            } else if (BmaUtility.isNullOrEmpty(inRequest.getKaijo())) {
                /* ���������l�ɕύX�����ꍇ */
                processName = "MstKanriShiyoKaijoUpdateInput_ChangeKaisaichi";
                log.Start(processName);

                List<MstKanriShiyoKaijoJoho> kaijoList = inSession.getKaijoList();
                MstKanriShiyoKaijoJoho kaijoChangeKaijo = kaijoList.get(0);

                //���R�[�h
                kaijoChangeKaijo.setKaijoCode("");
                //�S����
                kaijoChangeKaijo.setTantoshaList(new ArrayList<Option>());
                kaijoChangeKaijo.setTantoshaCode("");

                /* �u�g�p���ύX���́v���reload */
                return FWD_NM_SUCCESS;

            } else {
                /*�ُ�J��*/
                log.IllegalFWD();
                return FWD_NM_SESSION;
            }
        } catch (Exception e) {
            return FWD_NM_EXCEPTION;
        } finally {
            log.End(processName);
        }
    }

    public static MstKanriShiyoKaijoJoho createShiyoKaijoDetail(MstKanriShiyoKaijoJoho shiyoKaijo) {

        String kaijoShikenName = "";

        MstKanriShiyoKaijoJoho shiyoKaijoDetail = new MstKanriShiyoKaijoJoho();

        /* ��ꎎ���敪���̂��Z�b�g */
        if (BmaConstants.KAIJO_SHIKEN_KBN_NASHI.equals(shiyoKaijo.getKaijoShikenKbn())) {
            kaijoShikenName = "�敪���g�p���Ȃ�";
        } else if (BmaConstants.KAIJO_SHIKEN_KBN_GAKKA.equals(shiyoKaijo.getKaijoShikenKbn())) {
            kaijoShikenName = "�w�Ȏ����y�ю��Z�y�[�p�[�e�X�g";
        } else if (BmaConstants.KAIJO_SHIKEN_KBN_ZITSUGI.equals(shiyoKaijo.getKaijoShikenKbn())) {
            kaijoShikenName = "���Z��Ǝ���";
        }
        shiyoKaijoDetail.setKaijoShikenName(kaijoShikenName);

        return shiyoKaijoDetail;
    }

    /**
     * �����𐮌`����
     *
     * @param inRequest�@���N�G�X�g���
     * @param inSession�@�Z�b�V�������
     */
    public static void createNittei(MstKanriShiyoKaijoJoho inRequest, MstKanriShiyoKaijoJoho inSession) {
        /* �ϐ������� */
        String nitteiFrom = "";
        String nitteiTo = "";

        // ����From �N
        if (!BmaUtility.isNullOrEmpty(inRequest.getFromYear())) {
            // �����̓��͂�����Γ��t�p�ɘA��
            inSession.setFromYear(String.format("%4s", inRequest.getFromYear()).replace(' ', '0'));
            nitteiFrom = inSession.getFromYear();
        } else {
            // ���͂��Ȃ���΃G���[
            inSession.setFromYear(inRequest.getFromYear());
        }
        // ����From ��
        if (!BmaUtility.isNullOrEmpty(inRequest.getFromMonth())) {
            inSession.setFromMonth(String.format("%2s", inRequest.getFromMonth()).replace(' ', '0'));
            nitteiFrom += inSession.getFromMonth();
        } else {
            inSession.setFromMonth(inRequest.getFromMonth());
        }
        // ����From ��
        if (!BmaUtility.isNullOrEmpty(inRequest.getFromDate())) {
            inSession.setFromDate(String.format("%2s", inRequest.getFromDate()).replace(' ', '0'));
            nitteiFrom += inSession.getFromDate();
        } else {
            inSession.setFromDate(inRequest.getFromDate());
        }
        inSession.setNitteiFrom(nitteiFrom);

        // ����To �N
        if (!BmaUtility.isNullOrEmpty(inRequest.getToYear())) {
            // �����̓��͂�����Γ��t�p�ɘA��
            inSession.setToYear(String.format("%4s", inRequest.getToYear()).replace(' ', '0'));
            nitteiTo = inSession.getToYear();
        } else {
            // ���͂��Ȃ���΃G���[
            inSession.setToYear(inRequest.getToYear());
        }
        // ����To ��
        if (!BmaUtility.isNullOrEmpty(inRequest.getToMonth())) {
            inSession.setToMonth(String.format("%2s", inRequest.getToMonth()).replace(' ', '0'));
            nitteiTo += inSession.getToMonth();
        } else {
            inSession.setToMonth(inRequest.getToMonth());
        }
        // ����To ��
        if (!BmaUtility.isNullOrEmpty(inRequest.getToDate())) {
            inSession.setToDate(String.format("%2s", inRequest.getToDate()).replace(' ', '0'));
            nitteiTo += inSession.getToDate();
        } else {
            inSession.setToDate(inRequest.getToDate());
        }
        inSession.setNitteiTo(nitteiTo);
    }

    /**
     * ���t�ɂ���ėj�����擾����
     *
     * @param datetime�@���t
     * @return �j��
     */
    public static String dateToWeek(String datetime) {

        SimpleDateFormat f = new SimpleDateFormat("yyyyMMdd");
        String[] weekDays = {"��", "��", "��", "��", "��", "��", "�y"};
        Calendar cal = Calendar.getInstance();
        Date date;
        try {
            date = f.parse(datetime);
            cal.setTime(date);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        //the day number of a week
        int w = cal.get(Calendar.DAY_OF_WEEK) - 1;
        if (w < 0) {
            w = 0;
        }
        return weekDays[w];
    }

    /**
     * �ڍ׉�ʂɖ߂�悤�ɃZ�b�V������������������
     *
     * @param inSession�@�Z�b�V�������
     */
    public static void resetDetailData(MstKanriShiyoKaijoJoho inSession) {
        /* �ϐ������� */
        ShiyoKaijo shiyoKaijo = new ShiyoKaijo(DATA_SOURCE_NAME);
        KaijoTantoMst tanto = new KaijoTantoMst(DATA_SOURCE_NAME);

        // ��L�[�擾
        String nendo = inSession.getNendo();
        String sknKsuCode = inSession.getSknKsuCode();
        String shubetsuCode = inSession.getShubetsuCode();
        String kaisuCode = inSession.getKaisuCode();
        String kaijoId = inSession.getKaijoId();
        String kaijoShikenKbn = inSession.getDbKaijoShikenKbn();      // �ύX���͉�ʂŕύX�\�Ȃ��߁A�ޔ��������f�[�^���g�p
        String kaisaichiCode = inSession.getKaisaichiCode();
        String kaijoCode = inSession.getDbKaijoCode();                // �ύX���͉�ʂŕύX�\�Ȃ��߁A�ޔ��������f�[�^���g�p

        /* �ڍ׃f�[�^���擾���A�Z�b�V�����ɕێ� */
        ShiyoKaijo shiyoKaijoResult = shiyoKaijo.lockNoWait(nendo, sknKsuCode, shubetsuCode, kaisuCode, kaijoId, kaijoShikenKbn, kaisaichiCode, kaijoCode);
        KaijoTantoMst kaijoTantoResult = tanto.lockNoWait(kaisaichiCode, kaijoCode, shiyoKaijoResult.getTantoshaCode());

        inSession.setKaijoShikenKbn(kaijoShikenKbn);
        inSession.setKaijoCode(kaijoCode);
        inSession.setKaijoName(shiyoKaijoResult.getKaijoName());
        inSession.setKaijoNameRyaku(shiyoKaijoResult.getKaijoNameRyaku());
        inSession.setYubinNo(shiyoKaijoResult.getYubinNo());
        inSession.setJusho(shiyoKaijoResult.getJusho());
        inSession.setTantoshaCode(shiyoKaijoResult.getTantoshaCode());
        inSession.setNitteiFrom(shiyoKaijoResult.getNitteiFrom());
        inSession.setNitteiTo(shiyoKaijoResult.getNitteiTo());
        inSession.setTeiin(shiyoKaijoResult.getTeiin());
        inSession.setGenzaiNinzu(shiyoKaijoResult.getGenzaiNinzu());
        inSession.setBikoKaijo(shiyoKaijoResult.getBikoKaijo());
        inSession.setBikoTanto(shiyoKaijoResult.getBikoTanto());

        inSession.setKaijoShikenName(createShiyoKaijoDetail(inSession).getKaijoShikenName());
        inSession.setFromYear(inSession.getNitteiFrom().substring(0, 4));
        inSession.setFromMonth(inSession.getNitteiFrom().substring(4, 6));
        inSession.setFromDate(inSession.getNitteiFrom().substring(6, 8));
        inSession.setFromYobi(dateToWeek(inSession.getNitteiFrom()));
        inSession.setToYear(inSession.getNitteiTo().substring(0, 4));
        inSession.setToMonth(inSession.getNitteiTo().substring(4, 6));
        inSession.setToDate(inSession.getNitteiTo().substring(6, 8));
        inSession.setToYobi(dateToWeek(inSession.getNitteiTo()));

        inSession.setTantosha(kaijoTantoResult.getTantosha());
        inSession.setTantoBusho(kaijoTantoResult.getTantoBusho());
        inSession.setTelNo(kaijoTantoResult.getTelNo());
        inSession.setFaxNo(kaijoTantoResult.getFaxNo());
        inSession.setTantoshaMailAddress(kaijoTantoResult.getTantoshaMailAddress());
    }

    /**
     * ���̓`�F�b�N
     *
     * @param inSession �Z�b�V����RTO
     * @return true:�G���[��
     */
    private boolean validateInput(List<MstKanriShiyoKaijoJoho> shiyoKaijoList, MstKanriShiyoKaijoJoho inSession) {
        /* �ϐ������� */
        Messages errors = new Messages();
        String groupCode;
        String itemName;

        KaijoTantoMst tanto = new KaijoTantoMst(DATA_SOURCE_NAME);
        // �G���[�`�F�b�N�p���X�g�쐬
        String[] kaijoShikenKbns = {BmaConstants.KAIJO_SHIKEN_KBN_NASHI, BmaConstants.KAIJO_SHIKEN_KBN_GAKKA, BmaConstants.KAIJO_SHIKEN_KBN_ZITSUGI};

        for (int i = 0; i < shiyoKaijoList.size(); ++i) {
            MstKanriShiyoKaijoJoho shiyoKaijo = shiyoKaijoList.get(i);
//            if ("1".equals(shiyoKaijo.getSelectedKaijo())) {

            // �����쐬
            createNittei(shiyoKaijo, shiyoKaijo);

            /* ��ꎎ���敪 */
            groupCode = "kaijoShikenKbn";
            itemName = "��ꎎ���敪";
            if (BmaValidator.validateSelect(shiyoKaijo.getKaijoShikenKbn(), errors, groupCode, itemName)) {
                BmaValidator.validatePermissionSelect(shiyoKaijo.getKaijoShikenKbn(), kaijoShikenKbns, errors, groupCode, itemName);
            }

            /* �S���҃R�[�h */
            groupCode = "tantosha";
            itemName = "�S����";
            if ("10".equals(shiyoKaijo.getKaisaichiCode())) {
                String kaisaichiCodeKaijoMst = inSession.getKaijo().substring(0, 2);
                //�S����
                List<Option> tantoshaList = new ArrayList<Option>();
                tanto.findByOneTantosha(kaisaichiCodeKaijoMst, inSession.getKaijo().substring(2, 5), tantoshaList);
                if (BmaValidator.validateSelect(shiyoKaijo.getTantoshaCode(), errors, groupCode, itemName)) {
                    BmaValidator.validatePermissionSelect(shiyoKaijo.getTantoshaCode(), tantoshaList, errors, groupCode, itemName);
                }
            } else {
                List<Option> tantoshaList = new ArrayList<Option>();
                tanto.findByOneTantosha(shiyoKaijo.getKaisaichiCode(), shiyoKaijo.getKaijoCode(), tantoshaList);
                if (BmaValidator.validateSelect(shiyoKaijo.getTantoshaCode(), errors, groupCode, itemName)) {
                    BmaValidator.validatePermissionSelect(shiyoKaijo.getTantoshaCode(), tantoshaList, errors, groupCode, itemName);
                }
            }

            /* ����From */
            groupCode = "nitteiFrom";
            // �N
            itemName = "�����QFROM�̔N";
            if (BmaValidator.validateRequired(shiyoKaijo.getFromYear(), errors, groupCode, itemName)) {
                if (BmaValidator.validateNumber(shiyoKaijo.getFromYear(), errors, groupCode, itemName)) {
                    BmaValidator.validateMaxLength(shiyoKaijo.getFromYear(), BmaConstants.EQUAL_LENGTH_SCHED_DATE_YEAR, errors, groupCode, itemName);
                }
            }
            // ��
            itemName = "�����QFROM�̌�";
            if (BmaValidator.validateRequired(shiyoKaijo.getFromMonth(), errors, groupCode, itemName)) {
                if (BmaValidator.validateNumber(shiyoKaijo.getFromMonth(), errors, groupCode, itemName)) {
                    BmaValidator.validateMaxLength(shiyoKaijo.getFromMonth(), BmaConstants.EQUAL_LENGTH_SCHED_DATE_MONTH, errors, groupCode, itemName);
                }
            }
            // ��
            itemName = "�����QFROM�̓�";
            if (BmaValidator.validateRequired(shiyoKaijo.getFromDate(), errors, groupCode, itemName)) {
                if (BmaValidator.validateNumber(shiyoKaijo.getFromDate(), errors, groupCode, itemName)) {
                    BmaValidator.validateMaxLength(shiyoKaijo.getFromDate(), BmaConstants.EQUAL_LENGTH_SCHED_DATE_DAY, errors, groupCode, itemName);
                }
            }
            // ���t�̐�����
            if (errors.isEmpty()) {
                itemName = "�����QFROM";
                BmaValidator.validateDate2(shiyoKaijo.getNitteiFrom(), errors, groupCode, itemName);
            }

            /* ����To */
            groupCode = "nitteiTo";
            // �N
            itemName = "�����QTO�̔N";
            if (BmaValidator.validateRequired(shiyoKaijo.getToYear(), errors, groupCode, itemName)) {
                if (BmaValidator.validateNumber(shiyoKaijo.getToYear(), errors, groupCode, itemName)) {
                    BmaValidator.validateMaxLength(shiyoKaijo.getToYear(), BmaConstants.EQUAL_LENGTH_SCHED_DATE_YEAR, errors, groupCode, itemName);
                }
            }
            // ��
            itemName = "�����QTO�̌�";
            if (BmaValidator.validateRequired(shiyoKaijo.getToMonth(), errors, groupCode, itemName)) {
                if (BmaValidator.validateNumber(shiyoKaijo.getToMonth(), errors, groupCode, itemName)) {
                    BmaValidator.validateMaxLength(shiyoKaijo.getToMonth(), BmaConstants.EQUAL_LENGTH_SCHED_DATE_MONTH, errors, groupCode, itemName);
                }
            }
            // ��
            itemName = "�����QTO�̓�";
            if (BmaValidator.validateRequired(shiyoKaijo.getToDate(), errors, groupCode, itemName)) {
                if (BmaValidator.validateNumber(shiyoKaijo.getToDate(), errors, groupCode, itemName)) {
                    BmaValidator.validateMaxLength(shiyoKaijo.getToDate(), BmaConstants.EQUAL_LENGTH_SCHED_DATE_DAY, errors, groupCode, itemName);
                }
            }
            // ���t�̐�����
            if (errors.isEmpty()) {
                itemName = "�����QTO";
                BmaValidator.validateDate2(shiyoKaijo.getNitteiTo(), errors, groupCode, itemName);
            }

            // ����_FROM�Ɠ���_TO�̑O��֌W�`�F�b�N
            if (errors.isEmpty()) {
                itemName = "�����QFROM�Ɠ����QTO";
                if (!checkStartEndDate(shiyoKaijo.getNitteiFrom(), shiyoKaijo.getNitteiTo())) {
                    BmaValidator.addMessage(errors, groupCode, BmaText.E00004, itemName);
                }
            }

            // �X�P�W���[���������ԓ����ǂ����`�F�b�N
            if (errors.isEmpty()) {
                // �X�P�W���[���������Ԃ��擾
                String schedStart = "";
                String schedEnd = "";
                Schedule sched = new Schedule(DATA_SOURCE_NAME);
                schedStart = sched.find(inSession.getNendo(), inSession.getSknKsuCode(), inSession.getShubetsuCode(), inSession.getKaisuCode(), BmaConstants.SCHED_CODE_OPEN, BmaConstants.SCHEDULE_KBN_ST).getDate();
                schedEnd = sched.find(inSession.getNendo(), inSession.getSknKsuCode(), inSession.getShubetsuCode(), inSession.getKaisuCode(), BmaConstants.SCHED_CODE_OPEN, BmaConstants.SCHEDULE_KBN_ED).getDate();

                if (!checkDaysInTerm(shiyoKaijo.getNitteiFrom(), shiyoKaijo.getNitteiTo(), schedStart, schedEnd)) {
                    String strMsg1 = "����";
                    String strMsg2 = "�������u�K��̃X�P�W���[����������";
                    BmaValidator.addMessage(errors, groupCode, BmaText.E00129, strMsg1, strMsg2);
                }
            }

            /* ��� */
            groupCode = "teiin";
            itemName = "���";
            if (BmaValidator.validateRequired(shiyoKaijo.getTeiin(), errors, groupCode, itemName)) {
                if (BmaValidator.validateMaxLength(shiyoKaijo.getTeiin(), BmaConstants.MAX_LENGTH_TEIIN, errors, groupCode, itemName)) {
                    BmaValidator.validateNumber(shiyoKaijo.getTeiin(), errors, groupCode, itemName);
                }
            }

            /* ���l�i���j */
            groupCode = "bikoKaijo";
            itemName = "���l�i���j";
            if (BmaValidator.validateMaxLength(shiyoKaijo.getBikoKaijo(), BmaConstants.MAX_LENGTH_BIKO, errors, groupCode, itemName)) {
                BmaValidator.validateMojiCodeForBiko(shiyoKaijo.getBikoKaijo(), errors, groupCode, itemName);
            }

            /* ���l�i�S���j */
            groupCode = "bikoTanto";
            itemName = "���l�i�S���j";
            if (BmaValidator.validateMaxLength(shiyoKaijo.getBikoTanto(), BmaConstants.MAX_LENGTH_BIKO_TANTO, errors, groupCode, itemName)) {
                BmaValidator.validateMojiCodeForBiko(shiyoKaijo.getBikoTanto(), errors, groupCode, itemName);
            }
//            }
        }

        inSession.setErrors(errors);
        return errors.isEmpty();
    }

    /**
     * ����_TO������_FROM�ȍ~���ǂ����`�F�b�N
     *
     * @param startDate ����_FROM
     * @param endDate ����_TO
     * @return true:�J�n�����O�@false:�I�������O
     */
    private boolean checkStartEndDate(String startDate, String endDate) {
        /* �ϐ������� */
        SimpleDateFormat f = new SimpleDateFormat("yyyyMMdd");

        String checkStart = startDate;
        String checkEnd = endDate;

        try {
            Date dateStart = f.parse(checkStart);
            Date dateEnd = f.parse(checkEnd);
            if (dateStart.compareTo(dateEnd) != 1) {
                return true;
            } else {
                return false;
            }
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return false;
    }

    /**
     * �w��̊��ԓ����ǂ����`�F�b�N�i���ԁj �i����OK�j
     *
     * @param startDate �J�n��
     * @param endDate �I����
     * @param standardStartDate �w��̊��Ԃ̊J�n��
     * @param standardEndDate �w��̊��Ԃ̏I����
     * @return true:�������ԓ��@false:�������ԊO
     */
    private boolean checkDaysInTerm(String startDate, String endDate, String standardStartDate, String standardEndDate) {
        /* �ϐ������� */
        SimpleDateFormat f = new SimpleDateFormat("yyyyMMdd");

        try {
            Date dateStart = f.parse(startDate);
            Date dateEnd = f.parse(endDate);
            Date dateStandardStart = f.parse(standardStartDate);
            Date dateStandardEnd = f.parse(standardEndDate);
            if (dateStart.compareTo(dateStandardStart) != -1
                    && dateEnd.compareTo(dateStandardEnd) != 1) {
                return true;
            } else {
                return false;
            }
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return false;
    }
}
