package jp.co.nii.bma.integration;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import static jp.co.nii.bma.business.domain.GeneratedKessaiDao.TABLE_NAME;
import jp.co.nii.bma.business.domain.Kessai;
import jp.co.nii.bma.business.domain.KessaiDao;
import static jp.co.nii.bma.integration.GeneratedKessaiDaoImpl.FIELDS_DECRYPT;
import jp.co.nii.sew.common.LogGenerate;
import jp.co.nii.sew.integration.SQLStateSQLExceptionTranslater;

/**
 * ���� DAO�����N���X
 *
 * @author DB�Ǘ��c�[��
 */
public class KessaiDaoImpl extends GeneratedKessaiDaoImpl implements KessaiDao {

    /**
     * �C���X�^���X�𐶐�����B
     *
     * @param datasource �f�[�^�\�[�X��
     */
    public KessaiDaoImpl(String datasource) {
        super(datasource);
    }

    /**
     * ���� �̏����擾����B
     *
     * @param bo
     * @return ����
     */
    @Override
    public Kessai findRonriFlg(Kessai bo) {
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = "";
        try {
            con = getConnection();
            sql = "SELECT " + FIELDS_DECRYPT
                    + " FROM " + getSchemaName() + "." + TABLE_NAME
                    + " WHERE"
                    + " NENDO = ?"
                    + " AND UKETSUKE_NO = ?"
                    + " AND RONRI_SAKUJO_FLG = '0'";

            stmt = con.prepareStatement(sql);
            int i = 1;
            stmt.setString(i++, bo.getNendo());
            stmt.setString(i++, bo.getUketsukeNo());

            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();
            if (rs.next()) {
                setBoFromResultSet(bo, rs);
            } else {
                bo = null;
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return bo;
    }
}
