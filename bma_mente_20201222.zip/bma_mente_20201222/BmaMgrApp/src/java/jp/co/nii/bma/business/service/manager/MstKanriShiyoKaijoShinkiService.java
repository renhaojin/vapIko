package jp.co.nii.bma.business.service.manager;

import java.util.ArrayList;
import java.util.List;
import jp.co.nii.bma.business.domain.KaijoMst;
import jp.co.nii.bma.business.domain.KaijoTantoMst;
import jp.co.nii.bma.business.domain.MeishoKanri;
import jp.co.nii.bma.business.domain.Schedule;
import jp.co.nii.bma.business.domain.ShiyoKaijo;
import jp.co.nii.bma.business.domain.SknksuMst;
import jp.co.nii.bma.business.rto.manager.MstKanriShiyoKaijoJoho;
import jp.co.nii.bma.business.service.common.BmaConstants;
import jp.co.nii.bma.business.service.common.BmaLogger;
import jp.co.nii.bma.business.service.common.BmaValidator;
import jp.co.nii.bma.presentation.common.BmaText;
import jp.co.nii.bma.utility.BmaUtility;
import jp.co.nii.sew.business.service.AbstractService;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_BACK;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_EXCEPTION;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_RELOAD;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_SESSION;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_SUCCESS;
import jp.co.nii.sew.presentation.Messages;
import jp.co.nii.sew.presentation.Option;
import jp.co.nii.sew.presentation.RequestTransferObject;
import jp.co.nii.sew.utility.PropertyUtility;

/**
 *
 * @author nii19049
 */
public class MstKanriShiyoKaijoShinkiService extends AbstractService {

    /**
     * DB�ڑ��̃f�[�^�\�[�X
     */
    private static String DATA_SOURCE_NAME;
    /**
     * ���O
     */
    BmaLogger log = (BmaLogger) BmaLogger.getLogger(this.getClass().getName());
    /**
     * �Ɩ��R�[�h
     */
    private static final String BUSINESS_CODE = PropertyUtility.getProperty("business_code");
    /**
     * ���׃e�X�g���[�h
     */
    private static final String STRESS_MODE = PropertyUtility.getProperty(BUSINESS_CODE + "stress_mode");

    /**
     * �R���X�g���N�^
     */
    public MstKanriShiyoKaijoShinkiService() {
        super();
        /* DB�ڑ����̃��[�U�[������ */
        DATA_SOURCE_NAME = BmaConstants.DS_REGISTRANT;
    }

    /**
     * �T�[�r�X�N���X�̎��s���\�b�h
     *
     * @param rto ���N�G�X�g��񂩂�擾����rto
     * @param rtoInSession �Z�b�V�������rto
     * @return foward��
     * @throws Exception ��O
     */
    @Override
    public String doService(RequestTransferObject rto, RequestTransferObject rtoInSession)
            throws Exception {

        MstKanriShiyoKaijoJoho inRequest = (MstKanriShiyoKaijoJoho) rto;
        MstKanriShiyoKaijoJoho inSession = (MstKanriShiyoKaijoJoho) rtoInSession;
        String processName = "";

        /*�G���[���b�Z�[�W������*/
        inSession.setErrors(new Messages());

        try {
            if (!BmaUtility.isNullOrEmpty(inRequest.getShiyoKaijoShinki())) {
                /*�u�g�p���V�K�o�^�v��ʑJ�ڎ�*/
                processName = "MstKanriShiyoKaijoShinki";
                log.Start(processName);

                /* �c���Ă���Z�b�V������j�� */
                inSession.clearInfo();

                /**
                 * �����u�K��X�g���쐬
                 */
                inSession.setSknKbnList(findSknKsuList(BmaConstants.SKN_KBN));
                inSession.setKsuKbnList(findSknKsuList(BmaConstants.KSU_KBN));

                /* �J�Òn���X�g���쐬 */
                List<Option> list = createKaisaichiList();
                inSession.setKaisaichiCodeList(list);

                /**
                 * �g�p��ꃊ�X�g���쐬
                 */
                KaijoMst kaijoMst = new KaijoMst(DATA_SOURCE_NAME);
                List<MstKanriShiyoKaijoJoho> shiyoKaijoSearchResultList = kaijoMst.findAllKaijo();
                String detailCodes = "";
                List<MstKanriShiyoKaijoJoho> shiyoKaijoResultList = new ArrayList<MstKanriShiyoKaijoJoho>();
                for (MstKanriShiyoKaijoJoho shiyoKaijo : shiyoKaijoSearchResultList) {
                    detailCodes = shiyoKaijo.getKaisaichiCode()
                            + shiyoKaijo.getKaijoCode();
                    shiyoKaijo.setShiyoKaijoDetail(detailCodes);
                    shiyoKaijoResultList.add(shiyoKaijo);

                }
                inSession.setShiyoKaijoResultList(shiyoKaijoResultList);
                
                /* �u�g�p���V�K�o�^���́v��ʕ\�� */
                return FWD_NM_SUCCESS;

            } else if (!BmaUtility.isNullOrEmpty(inRequest.getShiyoKaijoShinkiInp())) {
                /*�u���ցv�{�^��������*/
                processName = "MstKanriShiyoKaijoShinki";
                log.Start(processName);

                /* �ϐ������� */
                String sknKsuCode = "";
                String shubetsuCode = "";
                String kaisuCode = "";
                Schedule sced = new Schedule(DATA_SOURCE_NAME);
                ShiyoKaijo syKaijo = new ShiyoKaijo(DATA_SOURCE_NAME);

                /* �I��l�ێ� */
                inSession.setSknksuKbn(inRequest.getSknksuKbn());
                if (BmaConstants.SKN_KBN.equals(inRequest.getSknksuKbn())) {
                    inSession.setSknName(inRequest.getSknName());
                    inSession.setKsuName("");
                } else if (BmaConstants.KSU_KBN.equals(inRequest.getSknksuKbn())) {
                    inSession.setSknName("");
                    inSession.setKsuName(inRequest.getKsuName());
                }
                
                // ���I��ێ�
                inSession.setKaijoSelect(inRequest.getKaijoSelect());
                // �I��l�`�F�b�N
                if (!validateInput(inSession)) {
                    // �G���[���������ꍇ�u�g�p���V�K�v���Reload
                    return FWD_NM_RELOAD;
                }

                // �I�����������u�K��ɍ��킹�āA�e�R�[�h���Z�b�V�����ɕێ�
                if (BmaConstants.SKN_KBN.equals(inSession.getSknksuKbn())) {
                    sknKsuCode = inSession.getSknName().substring(0, 2);
                    shubetsuCode = inSession.getSknName().substring(2, 4);
                    kaisuCode = inSession.getSknName().substring(4, 6);
                } else if (BmaConstants.KSU_KBN.equals(inSession.getSknksuKbn())) {
                    sknKsuCode = inSession.getKsuName().substring(0, 2);
                    shubetsuCode = inSession.getKsuName().substring(2, 4);
                    kaisuCode = inSession.getKsuName().substring(4, 6);
                }
                inSession.setSknKsuCode(sknKsuCode);
                inSession.setShubetsuCode(shubetsuCode);
                inSession.setKaisuCode(kaisuCode);

                String nendo = sced.findNendoKojiKikan(sknKsuCode, shubetsuCode, kaisuCode, BmaConstants.SCHED_CODE_OPEN, BmaConstants.SCHEDULE_KBN_ST);
                
                String nendoBf = syKaijo.nendoForDelete(sknKsuCode, shubetsuCode, kaisuCode);
                
                if (nendo.equals(nendoBf)) {
                    // �G���[���������ꍇ�u�g�p���V�K�v���Reload
                            Messages errors = new Messages();
                            BmaValidator.addMessage(errors, "nendo", BmaText.E00134, "�N�x");
                            inSession.setErrors(errors);
                    return FWD_NM_RELOAD;
                }
                inSession.setNendo(nendo);
//                inSession.setNendoBefore(nendoBf);
                
                /* �����u�K��@���̎擾 */
                SknksuMst sknksuMst = new SknksuMst(BmaConstants.DS_REGISTRANT);
                inSession.setSknksuNameRyaku(sknksuMst.findSknKsuNameRyaku(sknKsuCode, shubetsuCode, kaisuCode).getSknKsuNameRyaku());

                KaijoMst kaijoMst = new KaijoMst(DATA_SOURCE_NAME);

                String[] kaisaichiCodes = new String[inSession.getKaijoSelect().length];
                String[] kaijoCodes = new String[inSession.getKaijoSelect().length];
                for (int i = 0; i < inSession.getKaijoSelect().length; ++i) {
                    kaisaichiCodes[i] = inSession.getKaijoSelect()[i].substring(0, 2);
                    kaijoCodes[i] = inSession.getKaijoSelect()[i].substring(2, 5);
                }

                List<MstKanriShiyoKaijoJoho> kaijoResult = kaijoMst.findByKaijo(kaisaichiCodes, kaijoCodes);

                /**
                 * �J�Òn�����ƂɁA�S���҃��X�g���쐬
                 */
                KaijoTantoMst tanto = new KaijoTantoMst(DATA_SOURCE_NAME);
                for (int i = 0; i < kaijoResult.size(); ++i) {
                    List<Option> tantoshaList = new ArrayList<Option>();
                    MstKanriShiyoKaijoJoho shiyoKaijo = kaijoResult.get(i);

                    String kaisaichi = shiyoKaijo.getKaisaichiCode();
                    String kaijo = shiyoKaijo.getKaijoCode();
                    tanto.findByOneTantosha(kaisaichi, kaijo, tantoshaList);

                    shiyoKaijo.setKaisaichiCode(kaisaichi);
                    shiyoKaijo.setKaijoCode(kaijo);
                    shiyoKaijo.setTantoshaList(tantoshaList);
                    shiyoKaijo.setTantosha("");
                    shiyoKaijo.setShiyoKaijoHukusei(kaisaichi + kaijo);
                    kaijoResult.set(i, shiyoKaijo);
                }

                inSession.setKaijoList(kaijoResult);

                /* �u�g�p���V�K�o�^���́v��ʕ\�� */
                return "next";

            } else if (!BmaUtility.isNullOrEmpty(inRequest.getBack())) {
                /*�u�߂�v�{�^��������*/
                processName = "MstKanriShiyoKaijoShinki";
                log.Start(processName);

                /* �u���}�X�^�����E�ꗗ�v��ʕ\�� */
                return FWD_NM_BACK;

            } else {
                /*�ُ�J��*/
                log.IllegalFWD();
                return FWD_NM_SESSION;
            }
        } catch (Exception e) {
            return FWD_NM_EXCEPTION;
        } finally {
            log.End(processName);
        }
    }

    /**
     * �����u�K���X�g���擾����
     *
     * @param sknksuKbn
     * @return
     */
    public List<Option> findSknKsuList(String sknksuKbn) {
        List<Option> list = new ArrayList<>();
        //�����u�K���X�g��p�ӂ���
        SknksuMst sknksuMst = new SknksuMst(BmaConstants.DS_REGISTRANT);
        sknksuMst.findBySknKsuKbn(sknksuKbn, list);
        return list;
    }

    /**
     * �J�Òn���X�g�̍쐬
     *
     * @param inSession �Z�b�V�������
     */
    private List<Option> createKaisaichiList() {
        /* �ϐ������� */
        List<Option> list = new ArrayList<>();
        MeishoKanri meishoKanri = new MeishoKanri(BmaConstants.DS_REGISTRANT);

        /* �J�Òn���̃��X�g��p�� */
        meishoKanri.findByGroupCode(BmaConstants.MEISHO_KANRI_GROUP_KAISAICHI_CODE, list);
        return list;
    }

    private MstKanriShiyoKaijoJoho createShiyoKaijoDetail(ShiyoKaijo shiyoKaijo, List<Option> kaisaichiCodeList) {

        String detailCodes = "";

        MstKanriShiyoKaijoJoho shiyoKaijoShinkiInp = new MstKanriShiyoKaijoJoho();

        // �ڍ׃{�^���p
        detailCodes = shiyoKaijo.getKaisaichiCode()
                + shiyoKaijo.getKaijoCode();
        shiyoKaijoShinkiInp.setShiyoKaijoDetail(detailCodes);

        return shiyoKaijoShinkiInp;
    }

    /**
     * ���̓`�F�b�N
     *
     * @param inSession �Z�b�V����RTO
     * @return true:�G���[��
     */
    private boolean validateInput(MstKanriShiyoKaijoJoho inSession) {
        /* �ϐ������� */
        Messages errors = new Messages();
        String groupCode;
        String itemName;

        // �G���[�`�F�b�N�p���X�g�쐬
        String[] sknKsuKbns = {BmaConstants.SKN_KBN, BmaConstants.KSU_KBN};

        /* �����u�K��敪 */
        groupCode = "sknksuKbn";
        itemName = "�����^�u�K��";
        BmaValidator.validateSelect(inSession.getSknksuKbn(), errors, groupCode, itemName);
        BmaValidator.validatePermissionSelect(inSession.getSknksuKbn(), sknKsuKbns, errors, groupCode, itemName);

        /* �����u�K�� */
        groupCode = "sknKsuCode";
        itemName = "�����^�u�K� ";
        if (BmaConstants.SKN_KBN.equals(inSession.getSknksuKbn())) {
            BmaValidator.validateSelect(inSession.getSknName(), errors, groupCode, itemName);
            BmaValidator.validatePermissionSelect(inSession.getSknName(), inSession.getSknKbnList(), errors, groupCode, itemName);
        } else if (BmaConstants.KSU_KBN.equals(inSession.getSknksuKbn())) {
            BmaValidator.validateSelect(inSession.getKsuName(), errors, groupCode, itemName);
            BmaValidator.validatePermissionSelect(inSession.getKsuName(), inSession.getKsuKbnList(), errors, groupCode, itemName);
        }

        /* �J�Òn�R�[�h */
        groupCode = "kaisaichiCode";
        itemName = "�J�Òn";
        String kaisaichiCode;

        if (inSession.getKaijoSelect() == null) {
            BmaValidator.addMessage(errors, groupCode, BmaText.E00003, itemName);
        } else {

            for (String element : inSession.getKaijoSelect()) {
                kaisaichiCode = element.substring(0, 2);
                BmaValidator.validatePermissionSelect(kaisaichiCode, inSession.getKaisaichiCodeList(), errors, groupCode, itemName);
                if (!errors.isEmpty()) {
                    break;
                }
            }
        }

        inSession.setErrors(errors);
        return errors.isEmpty();
    }
    
}
