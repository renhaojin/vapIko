package jp.co.nii.bma.business.service.manager;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import jp.co.nii.bma.business.domain.ShiyoKaijo;
import jp.co.nii.bma.business.rto.manager.MstKanriKaijoTantoJoho;
import jp.co.nii.bma.business.rto.manager.MstKanriShiyoKaijoJoho;
import jp.co.nii.bma.business.service.common.BmaConstants;
import jp.co.nii.bma.business.service.common.BmaLogger;
import static jp.co.nii.bma.business.service.manager.MstKanriShiyoKaijoSerchService.dateToWeek;
import jp.co.nii.bma.utility.BmaUtility;
import jp.co.nii.sew.business.service.AbstractService;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_EXCEPTION;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_SESSION;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_SUCCESS;
import jp.co.nii.sew.presentation.Messages;
import jp.co.nii.sew.presentation.Option;
import jp.co.nii.sew.presentation.RequestTransferObject;
import jp.co.nii.sew.utility.PropertyUtility;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author nii19049
 */
public class MstKanriShiyoKaijoAddCompleteService extends AbstractService {

    /**
     * DB�ڑ��̃f�[�^�\�[�X
     */
    private static String DATA_SOURCE_NAME;
    /**
     * ���O
     */
    BmaLogger log = (BmaLogger) BmaLogger.getLogger(this.getClass().getName());
    /**
     * �Ɩ��R�[�h
     */
    private static final String BUSINESS_CODE = PropertyUtility.getProperty("business_code");
    /**
     * ���׃e�X�g���[�h
     */
    private static final String STRESS_MODE = PropertyUtility.getProperty(BUSINESS_CODE + "stress_mode");

    /**
     * �R���X�g���N�^
     */
    public MstKanriShiyoKaijoAddCompleteService() {
        super();
        /* DB�ڑ����̃��[�U�[������ */
        DATA_SOURCE_NAME = BmaConstants.DS_REGISTRANT;
    }

    /**
     * �T�[�r�X�N���X�̎��s���\�b�h
     *
     * @param rto ���N�G�X�g��񂩂�擾����rto
     * @param rtoInSession �Z�b�V�������rto
     * @return foward��
     * @throws Exception ��O
     */
    @Override
    public String doService(RequestTransferObject rto, RequestTransferObject rtoInSession)
            throws Exception {

        MstKanriShiyoKaijoJoho inRequest = (MstKanriShiyoKaijoJoho) rto;
        MstKanriShiyoKaijoJoho inSession = (MstKanriShiyoKaijoJoho) rtoInSession;
        String processName = "";

        /*�G���[���b�Z�[�W������*/
        inSession.setErrors(new Messages());
        try {
            if (!BmaUtility.isNullOrEmpty(inRequest.getNext())) {
                /*�u�ꗗ�֖߂�v�{�^��������*/
                processName = "MstKanriShiyoKaijoAddComplete";
                log.Start(processName);

                /*���X�g�擾*/
                ShiyoKaijo shiyoKaijo = new ShiyoKaijo(DATA_SOURCE_NAME);
//                String nendo = inSession.getSknKsuCode();
                String sknKsuCode = inSession.getSknKsuCode();
                String shubetsuCode = inSession.getShubetsuCode();
                String kaisuCode = inSession.getKaisuCode();

                String[] kaisaichiCodes = inSession.getKaisaichiSelect();

                List<ShiyoKaijo> shiyoKaijoSearchList = shiyoKaijo.findByKaisaichi(sknKsuCode, shubetsuCode, kaisuCode, kaisaichiCodes);

                if (!shiyoKaijoSearchList.isEmpty()) {
                    List<MstKanriShiyoKaijoJoho> shiyoKaijoSearchResultList = new ArrayList<>();
                    for (ShiyoKaijo element : shiyoKaijoSearchList) {
                        MstKanriShiyoKaijoJoho shiyoKaijoDetail = createShiyoKaijoDetail(element, inSession.getKaisaichiCodeList());
                        saveShiyoKaijoSession(element, shiyoKaijoDetail);
                        setNitteiDisp(element, shiyoKaijoDetail);
                        shiyoKaijoSearchResultList.add(shiyoKaijoDetail);
                    }
                    inSession.setShiyoKaijoSearchResultList(shiyoKaijoSearchResultList);
                    inSession.setShiyoKaijoSrcListFlg(BmaConstants.FLG_ON);

                    // �y�[�W����
                    inSession.setPage(0);
                    setPage(inSession);
                    setDisplayList(inSession);
                }

                /* �c���Ă���Z�b�V������j�� */
                inSession.setShiyoKaijoSrcListFlg("1");
                inSession.setShiyoKaijoInputList(new ArrayList<MstKanriShiyoKaijoJoho>());
                inSession.setKaijoList(new ArrayList<MstKanriShiyoKaijoJoho>());
                
                /* �u�g�p��ꌟ���E�ꗗ�v��ʕ\�� */
                return FWD_NM_SUCCESS;

            } else {
                /*�ُ�J��*/
                log.IllegalFWD();
                return FWD_NM_SESSION;
            }
        } catch (Exception e) {
            return FWD_NM_EXCEPTION;
        } finally {
            log.End(processName);
        }
    }

    /**
     * �w��y�[�W���ɍ��킹�āA�\������S���҃��X�g���쐬
     *
     * @param inSession�@�Z�b�V�������X�g
     */
    private void setDisplayList(MstKanriShiyoKaijoJoho inSession) {
        /* �ϐ������� */
        List<MstKanriShiyoKaijoJoho> displayList = new ArrayList<MstKanriShiyoKaijoJoho>();
        MstKanriShiyoKaijoJoho shiyoKaijo;

        List<MstKanriShiyoKaijoJoho> resultList = inSession.getShiyoKaijoSearchResultList();
        /* �y�[�W���ɍ��킹�ĕ\���p���X�g�쐬 */
        for (int i = inSession.getFirstDisp() - 1; i < inSession.getMaxDisp(); ++i) {
            shiyoKaijo = resultList.get(i);
            displayList.add(shiyoKaijo);
        }
        inSession.setShiyoKaijoDisplayList(displayList);
    }

    /**
     * �y�[�W����
     *
     * @param inSession�@�Z�b�V�������X�g
     */
    private void setPage(MstKanriShiyoKaijoJoho inSession) {
        /* �ϐ������� */
        int idx;
        int max;
        int maxLenDisp = inSession.getShiyoKaijoSearchResultList().size();
        int pageMax;

        /* ��ʂɕ\������ő匏�����擾 */
        int page = inSession.getPage();
        idx = page * BmaConstants.MAX_PAGE_NUM_SHIYOKAIJO_SEARCH;

        max = idx + BmaConstants.MAX_PAGE_NUM_SHIYOKAIJO_SEARCH;
        inSession.setFirstDisp(idx + 1);

        /* �������ʂ̌��� */
        if (maxLenDisp < max) {
            inSession.setMaxDisp(maxLenDisp);
        } else {
            /* �ő匏����茟�����ʂ������ꍇ */
            inSession.setMaxDisp(max);
        }

        /* �y�[�W�ԍ��̍ő���v�Z */
        pageMax = (int) (Math.ceil((double) maxLenDisp / (double) (BmaConstants.MAX_PAGE_NUM_SHIYOKAIJO_SEARCH)));
        inSession.setPageMax(pageMax + 1);

        /* �y�[�W�ԍ��ݒ� */
        int now = 0;
        now = inSession.getPage();

        /* �Œጏ�� */
        if (now == 0) {
            inSession.setPageBegin(now + 1);
        } else if (now == 1) {
            inSession.setPageBegin(now);
        } else if (now == 2) {
            inSession.setPageBegin(now - 1);
        } else {
            inSession.setPageBegin(now - 2);
        }
        /* �ő匏�����\������ő匏����3�{�ȉ��������ꍇ�̕\���p�y�[�W�ԍ� */
        if (now == pageMax) {
            inSession.setPageEnd(now + 1);
        } else if (now == pageMax - 1) {
            inSession.setPageEnd(now + 2);
        } else if (now == pageMax - 2) {
            inSession.setPageEnd(now + 3);
        } else {
            inSession.setPageEnd(now + 4);
        }
        inSession.setPage(now + 1);
    }

    /**
     * �ꗗ�\���p�ɐ��`����
     *
     * @param kaijoMst ��������
     * @return �������ʕ\���p
     */
    private MstKanriShiyoKaijoJoho createShiyoKaijoDetail(ShiyoKaijo shiyoKaijo, List<Option> kaisaichiCodeList) {
        String teiinBfr = "";
        String teiinAft = "";
        String detailCodes = "";
        String kaijoShikenKbnName = "";
        String kaijoShikenName = "";

        MstKanriShiyoKaijoJoho shiyoKaijoDetail = new MstKanriShiyoKaijoJoho();

        /**
         * ����̐��`
         */
        teiinBfr = shiyoKaijo.getTeiin();
        teiinAft = teiinBfr.replaceFirst("^0+", "");
        if (teiinAft.isEmpty()) {
            teiinAft = "0";
        } else if (teiinAft.length() > 3) {
            teiinAft = teiinAft.substring(0, teiinAft.length() - 3)
                    + ","
                    + teiinAft.substring(teiinAft.length() - 3);
        }
        shiyoKaijoDetail.setTeiinDisp(teiinAft);

        /* ��ꎎ���敪���́i���́j���Z�b�g */
        if (BmaConstants.KAIJO_SHIKEN_KBN_NASHI.equals(shiyoKaijo.getKaijoShikenKbn())) {
            kaijoShikenKbnName = "-";
        } else if (BmaConstants.KAIJO_SHIKEN_KBN_GAKKA.equals(shiyoKaijo.getKaijoShikenKbn())) {
            kaijoShikenKbnName = "�w��";
        } else if (BmaConstants.KAIJO_SHIKEN_KBN_ZITSUGI.equals(shiyoKaijo.getKaijoShikenKbn())) {
            kaijoShikenKbnName = "���Z";
        }
        shiyoKaijoDetail.setKaijoShikenKbnName(kaijoShikenKbnName);

        /* ��ꎎ���敪���̂��Z�b�g */
        if (BmaConstants.KAIJO_SHIKEN_KBN_NASHI.equals(shiyoKaijo.getKaijoShikenKbn())) {
            kaijoShikenName = "�敪���g�p���Ȃ�";
        } else if (BmaConstants.KAIJO_SHIKEN_KBN_GAKKA.equals(shiyoKaijo.getKaijoShikenKbn())) {
            kaijoShikenName = "�w�Ȏ����y�ю��Z�y�[�p�[�e�X�g";
        } else if (BmaConstants.KAIJO_SHIKEN_KBN_ZITSUGI.equals(shiyoKaijo.getKaijoShikenKbn())) {
            kaijoShikenName = "���Z��Ǝ���";
        }
        shiyoKaijoDetail.setKaijoShikenName(kaijoShikenName);

        // �ڍ׃{�^���p
        detailCodes = shiyoKaijo.getNendo()
                + shiyoKaijo.getSknKsuCode()
                + shiyoKaijo.getShubetsuCode()
                + shiyoKaijo.getKaisuCode()
                + shiyoKaijo.getKaijoId()
                + shiyoKaijo.getKaijoShikenKbn()
                + shiyoKaijo.getKaisaichiCode()
                + shiyoKaijo.getKaijoCode();
        shiyoKaijoDetail.setShiyoKaijoDetail(detailCodes);

        for (Option kaisaichi : kaisaichiCodeList) {
            if (kaisaichi.getValue().equals(shiyoKaijo.getKaisaichiCode())) {
                /**
                 * �J�Òn���̂��Z�b�g
                 */
                shiyoKaijoDetail.setKaisaichiName(kaisaichi.getLabel());
                break;
            }
        }

        shiyoKaijoDetail.setFromYear(shiyoKaijo.getNitteiFrom().substring(0, 4));
        shiyoKaijoDetail.setFromMonth(shiyoKaijo.getNitteiFrom().substring(4, 6));
        shiyoKaijoDetail.setFromDate(shiyoKaijo.getNitteiFrom().substring(6, 8));
        shiyoKaijoDetail.setFromYobi(dateToWeek(shiyoKaijo.getNitteiFrom()));

        shiyoKaijoDetail.setToYear(shiyoKaijo.getNitteiTo().substring(0, 4));
        shiyoKaijoDetail.setToMonth(shiyoKaijo.getNitteiTo().substring(4, 6));
        shiyoKaijoDetail.setToDate(shiyoKaijo.getNitteiTo().substring(6, 8));
        shiyoKaijoDetail.setToYobi(dateToWeek(shiyoKaijo.getNitteiTo()));

        return shiyoKaijoDetail;
    }

    private void setNitteiDisp(ShiyoKaijo nittei, MstKanriShiyoKaijoJoho nitteiDisp) {

        nitteiDisp.setFromYear(nittei.getNitteiFrom().substring(0, 4));
        nitteiDisp.setFromMonth(nittei.getNitteiFrom().substring(4, 6));
        nitteiDisp.setFromDate(nittei.getNitteiFrom().substring(6, 8));
        nitteiDisp.setFromYobi(dateToWeek(nittei.getNitteiFrom()));

        nitteiDisp.setToYear(nittei.getNitteiTo().substring(0, 4));
        nitteiDisp.setToMonth(nittei.getNitteiTo().substring(4, 6));
        nitteiDisp.setToDate(nittei.getNitteiTo().substring(6, 8));
        nitteiDisp.setToYobi(dateToWeek(nittei.getNitteiTo()));

    }

    /**
     * �W���f�[�^��MstKanriShiyoKaijoJoho�ɕێ�
     *
     * @param shiyoKaijo ���f�[�^
     * @param saveObject �ۑ���
     */
    private void saveShiyoKaijoSession(ShiyoKaijo shiyoKaijo, MstKanriShiyoKaijoJoho saveObject) {
        saveObject.setNendo(shiyoKaijo.getNendo());
        saveObject.setSknKsuCode(shiyoKaijo.getSknKsuCode());
        saveObject.setShubetsuCode(shiyoKaijo.getShubetsuCode());
        saveObject.setKaisuCode(shiyoKaijo.getKaisuCode());
        saveObject.setKaijoId(shiyoKaijo.getKaijoId());
        saveObject.setKaijoShikenKbn(shiyoKaijo.getKaijoShikenKbn());
        saveObject.setKaisaichiCode(shiyoKaijo.getKaisaichiCode());
        saveObject.setKaijoCode(shiyoKaijo.getKaijoCode());
        saveObject.setKaijoName(shiyoKaijo.getKaijoName());
        saveObject.setKaijoNameRyaku(shiyoKaijo.getKaijoNameRyaku());
        saveObject.setYubinNo(shiyoKaijo.getYubinNo());
        saveObject.setJusho(shiyoKaijo.getJusho());
        saveObject.setTantoshaCode(shiyoKaijo.getTantoshaCode());
        saveObject.setNitteiFrom(shiyoKaijo.getNitteiFrom());
        saveObject.setNitteiTo(shiyoKaijo.getNitteiTo());
        saveObject.setTeiin(shiyoKaijo.getTeiin());
        saveObject.setGenzaiNinzu(shiyoKaijo.getGenzaiNinzu());
        saveObject.setBikoKaijo(shiyoKaijo.getBikoKaijo());
        saveObject.setBikoTanto(shiyoKaijo.getBikoTanto());
    }

}
