package jp.co.nii.bma.integration;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import jp.co.nii.bma.business.domain.KaijoMst;
import jp.co.nii.bma.business.domain.KaijoMstDao;
import jp.co.nii.bma.business.domain.KaijoTantoMstDao;
import jp.co.nii.bma.business.domain.MeishoKanriDao;
import jp.co.nii.bma.business.rto.manager.MstKanriKaijoMstJoho;
import jp.co.nii.bma.business.rto.manager.MstKanriShiyoKaijoJoho;
import jp.co.nii.sew.common.LogGenerate;
import static jp.co.nii.sew.integration.AbstractDao.getSchemaName;
import jp.co.nii.sew.integration.SQLStateSQLExceptionTranslater;
import jp.co.nii.sew.presentation.Option;

/**
 * ���}�X�^ DAO�����N���X
 *
 * @author DB�Ǘ��c�[��
 */
public class KaijoMstDaoImpl extends GeneratedKaijoMstDaoImpl implements KaijoMstDao {

    /**
     * �C���X�^���X�𐶐�����B
     *
     * @param datasource �f�[�^�\�[�X��
     */
    public KaijoMstDaoImpl(String datasource) {
        super(datasource);
    }

    @Override
    public List<KaijoMst> findByKaisaichi(String[] kaisaichiCodes) {

        /**
         * �����J�Òn��������擾����B
         *
         * @param kaisaichiCodes �J�Òn�R�[�h
         */
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = "";
        List<String> param = new ArrayList<>();
        List<KaijoMst> kaijoByKaisaichiList = new ArrayList<>();

        try {
            con = getConnection();
            sql = "SELECT "
                    + "kaijo.KAISAICHI_CODE AS KAISAICHI_CODE"
                    + ", " + "kaijo.KAIJO_CODE AS KAIJO_CODE"
                    + ", " + "kaijo.KAIJO_NAME AS KAIJO_NAME"
                    + ", " + "kaijo.JUSHO AS JUSHO"
                    + ", " + "kaijo.TEIIN AS TEIIN"
                    + " FROM " + getSchemaName() + "." + KaijoMstDao.TABLE_NAME + " AS kaijo"
                    + " WHERE " + "kaijo.KAISAICHI_CODE IN ( ";

            for (int i = 0; i < kaisaichiCodes.length; i++) {
                if (i > 0) {
                    sql += ", ";
                }
                sql += "?";
            }
            sql += " )";
            sql += " AND " + "kaijo.RONRI_SAKUJO_FLG = '0'"
                    + " ORDER BY kaijo.KAISAICHI_CODE ASC , kaijo.KAIJO_CODE ASC";

            stmt = con.prepareStatement(sql);

            for (int i = 0; i < kaisaichiCodes.length; i++) {
                param.add(kaisaichiCodes[i]);
            }
            int j = 1;
            for (String kaisaichi : param) {
                stmt.setString(j++, kaisaichi);
            }

            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();

            while (rs.next()) {
                KaijoMst detail = new KaijoMst();
                detail.setKaisaichiCode(rs.getString("KAISAICHI_CODE"));
                detail.setKaijoCode(rs.getString("KAIJO_CODE"));
                detail.setKaijoName(rs.getString("KAIJO_NAME"));
                // �Z��
                detail.setJusho(rs.getString("JUSHO"));
                // ���
                detail.setTeiin(rs.getString("TEIIN"));

                kaijoByKaisaichiList.add(detail);
            }

        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return kaijoByKaisaichiList;
    }

    /**
     * 1�̊J�Òn������R�[�h�Ɖ�ꖼ���擾����B
     *
     * @param kaisaichi �J�Òn�R�[�h
     * @param list ��������
     */
    @Override
    public void findByOneKaisaichi(String kaisaichi, List<Option> list) {

        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql;

        try {
            con = getConnection();
            sql = "SELECT "
                    + "kaijo.KAISAICHI_CODE AS KAISAICHI_CODE"
                    + ", " + "kaijo.KAIJO_CODE AS KAIJO_CODE"
                    + ", " + "kaijo.KAIJO_NAME AS KAIJO_NAME"
                    + " FROM " + getSchemaName() + "." + KaijoMstDao.TABLE_NAME + " AS kaijo"
                    + " WHERE"
                    + " kaijo.KAISAICHI_CODE = ?"
                    + " AND kaijo.RONRI_SAKUJO_FLG = '0'"
                    + " ORDER BY kaijo.KAIJO_CODE";

            stmt = con.prepareStatement(sql);

            int i = 1;
            stmt.setString(i++, kaisaichi);
            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();

            while (rs.next()) {
                if (list != null) {
                    list.add(new Option(rs.getString("KAIJO_CODE"), rs.getString("KAIJO_NAME")));
                }
            }

        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
    }

    @Override
    public List<MstKanriKaijoMstJoho> findByKsc(String kaisaichiCode) {

        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = "";
        List<MstKanriKaijoMstJoho> kaisaichiMstSearchList = new ArrayList<>();

        try {
            con = getConnection();
            sql = "SELECT "
                    + "km.KAISAICHI_CODE AS KAISAICHI_CODE"
                    + ", " + "km.KAIJO_CODE AS KAIJO_CODE"
                    + ", " + "km.KAIJO_NAME AS KAIJO_NAME"
                    + ", " + "km.JUSHO AS JUSHO"
                    + ", " + "km.TEIIN AS TEIIN"
                    + " FROM " + getSchemaName() + "." + KaijoMstDao.TABLE_NAME + " AS km"
                    + " LEFT JOIN " + getSchemaName() + "." + MeishoKanriDao.TABLE_NAME + " AS kaisaichi_code"
                    + " ON " + "km.KAISAICHI_CODE = kaisaichi_code.HANYO_CODE "
                    + " AND " + "kaisaichi_code.GROUP_CODE = 'KAISAICHI_CODE' "
                    + " WHERE " + "km.KAISAICHI_CODE = ?"
                    + " ORDER BY km.KAISAICHI_CODE ASC, km.KAIJO_CODE ASC";

            stmt = con.prepareStatement(sql);
            int i = 1;
            stmt.setString(i++, kaisaichiCode);
            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();

            while (rs.next()) {
                MstKanriKaijoMstJoho detail = new MstKanriKaijoMstJoho();
                // ��ꖼ	
                detail.setKaisaichiCode(rs.getString("KAISAICHI_CODE"));
                detail.setKaijoCode(rs.getString("KAIJO_CODE"));
                detail.setKaijoName(rs.getString("KAIJO_NAME"));
                // �Z��
                detail.setJusho(rs.getString("JUSHO"));
                // ���
                detail.setTeiin(rs.getString("TEIIN"));

                kaisaichiMstSearchList.add(detail);
            }

        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return kaisaichiMstSearchList;
    }

    @Override
    public MstKanriKaijoMstJoho findDetail(String kaisaichiCode, String kaijoCode) {

        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = "";
        MstKanriKaijoMstJoho kaisaichiMstDetail = new MstKanriKaijoMstJoho();

        try {
            con = getConnection();
            sql = "SELECT "
                    + "km.KAISAICHI_CODE AS KAISAICHI_CODE"
                    + ", " + "km.KAIJO_CODE AS KAIJO_CODE"
                    + ", " + "km.KAIJO_NAME AS KAIJO_NAME"
                    + ", " + "km.KAIJO_NAME_RYAKU AS KAIJO_NAME_RYAKU"
                    + ", " + "km.YUBIN_NO AS YUBIN_NO"
                    + ", " + "km.JUSHO AS JUSHO"
                    + ", " + "km.TEIIN AS TEIIN"
                    + ", " + "km.KAIJO_HENKO_FLG AS KAIJO_HENKO_FLG"
                    + ", " + "km.CHUSHAJO_FLG AS CHUSHAJO_FLG"
                    + ", " + "km.CHIZU_DATA AS CHIZU_DATA"
                    + ", " + "km.BIKO AS BIKO"
                    + " FROM " + getSchemaName() + "." + KaijoMstDao.TABLE_NAME + " AS km"
                    + " LEFT JOIN " + getSchemaName() + "." + MeishoKanriDao.TABLE_NAME + " AS kaisaichi_code"
                    + " ON " + "km.KAISAICHI_CODE = kaisaichi_code.HANYO_CODE "
                    + " AND " + "kaisaichi_code.GROUP_CODE = 'KAISAICHI_CODE' "
                    + " LEFT JOIN " + getSchemaName() + "." + MeishoKanriDao.TABLE_NAME + " AS com_umu_flg"
                    + " ON " + "km.CHUSHAJO_FLG = com_umu_flg.HANYO_CODE "
                    + " AND " + "com_umu_flg.GROUP_CODE = 'COM_UMU_FLG' "
                    + " WHERE " + "km.KAISAICHI_CODE = ?"
                    + " AND " + "km.KAIJO_CODE = ?"
                    + " ORDER BY km.KAISAICHI_CODE ASC "
                    + " LIMIT 1 ";

            stmt = con.prepareStatement(sql);
            int i = 1;
            stmt.setString(i++, kaisaichiCode);
            stmt.setString(i++, kaijoCode);
            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();

            if (rs.next()) {
                // ��ꖼ	
                kaisaichiMstDetail.setKaisaichiCode(rs.getString("KAISAICHI_CODE"));
                kaisaichiMstDetail.setKaijoCode(rs.getString("KAIJO_CODE"));
                kaisaichiMstDetail.setKaijoName(rs.getString("KAIJO_NAME"));
                kaisaichiMstDetail.setKaijoNameRyaku(rs.getString("KAIJO_NAME_RYAKU"));
                //�X�֔ԍ�
                kaisaichiMstDetail.setYubinNo(rs.getString("YUBIN_NO"));
                // �Z��
                kaisaichiMstDetail.setJusho(rs.getString("JUSHO"));
                // ���
                kaisaichiMstDetail.setTeiin(rs.getString("TEIIN"));
                //���ύX�t���O
                kaisaichiMstDetail.setKaijoHenkoFlg(rs.getString("KAIJO_HENKO_FLG"));
                //���ԏ�t���O
                kaisaichiMstDetail.setChushajoFlg(rs.getString("CHUSHAJO_FLG"));
                //�n�}�f�[�^
                kaisaichiMstDetail.setChizuData(rs.getString("CHIZU_DATA"));
                //���l
                kaisaichiMstDetail.setBiko(rs.getString("Biko"));
            } else {
                kaisaichiMstDetail = null;
            }

        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return kaisaichiMstDetail;
    }

    /**
     * �J�Òn�R�[�h�����ƂɁA�����̉��R�[�h���擾����B
     *
     * @param kaisaichiCode �J�Òn�R�[�h
     */
    @Override
    public String findLastKaijoCode(String kaisaichiCode) {

        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = "";
        String lastKaijoCode = null;

        try {
            con = getConnection();
            sql = "SELECT "
                    + "MAX(kaijo.KAIJO_CODE) AS KAIJO_CODE"
                    + " FROM " + getSchemaName() + "." + KaijoMstDao.TABLE_NAME + " AS kaijo"
                    + " WHERE " + "kaijo.KAISAICHI_CODE = ?"
                    + " AND " + "kaijo.RONRI_SAKUJO_FLG = '0'";

            stmt = con.prepareStatement(sql);
            int i = 1;
            stmt.setString(i++, kaisaichiCode);
            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();

            if (rs.next()) {
                lastKaijoCode = rs.getString("KAIJO_CODE");
            } else {
                lastKaijoCode = null;
            }

        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return lastKaijoCode;
    }

    /**
     * �S�Ẳ����擾����B
     *
     */
    @Override
    public List<MstKanriShiyoKaijoJoho> findAllKaijo() {

        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql;
        List<MstKanriShiyoKaijoJoho> allKaijoList = new ArrayList<>();

        try {
            con = getConnection();
            sql = "SELECT "
                    + "kaijo.KAISAICHI_CODE AS KAISAICHI_CODE"
                    + ", " + "kaisaichi_code.HANYO_CHI AS KAISAICHI_NAME"
                    + ", " + "kaijo.KAIJO_CODE AS KAIJO_CODE"
                    + ", " + "kaijo.KAIJO_NAME AS KAIJO_NAME"
                    + ", " + "kaijo.KAIJO_NAME_RYAKU AS KAIJO_NAME_RYAKU"
                    + " FROM " + getSchemaName() + "." + KaijoMstDao.TABLE_NAME + " AS kaijo"
                    + " LEFT JOIN " + getSchemaName() + "." + MeishoKanriDao.TABLE_NAME + " AS kaisaichi_code"
                    + " ON " + "kaijo.KAISAICHI_CODE = kaisaichi_code.HANYO_CODE "
                    + " AND " + "kaisaichi_code.GROUP_CODE = 'KAISAICHI_CODE' "
                    + " WHERE"
                    + " kaijo.RONRI_SAKUJO_FLG = '0'"
                    + " ORDER BY kaijo.KAISAICHI_CODE, kaijo.KAIJO_CODE";

            stmt = con.prepareStatement(sql);

            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();

            while (rs.next()) {
                MstKanriShiyoKaijoJoho detail = new MstKanriShiyoKaijoJoho();
                detail.setKaisaichiCode(rs.getString("KAISAICHI_CODE"));
                detail.setKaisaichiName(rs.getString("KAISAICHI_NAME"));
                detail.setKaijoCode(rs.getString("KAIJO_CODE"));
                detail.setKaijoName(rs.getString("KAIJO_NAME"));
                detail.setKaijoNameRyaku(rs.getString("KAIJO_NAME_RYAKU"));

                allKaijoList.add(detail);
            }

        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return allKaijoList;

    }

    /**
     * �����J�Òn��������擾����B
     *
     * @param kaisaichiCodes �J�Òn�R�[�h
     */
    @Override
    public List<MstKanriShiyoKaijoJoho> findByKaijo(String[] kaisaichiCodes, String[] kaijoCodes) {

        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = "";
        List<String> param = new ArrayList<>();
        List<MstKanriShiyoKaijoJoho> kaijoByKaisaichiList = new LinkedList<>();

        try {
            con = getConnection();
            sql = "SELECT "
                    + "kaijo.KAISAICHI_CODE AS KAISAICHI_CODE"
                    + ", " + "kaisaichi_code.HANYO_CHI AS KAISAICHI_NAME"
                    + ", " + "kaijo.KAIJO_CODE AS KAIJO_CODE"
                    + ", " + "kaijo.KAIJO_NAME AS KAIJO_NAME"
                    + ", " + "kaijo.KAIJO_NAME_RYAKU AS KAIJO_NAME_RYAKU"
                    + ", " + "kaijo.JUSHO AS JUSHO"
                    + ", " + "kaijo.BIKO AS BIKO"
                    + " FROM " + getSchemaName() + "." + KaijoMstDao.TABLE_NAME + " AS kaijo"
                    + " LEFT JOIN " + getSchemaName() + "." + MeishoKanriDao.TABLE_NAME + " AS kaisaichi_code"
                    + " ON " + "kaijo.KAISAICHI_CODE = kaisaichi_code.HANYO_CODE "
                    + " AND " + "kaisaichi_code.GROUP_CODE = 'KAISAICHI_CODE' "
                    + " WHERE ";

            if (kaisaichiCodes.length > 1) {
                sql += "(";
            }
            for (int i = 0; i < kaisaichiCodes.length; i++) {
                if (i > 0) {
                    sql += " OR ";
                }
                sql += "(kaijo.KAISAICHI_CODE = ? AND kaijo.KAIJO_CODE = ?)";
            }
            if (kaisaichiCodes.length > 1) {
                sql += ")";
            }
            sql += " AND " + "kaijo.RONRI_SAKUJO_FLG = '0'"
                    + " ORDER BY kaijo.KAISAICHI_CODE ASC , kaijo.KAIJO_CODE ASC";

            stmt = con.prepareStatement(sql);

            for (int i = 0; i < kaisaichiCodes.length; i++) {
                param.add(kaisaichiCodes[i]);
                param.add(kaijoCodes[i]);
            }
            int j = 1;
            for (String code : param) {
                stmt.setString(j++, code);
            }

            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();

            while (rs.next()) {
                MstKanriShiyoKaijoJoho detail = new MstKanriShiyoKaijoJoho();
                detail.setKaisaichiCode(rs.getString("KAISAICHI_CODE"));
                detail.setKaisaichiName(rs.getString("KAISAICHI_NAME"));
                detail.setKaijoCode(rs.getString("KAIJO_CODE"));
                detail.setKaijoName(rs.getString("KAIJO_NAME"));
                detail.setKaijoNameRyaku(rs.getString("KAIJO_NAME_RYAKU"));
                // �Z��
                detail.setJusho(rs.getString("JUSHO"));
                // ���l
                detail.setBikoKaijo(rs.getString("BIKO"));

                kaijoByKaisaichiList.add(detail);
            }

        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return kaijoByKaisaichiList;
    }

    @Override
    public KaijoMst kaijoJohoForShiyoKaijo(String kaisaichiCode, String kaijoCode) {

        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = "";
        KaijoMst kaijo = new KaijoMst();

        try {
            con = getConnection();
            sql = "SELECT "
                    + "km.YUBIN_NO AS YUBIN_NO"
                    + ", " + "km.JUSHO AS JUSHO"
                    + ", " + "km.BIKO AS BIKO"
                    + " FROM " + getSchemaName() + "." + KaijoMstDao.TABLE_NAME + " AS km"
                    + " WHERE " + "km.KAISAICHI_CODE = ?"
                    + " AND " + "km.KAIJO_CODE = ?"
                    + " AND " + " km.RONRI_SAKUJO_FLG = '0'";

            stmt = con.prepareStatement(sql);
            int i = 1;
            stmt.setString(i++, kaisaichiCode);
            stmt.setString(i++, kaijoCode);
            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();

            if (rs.next()) {

                //�X�֔ԍ�
                kaijo.setYubinNo(rs.getString("YUBIN_NO"));
                // �Z��
                kaijo.setJusho(rs.getString("JUSHO"));
                //���l
                kaijo.setBiko(rs.getString("BIKO"));
            } else {
                kaijo = null;
            }

        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return kaijo;
    }

    /**
     * �J�Òn�R�[�h�����ƂɁA�����̉��R�[�h���擾����B
     *
     * @param kaisaichiCode �J�Òn�R�[�h
     * @param kaijoCode ���R�[�h
     */
    @Override
    public String findKaijoNameRyaku(String kaisaichiCode, String kaijoCode) {

        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = "";
        String kaijoName = "";

        try {
            con = getConnection();
            sql = "SELECT "
                    + "kaijo.KAIJO_NAME AS KAIJO_NAME"
                    + ", " + "kaijo.KAIJO_NAME_RYAKU AS KAIJO_NAME_RYAKU"
                    + " FROM " + getSchemaName() + "." + KaijoMstDao.TABLE_NAME + " AS kaijo"
                    + " WHERE " + "kaijo.KAISAICHI_CODE = ?"
                    + " AND " + "kaijo.KAIJO_CODE = ?"
                    + " AND " + "kaijo.RONRI_SAKUJO_FLG = '0'"
                    + " ORDER BY kaijo.KAIJO_CODE ASC "
                    + " LIMIT 1 ";

            stmt = con.prepareStatement(sql);
            int i = 1;
            stmt.setString(i++, kaisaichiCode);
            stmt.setString(i++, kaijoCode);
            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();

            if (rs.next()) {
                kaijoName = rs.getString("KAIJO_NAME");
//                kaijoName.setKaijoNameRyaku(rs.getString("KAIJO_NAME_RYAKU"));

            }

        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return kaijoName;
    }

    /**
     * 1�̊J�Òn������R�[�h�Ɖ�ꖼ���擾����B
     *
     * @param kaisaichiCodes �J�Òn�R�[�h
     * @param list ��������
     */
    @Override
    public void findByKaisaichies(String[] kaisaichiCodes, List<Option> list) {

        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql;
        List<String> param = new ArrayList<>();

        try {
            con = getConnection();
            sql = "SELECT "
                    + "kaijo.KAISAICHI_CODE AS KAISAICHI_CODE"
                    + ", " + "kaijo.KAIJO_CODE AS KAIJO_CODE"
                    + ", " + "kaijo.KAIJO_NAME AS KAIJO_NAME"
                    + " FROM " + getSchemaName() + "." + KaijoMstDao.TABLE_NAME + " AS kaijo"
                    + " WHERE"
                    + " kaijo.KAISAICHI_CODE IN (";
            for (int i = 0; i < kaisaichiCodes.length; i++) {
                if (i > 0) {
                    sql += ", ";
                }
                sql += "?";
            }
            sql += " )";
            sql += " AND " + "kaijo.RONRI_SAKUJO_FLG = '0'"
                    + " ORDER BY kaijo.KAISAICHI_CODE ASC , kaijo.KAIJO_CODE ASC";

            stmt = con.prepareStatement(sql);

            for (int i = 0; i < kaisaichiCodes.length; i++) {
                param.add(kaisaichiCodes[i]);
            }
            int j = 1;
            for (String kaisaichi : param) {
                stmt.setString(j++, kaisaichi);
            }
            
            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();

            while (rs.next()) {
                if (list != null) {
                    list.add(new Option(rs.getString("KAISAICHI_CODE") + rs.getString("KAIJO_CODE"), rs.getString("KAIJO_NAME")));
                }
            }

        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
    }
}
