package jp.co.nii.bma.business.rto.manager;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import jp.co.nii.bma.business.domain.HoyuShikakuMst;
import jp.co.nii.bma.business.service.common.BmaConstants;
import jp.co.nii.bma.business.service.manager.SmnMskService;
import jp.co.nii.sew.presentation.AbstractRequestTransferObject;
import jp.co.nii.sew.presentation.DownloadRTO;
import jp.co.nii.sew.presentation.Messages;
import jp.co.nii.sew.presentation.Option;
import org.apache.commons.fileupload.disk.DiskFileItem;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;

/**
 * �^�C�g��: �\���f�[�^�A�b�v���[�h ����: �\�����RTO ���쌠: Copyright (c) 2020 ��Ж�: ���{���Y�Ɗ������
 *
 * @author Luo-Yang
 */
public class SmnMskJoho extends DownloadRTO {

    private Messages errors;
    private String scrollPlace;
    /**
     * 01���ʐ\��_�\���f�[�^�A�b�v���[�h���
     */
    private String sknksuKbn;
    private List<Option> sknKbnList;
    private List<Option> ksuKbnList;
    private List<SmnMskJoho> kaiMskJohoList;
    private String kaisaichiCode;
    private String kaisaichi;
    private String date_From;
    private String date_To;
    private String date_From_Dsp;
    private String date_To_Dsp;
    private String kaijoCode;
    private String kaijoName;
    private String mskGazoUl;
    private String kaijoJusho;
    private String kuusekiSuu;
    private String sknName;
    private String ksuName;
    private String torokuCheck;
    private String shomenUketsukeNo;
    private String[] uketsukeNos;
    private String sknKsuNameChi;
    private int upKensu;
    /**
     * �u�Q�l�v�{�^��
     */
    /**
     * �u�e���v���[�g�_�E�����[�h�v�{�^��
     */
    private String mskTmpDl;
    /**
     * �u�A�b�v���[�h�v�{�^��
     */
    private String mskUl;
    private String gazoSearch;
    private String fileKbn;
    private String count;
    private String gazoKbn;

    SmnMskJoho(String kaisaichi, String kaijoName) {
        this.kaisaichi = kaisaichi;
        this.kaijoName = kaijoName;
    }

    private String kaijoshikenkbn;
    private String kessaiHoho;
    private String sakujoFlg;
    private DiskFileItem mskFileChoice;
    /**
     * 01-1���ʐ\��_�摜�f�[�^�A�b�v���[�h
     */
    private String gazoUlKekka;
    private String gazoUlSeq;
    private String gazoUlUketsukeNo;
    private String gazoUlJknJkuNo;
    private String gazoUlFurigana;
    private String gazoUlSimei;
    private String gazoUpd;
    private String gazoUlFlg;
    private String gazoUl;
    private String gazoUlKakunin;
    private String gokakuNo;
    private String birthday;
    private String nenrei;
    private String shimei;
    private String furigana;
    private String kaiinShinseiFlg;
    private String shikenNaiyoKbn;
    private String hairyoFlg;
    private String hairyoNaiyo;
    private String genmenFlg;
    private String biko;
    private String sofuSakiKbn;
    private String shikakuCode;
    private String shinseiShikakuNo;
    private String menjoCode;
    private String shinseiMenjoNo;
    private String shokurekiKbn;
    private String kinmusakiKaishaName;
    private String bushoYakushokuName;
    private String shokumuNaiyo;
    private String shozaichi;
    private String zaisekikikanFrom;
    private String zaisekikikanTo;
    private String kessaiHohoKbn;
    private String kaiinKbn;
    private String sex;
    private String yubinNo;
    private String todofuken;
    private String todofukenCode;
    private String jusho1;
    private String jusho2;
    private String tatemono;
    private String telNo;
    private String faxNo;
    private String mailAddress;
    private String kinmusakiName;
    private String kinmusakiYubinNo;
    private String kinmusakiTodofuken;
    private String kinmusakiTodofukenCode;
    private String kinmusakiJusho1;
    private String kinmusakiJusho2;
    private String kinmusakiTatemono;
    private String kinmusakiTelNo;
    private String kinmusakiFaxNo;
    private String uketsukeNo;

    private String kiboShikenchi;
    private String daiichiKibo;
    private String dainiKibo;
    private String kaiinFlg;
    private String nyukinBi;
    private String nyuKinkaku;
    private String kakuninBi;
    private String csvFlg;

    private String kigyoCode;
    private String gaijiFlg;
    private String gaijiShosai;
    private String kaijoId;
    private String shokurekiSeq;
    //�߂�{�^��
    private String gazoUlBack;
    //�����{�^��
    private String gazoUlComplete;
    /**
     * �_�E�����[�h�敪
     */
    private String downloadKbn;

    /**
     * 01-4���ʐ\��_���ʐ\������
     */
    private String torokuKanryoSknKsuName;
    private String torokuKanryoKensu;

    /**
     * ���j���[��ʂ́u���ʐ\���v�{�^��
     */
    private String shomenMsk;
    /**
     * w01-2���ʐ\��_�摜�I����� �{�^��
     */
    private String gazoChoiceBack;
    /**
     * w01-3���ʐ\��_�摜�m�F�@�{�^��
     */
    private String gazoKakuninBack;

    /**
     * ���X�g
     */
    private List<SmnMskJoho> gazoDetailList;
    private List<SmnMskJoho> searchOutList;
    private int pageMax;
    private int page;
    private int maxDisp;
    private int firstDisp;
    private int pageBegin;
    private int pageEnd;
    private String CommandPage;
    private String index;
    private String searchFlg;
    private String sknKsuCode;
    private String shubetsuCode;
    private String kaisuCode;
    private String nendo;
    private String gazo_idx;
    private String gazoHyojiKbn;
    private String seniFlg;
    private String moshikomishaId;
    private String seq;
    private String gazoChoiceGazoUpd;
    private String gazoChoice;
    private Workbook workbook;
    private List<String> errorLog;
    private List<String> shomenNoList;
    private String uploadCheck;
    //�V�[�g�ݒ�
    private Sheet sheet;
    //Excel�t�@�C����
    private String fileName;
    //Excel�o�͒l�ݒ�}�b�v
    private Map<String, Object> excelMap;
    //Excel�o�͒l�ݒ胊�X�g
    private List<Object>[] excelList;
    //Excel�o�͒l�ݒ胊�X�g�}�b�v
    private HashMap<String, List<Object>[]> excelListMap;
    //�W�vExcel�o�͒l�ݒ胊�X�g
    private Map<String, List<Object>[]> excelSyukeiList;
    //�V�[�g�i���o�[
    private int sheetNo;
    //�������s�֎~���X�g
    private List<String> autoWrapTextsNotList;
    //�\���ɓo�^������ID�}�b�v�i�u�K��̂݁j
    private Map<String, String> kiboKaijoId;
    private List<SmnMskJoho> kaijoCheckList;

    private String furiganaOnlyErrFlg;
    private String errorLogFlg;
    private String errorLogCheck;
    private List<SmnMskService.ErrorMsg> errorLogForDownload;
    //DB�o�^�X�V�p
    private List<SmnMskJoho> csvEvacuationList;
    private Map<String, HoyuShikakuMst> hoyuShikakuMstMapForUpdateBefore;

    /**
     * �R���X�g���N�^
     */
    public SmnMskJoho() {
        clearInfo();
    }

    /**
     * ���������\�b�h
     */
    public void clearInfo() {
        setErrors(new Messages());
        setScrollPlace("");
        /**
         * 01���ʐ\��_�\���f�[�^�A�b�v���[�h���
         */
        setCsvFlg("");
        setSknksuKbn("");
        setSknKsuCode("");
        setSearchFlg("");
        setSknName(BmaConstants.SKN_CHECK);
        setKsuName(BmaConstants.KSU_CHECK);
        setMskTmpDl("");
        setGazoUpd("");
        setMskUl("");
        setKaisaichiCode("");
        setKaisaichi("");
        setDate_From("");
        setDate_To("");
        setDate_From_Dsp("");
        setDate_To_Dsp("");
        setKaijoCode("");
        setKaijoName("");
        setKaijoJusho("");
        setKuusekiSuu("");
        setKaijoshikenkbn("");
        setMskGazoUl("");
        setGazoKbn("");
        setUketsukeNos(null);
        setUketsukeNo("");
        setSknKsuNameChi("");
        setUpKensu(0);
        /**
         * 01-1���ʐ\��_�摜�f�[�^�A�b�v���[�h
         */
        setGazoUlKekka("");
        setGazoUlSeq("");
        setGazoUlUketsukeNo("");
        setGazoUlJknJkuNo("");
        setGazoUlFurigana("");
        setGazoUlSimei("");
        setGazoUlFlg("");
        setGazoUl("");
        setGazoUlKakunin("");
        setGazoUlBack("");
        setGazoUlComplete("");
        setNendo("");
        setShubetsuCode("");
        setKaisuCode("");
        setGazo_idx("");
        setGazoSearch("");
        setDownloadKbn("");
        setGokakuNo("");
        setBirthday("");
        setNenrei("");
        setKaiinShinseiFlg("");
        setShikenNaiyoKbn("");
        setHairyoFlg("");
        setHairyoNaiyo("");
        setGenmenFlg("");
        setBiko("");
        setSofuSakiKbn("");
        setShikakuCode("");
        setShinseiShikakuNo("");
        setMenjoCode("");
        setShinseiMenjoNo("");
        setShokurekiKbn("");
        setKinmusakiKaishaName("");
        setBushoYakushokuName("");
        setShokumuNaiyo("");
        setShozaichi("");
        setZaisekikikanFrom("");
        setZaisekikikanTo("");
        setKessaiHohoKbn("");
        setKaiinKbn("");
        setSex("");
        setYubinNo("");
        setTodofukenCode("");
        setJusho1("");
        setJusho2("");
        setTatemono("");
        setTelNo("");
        setFaxNo("");
        setMailAddress("");
        setKinmusakiName("");
        setKinmusakiYubinNo("");
        setKinmusakiTodofukenCode("");
        setKinmusakiJusho1("");
        setKinmusakiJusho2("");
        setKinmusakiTatemono("");
        setKinmusakiTelNo("");
        setKinmusakiFaxNo("");
        setKigyoCode("");
        setGaijiFlg("");
        setGaijiShosai("");
        setKaijoId("");
        setShomenUketsukeNo("");
        setShokurekiSeq("");
        setShimei("");
        setFurigana("");
        setTodofuken("");
        setTorokuCheck("");
        setFileKbn("");
        setUploadCheck("");
        /**
         * 01-4���ʐ\��_���ʐ\������
         */
        setTorokuKanryoSknKsuName(torokuKanryoSknKsuName);
        setTorokuKanryoKensu(torokuKanryoKensu);

        /**
         * �{�^��
         */
        setShomenMsk("");
        setGazoChoiceBack("");
        setGazoKakuninBack("");
        setFirstDisp(0);
        setMaxDisp(0);
        setPage(0);
        setPageBegin(0);
        setPageEnd(0);
        setPageMax(0);
        setCommandPage("");
        setSearchFlg("0");
        setIndex("");
        setGazoHyojiKbn("");
        setSeniFlg("");
        setMoshikomishaId("");
        setSeq("");
        setGazoChoiceGazoUpd("");
        setGazoChoice("");
        setShomenNoList(new ArrayList<>());
        setKaijoCheckList(new ArrayList<>());
        setKiboKaijoId(new HashMap<>());
        
        setCsvEvacuationList(new ArrayList<>());
        setHoyuShikakuMstMapForUpdateBefore(new HashMap<>());
        setFuriganaOnlyErrFlg("");
        setErrorLogFlg("");
        setErrorLogCheck("");
        setErrorLogForDownload(new ArrayList<>());
        
    }

    /**
     * ���N�G�X�g��������擾���郁�\�b�h
     *
     * @param request ���N�G�X�g
     */
    @Override
    public void copyFromRequest(HttpServletRequest request) {
        setScrollPlace((String) request.getAttribute("scrollPlace"));
        /**
         * 01���ʐ\��_�\���f�[�^�A�b�v���[�h���
         */
        setSknksuKbn((String) request.getAttribute("sknksuKbn"));
        setSknName((String) request.getAttribute("sknName"));
        setKsuName((String) request.getAttribute("ksuName"));
        setMskTmpDl((String) request.getAttribute("mskTmpDl"));
        setMskUl((String) request.getAttribute("mskUl"));
        setKaisaichiCode((String) request.getAttribute("kaisaichiCode"));
        setKaisaichi((String) request.getAttribute("kaisaichi"));
        setDate_From((String) request.getAttribute("date_From"));
        setKaijoCode((String) request.getAttribute("kaijoCode"));
        setDate_To((String) request.getAttribute("date_To"));
        setDate_From_Dsp((String) request.getAttribute("date_From_Dsp"));
        setDate_To_Dsp((String) request.getAttribute("date_To_Dsp"));
        setKaijoName((String) request.getAttribute("kaijoName"));
        setKaijoJusho((String) request.getAttribute("kaijoJusho"));
        setGazoKbn((String) request.getAttribute("gazoKbn"));
        setKuusekiSuu((String) request.getAttribute("kuusekiSuu"));
        setKaijoshikenkbn((String) request.getAttribute("kaijoshikenkbn"));
        setMskFileChoice((DiskFileItem) request.getAttribute("mskFileChoice"));
        setMskGazoUl((String) request.getAttribute("mskGazoUl"));
        setUketsukeNos((String[]) request.getAttribute("uketsukeNos"));
        setSknKsuNameChi((String) request.getAttribute("sknKsuNameChi"));
        setCsvFlg((String) request.getAttribute("csvFlg"));
        /**
         * 01-1���ʐ\��_�摜�f�[�^�A�b�v���[�h
         */
        setGazoUlKekka((String) request.getAttribute("gazoUlKekka"));
        setGazoUlSeq((String) request.getAttribute("gazoUlSeq"));
        setGazoUlUketsukeNo((String) request.getAttribute("gazoUlUketsukeNo"));
        setGazoUlJknJkuNo((String) request.getAttribute("gazoUlJknJkuNo"));
        setGazoUlFurigana((String) request.getAttribute("gazoUlFurigana"));
        setGazoSearch((String) request.getAttribute("gazoSearch"));
        setGazoUlSimei((String) request.getAttribute("gazoUlSimei"));
        setGazoUlFlg((String) request.getAttribute("gazoUlFlg"));
        setGazoUl((String) request.getAttribute("gazoUl"));
        setGazoUlKakunin((String) request.getAttribute("gazoUlKakunin"));
        setGazoUlBack((String) request.getAttribute("gazoUlBack"));
        setGazoUlComplete((String) request.getAttribute("gazoUlComplete"));
        setCommandPage((String) request.getAttribute("commandPage"));
        setSearchFlg((String) request.getAttribute("searchFlg"));
        setIndex((String) request.getAttribute("index"));
        setNendo((String) request.getAttribute("nendo"));
        setSknKsuCode((String) request.getAttribute("sknKsuCode"));
        setShubetsuCode((String) request.getAttribute("shubetsuCode"));
        setKaisuCode((String) request.getAttribute("kaisuCode"));
        setGazoChoice((String) request.getAttribute("gazoChoice"));
        HttpSession session = request.getSession(false);
        if (session.getAttribute("GazoKanriJoho") != null) {
            GazoKanriJoho tmp = (GazoKanriJoho) session.getAttribute("GazoKanriJoho");
            setNendo((String) tmp.getNendo());
            setSknKsuCode(tmp.getSknKsuCode());
            setShubetsuCode(tmp.getShubetsuCode());
            setKaisuCode(tmp.getKaisuCode());
            setGazoChoiceGazoUpd(tmp.getGazoChoiceGazoUpd());
            setGazoUlSeq(tmp.getGazoUlSeq());
            setGazo_idx(tmp.getGazo_idx());
            setTorokuCheck(tmp.getTorokuCheck());
            setGazoUpd(tmp.getGazoUpd());
            setUploadCheck(tmp.getUploadCheck());
        }
        setGazoHyojiKbn((String) request.getAttribute("gazoHyojiKbn"));
        setDownloadKbn((String) request.getAttribute("downloadKbn"));
        setGokakuNo((String) request.getAttribute("gokakuNo"));
        setBirthday((String) request.getAttribute("birthday"));
        setKaiinShinseiFlg((String) request.getAttribute("kaiinShinseiFlg"));
        setShikenNaiyoKbn((String) request.getAttribute("shikenNaiyoKbn"));
        setHairyoFlg((String) request.getAttribute("gairyoFlg"));
        setHairyoNaiyo((String) request.getAttribute("hairyoNaiyo"));
        setGenmenFlg((String) request.getAttribute("genmenFlg"));
        setBiko((String) request.getAttribute("biko"));
        setSofuSakiKbn((String) request.getAttribute("sofuSakiKbn"));
        setShikakuCode((String) request.getAttribute("shikakuCode"));
        setShinseiShikakuNo((String) request.getAttribute("shinseiShikakuNo"));
        setMenjoCode((String) request.getAttribute("menjoCode"));
        setShinseiMenjoNo((String) request.getAttribute("shinseiMenjoNo"));
        setShokurekiKbn((String) request.getAttribute("shinseiMenjoNo"));
        setKinmusakiKaishaName((String) request.getAttribute("kinmusakiKaishaName"));
        setBushoYakushokuName((String) request.getAttribute("bushoYakushokuName"));
        setShokumuNaiyo((String) request.getAttribute("shokumuNaiyo"));
        setShozaichi((String) request.getAttribute("shozaichi"));
        setZaisekikikanFrom((String) request.getAttribute("zaisekikikanFrom"));
        setZaisekikikanTo((String) request.getAttribute("zaisekikikanTo"));
        setKessaiHohoKbn((String) request.getAttribute("kessaiHohoKbn"));
        setKaiinKbn((String) request.getAttribute("kaiinKbn"));
        setSex((String) request.getAttribute("sex"));
        setYubinNo((String) request.getAttribute("yubinNo"));
        setTodofukenCode((String) request.getAttribute("todofukenCode"));
        setJusho1((String) request.getAttribute("jusho1"));
        setJusho2((String) request.getAttribute("jusho2"));
        setTatemono((String) request.getAttribute("tatemono"));
        setTelNo((String) request.getAttribute("telNo"));
        setFaxNo((String) request.getAttribute("faxNo"));
        setMailAddress((String) request.getAttribute("mailAddress"));
        setKinmusakiName((String) request.getAttribute("kinmusakiName"));
        setKinmusakiYubinNo((String) request.getAttribute("kinmusakiYubinNo"));
        setKinmusakiTodofuken((String) request.getAttribute("kinmusakiTodofuken"));
        setKinmusakiTodofukenCode((String) request.getAttribute("kinmusakiTodofukenCode"));
        setKinmusakiJusho1((String) request.getAttribute("kinmusakiJusho1"));
        setKinmusakiJusho2((String) request.getAttribute("kinmusakiJusho2"));
        setKinmusakiTatemono((String) request.getAttribute("kinmusakiTatemono"));
        setKinmusakiTelNo((String) request.getAttribute("kinmusakiTelNo"));
        setKinmusakiFaxNo((String) request.getAttribute("kinmusakiFaxNo"));
        setKigyoCode((String) request.getAttribute("kigyoCode"));
        setGaijiFlg((String) request.getAttribute("gaijiFlg"));
        setGaijiShosai((String) request.getAttribute("gaijiShosai"));
        setKaijoId((String) request.getAttribute("kaijoId"));
        setShomenUketsukeNo((String) request.getAttribute("shomenUketsukeNo"));
        setUketsukeNo((String) request.getAttribute("uketsukeNo"));
        setShokurekiSeq((String) request.getAttribute("shokurekiSeq"));
        setShimei((String) request.getAttribute("shimei"));
        setFurigana((String) request.getAttribute("furigana"));
        setTodofuken((String) request.getAttribute("todofuken"));
        setFileKbn((String) request.getAttribute("fileKbn"));
        /**
         * 01-4���ʐ\��_���ʐ\������
         */
        setTorokuKanryoSknKsuName((String) request.getAttribute("torokuKanryoSknKsuName"));
        setTorokuKanryoKensu((String) request.getAttribute("torokuKanryoKensu"));

        //�{�^��
        setShomenMsk((String) request.getAttribute("shomenMsk"));
        setGazoChoiceBack((String) request.getAttribute("gazoChoiceBack"));
        setGazoKakuninBack((String) request.getAttribute("gazoKakuninBack"));
        setSeniFlg((String) request.getAttribute("seniFlg"));
        setMoshikomishaId((String) request.getAttribute("moshikomishaId"));
        setSeq((String) request.getAttribute("seq"));
        if (session.getAttribute("MgrTopJoho") != null) {
            MgrTopJoho tmp = (MgrTopJoho) session.getAttribute("MgrTopJoho");
            setMoshikomishaId(tmp.getMoshikomishaId());
        }

        setErrorLogCheck((String) request.getAttribute("errorLogCheck"));
    }

    public Messages getErrors() {
        return errors;
    }

    public void setErrors(Messages errors) {
        this.errors = errors;
    }

    public String getSknksuKbn() {
        return sknksuKbn;
    }

    public void setSknksuKbn(String sknksuKbn) {
        this.sknksuKbn = sknksuKbn;
    }

    public String getSknName() {
        return sknName;
    }

    public void setSknName(String sknName) {
        this.sknName = sknName;
    }

    public String getShomenMsk() {
        return shomenMsk;
    }

    public void setShomenMsk(String shomenMsk) {
        this.shomenMsk = shomenMsk;
    }

    public DiskFileItem getMskFileChoice() {
        return mskFileChoice;
    }

    public void setMskFileChoice(DiskFileItem mskFileChoice) {
        this.mskFileChoice = mskFileChoice;
    }

    public String getMskTmpDl() {
        return mskTmpDl;
    }

    public void setMskTmpDl(String mskTmpDl) {
        this.mskTmpDl = mskTmpDl;
    }

    public String getMskUl() {
        return mskUl;
    }

    public void setMskUl(String mskUl) {
        this.mskUl = mskUl;
    }

    public String getGazoUlKekka() {
        return gazoUlKekka;
    }

    public void setGazoUlKekka(String gazoUlKekka) {
        this.gazoUlKekka = gazoUlKekka;
    }

    public String getGazoUlSeq() {
        return gazoUlSeq;
    }

    public void setGazoUlSeq(String gazoUlSeq) {
        this.gazoUlSeq = gazoUlSeq;
    }

    public String getGazoUlUketsukeNo() {
        return gazoUlUketsukeNo;
    }

    public void setGazoUlUketsukeNo(String gazoUlUketsukeNo) {
        this.gazoUlUketsukeNo = gazoUlUketsukeNo;
    }

    public String getGazoUlJknJkuNo() {
        return gazoUlJknJkuNo;
    }

    public void setGazoUlJknJkuNo(String gazoUlJknJkuNo) {
        this.gazoUlJknJkuNo = gazoUlJknJkuNo;
    }

    public String getGazoUlFurigana() {
        return gazoUlFurigana;
    }

    public void setGazoUlFurigana(String gazoUlFurigana) {
        this.gazoUlFurigana = gazoUlFurigana;
    }

    public String getGazoUlSimei() {
        return gazoUlSimei;
    }

    public void setGazoUlSimei(String gazoUlSimei) {
        this.gazoUlSimei = gazoUlSimei;
    }

    public String getGazoUlFlg() {
        return gazoUlFlg;
    }

    public void setGazoUlFlg(String gazoUlFlg) {
        this.gazoUlFlg = gazoUlFlg;
    }

    public String getGazoUl() {
        return gazoUl;
    }

    public void setGazoUl(String gazoUl) {
        this.gazoUl = gazoUl;
    }

    public String getGazoUlKakunin() {
        return gazoUlKakunin;
    }

    public void setGazoUlKakunin(String gazoUlKakunin) {
        this.gazoUlKakunin = gazoUlKakunin;
    }

    public String getGazoUlBack() {
        return gazoUlBack;
    }

    public void setGazoUlBack(String gazoUlBack) {
        this.gazoUlBack = gazoUlBack;
    }

    public String getGazoUlComplete() {
        return gazoUlComplete;
    }

    public void setGazoUlComplete(String gazoUlComplete) {
        this.gazoUlComplete = gazoUlComplete;
    }

    public String getTorokuKanryoSknKsuName() {
        return torokuKanryoSknKsuName;
    }

    public void setTorokuKanryoSknKsuName(String torokuKanryoSknKsuName) {
        this.torokuKanryoSknKsuName = torokuKanryoSknKsuName;
    }

    public String getTorokuKanryoKensu() {
        return torokuKanryoKensu;
    }

    public void setTorokuKanryoKensu(String torokuKanryoKensu) {
        this.torokuKanryoKensu = torokuKanryoKensu;
    }

    public String getKsuName() {
        return ksuName;
    }

    public void setKsuName(String ksuName) {
        this.ksuName = ksuName;
    }

    public String getGazoChoiceBack() {
        return gazoChoiceBack;
    }

    public void setGazoChoiceBack(String gazoChoiceBack) {
        this.gazoChoiceBack = gazoChoiceBack;
    }

    public String getGazoKakuninBack() {
        return gazoKakuninBack;
    }

    public void setGazoKakuninBack(String gazoKakuninBack) {
        this.gazoKakuninBack = gazoKakuninBack;
    }

    /**
     * @return the gazoDetailList
     */
    public List<SmnMskJoho> getGazoDetailList() {
        return gazoDetailList;
    }

    /**
     * @param gazoDetailList the gazoDetailList to set
     */
    public void setGazoDetailList(List<SmnMskJoho> gazoDetailList) {
        this.gazoDetailList = gazoDetailList;
    }

    /**
     * @return the searchOutList
     */
    public List<SmnMskJoho> getSearchOutList() {
        return searchOutList;
    }

    /**
     * @param searchOutList the searchOutList to set
     */
    public void setSearchOutList(List<SmnMskJoho> searchOutList) {
        this.searchOutList = searchOutList;
    }

    /**
     * @return the pageMax
     */
    public int getPageMax() {
        return pageMax;
    }

    /**
     * @param pageMax the pageMax to set
     */
    public void setPageMax(int pageMax) {
        this.pageMax = pageMax;
    }

    /**
     * @return the page
     */
    public int getPage() {
        return page;
    }

    /**
     * @param page the page to set
     */
    public void setPage(int page) {
        this.page = page;
    }

    /**
     * @return the maxDisp
     */
    public int getMaxDisp() {
        return maxDisp;
    }

    /**
     * @param maxDisp the maxDisp to set
     */
    public void setMaxDisp(int maxDisp) {
        this.maxDisp = maxDisp;
    }

    /**
     * @return the firstDisp
     */
    public int getFirstDisp() {
        return firstDisp;
    }

    /**
     * @param firstDisp the firstDisp to set
     */
    public void setFirstDisp(int firstDisp) {
        this.firstDisp = firstDisp;
    }

    /**
     * @return the pageBegin
     */
    public int getPageBegin() {
        return pageBegin;
    }

    /**
     * @param pageBegin the pageBegin to set
     */
    public void setPageBegin(int pageBegin) {
        this.pageBegin = pageBegin;
    }

    /**
     * @return the pageEnd
     */
    public int getPageEnd() {
        return pageEnd;
    }

    /**
     * @param pageEnd the pageEnd to set
     */
    public void setPageEnd(int pageEnd) {
        this.pageEnd = pageEnd;
    }

    /**
     * @return the CommandPage
     */
    public String getCommandPage() {
        return CommandPage;
    }

    /**
     * @param CommandPage the CommandPage to set
     */
    public void setCommandPage(String CommandPage) {
        this.CommandPage = CommandPage;
    }

    /**
     * @return the index
     */
    public String getIndex() {
        return index;
    }

    /**
     * @param index the index to set
     */
    public void setIndex(String index) {
        this.index = index;
    }

    /**
     * @return the searchFlg
     */
    public String getSearchFlg() {
        return searchFlg;
    }

    /**
     * @param searchFlg the searchFlg to set
     */
    public void setSearchFlg(String searchFlg) {
        this.searchFlg = searchFlg;
    }

    /**
     * @return the sknKsuCode
     */
    public String getSknKsuCode() {
        return sknKsuCode;
    }

    /**
     * @param sknKsuCode the sknKsuCode to set
     */
    public void setSknKsuCode(String sknKsuCode) {
        this.sknKsuCode = sknKsuCode;
    }

    /**
     * @return the shubetsuCode
     */
    public String getShubetsuCode() {
        return shubetsuCode;
    }

    /**
     * @param shubetsuCode the shubetsuCode to set
     */
    public void setShubetsuCode(String shubetsuCode) {
        this.shubetsuCode = shubetsuCode;
    }

    /**
     * @return the kaisuCode
     */
    public String getKaisuCode() {
        return kaisuCode;
    }

    /**
     * @param kaisuCode the kaisuCode to set
     */
    public void setKaisuCode(String kaisuCode) {
        this.kaisuCode = kaisuCode;
    }

    /**
     * @return the nendo
     */
    public String getNendo() {
        return nendo;
    }

    /**
     * @param nendo the nendo to set
     */
    public void setNendo(String nendo) {
        this.nendo = nendo;
    }

    /**
     * @return the gazo_idx
     */
    public String getGazo_idx() {
        return gazo_idx;
    }

    /**
     * @param gazo_idx the gazo_idx to set
     */
    public void setGazo_idx(String gazo_idx) {
        this.gazo_idx = gazo_idx;
    }

    /**
     * @return the gazoHyojiKbn
     */
    public String getGazoHyojiKbn() {
        return gazoHyojiKbn;
    }

    /**
     * @param gazoHyojiKbn the gazoHyojiKbn to set
     */
    public void setGazoHyojiKbn(String gazoHyojiKbn) {
        this.gazoHyojiKbn = gazoHyojiKbn;
    }

    /**
     * @return the gazoSearch
     */
    public String getGazoSearch() {
        return gazoSearch;
    }

    /**
     * @param gazoSearch the gazoSearch to set
     */
    public void setGazoSearch(String gazoSearch) {
        this.gazoSearch = gazoSearch;
    }

    /**
     * @return the seniFlg
     */
    public String getSeniFlg() {
        return seniFlg;
    }

    /**
     * @param seniFlg the seniFlg to set
     */
    public void setSeniFlg(String seniFlg) {
        this.seniFlg = seniFlg;
    }

    /**
     * @return the moshikomishaId
     */
    public String getMoshikomishaId() {
        return moshikomishaId;
    }

    /**
     * @param moshikomishaId the moshikomishaId to set
     */
    public void setMoshikomishaId(String moshikomishaId) {
        this.moshikomishaId = moshikomishaId;
    }

    /**
     * @return the gazoChoiceGazoUpd
     */
    public String getGazoChoiceGazoUpd() {
        return gazoChoiceGazoUpd;
    }

    /**
     * @param gazoChoiceGazoUpd the gazoChoiceGazoUpd to set
     */
    public void setGazoChoiceGazoUpd(String gazoChoiceGazoUpd) {
        this.gazoChoiceGazoUpd = gazoChoiceGazoUpd;
    }

    /**
     * @return the seq
     */
    public String getSeq() {
        return seq;
    }

    /**
     * @param seq the seq to set
     */
    public void setSeq(String seq) {
        this.seq = seq;
    }

    /**
     * @return the gazoChoice
     */
    public String getGazoChoice() {
        return gazoChoice;
    }

    /**
     * @param gazoChoice the gazoChoice to set
     */
    public void setGazoChoice(String gazoChoice) {
        this.gazoChoice = gazoChoice;
    }

    /**
     * @return the sknKbnList
     */
    public List<Option> getSknKbnList() {
        return sknKbnList;
    }

    /**
     * @param sknKbnList the sknKbnList to set
     */
    public void setSknKbnList(List<Option> sknKbnList) {
        this.sknKbnList = sknKbnList;
    }

    /**
     * @return the kaisaichiCode
     */
    public String getKaisaichiCode() {
        return kaisaichiCode;
    }

    /**
     * @param kaisaichiCode the kaisaichiCode to set
     */
    public void setKaisaichiCode(String kaisaichiCode) {
        this.kaisaichiCode = kaisaichiCode;
    }

    /**
     * @return the kaisaichi
     */
    public String getKaisaichi() {
        return kaisaichi;
    }

    /**
     * @param kaisaichi the kaisaichi to set
     */
    public void setKaisaichi(String kaisaichi) {
        this.kaisaichi = kaisaichi;
    }

    /**
     * @return the date_From_Dsp
     */
    public String getDate_From_Dsp() {
        if (date_From.length() == 8) {
            return date_From.substring(0, 4) + "�N" + date_From.substring(4, 6) + "��" + date_From.substring(6) + "��";
        }
        return "";
    }

    /**
     * @param date_From_Dsp the date_From_Dsp to set
     */
    public void setDate_From_Dsp(String date_From_Dsp) {
        this.date_From_Dsp = date_From_Dsp;
    }

    /**
     * @return the date_To_Dsp
     */
    public String getDate_To_Dsp() {
        if (date_To.length() == 8) {
            return date_To.substring(0, 4) + "�N" + date_To.substring(4, 6) + "��" + date_To.substring(6) + "��";
        }
        return "";
    }

    /**
     * @param date_To_Dsp the date_To_Dsp to set
     */
    public void setDate_To_Dsp(String date_To_Dsp) {
        this.date_To_Dsp = date_To_Dsp;
    }

    /**
     * @return the kaijoName
     */
    public String getKaijoName() {
        return kaijoName;
    }

    /**
     * @param kaijoName the kaijoName to set
     */
    public void setKaijoName(String kaijoName) {
        this.kaijoName = kaijoName;
    }

    /**
     * @return the kaijoJusho
     */
    public String getKaijoJusho() {
        return kaijoJusho;
    }

    /**
     * @param kaijoJusho the kaijoJusho to set
     */
    public void setKaijoJusho(String kaijoJusho) {
        this.kaijoJusho = kaijoJusho;
    }

    /**
     * @return the kuusekiSuu
     */
    public String getKuusekiSuu() {
        return kuusekiSuu;
    }

    /**
     * @param kuusekiSuu the kuusekiSuu to set
     */
    public void setKuusekiSuu(String kuusekiSuu) {
        this.kuusekiSuu = kuusekiSuu;
    }

    /**
     * @return the ksuKbnList
     */
    public List<Option> getKsuKbnList() {
        return ksuKbnList;
    }

    /**
     * @param ksuKbnList the ksuKbnList to set
     */
    public void setKsuKbnList(List<Option> ksuKbnList) {
        this.ksuKbnList = ksuKbnList;
    }

    /**
     * @return the kaiMskJohoList
     */
    public List<SmnMskJoho> getKaiMskJohoList() {
        return kaiMskJohoList;
    }

    /**
     * @param kaiMskJohoList the kaiMskJohoList to set
     */
    public void setKaiMskJohoList(List<SmnMskJoho> kaiMskJohoList) {
        this.kaiMskJohoList = kaiMskJohoList;
    }

    /**
     * @return the scrollPlace
     */
    public String getScrollPlace() {
        return scrollPlace;
    }

    /**
     * @param scrollPlace the scrollPlace to set
     */
    public void setScrollPlace(String scrollPlace) {
        this.scrollPlace = scrollPlace;
    }

    /**
     * @return the count
     */
    public String getCount() {
        return count;
    }

    /**
     * @param count the count to set
     */
    public void setCount(String count) {
        this.count = count;
    }

    /**
     * @return the kaijoshikenkbn
     */
    public String getKaijoshikenkbn() {
        return kaijoshikenkbn;
    }

    /**
     * @param kaijoshikenkbn the kaijoshikenkbn to set
     */
    public void setKaijoshikenkbn(String kaijoshikenkbn) {
        this.kaijoshikenkbn = kaijoshikenkbn;
    }

    /**
     * @return the date_From
     */
    public String getDate_From() {
        return date_From;
    }

    /**
     * @param date_From the date_From to set
     */
    public void setDate_From(String date_From) {
        this.date_From = date_From;
    }

    /**
     * @return the date_To
     */
    public String getDate_To() {
        return date_To;
    }

    /**
     * @param date_To the date_To to set
     */
    public void setDate_To(String date_To) {
        this.date_To = date_To;
    }

    /**
     * @return the kaijoCode
     */
    public String getKaijoCode() {
        return kaijoCode;
    }

    /**
     * @param kaijoCode the kaijoCode to set
     */
    public void setKaijoCode(String kaijoCode) {
        this.kaijoCode = kaijoCode;
    }

    /**
     * ���[�N�u�b�N���擾����S
     *
     * @return ���[�N�u�b�N
     */
    public Workbook getWorkbook() {
        return workbook;
    }

    /**
     * ���[�N�u�b�N���Z�b�g����
     *
     * @param workbook ���[�N�u�b�N
     */
    public void setWorkbook(Workbook workbook) {
        this.workbook = workbook;
    }

    /**
     * �V�[�g���擾����
     *
     * @return �V�[�g
     */
    public Sheet getSheet() {
        return sheet;
    }

    /**
     * �V�[�g���Z�b�g����
     *
     * @param sheet �V�[�g
     */
    public void setSheet(Sheet sheet) {
        this.sheet = sheet;
    }

    /**
     * �t�@�C�������擾����
     *
     * @return �t�@�C����
     */
    public String getFileName() {
        return fileName;
    }

    /**
     * �t�@�C�������Z�b�g����
     *
     * @param fileName �t�@�C����
     */
    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    /**
     * Excel�o�͒l�ݒ�}�b�v���擾����
     *
     * @return Excel�o�͒l�ݒ�}�b�v
     */
    public Map<String, Object> getExcelMap() {
        return excelMap;
    }

    /**
     * Excel�o�͒l�ݒ�}�b�v���Z�b�g����
     *
     * @param excelMap Excel�o�͒l�ݒ�}�b�v
     */
    public void setExcelMap(Map<String, Object> excelMap) {
        this.excelMap = excelMap;
    }

    /**
     * Excel�o�͒l�ݒ胊�X�g���擾����
     *
     * @return Excel�o�͒l�ݒ胊�X�g
     */
    public List<Object>[] getExcelList() {
        return excelList;
    }

    /**
     * Excel�o�͒l�ݒ胊�X�g���Z�b�g����
     *
     * @param excelList Excel�o�͒l�ݒ胊�X�g
     */
    public void setExcelList(List<Object>[] excelList) {
        this.excelList = excelList;
    }

    /**
     * �V�[�g�i���o�[���擾����
     *
     * @return �V�[�g�i���o�[
     */
    public int getSheetNo() {
        return sheetNo;
    }

    /**
     * �V�[�g�i���o�[���Z�b�g����
     *
     * @param sheetNo �V�[�g�i���o�[
     */
    public void setSheetNo(int sheetNo) {
        this.sheetNo = sheetNo;
    }

    /**
     * @return the excelSyukeiList
     */
    public Map<String, List<Object>[]> getExcelSyukeiList() {
        return excelSyukeiList;
    }

    /**
     * @param excelSyukeiList the excelSyukeiList to set
     */
    public void setExcelSyukeiList(Map<String, List<Object>[]> excelSyukeiList) {
        this.excelSyukeiList = excelSyukeiList;
    }

    /**
     * Excel�o�͒l�ݒ�(���X�g)
     *
     * @param key �L�[
     * @param value �l
     */
    public void setExcelSyukeiList(String key, List<Object>[] value) {
        this.excelSyukeiList.put(key, value);
    }

    /**
     * Excel�o�͒l�ݒ�(�}�b�v)
     *
     * @param key �ݒ�L�[
     * @param value �l
     */
    public void setExcelMap(String key, Object value) {
        this.excelMap.put(key, value);
    }

    /**
     * Excel�o�͒l�ݒ�(���X�g)
     *
     * @param index �C���f�b�N�X
     * @param value �l
     */
    public void setExcelList(int index, Object value) {
        this.excelList[index].add(value);
    }

    /**
     * Excel�o�͒l�ݒ胊�X�g�}�b�v
     *
     * @param writeKey
     * @param excelList
     */
    public void setExcelListMap(String writeKey, List<Object>[] excelList) {
        this.excelListMap.put(writeKey, excelList);
    }

    /**
     * Excel�o�͒l�ݒ�(���X�g)�̏�����
     *
     * @param size ���X�g�T�C�Y
     */
    public void initExcelList(int size) {
        this.excelList = new ArrayList[size];
        for (int i = 0; i < size; i++) {
            this.excelList[i] = new ArrayList();
        }
    }

    /**
     * �V�[�g����ݒ肷��
     *
     * @param sheetName �V�[�g��
     */
    public void setSheetName(String sheetName) {
        this.workbook.setSheetName(this.sheetNo, sheetName);
    }

    /**
     * �������s�֎~���X�g
     *
     * @param key �L�[
     */
    public void setWrapTextsNotList(String key) {
        this.autoWrapTextsNotList.add(key);
    }

    public void setKaijoCheckList(List<SmnMskJoho> kaijoCheckList) {
        this.kaijoCheckList = kaijoCheckList;
    }

    public List<SmnMskJoho> getKaijoCheckList() {
        return kaijoCheckList;
    }

    public void setKiboKaijoId(Map<String,String> kiboKaijoId) {
        this.kiboKaijoId = kiboKaijoId;
    }

    public Map<String,String> getKiboKaijoId() {
        return kiboKaijoId;
    }

    /**
     * @return the downloadKbn
     */
    public String getDownloadKbn() {
        return downloadKbn;
    }

    /**
     * @param downloadKbn the downloadKbn to set
     */
    public void setDownloadKbn(String downloadKbn) {
        this.downloadKbn = downloadKbn;
    }

    /**
     * @return the gokakuNo
     */
    public String getGokakuNo() {
        return gokakuNo;
    }

    /**
     * @param gokakuNo the gokakuNo to set
     */
    public void setGokakuNo(String gokakuNo) {
        this.gokakuNo = gokakuNo;
    }

    /**
     * @return the birthday
     */
    public String getBirthday() {
        return birthday;
    }

    /**
     * @param birthday the birthday to set
     */
    public void setBirthday(String birthday) {
        this.birthday = birthday;
    }

    /**
     * @return the nenrei
     */
    public String getNenrei() {
        return nenrei;
    }

    /**
     * @param nenrei the nenrei to set
     */
    public void setNenrei(String nenrei) {
        this.nenrei = nenrei;
    }

    /**
     * @return the kaiinShinseiFlg
     */
    public String getKaiinShinseiFlg() {
        return kaiinShinseiFlg;
    }

    /**
     * @param kaiinShinseiFlg the kaiinShinseiFlg to set
     */
    public void setKaiinShinseiFlg(String kaiinShinseiFlg) {
        this.kaiinShinseiFlg = kaiinShinseiFlg;
    }

    /**
     * @return the shikenNaiyoKbn
     */
    public String getShikenNaiyoKbn() {
        return shikenNaiyoKbn;
    }

    /**
     * @param shikenNaiyoKbn the shikenNaiyoKbn to set
     */
    public void setShikenNaiyoKbn(String shikenNaiyoKbn) {
        this.shikenNaiyoKbn = shikenNaiyoKbn;
    }

    /**
     * @return the hairyoFlg
     */
    public String getHairyoFlg() {
        return hairyoFlg;
    }

    /**
     * @param hairyoFlg the hairyoFlg to set
     */
    public void setHairyoFlg(String hairyoFlg) {
        this.hairyoFlg = hairyoFlg;
    }

    /**
     * @return the hairyoNaiyo
     */
    public String getHairyoNaiyo() {
        return hairyoNaiyo;
    }

    /**
     * @param hairyoNaiyo the hairyoNaiyo to set
     */
    public void setHairyoNaiyo(String hairyoNaiyo) {
        this.hairyoNaiyo = hairyoNaiyo;
    }

    /**
     * @return the genmenFlg
     */
    public String getGenmenFlg() {
        return genmenFlg;
    }

    /**
     * @param genmenFlg the genmenFlg to set
     */
    public void setGenmenFlg(String genmenFlg) {
        this.genmenFlg = genmenFlg;
    }

    /**
     * @return the biko
     */
    public String getBiko() {
        return biko;
    }

    /**
     * @param biko the biko to set
     */
    public void setBiko(String biko) {
        this.biko = biko;
    }

    /**
     * @return the sofuSakiKbn
     */
    public String getSofuSakiKbn() {
        return sofuSakiKbn;
    }

    /**
     * @param sofuSakiKbn the sofuSakiKbn to set
     */
    public void setSofuSakiKbn(String sofuSakiKbn) {
        this.sofuSakiKbn = sofuSakiKbn;
    }

    /**
     * @return the shikakuCode
     */
    public String getShikakuCode() {
        return shikakuCode;
    }

    /**
     * @param shikakuCode the shikakuCode to set
     */
    public void setShikakuCode(String shikakuCode) {
        this.shikakuCode = shikakuCode;
    }

    /**
     * @return the shinseiShikakuNo
     */
    public String getShinseiShikakuNo() {
        return shinseiShikakuNo;
    }

    /**
     * @param shinseiShikakuNo the shinseiShikakuNo to set
     */
    public void setShinseiShikakuNo(String shinseiShikakuNo) {
        this.shinseiShikakuNo = shinseiShikakuNo;
    }

    /**
     * @return the menjoCode
     */
    public String getMenjoCode() {
        return menjoCode;
    }

    /**
     * @param menjoCode the menjoCode to set
     */
    public void setMenjoCode(String menjoCode) {
        this.menjoCode = menjoCode;
    }

    /**
     * @return the shinseiMenjoNo
     */
    public String getShinseiMenjoNo() {
        return shinseiMenjoNo;
    }

    /**
     * @param shinseiMenjoNo the shinseiMenjoNo to set
     */
    public void setShinseiMenjoNo(String shinseiMenjoNo) {
        this.shinseiMenjoNo = shinseiMenjoNo;
    }

    /**
     * @return the shokurekiKbn
     */
    public String getShokurekiKbn() {
        return shokurekiKbn;
    }

    /**
     * @param shokurekiKbn the shokurekiKbn to set
     */
    public void setShokurekiKbn(String shokurekiKbn) {
        this.shokurekiKbn = shokurekiKbn;
    }

    /**
     * @return the kinmusakiKaishaName
     */
    public String getKinmusakiKaishaName() {
        return kinmusakiKaishaName;
    }

    /**
     * @param kinmusakiKaishaName the kinmusakiKaishaName to set
     */
    public void setKinmusakiKaishaName(String kinmusakiKaishaName) {
        this.kinmusakiKaishaName = kinmusakiKaishaName;
    }

    /**
     * @return the bushoYakushokuName
     */
    public String getBushoYakushokuName() {
        return bushoYakushokuName;
    }

    /**
     * @param bushoYakushokuName the bushoYakushokuName to set
     */
    public void setBushoYakushokuName(String bushoYakushokuName) {
        this.bushoYakushokuName = bushoYakushokuName;
    }

    /**
     * @return the shokumuNaiyo
     */
    public String getShokumuNaiyo() {
        return shokumuNaiyo;
    }

    /**
     * @param shokumuNaiyo the shokumuNaiyo to set
     */
    public void setShokumuNaiyo(String shokumuNaiyo) {
        this.shokumuNaiyo = shokumuNaiyo;
    }

    /**
     * @return the shozaichi
     */
    public String getShozaichi() {
        return shozaichi;
    }

    /**
     * @param shozaichi the shozaichi to set
     */
    public void setShozaichi(String shozaichi) {
        this.shozaichi = shozaichi;
    }

    /**
     * @return the zaisekikikanFrom
     */
    public String getZaisekikikanFrom() {
        return zaisekikikanFrom;
    }

    /**
     * @param zaisekikikanFrom the zaisekikikanFrom to set
     */
    public void setZaisekikikanFrom(String zaisekikikanFrom) {
        this.zaisekikikanFrom = zaisekikikanFrom;
    }

    /**
     * @return the zaisekikikanTo
     */
    public String getZaisekikikanTo() {
        return zaisekikikanTo;
    }

    /**
     * @param zaisekikikanTo the zaisekikikanTo to set
     */
    public void setZaisekikikanTo(String zaisekikikanTo) {
        this.zaisekikikanTo = zaisekikikanTo;
    }

    /**
     * @return the kessaiHohoKbn
     */
    public String getKessaiHohoKbn() {
        return kessaiHohoKbn;
    }

    /**
     * @param kessaiHohoKbn the kessaiHohoKbn to set
     */
    public void setKessaiHohoKbn(String kessaiHohoKbn) {
        this.kessaiHohoKbn = kessaiHohoKbn;
    }

    /**
     * @return the kaiinKbn
     */
    public String getKaiinKbn() {
        return kaiinKbn;
    }

    /**
     * @param kaiinKbn the kaiinKbn to set
     */
    public void setKaiinKbn(String kaiinKbn) {
        this.kaiinKbn = kaiinKbn;
    }

    /**
     * @return the sex
     */
    public String getSex() {
        return sex;
    }

    /**
     * @param sex the sex to set
     */
    public void setSex(String sex) {
        this.sex = sex;
    }

    /**
     * @return the yubinNo
     */
    public String getYubinNo() {
        return yubinNo;
    }

    /**
     * @param yubinNo the yubinNo to set
     */
    public void setYubinNo(String yubinNo) {
        this.yubinNo = yubinNo;
    }

    /**
     * @return the todofukenCode
     */
    public String getTodofukenCode() {
        return todofukenCode;
    }

    /**
     * @param todofukenCode the todofukenCode to set
     */
    public void setTodofukenCode(String todofukenCode) {
        this.todofukenCode = todofukenCode;
    }

    /**
     * @return the jusho1
     */
    public String getJusho1() {
        return jusho1;
    }

    /**
     * @param jusho1 the jusho1 to set
     */
    public void setJusho1(String jusho1) {
        this.jusho1 = jusho1;
    }

    /**
     * @return the jusho2
     */
    public String getJusho2() {
        return jusho2;
    }

    /**
     * @param jusho2 the jusho2 to set
     */
    public void setJusho2(String jusho2) {
        this.jusho2 = jusho2;
    }

    /**
     * @return the tatemono
     */
    public String getTatemono() {
        return tatemono;
    }

    /**
     * @param tatemono the tatemono to set
     */
    public void setTatemono(String tatemono) {
        this.tatemono = tatemono;
    }

    /**
     * @return the telNo
     */
    public String getTelNo() {
        return telNo;
    }

    /**
     * @param telNo the telNo to set
     */
    public void setTelNo(String telNo) {
        this.telNo = telNo;
    }

    /**
     * @return the faxNo
     */
    public String getFaxNo() {
        return faxNo;
    }

    /**
     * @param faxNo the faxNo to set
     */
    public void setFaxNo(String faxNo) {
        this.faxNo = faxNo;
    }

    /**
     * @return the mailAddress
     */
    public String getMailAddress() {
        return mailAddress;
    }

    /**
     * @param mailAddress the mailAddress to set
     */
    public void setMailAddress(String mailAddress) {
        this.mailAddress = mailAddress;
    }

    /**
     * @return the kinmusakiName
     */
    public String getKinmusakiName() {
        return kinmusakiName;
    }

    /**
     * @param kinmusakiName the kinmusakiName to set
     */
    public void setKinmusakiName(String kinmusakiName) {
        this.kinmusakiName = kinmusakiName;
    }

    /**
     * @return the kinmusakiYubinNo
     */
    public String getKinmusakiYubinNo() {
        return kinmusakiYubinNo;
    }

    /**
     * @param kinmusakiYubinNo the kinmusakiYubinNo to set
     */
    public void setKinmusakiYubinNo(String kinmusakiYubinNo) {
        this.kinmusakiYubinNo = kinmusakiYubinNo;
    }

    /**
     * @return the kinmusakiTodofukenCode
     */
    public String getKinmusakiTodofukenCode() {
        return kinmusakiTodofukenCode;
    }

    /**
     * @param kinmusakiTodofukenCode the kinmusakiTodofukenCode to set
     */
    public void setKinmusakiTodofukenCode(String kinmusakiTodofukenCode) {
        this.kinmusakiTodofukenCode = kinmusakiTodofukenCode;
    }

    /**
     * @return the kinmusakiJusho1
     */
    public String getKinmusakiJusho1() {
        return kinmusakiJusho1;
    }

    /**
     * @param kinmusakiJusho1 the kinmusakiJusho1 to set
     */
    public void setKinmusakiJusho1(String kinmusakiJusho1) {
        this.kinmusakiJusho1 = kinmusakiJusho1;
    }

    /**
     * @return the kinmusakiJusho2
     */
    public String getKinmusakiJusho2() {
        return kinmusakiJusho2;
    }

    /**
     * @param kinmusakiJusho2 the kinmusakiJusho2 to set
     */
    public void setKinmusakiJusho2(String kinmusakiJusho2) {
        this.kinmusakiJusho2 = kinmusakiJusho2;
    }

    /**
     * @return the kinmusakiTatemono
     */
    public String getKinmusakiTatemono() {
        return kinmusakiTatemono;
    }

    /**
     * @param kinmusakiTatemono the kinmusakiTatemono to set
     */
    public void setKinmusakiTatemono(String kinmusakiTatemono) {
        this.kinmusakiTatemono = kinmusakiTatemono;
    }

    /**
     * @return the kinmusakiTelNo
     */
    public String getKinmusakiTelNo() {
        return kinmusakiTelNo;
    }

    /**
     * @param kinmusakiTelNo the kinmusakiTelNo to set
     */
    public void setKinmusakiTelNo(String kinmusakiTelNo) {
        this.kinmusakiTelNo = kinmusakiTelNo;
    }

    /**
     * @return the kinmusakiFaxNo
     */
    public String getKinmusakiFaxNo() {
        return kinmusakiFaxNo;
    }

    /**
     * @param kinmusakiFaxNo the kinmusakiFaxNo to set
     */
    public void setKinmusakiFaxNo(String kinmusakiFaxNo) {
        this.kinmusakiFaxNo = kinmusakiFaxNo;
    }

    /**
     * @return the kigyoCode
     */
    public String getKigyoCode() {
        return kigyoCode;
    }

    /**
     * @param kigyoCode the kigyoCode to set
     */
    public void setKigyoCode(String kigyoCode) {
        this.kigyoCode = kigyoCode;
    }

    /**
     * @return the gaijiFlg
     */
    public String getGaijiFlg() {
        return gaijiFlg;
    }

    /**
     * @param gaijiFlg the gaijiFlg to set
     */
    public void setGaijiFlg(String gaijiFlg) {
        this.gaijiFlg = gaijiFlg;
    }

    /**
     * @return the gaijiShosai
     */
    public String getGaijiShosai() {
        return gaijiShosai;
    }

    /**
     * @param gaijiShosai the gaijiShosai to set
     */
    public void setGaijiShosai(String gaijiShosai) {
        this.gaijiShosai = gaijiShosai;
    }

    /**
     * @return the kaijoId
     */
    public String getKaijoId() {
        return kaijoId;
    }

    /**
     * @param kaijoId the kaijoId to set
     */
    public void setKaijoId(String kaijoId) {
        this.kaijoId = kaijoId;
    }

    /**
     * @return the shomenUketsukeNo
     */
    public String getShomenUketsukeNo() {
        return shomenUketsukeNo;
    }

    /**
     * @param shomenUketsukeNo the shomenUketsukeNo to set
     */
    public void setShomenUketsukeNo(String shomenUketsukeNo) {
        this.shomenUketsukeNo = shomenUketsukeNo;
    }

    /**
     * @return the shokurekiSeq
     */
    public String getShokurekiSeq() {
        return shokurekiSeq;
    }

    /**
     * @param shokurekiSeq the shokurekiSeq to set
     */
    public void setShokurekiSeq(String shokurekiSeq) {
        this.shokurekiSeq = shokurekiSeq;
    }

    /**
     * @return the shimei
     */
    public String getShimei() {
        return shimei;
    }

    /**
     * @param shimei the shimei to set
     */
    public void setShimei(String shimei) {
        this.shimei = shimei;
    }

    /**
     * @return the furigana
     */
    public String getFurigana() {
        return furigana;
    }

    /**
     * @param furigana the furigana to set
     */
    public void setFurigana(String furigana) {
        this.furigana = furigana;
    }

    /**
     * @return the todofuken
     */
    public String getTodofuken() {
        return todofuken;
    }

    /**
     * @param todofuken the todofuken to set
     */
    public void setTodofuken(String todofuken) {
        this.todofuken = todofuken;
    }

    /**
     * @return the kinmusakiTodofuken
     */
    public String getKinmusakiTodofuken() {
        return kinmusakiTodofuken;
    }

    /**
     * @param kinmusakiTodofuken the kinmusakiTodofuken to set
     */
    public void setKinmusakiTodofuken(String kinmusakiTodofuken) {
        this.kinmusakiTodofuken = kinmusakiTodofuken;
    }

    /**
     * @return the mskGazoUl
     */
    public String getMskGazoUl() {
        return mskGazoUl;
    }

    /**
     * @param mskGazoUl the mskGazoUl to set
     */
    public void setMskGazoUl(String mskGazoUl) {
        this.mskGazoUl = mskGazoUl;
    }

    /**
     * @return the errorLog
     */
    public List<String> getErrorLog() {
        return errorLog;
    }

    /**
     * @param errorLog the errorLog to set
     */
    public void setErrorLog(List<String> errorLog) {
        this.errorLog = errorLog;
    }

    /**
     * @return the fileKbn
     */
    public String getFileKbn() {
        return fileKbn;
    }

    /**
     * @param fileKbn the fileKbn to set
     */
    public void setFileKbn(String fileKbn) {
        this.fileKbn = fileKbn;
    }

    /**
     * @return the torokuCheck
     */
    public String getTorokuCheck() {
        return torokuCheck;
    }

    /**
     * @param torokuCheck the torokuCheck to set
     */
    public void setTorokuCheck(String torokuCheck) {
        this.torokuCheck = torokuCheck;
    }

    /**
     * @return the uketsukeNo
     */
    public String getUketsukeNo() {
        return uketsukeNo;
    }

    /**
     * @param uketsukeNo the uketsukeNo to set
     */
    public void setUketsukeNo(String uketsukeNo) {
        this.uketsukeNo = uketsukeNo;
    }

    /**
     * @return the csvFlg
     */
    public String getCsvFlg() {
        return csvFlg;
    }

    /**
     * @param csvFlg the csvFlg to set
     */
    public void setCsvFlg(String csvFlg) {
        this.csvFlg = csvFlg;
    }

    /**
     * @return the kakuninBi
     */
    public String getKakuninBi() {
        return kakuninBi;
    }

    /**
     * @param kakuninBi the kakuninBi to set
     */
    public void setKakuninBi(String kakuninBi) {
        this.kakuninBi = kakuninBi;
    }

    /**
     * @return the kessaiHoho
     */
    public String getKessaiHoho() {
        return kessaiHoho;
    }

    /**
     * @param kessaiHoho the kessaiHoho to set
     */
    public void setKessaiHoho(String kessaiHoho) {
        this.kessaiHoho = kessaiHoho;
    }

    /**
     * @return the sakujoFlg
     */
    public String getSakujoFlg() {
        return sakujoFlg;
    }

    /**
     * @param sakujoFlg the sakujoFlg to set
     */
    public void setSakujoFlg(String sakujoFlg) {
        this.sakujoFlg = sakujoFlg;
    }

    /**
     * @return the nyuKinkaku
     */
    public String getNyuKinkaku() {
        return nyuKinkaku;
    }

    /**
     * @param nyuKinkaku the nyuKinkaku to set
     */
    public void setNyuKinkaku(String nyuKinkaku) {
        this.nyuKinkaku = nyuKinkaku;
    }

    /**
     * @return the nyukinBi
     */
    public String getNyukinBi() {
        return nyukinBi;
    }

    /**
     * @param nyukinBi the nyukinBi to set
     */
    public void setNyukinBi(String nyukinBi) {
        this.nyukinBi = nyukinBi;
    }

    /**
     * @return the kaiinFlg
     */
    public String getKaiinFlg() {
        return kaiinFlg;
    }

    /**
     * @param kaiinFlg the kaiinFlg to set
     */
    public void setKaiinFlg(String kaiinFlg) {
        this.kaiinFlg = kaiinFlg;
    }

    /**
     * @return the daiichiKibo
     */
    public String getDaiichiKibo() {
        return daiichiKibo;
    }

    /**
     * @param daiichiKibo the daiichiKibo to set
     */
    public void setDaiichiKibo(String daiichiKibo) {
        this.daiichiKibo = daiichiKibo;
    }

    /**
     * @return the dainiKibo
     */
    public String getDainiKibo() {
        return dainiKibo;
    }

    /**
     * @param dainiKibo the dainiKibo to set
     */
    public void setDainiKibo(String dainiKibo) {
        this.dainiKibo = dainiKibo;
    }

    /**
     * @return the kiboShikenchi
     */
    public String getKiboShikenchi() {
        return kiboShikenchi;
    }

    /**
     * @param kiboShikenchi the kiboShikenchi to set
     */
    public void setKiboShikenchi(String kiboShikenchi) {
        this.kiboShikenchi = kiboShikenchi;
    }

    /**
     * @return the uketsukeNos
     */
    public String[] getUketsukeNos() {
        return uketsukeNos;
    }

    /**
     * @param uketsukeNos the uketsukeNos to set
     */
    public void setUketsukeNos(String[] uketsukeNos) {
        this.uketsukeNos = uketsukeNos;
    }

    /**
     * @return the sknKsuNameChi
     */
    public String getSknKsuNameChi() {
        return sknKsuNameChi;
    }

    /**
     * @param sknKsuNameChi the sknKsuNameChi to set
     */
    public void setSknKsuNameChi(String sknKsuNameChi) {
        this.sknKsuNameChi = sknKsuNameChi;
    }

    /**
     * @return the upKensu
     */
    public int getUpKensu() {
        return upKensu;
    }

    /**
     * @param upKensu the upKensu to set
     */
    public void setUpKensu(int upKensu) {
        this.upKensu = upKensu;
    }

    /**
     * @return the gazoKbn
     */
    public String getGazoKbn() {
        return gazoKbn;
    }

    /**
     * @param gazoKbn the gazoKbn to set
     */
    public void setGazoKbn(String gazoKbn) {
        this.gazoKbn = gazoKbn;
    }

    /**
     * @return the gazoUpd
     */
    public String getGazoUpd() {
        return gazoUpd;
    }

    /**
     * @param gazoUpd the gazoUpd to set
     */
    public void setGazoUpd(String gazoUpd) {
        this.gazoUpd = gazoUpd;
    }

    /**
     * @return the uploadCheck
     */
    public String getUploadCheck() {
        return uploadCheck;
    }

    /**
     * @param uploadCheck the uploadCheck to set
     */
    public void setUploadCheck(String uploadCheck) {
        this.uploadCheck = uploadCheck;
    }

    /**
     * @return the shomenNoList
     */
    public List<String> getShomenNoList() {
        return shomenNoList;
    }

    /**
     * @param shomenNoList the shomenNoList to set
     */
    public void setShomenNoList(List<String> shomenNoList) {
        this.shomenNoList = shomenNoList;
    }

    public void setFuriganaOnlyErrFlg(String furiganaOnlyErrFlg) {
        this.furiganaOnlyErrFlg = furiganaOnlyErrFlg;
    }

    public String getFuriganaOnlyErrFlg() {
        return furiganaOnlyErrFlg;
    }

    public void setErrorLogFlg(String errorLogFlg) {
        this.errorLogFlg = errorLogFlg;
    }

    public String getErrorLogFlg() {
        return errorLogFlg;
    }

    public String getErrorLogCheck() {
        return errorLogCheck;
    }

    public void setErrorLogCheck(String errorLogCheck) {
        this.errorLogCheck = errorLogCheck;
    }

    public List<SmnMskService.ErrorMsg> getErrorLogForDownload() {
        return errorLogForDownload;
    }

    public void setErrorLogForDownload(List<SmnMskService.ErrorMsg> errorLogForDownload) {
        this.errorLogForDownload = errorLogForDownload;
    }

    public void setCsvEvacuationList(List<SmnMskJoho> csvEvacuationList) {
        this.csvEvacuationList = csvEvacuationList;
    }

    public List<SmnMskJoho> getCsvEvacuationList() {
        return csvEvacuationList;
    }

    public void setHoyuShikakuMstMapForUpdateBefore(Map<String, HoyuShikakuMst> hoyuShikakuMstMapForUpdateBefore) {
        this.hoyuShikakuMstMapForUpdateBefore = hoyuShikakuMstMapForUpdateBefore;
    }

    public Map<String, HoyuShikakuMst> getHoyuShikakuMstMapForUpdateBefore() {
        return hoyuShikakuMstMapForUpdateBefore;
    }

}
