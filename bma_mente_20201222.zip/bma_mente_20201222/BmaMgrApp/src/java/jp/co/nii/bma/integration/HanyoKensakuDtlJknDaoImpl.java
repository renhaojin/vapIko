package jp.co.nii.bma.integration;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import jp.co.nii.bma.business.domain.HanyoKensakuDtlJknDao;
import jp.co.nii.bma.business.rto.manager.HanyouSearchJoho;
import jp.co.nii.bma.business.rto.manager.HanyouSearchJoho;
import jp.co.nii.sew.business.SystemTime;
import static jp.co.nii.sew.business.domain.GeneratedServiceConfigDao.TABLE_NAME;
import jp.co.nii.sew.common.LogGenerate;
import static jp.co.nii.sew.integration.AbstractConfigDao.getSchemaName;
import jp.co.nii.sew.integration.SQLStateSQLExceptionTranslater;

/**
 * �ėp��������_���� DAO�����N���X
 *
 * @author DB�Ǘ��c�[��
 */
public class HanyoKensakuDtlJknDaoImpl extends GeneratedHanyoKensakuDtlJknDaoImpl implements HanyoKensakuDtlJknDao {

    /**
     * �C���X�^���X�𐶐�����B
     *
     * @param datasource �f�[�^�\�[�X��
     */
    public HanyoKensakuDtlJknDaoImpl(String datasource) {
        super(datasource);
    }

    @Override
    public List<HanyouSearchJoho> findByKensakuId(String vlaue) {
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        String sql = "";
        List<String> param = new ArrayList<>();
        List<HanyouSearchJoho> ret = new ArrayList<>();

        String currentDate = new SystemTime().getymd1();

        try {
            con = getConnection();
            con = getConnection();
            sql = "SELECT " + FIELDS
                    + " FROM " + getSchemaName() + "." + TABLE_NAME
                    + " WHERE "
                    + " HANYO_KENSAKU_ID_JKN = ? "
                    + " ORDER BY MEISAI_GYO_NO ASC";

            param.add(vlaue);
            stmt = con.prepareStatement(sql);
            int i = 1;
            for (String pm : param) {
                stmt.setString(i++, pm);
            }

            LogGenerate.debugOutput(getSql(stmt));
            rs = stmt.executeQuery();
            while (rs.next()) {
                HanyouSearchJoho joho = new HanyouSearchJoho();

                joho.setMeisaiGyoNo(rs.getString("MEISAI_GYO_NO"));
                joho.setJokenKomokuId(rs.getString("JOKEN_KOMOKU_ID"));
                joho.setJokenGyoNo(rs.getString("JOKEN_GYO_NO"));
                joho.setJokenChi(rs.getString("JOKEN_CHI"));

                ret.add(joho);
            }
        } catch (SQLException ex) {
            throw new SQLStateSQLExceptionTranslater().translate(getSql(stmt), ex);
        } finally {
            close(con, stmt, rs);
        }
        return ret;

    }
}
