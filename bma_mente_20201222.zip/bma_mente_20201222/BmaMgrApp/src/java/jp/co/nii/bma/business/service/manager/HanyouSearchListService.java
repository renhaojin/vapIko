package jp.co.nii.bma.business.service.manager;

import java.util.ArrayList;
import java.util.List;
import jp.co.nii.bma.business.domain.HanyoKensakuOutMst;
import jp.co.nii.bma.business.domain.HanyoKensakuHedOut;
import jp.co.nii.bma.business.domain.HoyuShikakuMst;
import jp.co.nii.bma.business.domain.MeishoKanri;
import jp.co.nii.bma.business.domain.Moshikomi;
import jp.co.nii.bma.business.domain.Torokusha;
import jp.co.nii.bma.business.rto.manager.HanyouSearchJoho;
import jp.co.nii.bma.business.service.common.BmaConstants;
import jp.co.nii.bma.business.service.common.BmaLogger;
import jp.co.nii.bma.utility.BmaUtility;
import jp.co.nii.sew.business.service.AbstractService;
import static jp.co.nii.sew.business.service.ApplicationService.FWD_NM_SESSION;
import jp.co.nii.sew.presentation.Messages;
import jp.co.nii.sew.presentation.Option;
import jp.co.nii.sew.presentation.RequestTransferObject;
import jp.co.nii.sew.utility.PropertyUtility;

/**
 * <p>
 * �^�C�g��: �ėp������ʃT�[�r�X</p>
 * <p>
 * ����: �ėp������ʃT�[�r�X</p>
 * <p>
 * ���쌠: Copyright (c) 2020</p>
 * <p>
 * ��Ж�: ���{���Y�Ɗ������</p>
 */
public class HanyouSearchListService extends AbstractService {

    /**
     * DB�ڑ��̃f�[�^�\�[�X
     */
    private static String DATA_SOURCE_NAME;
    /**
     * ���O
     */
    BmaLogger log = (BmaLogger) BmaLogger.getLogger(this.getClass().getName());
    /**
     * �Ɩ��R�[�h
     */
    private static final String BUSINESS_CODE = PropertyUtility.getProperty("business_code");

    /**
     * �N�x
     */
    private static final String NEN = PropertyUtility.getProperty(BUSINESS_CODE + "nen");

    /**
     * �R���X�g���N�^
     */
    public HanyouSearchListService() {
        super();
        /* DB�ڑ����̃��[�U�[������ */
        DATA_SOURCE_NAME = BmaConstants.DS_REGISTRANT;
    }

    /**
     * �T�[�r�X�N���X�̎��s���\�b�h
     *
     * @param rto ���N�G�X�g��񂩂�擾����rto
     * @param rtoinSession �Z�b�V�������rto
     * @return foward��
     * @throws Exception ��O
     */
    @Override
    public String doService(RequestTransferObject rto, RequestTransferObject rtoinSession)
            throws Exception {

        HanyouSearchJoho inRequest = (HanyouSearchJoho) rto;
        HanyouSearchJoho inSession = (HanyouSearchJoho) rtoinSession;
        String processName = "";

        /*�G���[���b�Z�[�W������*/
        inSession.setErrors(new Messages());

        try {
            if (!BmaUtility.isNullOrEmpty(inRequest.getShosai())) {
                /*�ڍ׃{�^��������*/
                processName = "shosai";
                log.Start(processName);

                inSession.clearInfo();

                String moshikomiId = inRequest.getMoshikomishaId();
                setTourokuMoshikomiJoho(inRequest, inSession, moshikomiId);
                return FWD_NM_NEXT;

            } else if (!BmaUtility.isNullOrEmpty(inRequest.getHayoBack())) {
                /*�u�߂�v�{�^��������*/
                processName = "hayoBack";
                log.Start(processName);

                HanyouSearchJoho taihi = inSession.getTaihi();

                inSession.setSrcTempNo(taihi.getSrcTempNo());
                inSession.setFurigana(taihi.getFurigana());

                inSession.setBirthYear(taihi.getBirthYear());
                inSession.setBirthMonth(taihi.getBirthMonth());
                inSession.setBirthDay(taihi.getBirthDay());
                inSession.setKigyocode(taihi.getKigyocode());
                inSession.setKinmusakiName(taihi.getKinmusakiName());

                inSession.setBangoNyuryoku(taihi.getBangoNyuryoku());
                inSession.setBangoInput(taihi.getBangoInput());
                inSession.setUpdateFlag(taihi.getUpdateFlag());

                return FWD_NM_BACK;
            } else if (!BmaUtility.isNullOrEmpty(inRequest.getHayoKakoBack())) {
                /*�u�߂�v�{�^��������*/
                processName = "hayoKakoBack";
                log.Start(processName);

                HanyouSearchJoho taihi = inSession.getTaihi();

                inSession.setSrcTempNo(taihi.getSrcTempNo());
                inSession.setFurigana(taihi.getFurigana());

                inSession.setBirthYear(taihi.getBirthYear());
                inSession.setBirthMonth(taihi.getBirthMonth());
                inSession.setBirthDay(taihi.getBirthDay());
                inSession.setKigyocode(taihi.getKigyocode());
                inSession.setKinmusakiName(taihi.getKinmusakiName());

                inSession.setBangoNyuryoku(taihi.getBangoNyuryoku());
                inSession.setBangoInput(taihi.getBangoInput());
                inSession.setUpdateFlag(taihi.getUpdateFlag());

                return FWD_NW_SEARCH;
            } else if (!BmaUtility.isNullOrEmpty(inRequest.getKoumokuSelect())) {
                /*�u���ڑI���v�{�^��������*/
                processName = "koumokuSelect";
                log.Start(processName);

                inSession.setSrcTempNo("");
                inSession.setHanyoKensakuOutList(null);

                //�����e���v���[�g���X�g �ėp�����w�b�__�o�͂���
                // �ėp��������_�����Ƀe���v���[�g�ۑ�
                List<Option> list = createKoumokuTempList();
                inSession.setKoumokuTmpList(list);

                List<Option> listOut = createHanyoKensakuNoOutList();
                inSession.setHanyoKensakuNoOutList(listOut);

                return FWD_NM_TEMPLATE;
            } else if (!BmaUtility.isNullOrEmpty(inRequest.getCommandPage())) {
                /* �y�[�W�J�� */
                processName = "commandPage";
                log.Start(processName);

                inSession.setPage(Integer.parseInt(inRequest.getCommandPage()));

                HanyouSearchPastYearService hanyouSearch = new HanyouSearchPastYearService();
                hanyouSearch.setPage(inSession);
                hanyouSearch.setDisplayList(inSession);

                return FWD_NM_RELOAD;
            } else {
                /*�ُ�J��*/
                log.IllegalFWD();
                return FWD_NM_SESSION;
            }
        } catch (Exception e) {
            throw e;
        } finally {
            log.End(processName);
        }
    }

    /**
     * �����e���v���[�g���X�g�̍쐬
     *
     * @param inSession �Z�b�V�������
     */
    private List<Option> createKoumokuTempList() {
        /* �ϐ������� */
        List<Option> list = new ArrayList<>();
        HanyoKensakuHedOut hedOut = new HanyoKensakuHedOut(BmaConstants.DS_REGISTRANT);

        /* �����e���v���[�g���X�g���X�g��p�� */
        hedOut.findHanyoListSearch(list);
        return list;
    }

    /**
     * �����e���v���[�g���X�g�̍쐬
     *
     * @param inSession �Z�b�V�������
     */
    private List<Option> createHanyoKensakuNoOutList() {
        /* �ϐ������� */
        List<Option> list = new ArrayList<>();
        HanyoKensakuOutMst hedOut = new HanyoKensakuOutMst(BmaConstants.DS_REGISTRANT);

        /* �����e���v���[�g���X�g���X�g��p�� */
        hedOut.findDtlOutMstList(list);
        return list;
    }

    /**
     * ��ʂɃf�[�^��ݒ肷��
     *
     * @param inSession
     */
    public void setTourokuMoshikomiJoho(HanyouSearchJoho inRequest, HanyouSearchJoho inSession, String moshikomiId) {
        List<Option> list;
        /* ���̊Ǘ��I�u�W�F�N�g�擾 */
        MeishoKanri meisho = new MeishoKanri(DATA_SOURCE_NAME);
        /*�^�p�󋵃��X�g�擾*/
        list = new ArrayList<>();
        meisho.findByGroupCode(BmaConstants.UNYO_JOKYO_KBN, list);
        inSession.setUnyouList(list);

        /*���ۃ��X�g�擾*/
        list = new ArrayList<>();
        meisho.findByGroupCode(BmaConstants.GOHI_JOKYO_KBN, list);
        inSession.setGohiJokyoKbnList(list);

        inSession.setMoshikomishaId(moshikomiId);

        /* ���͂��ꂽ����DB���� */
        Torokusha torokusha = new Torokusha(DATA_SOURCE_NAME).find(moshikomiId);

        inSession.setMoshikomishaId(torokusha.getMoshikomishaId());
        // ���O�C���敪
        inSession.setLoginKbn(torokusha.getLoginKbn());
        inSession.setShimei(torokusha.getShimei());
        inSession.setFurigana(torokusha.getFurigana());
        inSession.setKaiinKbn(torokusha.getKaiinKbn());

        // �O��
        inSession.setGaijiFlg(torokusha.getGaijiFlg());
        inSession.setGaijiShosai(torokusha.getGaijiShosai());
        inSession.setSex(torokusha.getSex());
        if (!BmaUtility.isNullOrEmpty(torokusha.getBirthday()) && torokusha.getBirthday().length() == 8) {
            inSession.setBirthYear(torokusha.getBirthday().substring(0, 4));
            inSession.setBirthMonth(torokusha.getBirthday().substring(4, 6));
            inSession.setBirthDay(torokusha.getBirthday().substring(6));
        }

        if (!BmaUtility.isNullOrEmpty(torokusha.getYubinNo()) && torokusha.getYubinNo().length() > 3) {
            inSession.setYubinNoFront(torokusha.getYubinNo().substring(0, 3));
            inSession.setYubinNoBack(torokusha.getYubinNo().substring(3));
        }

        inSession.setJusho1(torokusha.getJusho1());
        inSession.setJusho2(torokusha.getJusho2());
        inSession.setTatemono(torokusha.getTatemono());
        inSession.setTelNo(torokusha.getTelNo());
        inSession.setFaxNo(torokusha.getFaxNo());
        inSession.setMailAddress(torokusha.getMailAddress());
        //�Ζ�����
        inSession.setKinmusakiName(torokusha.getKinmusakiName());
        if (!BmaUtility.isNullOrEmpty(torokusha.getKinmusakiYubinNo()) && torokusha.getKinmusakiYubinNo().length() > 3) {
            inSession.setKinmusakiYubinFront(torokusha.getKinmusakiYubinNo().substring(0, 3));
            inSession.setKinmusakiYubinBack(torokusha.getKinmusakiYubinNo().substring(3));
        }

        inSession.setKinmusakiJusho1(torokusha.getKinmusakiJusho1());
        inSession.setKinmusakiJusho2(torokusha.getKinmusakiJusho2());

        inSession.setKinmusakiTatemono(torokusha.getKinmusakiTatemono());
        inSession.setKinmusakiTelNo(torokusha.getKinmusakiTelNo());
        inSession.setKinmusakiFaxNo(torokusha.getKinmusakiFaxNo());
        inSession.setKinmusakiName(torokusha.getKinmusakiName());
        inSession.setKinmusakiFaxNo(torokusha.getKinmusakiFaxNo());
        inSession.setKigyocode(torokusha.getKigyoCode());
        inSession.setKyokaiName(torokusha.getKyokaiName());
        inSession.setGaijiFlg(torokusha.getGaijiFlg());
        inSession.setBiko(torokusha.getBiko());

        Moshikomi mc = new Moshikomi(DATA_SOURCE_NAME);
        List<HanyouSearchJoho> allList = mc.findGroupByMoshkomiId(inSession);

        inSession.setMoshikomiDetailList(allList);

        HoyuShikakuMst hoyuShikakuMst = new HoyuShikakuMst(DATA_SOURCE_NAME);

        List<HanyouSearchJoho> allListHou = hoyuShikakuMst.searchGroupByMoshkomiId(inSession);

        inSession.setHoyoSikakuDetailList(allListHou);
    }

}
