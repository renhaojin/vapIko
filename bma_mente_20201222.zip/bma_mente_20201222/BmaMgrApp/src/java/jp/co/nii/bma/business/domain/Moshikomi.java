package jp.co.nii.bma.business.domain;

import java.util.ArrayList;
import java.util.List;
import jp.co.nii.bma.business.rto.manager.HanyouSearchJoho;
import jp.co.nii.bma.business.rto.manager.NumKanriJoho;

/**
 * �\�� BO�N���X
 *
 * @author DB�Ǘ��c�[��
 */
public class Moshikomi extends GeneratedMoshikomi {

    /**
     * ����
     */
    private String shimei;
    /**
     * �t���K�i
     */
    private String furigana;
    /**
     * ���N����
     */
    private String birthday;

    /**
     * �C���X�^���X�𐶐�����B
     */
    public Moshikomi() {
        super();
    }

    /**
     * �C���X�^���X�𐶐�����B
     *
     * @param connectionUser �f�[�^�\�[�X��
     */
    public Moshikomi(String connectionUser) {
        super(connectionUser);
    }

    /**
     * ���ʎ�t�ԍ����擾����B
     *
     * @param nendo
     * @return �摜�ꗗ���X�g
     */
    public List<String> searchShomenUketsukeNo() {
        return dao.searchShomenUketsukeNo();
    }

    /**
     * ���ʎ�t�ԍ����擾����B
     *
     * @param shomenUketsukeNo
     * @return �摜�ꗗ���X�g
     */
    public Moshikomi searchMoshikomiJoho(String shomenUketsukeNo) {
        Moshikomi bo = new Moshikomi();
        bo.setShomenUketsukeNo(shomenUketsukeNo);
        return dao.searchMoshikomiJoho(bo);
    }

    public ArrayList<Moshikomi> findTmpJohoList(NumKanriJoho inSession) {
        return dao.findTmpJohoList(inSession);
    }

    public Moshikomi findShikakuMenjo(String nendo, String jukenJukoNo) {
        return dao.findShikakuMenjo(nendo, jukenJukoNo);
    }

    public Moshikomi findByJukenJukoNo(String sknKsuCode, String shubetsuCode, String kaisuCode, String nendo, String jukenJukoNo) {
        return dao.findByJukenJukoNo(sknKsuCode, shubetsuCode, kaisuCode, nendo, jukenJukoNo);
    }

    /**
     * @return the shimei
     */
    public String getShimei() {
        return shimei;
    }

    /**
     * @param shimei the shimei to set
     */
    public void setShimei(String shimei) {
        this.shimei = shimei;
    }

    /**
     * @return the furigana
     */
    public String getFurigana() {
        return furigana;
    }

    /**
     * @param furigana the furigana to set
     */
    public void setFurigana(String furigana) {
        this.furigana = furigana;
    }

    /**
     * @return the birthday
     */
    public String getBirthday() {
        return birthday;
    }

    /**
     * @param birthday the birthday to set
     */
    public void setBirthday(String birthday) {
        this.birthday = birthday;
    }

    public List<HanyouSearchJoho> findGroupByMoshkomiId(HanyouSearchJoho inSession) {
        return dao.findGroupByMoshkomiId(inSession);
    }
    /**
     * �\�������擾����B
     *
     * @param bo
     * @return �\�����
     */
    public Moshikomi findRonriFlg(String nendo, String uketsukeNo) {
        Moshikomi bo = new Moshikomi();
        bo.setUketsukeNo(uketsukeNo);
        bo.setNendo(nendo);
        return dao.findRonriFlg(bo);
    }

}
