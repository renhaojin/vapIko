package jp.co.nii.bma.business.rto.manager;

import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import jp.co.nii.bma.business.service.common.BmaConstants;
import jp.co.nii.sew.presentation.AbstractRequestTransferObject;
import jp.co.nii.sew.presentation.DownloadRTO;
import jp.co.nii.sew.presentation.Messages;
import jp.co.nii.sew.presentation.Option;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItem;

/**
 * �^�C�g��: TOP��� ����: TOP���RTO ���쌠: Copyright (c) 2020 ��Ж�: ���{���Y�Ɗ������
 */
public class GazoKanriJoho extends DownloadRTO {

    /**
     * @return the uketukeNoCond
     */
    public String getUketukeNoCond() {
        return uketukeNoCond;
    }

    /**
     * @param uketukeNoCond the uketukeNoCond to set
     */
    public void setUketukeNoCond(String uketukeNoCond) {
        this.uketukeNoCond = uketukeNoCond;
    }

    /**
     * @return the furiganaCond
     */
    public String getFuriganaCond() {
        return furiganaCond;
    }

    /**
     * @param furiganaCond the furiganaCond to set
     */
    public void setFuriganaCond(String furiganaCond) {
        this.furiganaCond = furiganaCond;
    }

    private Messages errors;
    private String scrollPlace;
    private String gazoShuruiChoice;
    private String sknksuKbn;
    private String sknName;
    private String ksuName;
    private String[] chkGazoStatusChoice;
    private String[] gazoStatusCodes;
    private String[] gazoStatusNames;
    private String uketukeNo;
    private String jknJkuNo;
    private String furigana;
    private String uketukeNoCond;
    private String furiganaCond;
    private String shosaiUketukeNo;
    private String shosaiJknJkuNo;
    private String shosaiFurigana;
    private String shosaiShimei;
    private String shosaiSeq;
    private String[] chkMskKbn;
    private String sknKsuCode;
    private String[] mskKbnNames;
    private String[] chkKojinDantai;
    private String gazoStatus;
    private String gazoStatusChi;
    private String gazoSearch;
    private String inpClear;
    private String gazo_idx;
    private String[] gazo_idxs;
    private String[] uketukeNos;
    private String seq;
    private String shimei;
    private String kojinDantaiKbn;
    private String kojinDantaiChi;
    private String yusounetKbn;
    private String yusounetChi;
    private String mskKbn;
    private String gazoStatusChoice;
    private String shubetsuCode;
    private String uploadCheck;
    private String kaisuCode;
    private String gazoSearchKekka;
    private String kaojashinPreview;
    private String mskHohoKbn;
    private String shomeiSearchKekkaBack;
    private String kaojashinShosaiGazoDl;
    private String shomeiSearchKekkaUpd;
    private String gazoKanrenKomoku1st;
    private String gazoKanrenKomoku2nd;
    private String gazoKanrenKomoku3rd;
    private String gazoKanrenKomoku4td;
    private String gazoKanrenJoho1st;
    private String gazoKanrenJoho2nd;
    private String gazoKanrenJoho3rd;
    private String gazoKanrenJoho4td;
    private String gazoKanrenJoho5td;
    private String gazoKanrenJoho6td;
    private String gazoKanrenJoho7td;
    private String gazoKanrenJoho8td;
    private String shinsaKekka;
    private String[] chkFubiRiyu;
    private String biko;
    private String nendo;
    private String kaojashinShosaiToroku;
    private String torokuCheck;
    private String[] shosaiTorokuCodes;
    private String[] shosaiTorokuNames;
    private String kaojashinShosaiBack;
    private String kaojashinShosaiGazoUpd;
    private String gazoKanri;
    private String gazoShosai;
    private List<String> okngList;
    private String[] chkOkng;
    private String[] chkOkngValue;
    private String kaojashinSearchKekkaBack;
    private String kaojashinSearchKekkaUpd;
    private String hoseiKigenBi;
    private String hoseiKigen;
    private String gazoUpd;
    private List<Option> fubiRiyuCodes;
    private List<Option> fubiAriCodes;
    private String[] shinsaKekkaNames;
    private List<String> dispKeyList;
    private List<GazoKanriJoho> searchOutList;
    private List<GazoKanriJoho> gazoDetailList;
    private List<GazoKanriJoho> gazoShosaiList;
    private List<Option> sknKbnList;
    private List<Option> ksuKbnList;
    private List<Option> gazoKbnList;
    private List<Option> hoseiIraiKbnList;
    private List<Option> moshikomiKbnList;
    private List<Option> kojinDantaiKbnList;
    private int pageMax;
    private int page;
    private int maxDisp;
    private int firstDisp;
    private int pageBegin;
    private int pageEnd;
    private String searchFlg;
    private String CommandPage;
    private String index;
    private String koshin_date;
    private String koshin_time;
    private String listKoshin_date;
    private String listKoshin_time;
    private String gazoKbn;
    private String gazoKbnChi;
    private String nenrei;
    private String fubiRiyu1;
    private String fubiRiyu2;
    private String fubiRiyu3;
    private List<String> fubiRiyuList;
    private List<String> shokurekiList;
    private List<String> kunrenList;
    private List<GazoKanriJoho> gakurekiShosaiList;
    private List<GazoKanriJoho> kunrenShosaiList;
    private String shokurekiCnt;
    private String gakurekiCnt;
    private String genmen;
    private String birthday;
    private String shikakuCode;
    private String menjoCode;
    private String shinseiShikakuNo;
    private String shinseiMenjoNo;
    private String hoseiIraiKbn;
    private String gazoHyojiKbn;
    private String moshikomishaId;
    private String seniFlg;
    private String fileKbn;
    private String[] urls;
    private String tagPath;
    private String gazoUlBack;
    /**
     * w01-2���ʐ\��_�摜�I�����
     */
    private DiskFileItem gazoChoice;
    private String gazoPreview;
    private String gazoChoiceBack;
    private String gazoChoiceGazoDl;
    private String gazoChoiceGazoUpd;
    private String gazoUl;
    private String gazoUlSeq;
    private FileItem fileItem;

    /**
     * 01-1���ʐ\��_�摜�f�[�^�A�b�v���[�h��� �u�m�F�v�{�^��
     */
    private String gazoUlKakunin;
    /**
     * w01-3���ʐ\��_�摜�m�F��ʁ@�u����v�{�^��
     */
    private String gazoKakuninBack;

    //�R���X�g���N�^/������/���N�G�X�g�擾
    /**
     * �R���X�g���N�^
     */
    public GazoKanriJoho() {
        clearInfo();
    }

    /**
     * ���������\�b�h
     */
    public void clearInfo() {
        String init[] = {""};
        String initGazo[] = {""};
        setErrors(new Messages());
        setSknksuKbn("");
        setSknName(BmaConstants.SKN_CHECK);
        setKsuName(BmaConstants.KSU_CHECK);
        setGazoShuruiChoice("00");
        setChkGazoStatusChoice(initGazo);
        setChkMskKbn(init);
        setChkKojinDantai(init);
        setUketukeNo("");
        setUketukeNoCond("");
        setShosaiUketukeNo("");
        setShosaiJknJkuNo("");
        setShosaiFurigana("");
        setShosaiFurigana("");
        setShosaiShimei("");
        setShosaiSeq("");
        setJknJkuNo("");
        setFurigana("");
        setFuriganaCond("");
        setGazoUpd("");
        setSknKsuCode("");
        setGazoStatus("");
        setGazoStatusChi("");
        setInpClear("");
        setUploadCheck("");
        setGazo_idx("");
        setSeq("");
        setShimei("");
        setNendo("");
        setKojinDantaiKbn("");
        setKojinDantaiChi("");
        setYusounetKbn("");
        setYusounetChi("");
        setMskKbn("");
        setGazoStatusChoice("");
        setGazoSearch("");
        setGazoShosai("");
        setShubetsuCode("");
        setKaisuCode("");
        setGazoSearchKekka("");
        setKaojashinPreview("");
        setMskHohoKbn("");
        setShomeiSearchKekkaBack("");
        setKaojashinShosaiGazoDl("");
        setShomeiSearchKekkaUpd("");
        setGazoKanrenKomoku1st("");
        setGazoKanrenKomoku2nd("");
        setGazoKanrenKomoku3rd("");
        setGazoKanrenKomoku4td("");
        setGazoKanrenJoho1st("");
        setGazoKanrenJoho2nd("");
        setGazoKanrenJoho3rd("");
        setGazoKanrenJoho4td("");
        setGazoKanrenJoho5td("");
        setGazoKanrenJoho6td("");
        setGazoKanrenJoho7td("");
        setGazoKanrenJoho8td("");
        setShokurekiCnt("");
        setGakurekiCnt("");
        setShinsaKekka("");
        setBiko("");
        setKaojashinShosaiToroku("");
        setKaojashinShosaiBack("");
        setKaojashinShosaiGazoUpd("");
        setGazoKanri("");
        setKaojashinSearchKekkaBack("");
        setKaojashinSearchKekkaUpd("");
        setListKoshin_date("");
        setListKoshin_time("");
        setGazoKbn("");
        setGazoKbnChi("");
        setNenrei("");
        setFubiRiyu1("");
        setFubiRiyu2("");
        setFubiRiyu3("");
        setGenmen("");
        setBirthday("");
        setFirstDisp(0);
        setMaxDisp(0);
        setPage(0);
        setPageBegin(0);
        setPageEnd(0);
        setPageMax(0);
        setCommandPage("");
        setSearchFlg("0");
        setIndex("");
        setKoshin_date("");
        setKoshin_time("");
        setShikakuCode("");
        setMenjoCode("");
        setShinseiShikakuNo("");
        setShinseiMenjoNo("");
        setHoseiIraiKbn("");
        setGazoHyojiKbn("");
        setMoshikomishaId("");
        setGazoUlSeq("");
        setTorokuCheck("");
        setSeniFlg("");
        setFileKbn("");
        setTagPath("");
        setGazoUlBack("");
        setHoseiKigenBi("");
        setHoseiKigen("");
        /**
         * w01-2���ʐ\��_�摜�I�����
         */
        setGazoPreview("");
        setGazoChoiceBack("");
        setGazoChoiceGazoDl("");
        setGazoChoiceGazoUpd("");
        setGazoUl("");
        /**
         * 01-1���ʐ\��_�摜�f�[�^�A�b�v���[�h �{�^��
         */
        setGazoUlKakunin(gazoUlKakunin);
        /**
         * w01-3���ʐ\��_�摜�m�F  �{�^��
         */
        setGazoKakuninBack("");
    }

    /**
     * ���N�G�X�g��������擾���郁�\�b�h
     *
     * @param request ���N�G�X�g
     */
    @Override
    public void copyFromRequest(HttpServletRequest request) {
        setNendo((String) request.getAttribute("nendo"));
        setScrollPlace((String) request.getAttribute("scrollPlace"));
        setSknksuKbn((String) request.getAttribute("sknksuKbn"));
        setSknName((String) request.getAttribute("sknName"));
        setKsuName((String) request.getAttribute("ksuName"));
        setSknKsuCode((String) request.getAttribute("sknKsuCode"));
        setGazoShuruiChoice((String) request.getAttribute("gazoShuruiChoice"));
        setUketukeNo((String) request.getAttribute("uketukeNo"));
        setUketukeNoCond((String) request.getAttribute("uketukeNoCond"));
        setJknJkuNo((String) request.getAttribute("jknJkuNo"));
        setFurigana((String) request.getAttribute("furigana"));
        setFuriganaCond((String) request.getAttribute("furiganaCond"));
        setShosaiUketukeNo((String) request.getAttribute("shosaiUketukeNo"));
        setShosaiJknJkuNo((String) request.getAttribute("shosaiJknJkuNo"));
        setShosaiFurigana((String) request.getAttribute("shosaiFurigana"));
        setShosaiShimei((String) request.getAttribute("shosaiShimei"));
        setShosaiSeq((String) request.getAttribute("shosaiSeq"));
        setGazoStatus((String) request.getAttribute("gazoStatus"));
        setGazoStatusChi((String) request.getAttribute("gazoStatusChi"));
        setGazoSearch((String) request.getAttribute("gazoSearch"));
        setShokurekiCnt((String) request.getAttribute("shokurekiCnt"));
        setGakurekiCnt((String) request.getAttribute("gakurekiCnt"));
        setInpClear((String) request.getAttribute("inpClear"));
        setGazo_idx((String) request.getAttribute("gazo_idx"));
        setSeq((String) request.getAttribute("seq"));
        setShimei((String) request.getAttribute("shimei"));
        setHoseiKigenBi((String) request.getAttribute("hoseiKigenBi"));
        setHoseiKigen((String) request.getAttribute("hoseiKigen"));
        setChkGazoStatusChoice((String[]) request.getParameterValues("chkGazoStatusChoice"));
        setChkMskKbn((String[]) request.getParameterValues("chkMskKbn"));
        setChkKojinDantai((String[]) request.getParameterValues("chkKojinDantai"));
        setGazoShosai((String) request.getAttribute("gazoShosai"));
        setShubetsuCode((String) request.getAttribute("shubetsuCode"));
        setKaisuCode((String) request.getAttribute("kaisuCode"));
        setKojinDantaiKbn((String) request.getAttribute("kojinDantaiKbn"));
        setKojinDantaiChi((String) request.getAttribute("kojinDantaiChi"));
        setYusounetKbn((String) request.getAttribute("yusounetKbn"));
        setYusounetChi((String) request.getAttribute("yusounetChi"));
        setGazoSearchKekka((String) request.getAttribute("gazoSearchKekka"));
        setKaojashinPreview((String) request.getAttribute("kaojashinPreview"));
        setMskHohoKbn((String) request.getAttribute("mskHohoKbn"));
        setUploadCheck((String) request.getAttribute("uploadCheck"));
        setShomeiSearchKekkaBack((String) request.getAttribute("shomeiSearchKekkaBack"));
        setKaojashinShosaiGazoDl((String) request.getAttribute("kaojashinShosaiGazoDl"));
        setShomeiSearchKekkaUpd((String) request.getAttribute("shomeiSearchKekkaUpd"));
        setGazoKanrenKomoku1st((String) request.getAttribute("gazoKanrenKomoku1st"));
        setGazoKanrenKomoku2nd((String) request.getAttribute("gazoKanrenKomoku2nd"));
        setGazoKanrenKomoku3rd((String) request.getAttribute("gazoKanrenKomoku3rd"));
        setGazoKanrenKomoku4td((String) request.getAttribute("gazoKanrenKomoku4td"));
        setGazoKanrenJoho1st((String) request.getAttribute("gazoKanrenJoho1st"));
        setGazoKanrenJoho2nd((String) request.getAttribute("gazoKanrenJoho2nd"));
        setGazoKanrenJoho3rd((String) request.getAttribute("gazoKanrenJoho3rd"));
        setGazoKanrenJoho4td((String) request.getAttribute("gazoKanrenJoho4td"));
        setGazoKanrenJoho5td((String) request.getAttribute("gazoKanrenJoho5td"));
        setGazoKanrenJoho6td((String) request.getAttribute("gazoKanrenJoho6td"));
        setGazoKanrenJoho7td((String) request.getAttribute("gazoKanrenJoho7td"));
        setGazoKanrenJoho8td((String) request.getAttribute("gazoKanrenJoho8td"));
        setShinsaKekka((String) request.getAttribute("shinsaKekka"));
        setChkFubiRiyu((String[]) request.getParameterValues("chkFubiRiyu"));
        setGazoUpd((String) request.getAttribute("gazoUpd"));
        setBiko((String) request.getAttribute("biko"));
        setKaojashinShosaiToroku((String) request.getAttribute("kaojashinShosaiToroku"));
        setKaojashinShosaiBack((String) request.getAttribute("kaojashinShosaiBack"));
        setKaojashinShosaiGazoUpd((String) request.getAttribute("kaojashinShosaiGazoUpd"));
        setGazoKanri((String) request.getAttribute("gazoKanri"));
        setChkOkng((String[]) request.getParameterValues("chkOkng"));
        setChkOkngValue((String[]) request.getParameterValues("chkOkngValue"));
        setKaojashinSearchKekkaBack((String) request.getAttribute("kaojashinSearchKekkaBack"));
        setKaojashinSearchKekkaUpd((String) request.getAttribute("kaojashinSearchKekkaUpd"));
        setTorokuCheck((String) request.getAttribute("torokuCheck"));
        /**
         * w01-2���ʐ\��_�摜�I�����
         */
        setGazoChoice((DiskFileItem) request.getAttribute("gazoChoice"));
        setFileItem((FileItem) request.getAttribute("gazoChoice"));
        setGazoPreview((String) request.getAttribute("gazoPreview"));
        setGazoChoiceBack((String) request.getAttribute("gazoChoiceBack"));
        setGazoChoiceGazoDl((String) request.getAttribute("gazoChoiceGazoDl"));
        setGazoChoiceGazoUpd((String) request.getAttribute("gazoChoiceGazoUpd"));
        setGazoUl((String) request.getAttribute("gazoUl"));
        setGazoUlSeq((String) request.getAttribute("gazoUlSeq"));
        setGazo_idxs((String[]) request.getParameterValues("gazo_idxs"));
        setGazoUlBack((String) request.getAttribute("gazoUlBack"));
        /**
         * 01-1���ʐ\��_�摜�f�[�^�A�b�v���[�h �{�^��
         */
        setGazoUlKakunin((String) request.getAttribute("gazoUlKakunin"));
        /**
         * w01-3���ʐ\��_�摜�m�F
         */
        setGazoKakuninBack((String) request.getAttribute("gazoKakuninBack"));
        setCommandPage((String) request.getAttribute("commandPage"));
        setSearchFlg((String) request.getAttribute("searchFlg"));
        setIndex((String) request.getAttribute("index"));
        setKoshin_date((String) request.getAttribute("koshin_date"));
        setKoshin_time((String) request.getAttribute("koshin_time"));
        setListKoshin_date((String) request.getAttribute("listKoshin_date"));
        setListKoshin_time((String) request.getAttribute("listKoshin_time"));
        setGazoKbn((String) request.getAttribute("gazoKbn"));
        setGazoKbnChi((String) request.getAttribute("gazoKbnChi"));
        setNenrei((String) request.getAttribute("nenrei"));
        setFubiRiyu1((String) request.getAttribute("fubiRiyu1"));
        setFubiRiyu2((String) request.getAttribute("fubiRiyu2"));
        setFubiRiyu3((String) request.getAttribute("fubiRiyu3"));
        setGenmen((String) request.getAttribute("genmen"));
        setFileKbn((String) request.getAttribute("fileKbn"));
        setBirthday((String) request.getAttribute("birthday"));
        setShikakuCode((String) request.getAttribute("shikakuCode"));
        setMenjoCode((String) request.getAttribute("menjoCode"));
        setShinseiShikakuNo((String) request.getAttribute("shinseiShikakuNo"));
        setShinseiMenjoNo((String) request.getAttribute("shinseiMenjoNo"));
        setHoseiIraiKbn((String) request.getAttribute("hoseiIraiKbn"));
        setGazoHyojiKbn((String) request.getAttribute("gazoHyojiKbn"));
        setMoshikomishaId((String) request.getAttribute("moshikomishaId"));
        setGazoUl((String) request.getAttribute("gazoUl"));
        setGazoUlKakunin((String) request.getAttribute("gazoUlKakunin"));
        setTagPath((String) request.getAttribute("tagPath"));
        HttpSession session = request.getSession(false);
        if (session != null && session.getAttribute("SmnMskJoho") != null) {
            if ((String) request.getAttribute("gazoSearch") == null) {
                SmnMskJoho tmp = (SmnMskJoho) session.getAttribute("SmnMskJoho");
                int gazoUi = 0;
                if ((String) request.getAttribute("gazoUl") != null) {
                    gazoUi = Integer.parseInt((String) request.getAttribute("gazoUl"));
                    setGazoUlSeq((String) request.getAttribute("gazoUl"));
                }
                if (tmp.getGazoDetailList() != null) {
                    if ((String) request.getAttribute("gazoUl") == null) {
                        gazoUi = 1;
                    }
                    if (gazoUi > 20) {
                        gazoUi = gazoUi - (tmp.getPage() - 1) * BmaConstants.MAX_PAGE_NUM_MSK_JOHO_SEARCH;
                    }
                    setNendo(tmp.getGazoDetailList().get(gazoUi - 1).getNendo());
                    setUketukeNo(tmp.getGazoDetailList().get(gazoUi - 1).getGazoUlUketsukeNo());
                    setJknJkuNo(tmp.getGazoDetailList().get(gazoUi - 1).getGazoUlJknJkuNo());
                    setFurigana(tmp.getGazoDetailList().get(gazoUi - 1).getGazoUlFurigana());
                    setShimei(tmp.getGazoDetailList().get(gazoUi - 1).getGazoUlSimei());
                    setSeq(tmp.getGazoDetailList().get(gazoUi - 1).getSeq());
                    setGazoKbn(tmp.getGazoDetailList().get(gazoUi - 1).getGazoKbn());
                    setSeniFlg(tmp.getSeniFlg());
                }
            }
        }
        if (session != null && session.getAttribute("MgrTopJoho") != null) {
            MgrTopJoho tmp = (MgrTopJoho) session.getAttribute("MgrTopJoho");
            setMoshikomishaId(tmp.getMoshikomishaId());
        }
    }

    public Messages getErrors() {
        return errors;
    }

    public void setErrors(Messages errors) {
        this.errors = errors;
    }

    /**
     * @return the gazoShuruiChoice
     */
    public String getGazoShuruiChoice() {
        return gazoShuruiChoice;
    }

    /**
     * @param gazoShuruiChoice the gazoShuruiChoice to set
     */
    public void setGazoShuruiChoice(String gazoShuruiChoice) {
        this.gazoShuruiChoice = gazoShuruiChoice;
    }

    /**
     * @return the chkGazoStatusChoice
     */
    public String[] getChkGazoStatusChoice() {
        return chkGazoStatusChoice;
    }

    /**
     * @param chkGazoStatusChoice the chkGazoStatusChoice to set
     */
    public void setChkGazoStatusChoice(String[] chkGazoStatusChoice) {
        this.chkGazoStatusChoice = chkGazoStatusChoice;
    }

    /**
     * @return the gazoStatusCodes
     */
    public String[] getGazoStatusCodes() {
        return gazoStatusCodes;
    }

    /**
     * @param gazoStatusCodes the gazoStatusCodes to set
     */
    public void setGazoStatusCodes(String[] gazoStatusCodes) {
        this.gazoStatusCodes = gazoStatusCodes;
    }

    /**
     * @return the gazoStatusNames
     */
    public String[] getGazoStatusNames() {
        return gazoStatusNames;
    }

    /**
     * @param gazoStatusNames the gazoStatusNames to set
     */
    public void setGazoStatusNames(String[] gazoStatusNames) {
        this.gazoStatusNames = gazoStatusNames;
    }

    /**
     * @return the uketukeNo
     */
    public String getUketukeNo() {
        return uketukeNo;
    }

    /**
     * @param uketukeNo the uketukeNo to set
     */
    public void setUketukeNo(String uketukeNo) {
        this.uketukeNo = uketukeNo;
    }

    /**
     * @return the jknJkuNo
     */
    public String getJknJkuNo() {
        return jknJkuNo;
    }

    /**
     * @param jknJkuNo the jknJkuNo to set
     */
    public void setJknJkuNo(String jknJkuNo) {
        this.jknJkuNo = jknJkuNo;
    }

    /**
     * @return the furigana
     */
    public String getFurigana() {
        return furigana;
    }

    /**
     * @param furigana the furigana to set
     */
    public void setFurigana(String furigana) {
        this.furigana = furigana;
    }

    /**
     * @return the chkMskKbn
     */
    public String[] getChkMskKbn() {
        return chkMskKbn;
    }

    /**
     * @param chkMskKbn the chkMskKbn to set
     */
    public void setChkMskKbn(String[] chkMskKbn) {
        this.chkMskKbn = chkMskKbn;
    }

    /**
     * @return the chkKojinDantai
     */
    public String[] getChkKojinDantai() {
        return chkKojinDantai;
    }

    /**
     * @param chkKojinDantai the chkKojinDantai to set
     */
    public void setChkKojinDantai(String[] chkKojinDantai) {
        this.chkKojinDantai = chkKojinDantai;
    }

    /**
     * @return the gazoStatus
     */
    public String getGazoStatus() {
        return gazoStatus;
    }

    /**
     * @param gazoStatus the gazoStatus to set
     */
    public void setGazoStatus(String gazoStatus) {
        this.gazoStatus = gazoStatus;
    }

    /**
     * @return the gazoSearch
     */
    public String getGazoSearch() {
        return gazoSearch;
    }

    /**
     * @param gazoSearch the gazoSearch to set
     */
    public void setGazoSearch(String gazoSearch) {
        this.gazoSearch = gazoSearch;
    }

    /**
     * @return the gazoSearchKekka
     */
    public String getGazoSearchKekka() {
        return gazoSearchKekka;
    }

    /**
     * @param gazoSearchKekka the gazoSearchKekka to set
     */
    public void setGazoSearchKekka(String gazoSearchKekka) {
        this.gazoSearchKekka = gazoSearchKekka;
    }

    /**
     * @return the kaojashinPreview
     */
    public String getKaojashinPreview() {
        return kaojashinPreview;
    }

    /**
     * @param kaojashinPreview the kaojashinPreview to set
     */
    public void setKaojashinPreview(String kaojashinPreview) {
        this.kaojashinPreview = kaojashinPreview;
    }

    /**
     * @return the mskHohoKbn
     */
    public String getMskHohoKbn() {
        return mskHohoKbn;
    }

    /**
     * @param mskHohoKbn the mskHohoKbn to set
     */
    public void setMskHohoKbn(String mskHohoKbn) {
        this.mskHohoKbn = mskHohoKbn;
    }

    /**
     * @return the shomeiSearchKekkaBack
     */
    public String getShomeiSearchKekkaBack() {
        return shomeiSearchKekkaBack;
    }

    /**
     * @param shomeiSearchKekkaBack the shomeiSearchKekkaBack to set
     */
    public void setShomeiSearchKekkaBack(String shomeiSearchKekkaBack) {
        this.shomeiSearchKekkaBack = shomeiSearchKekkaBack;
    }

    /**
     * @return the kaojashinShosaiGazoDl
     */
    public String getKaojashinShosaiGazoDl() {
        return kaojashinShosaiGazoDl;
    }

    /**
     * @param kaojashinShosaiGazoDl the kaojashinShosaiGazoDl to set
     */
    public void setKaojashinShosaiGazoDl(String kaojashinShosaiGazoDl) {
        this.kaojashinShosaiGazoDl = kaojashinShosaiGazoDl;
    }

    /**
     * @return the shomeiSearchKekkaUpd
     */
    public String getShomeiSearchKekkaUpd() {
        return shomeiSearchKekkaUpd;
    }

    /**
     * @param shomeiSearchKekkaUpd the shomeiSearchKekkaUpd to set
     */
    public void setShomeiSearchKekkaUpd(String shomeiSearchKekkaUpd) {
        this.shomeiSearchKekkaUpd = shomeiSearchKekkaUpd;
    }

    /**
     * @return the gazoKanrenKomoku1st
     */
    public String getGazoKanrenKomoku1st() {
        return gazoKanrenKomoku1st;
    }

    /**
     * @param gazoKanrenKomoku1st the gazoKanrenKomoku1st to set
     */
    public void setGazoKanrenKomoku1st(String gazoKanrenKomoku1st) {
        this.gazoKanrenKomoku1st = gazoKanrenKomoku1st;
    }

    /**
     * @return the gazoKanrenKomoku2nd
     */
    public String getGazoKanrenKomoku2nd() {
        return gazoKanrenKomoku2nd;
    }

    /**
     * @param gazoKanrenKomoku2nd the gazoKanrenKomoku2nd to set
     */
    public void setGazoKanrenKomoku2nd(String gazoKanrenKomoku2nd) {
        this.gazoKanrenKomoku2nd = gazoKanrenKomoku2nd;
    }

    /**
     * @return the gazoKanrenJoho1st
     */
    public String getGazoKanrenJoho1st() {
        return gazoKanrenJoho1st;
    }

    /**
     * @param gazoKanrenJoho1st the gazoKanrenJoho1st to set
     */
    public void setGazoKanrenJoho1st(String gazoKanrenJoho1st) {
        this.gazoKanrenJoho1st = gazoKanrenJoho1st;
    }

    /**
     * @return the gazoKanrenJoho2nd
     */
    public String getGazoKanrenJoho2nd() {
        return gazoKanrenJoho2nd;
    }

    /**
     * @param gazoKanrenJoho2nd the gazoKanrenJoho2nd to set
     */
    public void setGazoKanrenJoho2nd(String gazoKanrenJoho2nd) {
        this.gazoKanrenJoho2nd = gazoKanrenJoho2nd;
    }

    /**
     * @return the shinsaKekka
     */
    public String getShinsaKekka() {
        return shinsaKekka;
    }

    /**
     * @param shinsaKekka the shinsaKekka to set
     */
    public void setShinsaKekka(String shinsaKekka) {
        this.shinsaKekka = shinsaKekka;
    }

    /**
     * @return the chkFubiRiyu
     */
    public String[] getChkFubiRiyu() {
        return chkFubiRiyu;
    }

    /**
     * @param chkFubiRiyu the chkFubiRiyu to set
     */
    public void setChkFubiRiyu(String[] chkFubiRiyu) {
        this.chkFubiRiyu = chkFubiRiyu;
    }

    /**
     * @return the biko
     */
    public String getBiko() {
        return biko;
    }

    /**
     * @param biko the biko to set
     */
    public void setBiko(String biko) {
        this.biko = biko;
    }

    /**
     * @return the kaojashinShosaiToroku
     */
    public String getKaojashinShosaiToroku() {
        return kaojashinShosaiToroku;
    }

    /**
     * @param kaojashinShosaiToroku the kaojashinShosaiToroku to set
     */
    public void setKaojashinShosaiToroku(String kaojashinShosaiToroku) {
        this.kaojashinShosaiToroku = kaojashinShosaiToroku;
    }

    /**
     * @return the shosaiTorokuCodes
     */
    public String[] getShosaiTorokuCodes() {
        return shosaiTorokuCodes;
    }

    /**
     * @param shosaiTorokuCodes the shosaiTorokuCodes to set
     */
    public void setShosaiTorokuCodes(String[] shosaiTorokuCodes) {
        this.shosaiTorokuCodes = shosaiTorokuCodes;
    }

    /**
     * @return the shosaiTorokuNames
     */
    public String[] getShosaiTorokuNames() {
        return shosaiTorokuNames;
    }

    /**
     * @param shosaiTorokuNames the shosaiTorokuNames to set
     */
    public void setShosaiTorokuNames(String[] shosaiTorokuNames) {
        this.shosaiTorokuNames = shosaiTorokuNames;
    }

    /**
     * @return the kaojashinShosaiBack
     */
    public String getKaojashinShosaiBack() {
        return kaojashinShosaiBack;
    }

    /**
     * @param kaojashinShosaiBack the kaojashinShosaiBack to set
     */
    public void setKaojashinShosaiBack(String kaojashinShosaiBack) {
        this.kaojashinShosaiBack = kaojashinShosaiBack;
    }

    /**
     * @return the kaojashinShosaiGazoUpd
     */
    public String getKaojashinShosaiGazoUpd() {
        return kaojashinShosaiGazoUpd;
    }

    /**
     * @param kaojashinShosaiGazoUpd the kaojashinShosaiGazoUpd to set
     */
    public void setKaojashinShosaiGazoUpd(String kaojashinShosaiGazoUpd) {
        this.kaojashinShosaiGazoUpd = kaojashinShosaiGazoUpd;
    }

    /**
     * @return the gazoKanri
     */
    public String getGazoKanri() {
        return gazoKanri;
    }

    /**
     * @param gazoKanri the gazoKanri to set
     */
    public void setGazoKanri(String gazoKanri) {
        this.gazoKanri = gazoKanri;
    }

    /**
     * @return the mskKbnNames
     */
    public String[] getMskKbnNames() {
        return mskKbnNames;
    }

    /**
     * @param mskKbnNames the mskKbnNames to set
     */
    public void setMskKbnNames(String[] mskKbnNames) {
        this.mskKbnNames = mskKbnNames;
    }

    /**
     * �Z�b�V�����p�\�������ő包��
     *
     * @return the page
     */
    public int getPage() {
        return page;
    }

    /**
     * �Z�b�V�����p�\�������ő包��
     *
     * @param page the page to set
     */
    public void setPage(int page) {
        this.page = page;
    }

    /**
     * �y�[�W�J�ڗp�F���ڈړ��Œ�l
     *
     * @return the pageBegin
     */
    public int getPageBegin() {
        return pageBegin;
    }

    /**
     * �y�[�W�J�ڗp�F���ڈړ��Œ�l
     *
     * @param pageBegin the pageBegin to set
     */
    public void setPageBegin(int pageBegin) {
        this.pageBegin = pageBegin;
    }

    /**
     * �y�[�W�J�ڗp�F���ڈړ��ő�l
     *
     * @return the pageEnd
     */
    public int getPageEnd() {
        return pageEnd;
    }

    /**
     * �y�[�W�J�ڗp�F���ڈړ��ő�l
     *
     * @param pageEnd the pageEnd to set
     */
    public void setPageEnd(int pageEnd) {
        this.pageEnd = pageEnd;
    }

    /**
     * �y�[�W�J�ڗp�F�ő�y�[�W��
     *
     * @return the pageMax
     */
    public int getPageMax() {
        return pageMax;
    }

    /**
     * �y�[�W�J�ڗp�F�ő�y�[�W��
     *
     * @param pageMax the pageMax to set
     */
    public void setPageMax(int pageMax) {
        this.pageMax = pageMax;
    }

    /**
     * �Z�b�V�����p�\�������J�n
     *
     * @return the firstDisp
     */
    public int getFirstDisp() {
        return firstDisp;
    }

    /**
     * �Z�b�V�����p�\�������J�n
     *
     * @param firstDisp the firstDisp to set
     */
    public void setFirstDisp(int firstDisp) {
        this.firstDisp = firstDisp;
    }

    /**
     * �Z�b�V�����p�\�������ő包��
     *
     * @return the maxDisp
     */
    public int getMaxDisp() {
        return maxDisp;
    }

    /**
     * �Z�b�V�����p�\�������ő包��
     *
     * @param maxDisp the maxDisp to set
     */
    public void setMaxDisp(int maxDisp) {
        this.maxDisp = maxDisp;
    }

    public void setGazoDetailList(List<GazoKanriJoho> gazoDetailList) {
        this.gazoDetailList = gazoDetailList;
    }

    public List<GazoKanriJoho> getGazoDetailList() {
        return gazoDetailList;
    }

    /**
     * ��������
     *
     * @return the dispKeyList
     */
    public List<String> getDispKeyList() {
        return dispKeyList;
    }

    /**
     * ��������
     *
     * @param dispKeyList the dispKeyList to set
     */
    public void setDispKeyList(List<String> dispKeyList) {
        this.dispKeyList = dispKeyList;
    }

    /**
     * ��������index���X�g
     *
     * @return the searchOutList
     */
    public List<GazoKanriJoho> getSearchOutList() {
        return searchOutList;
    }

    /**
     * ��������index���X�g
     *
     * @param searchOutList the searchOutList to set
     */
    public void setSearchOutList(List<GazoKanriJoho> searchOutList) {
        this.searchOutList = searchOutList;
    }

    /**
     * @return the kaojashinSearchKekkaBack
     */
    public String getKaojashinSearchKekkaBack() {
        return kaojashinSearchKekkaBack;
    }

    /**
     * @param kaojashinSearchKekkaBack the kaojashinSearchKekkaBack to set
     */
    public void setKaojashinSearchKekkaBack(String kaojashinSearchKekkaBack) {
        this.kaojashinSearchKekkaBack = kaojashinSearchKekkaBack;
    }

    /**
     * @return the kaojashinSearchKekkaUpd
     */
    public String getKaojashinSearchKekkaUpd() {
        return kaojashinSearchKekkaUpd;
    }

    /**
     * @param kaojashinSearchKekkaUpd the kaojashinSearchKekkaUpd to set
     */
    public void setKaojashinSearchKekkaUpd(String kaojashinSearchKekkaUpd) {
        this.kaojashinSearchKekkaUpd = kaojashinSearchKekkaUpd;
    }

    /**
     * @return the chkOkng
     */
    public String[] getChkOkng() {
        return chkOkng;
    }

    /**
     * @param chkOkng the chkOkng to set
     */
    public void setChkOkng(String[] chkOkng) {
        this.chkOkng = chkOkng;
    }

    public DiskFileItem getGazoChoice() {
        return gazoChoice;
    }

    public void setGazoChoice(DiskFileItem gazoChoice) {
        this.gazoChoice = gazoChoice;
    }

    public String getGazoPreview() {
        return gazoPreview;
    }

    public void setGazoPreview(String gazoPreview) {
        this.gazoPreview = gazoPreview;
    }

    public String getGazoChoiceBack() {
        return gazoChoiceBack;
    }

    public void setGazoChoiceBack(String gazoChoiceBack) {
        this.gazoChoiceBack = gazoChoiceBack;
    }

    public String getGazoChoiceGazoDl() {
        return gazoChoiceGazoDl;
    }

    public void setGazoChoiceGazoDl(String gazoChoiceGazoDl) {
        this.gazoChoiceGazoDl = gazoChoiceGazoDl;
    }

    public String getGazoChoiceGazoUpd() {
        return gazoChoiceGazoUpd;
    }

    public void setGazoChoiceGazoUpd(String gazoChoiceGazoUpd) {
        this.gazoChoiceGazoUpd = gazoChoiceGazoUpd;
    }

    public String getGazoUl() {
        return gazoUl;
    }

    public void setGazoUl(String gazoUl) {
        this.gazoUl = gazoUl;
    }

    public String getGazoKakuninBack() {
        return gazoKakuninBack;
    }

    public void setGazoKakuninBack(String gazoKakuninBack) {
        this.gazoKakuninBack = gazoKakuninBack;
    }

    /**
     * @return the gazoShosai
     */
    public String getGazoShosai() {
        return gazoShosai;
    }

    /**
     * @param gazoShosai the gazoShosai to set
     */
    public void setGazoShosai(String gazoShosai) {
        this.gazoShosai = gazoShosai;
    }

    /**
     * @return the shinsaKekkaNames
     */
    public String[] getShinsaKekkaNames() {
        return shinsaKekkaNames;
    }

    /**
     * @param shinsaKekkaNames the shinsaKekkaNames to set
     */
    public void setShinsaKekkaNames(String[] shinsaKekkaNames) {
        this.shinsaKekkaNames = shinsaKekkaNames;
    }

    /**
     * @return the sknksuKbn
     */
    public String getSknksuKbn() {
        return sknksuKbn;
    }

    /**
     * @param sknksuKbn the sknksuKbn to set
     */
    public void setSknksuKbn(String sknksuKbn) {
        this.sknksuKbn = sknksuKbn;
    }

    /**
     * @return the sknName
     */
    public String getSknName() {
        return sknName;
    }

    /**
     * @param sknName the sknName to set
     */
    public void setSknName(String sknName) {
        this.sknName = sknName;
    }

    /**
     * @return the ksuName
     */
    public String getKsuName() {
        return ksuName;
    }

    /**
     * @param ksuName the ksuName to set
     */
    public void setKsuName(String ksuName) {
        this.ksuName = ksuName;
    }

    public String getGazoUlKakunin() {
        return gazoUlKakunin;
    }

    public void setGazoUlKakunin(String gazoUlKakunin) {
        this.gazoUlKakunin = gazoUlKakunin;
    }

    /**
     * @return the ksuKbnList
     */
    public List<Option> getKsuKbnList() {
        return ksuKbnList;
    }

    /**
     * @param ksuKbnList the ksuKbnList to set
     */
    public void setKsuKbnList(List<Option> ksuKbnList) {
        this.ksuKbnList = ksuKbnList;
    }

    /**
     * @return the sknKbnList
     */
    public List<Option> getSknKbnList() {
        return sknKbnList;
    }

    /**
     * @param sknKbnList the sknKbnList to set
     */
    public void setSknKbnList(List<Option> sknKbnList) {
        this.sknKbnList = sknKbnList;
    }

    /**
     * @return the gazoKbnList
     */
    public List<Option> getGazoKbnList() {
        return gazoKbnList;
    }

    /**
     * @param gazoKbnList the gazoKbnList to set
     */
    public void setGazoKbnList(List<Option> gazoKbnList) {
        this.gazoKbnList = gazoKbnList;
    }

    /**
     * @return the hoseiIraiKbnList
     */
    public List<Option> getHoseiIraiKbnList() {
        return hoseiIraiKbnList;
    }

    /**
     * @param hoseiIraiKbnList the hoseiIraiKbnList to set
     */
    public void setHoseiIraiKbnList(List<Option> hoseiIraiKbnList) {
        this.hoseiIraiKbnList = hoseiIraiKbnList;
    }

    /**
     * @return the moshikomiKbnList
     */
    public List<Option> getMoshikomiKbnList() {
        return moshikomiKbnList;
    }

    /**
     * @param moshikomiKbnList the moshikomiKbnList to set
     */
    public void setMoshikomiKbnList(List<Option> moshikomiKbnList) {
        this.moshikomiKbnList = moshikomiKbnList;
    }

    /**
     * @return the kojinDantaiKbnList
     */
    public List<Option> getKojinDantaiKbnList() {
        return kojinDantaiKbnList;
    }

    /**
     * @param kojinDantaiKbnList the kojinDantaiKbnList to set
     */
    public void setKojinDantaiKbnList(List<Option> kojinDantaiKbnList) {
        this.kojinDantaiKbnList = kojinDantaiKbnList;
    }

    /**
     * @return the inpClear
     */
    public String getInpClear() {
        return inpClear;
    }

    /**
     * @param inpClear the inpClear to set
     */
    public void setInpClear(String inpClear) {
        this.inpClear = inpClear;
    }

    /**
     * @return the scrollPlace
     */
    public String getScrollPlace() {
        return scrollPlace;
    }

    /**
     * @param scrollPlace the scrollPlace to set
     */
    public void setScrollPlace(String scrollPlace) {
        this.scrollPlace = scrollPlace;
    }

    /**
     * @return the gazo_idx
     */
    public String getGazo_idx() {
        return gazo_idx;
    }

    /**
     * @param gazo_idx the gazo_idx to set
     */
    public void setGazo_idx(String gazo_idx) {
        this.gazo_idx = gazo_idx;
    }

    /**
     * @return the seq
     */
    public String getSeq() {
        return seq;
    }

    /**
     * @param seq the seq to set
     */
    public void setSeq(String seq) {
        this.seq = seq;
    }

    /**
     * @return the shimei
     */
    public String getShimei() {
        return shimei;
    }

    /**
     * @param shimei the shimei to set
     */
    public void setShimei(String shimei) {
        this.shimei = shimei;
    }

    /**
     * @return the mskKbn
     */
    public String getMskKbn() {
        return mskKbn;
    }

    /**
     * @param mskKbn the mskKbn to set
     */
    public void setMskKbn(String mskKbn) {
        this.mskKbn = mskKbn;
    }

    /**
     * @return the gazoStatusChoice
     */
    public String getGazoStatusChoice() {
        return gazoStatusChoice;
    }

    /**
     * @param gazoStatusChoice the gazoStatusChoice to set
     */
    public void setGazoStatusChoice(String gazoStatusChoice) {
        this.gazoStatusChoice = gazoStatusChoice;
    }

    /**
     * @return the shubetsuCode
     */
    public String getShubetsuCode() {
        return shubetsuCode;
    }

    /**
     * @param shubetsuCode the shubetsuCode to set
     */
    public void setShubetsuCode(String shubetsuCode) {
        this.shubetsuCode = shubetsuCode;
    }

    /**
     * @return the kaisuCode
     */
    public String getKaisuCode() {
        return kaisuCode;
    }

    /**
     * @param kaisuCode the kaisuCode to set
     */
    public void setKaisuCode(String kaisuCode) {
        this.kaisuCode = kaisuCode;
    }

    /**
     * @return the sknKsuCode
     */
    public String getSknKsuCode() {
        return sknKsuCode;
    }

    /**
     * @param sknKsuCode the sknKsuCode to set
     */
    public void setSknKsuCode(String sknKsuCode) {
        this.sknKsuCode = sknKsuCode;
    }

    /**
     * @return the kojinDantaiKbn
     */
    public String getKojinDantaiKbn() {
        return kojinDantaiKbn;
    }

    /**
     * @param kojinDantaiKbn the kojinDantaiKbn to set
     */
    public void setKojinDantaiKbn(String kojinDantaiKbn) {
        this.kojinDantaiKbn = kojinDantaiKbn;
    }

    /**
     * @return the kojinDantaiChi
     */
    public String getKojinDantaiChi() {
        return kojinDantaiChi;
    }

    /**
     * @param kojinDantaiChi the kojinDantaiChi to set
     */
    public void setKojinDantaiChi(String kojinDantaiChi) {
        this.kojinDantaiChi = kojinDantaiChi;
    }

    /**
     * @return the yusounetKbn
     */
    public String getYusounetKbn() {
        return yusounetKbn;
    }

    /**
     * @param yusounetKbn the yusounetKbn to set
     */
    public void setYusounetKbn(String yusounetKbn) {
        this.yusounetKbn = yusounetKbn;
    }

    /**
     * @return the yusounetChi
     */
    public String getYusounetChi() {
        return yusounetChi;
    }

    /**
     * @param yusounetChi the yusounetChi to set
     */
    public void setYusounetChi(String yusounetChi) {
        this.yusounetChi = yusounetChi;
    }

    /**
     * @return the gazoStatusChi
     */
    public String getGazoStatusChi() {
        return gazoStatusChi;
    }

    /**
     * @param gazoStatusChi the gazoStatusChi to set
     */
    public void setGazoStatusChi(String gazoStatusChi) {
        this.gazoStatusChi = gazoStatusChi;
    }

    /**
     * @return the CommandPage
     */
    public String getCommandPage() {
        return CommandPage;
    }

    /**
     * @param CommandPage the CommandPage to set
     */
    public void setCommandPage(String CommandPage) {
        this.CommandPage = CommandPage;
    }

    /**
     * @return the searchFlg
     */
    public String getSearchFlg() {
        return searchFlg;
    }

    /**
     * @param searchFlg the searchFlg to set
     */
    public void setSearchFlg(String searchFlg) {
        this.searchFlg = searchFlg;
    }

    /**
     * @return the index
     */
    public String getIndex() {
        return index;
    }

    /**
     * @param index the index to set
     */
    public void setIndex(String index) {
        this.index = index;
    }

    /**
     * @return the koshin_date
     */
    public String getKoshin_date() {
        return koshin_date;
    }

    /**
     * @param koshin_date the koshin_date to set
     */
    public void setKoshin_date(String koshin_date) {
        this.koshin_date = koshin_date;
    }

    /**
     * @return the koshin_time
     */
    public String getKoshin_time() {
        return koshin_time;
    }

    /**
     * @param koshin_time the koshin_time to set
     */
    public void setKoshin_time(String koshin_time) {
        this.koshin_time = koshin_time;
    }

    /**
     * @return the listKoshin_date
     */
    public String getListKoshin_date() {
        return listKoshin_date;
    }

    /**
     * @param listKoshin_date the listKoshin_date to set
     */
    public void setListKoshin_date(String listKoshin_date) {
        this.listKoshin_date = listKoshin_date;
    }

    /**
     * @return the listKoshin_time
     */
    public String getListKoshin_time() {
        return listKoshin_time;
    }

    /**
     * @param listKoshin_time the listKoshin_time to set
     */
    public void setListKoshin_time(String listKoshin_time) {
        this.listKoshin_time = listKoshin_time;
    }

    /**
     * @return the gazoKbn
     */
    public String getGazoKbn() {
        return gazoKbn;
    }

    /**
     * @param gazoKbn the gazoKbn to set
     */
    public void setGazoKbn(String gazoKbn) {
        this.gazoKbn = gazoKbn;
    }

    /**
     * @return the chkOkngValue
     */
    public String[] getChkOkngValue() {
        return chkOkngValue;
    }

    /**
     * @param chkOkngValue the chkOkngValue to set
     */
    public void setChkOkngValue(String[] chkOkngValue) {
        this.chkOkngValue = chkOkngValue;
    }

    /**
     * @return the nenrei
     */
    public String getNenrei() {
        return nenrei;
    }

    /**
     * @param nenrei the nenrei to set
     */
    public void setNenrei(String nenrei) {
        this.nenrei = nenrei;
    }

    /**
     * @return the fubiRiyu1
     */
    public String getFubiRiyu1() {
        return fubiRiyu1;
    }

    /**
     * @param fubiRiyu1 the fubiRiyu1 to set
     */
    public void setFubiRiyu1(String fubiRiyu1) {
        this.fubiRiyu1 = fubiRiyu1;
    }

    /**
     * @return the fubiRiyu2
     */
    public String getFubiRiyu2() {
        return fubiRiyu2;
    }

    /**
     * @param fubiRiyu2 the fubiRiyu2 to set
     */
    public void setFubiRiyu2(String fubiRiyu2) {
        this.fubiRiyu2 = fubiRiyu2;
    }

    /**
     * @return the fubiRiyu3
     */
    public String getFubiRiyu3() {
        return fubiRiyu3;
    }

    /**
     * @param fubiRiyu3 the fubiRiyu3 to set
     */
    public void setFubiRiyu3(String fubiRiyu3) {
        this.fubiRiyu3 = fubiRiyu3;
    }

    /**
     * @return the genmen
     */
    public String getGenmen() {
        return genmen;
    }

    /**
     * @param genmen the genmen to set
     */
    public void setGenmen(String genmen) {
        this.genmen = genmen;
    }

    /**
     * @return the birthday
     */
    public String getBirthday() {
        return birthday;
    }

    /**
     * @param birthday the birthday to set
     */
    public void setBirthday(String birthday) {
        this.birthday = birthday;
    }

    /**
     * @return the fubiRiyuList
     */
    public List<String> getFubiRiyuList() {
        return fubiRiyuList;
    }

    /**
     * @param fubiRiyuList the fubiRiyuList to set
     */
    public void setFubiRiyuList(List<String> fubiRiyuList) {
        this.fubiRiyuList = fubiRiyuList;
    }

    /**
     * @return the fubiRiyuCodes
     */
    public List<Option> getFubiRiyuCodes() {
        return fubiRiyuCodes;
    }

    /**
     * @param fubiRiyuCodes the fubiRiyuCodes to set
     */
    public void setFubiRiyuCodes(List<Option> fubiRiyuCodes) {
        this.fubiRiyuCodes = fubiRiyuCodes;
    }

    /**
     * @return the gazoKanrenJoho3rd
     */
    public String getGazoKanrenJoho3rd() {
        return gazoKanrenJoho3rd;
    }

    /**
     * @param gazoKanrenJoho3rd the gazoKanrenJoho3rd to set
     */
    public void setGazoKanrenJoho3rd(String gazoKanrenJoho3rd) {
        this.gazoKanrenJoho3rd = gazoKanrenJoho3rd;
    }

    /**
     * @return the gazoKanrenJoho4td
     */
    public String getGazoKanrenJoho4td() {
        return gazoKanrenJoho4td;
    }

    /**
     * @param gazoKanrenJoho4td the gazoKanrenJoho4td to set
     */
    public void setGazoKanrenJoho4td(String gazoKanrenJoho4td) {
        this.gazoKanrenJoho4td = gazoKanrenJoho4td;
    }

    /**
     * @return the gazoKanrenJoho5td
     */
    public String getGazoKanrenJoho5td() {
        return gazoKanrenJoho5td;
    }

    /**
     * @param gazoKanrenJoho5td the gazoKanrenJoho5td to set
     */
    public void setGazoKanrenJoho5td(String gazoKanrenJoho5td) {
        this.gazoKanrenJoho5td = gazoKanrenJoho5td;
    }

    /**
     * @return the gazoKanrenJoho6td
     */
    public String getGazoKanrenJoho6td() {
        return gazoKanrenJoho6td;
    }

    /**
     * @param gazoKanrenJoho6td the gazoKanrenJoho6td to set
     */
    public void setGazoKanrenJoho6td(String gazoKanrenJoho6td) {
        this.gazoKanrenJoho6td = gazoKanrenJoho6td;
    }

    /**
     * @return the gazoKanrenKomoku3rd
     */
    public String getGazoKanrenKomoku3rd() {
        return gazoKanrenKomoku3rd;
    }

    /**
     * @param gazoKanrenKomoku3rd the gazoKanrenKomoku3rd to set
     */
    public void setGazoKanrenKomoku3rd(String gazoKanrenKomoku3rd) {
        this.gazoKanrenKomoku3rd = gazoKanrenKomoku3rd;
    }

    /**
     * @return the gazoKanrenKomoku4td
     */
    public String getGazoKanrenKomoku4td() {
        return gazoKanrenKomoku4td;
    }

    /**
     * @param gazoKanrenKomoku4td the gazoKanrenKomoku4td to set
     */
    public void setGazoKanrenKomoku4td(String gazoKanrenKomoku4td) {
        this.gazoKanrenKomoku4td = gazoKanrenKomoku4td;
    }

    /**
     * @return the gazoKanrenJoho7td
     */
    public String getGazoKanrenJoho7td() {
        return gazoKanrenJoho7td;
    }

    /**
     * @param gazoKanrenJoho7td the gazoKanrenJoho7td to set
     */
    public void setGazoKanrenJoho7td(String gazoKanrenJoho7td) {
        this.gazoKanrenJoho7td = gazoKanrenJoho7td;
    }

    /**
     * @return the gazoKanrenJoho8td
     */
    public String getGazoKanrenJoho8td() {
        return gazoKanrenJoho8td;
    }

    /**
     * @param gazoKanrenJoho8td the gazoKanrenJoho8td to set
     */
    public void setGazoKanrenJoho8td(String gazoKanrenJoho8td) {
        this.gazoKanrenJoho8td = gazoKanrenJoho8td;
    }

    /**
     * @return the nendo
     */
    public String getNendo() {
        return nendo;
    }

    /**
     * @param nendo the nendo to set
     */
    public void setNendo(String nendo) {
        this.nendo = nendo;
    }

    /**
     * @return the shokurekiList
     */
    public List<String> getShokurekiList() {
        return shokurekiList;
    }

    /**
     * @param shokurekiList the shokurekiList to set
     */
    public void setShokurekiList(List<String> shokurekiList) {
        this.shokurekiList = shokurekiList;
    }

    /**
     * @return the kunrenList
     */
    public List<String> getKunrenList() {
        return kunrenList;
    }

    /**
     * @param kunrenList the kunrenList to set
     */
    public void setKunrenList(List<String> kunrenList) {
        this.kunrenList = kunrenList;
    }

    /**
     * @return the fubiAriCodes
     */
    public List<Option> getFubiAriCodes() {
        return fubiAriCodes;
    }

    /**
     * @param fubiAriCodes the fubiAriCodes to set
     */
    public void setFubiAriCodes(List<Option> fubiAriCodes) {
        this.fubiAriCodes = fubiAriCodes;
    }

    /**
     * @return the shinseiShikakuNo
     */
    public String getShinseiShikakuNo() {
        return shinseiShikakuNo;
    }

    /**
     * @param shinseiShikakuNo the shinseiShikakuNo to set
     */
    public void setShinseiShikakuNo(String shinseiShikakuNo) {
        this.shinseiShikakuNo = shinseiShikakuNo;
    }

    /**
     * @return the shinseiMenjoNo
     */
    public String getShinseiMenjoNo() {
        return shinseiMenjoNo;
    }

    /**
     * @param shinseiMenjoNo the shinseiMenjoNo to set
     */
    public void setShinseiMenjoNo(String shinseiMenjoNo) {
        this.shinseiMenjoNo = shinseiMenjoNo;
    }

    /**
     * @return the gazoShosaiList
     */
    public List<GazoKanriJoho> getGazoShosaiList() {
        return gazoShosaiList;
    }

    /**
     * @param gazoShosaiList the gazoShosaiList to set
     */
    public void setGazoShosaiList(List<GazoKanriJoho> gazoShosaiList) {
        this.gazoShosaiList = gazoShosaiList;
    }

    /**
     * @return the shikakuCode
     */
    public String getShikakuCode() {
        return shikakuCode;
    }

    /**
     * @param shikakuCode the shikakuCode to set
     */
    public void setShikakuCode(String shikakuCode) {
        this.shikakuCode = shikakuCode;
    }

    /**
     * @return the menjoCode
     */
    public String getMenjoCode() {
        return menjoCode;
    }

    /**
     * @param menjoCode the menjoCode to set
     */
    public void setMenjoCode(String menjoCode) {
        this.menjoCode = menjoCode;
    }

    /**
     * @return the hoseiIraiKbn
     */
    public String getHoseiIraiKbn() {
        return hoseiIraiKbn;
    }

    /**
     * @param hoseiIraiKbn the hoseiIraiKbn to set
     */
    public void setHoseiIraiKbn(String hoseiIraiKbn) {
        this.hoseiIraiKbn = hoseiIraiKbn;
    }

    /**
     * @return the gazoHyojiKbn
     */
    public String getGazoHyojiKbn() {
        return gazoHyojiKbn;
    }

    /**
     * @param gazoHyojiKbn the gazoHyojiKbn to set
     */
    public void setGazoHyojiKbn(String gazoHyojiKbn) {
        this.gazoHyojiKbn = gazoHyojiKbn;
    }

    /**
     * @return the moshikomishaId
     */
    public String getMoshikomishaId() {
        return moshikomishaId;
    }

    /**
     * @param moshikomishaId the moshikomishaId to set
     */
    public void setMoshikomishaId(String moshikomishaId) {
        this.moshikomishaId = moshikomishaId;
    }

    /**
     * @return the gazo_idxs
     */
    public String[] getGazo_idxs() {
        return gazo_idxs;
    }

    /**
     * @param gazo_idxs the gazo_idxs to set
     */
    public void setGazo_idxs(String[] gazo_idxs) {
        this.gazo_idxs = gazo_idxs;
    }

    /**
     * @return the uketukeNos
     */
    public String[] getUketukeNos() {
        return uketukeNos;
    }

    /**
     * @param uketukeNos the uketukeNos to set
     */
    public void setUketukeNos(String[] uketukeNos) {
        this.uketukeNos = uketukeNos;
    }

    /**
     * @return the gazoUlSeq
     */
    public String getGazoUlSeq() {
        return gazoUlSeq;
    }

    /**
     * @param gazoUlSeq the gazoUlSeq to set
     */
    public void setGazoUlSeq(String gazoUlSeq) {
        this.gazoUlSeq = gazoUlSeq;
    }

    /**
     * @return the fileItem
     */
    public FileItem getFileItem() {
        return fileItem;
    }

    /**
     * @param fileItem the fileItem to set
     */
    public void setFileItem(FileItem fileItem) {
        this.fileItem = fileItem;
    }

    /**
     * @return the torokuCheck
     */
    public String getTorokuCheck() {
        return torokuCheck;
    }

    /**
     * @param torokuCheck the torokuCheck to set
     */
    public void setTorokuCheck(String torokuCheck) {
        this.torokuCheck = torokuCheck;
    }

    /**
     * @return the seniFlg
     */
    public String getSeniFlg() {
        return seniFlg;
    }

    /**
     * @param seniFlg the seniFlg to set
     */
    public void setSeniFlg(String seniFlg) {
        this.seniFlg = seniFlg;
    }

    /**
     * @return the fileKbn
     */
    public String getFileKbn() {
        return fileKbn;
    }

    /**
     * @param fileKbn the fileKbn to set
     */
    public void setFileKbn(String fileKbn) {
        this.fileKbn = fileKbn;
    }

    /**
     * @return the urls
     */
    public String[] getUrls() {
        return urls;
    }

    /**
     * @param urls the urls to set
     */
    public void setUrls(String[] urls) {
        this.urls = urls;
    }

    /**
     * @return the tagPath
     */
    public String getTagPath() {
        return tagPath;
    }

    /**
     * @param tagPath the tagPath to set
     */
    public void setTagPath(String tagPath) {
        this.tagPath = tagPath;
    }
    
    /**
     * @return the gazoUlBack
     */
    public String getGazoUlBack() {
        return gazoUlBack;
    }

    /**
     * @param gazoUlBack the gazoUlBack to set
     */
    public void setGazoUlBack(String gazoUlBack) {
        this.gazoUlBack = gazoUlBack;
    }
    
    
    /**
     * @return the hoseiKigenBi
     */
    public String getHoseiKigenBi() {
        return hoseiKigenBi;
    }

    /**
     * @param hoseiKigenBi the hoseiKigenBi to set
     */
    public void setHoseiKigenBi(String hoseiKigenBi) {
        this.hoseiKigenBi = hoseiKigenBi;
    }
    
    /**
     * @return the gazoUpd
     */
    public String getGazoUpd() {
        return gazoUpd;
    }

    /**
     * @param gazoUpd the gazoUpd to set
     */
    public void setGazoUpd(String gazoUpd) {
        this.gazoUpd = gazoUpd;
    }
    
    
    /**
     * @return the uploadCheck
     */
    public String getUploadCheck() {
        return uploadCheck;
    }

    /**
     * @param uploadCheck the uploadCheck to set
     */
    public void setUploadCheck(String uploadCheck) {
        this.uploadCheck = uploadCheck;
    }
    
    
    /**
     * @return the shosaiUketukeNo
     */
    public String getShosaiUketukeNo() {
        return shosaiUketukeNo;
    }

    /**
     * @param shosaiUketukeNo the shosaiUketukeNo to set
     */
    public void setShosaiUketukeNo(String shosaiUketukeNo) {
        this.shosaiUketukeNo = shosaiUketukeNo;
    }

    /**
     * @return the shosaiJknJkuNo
     */
    public String getShosaiJknJkuNo() {
        return shosaiJknJkuNo;
    }

    /**
     * @param shosaiJknJkuNo the shosaiJknJkuNo to set
     */
    public void setShosaiJknJkuNo(String shosaiJknJkuNo) {
        this.shosaiJknJkuNo = shosaiJknJkuNo;
    }

    /**
     * @return the shosaiFurigana
     */
    public String getShosaiFurigana() {
        return shosaiFurigana;
    }

    /**
     * @param shosaiFurigana the shosaiFurigana to set
     */
    public void setShosaiFurigana(String shosaiFurigana) {
        this.shosaiFurigana = shosaiFurigana;
    }

    /**
     * @return the shosaiShimei
     */
    public String getShosaiShimei() {
        return shosaiShimei;
    }

    /**
     * @param shosaiShimei the shosaiShimei to set
     */
    public void setShosaiShimei(String shosaiShimei) {
        this.shosaiShimei = shosaiShimei;
    }

    /**
     * @return the shosaiSeq
     */
    public String getShosaiSeq() {
        return shosaiSeq;
    }

    /**
     * @param shosaiSeq the shosaiSeq to set
     */
    public void setShosaiSeq(String shosaiSeq) {
        this.shosaiSeq = shosaiSeq;
    }
    
    
    /**
     * @return the shokurekiCnt
     */
    public String getShokurekiCnt() {
        return shokurekiCnt;
    }

    /**
     * @param shokurekiCnt the shokurekiCnt to set
     */
    public void setShokurekiCnt(String shokurekiCnt) {
        this.shokurekiCnt = shokurekiCnt;
    }

    /**
     * @return the gakurekiCnt
     */
    public String getGakurekiCnt() {
        return gakurekiCnt;
    }

    /**
     * @param gakurekiCnt the gakurekiCnt to set
     */
    public void setGakurekiCnt(String gakurekiCnt) {
        this.gakurekiCnt = gakurekiCnt;
    }
    

    /**
     * @return the kunrenShosaiList
     */
    public List<GazoKanriJoho> getKunrenShosaiList() {
        return kunrenShosaiList;
    }

    /**
     * @param kunrenShosaiList the kunrenShosaiList to set
     */
    public void setKunrenShosaiList(List<GazoKanriJoho> kunrenShosaiList) {
        this.kunrenShosaiList = kunrenShosaiList;
    }
    
    
    /**
     * @return the gakurekiShosaiList
     */
    public List<GazoKanriJoho> getGakurekiShosaiList() {
        return gakurekiShosaiList;
    }

    /**
     * @param gakurekiShosaiList the gakurekiShosaiList to set
     */
    public void setGakurekiShosaiList(List<GazoKanriJoho> gakurekiShosaiList) {
        this.gakurekiShosaiList = gakurekiShosaiList;
    }
    
    
    /**
     * @return the gazoKbnChi
     */
    public String getGazoKbnChi() {
        return gazoKbnChi;
    }

    /**
     * @param gazoKbnChi the gazoKbnChi to set
     */
    public void setGazoKbnChi(String gazoKbnChi) {
        this.gazoKbnChi = gazoKbnChi;
    }
    
    
    /**
     * @return the okngList
     */
    public List<String> getOkngList() {
        return okngList;
    }

    /**
     * @param okngList the okngList to set
     */
    public void setOkngList(List<String> okngList) {
        this.okngList = okngList;
    }

    /**
     * @return the hoseiKigen
     */
    public String getHoseiKigen() {
        return hoseiKigen;
    }

    /**
     * @param hoseiKigen the hoseiKigen to set
     */
    public void setHoseiKigen(String hoseiKigen) {
        this.hoseiKigen = hoseiKigen;
    }

}
