package jp.co.nii.bma.business.rto.manager;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import jp.co.nii.bma.business.domain.KaijoMst;
import jp.co.nii.sew.presentation.AbstractRequestTransferObject;
import jp.co.nii.sew.presentation.Messages;
import jp.co.nii.sew.presentation.Option;

/**
 * �^�C�g��: TOP��� ����: TOP���RTO ���쌠: Copyright (c) 2020 ��Ж�: ���{���Y�Ɗ������
 */
public class MstKanriKaijoTantoJoho  extends AbstractRequestTransferObject {
    private Messages errors;
    private Map<Option,Messages> errorJohoMaps;
    private String moshikomishaId;

    /* �{�^���J�� */
    // �}�X�^�Ǘ����
    private String kaijoTantoshaMstTable;
    // ���S���҃}�X�^�������
    private String kaijoTantoSearchResult;
    private String kaijoTantoDetail;
    private String kaijoTantoShinkiInput;
    private String kaijoTantoSearchBack;
    // ���S���҃}�X�^�V�K�o�^���
    private String kaisaichiChange;
    private String kaijoTantoInpConf;
    private String kaijoTantoInpBack;
    // ���S���҃}�X�^�V�K�o�^�m�F���
    private String kaijoTantoInpComp;
    private String kaijoTantoInpConfBack;
    // ���S���҃}�X�^�V�K�o�^�������
    private String kaijoTantoInpCompBack;
    // ���S���҃}�X�^�ڍ׉��
    private String kaijoTantoUpdInput;
    private String kaijoTantoDetailBack;
    // ���S���҃}�X�^�ύX���͉��
    private String kaijoTantoUpdConf;
    private String kaijoTantoUpdInputBack;
    // ���S���҃}�X�^�ύX�m�F���
    private String kaijoTantoUpdComp;
    private String kaijoTantoUpdConfBack;
    // ���S���҃}�X�^�X�V�������
    private String kaijoTantoUpdCompBack;

    /* ���S���҃}�X�^�f�[�^ */
    private String kaisaichiCode;
    private String kaijoCode;
    private String tantoshaCode;
    private String tantosha;
    private String tantoBusho;
    private String telNo;
    private String faxNo;
    private String tantoshaMailAddress;
    private String biko;
    private String bikoDisp;

    /* ������ʁ@�y�[�W���� */
    private int pageMax;
    private int page;
    private int maxDisp;
    private int firstDisp;
    private int pageBegin;
    private int pageEnd;
    private String CommandPage;
    private String pageIndex;

    private List<Option> kaisaichiList;
    private String[] kaisaichiSelect;
    private String kaisaichiName;
    private List<KaijoMst> kaijoList;
    private String kaijoName;
    private List<Option> kaijoByKaisaichiList;
    private List<MstKanriKaijoTantoJoho> tantoResultList;
    private List<MstKanriKaijoTantoJoho> tantoDisplayList;
    private String tantoSrcListFlg;

    /**
     * �R���X�g���N�^
     */
    public MstKanriKaijoTantoJoho() {
        clearInfo();
    }

    /**
     * ���������\�b�h
     */
    public void clearInfo() {
        String initKaisaichi[] = {""};
        
        setErrors(new Messages());
        setErrorJohoMaps(new HashMap<Option,Messages>());
        setMoshikomishaId("");

        setKaijoTantoshaMstTable("");
        setKaijoTantoSearchResult("");
        setKaijoTantoDetail("");
        setKaijoTantoShinkiInput("");
        setKaijoTantoSearchBack("");
        setKaisaichiChange("");
        setKaijoTantoInpConf("");
        setKaijoTantoInpBack("");
        setKaijoTantoInpComp("");
        setKaijoTantoInpConfBack("");
        setKaijoTantoInpCompBack("");
        setKaijoTantoUpdInput("");
        setKaijoTantoDetailBack("");
        setKaijoTantoUpdConf("");
        setKaijoTantoUpdInputBack("");
        setKaijoTantoUpdComp("");
        setKaijoTantoUpdConfBack("");
        setKaijoTantoUpdCompBack("");

        setKaisaichiCode("");
        setKaijoCode("");
        setTantoshaCode("");
        setTantosha("");
        setTantoBusho("");
        setTelNo("");
        setFaxNo("");
        setTantoshaMailAddress("");
        setBiko("");
        setBikoDisp("");

        setFirstDisp(0);
        setMaxDisp(0);
        setPage(0);
        setPageBegin(0);
        setPageEnd(0);
        setPageMax(0);
        setCommandPage("");
        setPageIndex("");

        setKaisaichiList(new ArrayList<Option>());
        setKaisaichiSelect(initKaisaichi);
        setKaisaichiName("");
        setKaijoList(new ArrayList<KaijoMst>());
        setKaijoName("");
        setKaijoByKaisaichiList(new ArrayList<Option>());
        setTantoResultList(new ArrayList<MstKanriKaijoTantoJoho>());
        setTantoDisplayList(new ArrayList<MstKanriKaijoTantoJoho>());
        setTantoSrcListFlg("");
    }

    /**
     * ���N�G�X�g��������擾���郁�\�b�h
     *
     * @param request ���N�G�X�g
     */
    @Override
    public void copyFromRequest(HttpServletRequest request) {
        setKaijoTantoshaMstTable((String) request.getAttribute("kaijoTantoshaMstTable"));
        setKaijoTantoSearchResult((String) request.getAttribute("kaijoTantoSearchResult"));
        setKaijoTantoDetail((String) request.getAttribute("kaijoTantoDetail"));
        setKaijoTantoShinkiInput((String) request.getAttribute("kaijoTantoShinkiInput"));
        setKaijoTantoSearchBack((String) request.getAttribute("kaijoTantoSearchBack"));
        setKaisaichiChange((String) request.getAttribute("kaisaichiChange"));
        setKaijoTantoInpConf((String) request.getAttribute("kaijoTantoInpConf"));
        setKaijoTantoInpBack((String) request.getAttribute("kaijoTantoInpBack"));
        setKaijoTantoInpComp((String) request.getAttribute("kaijoTantoInpComp"));
        setKaijoTantoInpConfBack((String) request.getAttribute("kaijoTantoInpConfBack"));
        setKaijoTantoInpCompBack((String) request.getAttribute("kaijoTantoInpCompBack"));
        setKaijoTantoUpdInput((String) request.getAttribute("kaijoTantoUpdInput"));
        setKaijoTantoDetailBack((String) request.getAttribute("kaijoTantoDetailBack"));
        setKaijoTantoUpdConf((String) request.getAttribute("kaijoTantoUpdConf"));
        setKaijoTantoUpdInputBack((String) request.getAttribute("kaijoTantoUpdInputBack"));
        setKaijoTantoUpdComp((String) request.getAttribute("kaijoTantoUpdComp"));
        setKaijoTantoUpdConfBack((String) request.getAttribute("kaijoTantoUpdConfBack"));
        setKaijoTantoUpdCompBack((String) request.getAttribute("kaijoTantoUpdCompBack"));

        setKaisaichiCode((String) request.getAttribute("kaisaichiCode"));
        setKaijoCode((String) request.getAttribute("kaijoCode"));
        setTantoshaCode((String) request.getAttribute("tantoshaCode"));
        setTantosha((String) request.getAttribute("tantosha"));
        setTantoBusho((String) request.getAttribute("tantoBusho"));
        setTelNo((String) request.getAttribute("telNo"));
        setFaxNo((String) request.getAttribute("faxNo"));
        setTantoshaMailAddress((String) request.getAttribute("tantoshaMailAddress"));
        setBiko((String) request.getAttribute("biko"));

        setCommandPage((String) request.getAttribute("commandPage"));
        setPageIndex((String) request.getAttribute("pageIndex"));

        setKaisaichiList((List<Option>) request.getAttribute("kaisaichiList"));
        setKaisaichiSelect((String[]) request.getParameterValues("kaisaichiSelect"));
        setKaisaichiName((String) request.getAttribute("kaisaichiName"));
        setKaijoList((List<KaijoMst>) request.getAttribute("kaijoList"));
        setKaijoName((String) request.getAttribute("kaijoName"));
        setKaijoByKaisaichiList((List<Option>) request.getAttribute("kaijoByKaisaichiList"));
        setTantoResultList((List<MstKanriKaijoTantoJoho>) request.getAttribute("tantoResultList"));
        setTantoDisplayList((List<MstKanriKaijoTantoJoho>) request.getAttribute("tantoDisplayList"));
        setTantoSrcListFlg((String) request.getAttribute("tantoSrcListFlg"));

        HttpSession session = request.getSession(false);
        if (session.getAttribute("MgrTopJoho") != null) {
            MgrTopJoho tmp = (MgrTopJoho) session.getAttribute("MgrTopJoho");
            setMoshikomishaId((String) tmp.getMoshikomishaId());
        }
    }

    public Messages getErrors() {
        return errors;
    }

    public void setErrors(Messages errors) {
        this.errors = errors;
    }

    public Map<Option, Messages> getErrorJohoMaps() {
        return errorJohoMaps;
    }

    public void setErrorJohoMaps(Map<Option, Messages> errorJohoMaps) {
        this.errorJohoMaps = errorJohoMaps;
    }

    public String getMoshikomishaId() {
        return moshikomishaId;
    }

    public void setMoshikomishaId(String moshikomishaId) {
        this.moshikomishaId = moshikomishaId;
    }

    public String getKaijoTantoshaMstTable() {
        return kaijoTantoshaMstTable;
    }

    public void setKaijoTantoshaMstTable(String kaijoTantoshaMstTable) {
        this.kaijoTantoshaMstTable = kaijoTantoshaMstTable;
    }
    
    public String getKaijoTantoSearchResult() {
        return kaijoTantoSearchResult;
    }

    public void setKaijoTantoSearchResult(String kaijoTantoSearchResult) {
        this.kaijoTantoSearchResult = kaijoTantoSearchResult;
    }

    public String getKaijoTantoDetail() {
        return kaijoTantoDetail;
    }

    public void setKaijoTantoDetail(String kaijoTantoDetail) {
        this.kaijoTantoDetail = kaijoTantoDetail;
    }

    public String getKaijoTantoShinkiInput() {
        return kaijoTantoShinkiInput;
    }

    public void setKaijoTantoShinkiInput(String kaijoTantoShinkiInput) {
        this.kaijoTantoShinkiInput = kaijoTantoShinkiInput;
    }

    public String getKaijoTantoSearchBack() {
        return kaijoTantoSearchBack;
    }

    public void setKaijoTantoSearchBack(String kaijoTantoSearchBack) {
        this.kaijoTantoSearchBack = kaijoTantoSearchBack;
    }

    public String getKaisaichiChange() {
        return kaisaichiChange;
    }

    public void setKaisaichiChange(String kaisaichiChange) {
        this.kaisaichiChange = kaisaichiChange;
    }

    public String getKaijoTantoInpConf() {
        return kaijoTantoInpConf;
    }

    public void setKaijoTantoInpConf(String kaijoTantoInpConf) {
        this.kaijoTantoInpConf = kaijoTantoInpConf;
    }

    public String getKaijoTantoInpBack() {
        return kaijoTantoInpBack;
    }

    public void setKaijoTantoInpBack(String kaijoTantoInpBack) {
        this.kaijoTantoInpBack = kaijoTantoInpBack;
    }

    public String getKaijoTantoInpComp() {
        return kaijoTantoInpComp;
    }

    public void setKaijoTantoInpComp(String kaijoTantoInpComp) {
        this.kaijoTantoInpComp = kaijoTantoInpComp;
    }

    public String getKaijoTantoInpConfBack() {
        return kaijoTantoInpConfBack;
    }

    public void setKaijoTantoInpConfBack(String kaijoTantoInpConfBack) {
        this.kaijoTantoInpConfBack = kaijoTantoInpConfBack;
    }

    public String getKaijoTantoInpCompBack() {
        return kaijoTantoInpCompBack;
    }

    public void setKaijoTantoInpCompBack(String kaijoTantoInpCompBack) {
        this.kaijoTantoInpCompBack = kaijoTantoInpCompBack;
    }

    public String getKaijoTantoUpdInput() {
        return kaijoTantoUpdInput;
    }

    public void setKaijoTantoUpdInput(String kaijoTantoUpdInput) {
        this.kaijoTantoUpdInput = kaijoTantoUpdInput;
    }

    public String getKaijoTantoDetailBack() {
        return kaijoTantoDetailBack;
    }

    public void setKaijoTantoDetailBack(String kaijoTantoDetailBack) {
        this.kaijoTantoDetailBack = kaijoTantoDetailBack;
    }

    public String getKaijoTantoUpdConf() {
        return kaijoTantoUpdConf;
    }

    public void setKaijoTantoUpdConf(String kaijoTantoUpdConf) {
        this.kaijoTantoUpdConf = kaijoTantoUpdConf;
    }

    public String getKaijoTantoUpdInputBack() {
        return kaijoTantoUpdInputBack;
    }

    public void setKaijoTantoUpdInputBack(String kaijoTantoUpdInputBack) {
        this.kaijoTantoUpdInputBack = kaijoTantoUpdInputBack;
    }

    public String getKaijoTantoUpdComp() {
        return kaijoTantoUpdComp;
    }

    public void setKaijoTantoUpdComp(String kaijoTantoUpdComp) {
        this.kaijoTantoUpdComp = kaijoTantoUpdComp;
    }

    public String getKaijoTantoUpdConfBack() {
        return kaijoTantoUpdConfBack;
    }

    public void setKaijoTantoUpdConfBack(String kaijoTantoUpdConfBack) {
        this.kaijoTantoUpdConfBack = kaijoTantoUpdConfBack;
    }

    public String getKaijoTantoUpdCompBack() {
        return kaijoTantoUpdCompBack;
    }

    public void setKaijoTantoUpdCompBack(String kaijoTantoUpdCompBack) {
        this.kaijoTantoUpdCompBack = kaijoTantoUpdCompBack;
    }

    public String getKaisaichiCode() {
        return kaisaichiCode;
    }

    public void setKaisaichiCode(String kaisaichiCode) {
        this.kaisaichiCode = kaisaichiCode;
    }

    public String getKaijoCode() {
        return kaijoCode;
    }

    public void setKaijoCode(String kaijoCode) {
        this.kaijoCode = kaijoCode;
    }

    public String getTantoshaCode() {
        return tantoshaCode;
    }

    public void setTantoshaCode(String tantoshaCode) {
        this.tantoshaCode = tantoshaCode;
    }

    public String getTantosha() {
        return tantosha;
    }

    public void setTantosha(String tantosha) {
        this.tantosha = tantosha;
    }

    public String getTantoBusho() {
        return tantoBusho;
    }

    public void setTantoBusho(String tantoBusho) {
        this.tantoBusho = tantoBusho;
    }

    public String getTelNo() {
        return telNo;
    }

    public void setTelNo(String telNo) {
        this.telNo = telNo;
    }

    public String getFaxNo() {
        return faxNo;
    }

    public void setFaxNo(String faxNo) {
        this.faxNo = faxNo;
    }

    public String getTantoshaMailAddress() {
        return tantoshaMailAddress;
    }

    public void setTantoshaMailAddress(String tantoshaMailAddress) {
        this.tantoshaMailAddress = tantoshaMailAddress;
    }

    public String getBiko() {
        return biko;
    }

    public void setBiko(String biko) {
        this.biko = biko;
    }

    public String getBikoDisp() {
        return bikoDisp;
    }

    public void setBikoDisp(String bikoDisp) {
        this.bikoDisp = bikoDisp;
    }

    public int getPage() {
        return page;
    }

    public void setPage(int page) {
        this.page = page;
    }

    public int getPageBegin() {
        return pageBegin;
    }

    public void setPageBegin(int pageBegin) {
        this.pageBegin = pageBegin;
    }

    public int getPageEnd() {
        return pageEnd;
    }

    public void setPageEnd(int pageEnd) {
        this.pageEnd = pageEnd;
    }

    public int getPageMax() {
        return pageMax;
    }

    public void setPageMax(int pageMax) {
        this.pageMax = pageMax;
    }

    public int getFirstDisp() {
        return firstDisp;
    }

    public void setFirstDisp(int firstDisp) {
        this.firstDisp = firstDisp;
    }

    public int getMaxDisp() {
        return maxDisp;
    }

    public void setMaxDisp(int maxDisp) {
        this.maxDisp = maxDisp;
    }

    public String getCommandPage() {
        return CommandPage;
    }

    public void setCommandPage(String CommandPage) {
        this.CommandPage = CommandPage;
    }

    public String getPageIndex() {
        return pageIndex;
    }

    public void setPageIndex(String pageIndex) {
        this.pageIndex = pageIndex;
    }

    public List<Option> getKaisaichiList() {
        return kaisaichiList;
    }

    public void setKaisaichiList(List<Option> kaisaichiList) {
        this.kaisaichiList = kaisaichiList;
    }

    public String[] getKaisaichiSelect() {
        return kaisaichiSelect;
    }

    public void setKaisaichiSelect(String[] kaisaichiSelect) {
        this.kaisaichiSelect = kaisaichiSelect;
    }

    public String getKaisaichiName() {
        return kaisaichiName;
    }

    public void setKaisaichiName(String kaisaichiName) {
        this.kaisaichiName = kaisaichiName;
    }

    public List<KaijoMst> getKaijoList() {
        return kaijoList;
    }

    public void setKaijoList(List<KaijoMst> kaijoList) {
        this.kaijoList = kaijoList;
    }

    public String getKaijoName() {
        return kaijoName;
    }

    public void setKaijoName(String kaijoName) {
        this.kaijoName = kaijoName;
    }

    public List<Option> getKaijoByKaisaichiList() {
        return kaijoByKaisaichiList;
    }

    public void setKaijoByKaisaichiList(List<Option> kaijoByKaisaichiList) {
        this.kaijoByKaisaichiList = kaijoByKaisaichiList;
    }

    public List<MstKanriKaijoTantoJoho> getTantoResultList() {
        return tantoResultList;
    }

    public void setTantoResultList(List<MstKanriKaijoTantoJoho> tantoResultList) {
        this.tantoResultList = tantoResultList;
    }

    public List<MstKanriKaijoTantoJoho> getTantoDisplayList() {
        return tantoDisplayList;
    }

    public void setTantoDisplayList(List<MstKanriKaijoTantoJoho> tantoDisplayList) {
        this.tantoDisplayList = tantoDisplayList;
    }

    public String getTantoSrcListFlg() {
        return tantoSrcListFlg;
    }

    public void setTantoSrcListFlg(String tantoSrcListFlg) {
        this.tantoSrcListFlg = tantoSrcListFlg;
    }
}