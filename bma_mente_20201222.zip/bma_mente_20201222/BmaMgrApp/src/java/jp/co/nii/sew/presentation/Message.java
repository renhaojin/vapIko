package jp.co.nii.sew.presentation;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * ���b�Z�[�W�̃��X�g
 * ���b�Z�[�W ���b�Z�[�W�̈ꕔ���C���f�b�N�X�Ŏw�肵�Ēu��������@�\�͔p�~
 *
 * @author n-machida
 */
public class Message implements Serializable{

    private ArrayList<String> message = new ArrayList<String>();
    
    /**
     * @return the message
     */
    public ArrayList<String> getMessage() {
        return message;
    }

    /**
     * @param message the message to set
     */
    public void setMessage(ArrayList<String> message) {
        this.message = message;
    }
    
    public void add(String newMessage) {        
        getMessage().add(getMessage().size(), newMessage);
    }

    public String get(int i) {
        if (getMessage().size() < i) {
            return null;
        } else {
            return getMessage().get(i);
        }
    }
    
//    private String content;
//
//    public Message(String content) {
//        this.content = content;
//    }

//    public Message(String key, String arg0) {
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
//    }
//
//    public Message(String key, String arg0, String str) {
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
//    }
//
//    public Message(String key, String arg0, int i) {
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
//    }
//
//    public Message(String key, String arg0, String str1, String str2) {
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
//    }
    
//    /**
//     * @return the content
//     */
//    public String getContent() {
//        return content;
//    }
//
//    /**
//     * @param content the content to set
//     */
//    public void setContent(String content) {
//        this.content = content;
//    }

}
