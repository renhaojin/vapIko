
CREATE OR REPLACE FUNCTION config.encrypt(bytea, bytea, text)
  RETURNS bytea AS
'$libdir/pgcrypto', 'pg_encrypt'
  LANGUAGE c IMMUTABLE STRICT
  COST 1;
ALTER FUNCTION config.encrypt(bytea, bytea, text)
  OWNER TO samplesys;


CREATE OR REPLACE FUNCTION config.decrypt(bytea, bytea, text)
  RETURNS bytea AS
'$libdir/pgcrypto', 'pg_decrypt'
  LANGUAGE c IMMUTABLE STRICT
  COST 1;
ALTER FUNCTION config.decrypt(bytea, bytea, text)
  OWNER TO samplesys;
