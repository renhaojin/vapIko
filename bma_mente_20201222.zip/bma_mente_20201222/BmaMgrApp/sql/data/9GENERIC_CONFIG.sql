INSERT INTO config.GENERIC_CONFIG(
            config_id
            , config_value
            , koshin_kbn
            , toroku_date
            , toroku_time
            , toroku_user_id
            , koshin_date
            , koshin_time
            , koshin_user_id
            , ronri_sakujo_flg)
    VALUES ('config_reload_seconds'
            , '300' --�C�ӂ̍ēǍ��݊Ԋu�i�b�j
            , 'I'
            , TO_CHAR(CURRENT_TIMESTAMP, 'yyyyMMdd')
            , TO_CHAR(CURRENT_TIMESTAMP, 'hh24miss')
            , USER, TO_CHAR(CURRENT_TIMESTAMP, 'yyyyMMdd')
            , TO_CHAR(CURRENT_TIMESTAMP, 'hh24miss')
            , USER
            , '0');

INSERT INTO config.GENERIC_CONFIG(
            config_id
            , config_value
            , koshin_kbn
            , toroku_date
            , toroku_time
            , toroku_user_id
            , koshin_date
            , koshin_time
            , koshin_user_id
            , ronri_sakujo_flg)
    VALUES ('session_save_flg'
            , '1'
            , 'I'
            , TO_CHAR(CURRENT_TIMESTAMP, 'yyyyMMdd')
            , TO_CHAR(CURRENT_TIMESTAMP, 'hh24miss')
            , USER, TO_CHAR(CURRENT_TIMESTAMP, 'yyyyMMdd')
            , TO_CHAR(CURRENT_TIMESTAMP, 'hh24miss')
            , USER
            , '0');
