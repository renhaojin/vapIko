package vap.kikan.dataIko;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.seasar.doma.boot.autoconfigure.DomaAutoConfiguration;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Import;
import org.springframework.test.context.junit4.SpringRunner;

import vap.kikan.dataIko.dto.TSaiban;
import vap.kikan.dataIko.utils.saiban.repository.SaibanRepository;
import vap.kikan.dataIko.utils.saiban.service.SaibanService;

@RunWith(SpringRunner.class)
@Import(DomaAutoConfiguration.class)
@ComponentScan
@SpringBootTest(classes = SaibanService.class)
public class SaibanServiceTest {

//	@MockBean
//	private SaibanRepository saibanRepository;

	@Autowired
	private SaibanRepository saibanRepository;

	@Autowired
	private SaibanService saibanService;

	@Test
	void getSaiban_採番成功_DBアクセス有り() {
		long result = saibanService.getSaiban("T_KEIYAKU");
		assertEquals(14L, result);
	}

	@Test
	void getSaiban_採番失敗_DBアクセス有り() {
		long result = saibanService.getSaiban("T_KEIYAKU１１１");
		assertEquals(14L, result);
	}

	@Test
	void getSaiban_採番成功_DBアクセス無し() {

		TSaiban saiban = new TSaiban();
		saiban.setSaibanDate(null);
		saiban.setLatestNumber(new BigDecimal(10L));
		saiban.setMaxNumber(new BigDecimal(100L));
		saiban.setRecInsertUserId("TEST");

		when(this.saibanRepository.selectBySaibanId(Mockito.anyString())).thenReturn(saiban);
		when(this.saibanRepository.updateSaiban(Mockito.any(TSaiban.class))).thenReturn(1);

		long result = saibanService.getSaiban("T_KEIYAKU");
		assertEquals(13L, result);
	}

	@Test
	void getSaiban_採番失敗_データ無し_DBアクセス無し() {

		TSaiban saiban = new TSaiban();
		saiban.setSaibanDate(null);
		saiban.setLatestNumber(new BigDecimal(10L));
		saiban.setMaxNumber(new BigDecimal(100L));
		saiban.setRecInsertUserId("TEST");

		when(this.saibanRepository.selectBySaibanId(Mockito.anyString())).thenReturn(null);
		when(this.saibanRepository.updateSaiban(Mockito.any(TSaiban.class))).thenReturn(1);

		long result = saibanService.getSaiban("T_KEIYAKU");
		assertEquals(11L, result);
	}

	@Test
	void getSaiban_採番失敗_最大値超_DBアクセス無し() {

		TSaiban saiban = new TSaiban();
		saiban.setSaibanDate(null);
		saiban.setLatestNumber(new BigDecimal(100L));
		saiban.setMaxNumber(new BigDecimal(100L));
		saiban.setRecInsertUserId("TEST");

		when(this.saibanRepository.selectBySaibanId(Mockito.anyString())).thenReturn(saiban);
		when(this.saibanRepository.updateSaiban(Mockito.any(TSaiban.class))).thenReturn(1);

		long result = saibanService.getSaiban("T_KEIYAKU");
		assertEquals(11L, result);
	}
}
