package vap.kikan.dataIko;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;

import org.junit.jupiter.api.Test;

import vap.kikan.dataIko.utils.DataIkoUtils;

public class DataIkoUtilsTest {
	// DBコネクション接続テスト
	@Test
	void createConnectTest() throws IOException, InterruptedException, IllegalAccessException, InstantiationException,
			ClassNotFoundException, SQLException {
		// DBドライバクラス、URL、ユーザー名、パスワードはプロパティファイルより取得
		Connection conn = DataIkoUtils.createConnect();
		assertNotNull(conn);
	}

	// データエクスポートテスト
	@Test
	void exportTableTest() throws IOException, InterruptedException, IllegalAccessException, InstantiationException,
			ClassNotFoundException, SQLException {
		// 引数： テーブルID、バックアップフラグ
		// データ格納先はプロパティファイルより取得
		int ret = DataIkoUtils.exportTable("t_saiban", true);
		assertEquals(0, ret);
	}

// データインポートテスト
	@Test
	void importTableTest() throws IOException, InterruptedException, IllegalAccessException, InstantiationException,
			ClassNotFoundException, SQLException {
		// 引数：インポートテーブルID、インポートファイル、コミットカウント
		// データ格納先はプロパティファイルより取得
		int ret = DataIkoUtils.importTable("t_saiban", "t_saiban.csv", 2);
		assertEquals(0, ret);
	}

	// テーブルクリアテスト
	@Test
	void clearTableTest() throws IOException, InterruptedException, IllegalAccessException, InstantiationException,
			ClassNotFoundException, SQLException {
		// 引数：インポートテーブルID、インポートファイル、コミットカウント
		// データ格納先はプロパティファイルより取得
		int ret = DataIkoUtils.clearTable("t_saiban");
		assertEquals(0, ret);
	}

	// 暗号化と復号化テスト
	@Test
	void encryptDecryptTest() throws Exception {
		String[] tokens = { "123456789012", "abcdefghijkl", "abcd56789012" };
		for (String s : tokens) {
			System.out.println("encryptToken=" + DataIkoUtils.encryptToken(s));
			String decryptToken = DataIkoUtils.decryptToken(DataIkoUtils.encryptToken(s));
			assertEquals(s, decryptToken);
		}
	}
}
