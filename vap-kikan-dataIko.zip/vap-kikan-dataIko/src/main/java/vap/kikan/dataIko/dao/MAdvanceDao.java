package vap.kikan.dataIko.dao;

import java.math.BigDecimal;

import org.seasar.doma.Dao;
import org.seasar.doma.Delete;
import org.seasar.doma.Insert;
import org.seasar.doma.Select;
import org.seasar.doma.Update;
import org.seasar.doma.boot.ConfigAutowireable;

import vap.kikan.dataIko.dto.MAdvance;

/**
 */
@Dao
@ConfigAutowireable
public interface MAdvanceDao {

	/**
	 * @param keiyakuNumber
	 * @param edaban
	 * @param advanceJokenNumber
	 * @return the MAdvance entity
	 */
	@Select
	MAdvance selectById(String keiyakuNumber, String edaban, BigDecimal advanceJokenNumber);

	/**
	 * @param keiyakuNumber
	 * @param edaban
	 * @param advanceJokenNumber
	 * @param versionNo
	 * @return the MAdvance entity
	 */
	@Select(ensureResult = true)
	MAdvance selectByIdAndVersion(String keiyakuNumber, String edaban, BigDecimal advanceJokenNumber,
			BigDecimal versionNo);

	/**
	 * @param entity
	 * @return affected rows
	 */
	@Insert
	int insert(MAdvance entity);

	/**
	 * @param entity
	 * @return affected rows
	 */
	@Update
	int update(MAdvance entity);

	/**
	 * @param entity
	 * @return affected rows
	 */
	@Delete
	int delete(MAdvance entity);
}