package vap.kikan.dataIko.constant;

import java.nio.charset.Charset;

/**
 * 文字エンコード定数クラス。 <br >
 * UTF-8を使いたいときは{@link java.nio.charset.StandardCharsets#UTF_8}を使うこと。
 * 
 * @author kin
 *
 */
public enum DataIkoCharacters {

    ShiftJis {
        public String getValue() {
            return "Shift_JIS";
        }
    },
    Ms932 {
        public String getValue() {
            return "MS932";
        }
    },
    Windows31J {
        public String getValue() {
            return "Windows-31J";
        }


    };


    /**
     * 値を返す。
     * 
     * @return 値
     */
    public abstract String getValue();

    /**
     * Charset型を返す。
     * 
     * @return Charset型
     */
    public Charset getCharset() {
        return Charset.forName(getValue());
    }

}
