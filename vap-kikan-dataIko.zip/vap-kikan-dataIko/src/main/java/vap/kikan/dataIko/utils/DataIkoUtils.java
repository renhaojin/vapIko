package vap.kikan.dataIko.utils;

import static vap.kikan.dataIko.constant.DataIkoBatchConstant.GATSUKI_LIST;
import static vap.kikan.dataIko.constant.DataIkoBatchConstant.ID_LIST;
import static vap.kikan.dataIko.constant.DataIkoBatchConstant.KEY_LIST;

import java.io.IOException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Arrays;
import java.util.Base64;
import java.util.List;
import java.util.Objects;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import lombok.extern.slf4j.Slf4j;
import vap.kikan.dataIko.constant.DataIkoBatchConstant;
import vap.kikan.dataIko.constant.DataIkoBatchStatusCode;

/**
 * データ移行系のユーティリティクラス。
 * 
 * @author kin
 *
 */
@Component
@Slf4j
public class DataIkoUtils {
	// OS判定
	public static final boolean isWindows = System.getProperty("os.name").toLowerCase().startsWith("windows");

	// アルゴリズム/ブロックモード/パディング方式
	private static final String ALGORITHM = "AES/CBC/PKCS5Padding";
	// 暗号化＆復号化で使用する鍵
	private static final String ENCRYPT_KEY = PropertiesConfigUtils.getProperty("dataIko.encrypt.key");
	// 初期ベクトル
	private static final String INIT_VECTOR = PropertiesConfigUtils.getProperty("dataIko.init.vectory");
	private static final IvParameterSpec iv = new IvParameterSpec(INIT_VECTOR.getBytes());
	private static final SecretKeySpec key = new SecretKeySpec(ENCRYPT_KEY.getBytes(), "AES");

	// カレントスキーマ 定数
	private static final String CURRENT_SCHEMA = "currentSchema";
	private static final String SYSPROC_ADMIN_SQL = "CALL SYSPROC.ADMIN_CMD(?)";
	private static final String LOCK_TABLE_SQL = "LOCK TABLE  $tableId IN SHARE MODE";
	private static final String CLEAR_TABLE_SQL = "TRUNCATE TABLE  $tableId IMMEDIATE";

	private static String driver = PropertiesConfigUtils.getProperty("spring.datasource.driver-class-name");

	private static String url = PropertiesConfigUtils.getProperty("spring.datasource.url");

	private static String username = PropertiesConfigUtils.getProperty("spring.datasource.username");

	private static String password = PropertiesConfigUtils.getProperty("spring.datasource.password");

	/**
	 * DB接続を確立する。
	 * 
	 * @param dbName   データベース名
	 * @param userId   接続ユーザID
	 * @param password パスワード
	 * @return コネクション
	 * @throws IOException
	 * @throws InterruptedException
	 * @throws SQLException
	 * @throws ClassNotFoundException
	 * @throws InstantiationException
	 * @throws IllegalAccessException
	 */
	public static Connection createConnect() throws IOException, InterruptedException, SQLException,
			IllegalAccessException, InstantiationException, ClassNotFoundException {
		log.info("接続確立開始");
		// ドライブロード
		Class.forName(driver);
		Connection conn = DriverManager.getConnection(
				url.substring(0, url.indexOf(";") > 0 ? url.lastIndexOf(":") : url.length()), username, password);
		// スキーマ取得
		if (url.indexOf(";") > 0) {
			String schema = getSchema(url.substring(url.lastIndexOf(":") + 1).split(";"));
			if (!"".equals(schema)) {
				conn.setSchema(schema);
			}
		}
		log.info("接続確立終了");
		return conn;
	}

	// スキーマ取得
	private static String getSchema(String[] params) {
		for (String str : params) {
			String key = str.split("=")[0];
			if (Objects.equals(key, CURRENT_SCHEMA)) {
				return str.split("=")[1];
			}
		}
		return "";
	}

	/**
	 * テーブルバックアップする。
	 * 
	 * @param tableId   テーブルID
	 * @param backupFlg バックアップフラグ true : バックアップ false : バックアップしない
	 * @param password  パスワード
	 * @return 正常：0 異常：9
	 * @throws InterruptedException
	 * @throws IOException
	 * @throws SQLException
	 * @throws ClassNotFoundException
	 * @throws InstantiationException
	 * @throws IllegalAccessException
	 */
	public static int exportTable(String tableId, boolean backupFlg) throws IllegalAccessException,
			InstantiationException, ClassNotFoundException, SQLException, IOException, InterruptedException {
		log.info("引数：tableId = " + tableId + ", backupFlg = " + backupFlg);
		if (!backupFlg) {
			log.info("バックアップしません");
			return DataIkoBatchStatusCode.Normal.getCode();
		}

		log.info("エクスポート開始");

		int rows_exported;
		String msg_retrieval = null;
		String sqlcode = null;
		String msg = null;

		PreparedStatement stmtForExport = null;
		ResultSet rsForExport = null;
		ResultSet rsForMessage = null;

		try (Connection conn = createConnect();
				CallableStatement callStmtForExport = conn.prepareCall(SYSPROC_ADMIN_SQL)) {
			try {
				StringBuilder sb = new StringBuilder();
				sb.append("export to  ");
				sb.append(getDirectory("E"));
				sb.append(tableId);
				sb.append(".csv");
				sb.append("  of del messages on server  ");
				sb.append("  select * from  ");
				sb.append(tableId);

				// 入力パラメータ設定
				callStmtForExport.setString(1, sb.toString());
				log.info("CALL ADMIN_CMD('" + sb.toString() + "')");

				callStmtForExport.execute();

				rsForExport = callStmtForExport.getResultSet();
				if (rsForExport.next()) {
					// エクスポートレコード数
					rows_exported = rsForExport.getInt(1);
					// containing SYSPROC.ADMIN_GET_MSGS
					msg_retrieval = rsForExport.getString(2);

					// エクスポート結果を出力
					log.info("エクスポート件数  : " + rows_exported);
					log.info("SQL 検索メッセージ: " + msg_retrieval);
				}

				stmtForExport = conn.prepareStatement(msg_retrieval);
				log.info("\n" + "Executing " + msg_retrieval);

				// message retrivel
				rsForMessage = stmtForExport.executeQuery();

				// retrieve the resultset
				while (rsForMessage.next()) {
					// retrieve the sqlcode
					sqlcode = rsForMessage.getString(1);
					// retrieve the error message
					msg = rsForMessage.getString(2);
					log.info("SQLコード : " + sqlcode);
					log.info("メッセージ    : " + msg);
				}
			} catch (Exception e) {
				// エラー処理
				log.error("エラーメッセージ    : " + e.getMessage());
				log.info("エクスポート処理異常終了");
				return DataIkoBatchStatusCode.ErrorSystem.getCode();
			} finally {
				try {
					stmtForExport.close();
					rsForExport.close();
					rsForMessage.close();
				} catch (Exception x) {
					log.error("\n Unable to Rollback/Disconnect ");
					log.info("エクスポート処理異常終了");
					return DataIkoBatchStatusCode.ErrorSystem.getCode();
				}
			}
		}
		log.info("エクスポート終了");
		return DataIkoBatchStatusCode.Normal.getCode();
	}

	/**
	 * テーブルにデータを取り込む。
	 * 
	 * @param tableId    テーブルID
	 * @param fileName   ファイル名
	 * @param commitUnit コミット単位
	 * @return 正常：0 異常：9
	 * @throws InterruptedException
	 * @throws IOException
	 * @throws SQLException
	 * @throws ClassNotFoundException
	 * @throws InstantiationException
	 * @throws IllegalAccessException
	 */
	public static int importTable(String tableId, String fileName, Integer commitUnit) throws IllegalAccessException,
			InstantiationException, ClassNotFoundException, SQLException, IOException, InterruptedException {
		log.info("引数：tableId = " + tableId + ", fileName = " + fileName + ", commitUnit = " + commitUnit);

		log.info("インポート開始");

		int rows_read;
		int rows_skipped;
		int rows_loaded;
		int rows_rejected;
		int rows_deleted;
		int rows_committed;

		String msg_retrieval = null;
		String sqlcode = null;
		String msg = null;

		PreparedStatement stmtForImport = null;
		ResultSet rsForImport = null;
		ResultSet rsForMessage = null;

		try (Connection conn = createConnect();
				CallableStatement callStmtForImport = conn.prepareCall(SYSPROC_ADMIN_SQL)) {
			try {
				StringBuilder sb = new StringBuilder();
				sb.append("import from  ");
				sb.append(getDirectory("I"));
				sb.append(fileName);
				sb.append("  of del commitcount ");
				sb.append(commitUnit);
				sb.append(" messages on server  ");
				sb.append("  insert into  ");
				sb.append(tableId);

				// 入力パラメータ設定
				callStmtForImport.setString(1, sb.toString());
				log.info("CALL ADMIN_CMD('" + sb.toString() + "')");
				callStmtForImport.execute();

				rsForImport = callStmtForImport.getResultSet();
				if (rsForImport.next()) {
					// 読み込みレコード数
					rows_read = rsForImport.getInt(1);
					// スキップレコード数
					rows_skipped = rsForImport.getInt(2);
					// ロードレコード数
					rows_loaded = rsForImport.getInt(3);
					// 拒否レコード数
					rows_rejected = rsForImport.getInt(4);
					// 削除レコード数
					rows_deleted = rsForImport.getInt(5);
					// コミットレコード数
					rows_committed = rsForImport.getInt(6);
					// SQL 検索メッセージ
					msg_retrieval = rsForImport.getString(7);
					// Displaying the resultset
					log.info("読み込みレコード数      : " + rows_read);
					log.info("スキップレコード数   : " + rows_skipped);
					log.info("ロードレコード数    : " + rows_loaded);
					log.info("拒否レコード数  : " + rows_rejected);
					log.info("削除レコード数   : " + rows_deleted);
					log.info("コミットレコード数 :  " + rows_committed);
					log.info("SQL 検索メッセージ: " + msg_retrieval);
				}
				stmtForImport = conn.prepareStatement(msg_retrieval);
				log.info("\n" + "Executing " + msg_retrieval);

				// message retrivel
				rsForMessage = stmtForImport.executeQuery();
				// retrieve the resultset
				while (rsForMessage.next()) {
					// retrieve the sqlcode
					sqlcode = rsForMessage.getString(1);
					// retrieve the error message
					msg = rsForMessage.getString(2);
					log.info("SQLコード : " + sqlcode);
					log.info("メッセージ    : " + msg);
				}
			} catch (Exception e) {
				// エラー処理
				conn.rollback();
				log.error("エラーメッセージ    : " + e.getMessage());
				log.info("インポート処理異常終了");
				return DataIkoBatchStatusCode.ErrorSystem.getCode();
			} finally {
				try {
					stmtForImport.close();
					rsForImport.close();
					rsForMessage.close();
				} catch (Exception x) {
					conn.rollback();
					log.error("\n Unable to Rollback/Disconnect ");
					log.info("インポート処理異常終了");
					return DataIkoBatchStatusCode.ErrorSystem.getCode();
				}
			}
		}
		log.info("インポート終了");
		return DataIkoBatchStatusCode.Normal.getCode();
	}

	/**
	 * テーブルをクリアする。
	 * 
	 * @param tableId テーブルID
	 * @return 正常：0 異常：9
	 * @throws InterruptedException
	 * @throws IOException
	 * @throws SQLException
	 * @throws ClassNotFoundException
	 * @throws InstantiationException
	 * @throws IllegalAccessException
	 */
	public static int clearTable(String tableId) throws IllegalAccessException, InstantiationException,
			ClassNotFoundException, SQLException, IOException, InterruptedException {
		log.info("引数：tableId = " + tableId);

		log.info("テーブルクリア開始");
		try (Connection conn = createConnect();
				Statement pstmtForLock = conn.createStatement();
				Statement pstmtForClear = conn.createStatement()) {

			log.info("テーブルロック開始");
			pstmtForLock.execute(LOCK_TABLE_SQL.replace("$tableId", tableId));
			log.info("テーブルロック終了");

			pstmtForClear.execute(CLEAR_TABLE_SQL.replace("$tableId", tableId));
		} catch (Exception e) {
			log.error("エラーメッセージ    : " + e.getMessage());
			log.info("テーブルクリア異常終了");
			return DataIkoBatchStatusCode.ErrorSystem.getCode();
		}
		log.info("テーブルクリア終了");
		return DataIkoBatchStatusCode.Normal.getCode();
	}

	/**
	 * 起動時引数チェック
	 * 
	 * @param args 起動時引数
	 * @return 正常：0 必須エラー：1 id存在しない：2 その他：9
	 */
	public static int checkArgs(String[] args) {
		int ret = DataIkoBatchStatusCode.Normal.getCode();
		log.info("起動時引数：{}", Arrays.toString(args));
		log.info("起動時引数チェック開始");

		if (args.length == 0) {
			log.error("起動時引数が指定されていません。");
			log.info("起動時引数チェック異常終了");
			return DataIkoBatchStatusCode.ErrorRequired.getCode();
		}
		boolean idExists = false;
		String key = "";
		String value = "";
		String[] keyValue = {};
		List<String> keyList = List.of(KEY_LIST);
		List<String> idList = List.of(ID_LIST);
		List<String> gatsukiList = List.of(GATSUKI_LIST);

		for (String arg : args) {
			keyValue = arg.split("=");
			if (keyValue == null || keyValue.length == 0) {
				log.error("指定された引数が正しくありません。引数：{}", arg);
				ret = DataIkoBatchStatusCode.ErrorSystem.getCode();
				break;
			}
			key = keyValue[0];
			value = keyValue.length == 2 ? keyValue[1] : "";
			// キーの存在チェック
			if (!keyList.contains(key)) {
				log.error("指定された引数のキーが存在しません。引数：{}", arg);
				ret = DataIkoBatchStatusCode.ErrorSystem.getCode();
				break;
			}

			// 大文字に変換
			if (StringUtils.isNotBlank(value)) {
				if (Objects.equals("buff", key)) {
					value = value.toUpperCase();
				}
			}

			switch (key) {
			case "id":
				idExists = true;
				// id 値の存在チェック
				if (!idList.contains(value)) {
					log.error("存在しないidが指定されました。引数：{}", arg);
					log.info("起動時引数チェック異常終了");
					return DataIkoBatchStatusCode.ErrorExists.getCode();
				}
				break;
			case "backup":
				if (StringUtils.isBlank(value) || (StringUtils.isNotBlank(value) && !Objects.equals("0", value)
						&& !Objects.equals("1", value))) {
					log.error("存在しないbackupが指定されました。0か1を指定してください。引数：{}", arg);
					log.info("起動時引数チェック異常終了");
					return DataIkoBatchStatusCode.ErrorSystem.getCode();
				}
				break;
			case "unit":
				if (StringUtils.isBlank(value)
						|| (StringUtils.isNotBlank(value) && (!DataIkoStringUtils.isDigit(value)))) {
					log.error("指定した引数が正しくありません。数字を指定してください。引数：{}", arg);
					log.info("起動時引数チェック異常終了");
					return DataIkoBatchStatusCode.ErrorSystem.getCode();
				}
				break;
			case "buff":
				if (StringUtils.isBlank(value) || (StringUtils.isNotBlank(value))) {
					if (!value.endsWith(DataIkoBatchConstant.BUFF_UNIT)
							|| !DataIkoStringUtils.isDigit(value.substring(0, value.length() - 1))) {
						log.error("指定した引数が正しくありません。引数：{}", arg);
						log.info("起動時引数チェック異常終了");
						return DataIkoBatchStatusCode.ErrorSystem.getCode();
					}
				}
				break;
			case "nenki":
				if (StringUtils.isBlank(value)
						|| (StringUtils.isNotBlank(value) && !LocalDateFormatUtils.isYyyymmddFormat(value + "0101"))) {
					log.error("指定した引数が正しくありません。引数：{}", arg);
					log.info("起動時引数チェック異常終了");
					return DataIkoBatchStatusCode.ErrorSystem.getCode();
				}
				break;
			case "gakki":
				if (StringUtils.isBlank(value) || (StringUtils.isNotBlank(value) && !gatsukiList.contains(value))) {
					log.error("指定した引数が正しくありません。01～08範囲で指定してください。引数：{}", arg);
					log.info("起動時引数チェック異常終了");
					return DataIkoBatchStatusCode.ErrorSystem.getCode();
				}
				break;
			case "dateStart":
			case "dateEnd":
				if (StringUtils.isBlank(value)
						|| (StringUtils.isNotBlank(value) && !LocalDateFormatUtils.isYyyymmddFormat(value))) {
					log.error("指定した引数が正しくありません。正しい日付を指定してください。引数：{}", arg);
					log.info("起動時引数チェック異常終了");
					return DataIkoBatchStatusCode.ErrorSystem.getCode();
				}
				break;
			case "taishoNengetsu":
				if (StringUtils.isBlank(value)
						|| (StringUtils.isNotBlank(value) && !LocalDateFormatUtils.isYyyymmddFormat(value + "01"))) {
					log.error("指定した引数が正しくありません。正しい年月を指定してください。引数：{}", arg);
					log.info("起動時引数チェック異常終了");
					return DataIkoBatchStatusCode.ErrorSystem.getCode();
				}
				break;
			default:
				break;
			}
		}
		// id必須チェック
		if (!idExists) {
			log.error("起動時引数：idが指定されていません。");
			ret = DataIkoBatchStatusCode.ErrorRequired.getCode();
		}

		log.info("起動時引数チェック終了");
		return ret;
	}

	/**
	 * 実行中のクラス名を取得。
	 * 
	 * @return クラス名
	 */
	public static String getClassName() {
		return Thread.currentThread().getStackTrace()[2].getClassName();
	}

	/**
	 * 実行中のメソッド名を取得。
	 * 
	 * @return メソッド名
	 */
	public static String getMethodName() {
		return Thread.currentThread().getStackTrace()[2].getMethodName();
	}

	/**
	 * ファイル格納フォルダーを取得。
	 * 
	 * @param option I: インポート E：エクスポート
	 * @return フォルダー
	 */
	public static String getDirectory(String option) {
		if (isWindows) {
			return Objects.equals(option, "I") ? PropertiesConfigUtils.getProperty("win.data.import.dir")
					: PropertiesConfigUtils.getProperty("win.data.export.dir");
		} else {
			return Objects.equals(option, "I") ? PropertiesConfigUtils.getProperty("aix.data.import.dir")
					: PropertiesConfigUtils.getProperty("aix.data.export.dir");
		}
	}

	/**
	 * 暗号化処理
	 */
	public static String encryptToken(String token) throws Exception {
		if (StringUtils.isBlank(token)) {
			return "";
		}
		Cipher encrypter = Cipher.getInstance(ALGORITHM);
		encrypter.init(Cipher.ENCRYPT_MODE, key, iv);
		byte[] byteToken = encrypter.doFinal(token.getBytes());
		return new String(Base64.getEncoder().encode(byteToken));
	}

	/**
	 * 復号化処理
	 */
	public static String decryptToken(String encryptedToken) throws Exception {
		if (StringUtils.isBlank(encryptedToken)) {
			return "";
		}
		Cipher decrypter = Cipher.getInstance(ALGORITHM);
		decrypter.init(Cipher.DECRYPT_MODE, key, iv);
		byte[] byteToken = Base64.getDecoder().decode(encryptedToken);
		return new String(decrypter.doFinal(byteToken));
	}
}
