package vap.kikan.dataIko.advanceMstImp.dao;

import org.seasar.doma.Dao;
import org.seasar.doma.Select;
import org.seasar.doma.boot.ConfigAutowireable;

@ConfigAutowireable
@Dao
public interface AdvanceMstImpDao {

	/**
	 * 印税マスタワークより商品コードを取得。
	 * 
	 * @param inzeiCode 印税コード
	 * @param keisanNo  計算NO
	 * @return 商品コード
	 */
	@Select
	String selectInzei(String inzeiCode, String keisanNo);
}
