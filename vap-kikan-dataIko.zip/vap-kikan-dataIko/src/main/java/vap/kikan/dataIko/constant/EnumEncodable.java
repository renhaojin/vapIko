package vap.kikan.dataIko.constant;

import java.io.Serializable;

/**
 * Enum用エンコーダーインターフェース。
 *
 * @param <T> Enum定義
 */
public interface EnumEncodable<T extends Serializable> {

    /**
     * エンコーダー。
     *
     * @return Enum定義
     */
    T getValue();


}
