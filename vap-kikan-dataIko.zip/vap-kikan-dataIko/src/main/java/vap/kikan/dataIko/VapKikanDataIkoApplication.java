package vap.kikan.dataIko;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Properties;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.configuration.BatchConfigurationException;
import org.springframework.batch.core.configuration.annotation.DefaultBatchConfigurer;
import org.springframework.batch.core.converter.DefaultJobParametersConverter;
import org.springframework.batch.core.explore.JobExplorer;
import org.springframework.batch.core.explore.support.MapJobExplorerFactoryBean;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.launch.support.SimpleJobLauncher;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.repository.support.MapJobRepositoryFactoryBean;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.Bean;

import lombok.extern.slf4j.Slf4j;
import vap.kikan.dataIko.constant.DataIkoBatchStatusCode;
import vap.kikan.dataIko.utils.DataIkoUtils;

@SpringBootApplication
@Slf4j
public class VapKikanDataIkoApplication {
	// 処理開始時刻
	private static LocalDateTime startDateTime = null;

	// 処理終了時刻
	private static LocalDateTime endDateTime = null;

	/**
	 * 起動処理。
	 * 
	 * @param args 引数
	 * @throws Exception 予期せぬ例外が発生時
	 */
	public static void main(String[] args) throws Exception {
		// 起動時引数チェック
		int ret = DataIkoUtils.checkArgs(args);
		if (ret != DataIkoBatchStatusCode.Normal.getCode()) {
			log.info("exitCode:{}", ret);
			System.exit(ret);
		}

		String id = "";
		Map<String, String> params = new HashMap<String, String>();
		for (int i = 0; i < args.length; i++) {
			String param = args[i];
			String[] keyValue = param.split("=");
			String key = keyValue[0];
			String value = keyValue.length == 2 ? keyValue[1] : "";

			log.info("JOB起動時のパラメータ キー:{}, 値:{}", key, value);
			params.put(key, value);
			if (Objects.equals(key, "id")) {
				id = value;
			}
		}

		log.info("起動するJOB:{}", id);
		startDateTime = LocalDateTime.now();
		log.info("起動するJOB開始時刻：{}", startDateTime);

		params.put("timestamp", LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss")));
//		log.info("タイムスタンプ:{}", params.get("timestamp"));

		ConfigurableApplicationContext context = SpringApplication.run(VapKikanDataIkoApplication.class, args);
		JobLauncher jobLauncher = context.getBean("jobLauncher", JobLauncher.class);
		Properties property = new Properties();
		for (Map.Entry<String, String> set : params.entrySet()) {
			property.put(set.getKey(), set.getValue());
		}
		JobParameters jobParameters = new DefaultJobParametersConverter().getJobParameters(property);
		Job job = (Job) context.getBean(id, Job.class);
		JobExecution jobExecution = jobLauncher.run(job, jobParameters);

		log.info(jobExecution.getExitStatus().getExitCode());
		log.info("exitCode:{}", SingletonExitCode.getInstance().exitCode.getCode());

		// 処理終了時刻
		endDateTime = LocalDateTime.now();
		log.info("起動するJOB終了時刻：{}", endDateTime);
		log.info("起動するJOB実行時間：{}秒", ChronoUnit.SECONDS.between(startDateTime, endDateTime));

		System.exit(SingletonExitCode.getInstance().exitCode.getCode());
	}

	/**
	 * Spring BatchのJOBに関するメタデータは書き込まない設定。
	 * 
	 * @return DefaultBatchConfigurer
	 */
	@Bean
	DefaultBatchConfigurer batchConfigurer() {
		return new DefaultBatchConfigurer() {
			private final JobRepository jobRepository;
			private final JobExplorer jobExplorer;
			private final JobLauncher jobLauncher;

			{
				MapJobRepositoryFactoryBean jobRepositoryFactory = new MapJobRepositoryFactoryBean();
				try {
					this.jobRepository = jobRepositoryFactory.getObject();
					MapJobExplorerFactoryBean jobExplorerFactory = new MapJobExplorerFactoryBean(jobRepositoryFactory);
					this.jobExplorer = jobExplorerFactory.getObject();
					SimpleJobLauncher jobLauncher = new SimpleJobLauncher();
					jobLauncher.setJobRepository(jobRepository);
					jobLauncher.afterPropertiesSet();
					this.jobLauncher = jobLauncher;
				} catch (Exception e) {
					throw new BatchConfigurationException(e);
				}
			}

			@Override
			public JobRepository getJobRepository() {
				return jobRepository;
			}

			@Override
			public JobExplorer getJobExplorer() {
				return jobExplorer;
			}

			@Override
			public JobLauncher getJobLauncher() {
				return jobLauncher;
			}
		};
	}

//	@Bean
//	public JdbcLogger jdbcLogger() {
//		return new BatchJdbcLogger();
//	}

//	@Bean
//	public DomaConfigBuilder domaConfigBuilder() {
//		DomaConfigBuilder builder = new DomaConfigBuilder();
//		builder.jdbcLogger(jdbcLogger());
//		return builder;
//	}

}
