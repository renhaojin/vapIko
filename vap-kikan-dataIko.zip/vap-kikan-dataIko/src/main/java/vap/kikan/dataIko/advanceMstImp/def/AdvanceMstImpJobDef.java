package vap.kikan.dataIko.advanceMstImp.def;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import vap.kikan.dataIko.JobCompletionNotificationListener;
import vap.kikan.dataIko.advanceMstImp.tasklet.AdvanceMstImpTasklet;
import vap.kikan.dataIko.base.BaseDataIkoBatchDef;

@Configuration
@EnableBatchProcessing
public class AdvanceMstImpJobDef extends BaseDataIkoBatchDef {

	@Autowired
	private AdvanceMstImpTasklet dvanceMstImpTasklet;

	// 異なるクラスで同一メソッドを使えるようにする。
	private static final String jobBeanName = "AdvanceMstImp";
	private static final String mainStepBeanName = jobBeanName + "MainStep";
	private static final String taskletBeanName = jobBeanName + "Tasklet";

	// idを引数として受け取る
	protected static final String ID = "#{jobParameters['id']}";

	// backupを引数として受け取る
	protected static final String BACKUP = "#{jobParameters['backup']}";

	// unitを引数として受け取る
	protected static final String UNIT = "#{jobParameters['unit']}";

	// buffを引数として受け取る
	protected static final String BUFF = "#{jobParameters['buff']}";

	// fileNamesを引数として受け取る
	protected static final String FILE_NAMES = "#{jobParameters['fileNames']}";

	@Bean(name = taskletBeanName)
	@StepScope
	protected AdvanceMstImpTasklet tasklet(@Value(ID) String id, @Value(BACKUP) String backup, @Value(UNIT) String unit,
			@Value(BUFF) String buff, @Value(FILE_NAMES) String fileNames) {
		return new AdvanceMstImpTasklet(id, backup, unit, buff, fileNames);
	}

	/**
	 * JOBを実行する。
	 * 
	 * @param listener JobCompletionNotificationListener
	 * @return 実行するJOB
	 */
	@Bean(name = jobBeanName)
	public Job job(JobCompletionNotificationListener listener) {

		return getJobBuilderFactory().get(jobBeanName).preventRestart().incrementer(new RunIdIncrementer())
				.listener(listener).start(mainStep(dvanceMstImpTasklet)).on("*").end().end().build();
	}

	/**
	 * 主処理を行う。
	 * 
	 * @param tasklet 実際の処理を行うTasklet
	 * @return Step
	 */
	@Bean(name = mainStepBeanName)
	public Step mainStep(AdvanceMstImpTasklet tasklet) {
		return getStepBuilderFactory().get(mainStepBeanName).tasklet(tasklet).build();
	}

	@Override
	public String getBatchId() {
		return jobBeanName;
	}

	@Override
	public String getBatchName() {
		return "アドバンスマスタ取込処理";
	}
}
