package vap.kikan.dataIko.advanceMstImp.tasklet;

import static vap.kikan.dataIko.constant.DataIkoBatchConstant.BUFF_UNIT_SIZE;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import org.apache.commons.lang3.StringUtils;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.DefaultTransactionDefinition;

import com.univocity.parsers.common.processor.BeanListProcessor;
import com.univocity.parsers.csv.CsvParser;
import com.univocity.parsers.csv.CsvParserSettings;

import lombok.extern.slf4j.Slf4j;
import vap.kikan.dataIko.advanceMstImp.dto.IADMFPDto;
import vap.kikan.dataIko.advanceMstImp.repository.AdvanceMstImpRepository;
import vap.kikan.dataIko.base.BaseDataIkoBatchTasklet;
import vap.kikan.dataIko.constant.DataIkoBatchConstant;
import vap.kikan.dataIko.constant.DataIkoCharacters;
import vap.kikan.dataIko.constant.TextConstant;
import vap.kikan.dataIko.dto.MAdvance;
import vap.kikan.dataIko.dto.MShohin;
import vap.kikan.dataIko.dto.WkIkoZentokinKeiyakuNumber;
import vap.kikan.dataIko.utils.DataIkoUtils;
import vap.kikan.dataIko.utils.PropertiesConfigUtils;
import vap.kikan.dataIko.utils.saiban.service.SaibanService;

/**
 * アドバンスマスタ取込 Tasklet。
 * 
 * @author kin
 *
 */
@Slf4j
public class AdvanceMstImpTasklet extends BaseDataIkoBatchTasklet implements Tasklet {
	// アドバンスマスタ取込用リポジトリ
	@Autowired
	private AdvanceMstImpRepository advanceMstImpRepository;

	// 採番サービス
	@Autowired
	private SaibanService saibanService;

	// 取込ファイル名 複数場合あり
	private static final String[] FILE_NAMES = PropertiesConfigUtils.getProperty("dataIko.AdvanceMstImp.file")
			.split(TextConstant.Comma.getValue());

	// 移行対象テーブルID
	private static final String TABLE_ID = "M_ADVANCE";
	// ワークテーブルID
	private static final String TABLE_ID_WK = "WK_IKO_ZENTOKIN_KEIYAKU_NUMBER";

	// 契約NO先頭部分
	private static String KEIYAKU_NO_FIRST_PART = PropertiesConfigUtils
			.getProperty("dataIko.inzei.keiyakuNo.firstPart");

	private List<String> errorMessageList;

	// 起動時引数
	public AdvanceMstImpTasklet(String id, String backup, String unit, String buff, String fileNames) {
		super(id, backup, unit, buff, fileNames);
		this.errorMessageList = new ArrayList<>();
	}

	@Override
	public void executeMain(StepContribution contribution, ChunkContext chunkContext) throws Exception {
		log.info("{} タスクレット開始", this.getClass().getName());
		log.info("起動時引数 id={}, backup={}, unit={}, buff={}, fileNames={} ", this.id, this.backup, this.unit, this.buff,
				this.fileNames);

		TransactionStatus status = null;
		try {
			// コミット単位未設定の場合、デフォルト設定
			unit = StringUtils.isBlank(unit) ? DataIkoBatchConstant.COMMIT_UNIT : unit;

			// テーブルバックアップ
			DataIkoUtils.exportTable(TABLE_ID, Objects.equals(backup, "1") ? true : false);
			// テーブルクリア
			DataIkoUtils.clearTable(TABLE_ID);
			// テーブルクリア ワーク
			DataIkoUtils.clearTable(TABLE_ID_WK);

			// トランザクション定義
			DefaultTransactionDefinition definition = new DefaultTransactionDefinition();
			// 定義を設定
			definition.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRES_NEW);

			// 読み込みファイルリスト 引数でファイル名が指定された場合にそれを優先
			for (String fileName : StringUtils.isNotBlank(fileNames) ? fileNames.split(TextConstant.Comma.getValue())
					: FILE_NAMES) {

				// 以下からテーブル取込処理に入る
				String shohinCode = "";
				MShohin mShohin = null;
				// ファイル読み込み
				List<IADMFPDto> advanceMstImpeList = readFile(
						DataIkoUtils.getDirectory(DataIkoBatchConstant.IMPORT) + fileName);

				for (IADMFPDto dto : advanceMstImpeList) {
					log.debug("ファイル読み込み情報：{}", dto);
					// 印税コードと計算NOで、WK_印税マスタを検索
					shohinCode = advanceMstImpRepository.selectInzei(dto.getADIZCD(), dto.getADKENO());
					if (!Objects.isNull(shohinCode)) {
						// 商品マスタ検索
						mShohin = advanceMstImpRepository.selectMShohinById(shohinCode);
						if (Objects.isNull(mShohin)) {
							log.error("商品コード：{}は商品マスタに存在しません。", shohinCode);
							continue;
						}
					} else {
						log.error("印税コード：{}と計算NO：{}は印税マスタに存在しません。", dto.getADIZCD(), dto.getADKENO());
						continue;
					}
					if (insertCount % Long.parseLong(unit) == 0) {
						// トランザクション開始
						status = platformTransactionManager.getTransaction(definition);
					}
					// 採番
					long keiyakuNo = saibanService.getSaiban(TABLE_ID);
					String keiyakuNoStr = KEIYAKU_NO_FIRST_PART + String.format("%06d", keiyakuNo);

					// アドバンスマスタに登録
					MAdvance entity = new MAdvance();
					// 契約番号
					entity.setKeiyakuNumber(keiyakuNoStr);
					// 枝番
					entity.setEdaban("00001");
					// アドバンス条件ＮＯ
					entity.setAdvanceJokenNumber(BigDecimal.ONE);
					// 商品グループコード
					entity.setShohinGroupCode(dto.getADKENO());

					// アドバンスコード デフォルト設定

					// 制作部門区分
					entity.setSeisakuBumonKubun(mShohin.getAvKubun());
					// バンス金額（前渡金発生額）
					entity.setAdvanceKingakuZentokinKingakuHasseiKingaku(new BigDecimal(dto.getADTMWK()));
					// 作品名（印税管理用）
					entity.setSakuhinNameInzeiKanriYo(mShohin.getTitleKanji());

					// メモ１ デフォルト設定
					// メモ２ デフォルト設定

					// その他相殺額
					entity.setEtcSousaiKingaku(new BigDecimal(dto.getADSNTS()));

					// アドバンス金額（前渡金発生額）発生日 デフォルト
					// その他相殺額発生日 デフォルト

					// 共通項目設定
					setRecInsertInfo(entity);
					advanceMstImpRepository.insertMAdvance(entity);
					// WK_移行前渡金契約番号に登録
					WkIkoZentokinKeiyakuNumber entityForZentokin = new WkIkoZentokinKeiyakuNumber();
					// 印税コード
					entityForZentokin.setInzeiCode(dto.getADIZCD());
					// 計算NO
					entityForZentokin.setKeisanNo(new BigDecimal(dto.getADKENO()));
					// 契約番号
					entityForZentokin.setKeiyakuNumber(keiyakuNoStr);

					advanceMstImpRepository.insertWkIkoZentokinKeiyakuNumber(entityForZentokin);
					// INSERT件数をインクリメント
					insertCount++;
					if (insertCount % Long.parseLong(unit) == 0) {
						// トランザクションコミット
						platformTransactionManager.commit(status);
					}
				}
			}

			// トランザクション終了
			// コミット単位は指定したが、登録件数がコミット単位の倍数になってない場合のみ
			if (insertCount % Long.parseLong(unit) != 0) {
				// トランザクションコミット
				platformTransactionManager.commit(status);
			}
			// メッセージ出力
			writeMessage(null);
		} catch (Exception e) {
			e.printStackTrace();
			// トランザクションロールバック
			platformTransactionManager.rollback(status);
			log.error("{}タスクレット実行時エラー発生：{}", this.getClass().getName(), e.getMessage());
			log.info("{} タスクレット異常終了", this.getClass().getName());
			throw e;
		}
		log.info("{} タスクレット終了", this.getClass().getName());
	}

	@Override
	public List<String> getErrorMessageList() {
		return this.errorMessageList;
	}

	/**
	 * ファイル取り込み、Dtoリストを作成
	 * 
	 * @param FileName ファイル名
	 * @return アドバンスマスタ情報一覧
	 */
	private List<IADMFPDto> readFile(String FileName) throws IOException {
		BufferedReader buf = null;
		// バッファー変換 キロバイト単位からバイト単位に変換
		int buff_size = BUFF_UNIT_SIZE * Integer.parseInt(buff.substring(0, buff.length() - 1));

		try (InputStream stream = new FileInputStream(FileName);
				Reader reader = new InputStreamReader(stream, DataIkoCharacters.ShiftJis.getValue());) {

			// バッファチューニングか
			buf = Objects.isNull(buff) ? new BufferedReader(reader) : new BufferedReader(reader, buff_size);

			CsvParserSettings settings = new CsvParserSettings();
			settings.getFormat().setLineSeparator(
					DataIkoUtils.isWindows ? TextConstant.CRLF.getValue() : TextConstant.LF.getValue()); // 改行コードは CR+LF
			settings.setHeaderExtractionEnabled(false);

			BeanListProcessor<IADMFPDto> rowProcessor = new BeanListProcessor<>(IADMFPDto.class);
			settings.setProcessor(rowProcessor);

			CsvParser parser = new CsvParser(settings);

			parser.parse(buf);
			List<IADMFPDto> allRows = rowProcessor.getBeans(); // データ行を取得する

			log.info("読み込み行数:{}", allRows.size());
			readCount += allRows.size();
			return allRows;
		} catch (IOException e) {
			log.error(e.toString());
			throw e;
		}
	}

	@Override
	public void writeMessage(String option) {
		log.info("{}ファイル読込件数:{}件、{} 登録件数:{}件、{} 登録件数:{}件", "印税前渡金マスタ－.csv", readCount, "アドバンスマスタ", insertCount,
				"WK_移行前渡金契約番号", insertCount);
	}
}
