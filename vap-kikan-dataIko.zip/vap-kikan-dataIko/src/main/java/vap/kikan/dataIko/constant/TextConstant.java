package vap.kikan.dataIko.constant;

/**
 * テキストに関連する定数クラス。
 * 
 * @author kin
 *
 */
public enum TextConstant {

	Comma {
		@Override
		public String getValue() {
			return ",";
		}
	},
	Hyphen {
		@Override
		public String getValue() {
			return "-";
		}
	},
	Tab {
		@Override
		public String getValue() {
			return "\t";
		}
	},
	CRLF {
		@Override
		public String getValue() {
			return "\r\n";
		}
	},
	LF {
		@Override
		public String getValue() {
			return "\n";
		}
	},
	Colon {
		@Override
		public String getValue() {
			return ":";
		}
	};

	/**
	 * 定数が表す文字列を返す。
	 * 
	 * @return 定数が表す文字列
	 */
	public abstract String getValue();

}
