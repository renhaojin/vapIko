package vap.kikan.dataIko.advanceMstImp.dto;

import com.univocity.parsers.annotations.Parsed;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@ToString
public class IADMFPDto {
	/** 状態コード **/
	@Parsed(index = 0)
	private String ADJCD;
	/** 会社コード **/
	@Parsed(index = 1)
	private String ADKACD;
	/** 印税コード **/
	@Parsed(index = 2)
	private String ADIZCD;
	/** 計算ＮＯ **/
	@Parsed(index = 3)
	private String ADKENO;
	/** 前期前渡金残 **/
	@Parsed(index = 4)
	private String ADZMWZ;
	/** 製作費振替 **/
	@Parsed(index = 5)
	private String ADSKFR;
	/** その他相殺額 **/
	@Parsed(index = 6)
	private String ADSNTS;
	/** 前渡金発生額 **/
	@Parsed(index = 7)
	private String ADTMWK;
	/** 前渡金合計額 **/
	@Parsed(index = 8)
	private String ADTMWG;
	/** 前渡金相殺額 **/
	@Parsed(index = 9)
	private String ADTSOK;
	/** 当期前渡金残 **/
	@Parsed(index = 10)
	private String ADTMWZ;
	/** 当期印税額 **/
	@Parsed(index = 11)
	private String ADTIZK;
	/** 差引印税額 **/
	@Parsed(index = 12)
	private String ADSIZK;
	/** 前期印税額累計 **/
	@Parsed(index = 13)
	private String ADRIZZ;
	/** 前期前渡金累計 **/
	@Parsed(index = 14)
	private String ADRMWZ;
	/** 当期印税額累計 **/
	@Parsed(index = 15)
	private String ADRIZK;
	/** 当期前渡金累計 **/
	@Parsed(index = 16)
	private String ADRMWK;
	/** 計算区分 **/
	@Parsed(index = 17)
	private String ADKIKB;
	/** 確定ＦＬＧ **/
	@Parsed(index = 18)
	private String ADFLG;
	/** 残高金額 **/
	@Parsed(index = 19)
	private String ADZNKG;
	/** 残高日付 **/
	@Parsed(index = 20)
	private String ADZNDT;
	/** 最終書込端末 **/
	@Parsed(index = 21)
	private String ADWSID;
	/** 最終書込社員 **/
	@Parsed(index = 22)
	private String ADSYNO;
	/** 作成日付 **/
	@Parsed(index = 23)
	private String ADCRDT;
	/** 最終書込付日付 **/
	@Parsed(index = 24)
	private String ADUPDT;
	/** 最終書込時刻 **/
	@Parsed(index = 25)
	private String ADUPTM;
	/** 削除日付 **/
	@Parsed(index = 26)
	private String ADDEDT;
	/** 最終書込ＰＧＭ **/
	@Parsed(index = 27)
	private String ADPGM;
}
