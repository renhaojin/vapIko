package vap.kikan.dataIko.constant;

import org.springframework.batch.core.ExitStatus;

import vap.kikan.dataIko.utils.PropertiesConfigUtils;

public class DataIkoBatchConstant {

	public static final ExitStatus Warning = new ExitStatus("WARNING");

	// データ移行処理起動パラメータ：idの値一覧
	public static final String[] ID_LIST = PropertiesConfigUtils.getProperty("dataIko.id.list").split(",");

	// データ移行処理起動パラメータキー
	public static final String[] KEY_LIST = PropertiesConfigUtils.getProperty("dataIko.key.list").split(",");

	// 月期区分
	public static final String[] GATSUKI_LIST = PropertiesConfigUtils.getProperty("dataIko.gatsuki.list").split(",");

	// ファイルバッファー単位
	public static final String BUFF_UNIT = "K";

	// デフォルトバッファーサイズ
	public static final int DEFAULT_CHAR_BUFFER_SIZE = Integer
			.parseInt(PropertiesConfigUtils.getProperty("dataIko.buffer.size"));

	// コミット単位 デフォルト
	public static final String COMMIT_UNIT = PropertiesConfigUtils.getProperty("dataIko.commit.unit");

	// ファイルバッファー単位 固定
	public static final int BUFF_UNIT_SIZE = 1024;

	// インポートDIR
	public static final String IMPORT = "I";
	// インポートDIR
	public static final String EXPORT = "E";

}
