package vap.kikan.dataIko.utils;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.format.ResolverStyle;

import org.apache.commons.lang3.StringUtils;

/**
 * LocalDate型の値を文字列に変換する。
 * 
 * @author kin
 *
 */
public final class LocalDateFormatUtils {

	private static final DateTimeFormatter inputYyyymmdd = DateTimeFormatter.ofPattern("uuuuMMdd");

	private static final DateTimeFormatter displayYyyymmdd = DateTimeFormatter.ofPattern("uuuu/MM/dd");

	private static final DateTimeFormatter displayYyyymmddJpn = DateTimeFormatter.ofPattern("uuuu年 MM月 dd日");

	private static final DateTimeFormatter inputYyyymmddHHmmssSSS = DateTimeFormatter.ofPattern("uuuuMMddHHmmssSSS");

	/**
	 * LocalDate型の値を指定した形式の日付に変換する。
	 * 
	 * @param localDate
	 * @param format    フォーマット形式(例: yyyy/MM/dd)
	 * @return
	 */
	public static String formatDate(LocalDate localDate, String format) {

		if (localDate == null) {
			return StringUtils.EMPTY;
		}
		DateTimeFormatter customFormat = DateTimeFormatter.ofPattern(format);
		return customFormat.format(localDate);
	}

	/**
	 * LocalDate型の値をyyyyMMdd形式の日付に変換する。
	 * 
	 * @param localDate 変換対象の値
	 * @return yyyyMMdd形式の日付
	 */
	public static String formatInputYyyymmdd(LocalDate localDate) {

		if (localDate == null) {
			return StringUtils.EMPTY;
		}
		return inputYyyymmdd.format(localDate);
	}

	/**
	 * LocalDate型の値をyyyy/MM/dd形式の日付に変換する。
	 * 
	 * @param localDate 変換対象の値
	 * @return yyyy/MM/dd形式の日付
	 */
	public static String formatDisplayYyyymmdd(LocalDate localDate) {
		if (localDate == null) {
			return StringUtils.EMPTY;
		}
		return displayYyyymmdd.format(localDate);
	}

	/**
	 * LocalDate型の値をyyyy年 MM月 dd日形式の日付に変換する。
	 * 
	 * @param localDate 変換対象の値
	 * @return yyyy/MM/dd形式の日付
	 */
	public static String formatDisplayYyyymmddJpn(LocalDate localDate) {
		if (localDate == null) {
			return StringUtils.EMPTY;
		}
		return displayYyyymmddJpn.format(localDate);
	}

	/**
	 * yyyyMMdd, yyyy/MM/dd形式の文字列をLocalDate型に変換する。
	 * 
	 * @param date yyyyMMdd形式の文字列
	 * @return LocalDate型
	 */
	public static LocalDate toLocalDate(String date) {

		if (StringUtils.isBlank(date)) {
			return null;
		}

		date = date.replace("/", "");
		if (!isYyyymmddFormat(date)) {
			return null;
		}

		return LocalDate.parse(date, inputYyyymmdd);

	}

	/**
	 * yyyyMMdd形式の文字列かどうかをチェックする。
	 * 
	 * @param value チェック対象の文字列
	 * @return 正しい日付であればtrue
	 */
	public static boolean isYyyymmddFormat(String value) {

		if (StringUtils.isBlank(value)) {
			return false;
		}

		DateTimeFormatter df = inputYyyymmdd.withResolverStyle(ResolverStyle.STRICT);

		try {
			LocalDate.parse(value, df);
			return true;
		} catch (DateTimeParseException e) {
			return false;
		}
	}

	/**
	 * yyyy/MM/dd形式の文字列かどうかをチェックする。
	 * 
	 * @param value チェック対象の文字列
	 * @return 正しい日付であればtrue
	 */
	public static boolean isDisplayYyyymmddFormat(String value) {

		if (StringUtils.isBlank(value)) {
			return false;
		}

		DateTimeFormatter df = displayYyyymmdd.withResolverStyle(ResolverStyle.STRICT);

		try {
			LocalDate.parse(value, df);
			return true;
		} catch (DateTimeParseException e) {
			return false;
		}
	}

	/**
	 * yyyyMMddHHmmssSSS形式の文字列をLocalDate型に変換する。
	 * 
	 * @param dateTime yyyyMMddHHmmssSSS形式の文字列
	 * @return LocalDateTime型
	 */
	public static LocalDateTime toLocalDateTime(String dateTime) {
		try {
			return LocalDateTime.parse(dateTime, inputYyyymmddHHmmssSSS);
		} catch (Exception e) {
			return null;
		}
	}
}
