package vap.kikan.dataIko.base;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Objects;

import org.apache.commons.lang3.StringUtils;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.DefaultTransactionDefinition;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import vap.kikan.dataIko.common.DataIkoIBatchShoriKekka;
import vap.kikan.dataIko.constant.DataIkoBatchConstant;
import vap.kikan.dataIko.constant.DataIkoBatchShoriJokyo;
import vap.kikan.dataIko.dto.common.DomaDto;
import vap.kikan.dataIko.utils.MessageUtils;

@Setter
@Getter
@Slf4j
public abstract class BaseDataIkoBatchTasklet implements Tasklet {
	// ファイル読込件数・またはテーブル取得件数
	protected long readCount = 0;
	// 登録件数
	protected long insertCount = 0;
	// 更新件数
	protected long updateCount = 0;

	// 登録件数 ワーク
	protected long insertCountForWk = 0;

	private LocalDateTime systemDatetime;

	// 起動時引数：処理ID
	protected String id;
	// 起動時引数：バックアップフラグ
	protected String backup;
	// 起動時引数：コミット単位
	protected String unit;
	// 起動時引数：日付開始
	protected String dateStart;
	// 起動時引数：日付終了
	protected String dateEnd;
	// 起動時引数：年期
	protected String nenki;
	// 起動時引数：月期区分
	protected String gakki;
	// 起動時引数：対象年月
	protected String taishoNengetsu;
	// 起動時引数：ファイルバッファー
	protected String buff;
	// 起動時引数：ファイル名(カンマ区切り)
	protected String fileNames;

	protected BaseDataIkoBatchTasklet(String id, String backup, String unit, String buff, String fileNames) {
		this(id, backup, unit, null, null, null, null, null, buff, fileNames);
	}

	protected BaseDataIkoBatchTasklet(String id, String backup, String unit, String taishoNengetsu, String buff,
			String fileNames) {
		this(id, backup, unit, null, null, null, null, taishoNengetsu, buff, fileNames);
	}

	protected BaseDataIkoBatchTasklet(String id, String backup, String unit, String nenki, String gakki, String buff,
			String fileNames) {
		this(id, backup, unit, nenki, gakki, null, null, null, buff, fileNames);
	}

	protected BaseDataIkoBatchTasklet(String id, String backup, String unit, String nenki, String gakki,
			String dateStart, String dateEnd, String taishoNengetsu, String buff, String fileNames) {
		this.id = id;
		this.backup = backup;
		this.unit = unit;
		this.nenki = nenki;
		this.gakki = gakki;
		this.dateStart = dateStart;
		this.dateEnd = dateEnd;
		this.taishoNengetsu = taishoNengetsu;
		this.buff = buff;
		this.fileNames = fileNames;
	}

	@Autowired
	protected PlatformTransactionManager platformTransactionManager;

	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
		systemDatetime = LocalDateTime.now();
		TransactionStatus status = getTransactionStatus();
		try {
			executeMain(contribution, chunkContext);
		} catch (Exception e) {
			log.error(MessageUtils.getMessage("dataIkoBatch.errors.abnormalTermination"), e);

			contribution.setExitStatus(ExitStatus.FAILED);
			setBatchShoriJokyoAbend(chunkContext);
			platformTransactionManager.rollback(status);
			return RepeatStatus.FINISHED;
		}

		if (getErrorMessageList().isEmpty()) {
			platformTransactionManager.commit(status);
			contribution.setExitStatus(ExitStatus.COMPLETED);
			// 各バッチで処理状況を設定していたらそちらを優先
			final String shoriJokyo = (String) chunkContext.getStepContext().getStepExecution().getJobExecution()
					.getExecutionContext().get("shoriJokyo");
			if (Objects.isNull(shoriJokyo)) {
				setBatchShoriJokyoNormalEnd(chunkContext);
			} else {
				if (Objects.equals(shoriJokyo, DataIkoBatchShoriJokyo.WARNING_END.getValue())) {
					contribution.setExitStatus(DataIkoBatchConstant.Warning);
				}
			}
		} else {
			log.error(MessageUtils.getMessage("dataIkoBatch.errors.abnormalTermination"));
			for (String message : getErrorMessageList()) {
				log.error(message);
			}
			contribution.setExitStatus(ExitStatus.FAILED);
			setBatchShoriJokyoAbend(chunkContext);
			platformTransactionManager.rollback(status);
		}
		return RepeatStatus.FINISHED;
	}

	/**
	 * トランザクションステータスを取得する。
	 * 
	 * @return トランザクションステータス
	 */
	protected TransactionStatus getTransactionStatus() {
		DefaultTransactionDefinition definition = new DefaultTransactionDefinition();
		definition.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRES_NEW);
		TransactionStatus status = platformTransactionManager.getTransaction(definition);
		return status;
	}

	/**
	 * バッチ処理の主処理を行う。
	 * 
	 * @param contribution StepContribution
	 * @param chunkContext ChunkContext
	 * @throws Exception 取込処理中に例外が発生
	 */
	public abstract void executeMain(StepContribution contribution, ChunkContext chunkContext) throws Exception;

	/**
	 * バッチ処理中に発生したエラーメッセージを格納したリストを取得する。
	 * 
	 * @return バッチ処理中に発生したエラーメッセージを格納したリスト
	 */
	public abstract List<String> getErrorMessageList();

	/**
	 * バッチ開始時のシステム日時を返す。
	 * 
	 * @return バッチ開始時のシステム日時
	 */
	protected LocalDateTime getBatchStartDatetime() {
		return this.systemDatetime;
	}

	/**
	 * バッチ処理状況：正常終了 を設定する。
	 * 
	 * @param chunkContext ChunkContext
	 */
	protected void setBatchShoriJokyoNormalEnd(ChunkContext chunkContext) {
		chunkContext.getStepContext().getStepExecution().getJobExecution().getExecutionContext().put("shoriJokyo",
				DataIkoBatchShoriJokyo.NORMAL_END.getValue());
	}

	/**
	 * バッチ処理状況：警告終了 を設定する。
	 * 
	 * @param chunkContext ChunkContext
	 */
	protected void setBatchShoriJokyoWarningEnd(ChunkContext chunkContext) {
		chunkContext.getStepContext().getStepExecution().getJobExecution().getExecutionContext().put("shoriJokyo",
				DataIkoBatchShoriJokyo.WARNING_END.getValue());
	}

	/**
	 * バッチ処理状況：異常終了 を設定する。
	 * 
	 * @param chunkContext ChunkContext
	 */
	protected void setBatchShoriJokyoAbend(ChunkContext chunkContext) {
		chunkContext.getStepContext().getStepExecution().getJobExecution().getExecutionContext().put("shoriJokyo",
				DataIkoBatchShoriJokyo.ABEND.getValue());
	}

	/**
	 * バッチ処理結果 を設定する。
	 * 
	 * @param chunkContext ChunkContext
	 * @param shoriKekka   処理結果
	 */
	protected void setBatchShoriKekka(ChunkContext chunkContext, DataIkoIBatchShoriKekka shoriKekka) {

		if (Objects.isNull(shoriKekka)) {
			return;
		}

		ObjectMapper mapper = new ObjectMapper();
		try {
			String shoriKekkaJson = mapper.writeValueAsString(shoriKekka);
			if (StringUtils.isBlank(shoriKekkaJson)) {
				throw new IllegalArgumentException("バッチ実行結果が定義されていない");
			}

			chunkContext.getStepContext().getStepExecution().getJobExecution().getExecutionContext().put("shoriKekka",
					shoriKekkaJson);

		} catch (JsonProcessingException e) {
			log.error("バッチ実行結果をJSON型に変換するときに例外発生", e);
			throw new IllegalArgumentException("バッチ実行結果をJSON型に変換するときに例外発生。");
		}
	}

	/**
	 * レコード登録情報を設定する。
	 * 
	 * @param entity Entity
	 */
	protected void setRecInsertInfo(DomaDto entity) {
		entity.setVersionNo(new BigDecimal(0));
		entity.setRecInsertDatetime(systemDatetime);
		entity.setRecInsertUserId(id.length() > 20 ? id.substring(0, 20) : id);
		entity.setRecUpdateDatetime(systemDatetime);
		entity.setRecUpdateUserId(id.length() > 20 ? id.substring(0, 20) : id);
	}

	/**
	 * レコード更新情報を設定する。
	 * 
	 * @param entity Entity
	 */
	protected void setRecUpdateInfo(DomaDto entity) {
		entity.setRecUpdateDatetime(systemDatetime);
		entity.setRecUpdateUserId(id.length() > 20 ? id.substring(0, 20) : id);
	}

	/**
	 * メッセージを出力する。
	 * 
	 */
	abstract protected void writeMessage(String option);

}
