//package vap.kikan.dataIko.base.logger;
//
//import java.util.function.Supplier;
//import java.util.logging.Level;
//
//import org.seasar.doma.jdbc.Sql;
//import org.seasar.doma.jdbc.UtilLoggingJdbcLogger;
//
//public class BatchJdbcLogger extends UtilLoggingJdbcLogger {
//
//	public BatchJdbcLogger() {
//		super(Level.FINE);
//	}
//
//	@Override
//	protected void logSql(String callerClassName, String callerMethodName, Sql<?> sql, Level level,
//			Supplier<String> messageSupplier) {
//		// ★引数の level (デフォルトログレベル) を無視して、強制的に INFO に差し替え
//		super.logSql(callerClassName, callerMethodName, sql, Level.WARNING, messageSupplier);
////		super.logSql(callerClassName, callerMethodName, sql, Level.CONFIG, messageSupplier);
//	}
//}
