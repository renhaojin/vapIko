package vap.kikan.dataIko.utils;

import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.util.Objects;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;

import lombok.extern.slf4j.Slf4j;
import vap.kikan.dataIko.constant.DataIkoCharacters;

/**
 * データ移行プロジェクト用のString関連ユーティリティクラス。
 * 
 * @author kin
 *
 */
@Slf4j
public final class DataIkoStringUtils {

	private DataIkoStringUtils() {
	}

	/**
	 * 渡された値がNullだったらブランク文字を返す。
	 * 
	 * @param str 対象の値
	 * @return 渡された値がNullだったらブランク文字、そうでなければ引数の値
	 */
	public static final String nullToBlank(String str) {
		return StringUtils.defaultString(str);
	}

	/**
	 * 渡された値がNullだったらブランク文字を返す。
	 * 
	 * @param i 対象の値
	 * @return 渡された値がNullだったらブランク文字、そうでなければ引数の値
	 */
	public static final String nullToBlank(Integer i) {
		if (Objects.isNull(i)) {
			return StringUtils.EMPTY;
		}
		return String.valueOf(i.intValue());
	}

	/**
	 * 渡された値がNullだったらブランク文字を返す。
	 * 
	 * @param l 対象の値
	 * @return 渡された値がNullだったらブランク文字、そうでなければ引数の値
	 */
	public static final String nullToBlank(Long l) {
		if (Objects.isNull(l)) {
			return StringUtils.EMPTY;
		}
		return String.valueOf(l.longValue());
	}

	/**
	 * 渡された値がNullだったらブランク文字を返す。
	 * 
	 * @param b 対象の値
	 * @return 渡された値がNullだったらブランク文字、そうでなければ引数の値
	 */
	public static final String nullToBlank(BigDecimal b) {
		if (Objects.isNull(b)) {
			return StringUtils.EMPTY;
		}
		return String.valueOf(b.toPlainString());
	}

	/**
	 * 渡された値が半角英数かどうかチェックする。
	 * 
	 * @param str チェックする文字列
	 * @return チェック結果
	 */
	public static final boolean isAlphaNumeric(String str) {
		if (StringUtils.isBlank(str)) {
			return true;
		}
		return Pattern.matches("^[0-9a-zA-Z]+$", str);
	}

	/**
	 * 渡された値が半角英数、半角スペースかどうかチェックする。
	 * 
	 * @param str チェックする文字列
	 * @return チェック結果
	 */
	public static final boolean isAlphaNumericOrSpace(String str) {
		if (StringUtils.isBlank(str)) {
			return true;
		}
		return Pattern.matches("^[a-zA-Z0-9][a-zA-Z0-9 ]*", str);
	}

	/**
	 * 渡された値が半角数値かどうかチェックする。
	 * 
	 * @param str チェックする文字列
	 * @return チェック結果
	 */
	public static final boolean isDigit(String str) {

		if (StringUtils.isBlank(str)) {
			return true;
		}

		boolean isDigit = true;
		for (int i = 0; i < str.length(); i++) {
			isDigit = Character.isDigit(str.charAt(i));
			if (!isDigit) {
				break;
			}
		}

		return isDigit;
	}

	/**
	 * 指定した文字列がバイト数の上限に達していないか確認する。
	 * 
	 * @param str           チェック対象の文字列
	 * @param maxbyteLength 入力できる最大バイト数
	 * @return 入力できる最大バイト数を超えていたらfalse
	 * @throws UnsupportedEncodingException
	 */
	public static final boolean isMaxbyteLength(String str, int maxbyteLength) throws UnsupportedEncodingException {

		if (StringUtils.isBlank(str)) {
			return true;
		}

		int valueByte = getStrBytes(str);
		boolean ret = (valueByte <= maxbyteLength);
		return ret;

	}

	/**
	 * 指定した文字列がバイト数を取得する
	 * 
	 * @param str
	 * @return
	 * @throws UnsupportedEncodingException
	 */
	public static final int getStrBytes(String str) throws UnsupportedEncodingException {
		if (StringUtils.isBlank(str)) {
			return 0;
		}

		return str.getBytes(DataIkoCharacters.ShiftJis.getValue()).length;
	}

	/**
	 * 半角文字チェック
	 * 
	 * @param value
	 * @return
	 */
	public static final boolean isHankaku(String value) {

		if (StringUtils.isEmpty(value)) {
			return true;
		}

		for (int i = 0; i < value.length(); i++) {
			char c = value.charAt(i);
			if ((c <= '\u007e') || // 英数字
					(c == '\u00a5') || // \記号
					(c == '\u203e') || // ~記号
					(c >= '\uff61' && c <= '\uff9f') // 半角カナ
			) {
				// 何もしない
			} else {
				return false;
			}
		}

		return true;

	}

	/**
	 * 全角文字チェック
	 * 
	 * @param value
	 * @return
	 */
	public static final boolean isZenkaku(String value) {

		if (StringUtils.isEmpty(value)) {
			return true;
		}

		Pattern pattern = Pattern.compile("[^ -~｡-ﾟ]*");
		Matcher matcher = pattern.matcher(value);

		if (!matcher.matches()) {
			// 環境依存文字の場合はさらにチェック
			int len = value.length();
			for (int i = 0; i < len; i++) {
				String s = value.substring(i, i + 1);
				if (isHankaku(s)) {
					return false;
				}
			}

		}

		return true;

	}

	/**
	 * 対象文字列の桁数をチェック
	 * 
	 * @return nullの場合は -1を返す。
	 */
	public static final int checkStrLenth(String value) {

		if (value == null) {
			return -1;
		}

		return value.length();
	}

	/**
	 * 指定した文字列が桁数の上限に達していないか確認する。
	 * 
	 * @param value  チェック対象の文字列
	 * @param length 入力できる最大桁数
	 * @return 入力できる最大バイト数を超えていたらfalse
	 */
	public static final boolean isMaxlength(String value, int length) {

		boolean ret = checkStrLenth(value) <= length;

		return ret;

	}

	/**
	 * 対象文字列から指摘した桁数を切り出し
	 * 
	 * @return nullの場合は nullを返す。
	 */
	public static final String cutStrByLength(String value, int size) {

		if (value == null || value.length() <= size) {
			return value;
		}

		return value.substring(0, size);
	}

	/**
	 * 対象文字列から指摘した数を切り出し
	 * 
	 * @return nullの場合は nullを返す。
	 * @throws UnsupportedEncodingException
	 */
	public static final String cutStrByteslength(String str, int bytes) throws UnsupportedEncodingException {

		int allBytes = getStrBytes(str);
		if (allBytes <= bytes) {
			return str;
		} else {

			// 指定したバイト数を超えた場合は、カットする。

			int from = bytes / 2 - 1;
			if (from < 1) {
				from = 1;
			}
			StringBuilder sb = new StringBuilder();
			sb.append(str.substring(0, from));

			int nowBytes = getStrBytes(sb.toString());
			if (nowBytes > bytes) {

				return null;
			}

			String oneLetter;
			while (from < str.length() && nowBytes < bytes) {
				oneLetter = str.substring(from, from + 1);
				if (isHankaku(oneLetter)) {
					// 半角の場合
					nowBytes++;
					sb.append(oneLetter);
				} else {
					// 全角の場合
					nowBytes += 2;
					if (nowBytes <= bytes) {
						sb.append(oneLetter);
					}
				}

				from++;

			}
			return sb.toString();

		}

	}

	/**
	 * 数値文字列の前後のスペースを取り除いでから、同一値かどうかチェックする。
	 * 
	 * @param baseValueStr 比較基準文字列
	 * @param checkValue   比較対象文字列
	 * @return
	 */
	public static boolean isSameNumber(String baseValueStr, String checkValue) {

		if (StringUtils.isEmpty(baseValueStr)) {
			return false;
		}

		if (StringUtils.isEmpty(checkValue)) {
			return false;
		}

		return Objects.equals(baseValueStr.trim(), checkValue.trim());
	}

	/**
	 * 数値の文字列をBigDecimalに変換する。
	 * 
	 * @param numStr 変換対象の文字列
	 * @return null時はnull、そうでなければBigDecimalに変換した値
	 */
	public static BigDecimal convertNumberStrToBigDecimal(String numStr) {

		if (StringUtils.isBlank(numStr)) {
			return BigDecimal.ZERO;
		}

		// カンマ区切りの場合を顧慮
		numStr.replace(",", "");
		try {
			return new BigDecimal(numStr.trim());
		} catch (Exception ex) {
			log.warn("数値変換に失敗しました。", ex);
			return null;
		}

	}

	/**
	 * 渡された値がNullだったら指定した値を返す。
	 * 
	 * @param val           対象の値
	 * @param defualtNumStr 渡された値がNullだったら指定した値、そうでなければ引数の値
	 * @return
	 */
	public static BigDecimal defaultBigDecimal(BigDecimal val, String defualtNumStr) {

		if (!Objects.isNull(val)) {
			return val;
		}

		return convertNumberStrToBigDecimal(defualtNumStr);

	}

	/**
	 * 指定した区切り文字で連結した文字列から、前半の文字列を取得する
	 * 
	 * 例: 00:XXXの文字列に対して、00を切り出す。
	 * 
	 * @param str
	 * @param separatorChar
	 * @return 区切り文字が含まなければ、対象Strを、区切り文字で始まる場合は、「""」を それ以外は区切り文字の前半の文字列を返す。
	 */
	public static String getFirstPartyStr(String str, String separatorChar) {

		if (StringUtils.isEmpty(str)) {
			return null;
		}

		int idx = str.indexOf(separatorChar);

		if (idx < 0) {
			return str;
		} else if (idx == 0) {
			return StringUtils.EMPTY;
		} else {
			String arr[] = StringUtils.split(str, separatorChar);
			return arr[0];
		}
	}

	/**
	 * 「{}」を指定したパラメータの値を置換する。
	 * 
	 * @param mesagePatern
	 * @param objects
	 * @return
	 */
	public static String formatLogMessage(String mesagePatern, Object... paramObjects) {

		if (StringUtils.isBlank(mesagePatern) || mesagePatern == null) {
			return mesagePatern;
		}

		StringBuilder sb = new StringBuilder();
		int idx = 0;
		for (int i = 0; i < mesagePatern.length(); i++) {
			if (Objects.equals(mesagePatern.subSequence(i, i + 1), "{")) {
				if (i + 1 < mesagePatern.length()) {
					if (Objects.equals(mesagePatern.subSequence(i, i + 2), "{}")) {
						// 置換する
						if (idx < paramObjects.length) {
							sb.append(paramObjects[idx]);
							idx++;
							i++;
						} else {
							// 対象パラメータがない場合、置換せずに
							sb.append(mesagePatern.subSequence(i, i + 1));
						}

					} else {
						sb.append(mesagePatern.subSequence(i, i + 1));
					}
				} else {
					sb.append(mesagePatern.subSequence(i, i + 1));
				}

			} else {
				sb.append(mesagePatern.subSequence(i, i + 1));
			}
		}

		return sb.toString();

	}

}
