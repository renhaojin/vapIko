package vap.kikan.dataIko;

import vap.kikan.dataIko.constant.DataIkoBatchStatusCode;

public class SingletonExitCode {

	public DataIkoBatchStatusCode exitCode = DataIkoBatchStatusCode.Normal;
	private static SingletonExitCode instance = new SingletonExitCode();

	private SingletonExitCode() {
	}

	public static SingletonExitCode getInstance() {
		return instance;
	}

	public void setExitCode(DataIkoBatchStatusCode exitCode) {
		this.exitCode = exitCode;
	}
}
