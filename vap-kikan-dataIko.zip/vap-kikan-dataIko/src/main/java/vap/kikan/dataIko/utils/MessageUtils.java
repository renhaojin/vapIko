package vap.kikan.dataIko.utils;

import java.util.Locale;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.MessageSourceResolvable;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.stereotype.Component;

/**
 * メッセージ取得系のユーティリティクラス。
 * 
 * @author kin
 *
 */
@Component
public class MessageUtils {

	private static MessageSource messageSource;

	@Autowired
	public void setMessageSource(MessageSource messageSource) {
		MessageUtils.messageSource = messageSource;
	}

	/**
	 * メッセージを取得します。
	 * 
	 * @param key  メッセージキー
	 * @param args 補足する内容
	 * @return メッセージ
	 */
	public static String getMessage(String key, String... args) {
		Locale locale = LocaleContextHolder.getLocale();
		return MessageUtils.messageSource.getMessage(key, args, locale);
	}

	/**
	 * ロケールを指定してメッセージを取得します。
	 *
	 * @param key    メッセージキー
	 * @param locale ロケール
	 * @param args   補足する内容
	 * @return メッセージ
	 */
	public static String getMessage(String key, Locale locale, String... args) {
		return MessageUtils.messageSource.getMessage(key, args, locale);
	}

	/**
	 * メッセージを取得します。
	 * 
	 * @param resolvable MessageSourceResolvable
	 * @return メッセージ
	 */
	public static String getMessage(MessageSourceResolvable resolvable) {
		Locale locale = LocaleContextHolder.getLocale();
		return MessageUtils.messageSource.getMessage(resolvable, locale);
	}
}
