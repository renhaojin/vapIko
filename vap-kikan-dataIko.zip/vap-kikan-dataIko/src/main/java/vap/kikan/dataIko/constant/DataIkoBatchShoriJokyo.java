package vap.kikan.dataIko.constant;

public enum DataIkoBatchShoriJokyo implements EnumEncodable<String> {

	Wait("W"), Processing("R"), NORMAL_END("0"), WARNING_END("1"), ABEND("2");

	private static final EnumDecoder<String, DataIkoBatchShoriJokyo> DECODER = EnumDecoder.create(values());

	private String shoriJokyo;

	private DataIkoBatchShoriJokyo(String str) {
		this.shoriJokyo = str;
	}

	@Override
	public String getValue() {
		return this.shoriJokyo;
	}

	/**
	 * コード値からEnumクラスを取得する。
	 * 
	 * @param code コード値
	 * @return 受領形式Enumクラス
	 */
	public static DataIkoBatchShoriJokyo decode(String code) {
		return DECODER.decode(code);
	}
}
