package vap.kikan.dataIko.dto.common;

import java.math.BigDecimal;
import java.time.LocalDateTime;

public interface DomaDto extends Dto {

    public BigDecimal getVersionNo();

    public void setVersionNo(BigDecimal versionNo);

    public void setRecInsertUserId(String recInsertUserId);

    public String getRecInsertUserId();

    public void setRecInsertDatetime(LocalDateTime recInsertDatetime);

    public LocalDateTime getRecInsertDatetime();

    public void setRecUpdateUserId(String recUpdateUserId);

    public String getRecUpdateUserId();

    public void setRecUpdateDatetime(LocalDateTime recUpdateDatetime);

    public LocalDateTime getRecUpdateDatetime();



}
