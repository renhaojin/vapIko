package vap.kikan.dataIko.common;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import vap.kikan.dataIko.dto.common.Dto;

/**
 * 
 * データ取込処理結果
 * 
 * @author kin
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public interface DataIkoIBatchShoriKekka {

	/**
	 * データ取込処理結果
	 * 
	 * @return
	 */
	@JsonIgnore
	default Dto getShoriKekka() {
		return null;
	}

}
