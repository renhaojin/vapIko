package vap.kikan.dataIko.dto.common;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import org.seasar.doma.Entity;
import org.seasar.doma.Version;
import lombok.Getter;
import lombok.Setter;

@SuppressWarnings("serial")
@Entity
@Setter
@Getter
public abstract class DomaDtoImpl implements DomaDto, Serializable {

    @Version
    BigDecimal versionNo;

    String recInsertUserId;

    LocalDateTime recInsertDatetime;

    String recInsertUserNm;

    String recUpdateUserId;

    LocalDateTime recUpdateDatetime;

    String recUpdateUserNm;

}
