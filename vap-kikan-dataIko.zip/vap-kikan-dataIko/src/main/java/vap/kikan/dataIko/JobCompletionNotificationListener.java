package vap.kikan.dataIko;

import java.time.LocalDateTime;

import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.listener.JobExecutionListenerSupport;
import org.springframework.stereotype.Component;

import lombok.extern.slf4j.Slf4j;
import vap.kikan.dataIko.constant.DataIkoBatchStatusCode;

@Component
@Slf4j
public class JobCompletionNotificationListener extends JobExecutionListenerSupport {

	@Override
	public void beforeJob(JobExecution jobExecution) {
		log.info("{} 処理開始  時刻：{}", jobExecution.getJobInstance().getJobName(), LocalDateTime.now());
	}

	@Override
	public void afterJob(JobExecution jobExecution) {
		SingletonExitCode exitCode = SingletonExitCode.getInstance();
		if (jobExecution.getStepExecutions().stream().anyMatch(s -> ExitStatus.FAILED.equals(s.getExitStatus()))) {
			log.error("Exit with code " + DataIkoBatchStatusCode.ErrorSystem.getCode());
			exitCode.setExitCode(DataIkoBatchStatusCode.ErrorSystem);
		} else {
			log.info("Exit with code " + DataIkoBatchStatusCode.Normal.getCode());
			exitCode.setExitCode(DataIkoBatchStatusCode.Normal);
		}

		log.info("{} 処理終了  時刻：{}", jobExecution.getJobInstance().getJobName(), LocalDateTime.now());
	}
}
