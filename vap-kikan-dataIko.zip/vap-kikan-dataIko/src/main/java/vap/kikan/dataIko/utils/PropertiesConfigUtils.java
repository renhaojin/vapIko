package vap.kikan.dataIko.utils;

import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.Properties;

/**
 * データ移行専用プロパティ設定Utils
 * 
 * @author NII kin
 *
 */
public class PropertiesConfigUtils {
	/** プロパティ設定オブジェクト */
	private static Properties properties = null;
	static {
		properties = (new PropertiesConfigUtils()).load("/application.properties");
	}

	private Properties load(String... propertiesFileName) {
		properties = new Properties();
		for (String propertyName : propertiesFileName) {
			try (InputStreamReader in = new InputStreamReader(getClass().getResourceAsStream(propertyName),
					StandardCharsets.UTF_8)) {
				properties.load(in);
			} catch (IOException e) {
				throw new IllegalArgumentException(e);
			}
		}
		return properties;
	}

	/**
	 * プロパティの値を取得する。
	 * 
	 * @param key プロパティキー
	 * @return プロパティの値
	 */
	public static String getProperty(String key) {
		return properties.getProperty(key);
	}
}
