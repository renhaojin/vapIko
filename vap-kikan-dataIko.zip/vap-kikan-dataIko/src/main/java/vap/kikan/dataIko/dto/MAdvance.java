package vap.kikan.dataIko.dto;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

import org.seasar.doma.Column;
import org.seasar.doma.Entity;
import org.seasar.doma.Id;
import org.seasar.doma.OriginalStates;
import org.seasar.doma.Table;
import org.seasar.doma.Version;

import vap.kikan.dataIko.dto.common.DomaDto;

/**
 * アドバンスマスタ
 */
@Entity
@Table(name = "M_ADVANCE")
public class MAdvance implements DomaDto {

	/** 契約番号 */
	@Id
	@Column(name = "KEIYAKU_NUMBER")
	String keiyakuNumber;

	/** 枝番 */
	@Id
	@Column(name = "EDABAN")
	String edaban;

	/** アドバンス条件ＮＯ */
	@Id
	@Column(name = "ADVANCE_JOKEN_NUMBER")
	BigDecimal advanceJokenNumber;

	/** 商品グループコード */
	@Column(name = "SHOHIN_GROUP_CODE")
	String shohinGroupCode;

	/** アドバンスコード */
	@Column(name = "ADVANCE_CODE")
	String advanceCode;

	/** 制作部門区分 */
	@Column(name = "SEISAKU_BUMON_KUBUN")
	String seisakuBumonKubun;

	/** アドバンス金額（前渡金発生額） */
	@Column(name = "ADVANCE_KINGAKU_ZENTOKIN_KINGAKU_HASSEI_KINGAKU")
	BigDecimal advanceKingakuZentokinKingakuHasseiKingaku;

	/** 作品名（印税管理用） */
	@Column(name = "SAKUHIN_NAME_INZEI_KANRI_YO")
	String sakuhinNameInzeiKanriYo;

	/** メモ１ */
	@Column(name = "MEMO1")
	String memo1;

	/** メモ２ */
	@Column(name = "MEMO2")
	String memo2;

	/** その他相殺額 */
	@Column(name = "ETC_SOUSAI_KINGAKU")
	BigDecimal etcSousaiKingaku;

	/** アドバンス金額（前渡金発生額）発生日 */
	@Column(name = "ADVANCE_KINGAKU_ZENTOKIN_KINGAKU_HASSEI_KINGAKU_HASSEI_DATE")
	LocalDate advanceKingakuZentokinKingakuHasseiKingakuHasseiDate;

	/** その他相殺額発生日 */
	@Column(name = "ETC_SOUSAI_KINGAKU_HASSEI_DATE")
	LocalDate etcSousaiKingakuHasseiDate;

	/** バージョン番号 */
	@Version
	@Column(name = "VERSION_NO")
	BigDecimal versionNo;

	/** 登録日時 */
	@Column(name = "REC_INSERT_DATETIME")
	LocalDateTime recInsertDatetime;

	/** 登録ユーザーＩＤ */
	@Column(name = "REC_INSERT_USER_ID")
	String recInsertUserId;

	/** 更新日時 */
	@Column(name = "REC_UPDATE_DATETIME")
	LocalDateTime recUpdateDatetime;

	/** 更新ユーザーＩＤ */
	@Column(name = "REC_UPDATE_USER_ID")
	String recUpdateUserId;

	/** */
	@OriginalStates
	MAdvance originalStates;

	/**
	 * Returns the keiyakuNumber.
	 * 
	 * @return the keiyakuNumber
	 */
	public String getKeiyakuNumber() {
		return keiyakuNumber;
	}

	/**
	 * Sets the keiyakuNumber.
	 * 
	 * @param keiyakuNumber the keiyakuNumber
	 */
	public void setKeiyakuNumber(String keiyakuNumber) {
		this.keiyakuNumber = keiyakuNumber;
	}

	/**
	 * Returns the edaban.
	 * 
	 * @return the edaban
	 */
	public String getEdaban() {
		return edaban;
	}

	/**
	 * Sets the edaban.
	 * 
	 * @param edaban the edaban
	 */
	public void setEdaban(String edaban) {
		this.edaban = edaban;
	}

	/**
	 * Returns the advanceJokenNumber.
	 * 
	 * @return the advanceJokenNumber
	 */
	public BigDecimal getAdvanceJokenNumber() {
		return advanceJokenNumber;
	}

	/**
	 * Sets the advanceJokenNumber.
	 * 
	 * @param advanceJokenNumber the advanceJokenNumber
	 */
	public void setAdvanceJokenNumber(BigDecimal advanceJokenNumber) {
		this.advanceJokenNumber = advanceJokenNumber;
	}

	/**
	 * Returns the shohinGroupCode.
	 * 
	 * @return the shohinGroupCode
	 */
	public String getShohinGroupCode() {
		return shohinGroupCode;
	}

	/**
	 * Sets the shohinGroupCode.
	 * 
	 * @param shohinGroupCode the shohinGroupCode
	 */
	public void setShohinGroupCode(String shohinGroupCode) {
		this.shohinGroupCode = shohinGroupCode;
	}

	/**
	 * Returns the advanceCode.
	 * 
	 * @return the advanceCode
	 */
	public String getAdvanceCode() {
		return advanceCode;
	}

	/**
	 * Sets the advanceCode.
	 * 
	 * @param advanceCode the advanceCode
	 */
	public void setAdvanceCode(String advanceCode) {
		this.advanceCode = advanceCode;
	}

	/**
	 * Returns the seisakuBumonKubun.
	 * 
	 * @return the seisakuBumonKubun
	 */
	public String getSeisakuBumonKubun() {
		return seisakuBumonKubun;
	}

	/**
	 * Sets the seisakuBumonKubun.
	 * 
	 * @param seisakuBumonKubun the seisakuBumonKubun
	 */
	public void setSeisakuBumonKubun(String seisakuBumonKubun) {
		this.seisakuBumonKubun = seisakuBumonKubun;
	}

	/**
	 * Returns the advanceKingakuZentokinKingakuHasseiKingaku.
	 * 
	 * @return the advanceKingakuZentokinKingakuHasseiKingaku
	 */
	public BigDecimal getAdvanceKingakuZentokinKingakuHasseiKingaku() {
		return advanceKingakuZentokinKingakuHasseiKingaku;
	}

	/**
	 * Sets the advanceKingakuZentokinKingakuHasseiKingaku.
	 * 
	 * @param advanceKingakuZentokinKingakuHasseiKingaku the
	 *                                                   advanceKingakuZentokinKingakuHasseiKingaku
	 */
	public void setAdvanceKingakuZentokinKingakuHasseiKingaku(BigDecimal advanceKingakuZentokinKingakuHasseiKingaku) {
		this.advanceKingakuZentokinKingakuHasseiKingaku = advanceKingakuZentokinKingakuHasseiKingaku;
	}

	/**
	 * Returns the sakuhinNameInzeiKanriYo.
	 * 
	 * @return the sakuhinNameInzeiKanriYo
	 */
	public String getSakuhinNameInzeiKanriYo() {
		return sakuhinNameInzeiKanriYo;
	}

	/**
	 * Sets the sakuhinNameInzeiKanriYo.
	 * 
	 * @param sakuhinNameInzeiKanriYo the sakuhinNameInzeiKanriYo
	 */
	public void setSakuhinNameInzeiKanriYo(String sakuhinNameInzeiKanriYo) {
		this.sakuhinNameInzeiKanriYo = sakuhinNameInzeiKanriYo;
	}

	/**
	 * Returns the memo1.
	 * 
	 * @return the memo1
	 */
	public String getMemo1() {
		return memo1;
	}

	/**
	 * Sets the memo1.
	 * 
	 * @param memo1 the memo1
	 */
	public void setMemo1(String memo1) {
		this.memo1 = memo1;
	}

	/**
	 * Returns the memo2.
	 * 
	 * @return the memo2
	 */
	public String getMemo2() {
		return memo2;
	}

	/**
	 * Sets the memo2.
	 * 
	 * @param memo2 the memo2
	 */
	public void setMemo2(String memo2) {
		this.memo2 = memo2;
	}

	/**
	 * Returns the etcSousaiKingaku.
	 * 
	 * @return the etcSousaiKingaku
	 */
	public BigDecimal getEtcSousaiKingaku() {
		return etcSousaiKingaku;
	}

	/**
	 * Sets the etcSousaiKingaku.
	 * 
	 * @param etcSousaiKingaku the etcSousaiKingaku
	 */
	public void setEtcSousaiKingaku(BigDecimal etcSousaiKingaku) {
		this.etcSousaiKingaku = etcSousaiKingaku;
	}

	/**
	 * Returns the advanceKingakuZentokinKingakuHasseiKingakuHasseiDate.
	 * 
	 * @return the advanceKingakuZentokinKingakuHasseiKingakuHasseiDate
	 */
	public LocalDate getAdvanceKingakuZentokinKingakuHasseiKingakuHasseiDate() {
		return advanceKingakuZentokinKingakuHasseiKingakuHasseiDate;
	}

	/**
	 * Sets the advanceKingakuZentokinKingakuHasseiKingakuHasseiDate.
	 * 
	 * @param advanceKingakuZentokinKingakuHasseiKingakuHasseiDate the
	 *                                                             advanceKingakuZentokinKingakuHasseiKingakuHasseiDate
	 */
	public void setAdvanceKingakuZentokinKingakuHasseiKingakuHasseiDate(
			LocalDate advanceKingakuZentokinKingakuHasseiKingakuHasseiDate) {
		this.advanceKingakuZentokinKingakuHasseiKingakuHasseiDate = advanceKingakuZentokinKingakuHasseiKingakuHasseiDate;
	}

	/**
	 * Returns the etcSousaiKingakuHasseiDate.
	 * 
	 * @return the etcSousaiKingakuHasseiDate
	 */
	public LocalDate getEtcSousaiKingakuHasseiDate() {
		return etcSousaiKingakuHasseiDate;
	}

	/**
	 * Sets the etcSousaiKingakuHasseiDate.
	 * 
	 * @param etcSousaiKingakuHasseiDate the etcSousaiKingakuHasseiDate
	 */
	public void setEtcSousaiKingakuHasseiDate(LocalDate etcSousaiKingakuHasseiDate) {
		this.etcSousaiKingakuHasseiDate = etcSousaiKingakuHasseiDate;
	}

	/**
	 * Returns the versionNo.
	 * 
	 * @return the versionNo
	 */
	public BigDecimal getVersionNo() {
		return versionNo;
	}

	/**
	 * Sets the versionNo.
	 * 
	 * @param versionNo the versionNo
	 */
	public void setVersionNo(BigDecimal versionNo) {
		this.versionNo = versionNo;
	}

	/**
	 * Returns the recInsertDatetime.
	 * 
	 * @return the recInsertDatetime
	 */
	public LocalDateTime getRecInsertDatetime() {
		return recInsertDatetime;
	}

	/**
	 * Sets the recInsertDatetime.
	 * 
	 * @param recInsertDatetime the recInsertDatetime
	 */
	public void setRecInsertDatetime(LocalDateTime recInsertDatetime) {
		this.recInsertDatetime = recInsertDatetime;
	}

	/**
	 * Returns the recInsertUserId.
	 * 
	 * @return the recInsertUserId
	 */
	public String getRecInsertUserId() {
		return recInsertUserId;
	}

	/**
	 * Sets the recInsertUserId.
	 * 
	 * @param recInsertUserId the recInsertUserId
	 */
	public void setRecInsertUserId(String recInsertUserId) {
		this.recInsertUserId = recInsertUserId;
	}

	/**
	 * Returns the recUpdateDatetime.
	 * 
	 * @return the recUpdateDatetime
	 */
	public LocalDateTime getRecUpdateDatetime() {
		return recUpdateDatetime;
	}

	/**
	 * Sets the recUpdateDatetime.
	 * 
	 * @param recUpdateDatetime the recUpdateDatetime
	 */
	public void setRecUpdateDatetime(LocalDateTime recUpdateDatetime) {
		this.recUpdateDatetime = recUpdateDatetime;
	}

	/**
	 * Returns the recUpdateUserId.
	 * 
	 * @return the recUpdateUserId
	 */
	public String getRecUpdateUserId() {
		return recUpdateUserId;
	}

	/**
	 * Sets the recUpdateUserId.
	 * 
	 * @param recUpdateUserId the recUpdateUserId
	 */
	public void setRecUpdateUserId(String recUpdateUserId) {
		this.recUpdateUserId = recUpdateUserId;
	}
}