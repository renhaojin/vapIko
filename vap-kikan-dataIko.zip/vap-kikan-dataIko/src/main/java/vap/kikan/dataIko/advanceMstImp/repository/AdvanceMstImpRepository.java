package vap.kikan.dataIko.advanceMstImp.repository;

import org.springframework.stereotype.Repository;

import vap.kikan.dataIko.advanceMstImp.dao.AdvanceMstImpDao;
import vap.kikan.dataIko.dao.MAdvanceDao;
import vap.kikan.dataIko.dao.MShohinDao;
import vap.kikan.dataIko.dao.WkIkoZentokinKeiyakuNumberDao;
import vap.kikan.dataIko.dto.MAdvance;
import vap.kikan.dataIko.dto.MShohin;
import vap.kikan.dataIko.dto.WkIkoZentokinKeiyakuNumber;

@Repository
public class AdvanceMstImpRepository {

	private AdvanceMstImpDao advanceMstImpDao;
	private MShohinDao mShohinDao;
	private MAdvanceDao mAdvanceDao;
	private WkIkoZentokinKeiyakuNumberDao wkIkoZentokinKeiyakuNumberDao;

	/**
	 * アドバンスマスタ取込Repository
	 * 
	 * @param advanceMstImpDao
	 * @param mShohinDao
	 * @param mAdvanceDao
	 * @param wkIkoZentokinKeiyakuNumberDao
	 */
	public AdvanceMstImpRepository(AdvanceMstImpDao advanceMstImpDao, MShohinDao mShohinDao, MAdvanceDao mAdvanceDao,
			WkIkoZentokinKeiyakuNumberDao wkIkoZentokinKeiyakuNumberDao) {
		this.advanceMstImpDao = advanceMstImpDao;
		this.mShohinDao = mShohinDao;
		this.mAdvanceDao = mAdvanceDao;
		this.wkIkoZentokinKeiyakuNumberDao = wkIkoZentokinKeiyakuNumberDao;
	}

	/**
	 * 印税マスタワークより商品コードを取得
	 * 
	 * @param inzeiCode 印税コード
	 * @param keisanNo  計算NO
	 * @return 商品コード
	 */
	public String selectInzei(String inzeiCode, String keisanNo) {
		return advanceMstImpDao.selectInzei(inzeiCode, keisanNo);
	}

	/**
	 * 商品マスタからデータ取得
	 * 
	 * @param shohinCode
	 * @return 商品情報
	 */
	public MShohin selectMShohinById(String shohinCode) {
		return mShohinDao.selectById(shohinCode);
	}

	/**
	 * アドバンスマスタ登録
	 * 
	 * @param entity アドバンスマスタエンティティ
	 * @return 登録件数
	 */
	public int insertMAdvance(MAdvance entity) {
		return mAdvanceDao.insert(entity);
	}

	/**
	 * 移行前渡金契約番号ワーク登録
	 * 
	 * @param entity 移行前渡金契約番号ワーク
	 * @return 登録件数
	 */
	public int insertWkIkoZentokinKeiyakuNumber(WkIkoZentokinKeiyakuNumber entity) {
		return wkIkoZentokinKeiyakuNumberDao.insert(entity);
	}
}
