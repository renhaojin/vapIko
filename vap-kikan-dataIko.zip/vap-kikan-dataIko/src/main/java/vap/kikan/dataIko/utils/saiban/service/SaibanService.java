package vap.kikan.dataIko.utils.saiban.service;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import lombok.extern.slf4j.Slf4j;
import vap.kikan.dataIko.dto.TSaiban;
import vap.kikan.dataIko.exception.SaibanException;
import vap.kikan.dataIko.utils.saiban.repository.SaibanRepository;

/**
 * 採番処理を行う。
 * 
 * @author kin
 *
 */
@Service
@Transactional
@Slf4j
public class SaibanService {

	SaibanRepository saibanRepository;

	public SaibanService(SaibanRepository saibanRepository) {
		this.saibanRepository = saibanRepository;
	}

	/**
	 * 採番時の共通処理
	 * 
	 * @param saibanId    採番ID
	 * @param updDatetime 更新日時
	 * @param userId      更新ユーザー
	 * @return 採番結果
	 */
//	@Transactional(propagation = Propagation.REQUIRES_NEW)
	public long getSaiban(String saibanId) {
		// 採番マスタの検索
		TSaiban entity = saibanRepository.selectBySaibanId(saibanId);
		if (entity == null) {
			log.error("採番マスタに該当するデータがありません。採番IDは" + saibanId + "です。");
			throw new SaibanException("採番マスタに該当するデータがありません。採番IDは" + saibanId + "です。");
		}

		// 最新番号
		long newNo = entity.getLatestNumber().longValue();

		newNo++;
		if (newNo > entity.getMaxNumber().longValue()) {
			// 最新番号が最大番号より大きかったらエラー
			log.error("最大番号を超えました。採番IDは" + saibanId + "、設定されている最大番号は" + entity.getMaxNumber() + "です。");
			throw new SaibanException("最大番号を超えました。採番IDは" + saibanId + "、設定されている最大番号は" + entity.getMaxNumber() + "です。");
		}
		// 採番マスタ更新
		try {
			entity.setLatestNumber(new BigDecimal(newNo));
			entity.setRecUpdateDatetime(LocalDateTime.now());
			entity.setRecUpdateUserId("dataIko");
			saibanRepository.updateSaiban(entity);
		} catch (Exception e) {
			log.error("採番マスタ更新処理に失敗しました。" + e.getMessage());
			throw e;
		}
		return newNo;
	}
}
