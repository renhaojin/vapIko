package vap.kikan.dataIko.constant;

/**
 * データ移行実行時の戻り値。
 * 
 * @author kin
 *
 */
public enum DataIkoBatchStatusCode {

	Normal(0), ErrorRequired(1), ErrorExists(2), ErrorSystem(9);

	private DataIkoBatchStatusCode(int code) {
		this.code = code;
	}

	private int code;

	/**
	 * コードを返す。
	 * 
	 * @return コード
	 */
	public int getCode() {
		return code;
	}
}
