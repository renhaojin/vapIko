package vap.kikan.dataIko.exception;

/**
 * 採番処理中に発生した例外。
 * 
 * @author kin
 *
 */
public class SaibanException extends RuntimeException {

	private static final long serialVersionUID = -11675351034343506L;

	/**
	 * コンストラクタ。
	 * 
	 * @param message エラー内容
	 */
	public SaibanException(String message) {
		super(message);
	}

	/**
	 * コンストラクタ。
	 * 
	 * @param message エラー内容
	 * @param e       エラーの詳細
	 */
	public SaibanException(String message, Throwable e) {
		super(message, e);
	}
}
