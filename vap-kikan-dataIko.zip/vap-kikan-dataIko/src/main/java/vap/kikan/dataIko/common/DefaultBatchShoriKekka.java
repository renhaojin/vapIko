package vap.kikan.dataIko.common;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.ToString;

@AllArgsConstructor
@Getter
@ToString
public class DefaultBatchShoriKekka implements DataIkoIBatchShoriKekka {


    private String message;
}
