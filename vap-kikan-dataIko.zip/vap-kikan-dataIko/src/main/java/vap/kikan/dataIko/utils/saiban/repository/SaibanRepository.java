package vap.kikan.dataIko.utils.saiban.repository;

import org.springframework.stereotype.Repository;

import vap.kikan.dataIko.dao.TSaibanDao;
import vap.kikan.dataIko.dto.TSaiban;

/**
 * 採番処理用Repositoryクラス
 * 
 * @author kin
 *
 */
@Repository
public class SaibanRepository {

	TSaibanDao tSaibanDao;

	public SaibanRepository(TSaibanDao tSaibanDao) {
		this.tSaibanDao = tSaibanDao;
	}

	/**
	 * 採番テーブルを照会する。
	 * 
	 * @param saibanId 採番ID
	 * @return 照会結果
	 */
	public TSaiban selectBySaibanId(String saibanId) {
		TSaiban saiban = tSaibanDao.selectById(saibanId);
		return saiban;
	}

	/**
	 * 採番テーブルを更新する。
	 * 
	 * @param saiban 更新値
	 * @return 更新した件数
	 */
	public int updateSaiban(TSaiban saiban) {
		int count = tSaibanDao.update(saiban);
		return count;
	}
}
