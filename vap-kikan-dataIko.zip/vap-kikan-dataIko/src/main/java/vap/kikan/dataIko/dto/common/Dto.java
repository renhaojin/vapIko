package vap.kikan.dataIko.dto.common;

public interface Dto {
}
