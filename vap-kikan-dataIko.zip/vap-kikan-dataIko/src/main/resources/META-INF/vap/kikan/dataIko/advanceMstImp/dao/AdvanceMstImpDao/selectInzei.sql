select
  IZSHCD 
from
  WK_IKO_M_INZEI 
where
  IZIZCD = /* inzeiCode */'000000' 
  and IZKENO = /* keisanNo */'0' 
order by
  IZIZCD
  , IZKENO
  , IZEDNO
  , IZSHCD fetch first 1 rows only
